## build 
```shell
# build binary into ./bin
make build

# install binary into $GOPATH/bin
make install
```
## test
```shell
# gentle start
./bin/tfd --home ./play_sh/tokenfactory-1 start --pruning=nothing --grpc-web.enable=false --grpc.address="0.0.0.0:9090" --trace --log_level=trace
# destructive start
./play_tf.sh

# set up environment
source ./chains.env

# account addresses
tfd $NODE_HOME $KEYRING keys show tf1_owner -a
tfd $NODE_HOME $KEYRING keys show tf2_owner -a
tfd $NODE_HOME $KEYRING keys show masterminter -a
tfd $NODE_HOME $KEYRING keys show mintercontroller -a
tfd $NODE_HOME $KEYRING keys show minter -a
tfd $NODE_HOME $KEYRING keys show blacklister -a
tfd $NODE_HOME $KEYRING keys show pauser -a
tfd $NODE_HOME $KEYRING keys show user -a

# balances
tfd q bank balances $TF1_OWNER $NODE_CHAIN
tfd q bank balances $TF2_OWNER $NODE_CHAIN
tfd q bank balances $MASTERMINTER $NODE_CHAIN
tfd q bank balances $MINTER $NODE_CHAIN
tfd q bank balances $VALIDATOR $NODE_CHAIN
tfd q bank balances $USER $NODE_CHAIN
tfd q bank balances $USER2 $NODE_CHAIN

tfd q bank total $NODE_CHAIN

tfd q bank denom-metadata --denom uwfusd $NODE_CHAIN

tfd tx bank send $TF1_OWNER $USER 10stake $NODE_CHAIN $NODE_HOME $KEYRING -y

# query tx
tfd q tx A99B16037D830E9142407BA9AE660183728F4220EE27A8C54FFECC0E8C5AB975 $NODE_CHAIN  

# query tokenfactory
## roles
### params
tfd q tokenfactory params $NODE_HOME
tfd q fiat-tokenfactory params $NODE_HOME

### owner: one per tokenfactory
tfd q tokenfactory show-owner $NODE_HOME
tfd q fiat-tokenfactory show-owner $NODE_HOME

### masterminter: one per tokenfactory
tfd q tokenfactory show-master-minter $NODE_HOME
tfd q fiat-tokenfactory show-master-minter $NODE_HOME

### mintercontroller: each address can be only once per tokenfactory, i.e., the pair (controller, minter) is unique in controller
tfd q tokenfactory show-minter-controller $MINTERCONTROLLER $NODE_HOME
## bug: query result is independent of controller address
tfd q tokenfactory list-minter-controller $MINTERCONTROLLER $NODE_HOME

### minting denom
tfd q tokenfactory show-minting-denom $NODE_CHAIN
tfd q fiat-tokenfactory show-minting-denom $NODE_CHAIN

### minter: always paired with a mintercontroller
tfd q tokenfactory show-minters $MINTER $NODE_CHAIN
## bug: query result is independent of controller address; this may be all minters
tfd q tokenfactory list-minters $MINTERCONTROLLER $NODE_CHAIN

### blacklister: one per tokenfactory
tfd q tokenfactory show-blacklister $NODE_CHAIN

### pauser: one per tokenfactory
tfd q tokenfactory show-pauser $NODE_CHAIN
## states
tfd q tokenfactory show-blacklisted $USER $NODE_CHAIN
tfd q tokenfactory list-blacklisted $BLACKLISTER $NODE_CHAIN

tfd q tokenfactory show-paused $NODE_CHAIN

### feegrant
## a single grant
tfd q feegrant grant $FAUCET $USER $NODE_CHAIN
## grants by granter 
tfd q feegrant grants-by-granter $FAUCET $NODE_CHAIN
## grants by grantee 
tfd q feegrant grants-by-grantee $USER $NODE_CHAIN

# tx tokenfactory
## owner
## TODO: update-owner does not change the owner
tfd tx tokenfactory update-owner $TF2_OWNER --from tf1_owner $NODE_CHAIN $NODE_HOME $KEYRING -y # --trace --log_level=trace
## TODO: Error: unknown command "noble1h8jmqsfl4mlmaqmul3malxtmsmzcved9e0sdmg" for "nobled tx tokenfactory accept-owner"
tfd tx tokenfactory accept-owner $TF2_OWNER --from tf1_owner $NODE_CHAIN $NODE_HOME $KEYRING -y # --trace --log_level=trace

## masterminter
tfd tx tokenfactory update-master-minter $USER --from tf1_owner $NODE_CHAIN $NODE_HOME $KEYRING -y
tfd tx tokenfactory update-master-minter $MASTERMINTER --from tf1_owner $NODE_CHAIN $NODE_HOME $KEYRING -y

## mintercontroller
tfd tx tokenfactory configure-minter-controller $MINTERCONTROLLER $USER --from masterminter $NODE_CHAIN $NODE_HOME $KEYRING -y
tfd tx tokenfactory configure-minter-controller $MINTERCONTROLLER $MINTER --from masterminter $NODE_CHAIN $NODE_HOME $KEYRING -y
tfd tx tokenfactory configure-minter-controller $USER $MINTER --from masterminter $NODE_CHAIN $NODE_HOME $KEYRING -y

tfd tx tokenfactory remove-minter-controller $USER --from masterminter $NODE_CHAIN $NODE_HOME $KEYRING -y

## minter
tfd tx tokenfactory configure-minter $MINTER 10000uwfusd --from mintercontroller $NODE_CHAIN $NODE_HOME $KEYRING -y

tfd tx tokenfactory remove-minter $MINTER --from mintercontroller $NODE_CHAIN $NODE_HOME $KEYRING -y

tfd tx tokenfactory configure-minter $MINTER 1000uwfusd --from mintercontroller $NODE_CHAIN $NODE_HOME $KEYRING -y

## blacklister and blacklist
tfd tx tokenfactory update-blacklister $USER --from tf1_owner $NODE_CHAIN $NODE_HOME $KEYRING -y

tfd tx tokenfactory update-blacklister $BLACKLISTER --from tf1_owner $NODE_CHAIN $NODE_HOME $KEYRING -y

tfd tx tokenfactory blacklist $USER --from blacklister $NODE_CHAIN $NODE_HOME $KEYRING -y

tfd tx tokenfactory unblacklist $USER --from blacklister $NODE_CHAIN $NODE_HOME $KEYRING -y

## pauser and pause
tfd tx tokenfactory update-pauser $USER --from tf1_owner $NODE_CHAIN $NODE_HOME $KEYRING -y

tfd tx tokenfactory update-pauser $PAUSER --from tf1_owner $NODE_CHAIN $NODE_HOME $KEYRING -y

tfd tx tokenfactory pause --from pauser $NODE_CHAIN $NODE_HOME $KEYRING -y

tfd tx tokenfactory unpause --from pauser $NODE_CHAIN $NODE_HOME $KEYRING -y

## mint and burn
tfd tx tokenfactory mint $USER 10uwfusd --from minter $NODE_CHAIN $NODE_HOME $KEYRING -y

tfd tx bank send $USER $MINTER 10uwfusd --from user $NODE_CHAIN $NODE_HOME $KEYRING -y
tfd tx tokenfactory burn 10uwfusd --from minter $NODE_CHAIN $NODE_HOME $KEYRING -y

## feegrant
### grant
#### NOTE: --from is not used. siged by granter
tfd tx feegrant grant $TF1_OWNER $USER --spend-limit 100stake --expiration 2025-01-30T15:04:05Z --from minter $NODE_CHAIN $NODE_HOME $KEYRING -y 
tfd tx feegrant grant $TF2_OWNER $USER --spend-limit 100stake --expiration 2025-01-30T15:04:05Z $NODE_CHAIN $NODE_HOME $KEYRING -y 

### revoke
#### NOTE: --from is not used. siged by granter
tfd tx feegrant revoke $TF1_OWNER $USER --from tf1_owner $NODE_CHAIN $NODE_HOME $KEYRING -y
tfd tx feegrant revoke $TF2_OWNER $USER --from user2 $NODE_CHAIN $NODE_HOME $KEYRING -y


#tfd keys show $TF2_OWNER $NODE_HOME $KEYRING 

#tfd q tx 55CECA5040C85D36466E7CE7826BBAE3B23624202EC0D1D92DC28C94F4E89294 $NODE_CHAIN  

```

## run cosmwasm tokenfactory contract
```shell
## upload wasm code and get $CODE_ID: two steps
STORE=$(tfd tx wasm store ../../../rust/cosmos/wfdc2/target/wasm32-unknown-unknown/release/tokenfactory_optimized.wasm --from tf1_owner $TXFLAG $KEYRING $NODE_HOME -y -b sync --output json) && \
TX_HASH=$(echo $STORE | jq -r '.txhash') && \
echo "$TX_HASH" && \
sleep 5 && \
TX=$(tfd q tx $TX_HASH $NODE_CHAIN --output json) && \
CODE_ID=$(echo $TX | jq -r '.logs[0].events[-1].attributes[1].value') && \
echo $CODE_ID
# 1
# or
TX_HASH=D9A408CA25D3A06F9251BFF0969D601E1A34174CD64EAFF9212A872F4FFF622C && \
TX=$(tfd q tx $TX_HASH $NODE_CHAIN --output json) && \
CODE_ID=$(echo $TX | jq -r '.events[] | select(.type == "store_code").attributes[] | select(.key == "code_id").value')
echo "CODE_ID: $CODE_ID"
# 1

## instantiate and get CONTRACT_ADDRESS: two steps
INIT=$(jq -n --arg is_tf "true" '{ "is_tf": $is_tf | test("true") }') && \
echo $INIT && \
RES=$(tfd tx wasm instantiate $CODE_ID "$INIT" --from tf1_owner --label "tf" --no-admin $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
sleep 5 && \
CONTRACT_ADDRESS=$(tfd query wasm list-contract-by-code $CODE_ID $NODE_CHAIN --output json | jq -r '.contracts[-1]') && \
echo $CONTRACT_ADDRESS

# or
TX_HASH=AAB71E9021BC4B4AA3E928A30EA8B7BC6A30610234234E3F94125EEFD39AB685 && \
TX=$(tfd q tx $TX_HASH $NODE_CHAIN --output json) && \
CONTRACT_ADDRESS=$(echo $TX | jq -r '.events[] | select(.type == "wasm").attributes[] | select(.key == "_contract_address").value') && \
echo $CONTRACT_ADDRESS

# tf:  wf14hj2tavq8fpesdwxxcu44rty3hh90vhujrvcmstl4zr3txmfvw9s2s4a5q

## queries
### config raw data
tfd q wasm contract-state raw $CONTRACT_ADDRESS "config" --ascii 
#### tf  {is_tf: true}  - data: eyJpc190ZiI6dHJ1ZX0=
#### ftf {is_tf: false} - data: eyJpc190ZiI6ZmFsc2V9

JSON=$(jq -n '{ config: {} }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n '{ tf: { params: {} } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n '{ tf: { owner: {} } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n '{ tf: { master_minter: {} } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n --arg address "$MINTERCONTROLLER" '{ tf: { minter_controller: { address: $address } } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n '{ tf: { all_minter_controllers: {} } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n --arg address "$MINTER" '{ tf: { minting_denom: {} } }') && \
echo $JSON && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n --arg address "$MINTER" '{ tf: { minters: { address: $address } } }') && \
echo $JSON && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n '{ tf: { all_minters: {} } }') && \
echo $JSON && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n '{ tf: { blacklister: {} } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

# being empty shows some error
JSON=$(jq -n --arg address "$USER" '{ tf: { blacklisted: { address: $address } } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

# being empty shows some error
JSON=$(jq -n '{ tf: { all_blacklisted: {} } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n '{ tf: { pauser: {} } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n '{ tf: { paused: {} } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n '{ bank: { all_denom_metadata: {} } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n --arg base_denom "cent" '{ bank: { denom_metadata: { "denom": $base_denom } } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n --arg base_denom "uwfusd" '{ bank: { denom_metadata: { "denom": $base_denom } } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n --arg base_denom "cent" --arg denom "USD" '{ bank: { find_denom_metadata: { "base_denom": $base_denom, "denom": $denom } } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n --arg base_denom "uwfusd" --arg denom "mwfusd" '{ bank: { find_denom_metadata: { "base_denom": $base_denom, "denom": $denom } } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n --arg denom "USD" '{ bank: { find_metadata_for_denom: { "denom": $denom } } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n --arg denom "mwfusd" '{ bank: { find_metadata_for_denom: { "denom": $denom } } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n --arg granter "$FAUCET" --arg grantee "$USER" '{ feegrant: { fee_basic_allowance: { "granter": $granter, "grantee": $grantee } } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq


## execute txs
# update_master_minter
#JSON=$(jq -n --arg address "$USER" \
JSON=$(jq -n --arg address "$MASTERMINTER" \
'{ tf: { "update_master_minter": { "address": $address } } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from tf1_owner $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

# configure_minter_controller
JSON=$(jq -n --arg controller "$MINTERCONTROLLER" --arg minter "$MINTER" \
'{ tf: { "configure_minter_controller": { "controller": $controller, "minter": $minter } } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from masterminter $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

# remove_minter_controller
JSON=$(jq -n --arg controller "$MINTERCONTROLLER" \
'{ tf: { "remove_minter_controller": { "controller": $controller } } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from masterminter $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

# configure_minter
JSON=$(jq -n --arg address "$MINTER" --arg allowance_denom "uwfusd" --arg allowance_value 500 \
'{ tf: { "configure_minter": { "address": $address, "allowance_denom": $allowance_denom, "allowance_value": $allowance_value | tonumber } } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from mintercontroller $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

# remove_minter
JSON=$(jq -n --arg address "$MINTER" \
'{ tf: { "remove_minter": { "address": $address } } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from mintercontroller $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

# update_blacklister
JSON=$(jq -n --arg address "$BLACKLISTER" \
'{ tf: { "update_blacklister": { "address": $address } } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from tf1_owner $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

# blacklist
JSON=$(jq -n --arg address "$USER" \
'{ tf: { "blacklist": { "address": $address } } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from blacklister $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

# unblacklist
JSON=$(jq -n --arg address "$USER" \
'{ tf: { "unblacklist": { "address": $address } } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from blacklister $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

# update_pauser
JSON=$(jq -n --arg address "$PAUSER" \
'{ tf: { "update_pauser": { "address": $address } } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from tf1_owner $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

# pause
JSON=$(jq -n \
'{ tf: { "pause": { } } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from pauser $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

# unpause
JSON=$(jq -n \
'{ tf: { "unpause": { } } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from pauser $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

# mint
# minting decreases minter's allowance
JSON=$(jq -n --arg address "$USER" --arg denom "uwfusd" --arg value 10 \
'{ tf: { "mint": { "address": $address, "denom": $denom, "value": $value | tonumber } } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from minter $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $JSON && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

# burn
# burning does not increase minter's allowance
tfd tx bank send $USER $MINTER 10uwfusd --from user $NODE_CHAIN $NODE_HOME $KEYRING -y

JSON=$(jq -n --arg address "$USER" --arg denom "uwfusd" --arg value 10 \
'{ tf: { "burn": { "denom": $denom, "value": $value | tonumber } } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from minter $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

# feegrant
## grant
## TODO: why any --from can do the grant.
JSON=$(jq -n --arg granter "$FAUCET" --arg grantee "$USER" --arg denom "stake" --arg value 1000000 --arg hours_to_expire 10 \
'{ feegrant: { "grant_fee_basic_allowance": 
{ "granter": $granter, "grantee": $grantee, "allowance_denom": $denom, 
"allowance_value": $value | tonumber, "hours_to_expire": $hours_to_expire | tonumber } } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from tf1_owner $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq && \
sleep 5 && \
TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

## test grant
tfd q bank balances $USER $NODE_CHAIN
tfd q bank balances $USER1 $NODE_CHAIN
tfd tx bank send $USER $USER1 10stake $NODE_CHAIN $NODE_HOME $KEYRING -y --fee-account $FAUCET --fees 50stake

tfd q tx 05D7169BF9B1BBA3D4048F8221333DCCB09854C0121F2AFAACF22152D4A80F0F $NODE_CHAIN 


## revoke
## TODO: why any --from can do the revoke.
JSON=$(jq -n --arg granter "$FAUCET" --arg grantee "$USER" \
'{ feegrant: { "revoke_fee_allowance": { "granter": $granter, "grantee": $grantee } } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from tf1_owner $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq && \
sleep 5
TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

```


## test cosmwasm with difi contract
```shell    
## upload wasm code and get $CODE_ID: two steps
STORE=$(tfd tx wasm store ../../../monorepos/difi/cw-contracts/target/wasm32-unknown-unknown/release/difi_core_2.wasm --from validator $TXFLAG $KEYRING $NODE_HOME -y -b sync --output json) && \
TX_HASH=$(echo $STORE | jq -r '.txhash') && \
echo "$TX_HASH"

TX=$(tfd q tx $TX_HASH $NODE_CHAIN --output json) && \
CODE_ID=$(echo $TX | jq -r '.logs[0].events[-1].attributes[1].value') && \
echo $CODE_ID
# 2

## instantiate and get CONTRACT_ADDRESS: two steps
#export NFT_MINTER=$ACCT1
INIT=$(jq -n --arg nft_minter $MINTER --arg denom "uwfusd" '{ "nft_minter": $nft_minter, "denom": $denom }') && \
RES=$(tfd tx wasm instantiate $CODE_ID "$INIT" --from tf1_owner --label "difi" --no-admin $NODE_HOME $KEYRING $TXFLAG -y --output json)

CONTRACT_ADDRESS=$(tfd query wasm list-contract-by-code $CODE_ID $NODE_CHAIN --output json | jq -r '.contracts[-1]') && \
echo $CONTRACT_ADDRESS
# noble14hj2tavq8fpesdwxxcu44rty3hh90vhujrvcmstl4zr3txmfvw9s54w6k8

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq && \
echo "$TX_HASH"

## Query Examples
# ContractInfo {}
JSON=$(jq -n '{ contract_info: {} }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

# Config {}
JSON=$(jq -n '{ config: {} }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

## execute tx
# test SendCoin
JSON=$(jq -n --arg recipient "$USER" \
'{ "send_coin": { recipient: $recipient } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from tf1_owner --amount 10ustake $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

```