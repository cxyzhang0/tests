package tokenfactory

import (
	errorsmod "cosmossdk.io/errors"
	"encoding/json"
	"fmt"
	wasmvmtypes "github.com/CosmWasm/wasmvm/types"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/wfblockchain/noblechain/v5/x/contracts/tokenfactory/bindings"
)

func CustomQuerier(qp *QueryPlugin) func(ctx sdk.Context, request json.RawMessage) ([]byte, error) {
	return func(ctx sdk.Context, request json.RawMessage) ([]byte, error) {
		var contractQuery bindings.FactoryQuery
		if err := json.Unmarshal(request, &contractQuery); err != nil {
			return nil, errorsmod.Wrap(err, "failed to decode factory query")
		}

		if contractQuery.TF != nil {
			switch {
			case contractQuery.TF.Params != nil:
				resp, err := qp.Params(ctx, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "params"))
				}

				return encode(resp, "params")
			case contractQuery.TF.Owner != nil:
				resp, err := qp.Owner(ctx, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "owner"))
				}

				return encode(resp, "owner")
			case contractQuery.TF.MasterMinter != nil:
				resp, err := qp.MasterMinter(ctx, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "master minter"))
				}
				return encode(resp, "master minter")
			case contractQuery.TF.MinterController != nil:
				resp, err := qp.MinterController(ctx, contractQuery.TF.MinterController.Address, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s: %s", "minter controller", contractQuery.TF.MinterController.Address))
				}
				return encode(resp, "mint controller")
			case contractQuery.TF.AllMinterControllers != nil:
				resp, err := qp.AllMinterControllers(ctx, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "all minter controllers"))
				}
				return encode(resp, "all minter controllers")
			case contractQuery.TF.MintingDenom != nil:
				resp, err := qp.MintingDenom(ctx, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "minting denom"))
				}
				return encode(resp, "minting denom")
			case contractQuery.TF.Minters != nil:
				resp, err := qp.Minters(ctx, contractQuery.TF.Minters.Address, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s: %s", "minters", contractQuery.TF.Minters.Address))
				}
				return encode(resp, "minters")
			case contractQuery.TF.AllMinters != nil:
				resp, err := qp.AllMinters(ctx, contractQuery.TF.AllMinters.Address, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "all minters"))
				}
				return encode(resp, "all minters")
			case contractQuery.TF.Blacklister != nil:
				resp, err := qp.Blacklister(ctx, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "blacklister"))
				}
				return encode(resp, "blacklister")
			case contractQuery.TF.Pauser != nil:
				resp, err := qp.Pauser(ctx, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "pauser"))
				}
				return encode(resp, "pauser")
			case contractQuery.TF.Blacklisted != nil:
				resp, err := qp.Blacklisted(ctx, contractQuery.TF.Blacklisted.Address, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s: %s", "blacklisted", contractQuery.TF.Blacklisted.Address))
				}
				return encode(resp, "blacklisted")
			case contractQuery.TF.AllBlacklisted != nil:
				resp, err := qp.AllBlacklisted(ctx, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "all blacklisted"))
				}
				return encode(resp, "blacklisted")
			case contractQuery.TF.Paused != nil:
				resp, err := qp.Paused(ctx, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "paused"))
				}
				return encode(resp, "paused")

			default:
				return nil, wasmvmtypes.UnsupportedRequest{Kind: "unknown tokenfactory query variant"}
			}

		} else if contractQuery.FTF != nil {
			switch {
			case contractQuery.FTF.Params != nil:
				resp, err := qp.Params(ctx, false)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "params"))
				}

				return encode(resp, "params")
			case contractQuery.FTF.Owner != nil:
				resp, err := qp.Owner(ctx, false)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "owner"))
				}

				return encode(resp, "owner")
			case contractQuery.FTF.MasterMinter != nil:
				resp, err := qp.MasterMinter(ctx, false)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "master minter"))
				}
				return encode(resp, "master minter")
			case contractQuery.FTF.MinterController != nil:
				resp, err := qp.MinterController(ctx, contractQuery.FTF.MinterController.Address, false)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s: %s", "minter controller", contractQuery.FTF.MinterController.Address))
				}
				return encode(resp, "mint controller")
			case contractQuery.FTF.AllMinterControllers != nil:
				resp, err := qp.AllMinterControllers(ctx, false)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "all minter controllers"))
				}
				return encode(resp, "all minter controllers")
			case contractQuery.FTF.MintingDenom != nil:
				resp, err := qp.MintingDenom(ctx, false)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "minting denom"))
				}
				return encode(resp, "minting denom")
			case contractQuery.FTF.Minters != nil:
				resp, err := qp.Minters(ctx, contractQuery.FTF.Minters.Address, false)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s: %s", "minters", contractQuery.FTF.Minters.Address))
				}
				return encode(resp, "minters")
			case contractQuery.FTF.AllMinters != nil:
				resp, err := qp.AllMinters(ctx, contractQuery.FTF.AllMinters.Address, false)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "all minters"))
				}
				return encode(resp, "all minters")
			case contractQuery.FTF.Blacklister != nil:
				resp, err := qp.Blacklister(ctx, false)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "blacklister"))
				}
				return encode(resp, "blacklister")
			case contractQuery.FTF.Pauser != nil:
				resp, err := qp.Pauser(ctx, false)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "pauser"))
				}
				return encode(resp, "pauser")
			case contractQuery.FTF.Blacklisted != nil:
				resp, err := qp.Blacklisted(ctx, contractQuery.TF.Blacklisted.Address, false)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s: %s", "blacklisted", contractQuery.FTF.Blacklisted.Address))
				}
				return encode(resp, "blacklisted")
			case contractQuery.FTF.AllBlacklisted != nil:
				resp, err := qp.AllBlacklisted(ctx, false)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "all blacklisted"))
				}
				return encode(resp, "blacklisted")
			case contractQuery.FTF.Paused != nil:
				resp, err := qp.Paused(ctx, false)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "paused"))
				}
				return encode(resp, "paused")

			default:
				return nil, wasmvmtypes.UnsupportedRequest{Kind: "unknown fiat-tokenfactory query variant"}
			}
		} else if contractQuery.Bank != nil {
			switch {
			case contractQuery.Bank.DenomMetadata != nil:
				resp, err := qp.DenomMetadata(ctx, contractQuery.Bank.DenomMetadata.Denom)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s: %s", "denom metadata", contractQuery.Bank.DenomMetadata.Denom))
				}

				return encode(resp, "denom metadata")

			case contractQuery.Bank.AllDenomMetadata != nil:
				resp := qp.AllDenomMetadata(ctx)

				return encode(resp, "denoms metadata")

			case contractQuery.Bank.FindDenomMetadata != nil:
				resp, err := qp.FindDenomMetadata(ctx, contractQuery.Bank.FindDenomMetadata)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to find denom metadata for %s %s", contractQuery.Bank.FindDenomMetadata.BaseDenom, contractQuery.Bank.FindDenomMetadata.Denom))
				}

				return encode(resp, "find denom metadata")

			case contractQuery.Bank.FindMetadataForDenom != nil:
				resp, err := qp.FindMetadataForDenom(ctx, contractQuery.Bank.FindMetadataForDenom)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to find metadata for denom %s", contractQuery.Bank.FindMetadataForDenom.Denom))
				}

				return encode(resp, "find metadata for denom")

			default:
				return nil, wasmvmtypes.UnsupportedRequest{Kind: "unknown bank query variant"}

			}

		} else if contractQuery.Feegrant != nil {
			switch {
			case contractQuery.Feegrant.FeeBasicAllowance != nil:
				resp, err := qp.FeeBasicAllowance(ctx, contractQuery.Feegrant.FeeBasicAllowance)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s: %s", "fee basic allowance", contractQuery.Feegrant.FeeBasicAllowance.Granter))
				}

				return encode(resp, "fee basic allowance")

			default:
				return nil, wasmvmtypes.UnsupportedRequest{Kind: "unknown feegrant query variant"}
			}
		} else {
			return nil, wasmvmtypes.UnsupportedRequest{Kind: "unknown factory query variant"}
		}
	}
}

/*
	func CustomQuerier(qp *QueryPlugin) func(ctx sdk.Context, request json.RawMessage) ([]byte, error) {
		return func(ctx sdk.Context, request json.RawMessage) ([]byte, error) {
			var contractQuery bindings.FactoryQuery
			if err := json.Unmarshal(request, &contractQuery); err != nil {
				return nil, errorsmod.Wrap(err, "failed to decode factory query")
			}

			switch {
			case contractQuery.TF.Params != nil:
				resp, err := qp.Params(ctx, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "params"))
				}

				return encode(resp, "params")
			case contractQuery.FTF.Params != nil:
				resp, err := qp.Params(ctx, false)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "params"))
				}

				return encode(resp, "params")

			case contractQuery.TF.Owner != nil:
				resp, err := qp.Owner(ctx, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "owner"))
				}

				return encode(resp, "owner")
			case contractQuery.FTF.Owner != nil:
				resp, err := qp.Owner(ctx, false)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "owner"))
				}

				return encode(resp, "owner")

			case contractQuery.TF.MasterMinter != nil:
				resp, err := qp.MasterMinter(ctx)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "master minter"))
				}
				return encode(resp, "master minter")
			case contractQuery.TF.MinterController != nil:
				resp, err := qp.MinterController(ctx, contractQuery.TF.MinterController.Address)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s: %s", "minter controller", contractQuery.TF.MinterController.Address))
				}
				return encode(resp, "mint controller")
			case contractQuery.TF.AllMinterControllers != nil:
				resp, err := qp.AllMinterControllers(ctx)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "all minter controllers"))
				}
				return encode(resp, "all minter controllers")
			case contractQuery.TF.MintingDenom != nil:
				resp, err := qp.MintingDenom(ctx)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "minting denom"))
				}
				return encode(resp, "minting denom")
			case contractQuery.TF.Minters != nil:
				resp, err := qp.Minters(ctx, contractQuery.TF.Minters.Address)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s: %s", "minters", contractQuery.TF.Minters.Address))
				}
				return encode(resp, "minters")
			case contractQuery.TF.AllMinters != nil:
				resp, err := qp.AllMinters(ctx, contractQuery.TF.AllMinters.Address)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "all minters"))
				}
				return encode(resp, "all minters")
			case contractQuery.TF.Blacklister != nil:
				resp, err := qp.Blacklister(ctx)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "blacklister"))
				}
				return encode(resp, "blacklister")
			case contractQuery.TF.Pauser != nil:
				resp, err := qp.Pauser(ctx)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "pauser"))
				}
				return encode(resp, "pauser")
			case contractQuery.TF.Blacklisted != nil:
				resp, err := qp.Blacklisted(ctx, contractQuery.TF.Blacklisted.Address)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s: %s", "blacklisted", contractQuery.TF.Blacklisted.Address))
				}
				return encode(resp, "blacklisted")
			case contractQuery.TF.AllBlacklisted != nil:
				resp, err := qp.AllBlacklisted(ctx)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "all blacklisted"))
				}
				return encode(resp, "blacklisted")
			case contractQuery.TF.Paused != nil:
				resp, err := qp.Paused(ctx)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "paused"))
				}
				return encode(resp, "paused")

			default:
				return nil, wasmvmtypes.UnsupportedRequest{Kind: "unknown tokenfactory query variant"}

				//if contractQuery.Owner != nil {
				//	resp, err := qp.Owner(ctx)
				//	if err != nil {
				//		return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "owner"))
				//	}
				//
				//	//bz, err := json.Marshal(resp)
				//	//if err != nil {
				//	//	return nil, errorsmod.Wrap(err, "failed to marshal owner response")
				//	//}
				//	//return bz, nil
				//	return encode(resp, "owner")
				//}
			}
		}
	}
*/
func encode(resp any, msg string) ([]byte, error) {
	bz, err := json.Marshal(resp)
	if err != nil {
		return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to encode %s response", msg))
	}
	return bz, nil
}
