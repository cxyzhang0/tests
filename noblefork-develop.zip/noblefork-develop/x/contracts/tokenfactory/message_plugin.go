package tokenfactory

import (
	"encoding/json"

	errorsmod "cosmossdk.io/errors"
	"cosmossdk.io/math"
	sdkmath "cosmossdk.io/math"
	feegrant "cosmossdk.io/x/feegrant"
	feegrantkeeper "cosmossdk.io/x/feegrant/keeper"
	wasmkeeper "github.com/CosmWasm/wasmd/x/wasm/keeper"
	wasmvmtypes "github.com/CosmWasm/wasmvm/v2/types"
	codectypes "github.com/cosmos/cosmos-sdk/codec/types"
	sdk "github.com/cosmos/cosmos-sdk/types"
	fiattokenfactorymodulekeeper "github.com/wfblockchain/noble-fiattokenfactory/x/fiattokenfactory/keeper"
	fiattokenfactorymoduletypes "github.com/wfblockchain/noble-fiattokenfactory/x/fiattokenfactory/types"
	"github.com/wfblockchain/noblechain/v5/x/contracts/tokenfactory/bindings"
	tokenfactorymodulekeeper "github.com/wfblockchain/noblechain/v5/x/tokenfactory/keeper"
	tokenfactorymoduletypes "github.com/wfblockchain/noblechain/v5/x/tokenfactory/types"

	"time"
)

// CustomMessagerDecorator returns decorator for custom CosmWasm bindings messages
func CustomMessagerDecorator(tf *tokenfactorymodulekeeper.Keeper, ftf *fiattokenfactorymodulekeeper.Keeper, feegrant *feegrantkeeper.Keeper) func(message wasmkeeper.Messenger) wasmkeeper.Messenger {
	return func(old wasmkeeper.Messenger) wasmkeeper.Messenger {
		return &CustomMessenger{
			wrapped:  old,
			tf:       tf,
			ftf:      ftf,
			feegrant: feegrant,
		}
	}
}

type CustomMessenger struct {
	wrapped  wasmkeeper.Messenger
	tf       *tokenfactorymodulekeeper.Keeper
	ftf      *fiattokenfactorymodulekeeper.Keeper
	feegrant *feegrantkeeper.Keeper
}

func (m *CustomMessenger) DispatchMsg(ctx sdk.Context, contractAddr sdk.AccAddress, contractIBCPortID string, msg wasmvmtypes.CosmosMsg) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	if msg.Custom != nil {
		var contractMsg bindings.FactoryMsg
		if err := json.Unmarshal(msg.Custom, &contractMsg); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to decode tokenfactory msg")
		}
		if contractMsg.TF != nil {
			if contractMsg.TF.UpdateMasterMinter != nil {
				return m.updateMasterMinter(ctx, contractAddr, contractMsg.TF.UpdateMasterMinter, true)
			}
			if contractMsg.TF.ConfigureMinterController != nil {
				return m.configureMinterController(ctx, contractAddr, contractMsg.TF.ConfigureMinterController, true)
			}
			if contractMsg.TF.RemoveMinterController != nil {
				return m.removeMinterController(ctx, contractAddr, contractMsg.TF.RemoveMinterController, true)
			}
			if contractMsg.TF.ConfigureMinter != nil {
				return m.configureMinter(ctx, contractAddr, contractMsg.TF.ConfigureMinter, true)
			}
			if contractMsg.TF.RemoveMinter != nil {
				return m.removeMinter(ctx, contractAddr, contractMsg.TF.RemoveMinter, true)
			}
			if contractMsg.TF.UpdateBlacklister != nil {
				return m.updateBlacklister(ctx, contractAddr, contractMsg.TF.UpdateBlacklister, true)
			}
			if contractMsg.TF.Blacklist != nil {
				return m.blacklist(ctx, contractAddr, contractMsg.TF.Blacklist, true)
			}
			if contractMsg.TF.Unblacklist != nil {
				return m.unblacklist(ctx, contractAddr, contractMsg.TF.Unblacklist, true)
			}
			if contractMsg.TF.UpdatePauser != nil {
				return m.updatePauser(ctx, contractAddr, contractMsg.TF.UpdatePauser, true)
			}
			if contractMsg.TF.Pause != nil {
				return m.pause(ctx, contractAddr, contractMsg.TF.Pause, true)
			}
			if contractMsg.TF.Unpause != nil {
				return m.unpause(ctx, contractAddr, contractMsg.TF.Unpause, true)
			}
			if contractMsg.TF.Mint != nil {
				return m.mint(ctx, contractAddr, contractMsg.TF.Mint, true)
			}
			if contractMsg.TF.Burn != nil {
				return m.burn(ctx, contractAddr, contractMsg.TF.Burn, true)
			}
		} else if contractMsg.FTF != nil {
			if contractMsg.FTF.UpdateMasterMinter != nil {
				return m.updateMasterMinter(ctx, contractAddr, contractMsg.FTF.UpdateMasterMinter, false)
			}
			if contractMsg.FTF.ConfigureMinterController != nil {
				return m.configureMinterController(ctx, contractAddr, contractMsg.FTF.ConfigureMinterController, false)
			}
			if contractMsg.FTF.RemoveMinterController != nil {
				return m.removeMinterController(ctx, contractAddr, contractMsg.FTF.RemoveMinterController, false)
			}
			if contractMsg.FTF.ConfigureMinter != nil {
				return m.configureMinter(ctx, contractAddr, contractMsg.FTF.ConfigureMinter, false)
			}
			if contractMsg.FTF.RemoveMinter != nil {
				return m.removeMinter(ctx, contractAddr, contractMsg.FTF.RemoveMinter, false)
			}
			if contractMsg.FTF.UpdateBlacklister != nil {
				return m.updateBlacklister(ctx, contractAddr, contractMsg.FTF.UpdateBlacklister, false)
			}
			if contractMsg.FTF.Blacklist != nil {
				return m.blacklist(ctx, contractAddr, contractMsg.FTF.Blacklist, false)
			}
			if contractMsg.FTF.Unblacklist != nil {
				return m.unblacklist(ctx, contractAddr, contractMsg.FTF.Unblacklist, false)
			}
			if contractMsg.FTF.UpdatePauser != nil {
				return m.updatePauser(ctx, contractAddr, contractMsg.FTF.UpdatePauser, false)
			}
			if contractMsg.FTF.Pause != nil {
				return m.pause(ctx, contractAddr, contractMsg.FTF.Pause, false)
			}
			if contractMsg.FTF.Unpause != nil {
				return m.unpause(ctx, contractAddr, contractMsg.FTF.Unpause, false)
			}
			if contractMsg.FTF.Mint != nil {
				return m.mint(ctx, contractAddr, contractMsg.FTF.Mint, false)
			}
			if contractMsg.FTF.Burn != nil {
				return m.burn(ctx, contractAddr, contractMsg.FTF.Burn, false)
			}

		} else if contractMsg.Feegrant != nil {
			if contractMsg.Feegrant.GrantFeeBasicAllowance != nil {
				return m.grantFeeBasicAllowance(ctx, contractAddr, contractMsg.Feegrant.GrantFeeBasicAllowance)
			}
			if contractMsg.Feegrant.RevokeFeeAllowance != nil {
				return m.revokeFeeAllowance(ctx, contractAddr, contractMsg.Feegrant.RevokeFeeAllowance)
			}
		}
	}

	return m.wrapped.DispatchMsg(ctx, contractAddr, contractIBCPortID, msg)
}

/*
func (m *CustomMessenger) DispatchMsg(ctx sdk.Context, contractAddr sdk.AccAddress, contractIBCPortID string, msg wasmvmtypes.CosmosMsg) ([]sdk.Event, [][]byte, error) {
	// only handle the happy path where this is really minting / burning
	// leave everything else for the wrapped version
	if msg.Custom != nil {
		var contractMsg bindings.FactoryMsg
		if err := json.Unmarshal(msg.Custom, &contractMsg); err != nil {
			return nil, nil, errorsmod.Wrap(err, "failed to decode tokenfactory msg")
		}

		if contractMsg.TF.UpdateMasterMinter != nil {
			return m.updateMasterMinter(ctx, contractAddr, contractMsg.TF.UpdateMasterMinter, true)
		}
		if contractMsg.FTF.UpdateMasterMinter != nil {
			return m.updateMasterMinter(ctx, contractAddr, contractMsg.TF.UpdateMasterMinter, false)
		}

		if contractMsg.TF.ConfigureMinterController != nil {
			return m.configureMinterController(ctx, contractAddr, contractMsg.TF.ConfigureMinterController)
		}
		if contractMsg.TF.RemoveMinterController != nil {
			return m.removeMinterController(ctx, contractAddr, contractMsg.TF.RemoveMinterController)
		}
		if contractMsg.TF.ConfigureMinter != nil {
			return m.configureMinter(ctx, contractAddr, contractMsg.TF.ConfigureMinter)
		}
		if contractMsg.TF.RemoveMinter != nil {
			return m.removeMinter(ctx, contractAddr, contractMsg.TF.RemoveMinter)
		}
		if contractMsg.TF.UpdateBlacklister != nil {
			return m.updateBlacklister(ctx, contractAddr, contractMsg.TF.UpdateBlacklister)
		}
		if contractMsg.TF.Blacklist != nil {
			return m.blacklist(ctx, contractAddr, contractMsg.TF.Blacklist)
		}
		if contractMsg.TF.Unblacklist != nil {
			return m.unblacklist(ctx, contractAddr, contractMsg.TF.Unblacklist)
		}
		if contractMsg.TF.UpdatePauser != nil {
			return m.updatePauser(ctx, contractAddr, contractMsg.TF.UpdatePauser)
		}
		if contractMsg.TF.Pause != nil {
			return m.pause(ctx, contractAddr, contractMsg.TF.Pause)
		}
		if contractMsg.TF.Unpause != nil {
			return m.unpause(ctx, contractAddr, contractMsg.TF.Unpause)
		}
		if contractMsg.TF.Mint != nil {
			return m.mint(ctx, contractAddr, contractMsg.TF.Mint)
		}
		if contractMsg.TF.Burn != nil {
			return m.burn(ctx, contractAddr, contractMsg.TF.Burn)
		}
	}

	return m.wrapped.DispatchMsg(ctx, contractAddr, contractIBCPortID, msg)
}
*/

func (m *CustomMessenger) updateMasterMinter(ctx sdk.Context, _ sdk.AccAddress, custMsg *bindings.UpdateMasterMinter, isTF bool) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	// this is to prevent wrong function call
	if custMsg == nil {
		return events, data, msgResponses, wasmvmtypes.InvalidRequest{Err: "null custom message"}
	}

	if isTF {
		msgServer := tokenfactorymodulekeeper.NewMsgServerImpl(m.tf)

		msg := tokenfactorymoduletypes.NewMsgUpdateMasterMinter(custMsg.Signer, custMsg.Address)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic tf MsgUpdateMasterMinter")
		}

		_, err := msgServer.UpdateMasterMinter(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to update tf master minter")
		}
	} else {
		msgServer := fiattokenfactorymodulekeeper.NewMsgServerImpl(m.ftf)

		msg := fiattokenfactorymoduletypes.NewMsgUpdateMasterMinter(custMsg.Signer, custMsg.Address)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic ftf MsgUpdateMasterMinter")
		}

		_, err := msgServer.UpdateMasterMinter(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to update ftf master minter")
		}
	}

	return events, data, msgResponses, nil

	// TODO: is it beneficial to add an event here?
	//return []sdk.Event{sdk.NewEvent("tokenfactory", sdk.NewAttribute("update_master_minter", contractAddr.String()))}, nil, nil
}

func (m *CustomMessenger) configureMinterController(ctx sdk.Context, _ sdk.AccAddress, custMsg *bindings.ConfigureMinterController, isTF bool) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	// this is to prevent wrong function call
	if custMsg == nil {
		return events, data, msgResponses, wasmvmtypes.InvalidRequest{Err: "null custom message"}
	}

	if isTF {
		msgServer := tokenfactorymodulekeeper.NewMsgServerImpl(m.tf)

		msg := tokenfactorymoduletypes.NewMsgConfigureMinterController(custMsg.Signer, custMsg.Controller, custMsg.Minter)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic tf MsgConfigureMinterController")
		}

		_, err := msgServer.ConfigureMinterController(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to configure tf minter controller")
		}
	} else {
		msgServer := fiattokenfactorymodulekeeper.NewMsgServerImpl(m.ftf)

		msg := fiattokenfactorymoduletypes.NewMsgConfigureMinterController(custMsg.Signer, custMsg.Controller, custMsg.Minter)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic ftf MsgConfigureMinterController")
		}

		_, err := msgServer.ConfigureMinterController(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to configure ftf minter controller")
		}

	}
	return events, data, msgResponses, nil

	// TODO: is it beneficial to add an event here?
	//return []sdk.Event{sdk.NewEvent("tokenfactory", sdk.NewAttribute("configure_minter_controller", contractAddr.String()))}, nil, nil
}

func (m *CustomMessenger) removeMinterController(ctx sdk.Context, _ sdk.AccAddress, custMsg *bindings.RemoveMinterController, isTF bool) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	// this is to prevent wrong function call
	if custMsg == nil {
		return events, data, msgResponses, wasmvmtypes.InvalidRequest{Err: "null custom message"}
	}

	if isTF {
		msgServer := tokenfactorymodulekeeper.NewMsgServerImpl(m.tf)

		msg := tokenfactorymoduletypes.NewMsgRemoveMinterController(custMsg.Signer, custMsg.Controller)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic tf MsgRemoveMinterController")
		}

		_, err := msgServer.RemoveMinterController(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to remove tf minter controller")
		}
	} else {
		msgServer := fiattokenfactorymodulekeeper.NewMsgServerImpl(m.ftf)

		msg := fiattokenfactorymoduletypes.NewMsgRemoveMinterController(custMsg.Signer, custMsg.Controller)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic ftf MsgRemoveMinterController")
		}

		_, err := msgServer.RemoveMinterController(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to remove ftf minter controller")
		}

	}

	return events, data, msgResponses, nil

	// TODO: is it beneficial to add an event here?
	//return []sdk.Event{sdk.NewEvent("tokenfactory", sdk.NewAttribute("remove_minter_controller", contractAddr.String()))}, nil, nil
}

func (m *CustomMessenger) configureMinter(ctx sdk.Context, _ sdk.AccAddress, custMsg *bindings.ConfigureMinter, isTF bool) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	// this is to prevent wrong function call
	if custMsg == nil {
		return events, data, msgResponses, wasmvmtypes.InvalidRequest{Err: "null custom message"}
	}

	if isTF {
		msgServer := tokenfactorymodulekeeper.NewMsgServerImpl(m.tf)

		vInt := sdkmath.NewIntFromUint64(custMsg.AllowanceValue)
		msg := tokenfactorymoduletypes.NewMsgConfigureMinter(custMsg.Signer, custMsg.Address, sdk.NewCoin(custMsg.AllowanceDenom, vInt))

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating tf basic MsgConfigureMinter")
		}

		_, err := msgServer.ConfigureMinter(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to configure tf minter")
		}
	} else {
		msgServer := fiattokenfactorymodulekeeper.NewMsgServerImpl(m.ftf)

		vInt := sdkmath.NewIntFromUint64(custMsg.AllowanceValue)
		msg := fiattokenfactorymoduletypes.NewMsgConfigureMinter(custMsg.Signer, custMsg.Address, sdk.NewCoin(custMsg.AllowanceDenom, vInt))

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic ftf MsgConfigureMinter")
		}

		_, err := msgServer.ConfigureMinter(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to configure ftf minter")
		}

	}
	return events, data, msgResponses, nil

	// TODO: is it beneficial to add an event here?
	//return []sdk.Event{sdk.NewEvent("tokenfactory", sdk.NewAttribute("configure_minter", contractAddr.String()))}, nil, nil
}

func (m *CustomMessenger) removeMinter(ctx sdk.Context, _ sdk.AccAddress, custMsg *bindings.RemoveMinter, isTF bool) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	// this is to prevent wrong function call
	if custMsg == nil {
		return events, data, msgResponses, wasmvmtypes.InvalidRequest{Err: "null custom message"}
	}

	if isTF {
		msgServer := tokenfactorymodulekeeper.NewMsgServerImpl(m.tf)

		msg := tokenfactorymoduletypes.NewMsgRemoveMinter(custMsg.Signer, custMsg.Address)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic tf MsgRemoveMinter")
		}

		_, err := msgServer.RemoveMinter(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to remove tf minter")
		}
	} else {
		msgServer := fiattokenfactorymodulekeeper.NewMsgServerImpl(m.ftf)

		msg := fiattokenfactorymoduletypes.NewMsgRemoveMinter(custMsg.Signer, custMsg.Address)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating ftf basic MsgRemoveMinter")
		}

		_, err := msgServer.RemoveMinter(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to remove ftf minter")
		}
	}
	return events, data, msgResponses, nil

	// TODO: is it beneficial to add an event here?
	//return []sdk.Event{sdk.NewEvent("tokenfactory", sdk.NewAttribute("remove_minter", contractAddr.String()))}, nil, nil
}

func (m *CustomMessenger) updateBlacklister(ctx sdk.Context, _ sdk.AccAddress, custMsg *bindings.UpdateBlacklister, isTF bool) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	// this is to prevent wrong function call
	if custMsg == nil {
		return events, data, msgResponses, wasmvmtypes.InvalidRequest{Err: "null custom message"}
	}

	if isTF {
		msgServer := tokenfactorymodulekeeper.NewMsgServerImpl(m.tf)

		msg := tokenfactorymoduletypes.NewMsgUpdateBlacklister(custMsg.Signer, custMsg.Address)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic tf MsgUpdateBlacklister")
		}

		_, err := msgServer.UpdateBlacklister(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to update tf blacklister")
		}
	} else {
		msgServer := fiattokenfactorymodulekeeper.NewMsgServerImpl(m.ftf)

		msg := fiattokenfactorymoduletypes.NewMsgUpdateBlacklister(custMsg.Signer, custMsg.Address)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic ftf MsgUpdateBlacklister")
		}

		_, err := msgServer.UpdateBlacklister(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to update ftf blacklister")
		}
	}
	return events, data, msgResponses, nil

	// TODO: is it beneficial to add an event here?
	//return []sdk.Event{sdk.NewEvent("tokenfactory", sdk.NewAttribute("update_blacklister", contractAddr.String()))}, nil, nil
}

func (m *CustomMessenger) blacklist(ctx sdk.Context, _ sdk.AccAddress, custMsg *bindings.Blacklist, isTF bool) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	// this is to prevent wrong function call
	if custMsg == nil {
		return events, data, msgResponses, wasmvmtypes.InvalidRequest{Err: "null custom message"}
	}

	if isTF {
		msgServer := tokenfactorymodulekeeper.NewMsgServerImpl(m.tf)

		msg := tokenfactorymoduletypes.NewMsgBlacklist(custMsg.Signer, custMsg.Address)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic tf MsgBlacklist")
		}

		_, err := msgServer.Blacklist(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to blacklist tf")
		}
	} else {
		msgServer := fiattokenfactorymodulekeeper.NewMsgServerImpl(m.ftf)

		msg := fiattokenfactorymoduletypes.NewMsgBlacklist(custMsg.Signer, custMsg.Address)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic ftf MsgBlacklist")
		}

		_, err := msgServer.Blacklist(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to blacklist ftf")
		}
	}
	return events, data, msgResponses, nil

	// TODO: is it beneficial to add an event here?
	//return []sdk.Event{sdk.NewEvent("tokenfactory", sdk.NewAttribute("blacklist", contractAddr.String()))}, nil, nil
}

func (m *CustomMessenger) unblacklist(ctx sdk.Context, _ sdk.AccAddress, custMsg *bindings.Unblacklist, isTF bool) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	// this is to prevent wrong function call
	if custMsg == nil {
		return events, data, msgResponses, wasmvmtypes.InvalidRequest{Err: "null custom message"}
	}

	if isTF {
		msgServer := tokenfactorymodulekeeper.NewMsgServerImpl(m.tf)

		msg := tokenfactorymoduletypes.NewMsgUnblacklist(custMsg.Signer, custMsg.Address)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic tf MsgUnblacklist")
		}

		_, err := msgServer.Unblacklist(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to unblacklist tf")
		}
	} else {
		msgServer := fiattokenfactorymodulekeeper.NewMsgServerImpl(m.ftf)

		msg := fiattokenfactorymoduletypes.NewMsgUnblacklist(custMsg.Signer, custMsg.Address)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic ftf MsgUnblacklist")
		}

		_, err := msgServer.Unblacklist(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to unblacklist ftf")
		}
	}
	return events, data, msgResponses, nil

	// TODO: is it beneficial to add an event here?
	//return []sdk.Event{sdk.NewEvent("tokenfactory", sdk.NewAttribute("unblacklist", contractAddr.String()))}, nil, nil
}

func (m *CustomMessenger) updatePauser(ctx sdk.Context, _ sdk.AccAddress, custMsg *bindings.UpdatePauser, isTF bool) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	// this is to prevent wrong function call
	if custMsg == nil {
		return events, data, msgResponses, wasmvmtypes.InvalidRequest{Err: "null custom message"}
	}

	if isTF {
		msgServer := tokenfactorymodulekeeper.NewMsgServerImpl(m.tf)

		msg := tokenfactorymoduletypes.NewMsgUpdatePauser(custMsg.Signer, custMsg.Address)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic tf MsgUpdatePauser")
		}

		_, err := msgServer.UpdatePauser(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to update tf pauser")
		}
	} else {
		msgServer := fiattokenfactorymodulekeeper.NewMsgServerImpl(m.ftf)

		msg := fiattokenfactorymoduletypes.NewMsgUpdatePauser(custMsg.Signer, custMsg.Address)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic ftf MsgUpdatePauser")
		}

		_, err := msgServer.UpdatePauser(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to update ftf pauser")
		}
	}
	return events, data, msgResponses, nil

	// TODO: is it beneficial to add an event here?
	//return []sdk.Event{sdk.NewEvent("tokenfactory", sdk.NewAttribute("update_pauser", contractAddr.String()))}, nil, nil
}

func (m *CustomMessenger) pause(ctx sdk.Context, _ sdk.AccAddress, custMsg *bindings.Pause, isTF bool) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	// this is to prevent wrong function call
	if custMsg == nil {
		return events, data, msgResponses, wasmvmtypes.InvalidRequest{Err: "null custom message"}
	}

	if isTF {
		msgServer := tokenfactorymodulekeeper.NewMsgServerImpl(m.tf)

		msg := tokenfactorymoduletypes.NewMsgPause(custMsg.Signer)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic tf MsgPause")
		}

		_, err := msgServer.Pause(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to pause tf")
		}
	} else {
		msgServer := fiattokenfactorymodulekeeper.NewMsgServerImpl(m.ftf)

		msg := fiattokenfactorymoduletypes.NewMsgPause(custMsg.Signer)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic ftf MsgPause")
		}

		_, err := msgServer.Pause(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to pause ftf")
		}
	}
	return events, data, msgResponses, nil

	// TODO: is it beneficial to add an event here?
	//return []sdk.Event{sdk.NewEvent("tokenfactory", sdk.NewAttribute("pause", contractAddr.String()))}, nil, nil
}

func (m *CustomMessenger) unpause(ctx sdk.Context, _ sdk.AccAddress, custMsg *bindings.Unpause, isTF bool) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	// this is to prevent wrong function call
	if custMsg == nil {
		return events, data, msgResponses, wasmvmtypes.InvalidRequest{Err: "null custom message"}
	}

	if isTF {
		msgServer := tokenfactorymodulekeeper.NewMsgServerImpl(m.tf)

		msg := tokenfactorymoduletypes.NewMsgUnpause(custMsg.Signer)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic tf MsgUnpause")
		}

		_, err := msgServer.Unpause(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to unpause tf")
		}
	} else {
		msgServer := fiattokenfactorymodulekeeper.NewMsgServerImpl(m.ftf)

		msg := fiattokenfactorymoduletypes.NewMsgUnpause(custMsg.Signer)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic ftf MsgUnpause")
		}

		_, err := msgServer.Unpause(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to unpause ftf")
		}
	}
	return events, data, msgResponses, nil

	// TODO: is it beneficial to add an event here?
	//return []sdk.Event{sdk.NewEvent("tokenfactory", sdk.NewAttribute("unpause", contractAddr.String()))}, nil, nil
}

func (m *CustomMessenger) mint(ctx sdk.Context, _ sdk.AccAddress, custMsg *bindings.Mint, isTF bool) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	// this is to prevent wrong function call
	if custMsg == nil {
		return events, data, msgResponses, wasmvmtypes.InvalidRequest{Err: "null custom message"}
	}

	if isTF {
		msgServer := tokenfactorymodulekeeper.NewMsgServerImpl(m.tf)

		vInt := sdkmath.NewIntFromUint64(custMsg.Value)
		msg := tokenfactorymoduletypes.NewMsgMint(custMsg.Signer, custMsg.Address, sdk.NewCoin(custMsg.Denom, vInt))

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic tf MsgMint")
		}

		_, err := msgServer.Mint(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to mint tf")
		}
	} else {
		msgServer := fiattokenfactorymodulekeeper.NewMsgServerImpl(m.ftf)

		vInt := sdkmath.NewIntFromUint64(custMsg.Value)
		msg := fiattokenfactorymoduletypes.NewMsgMint(custMsg.Signer, custMsg.Address, sdk.NewCoin(custMsg.Denom, vInt))

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic ftf MsgMint")
		}

		_, err := msgServer.Mint(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to mint ftf")
		}
	}
	return events, data, msgResponses, nil

	// TODO: is it beneficial to add an event here?
	//return []sdk.Event{sdk.NewEvent("tokenfactory", sdk.NewAttribute("mint", contractAddr.String()))}, nil, nil
}

func (m *CustomMessenger) burn(ctx sdk.Context, _ sdk.AccAddress, custMsg *bindings.Burn, isTF bool) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	// this is to prevent wrong function call
	if custMsg == nil {
		return events, data, msgResponses, wasmvmtypes.InvalidRequest{Err: "null custom message"}
	}

	if isTF {
		msgServer := tokenfactorymodulekeeper.NewMsgServerImpl(m.tf)

		vInt := sdkmath.NewIntFromUint64(custMsg.Value)
		msg := tokenfactorymoduletypes.NewMsgBurn(custMsg.Signer, sdk.NewCoin(custMsg.Denom, vInt))

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic tf MsgBurn")
		}

		_, err := msgServer.Burn(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to burn tf")
		}
	} else {
		msgServer := fiattokenfactorymodulekeeper.NewMsgServerImpl(m.ftf)

		vInt := sdkmath.NewIntFromUint64(custMsg.Value)
		msg := fiattokenfactorymoduletypes.NewMsgBurn(custMsg.Signer, sdk.NewCoin(custMsg.Denom, vInt))

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic ftf MsgBurn")
		}

		_, err := msgServer.Burn((ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to burn ftf")
		}
	}
	return events, data, msgResponses, nil

	// TODO: is it beneficial to add an event here?
	//return []sdk.Event{sdk.NewEvent("tokenfactory", sdk.NewAttribute("burn", contractAddr.String()))}, nil, nil
}

func (m *CustomMessenger) grantFeeBasicAllowance(ctx sdk.Context, _ sdk.AccAddress, custMsg *bindings.GrantFeeBasicAllowance) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	// this is to prevent wrong function call
	if custMsg == nil {
		return events, data, msgResponses, wasmvmtypes.InvalidRequest{Err: "null custom message"}
	}

	msgServer := feegrantkeeper.NewMsgServerImpl(*m.feegrant)

	granter, err := sdk.AccAddressFromBech32(custMsg.Granter)
	if err != nil {
		return events, data, msgResponses, errorsmod.Wrap(err, "failed to parse granter address")
	}

	grantee, err := sdk.AccAddressFromBech32(custMsg.Grantee)
	if err != nil {
		return events, data, msgResponses, errorsmod.Wrap(err, "failed to parse granter address")
	}

	expiration := time.Now().UTC().Add(time.Duration(int64(time.Hour) * int64(custMsg.HoursToExpire)))

	allowance := feegrant.BasicAllowance{
		SpendLimit: sdk.NewCoins(sdk.NewCoin(custMsg.AllowanceDenom, math.NewIntFromUint64(custMsg.AllowanceValue))),
		Expiration: &expiration,
	}

	msg, err := feegrant.NewMsgGrantAllowance(&allowance, granter, grantee)
	if err != nil {
		return events, data, msgResponses, errorsmod.Wrap(err, "failed to create MsgGrantAllowance")
	}

	// if err := msg.ValidateBasic(); err != nil {
	// 	return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic MsgGrantFeeAllowance")
	// }

	_, err = msgServer.GrantAllowance(sdk.WrapSDKContext(ctx), msg)

	if err != nil {
		return events, data, msgResponses, errorsmod.Wrap(err, "failed to grant fee allowance")
	}

	return events, data, msgResponses, nil
}

func (m *CustomMessenger) revokeFeeAllowance(ctx sdk.Context, _ sdk.AccAddress, custMsg *bindings.RevokeFeeAllowance) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	// this is to prevent wrong function call
	if custMsg == nil {
		return events, data, msgResponses, wasmvmtypes.InvalidRequest{Err: "null custom message"}
	}

	msgServer := feegrantkeeper.NewMsgServerImpl(*m.feegrant)

	granter, err := sdk.AccAddressFromBech32(custMsg.Granter)
	if err != nil {
		return events, data, msgResponses, errorsmod.Wrap(err, "failed to parse granter address")
	}

	grantee, err := sdk.AccAddressFromBech32(custMsg.Grantee)
	if err != nil {
		return events, data, msgResponses, errorsmod.Wrap(err, "failed to parse granter address")
	}

	msg := feegrant.NewMsgRevokeAllowance(granter, grantee)
	//msg := feegranttypes.NewMsgRevokeAllowance(sdk.AccAddress(custMsg.Granter), sdk.AccAddress(custMsg.Grantee))

	// if err := msg.ValidateBasic(); err != nil {
	// 	return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic MsgRevokeAllowance")
	// }

	_, err = msgServer.RevokeAllowance(sdk.WrapSDKContext(ctx), &msg)

	if err != nil {
		return events, data, msgResponses, errorsmod.Wrap(err, "failed to revoke fee allowance")
	}

	return events, data, msgResponses, nil
}
