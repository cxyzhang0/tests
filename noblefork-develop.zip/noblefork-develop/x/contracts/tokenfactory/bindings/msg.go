package bindings

type FactoryMsg struct {
	TF       *TokenfactoryMsg `json:"tf,omitempty"`
	FTF      *TokenfactoryMsg `json:"ftf,omitempty"`
	Feegrant *FeegrantMsg     `json:"feegrant,omitempty"`
}

type TokenfactoryMsg struct {
	UpdateMasterMinter        *UpdateMasterMinter        `json:"update_master_minter,omitempty"`
	ConfigureMinterController *ConfigureMinterController `json:"configure_minter_controller,omitempty"`
	RemoveMinterController    *RemoveMinterController    `json:"remove_minter_controller,omitempty"`
	ConfigureMinter           *ConfigureMinter           `json:"configure_minter,omitempty"`
	RemoveMinter              *RemoveMinter              `json:"remove_minter,omitempty"`
	UpdateBlacklister         *UpdateBlacklister         `json:"update_blacklister,omitempty"`
	Blacklist                 *Blacklist                 `json:"blacklist,omitempty"`
	Unblacklist               *Unblacklist               `json:"unblacklist,omitempty"`
	UpdatePauser              *UpdatePauser              `json:"update_pauser,omitempty"`
	Pause                     *Pause                     `json:"pause,omitempty"`
	Unpause                   *Unpause                   `json:"unpause,omitempty"`
	Mint                      *Mint                      `json:"mint,omitempty"`
	Burn                      *Burn                      `json:"burn,omitempty"`
}

type FeegrantMsg struct {
	GrantFeeBasicAllowance *GrantFeeBasicAllowance `json:"grant_fee_basic_allowance,omitempty"`
	RevokeFeeAllowance     *RevokeFeeAllowance     `json:"revoke_fee_allowance,omitempty"`
}

/*
	type FiatTokenfactoryMsg struct {
		UpdateMasterMinter        *UpdateMasterMinter        `json:"update_master_minter,omitempty"`
		ConfigureMinterController *ConfigureMinterController `json:"configure_minter_controller,omitempty"`
		RemoveMinterController    *RemoveMinterController    `json:"remove_minter_controller,omitempty"`
		ConfigureMinter           *ConfigureMinter           `json:"configure_minter,omitempty"`
		RemoveMinter              *RemoveMinter              `json:"remove_minter,omitempty"`
		UpdateBlacklister         *UpdateBlacklister         `json:"update_blacklister,omitempty"`
		Blacklist                 *Blacklist                 `json:"blacklist,omitempty"`
		Unblacklist               *Unblacklist               `json:"unblacklist,omitempty"`
		UpdatePauser              *UpdatePauser              `json:"update_pauser,omitempty"`
		Pause                     *Pause                     `json:"pause,omitempty"`
		Unpause                   *Unpause                   `json:"unpause,omitempty"`
		Mint                      *Mint                      `json:"mint,omitempty"`
		Burn                      *Burn                      `json:"burn,omitempty"`
	}
*/
type UpdateMasterMinter struct {
	Signer  string `json:"signer"`
	Address string `json:"address"`
}

type ConfigureMinterController struct {
	Signer     string `json:"signer"`
	Controller string `json:"controller"`
	Minter     string `json:"minter"`
}

type RemoveMinterController struct {
	Signer     string `json:"signer"`
	Controller string `json:"controller"`
}

type ConfigureMinter struct {
	Signer         string `json:"signer"`
	Address        string `json:"address"`
	AllowanceDenom string `json:"allowance_denom"`
	AllowanceValue uint64 `json:"allowance_value"`
}

type RemoveMinter struct {
	Signer  string `json:"signer"`
	Address string `json:"address"`
}

type UpdateBlacklister struct {
	Signer  string `json:"signer"`
	Address string `json:"address"`
}

type Blacklist struct {
	Signer  string `json:"signer"`
	Address string `json:"address"`
}

type Unblacklist struct {
	Signer  string `json:"signer"`
	Address string `json:"address"`
}

type UpdatePauser struct {
	Signer  string `json:"signer"`
	Address string `json:"address"`
}

type Pause struct {
	Signer string `json:"signer"`
}

type Unpause struct {
	Signer string `json:"signer"`
}

type Mint struct {
	Signer  string `json:"signer"`
	Address string `json:"address"`
	Denom   string `json:"denom"`
	Value   uint64 `json:"value"`
}

type Burn struct {
	Signer string `json:"signer"`
	Denom  string `json:"denom"`
	Value  uint64 `json:"value"`
}

type GrantFeeBasicAllowance struct {
	Signer         string `json:"signer"`
	Granter        string `json:"granter"`
	Grantee        string `json:"grantee"`
	AllowanceDenom string `json:"allowance_denom"`
	AllowanceValue uint64 `json:"allowance_value"`
	HoursToExpire  uint64 `json:"hours_to_expire"`
}

type RevokeFeeAllowance struct {
	Signer  string `json:"signer"`
	Granter string `json:"granter"`
	Grantee string `json:"grantee"`
}
