package bindings

type FactoryQuery struct {
	TF  *TokenfactoryQuery `json:"tf,omitempty"`
	FTF *TokenfactoryQuery `json:"ftf,omitempty"`
	/*
		We use this special BankQuery to query the denom metadata.
		This is a stop-gap solution until we upgrade wasmd (and CosmWasm/wasmvm) because
		the current v1.2.1 wasmvm BankQuery does not have DenomMetadata or AllDenomMetadata.
		v1.30.0+ will have them.
	*/
	Bank     *BankQuery     `json:"bank,omitempty"`
	Feegrant *FeegrantQuery `json:"feegrant,omitempty"`
}

type TokenfactoryQuery struct {
	Params               *Params               `json:"params,omitempty"`
	Owner                *Owner                `json:"owner,omitempty"`
	MasterMinter         *MasterMinter         `json:"master_minter,omitempty"`
	MinterController     *MinterController     `json:"minter_controller,omitempty"`
	AllMinterControllers *AllMinterControllers `json:"all_minter_controllers,omitempty"`
	Blacklister          *Blacklister          `json:"blacklister,omitempty"`
	Pauser               *Pauser               `json:"pauser,omitempty"`
	MintingDenom         *MintingDenom         `json:"minting_denom,omitempty"`
	Minters              *Minters              `json:"minters,omitempty"`
	AllMinters           *AllMinters           `json:"all_minters,omitempty"`
	Blacklisted          *Blacklisted          `json:"blacklisted,omitempty"`
	AllBlacklisted       *AllBlacklisted       `json:"all_blacklisted,omitempty"`
	Paused               *Paused               `json:"paused,omitempty"`
}

type BankQuery struct {
	DenomMetadata        *DenomMetadata        `json:"denom_metadata,omitempty"`
	AllDenomMetadata     *AllDenomMetadata     `json:"all_denom_metadata,omitempty"`
	FindDenomMetadata    *FindDenomMetadata    `json:"find_denom_metadata,omitempty"`
	FindMetadataForDenom *FindMetadataForDenom `json:"find_metadata_for_denom,omitempty"`
}

type FeegrantQuery struct {
	FeeBasicAllowance *FeeBasicAllowance `json:"fee_basic_allowance,omitempty"`
}

/*
type FiatTokenfactoryQuery struct {
	Params               *Params               `json:"params,omitempty"`
	Owner                *Owner                `json:"owner,omitempty"`
	MasterMinter         *MasterMinter         `json:"master_minter,omitempty"`
	MinterController     *MinterController     `json:"minter_controller,omitempty"`
	AllMinterControllers *AllMinterControllers `json:"all_minter_controllers,omitempty"`
	Blacklister          *Blacklister          `json:"blacklister,omitempty"`
	Pauser               *Pauser               `json:"pauser,omitempty"`
	MintingDenom         *MintingDenom         `json:"minting_denom,omitempty"`
	Minters              *Minters              `json:"minters,omitempty"`
	AllMinters           *AllMinters           `json:"all_minters,omitempty"`
	Blacklisted          *Blacklisted          `json:"blacklisted,omitempty"`
	AllBlacklisted       *AllBlacklisted       `json:"all_blacklisted,omitempty"`
	Paused               *Paused               `json:"paused,omitempty"`
}
*/

type Params struct{}
type ParamsResponse struct {
	Params string `json:"params"`
}

type Owner struct{}
type OwnerResponse struct {
	Address string `json:"address"`
}

type MasterMinter struct{}
type MasterMinterResponse struct {
	Address string `json:"address"`
}

type MinterController struct {
	Address string `json:"address"`
}
type MinterControllerResponse struct {
	Minter     string `json:"minter"`
	Controller string `json:"controller"`
}

type AllMinterControllers struct{}
type AllMinterControllersResponse struct {
	MinterControllers []MinterControllerResponse `json:"minter_controllers"`
}

type MintingDenom struct{}
type MintingDenomResponse struct {
	Denom string `json:"denom"`
}

// Should be in singular form but the API is in plural form
type Minters struct {
	Address string `json:"address"`
}
type MintersResponse struct {
	Address        string `json:"address"`
	AllowanceDenom string `json:"allowance_denom"`
	AllowanceValue uint64 `json:"allowance_value"`
}

type AllMinters struct {
	Address string `json:"address"`
}
type AllMintersResponse struct {
	Minters []MintersResponse `json:"minters"`
}

type Blacklister struct{}
type BlacklisterResponse struct {
	Address string `json:"address"`
}

type Pauser struct{}
type PauserResponse struct {
	Address string `json:"address"`
}

type Blacklisted struct {
	Address string `json:"address"`
}

// note: proto uses bytes addressBz. We try string address here.
type BlacklistedResponse struct {
	Address string `json:"address"`
}

type AllBlacklisted struct{}
type AllBlacklistedResponse struct {
	Blacklisted []BlacklistedResponse `json:"blacklisted"`
}

type Paused struct{}
type PausedResponse struct {
	Paused bool `json:"paused"`
}

/*
DemonMetadata (QueryDemonMetadataRequest) and DemonMetadataResponse (QueryDenomMetadataResponse)
AllDemonMetadata (QueryDenomsMetadataRequest) and AllDemonMetadataResponse (QueryDenomsMetadataResponse)
Metadata and DenomUnit
are based on x/bank/types/query.pb.go and bank.pb.go.
We make the following changes for desired json.Marshal output:
remove protobuf tag
remove omitempty tag
no pagination
*/
type DenomMetadata struct {
	// This is base denom to look up metadata for.
	Denom string `json:"denom"`
}
type DenomMetadataResponse struct {
	// metadata describes and provides all the client information for the requested token.
	Metadata Metadata `json:"metadata"`
	//Metadata Metadata `protobuf:"bytes,1,opt,name=metadata,proto3" json:"metadata"`
}

type AllDenomMetadata struct{}
type AllDenomMetadataResponse struct {
	Metadatas []Metadata `json:"metadatas"`
}

type FindDenomMetadata struct {
	BaseDenom string `json:"base_denom"`
	Denom     string `json:"denom"`
}

type FindMetadataForDenom struct {
	// This is any denom to look up metadata for, not just the base denom.
	Denom string `json:"denom"`
}

type FindDenomMetadataResponse struct {
	Description string   `json:"description"`
	Base        string   `json:"base"`
	Display     string   `json:"display"`
	Name        string   `json:"name"`
	Symbol      string   `json:"symbol"`
	Denom       string   `json:"denom"`
	Exponent    uint32   `json:"exponent"`
	Aliases     []string `json:"aliases"`
}

type Metadata struct {
	Description string `json:"description"`
	//Description string `protobuf:"bytes,1,opt,name=description,proto3" json:"description,omitempty"`
	// denom_units represents the list of DenomUnit's for a given coin
	DenomUnits []*DenomUnit `json:"denom_units"`
	//DenomUnits []*DenomUnit `protobuf:"bytes,2,rep,name=denom_units,json=denomUnits,proto3" json:"denom_units,omitempty"`
	// base represents the base denom (should be the DenomUnit with exponent = 0).
	Base string `json:"base"`
	//Base string `protobuf:"bytes,3,opt,name=base,proto3" json:"base,omitempty"`
	// display indicates the suggested denom that should be
	// displayed in clients.
	Display string `json:"display"`
	//Display string `protobuf:"bytes,4,opt,name=display,proto3" json:"display,omitempty"`
	// name defines the name of the token (eg: Cosmos Atom)
	//
	// Since: cosmos-sdk 0.43
	Name string `json:"name"`
	//Name string `protobuf:"bytes,5,opt,name=name,proto3" json:"name,omitempty"`
	// symbol is the token symbol usually shown on exchanges (eg: ATOM). This can
	// be the same as the display.
	//
	// Since: cosmos-sdk 0.43
	Symbol string `json:"symbol"`
	//Symbol string `protobuf:"bytes,6,opt,name=symbol,proto3" json:"symbol,omitempty"`
}

type DenomUnit struct {
	// denom represents the string name of the given denom unit (e.g uatom).
	Denom string `json:"denom"`
	//Denom string `protobuf:"bytes,1,opt,name=denom,proto3" json:"denom,omitempty"`
	// exponent represents power of 10 exponent that one must
	// raise the base_denom to in order to equal the given DenomUnit's denom
	// 1 denom = 1^exponent base_denom
	// (e.g. with a base_denom of uatom, one can create a DenomUnit of 'atom' with
	// exponent = 6, thus: 1 atom = 10^6 uatom).
	Exponent uint32 `json:"exponent"`
	//Exponent uint32 `protobuf:"varint,2,opt,name=exponent,proto3" json:"exponent,omitempty"`
	// aliases is a list of string aliases for the given denom
	Aliases []string `json:"aliases"`
	//Aliases []string `protobuf:"bytes,3,rep,name=aliases,proto3" json:"aliases,omitempty"`
}

type FeeBasicAllowance struct {
	Granter string `json:"granter"`
	Grantee string `json:"grantee"`
}
type FeeBasicAllowanceResponse struct {
	Allowance *FeeBasicGrant `json:"allowance"`
}

type FeeBasicGrant struct {
	Granter        string `json:"granter"`
	Grantee        string `json:"grantee"`
	AllowanceDenom string `json:"allowance_denom"`
	AllowanceValue uint64 `json:"allowance_value"`
	Expiration     string `json:"expiration"`
}
