package tokenfactory

import (
	"fmt"

	errorsmod "cosmossdk.io/errors"

	"cosmossdk.io/x/feegrant"
	feegrantkeeper "cosmossdk.io/x/feegrant/keeper"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/cosmos/cosmos-sdk/types/bech32"
	bankkeeper "github.com/cosmos/cosmos-sdk/x/bank/keeper"
	fiattokenfactorymodulekeeper "github.com/wfblockchain/noble-fiattokenfactory/x/fiattokenfactory/keeper"
	"github.com/wfblockchain/noblechain/v5/x/contracts/tokenfactory/bindings"
	tokenfactorymodulekeeper "github.com/wfblockchain/noblechain/v5/x/tokenfactory/keeper"
)

type QueryPlugin struct {
	tf       *tokenfactorymodulekeeper.Keeper
	ftf      *fiattokenfactorymodulekeeper.Keeper
	bank     *bankkeeper.BaseKeeper
	feegrant *feegrantkeeper.Keeper
}

func NewQueryPlugin(tf *tokenfactorymodulekeeper.Keeper, ftf *fiattokenfactorymodulekeeper.Keeper, bank *bankkeeper.BaseKeeper, feegrant *feegrantkeeper.Keeper) *QueryPlugin {
	return &QueryPlugin{
		tf,
		ftf,
		bank,
		feegrant,
	}
}

func (qp *QueryPlugin) Params(ctx sdk.Context, isTF bool) (*bindings.ParamsResponse, error) {
	var resp *bindings.ParamsResponse
	if isTF {
		r := qp.tf.GetParams(ctx)
		resp = &bindings.ParamsResponse{Params: r.String()}
	} else {
		r := qp.ftf.GetParams(ctx)
		resp = &bindings.ParamsResponse{Params: r.String()}
	}
	return resp, nil //&bindings.ParamsResponse{Params: resp.String()}, nil
}

func (qp *QueryPlugin) Owner(ctx sdk.Context, isTF bool) (*bindings.OwnerResponse, error) {
	var resp *bindings.OwnerResponse
	if isTF {
		r, ok := qp.tf.GetOwner(ctx)
		if !ok {
			return nil, fmt.Errorf("failed to get tf owner")
		}
		resp = &bindings.OwnerResponse{Address: r.Address}
	} else {
		r, ok := qp.ftf.GetOwner(ctx)
		if !ok {
			return nil, fmt.Errorf("failed to get ftf owner")
		}
		resp = &bindings.OwnerResponse{Address: r.Address}
	}
	return resp, nil
}

func (qp *QueryPlugin) MasterMinter(ctx sdk.Context, isTF bool) (*bindings.MasterMinterResponse, error) {
	var resp *bindings.MasterMinterResponse
	if isTF {
		r, ok := qp.tf.GetMasterMinter(ctx)
		if !ok {
			return nil, fmt.Errorf("failed to get master minter")
		}
		resp = &bindings.MasterMinterResponse{Address: r.Address}
	} else {
		r, ok := qp.ftf.GetMasterMinter(ctx)
		if !ok {
			return nil, fmt.Errorf("failed to get master minter")
		}
		resp = &bindings.MasterMinterResponse{Address: r.Address}
	}
	return resp, nil
}

func (qp *QueryPlugin) MinterController(ctx sdk.Context, address string, isTF bool) (*bindings.MinterControllerResponse, error) {
	var resp *bindings.MinterControllerResponse
	if isTF {
		r, ok := qp.tf.GetMinterController(ctx, address)
		if !ok {
			return nil, fmt.Errorf("failed to get minter controller")
		}
		resp = &bindings.MinterControllerResponse{Minter: r.Minter, Controller: r.Controller}
	} else {
		r, ok := qp.ftf.GetMinterController(ctx, address)
		if !ok {
			return nil, fmt.Errorf("failed to get minter controller")
		}
		resp = &bindings.MinterControllerResponse{Minter: r.Minter, Controller: r.Controller}
	}
	return resp, nil
}

func (qp *QueryPlugin) AllMinterControllers(ctx sdk.Context, isTF bool) (*bindings.AllMinterControllersResponse, error) {
	var resp *bindings.AllMinterControllersResponse
	if isTF {
		r := qp.tf.GetAllMinterControllers(ctx)
		var list []bindings.MinterControllerResponse
		for _, minterController := range r {
			list = append(list, bindings.MinterControllerResponse{Minter: minterController.Minter, Controller: minterController.Controller})
		}
		resp = &bindings.AllMinterControllersResponse{MinterControllers: list}
	} else {
		r := qp.ftf.GetAllMinterControllers(ctx)
		var list []bindings.MinterControllerResponse
		for _, minterController := range r {
			list = append(list, bindings.MinterControllerResponse{Minter: minterController.Minter, Controller: minterController.Controller})
		}
		resp = &bindings.AllMinterControllersResponse{MinterControllers: list}

	}
	return resp, nil
}

func (qp *QueryPlugin) MintingDenom(ctx sdk.Context, isTF bool) (*bindings.MintingDenomResponse, error) {
	var resp *bindings.MintingDenomResponse
	if isTF {
		r := qp.tf.GetMintingDenom(ctx)
		resp = &bindings.MintingDenomResponse{Denom: r.Denom}
	} else {
		r := qp.ftf.GetMintingDenom(ctx)
		resp = &bindings.MintingDenomResponse{Denom: r.Denom}
	}
	return resp, nil
}

func (qp *QueryPlugin) Minters(ctx sdk.Context, address string, isTF bool) (*bindings.MintersResponse, error) {
	var resp *bindings.MintersResponse
	if isTF {
		r, ok := qp.tf.GetMinters(ctx, address)
		if !ok {
			return nil, fmt.Errorf("failed to get minters")
		}
		resp = &bindings.MintersResponse{Address: r.Address, AllowanceDenom: r.Allowance.Denom, AllowanceValue: r.Allowance.Amount.Uint64()}
	} else {
		r, ok := qp.ftf.GetMinters(ctx, address)
		if !ok {
			return nil, fmt.Errorf("failed to get minters")
		}
		resp = &bindings.MintersResponse{Address: r.Address, AllowanceDenom: r.Allowance.Denom, AllowanceValue: r.Allowance.Amount.Uint64()}
	}
	return resp, nil
}

// TODO: address is not used because tf module GetAllMinters does not take an address as an argument
func (qp *QueryPlugin) AllMinters(ctx sdk.Context, address string, isTF bool) (*bindings.AllMintersResponse, error) {
	var resp *bindings.AllMintersResponse
	if isTF {
		r := qp.tf.GetAllMinters(ctx)
		var list []bindings.MintersResponse
		for _, minters := range r {
			list = append(list, bindings.MintersResponse{Address: minters.Address, AllowanceDenom: minters.Allowance.Denom, AllowanceValue: minters.Allowance.Amount.Uint64()})
		}
		resp = &bindings.AllMintersResponse{Minters: list}
	} else {
		r := qp.ftf.GetAllMinters(ctx)
		var list []bindings.MintersResponse
		for _, minters := range r {
			list = append(list, bindings.MintersResponse{Address: minters.Address, AllowanceDenom: minters.Allowance.Denom, AllowanceValue: minters.Allowance.Amount.Uint64()})
		}
		resp = &bindings.AllMintersResponse{Minters: list}
	}
	return resp, nil
}

func (qp *QueryPlugin) Blacklister(ctx sdk.Context, isTF bool) (*bindings.BlacklisterResponse, error) {
	var resp *bindings.BlacklisterResponse
	if isTF {
		r, ok := qp.tf.GetBlacklister(ctx)
		if !ok {
			return nil, fmt.Errorf("failed to get blacklister")
		}
		resp = &bindings.BlacklisterResponse{Address: r.Address}
	} else {
		r, ok := qp.ftf.GetBlacklister(ctx)
		if !ok {
			return nil, fmt.Errorf("failed to get blacklister")
		}
		resp = &bindings.BlacklisterResponse{Address: r.Address}
	}
	return resp, nil
}

func (qp *QueryPlugin) Pauser(ctx sdk.Context, isTF bool) (*bindings.PauserResponse, error) {
	var resp *bindings.PauserResponse
	if isTF {
		r, ok := qp.tf.GetPauser(ctx)
		if !ok {
			return nil, fmt.Errorf("failed to get pauser")
		}
		resp = &bindings.PauserResponse{Address: r.Address}
	} else {
		r, ok := qp.ftf.GetPauser(ctx)
		if !ok {
			return nil, fmt.Errorf("failed to get pauser")
		}
		resp = &bindings.PauserResponse{Address: r.Address}
	}
	return resp, nil
}

func (qp *QueryPlugin) Blacklisted(ctx sdk.Context, address string, isTF bool) (*bindings.BlacklistedResponse, error) {
	var resp *bindings.BlacklistedResponse
	if isTF {
		_, addressBz, err := bech32.DecodeAndConvert(address)
		if err != nil {
			return nil, fmt.Errorf("failed to decode address")
		}

		r, ok := qp.tf.GetBlacklisted(ctx, addressBz)
		if !ok {
			return nil, fmt.Errorf("failed to get blacklisted")
		}
		resp = &bindings.BlacklistedResponse{Address: r.String()}
	} else {
		_, addressBz, err := bech32.DecodeAndConvert(address)
		if err != nil {
			return nil, fmt.Errorf("failed to decode address")
		}

		r, ok := qp.ftf.GetBlacklisted(ctx, addressBz)
		if !ok {
			return nil, fmt.Errorf("failed to get blacklisted")
		}
		resp = &bindings.BlacklistedResponse{Address: r.String()}
	}
	return resp, nil
}

func (qp *QueryPlugin) AllBlacklisted(ctx sdk.Context, isTF bool) (*bindings.AllBlacklistedResponse, error) {
	var resp *bindings.AllBlacklistedResponse
	if isTF {
		r := qp.tf.GetAllBlacklisted(ctx)
		var list []bindings.BlacklistedResponse
		for _, blacklisted := range r {
			list = append(list, bindings.BlacklistedResponse{Address: blacklisted.String()})
		}
		resp = &bindings.AllBlacklistedResponse{Blacklisted: list}
	} else {
		r := qp.ftf.GetAllBlacklisted(ctx)
		var list []bindings.BlacklistedResponse
		for _, blacklisted := range r {
			list = append(list, bindings.BlacklistedResponse{Address: blacklisted.String()})
		}
		resp = &bindings.AllBlacklistedResponse{Blacklisted: list}
	}
	return resp, nil
}

func (qp *QueryPlugin) Paused(ctx sdk.Context, isTF bool) (*bindings.PausedResponse, error) {
	var resp *bindings.PausedResponse
	if isTF {
		r := qp.tf.GetPaused(ctx)
		resp = &bindings.PausedResponse{Paused: r.Paused}
	} else {
		r := qp.ftf.GetPaused(ctx)
		resp = &bindings.PausedResponse{Paused: r.Paused}
	}
	return resp, nil
}

func (qp *QueryPlugin) FindDenomMetadata(ctx sdk.Context, req *bindings.FindDenomMetadata) (*bindings.FindDenomMetadataResponse, error) {
	r, ok := qp.bank.GetDenomMetaData(ctx, req.BaseDenom)
	if !ok {
		return nil, fmt.Errorf("failed to get denom metadata for %s", req.BaseDenom)
	}

	for _, u := range r.DenomUnits {
		if u.Denom == req.Denom {
			// in case unit.Aliases is nil, we need to have an empty slice so that json.Marshal does not return null but [] instead
			// otherwise, the deserialization on rust side (cosmwasm) will fail
			var aliases = make([]string, 0)
			for _, alias := range u.Aliases {
				aliases = append(aliases, alias)
			}
			return &bindings.FindDenomMetadataResponse{Description: r.Description, Base: r.Base, Display: r.Display, Name: r.Name, Symbol: r.Symbol, Denom: u.Denom, Exponent: u.Exponent, Aliases: aliases}, nil
		}
	}

	return nil, fmt.Errorf("failed to find denom unit for %s", req.Denom)
}

func (qp *QueryPlugin) FindMetadataForDenom(ctx sdk.Context, req *bindings.FindMetadataForDenom) (*bindings.FindDenomMetadataResponse, error) {
	res := qp.bank.GetAllDenomMetaData(ctx)

	for _, r := range res {
		for _, u := range r.DenomUnits {
			if u.Denom == req.Denom {
				// in case unit.Aliases is nil, we need to have an empty slice so that json.Marshal does not return null but [] instead
				// otherwise, the deserialization on rust side (cosmwasm) will fail
				var aliases = make([]string, 0)
				for _, alias := range u.Aliases {
					aliases = append(aliases, alias)
				}
				return &bindings.FindDenomMetadataResponse{Description: r.Description, Base: r.Base, Display: r.Display, Name: r.Name, Symbol: r.Symbol, Denom: u.Denom, Exponent: u.Exponent, Aliases: aliases}, nil
			}
		}
	}

	return nil, fmt.Errorf("failed to find metadata for %s", req.Denom)
}

func (qp *QueryPlugin) DenomMetadata(ctx sdk.Context, denom string) (*bindings.DenomMetadataResponse, error) {
	//func (qp *QueryPlugin) DenomMetadata(ctx sdk.Context, denom string) (*banktypes.QueryDenomMetadataResponse, error) {
	r, ok := qp.bank.GetDenomMetaData(ctx, denom)
	if !ok {
		return nil, fmt.Errorf("failed to get denom metadata")
	}

	var denon_units []*bindings.DenomUnit

	for _, unit := range r.DenomUnits {
		// in case unit.Aliases is nil, we need to have an empty slice so that json.Marshal does not return null but [] instead
		// otherwise, the deserialization on rust side (cosmwasm) will fail
		var aliases = make([]string, 0)
		for _, alias := range unit.Aliases {
			aliases = append(aliases, alias)
		}
		denon_units = append(denon_units, &bindings.DenomUnit{Denom: unit.Denom, Exponent: unit.Exponent, Aliases: aliases})
	}
	metadata := bindings.Metadata{
		Description: r.Description,
		DenomUnits:  denon_units,
		Base:        r.Base,
		Display:     r.Display,
		Name:        r.Name,
		Symbol:      r.Symbol,
	}
	return &bindings.DenomMetadataResponse{Metadata: metadata}, nil
	//return &banktypes.QueryDenomMetadataResponse{Metadata: r}, nil
}

func (qp *QueryPlugin) AllDenomMetadata(ctx sdk.Context) *bindings.AllDenomMetadataResponse {
	r := qp.bank.GetAllDenomMetaData(ctx)

	var metatdatas []bindings.Metadata
	for _, m := range r {
		var denon_units []*bindings.DenomUnit
		for _, unit := range m.DenomUnits {
			// in case unit.Aliases is nil, we need to have an empty slice so that json.Marshal does not return null but [] instead
			// otherwise, the deserialization on rust side (cosmwasm) will fail
			var aliases = make([]string, 0)
			for _, alias := range unit.Aliases {
				aliases = append(aliases, alias)
			}
			denon_units = append(denon_units, &bindings.DenomUnit{Denom: unit.Denom, Exponent: unit.Exponent, Aliases: aliases})
		}
		metadata := bindings.Metadata{
			Description: m.Description,
			DenomUnits:  denon_units,
			Base:        m.Base,
			Display:     m.Display,
			Name:        m.Name,
			Symbol:      m.Symbol,
		}
		metatdatas = append(metatdatas, metadata)
	}

	return &bindings.AllDenomMetadataResponse{Metadatas: metatdatas}
}

func (qp *QueryPlugin) FeeBasicAllowance(ctx sdk.Context, req *bindings.FeeBasicAllowance) (*bindings.FeeBasicAllowanceResponse, error) {
	granter, err := sdk.AccAddressFromBech32(req.Granter)
	if err != nil {
		return nil, errorsmod.Wrap(err, "failed to parse granter address")
	}

	grantee, err := sdk.AccAddressFromBech32(req.Grantee)
	if err != nil {
		return nil, errorsmod.Wrap(err, "failed to parse granter address")
	}

	allowance, err := qp.feegrant.GetAllowance(ctx, granter, grantee)
	if err != nil {
		return nil, errorsmod.Wrap(err, "failed to get fee allowance")
	}

	basicAllowance, ok := allowance.(*feegrant.BasicAllowance)
	if !ok {
		return nil, errorsmod.Wrap(err, "failed to get basic fee allowance")
	}

	//q := feegranttypes.QueryAllowanceRequest{
	//	Granter: req.Granter,
	//	Grantee: req.Grantee,
	//}
	//r, err := qp.feegrant.Allowance(ctx.Context(), &q)
	//if err != nil {
	//	return nil, errorsmod.Wrap(err, "failed to get fee allowance")
	//}

	return &bindings.FeeBasicAllowanceResponse{
		Allowance: &bindings.FeeBasicGrant{
			Granter:        req.Granter,
			Grantee:        req.Grantee,
			AllowanceDenom: basicAllowance.SpendLimit[0].Denom,
			AllowanceValue: basicAllowance.SpendLimit[0].Amount.Uint64(),
			Expiration:     basicAllowance.Expiration.String(),
		},
	}, nil
}
