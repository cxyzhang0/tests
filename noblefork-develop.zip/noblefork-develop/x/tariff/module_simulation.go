package tariff

import (
	"github.com/cosmos/cosmos-sdk/types/module"
	simtypes "github.com/cosmos/cosmos-sdk/types/simulation"
	"github.com/wfblockchain/noblechain/v5/x/tariff/types"
)

var _ module.AppModuleSimulation = AppModule{}

func (am AppModule) GenerateGenesisState(simState *module.SimulationState) {
	genesis := types.DefaultGenesis()
	simState.GenState[types.ModuleName] = simState.Cdc.MustMarshalJSON(genesis)
}

func (am AppModule) ProposalContents(_ module.SimulationState) []simtypes.WeightedProposalContent {
	return nil
}

// func (am AppModule) RandomizedParams(_ *rand.Rand) []simtypes.ParamChange {
// 	return nil
// }

func (am AppModule) RegisterStoreDecoder(_ simtypes.StoreDecoderRegistry) {}

func (am AppModule) WeightedOperations(_ module.SimulationState) []simtypes.WeightedOperation {
	return nil
}
