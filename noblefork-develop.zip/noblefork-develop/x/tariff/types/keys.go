package types

const (
	// ModuleName defines the module name
	ModuleName = "tariff"
)
