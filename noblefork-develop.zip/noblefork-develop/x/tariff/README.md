# Tariff module

Please see docs located [here](../../docs/modules/tariff.md).
