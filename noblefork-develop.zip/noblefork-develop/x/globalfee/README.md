# Global fee module

The Global fee module was supplied by the great folks at [TGrade](https://github.com/confio/tgrade) 👋, with minor modifications. All credits and big thanks go to the original authors.

More information about Cosmoshub fee system please check [here](../../docs/modules/globalfee.md).
