package globalfee

import (
	"github.com/wfblockchain/noblechain/v5/x/globalfee/types"
)

const (
	ModuleName = types.ModuleName
)
