#!/bin/bash

# !! PLEASE ONLY RUN THIS SCRIPT IN A TESTING ENVIRONMENT !!
#   THIS SCRIPT: 
#     - Stops/starts tfd binary

# This script is meant for quick experimentation of the Tokenfactory Module and tokenfactory Chain functionality.
#   - Starts tokenfactory chain
#   - Delagates and funds all privledged accounts for the `tokenfactory`.
#   - Only the "owner" account in the `fiat-tokenfactory` is set.
#   - The "owner" account is both the `tokenfactory` Owner AND the Param Authority

# This script is a template script for 1-val tokenfactory chain for the July release.
# tokenfactory module is to be used for wfdc2 and the fiat-tokenfactory module is to be used for the future WF deposit token wfusd.
# it corresponds tmkms/.tmkms-p11-val-all/tmkms-tf.toml
# This script is based on play_wallet_tmkms_usd.sh. Specifically,
# TF_OWNER, FTF_OWNER, and AUTHORITY are explicitly defined.
# no other accounts are funded.
#

CHAINDIR="play_1_val_july_sh"

killall tfd
[ -d "play_1_val_july_sh" ] && rm -r "play_1_val_july_sh"
# this does not work
#[ -d "'$CHAINDIR'" ] && rm -r "'$CHAINDIR'"

BINARY="./bin/tfd"
CHAINID="tokenfactory-1"
VAL="val-1"
CHAINHOME="$CHAINDIR/$CHAINID"
VALHOME="$CHAINDIR/$CHAINID/$VAL"
RPCPORT="26657"
P2PPORT="26656"
PROFPORT="6060"
GRPCPORT="9090"
VALIDATOR_PORT="26658"
DENOM="stake"
BASEDENOM="ustake"

KEYRING="--keyring-backend test"

# tokenfactory
TF1_MINTING_DENOM='USD'
TF1_MINTING_BASEDENOM="cent"

TF2_MINTING_DENOM='wfusd'
TF2_MINTING_BASEDENOM="u$TF2_MINTING_DENOM"

# The keys are stored in SoftHSM with labels as "Slot Token 0/wfdc2/owner/1", "Slot Token 0/wfdc2/masterminter/1", "Slot Token 0/wfdc2/mintercontroller/1", "Slot Token 0/wfdc2/minter/1", "Slot Token 0/wfdc2/blacklister/1", "Slot Token 0/wfdc2/pauser/1", "Slot Token 0/wfdc2/usa/1", "Slot Token 0/wfdc2/can/1", "Slot Token 0/wfdc2/user1/1", "Slot Token 0/wfdc2/user2/1"
# SoftHSM keys
## This is the tokenfactory owner address
TF_OWNER='wf1za2g3w046khqgmapgt3kmvv40nwlphv4xcf8jk'
## This is the fiat-tokenfactory owner address
## TODO: TF_OWNER and FTF_OWNER cannot be the same.
FTF_OWNER='wf1a02z7rzutc9g833943tjh4j5dvsplc0jqr03lw'
## This is the chain authority address. we set this to the TF_OWNER
AUTHORITY=$TF_OWNER

# Validator key - SoftHSM keys
PUBKEY_1="{\"@type\":\"/cosmos.crypto.ed25519.PubKey\",\"key\":\"8vSqNl18SajeCU8Y7LIM0c3xhZEqWRwKhk6ZtVRXoQA=\"}" #Slot Token 0/tmkms/ed25519-1/1

# Validator key - FX keys
#PUBKEY_1="{\"@type\":\"/cosmos.crypto.ed25519.PubKey\",\"key\":\"9fvps1uCAV1vi7aIHQLW+IBbRvrEwRAlT1aK+DtsCU4=\"}" #Slot Token 0/tmkms/ed25519-1/1


SILENT=1

redirect() {
  if [ "$SILENT" -eq 1 ]; then
    "$@" > /dev/null 2>&1
  else
    "$@"
  fi
}

# Add dir for chain, exit if error
if ! mkdir -p $VALHOME 2>/dev/null; then
    echo "Failed to create chain folder. Aborting..."
    exit 1
fi

# Build genesis file incl account for passed address
coins="1000000000000$DENOM"
#coins="1000000000000$DENOM,1000000000000$BASEDENOM"
delegate="100000000000$DENOM"
fund="100000000$DENOM"

$BINARY --home $VALHOME --chain-id $CHAINID init $CHAINID
sleep 1
$BINARY --home $VALHOME $KEYRING keys add validator --output json > $VALHOME/validator_seed.json 2>&1
sleep 1

$BINARY --home $VALHOME $KEYRING genesis add-genesis-account $TF_OWNER $coins
sleep 1
$BINARY --home $VALHOME $KEYRING genesis add-genesis-account $FTF_OWNER $coins
sleep 1
$BINARY --home $VALHOME $KEYRING genesis add-genesis-account $($BINARY --home $VALHOME keys $KEYRING show validator -a) $coins
sleep 1
$BINARY genesis gentx validator $delegate \
  --pubkey "$PUBKEY_1" \
  --home $VALHOME $KEYRING \
  --chain-id $CHAINID
sleep 1
$BINARY --home $VALHOME genesis collect-gentxs
sleep 1

# Check platform
platform='unknown'
unamestr=`uname`
if [ "$unamestr" = 'Linux' ]; then
   platform='linux'
fi

# Set proper defaults and change ports (use a different sed for Mac or Linux)
echo "Change settings in config.toml and genesis.json files..."
if [ $platform = 'linux' ]; then
echo "linux..."
  sed -i 's#"tcp://127.0.0.1:26657"#"tcp://0.0.0.0:'"$RPCPORT"'"#g' $VALHOME/config/config.toml
  sed -i 's#"tcp://0.0.0.0:26656"#"tcp://0.0.0.0:'"$P2PPORT"'"#g' $VALHOME/config/config.toml
  sed -i 's#"localhost:6060"#"localhost:'"$P2PPORT"'"#g' $VALHOME/config/config.toml
  sed -i 's/timeout_commit = "5s"/timeout_commit = "1s"/g' $VALHOME/config/config.toml
  sed -i 's/timeout_propose = "3s"/timeout_propose = "1s"/g' $VALHOME/config/config.toml
  sed -i 's/index_all_keys = false/index_all_keys = true/g' $VALHOME/config/config.toml
  # validator use external tmkms
  sed -i -e 's#priv_validator_laddr = ""#priv_validator_laddr = "tcp://0.0.0.0:'"$VALIDATOR_PORT"'"#g' $VALHOME/config/config.toml
  sed -i -e 's!priv_validator_key_file = "config/priv_validator_key.json"!\#priv_validator_key_file = "config/priv_validator_key.json"!g' $VALHOME/config/config.toml
  sed -i -e 's!priv_validator_state_file = "data/priv_validator_state.json"!\#priv_validator_state_file = "data/priv_validator_state.json"!g' $VALHOME/config/config.toml

  sed -i 's/"bond_denom": "stake"/"bond_denom": "'"$DENOM"'"/g' $VALHOME/config/genesis.json
  sed -i 's/"denom_metadata": \[]/"denom_metadata": [ { "display": "'$TF1_MINTING_DENOM'", "base": "'$TF1_MINTING_BASEDENOM'", "name": "'$TF1_MINTING_DENOM'", "symbol": "'$TF1_MINTING_DENOM'", "denom_units": [ { "denom": "'$TF1_MINTING_DENOM'", "aliases": [ "'$TF1_MINTING_DENOM'", "Dollar" ], "exponent": "2" }, { "denom": "'$TF1_MINTING_BASEDENOM'", "aliases": ["penny"], "exponent": "0" } ] }, { "display": "'$TF2_MINTING_DENOM'", "base": "'$TF2_MINTING_BASEDENOM'", "name": "'$TF2_MINTING_DENOM'", "symbol": "'$TF2_MINTING_DENOM'", "denom_units": [ { "denom": "'$TF2_MINTING_DENOM'", "aliases": [ "'$TF2_MINTING_DENOM'" ], "exponent": "6" }, { "denom": "m'$TF2_MINTING_DENOM'", "aliases": [ "micro'$TF2_MINTING_DENOM'" ], "exponent": "3" }, { "denom": "'$TF2_MINTING_BASEDENOM'", "aliases": null, "exponent": "0" } ] } ]/g' $VALHOME/config/genesis.json
  sed -i 's/"authority": ""/"authority": "'"$AUTHORITY"'"/g' $VALHOME/config/genesis.json
else
echo "not linux..."
  sed -i '' 's#"tcp://127.0.0.1:26657"#"tcp://0.0.0.0:'"$RPCPORT"'"#g' $VALHOME/config/config.toml
  sed -i '' 's#"tcp://0.0.0.0:26656"#"tcp://0.0.0.0:'"$P2PPORT"'"#g' $VALHOME/config/config.toml
  sed -i '' 's#"localhost:6060"#"localhost:'"$P2PPORT"'"#g' $VALHOME/config/config.toml
  sed -i '' 's/timeout_commit = "5s"/timeout_commit = "1s"/g' $VALHOME/config/config.toml
  sed -i '' 's/timeout_propose = "3s"/timeout_propose = "1s"/g' $VALHOME/config/config.toml
  sed -i '' 's/index_all_keys = false/index_all_keys = true/g' $VALHOME/config/config.toml
  # validator use external tmkms
  sed -i -e 's#priv_validator_laddr = ""#priv_validator_laddr = "tcp://0.0.0.0:'"$VALIDATOR_PORT"'"#g' $VALHOME/config/config.toml
  sed -i -e 's!priv_validator_key_file = "config/priv_validator_key.json"!\#priv_validator_key_file = "config/priv_validator_key.json"!g' $VALHOME/config/config.toml
  sed -i -e 's!priv_validator_state_file = "data/priv_validator_state.json"!\#priv_validator_state_file = "data/priv_validator_state.json"!g' $VALHOME/config/config.toml

  sed -i '' 's/"bond_denom": "stake"/"bond_denom": "'"$DENOM"'"/g' $VALHOME/config/genesis.json
  sed -i '' 's/"denom_metadata": \[]/"denom_metadata": [ { "display": "'$TF1_MINTING_DENOM'", "base": "'$TF1_MINTING_BASEDENOM'", "name": "'$TF1_MINTING_DENOM'", "symbol": "'$TF1_MINTING_DENOM'", "denom_units": [ { "denom": "'$TF1_MINTING_DENOM'", "aliases": [ "'$TF1_MINTING_DENOM'", "Dollar" ], "exponent": "2" }, { "denom": "'$TF1_MINTING_BASEDENOM'", "aliases": ["penny"], "exponent": "0" } ] }, { "display": "'$TF2_MINTING_DENOM'", "base": "'$TF2_MINTING_BASEDENOM'", "name": "'$TF2_MINTING_DENOM'", "symbol": "'$TF2_MINTING_DENOM'", "denom_units": [ { "denom": "'$TF2_MINTING_DENOM'", "aliases": [ "'$TF2_MINTING_DENOM'" ], "exponent": "6" }, { "denom": "m'$TF2_MINTING_DENOM'", "aliases": [ "micro'$TF2_MINTING_DENOM'" ], "exponent": "3" }, { "denom": "'$TF2_MINTING_BASEDENOM'", "aliases": null, "exponent": "0" } ] } ]/g' $VALHOME/config/genesis.json
#  sed -i '' 's/"denom_metadata": \[]/"denom_metadata": [ { "display": "'$TF1_MINTING_DENOM'", "base": "'$TF1_MINTING_BASEDENOM'", "name": "'$TF1_MINTING_DENOM'", "symbol": "'$TF1_MINTING_DENOM'", "denom_units": [ { "denom": "'$TF1_MINTING_DENOM'", "aliases": [ "'$TF1_MINTING_DENOM'", "Dollar" ], "exponent": "2" }, { "denom": "'$TF1_MINTING_BASEDENOM'", "aliases": ["penny"], "exponent": "0" } ] }, { "display": "'$TF2_MINTING_DENOM'", "base": "'$TF2_MINTING_BASEDENOM'", "name": "'$TF2_MINTING_DENOM'", "symbol": "'$TF2_MINTING_DENOM'", "denom_units": [ { "denom": "'$TF2_MINTING_DENOM'", "aliases": [ "'$TF2_MINTING_DENOM'" ], "exponent": "6" }, { "denom": "m'$TF2_MINTING_DENOM'", "aliases": [ "micro'$TF2_MINTING_DENOM'" ], "exponent": "3" }, { "denom": "'$TF2_MINTING_BASEDENOM'", "aliases": [ "'$TF2_MINTING_BASEDENOM'" ], "exponent": "0" } ] } ]/g' $VALHOME/config/genesis.json
  sed -i '' 's/"authority": ""/"authority": "'"$TF_OWNER"'"/g' $VALHOME/config/genesis.json
fi

echo "Use tempGen to change settings in genesis.json ..."
TMPGEN=tempGen.json
touch $TMPGEN && jq '.app_state.tokenfactory.owner.address = "'$TF_OWNER'"' $VALHOME/config/genesis.json > $TMPGEN && mv $TMPGEN $VALHOME/config/genesis.json
touch $TMPGEN && jq '.app_state.tokenfactory.mintingDenom.denom = "'$TF1_MINTING_BASEDENOM'"' $VALHOME/config/genesis.json > $TMPGEN && mv $TMPGEN $VALHOME/config/genesis.json
touch $TMPGEN && jq '.app_state.tokenfactory.paused.paused = false' $VALHOME/config/genesis.json > $TMPGEN && mv $TMPGEN $VALHOME/config/genesis.json

touch $TMPGEN && jq '.app_state."fiat-tokenfactory".owner.address = "'$FTF_OWNER'"' $VALHOME/config/genesis.json > $TMPGEN && mv $TMPGEN $VALHOME/config/genesis.json
touch $TMPGEN && jq '.app_state."fiat-tokenfactory".mintingDenom.denom = "'$TF2_MINTING_BASEDENOM'"' $VALHOME/config/genesis.json > $TMPGEN && mv $TMPGEN $VALHOME/config/genesis.json
touch $TMPGEN && jq '.app_state."fiat-tokenfactory".paused.paused = false' $VALHOME/config/genesis.json > $TMPGEN && mv $TMPGEN $VALHOME/config/genesis.json

# note: validate-genesis Error: error validating genesis file play_1_val_july_sh/tokenfactory-1/val-1/config/genesis.json: metadata's first denomination unit must be the one with base denom 'cent'
#echo "***** validate-genesis on $VAL ..."
#$BINARY validate-genesis --home $VALHOME

echo "Start chain ..."
# Start
$BINARY --home $VALHOME start --pruning=nothing --grpc-web.enable=false --grpc.address="0.0.0.0:$GRPCPORT" --trace --log_level=trace
#$BINARY --home $VALHOME start --pruning=nothing --grpc-web.enable=false --grpc.address="0.0.0.0:$GRPCPORT" > $VALHOME/$VAL.log 2>&1 &


# tfd --home ./play_1_val_july_sh/tokenfactory-1/val-1 start --pruning=nothing --grpc-web.enable=false --grpc.address="0.0.0.0:9090" --trace --log_level=trace
