#!/bin/bash

# !! PLEASE ONLY RUN THIS SCRIPT IN A TESTING ENVIRONMENT !!
#   THIS SCRIPT: 
#     - Stops/starts tfd binary

# This script is meant for quick experimentation of the Tokenfactory Module and tokenfactory Chain functionality.
#   - Starts tokenfactory chain
#   - Delagates and funds all privledged accounts for the `tokenfactory`.
#   - Only the "owner" account in the `fiat-tokenfactory` is set.
#   - The "owner" account is both the `tokenfactory` Owner AND the Param Authority

# This script starts to treat chain as tokenfactory chain instead of nobel chain.
# source ./chains.env

killall tfd
[ -d "play_sh" ] && rm -r "play_sh"

BINARY="./bin/tfd"
CHAINID="tokenfactory-1"
CHAINDIR="play_sh"
RPCPORT="26657"
P2PPORT="26656"
PROFPORT="6060"
GRPCPORT="9090"
DENOM="stake"
BASEDENOM="ustake"

KEYRING="--keyring-backend=test"

STAKE_DENOM="stake"

# tokenfactory
TF1_MINTING_DENOM='wfusd'
TF1_MINTING_BASEDENOM="u$TF1_MINTING_DENOM"

TF2_MINTING_DENOM='wfdc'
TF2_MINTING_BASEDENOM="u$TF2_MINTING_DENOM"

echo "retrieve faucet mnemonics ..."
FAUCET_MNEMONIC=$(jq -r '.mnemonic' ./july/seeds/faucet_seed.json)

SILENT=1

redirect() {
  if [ "$SILENT" -eq 1 ]; then
    "$@" > /dev/null 2>&1
  else
    "$@"
  fi
}

# Add dir for chain, exit if error
if ! mkdir -p $CHAINDIR/$CHAINID 2>/dev/null; then
    echo "Failed to create chain folder. Aborting..."
    exit 1
fi



# Build genesis file incl account for passed address
# TODO: why only one coin in coins does not work?
#coins="100000000000$BASEDENOM"
coins="1000000000000$DENOM,1000000000000$BASEDENOM"
delegate="100000000000$DENOM"

# Build genesis file incl account for passed address
FAUCET_COINS="1000000000000000$STAKE_DENOM" # 10^15
COINS="1000000000$STAKE_DENOM" # 10^9
DELEGATE="1000000000$STAKE_DENOM" # 10^9
FUND_COINS="1000000$STAKE_DENOM" # 10^6

$BINARY --home $CHAINDIR/$CHAINID --chain-id $CHAINID init $CHAINID

sleep 2

echo "***** add faucet key ..."
(echo $FAUCET_MNEMONIC; echo "") | $BINARY keys add faucet --home $CHAINDIR/$CHAINID $KEYRING --interactive --no-backup
FAUCET_ADDR=$($BINARY keys show faucet -a --home $CHAINDIR/$CHAINID $KEYRING)
echo "faucet address: $FAUCET_ADDR"
sleep 1

sleep 1
$BINARY --home $CHAINDIR/$CHAINID $KEYRING keys add validator --output json > $CHAINDIR/$CHAINID/validator_seed.json 2>&1
sleep 1
$BINARY --home $CHAINDIR/$CHAINID $KEYRING keys add tf1_owner --output json > $CHAINDIR/$CHAINID/tf1_ownerSeed.json 2>&1
sleep 1
$BINARY --home $CHAINDIR/$CHAINID $KEYRING keys add tf2_owner --output json > $CHAINDIR/$CHAINID/tf2_ownerSeed.json 2>&1
sleep 1
$BINARY --home $CHAINDIR/$CHAINID $KEYRING genesis add-genesis-account $($BINARY --home $CHAINDIR/$CHAINID keys $KEYRING show tf1_owner -a) $coins
sleep 1
$BINARY --home $CHAINDIR/$CHAINID $KEYRING genesis add-genesis-account $($BINARY --home $CHAINDIR/$CHAINID keys $KEYRING show tf2_owner -a) $coins
sleep 1
$BINARY --home $CHAINDIR/$CHAINID $KEYRING genesis add-genesis-account $($BINARY --home $CHAINDIR/$CHAINID keys $KEYRING show validator -a) $coins
sleep 1
$BINARY --home $CHAINDIR/$CHAINID $KEYRING genesis gentx validator $delegate --chain-id $CHAINID
sleep 1
$BINARY --home $CHAINDIR/$CHAINID genesis collect-gentxs
sleep 1

TF1_OWNER=$(jq '.address' $CHAINDIR/$CHAINID/tf1_ownerSeed.json)
TF2_OWNER=$(jq '.address' $CHAINDIR/$CHAINID/tf2_ownerSeed.json)

# Check platform
platform='unknown'
unamestr=`uname`
if [ "$unamestr" = 'Linux' ]; then
   platform='linux'
fi

# Set proper defaults and change ports (use a different sed for Mac or Linux)
echo "Change settings in config.toml and genesis.json files..."
if [ $platform = 'linux' ]; then
  sed -i 's#"tcp://127.0.0.1:26657"#"tcp://0.0.0.0:'"$RPCPORT"'"#g' $CHAINDIR/$CHAINID/config/config.toml
  sed -i 's#"tcp://0.0.0.0:26656"#"tcp://0.0.0.0:'"$P2PPORT"'"#g' $CHAINDIR/$CHAINID/config/config.toml
  sed -i 's#"localhost:6060"#"localhost:'"$P2PPORT"'"#g' $CHAINDIR/$CHAINID/config/config.toml
  sed -i 's/timeout_commit = "5s"/timeout_commit = "1s"/g' $CHAINDIR/$CHAINID/config/config.toml
  sed -i 's/timeout_propose = "3s"/timeout_propose = "1s"/g' $CHAINDIR/$CHAINID/config/config.toml
  sed -i 's/index_all_keys = false/index_all_keys = true/g' $CHAINDIR/$CHAINID/config/config.toml
  sed -i 's/"bond_denom": "stake"/"bond_denom": "'"$DENOM"'"/g' $CHAINDIR/$CHAINID/config/genesis.json
  sed -i 's/"denom_metadata": \[]/"denom_metadata": [ { "display": "'$TF1_MINTING_DENOM'", "base": "'$TF1_MINTING_BASEDENOM'", "name": "'$TF1_MINTING_DENOM'", "symbol": "'$TF1_MINTING_DENOM'", "denom_units": [ { "denom": "'$TF1_MINTING_DENOM'", "aliases": [ "micro'$TF1_MINTING_DENOM'" ], "exponent": "0" }, { "denom": "m'$TF1_MINTING_DENOM'", "aliases": [ "mili'$TF1_MINTING_DENOM'" ], "exponent": "3" }, { "denom": "'$TF1_MINTING_BASEDENOM'", "aliases": null, "exponent": "6" } ] }, { "display": "'$TF2_MINTING_DENOM'", "base": "'$TF2_MINTING_BASEDENOM'", "name": "'$TF2_MINTING_DENOM'", "symbol": "'$TF2_MINTING_DENOM'", "denom_units": [ { "denom": "'$TF2_MINTING_DENOM'", "aliases": [ "micro'$TF2_MINTING_DENOM'" ], "exponent": "0" }, { "denom": "m'$TF2_MINTING_DENOM'", "aliases": [ "mili'$TF2_MINTING_DENOM'" ], "exponent": "3" }, { "denom": "'$TF2_MINTING_BASEDENOM'", "aliases": null, "exponent": "6" } ] } ]/g' $CHAINDIR/$CHAINID/config/genesis.json
  sed -i 's/"authority": ""/"authority": '"$TF1_OWNER"'/g' $CHAINDIR/$CHAINID/config/genesis.json
else
  sed -i '' 's#"tcp://127.0.0.1:26657"#"tcp://0.0.0.0:'"$RPCPORT"'"#g' $CHAINDIR/$CHAINID/config/config.toml
  sed -i '' 's#"tcp://0.0.0.0:26656"#"tcp://0.0.0.0:'"$P2PPORT"'"#g' $CHAINDIR/$CHAINID/config/config.toml
  sed -i '' 's#"localhost:6060"#"localhost:'"$P2PPORT"'"#g' $CHAINDIR/$CHAINID/config/config.toml
  sed -i '' 's/timeout_commit = "5s"/timeout_commit = "1s"/g' $CHAINDIR/$CHAINID/config/config.toml
  sed -i '' 's/timeout_propose = "3s"/timeout_propose = "1s"/g' $CHAINDIR/$CHAINID/config/config.toml
  sed -i '' 's/index_all_keys = false/index_all_keys = true/g' $CHAINDIR/$CHAINID/config/config.toml
  sed -i '' 's/"bond_denom": "stake"/"bond_denom": "'"$DENOM"'"/g' $CHAINDIR/$CHAINID/config/genesis.json
  sed -i '' 's/"denom_metadata": \[]/"denom_metadata": [ { "display": "'$TF1_MINTING_DENOM'", "base": "'$TF1_MINTING_BASEDENOM'", "name": "'$TF1_MINTING_DENOM'", "symbol": "'$TF1_MINTING_DENOM'", "denom_units": [ { "denom": "'$TF1_MINTING_DENOM'", "aliases": [ "micro'$TF1_MINTING_DENOM'" ], "exponent": "0" }, { "denom": "m'$TF1_MINTING_DENOM'", "aliases": [ "mili'$TF1_MINTING_DENOM'" ], "exponent": "3" }, { "denom": "'$TF1_MINTING_BASEDENOM'", "aliases": null, "exponent": "6" } ] }, { "display": "'$TF2_MINTING_DENOM'", "base": "'$TF2_MINTING_BASEDENOM'", "name": "'$TF2_MINTING_DENOM'", "symbol": "'$TF2_MINTING_DENOM'", "denom_units": [ { "denom": "'$TF2_MINTING_DENOM'", "aliases": [ "micro'$TF2_MINTING_DENOM'" ], "exponent": "0" }, { "denom": "m'$TF2_MINTING_DENOM'", "aliases": [ "mili'$TF2_MINTING_DENOM'" ], "exponent": "3" }, { "denom": "'$TF2_MINTING_BASEDENOM'", "aliases": null, "exponent": "6" } ] } ]/g' $CHAINDIR/$CHAINID/config/genesis.json
  sed -i '' 's/"authority": ""/"authority": '"$TF1_OWNER"'/g' $CHAINDIR/$CHAINID/config/genesis.json
fi

TMPGEN=tempGen.json
touch $TMPGEN && jq '.app_state.tokenfactory.owner.address = '$TF1_OWNER'' $CHAINDIR/$CHAINID/config/genesis.json > $TMPGEN && mv $TMPGEN $CHAINDIR/$CHAINID/config/genesis.json
touch $TMPGEN && jq '.app_state.tokenfactory.mintingDenom.denom = "'$TF1_MINTING_BASEDENOM'"' $CHAINDIR/$CHAINID/config/genesis.json > $TMPGEN && mv $TMPGEN $CHAINDIR/$CHAINID/config/genesis.json
touch $TMPGEN && jq '.app_state.tokenfactory.paused.paused = false' $CHAINDIR/$CHAINID/config/genesis.json > $TMPGEN && mv $TMPGEN $CHAINDIR/$CHAINID/config/genesis.json

touch $TMPGEN && jq '.app_state."fiat-tokenfactory".owner.address = '$TF2_OWNER'' $CHAINDIR/$CHAINID/config/genesis.json > $TMPGEN && mv $TMPGEN $CHAINDIR/$CHAINID/config/genesis.json
touch $TMPGEN && jq '.app_state."fiat-tokenfactory".mintingDenom.denom = "'$TF2_MINTING_BASEDENOM'"' $CHAINDIR/$CHAINID/config/genesis.json > $TMPGEN && mv $TMPGEN $CHAINDIR/$CHAINID/config/genesis.json
touch $TMPGEN && jq '.app_state."fiat-tokenfactory".paused.paused = false' $CHAINDIR/$CHAINID/config/genesis.json > $TMPGEN && mv $TMPGEN $CHAINDIR/$CHAINID/config/genesis.json


# Start
$BINARY --home $CHAINDIR/$CHAINID start --pruning=nothing --grpc-web.enable=false --grpc.address="0.0.0.0:$GRPCPORT" > $CHAINDIR/$CHAINID.log 2>&1 &


OWNER_MN=$(jq .mnemonic $CHAINDIR/$CHAINID/tf1_ownerSeed.json)
OWNER_MN=$(echo $OWNER_MN | cut -d "\"" -f 2)

# Create keys
sleep 2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING keys add masterminter
$BINARY --home $CHAINDIR/$CHAINID $KEYRING keys add mintercontroller
$BINARY --home $CHAINDIR/$CHAINID $KEYRING keys add minter
$BINARY --home $CHAINDIR/$CHAINID $KEYRING keys add blacklister
$BINARY --home $CHAINDIR/$CHAINID $KEYRING keys add pauser
$BINARY --home $CHAINDIR/$CHAINID $KEYRING keys add user

$BINARY --home $CHAINDIR/$CHAINID $KEYRING keys add masterminter2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING keys add mintercontroller2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING keys add minter2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING keys add blacklister2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING keys add pauser2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING keys add user2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING keys add user3

$BINARY --home $CHAINDIR/$CHAINID $KEYRING keys add faucet

# Fund accounts
$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx bank send tf1_owner $($BINARY --home $CHAINDIR/$CHAINID $KEYRING keys show masterminter -a) 1000000stake -y
sleep 2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx bank send tf1_owner $($BINARY --home $CHAINDIR/$CHAINID $KEYRING keys show mintercontroller -a) 1000000stake -y
sleep 2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx bank send tf1_owner $($BINARY --home $CHAINDIR/$CHAINID $KEYRING keys show minter -a) 1000000stake -y
sleep 2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx bank send tf1_owner $($BINARY --home $CHAINDIR/$CHAINID $KEYRING keys show blacklister -a) 1000000stake -y
sleep 2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx bank send tf1_owner $($BINARY --home $CHAINDIR/$CHAINID $KEYRING keys show pauser -a) 1000000stake -y
sleep 2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx bank send tf1_owner $($BINARY --home $CHAINDIR/$CHAINID $KEYRING keys show user -a) 1000000stake -y
sleep 2

$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx bank send tf1_owner $($BINARY --home $CHAINDIR/$CHAINID $KEYRING keys show masterminter2 -a) 1000000stake -y
sleep 2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx bank send tf1_owner $($BINARY --home $CHAINDIR/$CHAINID $KEYRING keys show mintercontroller2 -a) 1000000stake -y
sleep 2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx bank send tf1_owner $($BINARY --home $CHAINDIR/$CHAINID $KEYRING keys show minter2 -a) 1000000stake -y
sleep 2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx bank send tf1_owner $($BINARY --home $CHAINDIR/$CHAINID $KEYRING keys show blacklister2 -a) 1000000stake -y
sleep 2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx bank send tf1_owner $($BINARY --home $CHAINDIR/$CHAINID $KEYRING keys show pauser2 -a) 1000000stake -y
sleep 2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx bank send tf1_owner $($BINARY --home $CHAINDIR/$CHAINID $KEYRING keys show user2 -a) 1000000stake -y
sleep 2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx bank send tf1_owner $($BINARY --home $CHAINDIR/$CHAINID $KEYRING keys show user3 -a) 1000000stake -y
sleep 2

# Delegate privledges
$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx tokenfactory update-master-minter $($BINARY --home $CHAINDIR/$CHAINID $KEYRING keys show masterminter -a) --from tf1_owner -y
sleep 2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx tokenfactory configure-minter-controller $($BINARY --home $CHAINDIR/$CHAINID $KEYRING keys show mintercontroller -a) $($BINARY --home $CHAINDIR/$CHAINID $KEYRING keys show minter -a) --from masterminter -y
sleep 2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx tokenfactory configure-minter $($BINARY --home $CHAINDIR/$CHAINID $KEYRING keys show minter -a) 1000$TF1_MINTING_BASEDENOM --from mintercontroller -y
sleep 2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx tokenfactory update-blacklister $($BINARY --home $CHAINDIR/$CHAINID $KEYRING keys show blacklister -a) --from tf1_owner -y
sleep 2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx tokenfactory update-pauser $($BINARY --home $CHAINDIR/$CHAINID $KEYRING keys show pauser -a) --from tf1_owner -y

# Delegate privledges - fiat-tokenfactory
$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx fiat-tokenfactory update-master-minter $($BINARY --home $CHAINDIR/$CHAINID $KEYRING keys show masterminter -a) --from tf2_owner -y
sleep 2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx fiat-tokenfactory configure-minter-controller $($BINARY --home $CHAINDIR/$CHAINID $KEYRING keys show mintercontroller -a) $($BINARY --home $CHAINDIR/$CHAINID $KEYRING keys show minter -a) --from masterminter -y
sleep 2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx fiat-tokenfactory configure-minter $($BINARY --home $CHAINDIR/$CHAINID $KEYRING keys show minter -a) 1000$TF2_MINTING_BASEDENOM --from mintercontroller -y
sleep 2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx fiat-tokenfactory update-blacklister $($BINARY --home $CHAINDIR/$CHAINID $KEYRING keys show blacklister -a) --from tf2_owner -y
sleep 2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx fiat-tokenfactory update-pauser $($BINARY --home $CHAINDIR/$CHAINID $KEYRING keys show pauser -a) --from tf2_owner -y

# tfd --home ./play_sh/tokenfactory-1 start --pruning=nothing --grpc-web.enable=false --grpc.address="0.0.0.0:9090" --trace --log_level=trace