#!/bin/bash

# IMPORTANT: This script is meant to be run only once.
BINARY=../../bin/tfd
$BINARY --home ./temphome --keyring-backend test keys add faucet --output json > faucet_seed.json 2>&1
sleep 1
i=1
while [ $i -le 10 ]; do
  $BINARY --home ./temphome --keyring-backend test keys add val_$i --output json > val_"$i"_seed.json 2>&1
  sleep 1
  i=$((i+1))
done

i=1
while [ $i -le 15 ]; do
  $BINARY --home ./temphome --keyring-backend test keys add xyz_$i --output json > xyz_"$i"_seed.json 2>&1
  sleep 1
  i=$((i+1))
done

rm -r ./temphome
