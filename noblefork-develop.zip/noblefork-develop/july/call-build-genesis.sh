./build-genesis.sh \
 "tokenfactory-1" \
 "192.168.4.51,192.168.4.51,192.168.4.51,192.168.4.51" \
 "4441,4442,4443,4444" \
 "wf129gnx4fm96pjdhp8k8ey4pwuvwequuetun50ts" \
 "wf129gnx4fm96pjdhp8k8ey4pwuvwequuetun50ts" \
 "wf1y4azpdylc27q8yyru3ua9t7am3493vexqfsenu" \
 "wf1x5u0nzy2ygxanyrvtfp0tsvdyqzshh36q492w5" \
 "wf1wn5nkfw57kpmlxhgskv56275mflmapxkr4tc8m" \
 "wf1l4zym6tk6wnwe7p7m3yjr6zvsnljg0ud4drap6" \
 "wf1fz3mzr4j8l9h8xsmx7lgxgncq6ah92w75wpe6p" \
 "wf1pxy6ntphdt6s0nnv4qd9frhv48sqzjs768kmzs"
