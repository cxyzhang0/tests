#!/bin/sh
# ref: https://medium.com/@himitsu1007/adding-a-validator-node-to-existing-cosmos-sdk-chain-b96a6891bad7

# add a validator to an existing running chain which must have 2 or more validators.
# steps:
# 1. run this script to initialize and configure the validator
# 2. fund the validator stake tokens from the faucet
# 3. start the node to sync with the chain
# 4. create the validator with the stake tokens

# Validator consensus keys are from tmkms p11hsm or softsign.

# example:
# cd july
# ./addval.sh "tokenfactory-1" "val_4" "1114" "2224" "3334" "4444" "5554" "6664" "192.168.4.51" "./seeds/val_4_seed.json" "5b06e01f2a483b7af6f35bf61795eb32073ebf92@192.168.4.51:4441,ed36df6a1aaf55ec8e6f84ad562abfbab6399de4@192.168.4.51:4442" "localhost:2221,localhost:2222" "2640" "E60DBFF1060FCF7CD4957483429C325F7D196D90DDEFC52F4600A343F632D75C" "./tokenfactory-1/val_1/config/genesis.json"
# ./addval.sh "tokenfactory-1" "val_3" "1113" "2223" "3333" "4443" "5553" "6663" "192.168.4.51" "./seeds/val_3_seed.json" "5b06e01f2a483b7af6f35bf61795eb32073ebf92@192.168.4.51:4441,ed36df6a1aaf55ec8e6f84ad562abfbab6399de4@192.168.4.51:4442" "localhost:2221,localhost:2222" "20" "A3BC11A86504EF84B564F420F3C383E02293EF65A5919E11EFDF405ACA790E63" "./tokenfactory-1/val_1/config/genesis.json"
# for Redhat node -
# ./addval.sh "tokenfactory-1" "val_3" "26658" "26657" "9090" "26656" "6060" "9091" "192.168.4.51" "./seeds/val_3_seed.json" "5b06e01f2a483b7af6f35bf61795eb32073ebf92@192.168.4.51:4441,ed36df6a1aaf55ec8e6f84ad562abfbab6399de4@192.168.4.51:4442" "localhost:2221,localhost:2222" "20" "A3BC11A86504EF84B564F420F3C383E02293EF65A5919E11EFDF405ACA790E63" "./tokenfactory-1/val_1/config/genesis.json"

# utility:
# tfd tendermint show-node-id --home ./tokenfactory-1/val_1
# tfd config -h
# to get the block hash at height 5493, search 5494's last block_id.hash and use base64 to hex conversion
# tfd q block 5494 --home ./tokenfactory-1/val_1  # height 5493 hash  DE8D5A84B68623E4E98516844927CA760AFD689785C98EFFF25B32BB605E500B
# https://base64.guru/converter/decode/hex

# tfd q staking validators $NODE
# tfd q tendermint-validator-set $NODE

# curl -s localhost:2223/status | jq '.result.sync_info.catching_up'
# tfd status $NODE | jq

# todo: make sure BINARY is set correctly for the chain daemon
BINARY="../bin/tfd"
echo "***** parse args ..."
CHAINID=${1}          #"tokenfactory-1"
VALID=${2}            #"val_2"
VALIDATOR_PORT=${3}   #1112
RPC_PORT=${4}         #2222
GRPC_PORT=${5}        #3332
P2P_PORT=${6}         #4442
PPROF_PORT=${7}       #5552
GRPCWEB_PORT=${8}     #6662
HOST=${9}             #"192.168.4.51"
VAL_SEED=${10}        #"./seeds/val_1_seed.json"
PEERS=${11}           #"5b06e01f2a483b7af6f35bf61795eb32073ebf92@192.168.4.51:4441,ed36df6a1aaf55ec8e6f84ad562abfbab6399de4@192.168.4.51:4442"
RPC_SERVERS=${12}     #"localhost:2221,localhost:2222"
TRUST_HEIGHT=${13}    #"5493"
TRUST_HASH=${14}      #"DE8D5A84B68623E4E98516844927CA760AFD689785C98EFFF25B32BB605E500B"
SOURCE_GENESIS=${15}  #"./tokenfactory-1/val_1/config/genesis.json"

echo "***** set vars ..."
CHAINID_ARG="--chain-id $CHAINID"
CHAINHOME="./$CHAINID"
HOME="$CHAINID/$VALID"
HOME_ARG="--home $HOME"

KEYRING="--keyring-backend=file"
KEYRING_DIR="--keyring-dir=$CHAINHOME/keys"

STAKE_DENOM="stake"
STAKE_BASE_DENOM="u$STAKE_DENOM"
COINS="1000000000$STAKE_DENOM" # 10^9
DELEGATE="100000000$STAKE_DENOM" # 10^8
FEES="1000000$STAKE_DENOM" # 10^6

echo "***** retrieve mnemonics ..."
VAL_MNEMONIC=$(jq -r '.mnemonic' $VAL_SEED)

echo "***** cleanup - delete just the validator ..."
rm -r $HOME

echo "***** chain initialization ..."
$BINARY init "$VALID" --chain-id "$CHAINID" $HOME_ARG --overwrite > /dev/null 2>&1 &
sleep 2

echo "***** add validator key ..."
(echo "$VAL_MNEMONIC"; echo ""; echo password; echo password) | $BINARY keys add $VALID $KEYRING "$KEYRING_DIR" --interactive --no-backup

echo "***** copy genesis.json from source ..."
cp "$SOURCE_GENESIS" "$HOME/config/genesis.json"

echo "***** edit config.toml, app.toml and client.toml for $VALID ..."
./configval.sh "$CHAINID" "$VALID" "$VALIDATOR_PORT" "$RPC_PORT" "$GRPC_PORT" "$P2P_PORT" "$PPROF_PORT" "$GRPCWEB_PORT" "$HOST"

echo "***** edit config.toml - enable statesync, rpc_servers, trust_height, trust_hash ..."
sed -i -e '/\[statesync\]/,+6 s/enable = false/enable = true/' "$HOME/config/config.toml"
#sed -i -e 's/enable = false/enable = true/g' "$HOME/config/config.toml"
sed -i -e 's#rpc_servers = ""#rpc_servers = "'"$RPC_SERVERS"'"#g' "$HOME/config/config.toml"
sed -i -e 's#trust_height = 0#trust_height = '"$TRUST_HEIGHT"'#g' "$HOME/config/config.toml"
sed -i -e 's#trust_hash = ""#trust_hash = "'"$TRUST_HASH"'"#g' "$HOME/config/config.toml"

echo "***** edit config.toml - seeds, peers ..."
sed -i -e 's#seeds = ""#seeds = "'"$PEERS"'"#g' "$HOME/config/config.toml"
sed -i -e 's#persistent_peers = "*"#persistent_peers = "'"$PEERS"'"#g' "$HOME/config/config.toml"

# todo: why ./tokenfactory/ was created?
rm -r "$HOME/.tokenfactory/"

# step 2 - fund validator
#echo "fund validator"
# todo: note here --home uses val_1 instead of val_3 because node 3 is not running.
#  alternatively, we could also use --node tcp://localhost:2221
#FAUCET_ADDR=$(echo password | $BINARY keys show faucet -a $KEYRING "$KEYRING_DIR")
#VAL_ADDR=$(echo password | $BINARY keys show $VALID -a $KEYRING "$KEYRING_DIR")
#echo password | $BINARY tx bank send $FAUCET_ADDR $VAL_ADDR $COINS \
#$CHAINID_ARG --home $CHAINHOME/val_1 $KEYRING "$KEYRING_DIR" --yes

# step 3 - start the node to sync with the chain
#$BINARY start $HOME_ARG --log_level trace --pruning nothing --grpc.address :$GRPC_PORT
#tfd start --home ./tokenfactory-1/val_4 --log_level trace --pruning nothing --grpc.address :3334
#gex -p 2224
#tfd start --home ./tokenfactory-1/val_3 --log_level trace --pruning nothing --grpc.address :3333
#gex -p 2223
#tfd start --home ./tokenfactory-1/val_2 --log_level trace --pruning nothing --grpc.address :3332
#gex -p 2222

# step 4 - create the validator with the stake tokens
# todo: this step follows when the node has completed its sync.
# note: syntax differs for different versions of cometbft
# cometbft 0.38.0+
#echo password | tfd tx staking create-validator ./data/val_4.json \
#  --from val_4 \
#    $CHAINID_ARG $TXFLAG $KEYRING $KEYRING_DIR \
#    --log_level trace --trace

#echo password | tfd tx staking create-validator ./data/val_3.json \
#  --from val_3 \
#    $CHAINID_ARG $TXFLAG $KEYRING $KEYRING_DIR \
#    --log_level trace --trace
#    -y

# cometbft 0.38.0-
#echo password | tfd tx staking create-validator
#  --from val_3 \
#  --amount 100000000stake \
#  --pubkey "{\"@type\":\"/cosmos.crypto.ed25519.PubKey\",\"key\":\"3/8REMmORznU8PKp1K3VkCCtHY9TxlUcLeeK4gKF7bQ=\"}" \
#  --moniker "val_3" \
#  --chain-id "tokenfactory-1" \
#  --commission-rate "0.10" \
#  --commission-max-rate "0.20" \
#  --commission-max-change-rate "0.01" \
#  --min-self-delegation "1" \
#  --gas auto \
#  --gas-adjustment 1.5 \
#  --gas-prices "0.025stake" \

