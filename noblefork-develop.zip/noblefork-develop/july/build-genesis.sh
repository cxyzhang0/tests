#!/bin/sh

# build a tokenfactory chain initially with N genesis validators, val_1, val_2, ..., val_N
#  additional validators can be added subsequently via addval.sh
# this set of scripts can be run on a redhat 8 vm as well as on a mac localhost.
# it results in N home folders, tokenfactory-1/val_1, tokenfactory-1/val_2, ...,  tokenfactory-1/val_N and
#  a tokenfactory-1/keys folder to store the common keyring-file.
# for redhat 8, we assume the N validators are on different vms - so the IP addresses are different and the ports are the same
# for localhost, we assume the N validators are on the same localhost - so the IP addresses are the same and the ports are different

# faucet:
# faucet address is passed in as an argument.
# for dev/test net and production, the faucet private key is created and stored in HSM.
# for local development, the faucet private key can be created from the faucet mnemonic seed and stored in a keyring file.
#echo "retrieve faucet mnemonics ..."
#FAUCET_MNEMONIC=$(jq -r '.mnemonic' ./seeds/faucet_seed.json)
#echo "***** add faucet key to keyring ..."
#(echo $FAUCET_MNEMONIC; echo ""; echo password; echo password) | $BINARY keys add faucet $KEYRING "$KEYRING_DIR" --interactive --no-backup
#FAUCET_ADDR=$(echo password | $BINARY keys show faucet -a $KEYRING "$KEYRING_DIR")

# hard-coded:
# faucet is the key name in the keyring for the faucet account
# val_i is key name in the keyring, i = 1, 2, ..., N

# dependencies:
# ./seeds - mnemonic seeds for each validator's genesis account
# ./pubkeys - public keys for each validator's consensus key

# example - 4 validator local net with SoftHsm keys: see call-build-genesis.sh
# cd july
# ./build-genesis.sh "tokenfactory-1" "192.168.4.51,192.168.4.51" "4441,4442" "wf129gnx4fm96pjdhp8k8ey4pwuvwequuetun50ts" "wf129gnx4fm96pjdhp8k8ey4pwuvwequuetun50ts" "wf1y4azpdylc27q8yyru3ua9t7am3493vexqfsenu"
#./build-genesis.sh \
# "tokenfactory-1" \
# "192.168.4.51,192.168.4.51,192.168.4.51,192.168.4.51" \
# "4441,4442,4443,4444" \
# "wf129gnx4fm96pjdhp8k8ey4pwuvwequuetun50ts" \
# "wf129gnx4fm96pjdhp8k8ey4pwuvwequuetun50ts" \
# "wf1y4azpdylc27q8yyru3ua9t7am3493vexqfsenu" \
# "wf1x5u0nzy2ygxanyrvtfp0tsvdyqzshh36q492w5" \
# "wf1wn5nkfw57kpmlxhgskv56275mflmapxkr4tc8m" \
# "wf1l4zym6tk6wnwe7p7m3yjr6zvsnljg0ud4drap6" \
# "wf1fz3mzr4j8l9h8xsmx7lgxgncq6ah92w75wpe6p" \
# "wf1pxy6ntphdt6s0nnv4qd9frhv48sqzjs768kmzs"

#
# the above puts all chain and val data under ./tokenfactory-1
# that corresponds tmkms/.tmkms-p11-val-all/tmkms-simd-july.toml

# notes:
# note: P2P_PORTS are not used for gentx here because the cometbft currently used by tokenfactory is old.
#  newer versions of cometbft's gentx supports setting p2p port.
# note: tokenfactory may not support localhost chain with multiple validators because it uses cometbft 0.34.0.
#  it seems only cometbft 0.38.0+ supports localhost chain multiple validators.
#  so we may not be able to test the scripts by running a chain locally with multiple validators.
#  but we may test the scripts for by running a single validator chain locally -
# ./build-genesis.sh "tokenfactory-1" "192.168.4.51" "26656" "wf129gnx4fm96pjdhp8k8ey4pwuvwequuetun50ts" "wf129gnx4fm96pjdhp8k8ey4pwuvwequuetun50ts" "wf1y4azpdylc27q8yyru3ua9t7am3493vexqfsenu"

# Validator consensus keys are from tmkms p11hsm.
# SoftHSM keys - this is replaced by ./pubkeys/val_*_pubkey.json
#PUBKEY_1="{\"@type\":\"/cosmos.crypto.ed25519.PubKey\",\"key\":\"8vSqNl18SajeCU8Y7LIM0c3xhZEqWRwKhk6ZtVRXoQA=\"}" #Slot Token 0/tmkms/ed25519-1/1
#PUBKEY_2="{\"@type\":\"/cosmos.crypto.ed25519.PubKey\",\"key\":\"nHSyTp1csR7K84oJXpC+UIuRx5rPzjXIH25FcqQ1mDY=\"}" #Slot Token 0/tmkms/ed25519-2/1
#PUBKEY_3="{\"@type\":\"/cosmos.crypto.ed25519.PubKey\",\"key\":\"3/8REMmORznU8PKp1K3VkCCtHY9TxlUcLeeK4gKF7bQ=\"}" #Slot Token 0/tmkms/ed25519-3/1
#PUBKEY_4="{\"@type\":\"/cosmos.crypto.ed25519.PubKey\",\"key\":\"WOVea4ERYji2biV/X/G67aG3Q6ERK0WIwOla+gjU/os=\"}" #Slot Token 0/tmkms/ed25519-4/1

# FX keys - these are in Virtucrypt. if desired, replace ./pubkeys/val_*_pubkey.json with these keys.
#PUBKEY_1="{\"@type\":\"/cosmos.crypto.ed25519.PubKey\",\"key\":\"9fvps1uCAV1vi7aIHQLW+IBbRvrEwRAlT1aK+DtsCU4=\"}" #Slot Token 0/tmkms/ed25519-1/1
#PUBKEY_2="{\"@type\":\"/cosmos.crypto.ed25519.PubKey\",\"key\":\"7P4Ej2rZ7+Is7yVpiLLy2VQyHp0mn1Rn44CV88RVu/k=\"}" #Slot Token 0/tmkms/ed25519-2/1
#PUBKEY_3="{\"@type\":\"/cosmos.crypto.ed25519.PubKey\",\"key\":\"CmX82H45wvfu272oYWc+ZBNSuSpaegyB3A79pRAzP1I=\"}" #Slot Token 0/tmkms/ed25519-3/1
#PUBKEY_4="{\"@type\":\"/cosmos.crypto.ed25519.PubKey\",\"key\":\"FyLjsivmT9b2Nsg1Ac3UxkkgioN5B/qHlC5HypIM3pQ=\"}" #Slot Token 0/tmkms/ed25519-4/1

# todo: make sure BINARY is set correctly for the chain daemon
BINARY="../bin/tfd"
echo "***** parse args ..."
CHAINID=${1}
HOSTS=${2}
P2P_PORTS=${3}
TF_OWNER=${4}
FTF_OWNER=${5}
FAUCET_ADDR=${6}
MASTERMINTER=${7}
MINTERCONTROLLER=${8}
MINTER=${9}
BLACKLISTER=${10}
PAUSER=${11}

AUTHORITY=$TF_OWNER

IFS=","
read -ra HOSTS <<< "$HOSTS"
read -ra P2P_PORTS <<< "$P2P_PORTS"
if [ ${#HOSTS[@]} -ne ${#P2P_PORTS[@]} ]; then
  echo "hosts and p2p_ports mismatch"
  exit 1
fi
N=${#HOSTS[@]}
echo "***** number of genesis validators: $N"

echo "***** set vars ..."
CHAINID_ARG="--chain-id $CHAINID"
CHAINHOME="./$CHAINID"
KEYRING="--keyring-backend=file"
KEYRING_DIR="--keyring-dir=$CHAINHOME/keys"

STAKE_DENOM="stake"
STAKE_BASE_DENOM="u$STAKE_DENOM"
# tokenfactory denoms
TF1_MINTING_DENOM='USD'
TF1_MINTING_BASEDENOM="cent"
TF2_MINTING_DENOM='wfusd'
TF2_MINTING_BASEDENOM="u$TF2_MINTING_DENOM"

FAUCET_COINS="1000000000000000$STAKE_DENOM" # 10^15
OWNER_COINS="0$STAKE_DENOM" # 0
VAL_COINS="1000000000$STAKE_DENOM" # 10^10
DELEGATE="900000000$STAKE_DENOM" # 9*10^9 < VAL_COINS because validator needs coins to pay for such tx as unjail
FEES="10$STAKE_DENOM" # 10^1

i=0
VALS=()
MNEMONICS=()
PUBKEYS=()
while [ $i -lt $N ]; do
  j=$((i+1))
  VAL="val_$j"
  MNEMONIC=$(jq -r '.mnemonic' ./seeds/$VAL"_seed.json")
  PUBKEY=$(jq '' ./pubkeys/$VAL"_pubkey.json")
  VALS[$i]=$VAL
  MNEMONICS[$i]=$MNEMONIC
  PUBKEYS[$i]=$PUBKEY
  i=$((i+1))
done

#echo "retrieve faucet mnemonics ..."
#FAUCET_MNEMONIC=$(jq -r '.mnemonic' ./seeds/faucet_seed.json)

echo "***** cleanup ..."
killall $BINARY
rm -r $CHAINHOME

# initialize validators
echo "***** chain val initialization ..."
for val in "${VALS[@]}"; do
  echo "***** chain val initialization $val..."
  $BINARY init $val --chain-id $CHAINID --home $CHAINHOME/$val --overwrite > /dev/null 2>&1 &
done
#echo -e $VALS \
#  | xargs -I {} \
#  $BINARY init {} --chain-id $CHAINID --home $CHAINHOME/{} --overwrite > null 2>&1

#echo "***** add faucet key ..."
#(echo $FAUCET_MNEMONIC; echo ""; echo password; echo password) | $BINARY keys add faucet $KEYRING "$KEYRING_DIR" --interactive --no-backup
#FAUCET_ADDR=$(echo password | $BINARY keys show faucet -a $KEYRING "$KEYRING_DIR")
sleep 1

echo "***** add faucet genesis account ..."
$BINARY genesis add-genesis-account "$FAUCET_ADDR" "$FAUCET_COINS" --home $CHAINHOME/${VALS[0]}
echo "***** add tf owner genesis account ..."
$BINARY genesis add-genesis-account "$TF_OWNER" "$OWNER_COINS" --home $CHAINHOME/${VALS[0]}
echo "***** add ftf owner genesis account ..."
$BINARY genesis add-genesis-account "$FTF_OWNER" "$OWNER_COINS" --home $CHAINHOME/${VALS[0]}
echo "***** add other genesis accounts ..."
$BINARY genesis add-genesis-account "$MASTERMINTER" "$OWNER_COINS" --home $CHAINHOME/${VALS[0]}
$BINARY genesis add-genesis-account "$MINTERCONTROLLER" "$OWNER_COINS" --home $CHAINHOME/${VALS[0]}
$BINARY genesis add-genesis-account "$MINTER" "$OWNER_COINS" --home $CHAINHOME/${VALS[0]}
$BINARY genesis add-genesis-account "$BLACKLISTER" "$OWNER_COINS" --home $CHAINHOME/${VALS[0]}
$BINARY genesis add-genesis-account "$PAUSER" "$OWNER_COINS" --home $CHAINHOME/${VALS[0]}
echo "***** add validators' keys and genesis accounts ..."
i=0
while [ $i -lt $N ]; do
  VAL=${VALS[$i]}
  MNEMONIC=${MNEMONICS[$i]}
  echo "***** add $VAL key and genesis account ..."
  (echo "$MNEMONIC"; echo ""; echo password; echo password) | $BINARY keys add $VAL $KEYRING $KEYRING_DIR --home $CHAINHOME/${VALS[0]} --interactive --no-backup
  VAL_ADDR=$(echo password | $BINARY keys show $VAL -a $KEYRING $KEYRING_DIR)
  $BINARY genesis add-genesis-account $VAL_ADDR $VAL_COINS --home $CHAINHOME/${VALS[0]} # NOTE: add to val_1's genesis.json
  i=$((i+1))
done

echo "***** gentx ..."
i=1
while [ $i -lt $((N+1)) ]; do
  prev=$((i-1))
  j=$i
  if [ $i -eq $N ]; then
    j=0
  fi
  VAL=${VALS[$j]}
  echo "***** gentx for $VAL $CHAINID_ARG"
  PUBKEY=${PUBKEYS[$j]}
  P2P_PORT=${P2P_PORTS[$j]}
  mv $CHAINHOME/${VALS[$prev]}/config/genesis.json $CHAINHOME/$VAL/config
  echo password | $BINARY genesis gentx $VAL $DELEGATE \
    --fees $FEES \
    --pubkey "$PUBKEY" \
    --home $CHAINHOME/$VAL \
    --chain-id $CHAINID $KEYRING $KEYRING_DIR
  #  --p2p-port $P2P_PORT \
  i=$((i+1))
done

echo "***** gather all other gentxs to ${VALS[0]} ..."
i=1
while [ $i -lt $N ]; do
  cp -r $CHAINHOME/${VALS[$i]}/config/gentx/* $CHAINHOME/${VALS[0]}/config/gentx
  i=$((i+1))
done

echo "***** collect-gentxs on ${VALS[0]} ..."
$BINARY genesis collect-gentxs --home $CHAINHOME/${VALS[0]} > /dev/null 2>&1 &
echo "***** validate-genesis on ${VALS[0]} ..."
$BINARY genesis validate-genesis --home $CHAINHOME/${VALS[0]}

echo "***** post gentx - edit ${VALS[0]} genesis.json ..."
sed -i -e 's/"bond_denom": "stake"/"bond_denom": "'"$STAKE_DENOM"'"/g' $CHAINHOME/${VALS[0]}/config/genesis.json
sed -i -e 's/"denom_metadata": \[]/"denom_metadata": [ { "display": "'$TF1_MINTING_DENOM'", "base": "'$TF1_MINTING_BASEDENOM'", "name": "'$TF1_MINTING_DENOM'", "symbol": "'$TF1_MINTING_DENOM'", "denom_units": [ { "denom": "'$TF1_MINTING_DENOM'", "aliases": [ "'$TF1_MINTING_DENOM'", "Dollar" ], "exponent": "2" }, { "denom": "'$TF1_MINTING_BASEDENOM'", "aliases": ["penny"], "exponent": "0" } ] }, { "display": "'$TF2_MINTING_DENOM'", "base": "'$TF2_MINTING_BASEDENOM'", "name": "'$TF2_MINTING_DENOM'", "symbol": "'$TF2_MINTING_DENOM'", "denom_units": [ { "denom": "'$TF2_MINTING_DENOM'", "aliases": [ "'$TF2_MINTING_DENOM'" ], "exponent": "6" }, { "denom": "m'$TF2_MINTING_DENOM'", "aliases": [ "micro'$TF2_MINTING_DENOM'" ], "exponent": "3" }, { "denom": "'$TF2_MINTING_BASEDENOM'", "aliases": null, "exponent": "0" } ] } ]/g' $CHAINHOME/${VALS[0]}/config/genesis.json
sed -i -e 's/"authority": ""/"authority": "'"$AUTHORITY"'"/g' $CHAINHOME/${VALS[0]}/config/genesis.json

echo "***** use tempGen to change settings in genesis.json ..."
TMPGEN=tempGen.json
touch $TMPGEN && jq '.app_state.tokenfactory.owner.address = "'$TF_OWNER'"' $CHAINHOME/${VALS[0]}/config/genesis.json > $TMPGEN && mv $TMPGEN $CHAINHOME/${VALS[0]}/config/genesis.json
touch $TMPGEN && jq '.app_state.tokenfactory.mintingDenom.denom = "'$TF1_MINTING_BASEDENOM'"' $CHAINHOME/${VALS[0]}/config/genesis.json > $TMPGEN && mv $TMPGEN $CHAINHOME/${VALS[0]}/config/genesis.json
touch $TMPGEN && jq '.app_state.tokenfactory.paused.paused = false' $CHAINHOME/${VALS[0]}/config/genesis.json > $TMPGEN && mv $TMPGEN $CHAINHOME/${VALS[0]}/config/genesis.json

touch $TMPGEN && jq '.app_state."fiat-tokenfactory".owner.address = "'$FTF_OWNER'"' $CHAINHOME/${VALS[0]}/config/genesis.json > $TMPGEN && mv $TMPGEN $CHAINHOME/${VALS[0]}/config/genesis.json
touch $TMPGEN && jq '.app_state."fiat-tokenfactory".mintingDenom.denom = "'$TF2_MINTING_BASEDENOM'"' $CHAINHOME/${VALS[0]}/config/genesis.json > $TMPGEN && mv $TMPGEN $CHAINHOME/${VALS[0]}/config/genesis.json
touch $TMPGEN && jq '.app_state."fiat-tokenfactory".paused.paused = false' $CHAINHOME/${VALS[0]}/config/genesis.json > $TMPGEN && mv $TMPGEN $CHAINHOME/${VALS[0]}/config/genesis.json

echo "***** distribute ${VALS[0]} genesis.json to all other validators ..."
i=1
while [ $i -lt $N ]; do
  cp -r $CHAINHOME/${VALS[0]}/config/genesis.json $CHAINHOME/${VALS[$i]}/config
  i=$((i+1))
done

echo "***** define persistent_peers ..."
PEERS=""
i=0
while [ $i -lt $N ]; do
  if [ "$PEERS" != "" ]; then
    PEERS="$PEERS,"
  fi
  PEERS="$PEERS$($BINARY tendermint show-node-id --home $CHAINHOME/${VALS[$i]})@${HOSTS[$i]}:${P2P_PORTS[$i]}"
  i=$((i+1))
done

echo "***** Peers: $PEERS"

# todo: should this be done in configval.sh?
#  pro for being here - peers are dynamic and complex so it is messy to set an example in configval.sh documentation.
echo "***** update persistent_peers in all config.toml ..."
for val in "${VALS[@]}"; do
##  if [ "$val" != "val_1" ]; then
    sed -i -e 's#persistent_peers = ".*"#persistent_peers = "'"$PEERS"'"#g' "$CHAINHOME/$val/config/config.toml"
##  fi
done

platform=$(uname -s)
echo "***** platform=$platform"

echo "***** edit genesis.json, config.toml, app.toml and client.toml ..."
i=0
while [ $i -lt $N ]; do
  VAL=${VALS[$i]}
  j=$((i+1))
  echo "***** edit config.toml, app.toml and client.toml for $VAL ..."
  if [[ $platform = 'Linux'  ||  $N = 1 ]]; then
    echo "***** for Linux or N=1 ..."
    ./configval.sh "$CHAINID" $VAL "26658" "26657" "9090" ${P2P_PORTS[$i]} "6060" "9091" ${HOSTS[$i]}
  else
    echo "***** for not (Linux or N=1) ..."
    ./configval.sh "$CHAINID" $VAL "111$j" "222$j" "333$j" ${P2P_PORTS[$i]} "555$j" "666$j" ${HOSTS[$i]}
  fi
  i=$j
done

# start the chain
# single validator
#tfd start --home ./tokenfactory-1/val_1 --log_level trace --pruning nothing --grpc.address :9090
#tfd start --home ./tokenfactory-1/val_1 --pruning=nothing --grpc-web.enable=false --grpc.address="0.0.0.0:9090" --trace --log_level=trace

# multiple validators
#tfd start --home ./tokenfactory-1/val_1 --log_level trace --pruning nothing --grpc.address :3331
#gex -p 2221
#tfd start --home ./tokenfactory-1/val_2 --log_level trace --pruning nothing --grpc.address :3332
#gex -p 2222
#tfd start --home ./tokenfactory-1/val_3 --log_level trace --pruning nothing --grpc.address :3333
#gex -p 2223
#tfd start --home ./tokenfactory-1/val_4 --log_level trace --pruning nothing --grpc.address :3334
#gex -p 2224

