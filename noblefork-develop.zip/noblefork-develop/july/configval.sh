#!/bin/sh
# or #!/bin/bash or #!/bin/zsh
# this script configures a validator as part of build-genesis.sh
# it is useful for testing the network of validators backed by tmkms.
# it takes these arguments:
# 1. chain id, e.g. "tokenfactory-1"
# 2. validator id, e.g. "val_1"
# 3. validator port number, e.g. "1111"
# 4. rpc port number, e.g. "2221"
# 5. grpc port number, e.g. "3331"
# 6. p2p port number, e.g. "4441"
# 7. pprof port number, e.g. "5551"
# 8. gRPC web port number, e.g. "6661"
# 9. host  #old: TMKMS, "tmkms" indicates config for tmkms.

# example
# ./configval.sh "chain-1" "val_1" "1111" "2221" "3331" "4441" "5551" "6661" "192.168.4.51"
# ./configval.sh "chain-1" "val_2" "1112" "2222" "3332" "4442" "5552" "6662" "192.168.4.51"
# ./configval.sh "chain-1" "val_3" "1113" "2223" "3333" "4443" "5553" "6663" "192.168.4.51"
# ./configval.sh "chain-1" "val_4" "1114" "2224" "3334" "4444" "5554" "6664" "192.168.4.51"

echo "***** configval.sh - parse args ..."
CHAINID=${1} #"tokenfactory-1"
VALID=${2}
VALIDATOR_PORT=${3} #1111
RPC_PORT=${4} #2221
GRPC_PORT=${5} #3331
P2P_PORT=${6} #4441
PPROF_PORT=${7} #5551
GRPCWEB_PORT=${8} #6661
HOST=${9} # 192.168.4.51

CHAINID_ARG="--chain-id $CHAINID"
HOME="./$CHAINID/$VALID"
HOME_ARG="--home $HOME"

echo "***** configval.sh - CHAINID: $CHAINID; VAL: $VALID; HOME: $HOME"

set -e

echo "***** configval.sh - edit config.toml ..."
sed -i -e 's#tcp://127.0.0.1:26657#tcp://0.0.0.0:'"$RPC_PORT"'#g' "$HOME/config/config.toml"

# note: the following setting of grpc_laddr causes grpc client connection error. be careful.
#sed -i -e 's#grpc_laddr = ""#grpc_laddr = "tcp://localhost:'"$GRPC_PORT"'"#g' "$HOME/config/config.toml"

sed -i -e 's#tcp://0.0.0.0:26656#tcp://0.0.0.0:'"$P2P_PORT"'#g' "$HOME/config/config.toml"
sed -i -e 's#external_address = ""#external_address = "'"$HOST"':'"$P2P_PORT"'"#g' "$HOME/config/config.toml"

# note: the original play.sh use P2P_PORT; is that a typo?
sed -i -e 's#localhost:6060#localhost:'"$PPROF_PORT"'#g' "$HOME/config/config.toml"
#sed -i -e 's#localhost:6060#localhost:'"$P2P_PORT"'#g' "$HOME/config/config.toml"

sed -i -e 's/timeout_commit = "5s"/timeout_commit = "1s"/g' $HOME/config/config.toml
sed -i -e 's/timeout_propose = "3s"/timeout_propose = "1s"/g' $HOME/config/config.toml
sed -i -e 's/index_all_keys = false/index_all_keys = true/g' $HOME/config/config.toml
sed -i -e 's#addr_book_strict = true#addr_book_strict = false#g' "$HOME/config/config.toml"
sed -i -e 's#allow_duplicate_ip = false#allow_duplicate_ip = true#g' "$HOME/config/config.toml"

sed -i -e 's#priv_validator_laddr = ""#priv_validator_laddr = "tcp://0.0.0.0:'"$VALIDATOR_PORT"'"#g' "$HOME/config/config.toml"
sed -i -e 's!priv_validator_key_file = "config/priv_validator_key.json"!\#priv_validator_key_file = "config/priv_validator_key.json"!g' "$HOME/config/config.toml"
sed -i -e 's!priv_validator_state_file = "data/priv_validator_state.json"!\#priv_validator_state_file = "data/priv_validator_state.json"!g' "$HOME/config/config.toml"

sed -i -e 's#log_format = "plain"#log_format = "json"#g' "$HOME/config/config.toml"

echo "***** configval.sh - app.toml ..."
sed -i -e '/\[telemetry\]/,+8 s/enable = false/enable = true/' "$HOME/config/app.toml"
sed -i -e '/\[api\]/,+3 s/enable = false/enable = true/' "$HOME/config/app.toml"
# note: the original play.sh does not set the following two
sed -i -e 's#address = "localhost:9090"#address = "localhost:'"$GRPC_PORT"'"#g' "$HOME/config/app.toml" # grpc
sed -i -e 's#address = "localhost:9091"#address = "localhost:'"$GRPCWEB_PORT"'"#g' "$HOME/config/app.toml" # grpc web
sed -i -e 's#snapshot-interval = 0#snapshot-interval = 10#g' "$HOME/config/app.toml"

echo "***** configval.sh - client.toml node ..."
#this is another way set config - $BINARY config set client node tcp://lochost:2221 $HOME_ARG
sed -i -e 's#node = "tcp://localhost:26657"#node = "tcp://localhost:'"$RPC_PORT"'"#g' "$HOME/config/client.toml" # grpc web
