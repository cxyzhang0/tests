# noblechain
This repo is a private fork of https://github.com/noble-assets/noble.git. See the original [README](README.md).  
It is a submodule of [coreblock-chains](https://github.com/wfblockchain/coreblock-chains.git).  
The main contribution is the integration of wasmd and custom messages for tokenfactory and fiat-tokenfactory. See [Developer notes](Developer.md) for more details.  

This branch is made to work with following dependencies:
cosmos-sdk v0.50.7
cosmWasm wasmd v0.51.0
cometbft v0.38.7

Some of the changes introduced in latest version of sdk are as follows and the observations made on that:
1. When started to upgrade the chain to work with cometbft latest version, it was noticed that the this lates cometbft supports sdk version 0.50.x, hence started with upgrading sdk version as well.
2. Noblefork is dependent on three other dependencies, namely, noble-cctp, noble-fiattokenfactory and noble-paramauthority. First upgraded these three dependencies to work with sdk v0.50.7.
3. functions BeginBlock and EndBlock are now changed to FinalizeBlock
4. GetQueryCmd function is no longer required
5. GetOrGenerate function no longer requires codec as argument
6. Instead of keeping the add-genesis-account, gentx and collect-gentxs commands as seperate, these have been included in a single command genesis. 
7. Starting from the ibc-go v8.3.x, we need to add the query router before starting the chain.
8. Delivertx function has been made private and hence is called internally.
9. Previously, all modules were required to be set in OrderBeginBlockers, OrderEndBlockers and OrderInitGenesis / OrderExportGenesis in app.go. This is no longer the case, the assertion has been loosened to only require modules implementing, respectively, the appmodule.HasBeginBlocker, appmodule.HasEndBlocker and appmodule.HasGenesis / module.HasGenesis interfaces.
10. The cosmos is not compatible with the "github.com/syndtr/goleveldb v1.0.1-0.20220721030215-126854af5e6d" and this leads to failing of query and other commands, added the compatible version: 
github.com/syndtr/goleveldb => github.com/syndtr/goleveldb v1.0.1-0.20210819022825-2ae1ddf74ef7
11. The following modules NewKeeper function now take a KVStoreService instead of a StoreKey:

   - x/auth
   - x/authz
   - x/bank
   - x/consensus
   - x/crisis
   - x/distribution
   - x/evidence
   - x/feegrant
   - x/gov
   - x/mint
   - x/nft
   - x/slashing
   - x/upgrade

