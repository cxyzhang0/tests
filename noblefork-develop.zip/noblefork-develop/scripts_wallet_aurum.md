## scripts for aurum contract

```shell
source ./chains_wallet_tmkms.env

# upload wasm code and get $CODE_ID: two steps
STORE=$(tfd tx wasm store ../../../rust/cosmos/wfdc2/target/wasm32-unknown-unknown/release/aurum_optimized.wasm --from validator $TXFLAG $KEYRING $NODE_HOME -y -b sync --output json) && \
TX_HASH=$(echo $STORE | jq -r '.txhash') && \
echo "$TX_HASH"

TX=$(tfd q tx $TX_HASH $NODE_CHAIN --output json) && \
CODE_ID=$(echo $TX | jq -r '.logs[0].events[-1].attributes[1].value') && \
echo $CODE_ID
## 8, 5, 4, 2

# instantiate and get CONTRACT_ADDRESS: two steps
TF_ADDRESS=wf1gwm6mrnse9atzf4mer4dnrz64mp6pa75wpsxywu8gymt9fwsk46sqsvkyg && \
INIT=$(jq -n --arg tf_address $TF_ADDRESS '{ "tf_address": $tf_address }') && \
echo $INIT && \
RES=$(tfd tx wasm instantiate $CODE_ID "$INIT" --from validator --label "aurum" --no-admin $NODE_HOME $KEYRING $TXFLAG -y --output json)

CONTRACT_ADDRESS=$(tfd query wasm list-contract-by-code $CODE_ID $NODE_CHAIN --output json | jq -r '.contracts[-1]') && \
echo $CONTRACT_ADDRESS

## wf1nc5tatafv6eyq7llkr2gv50ff9e22mnf70qgjlv737ktmt4eswrqx9slkx from code 2

# ***** NO tx can be executed via daemon because the keys are in HSM
# tx
## mint/fund
#TRACKING_ID="aac39993-9dbb-416e-9107-7834eeaf498e" && \
TRACKING_ID=$(uuidgen) && \
DT=$(date -u +"%Y-%m-%dT%H:%M:%S.%1Z") && \
DATE=$(date -u +"%Y-%m-%d") && \
X500_ISSUER=$(jq -n '{ "common_name": "PartyC", "organization_unit": "", "organization": "PartyC", "locality": "Dallas", "state": "TX", "country": "US" }') && \
X500_BRANCH=$(jq -n '{ "common_name": "PartyA", "organization_unit": "", "organization": "PartyA", "locality": "Dallas", "state": "TX", "country": "US" }') && \
REQ=$(jq -n --arg tracking_id $TRACKING_ID --arg amount 100 --arg currency "uwfusd" --argjson originating_party $X500_ISSUER --argjson beneficiary_party $X500_BRANCH \
--arg message_type "MT202" --arg payment_type "Funding" \
--arg dt $DT --arg date $DATE \
'{ "originating_party": $originating_party, "beneficiary_party": $beneficiary_party, "amount": $amount | tonumber, "currency": $currency, 
"message_type": $message_type, "payment_type": $payment_type, "payment_instruction": "MT202 blob", "tracking_id": $tracking_id,
"send_business_date": $date, "request_date_time": $dt,
"custom1": "custom1", "custom2": "custom2", "custom3": "custom3", "custom4": "custom4", "custom5": "custom5", "custom6": "custom6" } ') && \
JSON=$(jq -n --argjson req "$REQ" --arg beneficiary $USER '{ "fund": { "req": $req, "beneficiary": $beneficiary } }') && \
echo $JSON && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from minter $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

## payment
TRACKING_ID=$(uuidgen) && \
DT=$(date -u +"%Y-%m-%dT%H:%M:%S.%1Z") && \
DATE=$(date -u +"%Y-%m-%d") && \
X500_A=$(jq -n '{ "common_name": "PartyA", "organization_unit": "", "organization": "PartyA", "locality": "Dallas", "state": "TX", "country": "US" }') && \
X500_B=$(jq -n '{ "common_name": "PartyB", "organization_unit": "", "organization": "PartyB", "locality": "Dallas", "state": "TX", "country": "US" }') && \
REQ=$(jq -n --arg tracking_id $TRACKING_ID --arg amount 5 --arg currency "uwfusd" --argjson originating_party $X500_A --argjson beneficiary_party $X500_B \
--arg message_type "MT103" --arg payment_type "Payment" \
--arg dt $DT --arg date $DATE \
'{ "originating_party": $originating_party, "beneficiary_party": $beneficiary_party, "amount": $amount | tonumber, "currency": $currency, 
"message_type": $message_type, "payment_type": $payment_type, "payment_instruction": "MT103 blob", "tracking_id": $tracking_id,
"send_business_date": $date, "request_date_time": $dt,
"custom1": "custom1", "custom2": "custom2", "custom3": "custom3", "custom4": "custom4", "custom5": "custom5", "custom6": "custom6" } ') && \
JSON=$(jq -n --argjson req "$REQ" --arg beneficiary $USER2 '{ "pay": { "req": $req, "beneficiary": $beneficiary } }') && \
echo $JSON && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from user --amount 5uwfusd $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

## defund
TRACKING_ID=$(uuidgen) && \
DT=$(date -u +"%Y-%m-%dT%H:%M:%S.%1Z") && \
DATE=$(date -u +"%Y-%m-%d") && \
X500_A=$(jq -n '{ "common_name": "PartyA", "organization_unit": "", "organization": "PartyA", "locality": "Dallas", "state": "TX", "country": "US" }') && \
X500_B=$(jq -n '{ "common_name": "PartyC", "organization_unit": "", "organization": "PartyC", "locality": "Dallas", "state": "TX", "country": "US" }') && \
REQ=$(jq -n --arg tracking_id $TRACKING_ID --arg amount 10 --arg currency "uwfusd" --argjson originating_party $X500_A --argjson beneficiary_party $X500_B \
--arg message_type "MT202" --arg payment_type "Defunding" \
--arg dt $DT --arg date $DATE \
'{ "originating_party": $originating_party, "beneficiary_party": $beneficiary_party, "amount": $amount | tonumber, "currency": $currency, 
"message_type": $message_type, "payment_type": $payment_type, "payment_instruction": "MT103 blob", "tracking_id": $tracking_id,
"send_business_date": $date, "request_date_time": $dt,
"custom1": "custom1", "custom2": "custom2", "custom3": "custom3", "custom4": "custom4", "custom5": "custom5", "custom6": "custom6" } ') && \
JSON=$(jq -n --argjson req "$REQ" --arg beneficiary $MINTER '{ "defund": { "req": $req, "beneficiary": $beneficiary } }') && \
echo $JSON && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from user --amount 10uwfusd $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

# query
## Config {}
JSON=$(jq -n '{ config: {} }') && \
echo $JSON && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

## PaymentState { tracking_id }
JSON=$(jq -n --arg tracking_id $TRACKING_ID '{ payment_state: { "tracking_id": $tracking_id } }') && \
echo $JSON && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

## Balance { req, address } 
TRACKING_ID=$(uuidgen) && \
DT=$(date -u +"%Y-%m-%dT%H:%M:%S.%1Z") && \
DATE=$(date -u +"%Y-%m-%d") && \
X500_A=$(jq -n '{ "common_name": "PartyA", "organization_unit": "", "organization": "PartyA", "locality": "Dallas", "state": "TX", "country": "US" }') && \
REQ=$(jq -n --arg tracking_id $TRACKING_ID --arg ref_number "AABBB" --arg currency "uwfusd" --argjson party $X500_A \
--arg dt $DT --arg date $DATE \
'{ "party": $party, 
"currency": $currency, 
"tracking_id": $tracking_id,
"ref_number": $ref_number,
"request_date_time": $dt
} ') && \
JSON=$(jq -n --argjson req "$REQ" --arg address $CAN '{ "balance": { "req": $req, "address": $address } }') && \
echo $JSON && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq



```
