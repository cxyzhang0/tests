#!/bin/bash

# !! PLEASE ONLY RUN THIS SCRIPT IN A TESTING ENVIRONMENT !!
#   THIS SCRIPT: 
#     - Stops/starts tfd binary

# This script is meant for quick experimentation of the Tokenfactory Module and tokenfactory Chain functionality.
#   - Starts tokenfactory chain
#   - Delagates and funds all privledged accounts for the `tokenfactory`.
#   - Only the "owner" account in the `fiat-tokenfactory` is set.
#   - The "owner" account is both the `tokenfactory` Owner AND the Param Authority

# This script is based on play_wallet.sh. Specifically,
# This script starts to treat chain as tokenfactory chain instead of nobel chain.
# Further, tokenfactory entities's keys are stored in PKCS11 HSM backed wallets.
# Further, validator key is stored in SoftHSM.
# Further, minting denom for tokenfactory uses USD instead of wfusd/wfdc while the fiat-tokenfactory uses wfusd.
# it corresponds tmkms/.tmkms-p11-val-all/tmkms-tf.toml
# TODO: instead of mnemonic, faucet key should be stored in PKCS11 HSM backed wallets. See play_wallet.sh for reference.
# source ./chains_wallet_tmkms.env

killall tfd
[ -d "play_wallet_tmkms_sh" ] && rm -r "play_wallet_tmkms_sh"

BINARY="./bin/tfd"
CHAINID="tokenfactory-1"
CHAINDIR="play_wallet_tmkms_sh"
RPCPORT="26657"
P2PPORT="26656"
PROFPORT="6060"
GRPCPORT="9090"
VALIDATOR_PORT="26658"

KEYRING="--keyring-backend test"

DENOM="stake"
BASEDENOM="ustake"
# tokenfactory
TF1_MINTING_DENOM='USD'
TF1_MINTING_BASEDENOM="cent"

TF2_MINTING_DENOM='wfusd'
TF2_MINTING_BASEDENOM="u$TF2_MINTING_DENOM"

# The keys are stored in SoftHSM with labels as "Slot Token 0/wfdc2/owner/1", "Slot Token 0/wfdc2/masterminter/1", "Slot Token 0/wfdc2/mintercontroller/1", "Slot Token 0/wfdc2/minter/1", "Slot Token 0/wfdc2/blacklister/1", "Slot Token 0/wfdc2/pauser/1", "Slot Token 0/wfdc2/usa/1", "Slot Token 0/wfdc2/can/1", "Slot Token 0/wfdc2/user1/1", "Slot Token 0/wfdc2/user2/1"
# SoftHSM keys
TF_OWNER='wf129gnx4fm96pjdhp8k8ey4pwuvwequuetun50ts'
TF_MASTERMINTER='wf1x5u0nzy2ygxanyrvtfp0tsvdyqzshh36q492w5'
TF_MINTERCONTROLLER='wf1wn5nkfw57kpmlxhgskv56275mflmapxkr4tc8m'
TF_MINTER='wf1l4zym6tk6wnwe7p7m3yjr6zvsnljg0ud4drap6'
TF_BLACKLISTER='wf1fz3mzr4j8l9h8xsmx7lgxgncq6ah92w75wpe6p'
TF_PAUSER='wf1pxy6ntphdt6s0nnv4qd9frhv48sqzjs768kmzs'

TF_USA='wf1vnzcv55fxt2n9v3dam9dsjf7wrxww4mxj8gzvq'
TF_CAN='wf1qcnvhjpuue9a8kdhzk9x0mzy7u844pzvyxwzz7'
TF_USER1='wf1pdnrlm04qllz6h2en34n90w800q07xeu5jtja9'
TF_USER2='wf169wf39jpge0n2f7zpwn9fz2grdk5yl8yr86t68'

# FX keys
#TF_OWNER='wf1eakrd6mswtje95ldtqrrxw3x55srz76mqe4t0y'
#TF_MASTERMINTER='wf1zfkmjasvwf4k0zfxc5tp6v244puv3828gd4fhh'
#TF_MINTERCONTROLLER='wf1pwhh02knkd3f9l07ev0f4uhshfeestwhr4h9e8'
#TF_MINTER='wf1cvfvwus3rmqak8sgf5h4fepduju6m7yukzuw8w'
#TF_BLACKLISTER='wf1cpgjhv9lusjgrgkqvwxssngmjats6g9y7nc5l9'
#TF_PAUSER='wf1e4rdj38zrm8gtl8xm4vdh4lvrl3e3ktqkjx8yl'
#
#TF_USA='wf1n44er0cd6c33ms0x4a9k75lq0xq4uxw3th5dap'
#TF_CAN='wf1hydfahkz2e78c9c429jhh33x39p5x2umas47d4'
#TF_USER1='wf19vgaytzeut4apyhv8ykp5azwf4pghe7thr7n22'
#TF_USER2='wf1jptxe988ycf8zank8cjkgsd5fmv2muhjkh9xc3'


# Validator key - SoftHSM keys
PUBKEY_1="{\"@type\":\"/cosmos.crypto.ed25519.PubKey\",\"key\":\"8vSqNl18SajeCU8Y7LIM0c3xhZEqWRwKhk6ZtVRXoQA=\"}" #Slot Token 0/tmkms/ed25519-1/1

# Validator key - FX keys
#PUBKEY_1="{\"@type\":\"/cosmos.crypto.ed25519.PubKey\",\"key\":\"9fvps1uCAV1vi7aIHQLW+IBbRvrEwRAlT1aK+DtsCU4=\"}" #Slot Token 0/tmkms/ed25519-1/1

echo "retrieve faucet mnemonics ..."
FAUCET_MNEMONIC=$(jq -r '.mnemonic' ./july/seeds/faucet_seed.json)

SILENT=1

redirect() {
  if [ "$SILENT" -eq 1 ]; then
    "$@" > /dev/null 2>&1
  else
    "$@"
  fi
}

# Add dir for chain, exit if error
if ! mkdir -p $CHAINDIR/$CHAINID 2>/dev/null; then
    echo "Failed to create chain folder. Aborting..."
    exit 1
fi

# Build genesis file incl account for passed address
FAUCET_COINS="1000000000000000$DENOM" # 10^15
OWNER_COINS="0$DENOM" # 0
coins="1000000000$DENOM" # 10^9
delegate="1000000000$DENOM" # 10^9
fund="1000000$DENOM" # 10^6

$BINARY --home $CHAINDIR/$CHAINID --chain-id $CHAINID init $CHAINID
sleep 2

echo "***** add faucet key ..."
(echo $FAUCET_MNEMONIC; echo "") | $BINARY keys add faucet --home $CHAINDIR/$CHAINID $KEYRING --interactive --no-backup
FAUCET_ADDR=$($BINARY keys show faucet -a --home $CHAINDIR/$CHAINID $KEYRING)
echo "faucet address: $FAUCET_ADDR"
sleep 1

$BINARY --home $CHAINDIR/$CHAINID $KEYRING keys add validator --output json > $CHAINDIR/$CHAINID/validator_seed.json 2>&1
sleep 1

$BINARY --home $CHAINDIR/$CHAINID $KEYRING add-genesis-account $($BINARY --home $CHAINDIR/$CHAINID keys $KEYRING show faucet -a) $FAUCET_COINS
sleep 1
$BINARY --home $CHAINDIR/$CHAINID $KEYRING add-genesis-account $TF_OWNER $OWNER_COINS
sleep 1
$BINARY --home $CHAINDIR/$CHAINID $KEYRING add-genesis-account $($BINARY --home $CHAINDIR/$CHAINID keys $KEYRING show validator -a) $coins
sleep 1
$BINARY gentx validator $delegate \
  --pubkey "$PUBKEY_1" \
  --home $CHAINDIR/$CHAINID $KEYRING \
  --chain-id $CHAINID
sleep 1
$BINARY --home $CHAINDIR/$CHAINID collect-gentxs
sleep 1

# Check platform
platform='unknown'
unamestr=`uname`
if [ "$unamestr" = 'Linux' ]; then
   platform='linux'
fi

# Set proper defaults and change ports (use a different sed for Mac or Linux)
echo "Change settings in config.toml and genesis.json files..."
sed -i -e 's#"tcp://127.0.0.1:26657"#"tcp://0.0.0.0:'"$RPCPORT"'"#g' $CHAINDIR/$CHAINID/config/config.toml
sed -i -e 's#"tcp://0.0.0.0:26656"#"tcp://0.0.0.0:'"$P2PPORT"'"#g' $CHAINDIR/$CHAINID/config/config.toml
sed -i -e 's#"localhost:6060"#"localhost:'"$P2PPORT"'"#g' $CHAINDIR/$CHAINID/config/config.toml
sed -i -e 's/timeout_commit = "5s"/timeout_commit = "1s"/g' $CHAINDIR/$CHAINID/config/config.toml
sed -i -e 's/timeout_propose = "3s"/timeout_propose = "1s"/g' $CHAINDIR/$CHAINID/config/config.toml
sed -i -e 's/index_all_keys = false/index_all_keys = true/g' $CHAINDIR/$CHAINID/config/config.toml
# validator use external tmkms
sed -i -e 's#priv_validator_laddr = ""#priv_validator_laddr = "tcp://0.0.0.0:'"$VALIDATOR_PORT"'"#g' $CHAINDIR/$CHAINID/config/config.toml
sed -i -e 's!priv_validator_key_file = "config/priv_validator_key.json"!\#priv_validator_key_file = "config/priv_validator_key.json"!g' $CHAINDIR/$CHAINID/config/config.toml
sed -i -e 's!priv_validator_state_file = "data/priv_validator_state.json"!\#priv_validator_state_file = "data/priv_validator_state.json"!g' $CHAINDIR/$CHAINID/config/config.toml

sed -i -e 's/"bond_denom": "stake"/"bond_denom": "'"$DENOM"'"/g' $CHAINDIR/$CHAINID/config/genesis.json
sed -i -e 's/"denom_metadata": \[]/"denom_metadata": [ { "display": "'$TF1_MINTING_DENOM'", "base": "'$TF1_MINTING_BASEDENOM'", "name": "'$TF1_MINTING_DENOM'", "symbol": "'$TF1_MINTING_DENOM'", "denom_units": [ { "denom": "'$TF1_MINTING_DENOM'", "aliases": [ "'$TF1_MINTING_DENOM'", "Dollar" ], "exponent": "2" }, { "denom": "'$TF1_MINTING_BASEDENOM'", "aliases": ["penny"], "exponent": "0" } ] }, { "display": "'$TF2_MINTING_DENOM'", "base": "'$TF2_MINTING_BASEDENOM'", "name": "'$TF2_MINTING_DENOM'", "symbol": "'$TF2_MINTING_DENOM'", "denom_units": [ { "denom": "'$TF2_MINTING_DENOM'", "aliases": [ "'$TF2_MINTING_DENOM'" ], "exponent": "6" }, { "denom": "m'$TF2_MINTING_DENOM'", "aliases": [ "micro'$TF2_MINTING_DENOM'" ], "exponent": "3" }, { "denom": "'$TF2_MINTING_BASEDENOM'", "aliases": null, "exponent": "0" } ] } ]/g' $CHAINDIR/$CHAINID/config/genesis.json
sed -i -e 's/"authority": ""/"authority": "'"$TF_OWNER"'"/g' $CHAINDIR/$CHAINID/config/genesis.json

echo "Use tempGen to change settings in genesis.json ..."
TMPGEN=tempGen.json
touch $TMPGEN && jq '.app_state.tokenfactory.owner.address = "'$TF_OWNER'"' $CHAINDIR/$CHAINID/config/genesis.json > $TMPGEN && mv $TMPGEN $CHAINDIR/$CHAINID/config/genesis.json
touch $TMPGEN && jq '.app_state.tokenfactory.mintingDenom.denom = "'$TF1_MINTING_BASEDENOM'"' $CHAINDIR/$CHAINID/config/genesis.json > $TMPGEN && mv $TMPGEN $CHAINDIR/$CHAINID/config/genesis.json
touch $TMPGEN && jq '.app_state.tokenfactory.paused.paused = false' $CHAINDIR/$CHAINID/config/genesis.json > $TMPGEN && mv $TMPGEN $CHAINDIR/$CHAINID/config/genesis.json

touch $TMPGEN && jq '.app_state."fiat-tokenfactory".owner.address = "'$TF_OWNER'"' $CHAINDIR/$CHAINID/config/genesis.json > $TMPGEN && mv $TMPGEN $CHAINDIR/$CHAINID/config/genesis.json
touch $TMPGEN && jq '.app_state."fiat-tokenfactory".mintingDenom.denom = "'$TF2_MINTING_BASEDENOM'"' $CHAINDIR/$CHAINID/config/genesis.json > $TMPGEN && mv $TMPGEN $CHAINDIR/$CHAINID/config/genesis.json
touch $TMPGEN && jq '.app_state."fiat-tokenfactory".paused.paused = false' $CHAINDIR/$CHAINID/config/genesis.json > $TMPGEN && mv $TMPGEN $CHAINDIR/$CHAINID/config/genesis.json

echo "Start chain ..."
# Start
$BINARY --home $CHAINDIR/$CHAINID start --pruning=nothing --grpc-web.enable=false --grpc.address="0.0.0.0:$GRPCPORT" > $CHAINDIR/$CHAINID.log 2>&1 &
sleep 4

echo "Fund accounts with gas tokens ..."
# Fund accounts with gas tokens
$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx bank send faucet $TF_OWNER $fund -y
sleep 2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx bank send faucet $TF_MASTERMINTER $fund -y
sleep 2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx bank send faucet $TF_MINTERCONTROLLER $fund -y
sleep 2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx bank send faucet $TF_MINTER $fund -y
sleep 2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx bank send faucet $TF_BLACKLISTER $fund -y
sleep 2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx bank send faucet $TF_PAUSER $fund -y
sleep 2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx bank send faucet $TF_USA $fund -y
sleep 2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx bank send faucet $TF_CAN $fund -y
sleep 2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx bank send faucet $TF_USER1 $fund -y
sleep 2
$BINARY --home $CHAINDIR/$CHAINID $KEYRING tx bank send faucet $TF_USER2 $fund -y
sleep 2


# tfd --home ./play_wallet_tmkms_sh/tokenfactory-1 start --pruning=nothing --grpc-web.enable=false --grpc.address="0.0.0.0:9090" --trace --log_level=trace
