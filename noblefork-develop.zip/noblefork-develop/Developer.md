# Developer notes
This repo is intended to be a private fork of https://github.com/noble-assets/noble.git.  
We need to be able to fetch future changes in the original repo via upstream.

## See [exmples](./scripts.md) for scripts to build, test, and deploy, including both native and cosmwasm contracts.

## upstream
```bash
git remote add upstream https://github.com/noble-assets/noble.git
git remote set-url --push upstream DISABLE
git remote -v
# should show something like this:
origin  https://github.com/wfblockchain/noblefork.git (fetch)
origin  https://github.com/wfblockchain/noblefork.git (push)
upstream        https://github.com/noble-assets/noble.git (fetch)
upstream        DISABLE (push)

# We can pull changes from the original repo like this:
git fetch upstream
# TBD: git rebase upstream/main
# resolve any conflicts
# Review the upsteam PRs and merge appropriately or manually update the code
```

## submodule
It may be made a submodule of [coreblock-chains](https://github.com/wfblockchain/coreblock-chains.git).  

## tools
> - gex is a neat tool for visualizing validator  
go install github.com/cosmos/gex@latest  
gex -p port