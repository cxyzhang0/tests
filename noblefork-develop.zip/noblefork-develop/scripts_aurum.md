## scripts for aurum contract

```shell
source ./chains.env

# to get participant's address: 
tfd keys list $NODE_HOME $KEYRING

## upload wasm code and get $CODE_ID: two steps
STORE=$(tfd tx wasm store ./cw-contracts/contracts/aurum/target/wasm32-unknown-unknown/release/aurum.wasm --from $VALIDATOR $TXFLAG $KEYRING $NODE_HOME -y -b sync --output json)
echo "STORE: $STORE"

TX_HASH=$(echo $STORE | jq -r '.txhash')
echo "TX_HASH: $TX_HASH"

sleep 5

TX=$(tfd q tx $TX_HASH $NODE_CHAIN --output json)
echo "TX: $TX"

# Extract the code_id using jq
CODE_ID=$(echo $TX | jq -r '.events[] | select(.type == "store_code").attributes[] | select(.key == "code_id").value')
echo "CODE_ID: $CODE_ID"
# 2


STORE=$(tfd tx wasm store ./cw-contracts/contracts/tokenfactory/target/wasm32-unknown-unknown/release/tokenfactory.wasm --from $VALIDATOR $TXFLAG $KEYRING $NODE_HOME -y -b sync --output json)
echo "STORE: $STORE"

TX_HASH=$(echo $STORE | jq -r '.txhash')
echo "TX_HASH: $TX_HASH"

sleep 5

TX=$(tfd q tx $TX_HASH $NODE_CHAIN --output json)
echo "TX: $TX"

# Extract the code_id using jq
CODE_ID=$(echo $TX | jq -r '.events[] | select(.type == "store_code").attributes[] | select(.key == "code_id").value')
echo "CODE_ID: $CODE_ID"

TF_ADDRESS=wf1j5ndlusnf3wwuqwngpxh3act0k9xgad5ac2wzw

## instantiate and get CONTRACT_ADDRESS: two steps
## for tokenfactory as INIt is different
TF_ADDRESS=wf14hj2tavq8fpesdwxxcu44rty3hh90vhujrvcmstl4zr3txmfvw9s2s4a5q && \
INIT=$(jq -n \
    --arg tf_address "$TF_ADDRESS" \
    --argjson is_tf true \
    '{ tf_address: $tf_address, is_tf: $is_tf }') && \
echo $INIT && \
RES=$(tfd tx wasm instantiate $CODE_ID "$INIT" --from tf1_owner --label "cw20_base" --no-admin $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
sleep 5 && \
CONTRACT_ADDRESS2=$(tfd query wasm list-contract-by-code $CODE_ID $NODE_CHAIN --output json | jq -r '.contracts[-1]') && \
echo $CONTRACT_ADDRESS2

## for aurum as INIt is different
TF_ADDRESS=wf14hj2tavq8fpesdwxxcu44rty3hh90vhujrvcmstl4zr3txmfvw9s2s4a5q && \
INIT=$(jq -n --arg tf_address $TF_ADDRESS '{ "tf_address": $tf_address }') && \
echo $INIT && \
RES=$(tfd tx wasm instantiate $CODE_ID "$INIT" --from tf1_owner --label "cw20_base" --no-admin $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
sleep 5 && \
CONTRACT_ADDRESS=$(tfd query wasm list-contract-by-code $CODE_ID $NODE_CHAIN --output json | jq -r '.contracts[-1]') && \
echo $CONTRACT_ADDRESS

# wf1nc5tatafv6eyq7llkr2gv50ff9e22mnf70qgjlv737ktmt4eswrqx9slkx


# Define the MemberState variables
ID="CN=PartyC, OU=, O=PartyC, L=Dallas, C=US"
ADDR=$MINTER

# Construct the JSON payload
JSON=$(jq -n --arg id "$ID" --arg addr "$ADDR" \
    '{ 
        "update_member": { 
            "req": { 
                "id": $id, 
                "addr": $addr, 
                "pubkey": "", 
                "grpc": "" 
            } 
        } 
    }') && \
echo $JSON && \

# Execute the transaction
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from $MINTER $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq



## mint/fund
#TRACKING_ID="aac39993-9dbb-416e-9107-7834eeaf498e" && \
TRACKING_ID=$(uuidgen) && \
DT=$(date -u +"%Y-%m-%dT%H:%M:%S.%1Z") && \
DATE=$(date -u +"%Y-%m-%d")


X500_ISSUER=$(jq -n '{ "common_name": "PartyC", "organization_unit": "", "organization": "PartyC", "locality": "Dallas", "state": "TX", "country": "US" }') && \
X500_BRANCH=$(jq -n '{ "common_name": "PartyA", "organization_unit": "", "organization": "PartyA", "locality": "Dallas", "state": "TX", "country": "US" }')

REQ=$(jq -n \
    --arg tracking_id "$TRACKING_ID" \
    --arg amount "100" \
    --arg currency "USD" \
    --argjson originating_party "$X500_ISSUER" \
    --argjson beneficiary_party "$X500_BRANCH" \
    --arg message_type "MT202" \
    --arg payment_type "Funding" \
    --arg dt "$DT" \
    --arg date "$DATE" \
    '{
        "originating_party": $originating_party,
        "beneficiary_party": $beneficiary_party,
        "amount": $amount,
        "currency": $currency,
        "message_type": $message_type,
        "payment_type": $payment_type,
        "payment_instruction": "MT202 blob",
        "tracking_id": $tracking_id,
        "send_business_date": $date,
        "request_date_time": $dt,
        "custom1": "custom1",
        "custom2": "custom2",
        "custom3": "custom3",
        "custom4": "custom4",
        "custom5": "custom5",
        "custom6": "custom6"
    }')

    JSON=$(jq -n --argjson req "$REQ" --arg beneficiary "$USER" \
    '{
        "fund": {
            "req": $req,
            "beneficiary": $beneficiary
        }
    }')

RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from $MINTER --amount 100stake $NODE_HOME $KEYRING $TXFLAG -y --output json)

echo $RES | jq





## payment
TRACKING_ID=$(uuidgen) && \
DT=$(date -u +"%Y-%m-%dT%H:%M:%S.%1Z") && \
DATE=$(date -u +"%Y-%m-%d") && \
X500_A=$(jq -n '{ "common_name": "PartyA", "organization_unit": "", "organization": "PartyA", "locality": "Dallas", "state": "TX", "country": "US" }') && \
X500_B=$(jq -n '{ "common_name": "PartyB", "organization_unit": "", "organization": "PartyB", "locality": "Dallas", "state": "TX", "country": "US" }') && \
REQ=$(jq -n \
    --arg tracking_id "$TRACKING_ID" \
    --arg amount "5" \
    --arg currency "ustake" \
    --argjson originating_party "$X500_A" \
    --argjson beneficiary_party "$X500_B" \
    --arg message_type "MT103" \
    --arg payment_type "Payment" \
    --arg dt "$DT" \
    --arg date "$DATE" \
    '{ 
        "originating_party": $originating_party, 
        "beneficiary_party": $beneficiary_party, 
        "amount": ($amount | tonumber), 
        "currency": $currency, 
        "message_type": $message_type, 
        "payment_type": $payment_type, 
        "payment_instruction": "MT103 blob", 
        "tracking_id": $tracking_id,
        "send_business_date": $date, 
        "request_date_time": $dt,
        "custom1": "custom1", 
        "custom2": "custom2", 
        "custom3": "custom3", 
        "custom4": "custom4", 
        "custom5": "custom5", 
        "custom6": "custom6" 
    }') && \
JSON=$(jq -n \
    --argjson req "$REQ" \
    --arg beneficiary "$USER2" \
    '{ "pay": { "req": $req, "beneficiary": $beneficiary } }') && \
echo $JSON && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from user --amount 5ustake $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq


## defund
TRACKING_ID=$(uuidgen) && \
DT=$(date -u +"%Y-%m-%dT%H:%M:%S.%1Z") && \
DATE=$(date -u +"%Y-%m-%d") && \
X500_A=$(jq -n '{ "common_name": "PartyA", "organization_unit": "", "organization": "PartyA", "locality": "Dallas", "state": "TX", "country": "US" }') && \
X500_B=$(jq -n '{ "common_name": "PartyC", "organization_unit": "", "organization": "PartyC", "locality": "Dallas", "state": "TX", "country": "US" }') && \
REQ=$(jq -n --arg tracking_id $TRACKING_ID --arg amount 10 --arg currency "uwfusd" --argjson originating_party $X500_A --argjson beneficiary_party $X500_B \
--arg message_type "MT202" --arg payment_type "Defunding" \
--arg dt $DT --arg date $DATE \
'{ "originating_party": $originating_party, "beneficiary_party": $beneficiary_party, "amount": $amount | tonumber, "currency": $currency, 
"message_type": $message_type, "payment_type": $payment_type, "payment_instruction": "MT103 blob", "tracking_id": $tracking_id,
"send_business_date": $date, "request_date_time": $dt,
"custom1": "custom1", "custom2": "custom2", "custom3": "custom3", "custom4": "custom4", "custom5": "custom5", "custom6": "custom6" } ') && \
JSON=$(jq -n --argjson req "$REQ" --arg beneficiary $MINTER '{ "defund": { "req": $req, "beneficiary": $beneficiary } }') && \
echo $JSON && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from user --amount 10uwfusd $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

## query
# Config {}
JSON=$(jq -n '{ config: {} }') && \
echo $JSON && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

# PaymentState { tracking_id }
JSON=$(jq -n --arg tracking_id $TRACKING_ID '{ payment_state: { "tracking_id": $tracking_id } }') && \
echo $JSON && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

 

```