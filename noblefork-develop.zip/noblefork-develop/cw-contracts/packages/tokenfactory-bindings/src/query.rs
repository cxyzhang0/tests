use cosmwasm_schema::{cw_serde, QueryResponses};
use cosmwasm_std::CustomQuery;
// use cosmwasm_std::{DenomMetadataResponse, AllDenomMetadataResponse};

#[cw_serde]
pub enum FactoryQuery {
    Tf(TokenfactoryQuery),
    Ftf(TokenfactoryQuery),
    /*
    We use BankQuery as stop-gap solution until we upgrade wasmd (wasmvm).
    Our current wasmvm 1.2.1 BankQuery does not have denom metadata queries.
    v1.3.0+ will have them.
     */
    Bank(BankQuery),
    Feegrant(FeegrantQuery),
}
#[cw_serde]
#[derive(QueryResponses)]
pub enum TokenfactoryQuery {
    #[returns(ParamsResponse)]
    Params {},

    #[returns(OwnerResponse)]
    Owner {},

    #[returns(MasterMinterResponse)]
    MasterMinter {},

    #[returns(MinterControllerResponse)]
    MinterController { address: String },

    #[returns(AllMinterControllersResponse)]
    AllMinterControllers {},

    #[returns(MintingDenomResponse)]
    MintingDenom {},

    #[returns(MintersResponse)]
    Minters { address: String },

    #[returns(AllMintersResponse)]
    AllMinters {},

    #[returns(BlacklisterResponse)]
    Blacklister {},

    #[returns(PauserResponse)]
    Pauser {},

    #[returns(BlacklistedResponse)]
    Blacklisted { address: String },

    #[returns(AllBlacklistedResponse)]
    AllBlacklisted {},

    #[returns(PausedResponse)]
    Paused {},
}

#[cw_serde]
#[derive(QueryResponses)]
pub enum BankQuery {
    // denom is the base denom
    #[returns(DenomMetadataResponse)]
    DenomMetadata { denom: String },

    #[returns(AllDenomMetadataResponse)]
    AllDenomMetadata {},

    #[returns(FindDenomMetadataResponse)]
    FindDenomMetadata { base_denom: String, denom: String },

    #[returns(FindDenomMetadataResponse)]
    // denom is any denom, not just base denom
    FindMetadataForDenom { denom: String },
}

#[cw_serde]
#[derive(QueryResponses)]
pub enum FeegrantQuery {
    #[returns(FeeBasicAllowanceResponse)]
    FeeBasicAllowance { granter: String, grantee: String },
}
/*
#[cw_serde]
#[derive(QueryResponses)]
pub enum FiatTokenfactoryQuery {
    #[returns(ParamsResponse)]
    Params {},

    #[returns(OwnerResponse)]
    Owner {},

    #[returns(MasterMinterResponse)]
    MasterMinter {},

    #[returns(MinterControllerResponse)]
    MinterController { address: String },

    #[returns(AllMinterControllersResponse)]
    AllMinterControllers {},

    #[returns(MintingDenomResponse)]
    MintingDenom {},

    #[returns(MintersResponse)]
    Minters { address: String },

    #[returns(AllMintersResponse)]
    AllMinters {},

    #[returns(BlacklisterResponse)]
    Blacklister {},

    #[returns(PauserResponse)]
    Pauser {},

    #[returns(BlacklistedResponse)]
    Blacklisted { address: String },

    #[returns(AllBlacklistedResponse)]
    AllBlacklisted {},

    #[returns(PausedResponse)]
    Paused {},
}
*/
impl CustomQuery for FactoryQuery {}
impl cosmwasm_std::CustomMsg for FactoryQuery {}

// TODO: Are the following two impl for TokenfactoryQuery necessary?
//  No such impl for BankQuery and FeegrantQuery.
impl CustomQuery for TokenfactoryQuery {}
impl cosmwasm_std::CustomMsg for TokenfactoryQuery {}

impl CustomQuery for BankQuery {}
impl cosmwasm_std::CustomMsg for BankQuery {}

impl CustomQuery for FeegrantQuery {}
impl cosmwasm_std::CustomMsg for FeegrantQuery {}

// impl CustomQuery for FiatTokenfactoryQuery {}
// impl cosmwasm_std::CustomMsg for FiatTokenfactoryQuery {}
#[cw_serde]
pub struct ParamsResponse {
    pub params: Option<String>,
}

#[cw_serde]
pub struct OwnerResponse {
    pub address: String,
}
#[cw_serde]
pub struct MasterMinterResponse {
    pub address: String,
}
#[cw_serde]
pub struct MinterControllerResponse {
    pub minter: String,
    pub controller: String,
}
#[cw_serde]
pub struct AllMinterControllersResponse {
    pub minter_controllers: Vec<MinterControllerResponse>,
}

#[cw_serde]
pub struct MintingDenomResponse {
    pub denom: String,
}

#[cw_serde]
pub struct MintersResponse {
    pub address: String,
    pub allowance_denom: String,
    pub allowance_value: u64,
}
#[cw_serde]
pub struct AllMintersResponse {
    pub minters: Vec<MintersResponse>,
}
#[cw_serde]
pub struct BlacklisterResponse {
    pub address: String,
}
#[cw_serde]
pub struct PauserResponse {
    pub address: String,
}
#[cw_serde]
pub struct BlacklistedResponse {
    pub address: String,
}
#[cw_serde]
pub struct AllBlacklistedResponse {
    pub blacklisted: Vec<BlacklistedResponse>,
}
#[cw_serde]
pub struct PausedResponse {
    pub paused: bool,
}

/*
DenomMetadataResponse and AllDenomMetadataResponse, and DenomMetadata and DenomUnit
are based on cosmwasm_std::{DenomMetadataResponse, AllDenomMetadataResponse}.
We make these changes to be consistent with the wasm bindings:
no pagination
remove uri and uri_hash because they are not used in the wasm bindings.
also use cw_serde instead.
 */
#[cw_serde]
pub struct DenomMetadataResponse {
    pub metadata: DenomMetadata,
}

#[cw_serde]
pub struct AllDenomMetadataResponse {
    pub metadatas: Vec<DenomMetadata>,
}

#[cw_serde]
pub struct FindDenomMetadataResponse {
    pub description: String,
    pub base: String,
    pub display: String,
    pub name: String,
    pub symbol: String,
    pub denom: String,
    pub exponent: u32,
    pub aliases: Vec<String>,
}

#[cw_serde]
pub struct DenomMetadata {
    pub description: String,
    pub denom_units: Vec<DenomUnit>,
    pub base: String,
    pub display: String,
    pub name: String,
    pub symbol: String,
    // pub uri: String,
    // pub uri_hash: String,
}
#[cw_serde]
pub struct DenomUnit {
    pub denom: String,
    pub exponent: u32,
    pub aliases: Vec<String>,
}

#[cw_serde]
pub struct FeeBasicAllowanceResponse {
    pub allowance: FeeBasicGrant,
}

#[cw_serde]
pub struct FeeBasicGrant {
    pub granter: String,
    pub grantee: String,
    pub allowance_denom: String,
    pub allowance_value: u64,
    pub expiration: String,
}
