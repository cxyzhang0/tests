use crate::query::{
    AllBlacklistedResponse, AllDenomMetadataResponse, AllMinterControllersResponse,
    AllMintersResponse, BankQuery, BlacklistedResponse, BlacklisterResponse, DenomMetadataResponse,
    FactoryQuery, FeeBasicAllowanceResponse, FeegrantQuery, FindDenomMetadataResponse,
    MasterMinterResponse, MinterControllerResponse, MintersResponse, MintingDenomResponse,
    OwnerResponse, ParamsResponse, PausedResponse, PauserResponse, TokenfactoryQuery,
};
use cosmwasm_std::{QuerierWrapper, StdResult};

/// This query wrapper pattern eases the use of custom query types.
pub struct FQuerier<'a> {
    querier: &'a QuerierWrapper<'a, FactoryQuery>,
}

impl<'a> FQuerier<'a> {
    pub fn new(querier: &'a QuerierWrapper<'a, FactoryQuery>) -> Self {
        FQuerier { querier }
    }

    pub fn params(&self, is_tf: bool) -> StdResult<ParamsResponse> {
        let q = if is_tf {
            let q = TokenfactoryQuery::Params {};
            FactoryQuery::Tf(q)
        } else {
            let q = TokenfactoryQuery::Params {};
            FactoryQuery::Ftf(q)
        };
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn owner(&self, is_tf: bool) -> StdResult<OwnerResponse> {
        let q = if is_tf {
            FactoryQuery::Tf(TokenfactoryQuery::Owner {})
        } else {
            FactoryQuery::Ftf(TokenfactoryQuery::Owner {})
        };
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn master_minter(&self, is_tf: bool) -> StdResult<MasterMinterResponse> {
        let q = if is_tf {
            FactoryQuery::Tf(TokenfactoryQuery::MasterMinter {})
        } else {
            FactoryQuery::Ftf(TokenfactoryQuery::MasterMinter {})
        };
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn minter_controller(
        &self,
        address: String,
        is_tf: bool,
    ) -> StdResult<MinterControllerResponse> {
        let q = if is_tf {
            FactoryQuery::Tf(TokenfactoryQuery::MinterController { address })
        } else {
            FactoryQuery::Ftf(TokenfactoryQuery::MinterController { address })
        };
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn all_minter_controllers(&self, is_tf: bool) -> StdResult<AllMinterControllersResponse> {
        let q = if is_tf {
            FactoryQuery::Tf(TokenfactoryQuery::AllMinterControllers {})
        } else {
            FactoryQuery::Ftf(TokenfactoryQuery::AllMinterControllers {})
        };
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn minting_denom(&self, is_tf: bool) -> StdResult<MintingDenomResponse> {
        let q = if is_tf {
            FactoryQuery::Tf(TokenfactoryQuery::MintingDenom {})
        } else {
            FactoryQuery::Ftf(TokenfactoryQuery::MintingDenom {})
        };
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn minters(&self, address: String, is_tf: bool) -> StdResult<MintersResponse> {
        let q = if is_tf {
            FactoryQuery::Tf(TokenfactoryQuery::Minters { address })
        } else {
            FactoryQuery::Ftf(TokenfactoryQuery::Minters { address })
        };
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn all_minters(&self, is_tf: bool) -> StdResult<AllMintersResponse> {
        let q = if is_tf {
            FactoryQuery::Tf(TokenfactoryQuery::AllMinters {})
        } else {
            FactoryQuery::Ftf(TokenfactoryQuery::AllMinters {})
        };
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn blacklister(&self, is_tf: bool) -> StdResult<BlacklisterResponse> {
        let q = if is_tf {
            FactoryQuery::Tf(TokenfactoryQuery::Blacklister {})
        } else {
            FactoryQuery::Ftf(TokenfactoryQuery::Blacklister {})
        };
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn pauser(&self, is_tf: bool) -> StdResult<PauserResponse> {
        let q = if is_tf {
            FactoryQuery::Tf(TokenfactoryQuery::Pauser {})
        } else {
            FactoryQuery::Ftf(TokenfactoryQuery::Pauser {})
        };
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn blacklisted(&self, address: String, is_tf: bool) -> StdResult<BlacklistedResponse> {
        let q = if is_tf {
            FactoryQuery::Tf(TokenfactoryQuery::Blacklisted { address })
        } else {
            FactoryQuery::Ftf(TokenfactoryQuery::Blacklisted { address })
        };
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn all_blacklisted(&self, is_tf: bool) -> StdResult<AllBlacklistedResponse> {
        let q = if is_tf {
            FactoryQuery::Tf(TokenfactoryQuery::AllBlacklisted {})
        } else {
            FactoryQuery::Ftf(TokenfactoryQuery::AllBlacklisted {})
        };
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn paused(&self, is_tf: bool) -> StdResult<PausedResponse> {
        let q = if is_tf {
            FactoryQuery::Tf(TokenfactoryQuery::Paused {})
        } else {
            FactoryQuery::Ftf(TokenfactoryQuery::Paused {})
        };
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn denom_metadata(&self, denom: String) -> StdResult<DenomMetadataResponse> {
        let q = FactoryQuery::Bank(BankQuery::DenomMetadata { denom });
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn all_denom_metadata(&self) -> StdResult<AllDenomMetadataResponse> {
        let q = FactoryQuery::Bank(BankQuery::AllDenomMetadata {});
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn find_denom_metadata(
        &self,
        base_denom: String,
        denom: String,
    ) -> StdResult<FindDenomMetadataResponse> {
        let q = FactoryQuery::Bank(BankQuery::FindDenomMetadata { base_denom, denom });
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn find_metadata_for_denom(&self, denom: String) -> StdResult<FindDenomMetadataResponse> {
        let q = FactoryQuery::Bank(BankQuery::FindMetadataForDenom { denom });
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn fee_basic_allowance(
        &self,
        granter: String,
        grantee: String,
    ) -> StdResult<FeeBasicAllowanceResponse> {
        let q = FactoryQuery::Feegrant(FeegrantQuery::FeeBasicAllowance { granter, grantee });
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }
}
