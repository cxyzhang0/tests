use cosmwasm_schema::cw_serde;
use cosmwasm_std::{CosmosMsg, CustomMsg};

#[cw_serde]
pub enum FactoryMsg {
    Tf(TokenfactoryMsg),
    Ftf(TokenfactoryMsg),
    Feegrant(FeegrantMsg),
}
#[cw_serde]
pub enum TokenfactoryMsg {
    UpdateMasterMinter {
        signer: String,
        address: String,
    },
    ConfigureMinterController {
        signer: String,
        controller: String,
        minter: String,
    },
    RemoveMinterController {
        signer: String,
        controller: String,
    },
    ConfigureMinter {
        signer: String,
        address: String,
        allowance_denom: String,
        allowance_value: u64,
    },
    RemoveMinter {
        signer: String,
        address: String,
    },
    UpdateBlacklister {
        signer: String,
        address: String,
    },
    Blacklist {
        signer: String,
        address: String,
    },
    Unblacklist {
        signer: String,
        address: String,
    },
    UpdatePauser {
        signer: String,
        address: String,
    },
    Pause {
        signer: String,
    },
    Unpause {
        signer: String,
    },
    Mint {
        signer: String,
        address: String,
        denom: String,
        value: u64,
    },
    Burn {
        signer: String,
        denom: String,
        value: u64,
    },
}

#[cw_serde]
pub enum FeegrantMsg {
    GrantFeeBasicAllowance {
        signer: String,
        granter: String,
        grantee: String,
        allowance_denom: String,
        allowance_value: u64,
        hours_to_expire: u64,
    },
    RevokeFeeAllowance {
        signer: String,
        granter: String,
        grantee: String,
    },
}

// From trait implicitly converts from a type into another type,
// whereas Into trait is used to explicitly convert from one type to another.
/*
impl From<TokenfactoryMsg> for CosmosMsg<TokenfactoryMsg> {
    fn from(msg: TokenfactoryMsg) -> Self {
        CosmosMsg::Custom(msg)
    }
}
*/
impl From<FactoryMsg> for CosmosMsg<FactoryMsg> {
    fn from(msg: FactoryMsg) -> Self {
        CosmosMsg::Custom(msg)
    }
}

impl CustomMsg for FactoryMsg {}
impl CustomMsg for TokenfactoryMsg {}

impl CustomMsg for FeegrantMsg {}
// From and Into are in conflict with each other
/*
impl Into<CosmosMsg<TokenfactoryMsg>> for TokenfactoryMsg {
    fn into(self) -> CosmosMsg<TokenfactoryMsg> {
        CosmosMsg::Custom(self)
    }
}
 */
