pub mod msg;

pub mod querier;

pub mod query;

// This is a signal, such that any contract that imports these helpers will only run on the
// blockchain with tokenfactory capability
#[no_mangle]
extern "C" fn requires_tokenfactory() {}
#[no_mangle]
extern "C" fn requires_fiattokenfactory() {}
