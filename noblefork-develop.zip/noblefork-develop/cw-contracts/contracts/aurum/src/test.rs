use cosmwasm_std::{to_json_binary, Binary, ContractResult};

use tokenfactory::msg::QueryMsg;
use tokenfactory::{MintersResponse, OwnerResponse, TokenfactoryQuery};

pub fn custom_query_execute(query: &QueryMsg) -> ContractResult<Binary> {
    match query {
        QueryMsg::Tf(TokenfactoryQuery::Minters { address: _ }) => {
            to_json_binary(&MintersResponse {
                address: "minter".to_string(),
                allowance_denom: "uwfusd".to_string(),
                allowance_value: 1000,
            })
            .into()
        }
        _default => to_json_binary(&OwnerResponse {
            address: "".to_string(),
        })
        .into(),
    }
}
