use cosmwasm_std::{Addr, StdError};
use cw_utils::PaymentError;
use thiserror::Error;

#[derive(Error, Debug, PartialEq)]
pub enum ContractError {
    #[error("{0}")]
    StdError(#[from] StdError),
    #[error("Payment error: {0}")]
    PaymentError(#[from] PaymentError),

    #[error("base denom not found for currency {currency}")]
    BaseDenomNotFound { currency: String },
    #[error("{got} is not the same as paid amount {expected}")]
    InvalidAmount { expected: u128, got: u128 },
    #[error("{got} is not the same as minting denom {expected}")]
    InvalidCurrency { expected: String, got: String },
    #[error("{beneficiary} is not a minter")]
    #[allow(unused)]
    InvalidDefundBeneficiary { beneficiary: Addr },
    #[error("{got} is incorrect message type; expected: {expected}")]
    InvalidMessageType { expected: String, got: String },
    #[error("{got} is incorrect payment type; expected: {expected}")]
    InvalidPaymentType { expected: String, got: String },
    #[error("minting denom not found: this cannot happen")]
    MintingDenomNotFound {},
    #[error("tracking_id {tracking_id} already exists")]
    TrackingIdExists { tracking_id: String },
    #[error("{sender} is not authorized to perform the function")]
    Unauthorized { sender: Addr },
    #[error("{sender} is not an authorized minter")]
    UnauthorizedMinter { sender: Addr },
}
