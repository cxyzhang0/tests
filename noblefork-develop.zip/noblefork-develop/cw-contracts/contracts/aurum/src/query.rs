#[allow(unused_imports)]
use cosmwasm_std::entry_point;
use cosmwasm_std::{to_json_binary, Binary, Deps, Env, StdResult};

use crate::msg::QueryMsg;
use crate::state::{Config, PaymentState, CONFIG, PAYMENT_STATE};

#[cfg_attr(not(feature = "library"), entry_point)]
#[allow(unused)]
pub fn query(deps: Deps, env: Env, msg: QueryMsg) -> StdResult<Binary> {
    match msg {
        QueryMsg::Config {} => to_json_binary(&query::get_config(deps, env)?),
        QueryMsg::PaymentState { tracking_id } => {
            to_json_binary(&query::get_payment_state(deps, env, tracking_id)?)
        }
        QueryMsg::Balance { req } => to_json_binary(&query::get_balance(deps, env, req)?),
        QueryMsg::MemberState { id } => to_json_binary(&query::get_member_state(deps, env, id)?),
        QueryMsg::MemberStates {} => to_json_binary(&query::get_member_states(deps, env)?),
    }
}

#[allow(clippy::module_inception)]
mod query {
    use cosmwasm_std::{Order, StdError};

    use crate::contract::lookup_metadata_for_denom_by_wasm_smart;
    use crate::state::{to_currency_amount, MemberState, MEMBER_STATE};
    use crate::{BalanceRequest, BalanceResponse, MemberStates};

    use super::*;

    pub(super) fn get_config(deps: Deps, _env: Env) -> StdResult<Config> {
        let config = CONFIG.load(deps.storage)?;
        Ok(config)
    }

    pub(super) fn get_payment_state(
        deps: Deps,
        _env: Env,
        tracking_id: String,
    ) -> StdResult<PaymentState> {
        let payment_state = PAYMENT_STATE().load(deps.storage, tracking_id)?;
        Ok(payment_state)
    }

    pub(super) fn get_balance(
        deps: Deps,
        _env: Env,
        req: BalanceRequest,
        // address: String,
    ) -> StdResult<BalanceResponse> {
        let config = CONFIG.load(deps.storage)?;

        let id = req.party.to_owned().unwrap().id();

        let member = MEMBER_STATE.load(deps.storage, id)?;

        let currency = req.currency.to_owned();

        let metadata =
            lookup_metadata_for_denom_by_wasm_smart(&deps, req.currency.to_owned(), &config)
                .map_err(|e| StdError::generic_err(format!("Currency not found: {}", e)))?;

        let coin = deps.querier.query_balance(member.addr, metadata.base)?;
        let balance = to_currency_amount(coin.amount.u128(), metadata.exponent);
        // let balance = Decimal::from_atomics(coin.amount.u128(), 0).unwrap() / Decimal::from_atomics(10u128.pow(exponent as u32), 0).unwrap();

        let mut resp: BalanceResponse = req.into();
        if let Some(ref mut r) = resp.data {
            r.currency = currency;
            r.amount = balance.to_string();
        };

        /*
        // Update resp with balance
        // TODO: is this optimal? can we do in-place update?
        let data = resp.data.map(|mut r| {
            r.currency = balance.denom;
            r.amount = balance.amount.to_string();
            r
        });
        resp.data = data;
        */

        Ok(resp)

        /*
        Ok(crate::types::BalanceResponse {
            // Note: use TransactionStatus instead of BalanceStatus
            //  because the later uses "BalanceStatus_SUCCESS" as_str_name.
            status: TransactionStatus::Success.as_str_name().to_string(),
            message: Some(BalanceError {
                error_code: "".to_string(),
                error_description: "".to_string(),
            }),
            data: Some(CashResponse{
                party: req.party,
                amount: balance.amount.to_string(),
                currency: balance.denom,
                tracking_id: req.tracking_id,
                ref_number: req.ref_number,
                request_date_time: req.request_date_time,
            }),
        })
        */
    }

    pub(super) fn get_member_state(deps: Deps, _env: Env, id: String) -> StdResult<MemberState> {
        let member_state = MEMBER_STATE.load(deps.storage, id)?;
        Ok(member_state)
    }

    pub(super) fn get_member_states(deps: Deps, _env: Env) -> StdResult<MemberStates> {
        let member_states = MEMBER_STATE
            .range(deps.storage, None, None, Order::Ascending)
            .map(|item| item.map(|(_id, state)| state))
            .collect::<StdResult<Vec<MemberState>>>()?;

        Ok(MemberStates {
            members: member_states,
        })
    }
}
