use cosmwasm_schema::cw_serde;
use cosmwasm_std::{Addr, Decimal};
use cw_storage_plus::{Index, IndexList, IndexedMap, Item, Map, MultiIndex};

use super::PaymentResponse;

// Config is created at instantiation.
pub const CONFIG: Item<Config> = Item::new("config");

// tracking_id -> PaymentState
#[allow(non_snake_case)]
pub fn PAYMENT_STATE<'a>() -> IndexedMap<String, PaymentState, PSIndexes<'a>> {
    let indexes = PSIndexes {
        iid: MultiIndex::new(
            |_pk: &[u8], d: &PaymentState| d.resp.id.clone(),
            "payment_state",
            "payment_state_id",
        ),
    };
    IndexedMap::new("payment_state", indexes)
}

pub const MEMBER_STATE: Map<String, MemberState> = Map::new("member_state");

#[cw_serde]
pub struct Config {
    // creator of the contract
    pub owner: Addr,
    // contract address of tokenfactory
    pub tf_address: Addr,
}

#[cw_serde]
pub struct PaymentState {
    pub resp: PaymentResponse,
    pub txhash: Option<String>,
    // pub from_addr: Addr,
    // pub to_addr: Addr,
}

pub struct PSIndexes<'a> {
    // TODO: this index is not necessary since id = tracking_id which is pk.
    pub iid: MultiIndex<'a, String, PaymentState, String>,
}

impl<'a> IndexList<PaymentState> for PSIndexes<'a> {
    fn get_indexes(&'_ self) -> Box<dyn Iterator<Item = &'_ dyn Index<PaymentState>> + '_> {
        let v: Vec<&dyn Index<PaymentState>> = vec![&self.iid];
        Box::new(v.into_iter())
    }
}

#[cw_serde]
pub struct MemberState {
    pub id: String,
    pub addr: Addr,
    pub pubkey: String,
    pub grpc: String,
}

// TODO: these two fns may not belong in this state mod.
pub fn to_base_amount(amount: Decimal, exponent: u32) -> u128 {
    (amount * Decimal::from_atomics((10u32).pow(exponent), 0).unwrap())
        .to_uint_floor()
        .u128()
}

pub fn to_currency_amount(amount: u128, exponent: u32) -> Decimal {
    Decimal::from_atomics(amount, 0).unwrap()
        / Decimal::from_atomics(10u128.pow(exponent), 0).unwrap()
}
