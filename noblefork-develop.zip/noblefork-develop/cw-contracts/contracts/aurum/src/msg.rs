use cosmwasm_schema::{cw_serde, QueryResponses};
use cosmwasm_std::Addr;

#[allow(unused_imports)]
use super::{BalanceRequest, BalanceResponse, PaymentRequest};
#[allow(unused_imports)]
use crate::state::{Config, MemberState, PaymentState};

#[cw_serde]
pub struct InstantiateMsg {
    // tokenfactory contract address
    pub tf_address: Addr,
}

#[cw_serde]
pub enum ExecuteMsg {
    UpdateMember {
        req: MemberState,
    },
    Fund {
        req: PaymentRequest,
        // beneficiary: String,
    },
    Pay {
        req: PaymentRequest,
        // beneficiary: String,
    },
    Defund {
        req: PaymentRequest,
        // beneficiary: String,
    },
    ValidateMinterSender {},
    UpdateTxhash {
        tracking_id: String,
        txhash: String,
    },
}

#[cw_serde]
#[derive(QueryResponses)]
#[allow(clippy::large_enum_variant)]
pub enum QueryMsg {
    #[returns(Config)]
    Config {},
    #[returns(PaymentState)]
    PaymentState { tracking_id: String },
    #[returns(BalanceResponse)]
    Balance { req: BalanceRequest },
    #[returns(MemberState)]
    MemberState { id: String },
    #[returns(MemberState)]
    MemberStates {},
}
