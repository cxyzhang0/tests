/// This is identical to the corresponding types generated wfdc2.wallet.v1.rs
/// except that here we use #[cw_serde] instead of all the prost decorations.
/// The reason for the "duplication" is that wasm and prost are incompatible.
/// Note: not all types in wfdc2.wallet.v1.rs are duplicated here, only those necessary.
use cosmwasm_schema::cw_serde;
use cosmwasm_std::{Decimal, StdError, StdResult};
use regex::Regex;

use crate::state::MemberState;

#[cw_serde]
pub struct BalanceRequest {
    pub party: ::core::option::Option<X500Name>,
    pub currency: String,
    pub tracking_id: String,
    pub ref_number: String,
    pub request_date_time: String,
}

#[cw_serde]
pub struct BalanceResponse {
    pub status: String,
    pub message: ::core::option::Option<BalanceError>,
    pub data: ::core::option::Option<CashResponse>,
}

#[cw_serde]
pub struct CashResponse {
    pub party: Option<X500Name>,
    pub amount: String,
    pub currency: String,
    pub tracking_id: String,
    pub ref_number: String,
    pub request_date_time: String,
}

#[cw_serde]
pub struct BalanceError {
    pub error_code: String,
    pub error_description: String,
}

#[cw_serde]
pub enum BalanceStatus {
    Unspecified = 0,
    /// "SUCCESS"
    Success = 1,
    /// "FAILED"
    Failed = 2,
}
impl BalanceStatus {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            BalanceStatus::Unspecified => "BalanceStatus_UNSPECIFIED",
            BalanceStatus::Success => "BalanceStatus_SUCCESS",
            BalanceStatus::Failed => "BalanceStatus_FAILED",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "BalanceStatus_UNSPECIFIED" => Some(Self::Unspecified),
            "BalanceStatus_SUCCESS" => Some(Self::Success),
            "BalanceStatus_FAILED" => Some(Self::Failed),
            _ => None,
        }
    }
}

#[cw_serde]
pub enum MessageType {
    NotSet = 0,
    Mt103 = 1,
    Mt202 = 2,
}
impl MessageType {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            MessageType::NotSet => "MessageType_NotSet",
            MessageType::Mt103 => "MT103",
            MessageType::Mt202 => "MT202",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "MessageType_NotSet" => Some(Self::NotSet),
            "MT103" => Some(Self::Mt103),
            "MT202" => Some(Self::Mt202),
            _ => None,
        }
    }
}

#[cw_serde]
pub enum PaymentType {
    Unknown = 0,
    /// ("Funding")
    Funding = 1,
    /// ("Defunding")
    Defunding = 2,
    /// ("Payment")
    Payment = 3,
}
impl PaymentType {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            PaymentType::Unknown => "PaymentType_Unknown",
            PaymentType::Funding => "Funding",
            PaymentType::Defunding => "Defunding",
            PaymentType::Payment => "Payment",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "PaymentType_Unknown" => Some(Self::Unknown),
            "Funding" => Some(Self::Funding),
            "Defunding" => Some(Self::Defunding),
            "Payment" => Some(Self::Payment),
            _ => None,
        }
    }
}

#[cw_serde]
pub enum PaymentStateStatus {
    NotSet = 0,
    ///
    FundTransferred = 1,
    ///
    Confirmed = 2,
    ///
    Rejected = 3,
    ///
    Defunded = 4,
    ///
    Funded = 5,
}
impl PaymentStateStatus {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            PaymentStateStatus::NotSet => "PaymentStateStatus_NotSet",
            PaymentStateStatus::FundTransferred => "FundTransferred",
            PaymentStateStatus::Confirmed => "Confirmed",
            PaymentStateStatus::Rejected => "Rejected",
            PaymentStateStatus::Defunded => "Defunded",
            PaymentStateStatus::Funded => "Funded",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "PaymentStateStatus_NotSet" => Some(Self::NotSet),
            "FundTransferred" => Some(Self::FundTransferred),
            "Confirmed" => Some(Self::Confirmed),
            "Rejected" => Some(Self::Rejected),
            "Defunded" => Some(Self::Defunded),
            "Funded" => Some(Self::Funded),
            _ => None,
        }
    }
}

#[cw_serde]
pub enum PaymentStatus {
    Unknown = 0,
    /// ("Pending")
    Pending = 1,
    /// ("Success")
    Success = 2,
    /// ("Error")
    Error = 3,
}
impl PaymentStatus {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            PaymentStatus::Unknown => "Unknown",
            PaymentStatus::Pending => "Pending",
            PaymentStatus::Success => "Success",
            PaymentStatus::Error => "Error",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "Unknown" => Some(Self::Unknown),
            "Pending" => Some(Self::Pending),
            "Success" => Some(Self::Success),
            "Error" => Some(Self::Error),
            _ => None,
        }
    }
}

#[cw_serde]
pub enum NotificationType {
    Unspecified = 0,
    Notifysender = 1,
    Transfernotification = 2,
}
impl NotificationType {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            NotificationType::Unspecified => "NotificationType_UNSPECIFIED",
            NotificationType::Notifysender => "NOTIFYSENDER",
            NotificationType::Transfernotification => "TRANSFERNOTIFICATION",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "NotificationType_UNSPECIFIED" => Some(Self::Unspecified),
            "NOTIFYSENDER" => Some(Self::Notifysender),
            "TRANSFERNOTIFICATION" => Some(Self::Transfernotification),
            _ => None,
        }
    }
}

#[cw_serde]
pub enum TransactionStatus {
    Unspecified = 0,
    Success = 1,
    Error = 2,
}
impl TransactionStatus {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            TransactionStatus::Unspecified => "TransactionStatus_UNSPECIFIED",
            TransactionStatus::Success => "SUCCESS",
            TransactionStatus::Error => "ERROR",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "TransactionStatus_UNSPECIFIED" => Some(Self::Unspecified),
            "SUCCESS" => Some(Self::Success),
            "ERROR" => Some(Self::Error),
            _ => None,
        }
    }
}
#[cw_serde]
pub enum ErrorCode {
    Unspecified = 0,
    /// ("100", "Invalid Currency")
    InvalidCurrency = 100,
    /// ("110", "Corda Flow Failed")
    CordaFlowFailed = 110,
    /// ("120", "Funding/Defunding must include Issuer Branch")
    PartiesNotFundingNode = 120,
    /// ("130", "Originating and beneficiary cannot be the same")
    PartiesCannotBeTheSame = 130,
    /// ("140", "Funding node cannot originate payments")
    FundingNodeCannotOriginatePayments = 140,
    /// ("150", "Funding node cannot receive payments")
    FundingNodeCannotReceivePayments = 150,
    /// ("160", "Not sufficient funds")
    NotSufficientFunds = 160,
    /// ("165", "Token count is too low")
    InsufficientNotLockedBalance = 165,
    /// ("170", "Originating party required")
    OriginatingPartyRequired = 170,
    /// ("180", "Data not found")
    DataNotFound = 180,
    /// ("200", "Invalid Party")
    InvalidParty = 200,
}
impl ErrorCode {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            ErrorCode::Unspecified => "ErrorCode_UNSPECIFIED",
            ErrorCode::InvalidCurrency => "INVALID_CURRENCY",
            ErrorCode::CordaFlowFailed => "CORDA_FLOW_FAILED",
            ErrorCode::PartiesNotFundingNode => "PARTIES_NOT_FUNDING_NODE",
            ErrorCode::PartiesCannotBeTheSame => "PARTIES_CANNOT_BE_THE_SAME",
            ErrorCode::FundingNodeCannotOriginatePayments => {
                "FUNDING_NODE_CANNOT_ORIGINATE_PAYMENTS"
            }
            ErrorCode::FundingNodeCannotReceivePayments => "FUNDING_NODE_CANNOT_RECEIVE_PAYMENTS",
            ErrorCode::NotSufficientFunds => "NOT_SUFFICIENT_FUNDS",
            ErrorCode::InsufficientNotLockedBalance => "INSUFFICIENT_NOT_LOCKED_BALANCE",
            ErrorCode::OriginatingPartyRequired => "ORIGINATING_PARTY_REQUIRED",
            ErrorCode::DataNotFound => "DATA_NOT_FOUND",
            ErrorCode::InvalidParty => "INVALID_PARTY",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "ErrorCode_UNSPECIFIED" => Some(Self::Unspecified),
            "INVALID_CURRENCY" => Some(Self::InvalidCurrency),
            "CORDA_FLOW_FAILED" => Some(Self::CordaFlowFailed),
            "PARTIES_NOT_FUNDING_NODE" => Some(Self::PartiesNotFundingNode),
            "PARTIES_CANNOT_BE_THE_SAME" => Some(Self::PartiesCannotBeTheSame),
            "FUNDING_NODE_CANNOT_ORIGINATE_PAYMENTS" => {
                Some(Self::FundingNodeCannotOriginatePayments)
            }
            "FUNDING_NODE_CANNOT_RECEIVE_PAYMENTS" => Some(Self::FundingNodeCannotReceivePayments),
            "NOT_SUFFICIENT_FUNDS" => Some(Self::NotSufficientFunds),
            "INSUFFICIENT_NOT_LOCKED_BALANCE" => Some(Self::InsufficientNotLockedBalance),
            "ORIGINATING_PARTY_REQUIRED" => Some(Self::OriginatingPartyRequired),
            "DATA_NOT_FOUND" => Some(Self::DataNotFound),
            "INVALID_PARTY" => Some(Self::InvalidParty),
            _ => None,
        }
    }
}
#[cw_serde]
pub struct PaymentRequest {
    pub originating_party: Option<X500Name>,
    pub beneficiary_party: Option<X500Name>,
    pub amount: Decimal,
    pub currency: String,
    pub message_type: String,
    pub payment_type: String,
    pub payment_instruction: String,
    pub tracking_id: String,
    pub send_business_date: String,
    pub request_date_time: String,
    pub custom1: String,
    pub custom2: String,
    pub custom3: String,
    pub custom4: String,
    pub custom5: String,
    pub custom6: String,
}

#[cw_serde]
pub struct PaymentResponse {
    pub id: String,
    pub originating_party: Option<X500Name>,
    pub beneficiary_party: Option<X500Name>,
    pub amount: Decimal,
    pub currency: String,
    pub payment_instruction: String,
    pub tracking_id: String,
    pub send_business_date: String,
    pub request_date_time: String,
    pub message_type: String,
    pub payment_type: String,
    pub notification_type: String,
    pub entry_date_time: String,
    pub payment_status: String,
    pub transaction_status: String,
    pub error_code: String,
    pub error_description: String,
    pub custom1: String,
    pub custom2: String,
    pub custom3: String,
    pub custom4: String,
    pub custom5: String,
    pub custom6: String,
}

#[cw_serde]
pub struct X500Name {
    pub common_name: String,
    pub organization_unit: String,
    pub organization: String,
    pub locality: String,
    pub state: String,
    pub country: String,
}

#[cw_serde]
pub struct PaymentStateRequest {
    pub tracking_id: String,
}

#[cw_serde]
pub struct PaymentStateResponse {
    pub resp: ::core::option::Option<PaymentResponse>,
    pub txhash: Option<String>,
}

// NOTE: cw cannot use proto/prost types.
/*
impl From<ProtoX500Name> for X500Name {
    fn from(v: ProtoX500Name) -> Self {
        Self {
            common_name: v.common_name,
            organization_unit: v.organization_unit,
            organization: v.organization,
            locality: v.locality,
            state: v.state,
            country: v.country,
        }
    }
}
*/

/*
impl From<ProtoPaymentRequest> for PaymentRequest{
    fn from(req: ProtoPaymentRequest) -> Self {
        PaymentRequest {
            originating_party: match req.originating_party {
                None => None,
                Some(r) => Some(X500Name::from(r))
            },
            beneficiary_party: match req.beneficiary_party {
                None => None,
                Some(r) => Some(X500Name::from(r))
            },
            amount: req.amount,
            currency: req.currency,
            message_type: req.message_type,
            payment_type: req.payment_type,
            payment_instruction: req.payment_instruction,
            tracking_id: req.tracking_id,
            send_business_date: req.send_business_date,
            request_date_time: req.request_date_time,
            custom1: req.custom1,
            custom2: req.custom2,
            custom3: req.custom3,
            custom4: req.custom4,
            custom5: req.custom5,
            custom6: req.custom6,
        }
    }
}
*/

// The following is not from wfdc2.wallet.v1.rs
/*
impl Into<PaymentResponse> for PaymentRequest {
    fn into(self) -> PaymentResponse {
        PaymentResponse {
            id: self.tracking_id.to_owned(),
            originating_party: self.originating_party,
            beneficiary_party: self.beneficiary_party,
            amount: self.amount,
            currency: self.currency.to_owned(),
            payment_instruction: self.payment_instruction,
            tracking_id: self.tracking_id,
            send_business_date: self.send_business_date,
            request_date_time: self.request_date_time,
            message_type: self.message_type,
            payment_type: self.payment_type,
            // TODO: how to differentiate between Notifysender and Transfernotification?
            notification_type: NotificationType::Unspecified.as_str_name().to_string(),
            entry_date_time: "TBD".to_string(), // : env.block.time.seconds().to_string(),
            payment_status: PaymentStatus::Success.as_str_name().to_string(),
            transaction_status: TransactionStatus::Success.as_str_name().to_string(),
            error_code: "".to_string(),
            error_description: "".to_string(),
            custom1: self.custom1,
            custom2: self.custom2,
            custom3: self.custom3,
            custom4: self.custom4,
            custom5: self.custom5,
            custom6: self.custom6,
        }
    }
}
*/
impl From<PaymentRequest> for PaymentResponse {
    fn from(req: PaymentRequest) -> Self {
        PaymentResponse {
            id: req.tracking_id.to_owned(),
            originating_party: req.originating_party,
            beneficiary_party: req.beneficiary_party,
            amount: req.amount,
            currency: req.currency.to_owned(),
            payment_instruction: req.payment_instruction,
            tracking_id: req.tracking_id,
            send_business_date: req.send_business_date,
            request_date_time: req.request_date_time,
            message_type: req.message_type,
            payment_type: req.payment_type,
            // TODO: how to differentiate between Notifysender and Transfernotification?
            notification_type: NotificationType::Unspecified.as_str_name().to_string(),
            entry_date_time: "TBD".to_string(), // : env.block.time.seconds().to_string(),
            payment_status: PaymentStatus::Success.as_str_name().to_string(),
            transaction_status: TransactionStatus::Success.as_str_name().to_string(),
            error_code: "".to_string(),
            error_description: "".to_string(),
            custom1: req.custom1,
            custom2: req.custom2,
            custom3: req.custom3,
            custom4: req.custom4,
            custom5: req.custom5,
            custom6: req.custom6,
        }
    }
}

impl From<BalanceRequest> for BalanceResponse {
    fn from(resp: BalanceRequest) -> BalanceResponse {
        BalanceResponse {
            // Note: use TransactionStatus instead of BalanceStatus
            //  because the later uses "BalanceStatus_SUCCESS" as_str_name.
            status: TransactionStatus::Success.as_str_name().to_string(),
            message: Some(BalanceError {
                error_code: "".to_string(),
                error_description: "".to_string(),
            }),
            data: Some(CashResponse {
                party: resp.party,
                amount: "TBD".to_string(),
                currency: "TBD".to_string(),
                tracking_id: resp.tracking_id,
                ref_number: resp.ref_number,
                request_date_time: resp.request_date_time,
            }),
        }
    }
}

/*
impl Into<BalanceResponse> for BalanceRequest {
    fn into(self) -> BalanceResponse {
        BalanceResponse {
            // Note: use TransactionStatus instead of BalanceStatus
            //  because the later uses "BalanceStatus_SUCCESS" as_str_name.
            status: TransactionStatus::Success.as_str_name().to_string(),
            message: Some(BalanceError {
                error_code: "".to_string(),
                error_description: "".to_string(),
            }),
            data: Some(CashResponse {
                party: self.party,
                amount: "TBD".to_string(),
                currency: "TBD".to_string(),
                tracking_id: self.tracking_id,
                ref_number: self.ref_number,
                request_date_time: self.request_date_time,
            }),
        }
    }
}
*/
impl X500Name {
    pub fn id(&self) -> String {
        format!(
            "CN={}, OU={}, O={}, L={}, C={}",
            self.common_name,
            self.organization_unit,
            self.organization,
            self.locality,
            // self.state,
            self.country
        )
    }

    pub fn equal(&self, other: &X500Name) -> bool {
        self.id() == other.id()
    }

    pub fn from_id(id: &str, state: &str) -> StdResult<Self> {
        // OU can be empty
        let re = Regex::new(r"CN=.+, OU=.*, O=.+, L=.+, C=.+").unwrap();
        if !re.is_match(id) {
            return Err(StdError::generic_err(format!("Invalid id: {}", id)));
        }
        let parts: Vec<&str> = id.split(',').collect();
        let mut common_name = "";
        let mut organization_unit = "";
        let mut organization = "";
        let mut locality = "";
        let mut country = "";
        for part in parts {
            let part = part.trim();
            let kv: Vec<&str> = part.split('=').collect();
            if kv.len() != 2 {
                continue;
            }
            match kv[0] {
                "CN" => common_name = kv[1],
                "OU" => organization_unit = kv[1],
                "O" => organization = kv[1],
                "L" => locality = kv[1],
                "C" => country = kv[1],
                _ => (),
            }
        }
        Ok(Self {
            common_name: common_name.to_string(),
            organization_unit: organization_unit.to_string(),
            organization: organization.to_string(),
            locality: locality.to_string(),
            state: state.to_string(),
            country: country.to_string(),
        })
    }
}

#[cw_serde]
pub struct MemberStates {
    pub members: Vec<MemberState>,
}
