use std::str::FromStr;

use cosmwasm_std::Decimal;

use crate::state::{to_base_amount, to_currency_amount};
use crate::X500Name;

#[test]
fn test_x500() {
    let x500 = X500Name {
        common_name: "PartyA".to_string(),
        organization_unit: "".to_string(),
        organization: "PartyA".to_string(),
        locality: "Dallas".to_string(),
        state: "".to_string(),
        country: "US".to_string(),
    };
    let id = x500.id();
    let from_idx500 = X500Name::from_id(&id, "").unwrap();
    assert_eq!(x500, from_idx500);
    assert!(x500.equal(&from_idx500));
    println!("id: {}", id);

    let x500 = X500Name {
        common_name: "PartyB".to_string(),
        organization_unit: "".to_string(),
        organization: "PartyB".to_string(),
        locality: "Dallas".to_string(),
        state: "".to_string(),
        country: "US".to_string(),
    };
    let id = x500.id();
    println!("id: {}", id);

    let x500 = X500Name {
        common_name: "PartyC".to_string(),
        organization_unit: "".to_string(),
        organization: "PartyC".to_string(),
        locality: "Dallas".to_string(),
        state: "".to_string(),
        country: "US".to_string(),
    };
    let id = x500.id();
    println!("id: {}", id);
}

#[test]
fn test_decimal_to_string() {
    let decimal = Decimal::from_str("100.12").unwrap();
    let decimal_str = decimal.to_string();
    println!("decimal: {}", decimal_str);
    assert_eq!(decimal_str, "100.12");
}

#[test]
fn test_to_base_amount() {
    let decimal = Decimal::from_str("100.12").unwrap();
    let base_amount = to_base_amount(decimal, 2);
    println!("base_amount: {}", base_amount);
    assert_eq!(base_amount, 10012);
}

#[test]
fn test_to_currency_amount() {
    let base_amount = 10012;
    let exponent = 2;
    let currency_amount = to_currency_amount(base_amount, exponent);
    println!("currency_amount: {}", currency_amount.to_string());
    assert_eq!(currency_amount, Decimal::from_str("100.12").unwrap());
}

/*
#[test]
fn test_utc_now() {
    let now = time::OffsetDateTime::now_utc().to_string();
    println!("now: {:?}", now);
    // now: "2024-03-22 18:51:41.077105 +00:00:00"
}

#[test]
fn test_uuid() {
    let uuid = uuid::Uuid::new_v4().to_string();
    println!("uuid: {}", uuid);
    // uuid: 7fbb4b1e-5d8f-4f1b-97e3-fac7f8f6ba28
    // uuid: aac39993-9dbb-416e-9107-7834eeaf498e
}
*/
