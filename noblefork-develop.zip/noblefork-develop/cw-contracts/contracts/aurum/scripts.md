# scripts for aurum smart contract
## build wasm
```shell
cd aurum
RUSTFLAGS='-C link-arg=-s' cargo wasm -v

# optimize wasm to produce aurum_optimized.wasm and also to support 1.70.0+ build
wasm-opt -Os --signext-lowering ./target/wasm32-unknown-unknown/release/aurum.wasm -o ./target/wasm32-unknown-unknown/release/aurum_optimized.wasm

# validate aurum_optimized.wasm will pass
cosmwasm-check ./target/wasm32-unknown-unknown/release/aurum.wasm --available-capabilities "tokenfactory, fiattokenfactory, iterator, staking, cosmwasm_1_1, cosmwasm_1_2, cosmwasm_1_3" 

# schema
cargo run schema
```

## Deploy on noblefork chain
See https://github.com/wfblockchain/noblefork/blob/main/scripts_aurum.md .