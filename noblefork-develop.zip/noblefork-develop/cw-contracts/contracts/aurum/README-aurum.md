# aurum
this contract implements the functionality of the cordapp aurum flows. it uses the tokenfactory for funding and defunding wallets and the bank MsgSend for payment from one wallet to another. for each of those transactions, we also store the metadata in payment_state.  

## two types of participants
- the issuer/minter wallet
- the branch wallet
both are identity-based wallets with private keys in HSM. future enhancements will use MPC wallets.

## multi-currency support
we support fiat tokens such as USD, CAD, EURO, GBP, JPY, CNY, CHF, etc. 
> problem: the tokenfactory is limited to one minting denom (per chain).  
> question: can one chain have multiple tokenfactories?

## three types of transactions
- funding - the issuer/minter wallet signs the mint msg with metadata. the newly minted tokens are credited to the beneficiary branch wallet.
- payment - the originating branch wallet signs MsgSend with metadata. the tokens are debited from the originating branch wallet and credited to the beneficiary branch wallet.
- defunding - the defunding branch signs MsgSend with metadata. the tokens are debited from the defunding branch wallet and credited to the issuer/minter wallet. then the issuer/minter wallet signs the burn msg with metadata to debit the issuer/minter wallet. 