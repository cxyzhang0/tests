use aurum::msg::{ExecuteMsg, InstantiateMsg};
use aurum::test::custom_query_execute;
use cosmwasm_std::{coins, Coin, ContractResult, Response, SystemResult};
use cosmwasm_vm::internals::check_wasm;
use cosmwasm_vm::testing::{
    execute, instantiate, mock_env, mock_info, mock_instance_options, mock_instance_with_options,
    MockApi, MockInstanceOptions, MockQuerier, MockStorage, MOCK_CONTRACT_ADDR,
};
use cosmwasm_vm::{Backend, Instance, InstanceOptions};
use std::collections::HashSet;
use tokenfactory::msg::QueryMsg;

static WASM: &[u8] =
    include_bytes!("../../../../target/wasm32-unknown-unknown/release/aurum_optimized.wasm");

pub fn mock_dependencies_with_custom_querier(
    contract_balance: &[Coin],
) -> Backend<MockApi, MockStorage, MockQuerier<QueryMsg>> {
    let custom_querier: MockQuerier<QueryMsg> =
        MockQuerier::new(&[(MOCK_CONTRACT_ADDR, contract_balance)])
            .with_custom_handler(|query| SystemResult::Ok(custom_query_execute(query)));

    Backend {
        api: MockApi::default().with_prefix("wf"),
        storage: MockStorage::default(),
        querier: custom_querier,
    }
}

pub fn mock_dependencies_with_custom_querier_and_balances(
    balances: &[(&str, &[Coin])],
) -> Backend<MockApi, MockStorage, MockQuerier<QueryMsg>> {
    let custom_querier: MockQuerier<QueryMsg> = MockQuerier::new(balances)
        .with_custom_handler(|query| SystemResult::Ok(custom_query_execute(query)));

    Backend {
        api: MockApi::default().with_prefix("wf"),
        storage: MockStorage::default(),
        querier: custom_querier,
    }
}

// TODO: check config state
#[test]
fn it_instantiate() {
    let mut ac = HashSet::new();
    ac.insert("tokenfactory".to_string());
    ac.insert("iterator".to_string());
    ac.insert("staking".to_string());

    let mut deps = mock_instance_with_options(
        WASM,
        MockInstanceOptions {
            contract_balance: Some(&[]),
            available_capabilities: ac,
            ..Default::default()
        },
    );

    let msg = InstantiateMsg {
        tf_address: "tokenfactory".to_string(),
    };
    let info = mock_info("owner", &coins(1000, "uwfusd"));

    let resp: Response = instantiate(&mut deps, mock_env(), info, msg).unwrap();

    assert_eq!(0, resp.messages.len());
    assert_eq!(2, resp.attributes.len());
    assert_eq!(
        resp.attributes
            .iter()
            .find(|attr| attr.key == "action")
            .unwrap()
            .value,
        "instantiate"
    );
    assert_eq!(
        resp.attributes
            .iter()
            .find(|attr| attr.key == "tf_address")
            .unwrap()
            .value,
        "tokenfactory"
    );
}

#[test]
fn it_validate_minter_sender() {
    let mut ac = HashSet::new();
    ac.insert("tokenfactory".to_string());
    ac.insert("iterator".to_string());
    ac.insert("staking".to_string());

    check_wasm(WASM, &ac).unwrap();

    let custom = mock_dependencies_with_custom_querier(&[]);
    let (instance_options, memory_limit) = mock_instance_options();
    let mut deps = Instance::from_code(
        WASM,
        custom,
        instance_options as InstanceOptions,
        memory_limit,
    )
    .unwrap();

    // TODO: what should be tf_address?
    let msg = InstantiateMsg {
        tf_address: MOCK_CONTRACT_ADDR.to_string(),
    };
    let info = mock_info("owner", &coins(1000, "uwfusd"));

    let _resp: Response = instantiate(&mut deps, mock_env(), info, msg).unwrap();

    let msg = ExecuteMsg::ValidateMinterSender {};
    let info = mock_info("minter", &[]);
    // let _resp: Response = execute(&mut deps, mock_env(), info, msg).unwrap();
    let resp: ContractResult<Response> = execute(&mut deps, mock_env(), info, msg);
    // TODO: we expect no error here instead.
    assert_eq!(resp.is_err(), true);
}
