#[cfg(not(feature = "library"))]
use cosmwasm_std::entry_point;
use cosmwasm_std::{DepsMut, Env, MessageInfo, Response, StdError, StdResult};
use cw2::set_contract_version;

use tokenfactory_bindings::msg::{FactoryMsg, FeegrantMsg, TokenfactoryMsg};
use tokenfactory_bindings::query::FactoryQuery;

use crate::msg::{ExecuteMsg, FeegrantContractMsg, InstantiateMsg, TokenfactoryContractMsg};
use crate::state::{Config, CONFIG};

const CONTRACT_NAME: &str = "crates.io:tokenfactory-integration";
const CONTRACT_VERSION: &str = env!("CARGO_PKG_VERSION");

#[cfg_attr(not(feature = "library"), entry_point)]
pub fn instantiate(
    deps: DepsMut,
    _env: Env,
    info: MessageInfo,
    msg: InstantiateMsg,
) -> StdResult<Response> {
    set_contract_version(deps.storage, CONTRACT_NAME, CONTRACT_VERSION)?;

    let config = Config {
        owner: info.sender.to_owned(),
        is_tf: msg.is_tf,
    };
    CONFIG.save(deps.storage, &config)?;

    Ok(Response::new()
        .add_attribute("action", "instantiate")
        .add_attribute("owner", info.sender)
        .add_attribute("is_tf", msg.is_tf.to_string()))
}

#[cfg_attr(not(feature = "library"), entry_point)]
pub fn execute(
    deps: DepsMut<FactoryQuery>,
    env: Env,
    info: MessageInfo,
    msg: ExecuteMsg,
) -> Result<Response<FactoryMsg>, StdError> {
    let is_tf = CONFIG.load(deps.storage)?.is_tf;
    match msg {
        ExecuteMsg::Tf(TokenfactoryContractMsg::UpdateMasterMinter { address }) => {
            execute::update_master_minter(info.sender, address, is_tf)
        }
        ExecuteMsg::Tf(TokenfactoryContractMsg::ConfigureMinterController {
            controller,
            minter,
        }) => execute::configure_minter_controller(info.sender, controller, minter, is_tf),
        ExecuteMsg::Tf(TokenfactoryContractMsg::RemoveMinterController { controller }) => {
            execute::remove_minter_controller(info.sender, controller, is_tf)
        }
        ExecuteMsg::Tf(TokenfactoryContractMsg::ConfigureMinter {
            address,
            allowance_denom,
            allowance_value,
        }) => execute::configure_minter(
            info.sender,
            address,
            allowance_denom,
            allowance_value,
            is_tf,
        ),
        ExecuteMsg::Tf(TokenfactoryContractMsg::RemoveMinter { address }) => {
            execute::remove_minter(info.sender, address, is_tf)
        }
        ExecuteMsg::Tf(TokenfactoryContractMsg::UpdateBlacklister { address }) => {
            execute::update_blacklister(info.sender, address, is_tf)
        }
        ExecuteMsg::Tf(TokenfactoryContractMsg::Blacklist { address }) => {
            execute::blacklist(info.sender, address, is_tf)
        }
        ExecuteMsg::Tf(TokenfactoryContractMsg::Unblacklist { address }) => {
            execute::unblacklist(info.sender, address, is_tf)
        }
        ExecuteMsg::Tf(TokenfactoryContractMsg::UpdatePauser { address }) => {
            execute::update_pauser(info.sender, address, is_tf)
        }
        ExecuteMsg::Tf(TokenfactoryContractMsg::Pause {}) => execute::pause(info.sender, is_tf),
        ExecuteMsg::Tf(TokenfactoryContractMsg::Unpause {}) => execute::unpause(info.sender, is_tf),
        ExecuteMsg::Tf(TokenfactoryContractMsg::Mint {
            orig_sender,
            address,
            denom,
            value,
        }) => execute::mint(deps, env, info, orig_sender, address, denom, value, is_tf),
        ExecuteMsg::Tf(TokenfactoryContractMsg::Burn {
            orig_sender,
            denom,
            value,
        }) => execute::burn(deps, env, info, orig_sender, denom, value, is_tf),
        ExecuteMsg::Feegrant(FeegrantContractMsg::GrantFeeBasicAllowance {
            granter,
            grantee,
            allowance_denom,
            allowance_value,
            hours_to_expire,
        }) => execute::grant_fee_basic_allowance(
            deps,
            info.sender,
            granter,
            grantee,
            allowance_denom,
            allowance_value,
            hours_to_expire,
        ),
        ExecuteMsg::Feegrant(FeegrantContractMsg::RevokeFeeAllowance { granter, grantee }) => {
            execute::revoke_fee_allowance(deps, info.sender, granter, grantee)
        }
    }
}

pub mod execute {
    use cosmwasm_std::Addr;

    use tokenfactory_bindings::msg::FactoryMsg;
    use tokenfactory_bindings::query::FactoryQuery;

    use super::*;

    pub(super) fn update_master_minter(
        sender: Addr,
        address: String,
        is_tf: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let msg = if is_tf {
            FactoryMsg::Tf(TokenfactoryMsg::UpdateMasterMinter {
                signer: sender.to_string(),
                address: address.to_owned(),
            })
        } else {
            FactoryMsg::Ftf(TokenfactoryMsg::UpdateMasterMinter {
                signer: sender.to_string(),
                address: address.to_owned(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute("action", "update_master_minter")
            .add_attribute("address", address))
    }

    pub(super) fn configure_minter_controller(
        sender: Addr,
        controller: String,
        minter: String,
        is_tf: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let msg = if is_tf {
            FactoryMsg::Tf(TokenfactoryMsg::ConfigureMinterController {
                signer: sender.to_string(),
                controller: controller.to_owned(),
                minter: minter.to_owned(),
            })
        } else {
            FactoryMsg::Ftf(TokenfactoryMsg::ConfigureMinterController {
                signer: sender.to_string(),
                controller: controller.to_owned(),
                minter: minter.to_owned(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute("action", "configure_minter_controller")
            .add_attribute("controller", controller)
            .add_attribute("minter", minter))
    }

    pub(super) fn remove_minter_controller(
        sender: Addr,
        controller: String,
        is_tf: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let msg = if is_tf {
            FactoryMsg::Tf(TokenfactoryMsg::RemoveMinterController {
                signer: sender.to_string(),
                controller: controller.to_owned(),
            })
        } else {
            FactoryMsg::Ftf(TokenfactoryMsg::RemoveMinterController {
                signer: sender.to_string(),
                controller: controller.to_owned(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute("action", "remove_minter_controller")
            .add_attribute("controller", controller))
    }

    pub(super) fn configure_minter(
        sender: Addr,
        address: String,
        allowance_denom: String,
        allowance_value: u64,
        is_tf: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let msg = if is_tf {
            FactoryMsg::Tf(TokenfactoryMsg::ConfigureMinter {
                signer: sender.to_string(),
                address: address.to_owned(),
                allowance_denom: allowance_denom.to_owned(),
                allowance_value,
            })
        } else {
            FactoryMsg::Ftf(TokenfactoryMsg::ConfigureMinter {
                signer: sender.to_string(),
                address: address.to_owned(),
                allowance_denom: allowance_denom.to_owned(),
                allowance_value,
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute("action", "configure_minter")
            .add_attribute("address", address)
            .add_attribute("allowance_denom", allowance_denom)
            .add_attribute("allowance_value", allowance_value.to_string()))
    }

    pub(super) fn remove_minter(
        sender: Addr,
        address: String,
        is_tf: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let msg = if is_tf {
            FactoryMsg::Tf(TokenfactoryMsg::RemoveMinter {
                signer: sender.to_string(),
                address: address.to_owned(),
            })
        } else {
            FactoryMsg::Ftf(TokenfactoryMsg::RemoveMinter {
                signer: sender.to_string(),
                address: address.to_owned(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute("action", "remove_minter")
            .add_attribute("address", address))
    }

    pub(super) fn update_blacklister(
        sender: Addr,
        address: String,
        is_tf: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let msg = if is_tf {
            FactoryMsg::Tf(TokenfactoryMsg::UpdateBlacklister {
                signer: sender.to_string(),
                address: address.to_owned(),
            })
        } else {
            FactoryMsg::Ftf(TokenfactoryMsg::UpdateBlacklister {
                signer: sender.to_string(),
                address: address.to_owned(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute("action", "update_blacklister")
            .add_attribute("address", address))
    }

    pub(super) fn blacklist(
        sender: Addr,
        address: String,
        is_tf: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let msg = if is_tf {
            FactoryMsg::Tf(TokenfactoryMsg::Blacklist {
                signer: sender.to_string(),
                address: address.to_owned(),
            })
        } else {
            FactoryMsg::Ftf(TokenfactoryMsg::Blacklist {
                signer: sender.to_string(),
                address: address.to_owned(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute("action", "blacklist")
            .add_attribute("address", address))
    }

    pub(super) fn unblacklist(
        sender: Addr,
        address: String,
        is_tf: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let msg = if is_tf {
            FactoryMsg::Tf(TokenfactoryMsg::Unblacklist {
                signer: sender.to_string(),
                address: address.to_owned(),
            })
        } else {
            FactoryMsg::Ftf(TokenfactoryMsg::Unblacklist {
                signer: sender.to_string(),
                address: address.to_owned(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute("action", "unblacklist")
            .add_attribute("address", address))
    }

    pub(super) fn update_pauser(
        sender: Addr,
        address: String,
        is_tf: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let msg = if is_tf {
            FactoryMsg::Tf(TokenfactoryMsg::UpdatePauser {
                signer: sender.to_string(),
                address: address.to_owned(),
            })
        } else {
            FactoryMsg::Ftf(TokenfactoryMsg::UpdatePauser {
                signer: sender.to_string(),
                address: address.to_owned(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute("action", "update_pauser")
            .add_attribute("address", address))
    }

    pub(super) fn pause(sender: Addr, is_tf: bool) -> Result<Response<FactoryMsg>, StdError> {
        let msg = if is_tf {
            FactoryMsg::Tf(TokenfactoryMsg::Pause {
                signer: sender.to_string(),
            })
        } else {
            FactoryMsg::Ftf(TokenfactoryMsg::Pause {
                signer: sender.to_string(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute("action", "pause"))
    }

    pub(super) fn unpause(sender: Addr, is_tf: bool) -> Result<Response<FactoryMsg>, StdError> {
        let msg = if is_tf {
            FactoryMsg::Tf(TokenfactoryMsg::Unpause {
                signer: sender.to_string(),
            })
        } else {
            FactoryMsg::Ftf(TokenfactoryMsg::Unpause {
                signer: sender.to_string(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute("action", "unpause"))
    }

    #[allow(clippy::too_many_arguments)]
    pub(super) fn mint(
        deps: DepsMut<FactoryQuery>,
        _env: Env,
        info: MessageInfo,
        orig_sender: Option<String>,
        address: String,
        denom: String,
        value: u64,
        is_tf: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let sender = get_sender(&deps, info, orig_sender)?;

        deps.api.addr_validate(&address)?;

        let msg = if is_tf {
            FactoryMsg::Tf(TokenfactoryMsg::Mint {
                signer: sender.to_string(),
                address: address.to_owned(),
                denom: denom.to_owned(),
                value,
            })
        } else {
            FactoryMsg::Ftf(TokenfactoryMsg::Mint {
                signer: sender.to_string(),
                address: address.to_owned(),
                denom: denom.to_owned(),
                value,
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute("action", "mint")
            .add_attribute("address", address)
            .add_attribute("denom", denom)
            .add_attribute("value", value.to_string()))
    }

    pub(super) fn burn(
        deps: DepsMut<FactoryQuery>,
        _env: Env,
        info: MessageInfo,
        orig_sender: Option<String>,
        denom: String,
        value: u64,
        is_tf: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let sender = get_sender(&deps, info, orig_sender)?;

        let msg = if is_tf {
            FactoryMsg::Tf(TokenfactoryMsg::Burn {
                signer: sender.to_string(),
                denom: denom.to_owned(),
                value,
            })
        } else {
            FactoryMsg::Ftf(TokenfactoryMsg::Burn {
                signer: sender.to_string(),
                denom: denom.to_owned(),
                value,
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute("action", "burn")
            .add_attribute("denom", denom)
            .add_attribute("value", value.to_string()))
    }

    pub(super) fn grant_fee_basic_allowance(
        _deps: DepsMut<FactoryQuery>,
        sender: Addr,
        granter: String,
        grantee: String,
        allowance_denom: String,
        allowance_value: u64,
        hours_to_expire: u64,
    ) -> Result<Response<FactoryMsg>, StdError> {
        // Ensure sender is granter
        // Note: feegrant module does not validate granter if called by a contract
        if sender.to_string() != granter {
            return Err(StdError::generic_err("granter must be the sender"));
        }

        let msg = FactoryMsg::Feegrant(FeegrantMsg::GrantFeeBasicAllowance {
            signer: sender.to_string(),
            granter: granter.to_owned(),
            grantee: grantee.to_owned(),
            allowance_denom: allowance_denom.to_owned(),
            allowance_value,
            hours_to_expire,
        });

        Ok(Response::new()
            .add_message(msg)
            .add_attribute("action", "grant_fee_basic_allowance")
            .add_attribute("granter", granter)
            .add_attribute("grantee", grantee)
            .add_attribute("allowance_denom", allowance_denom)
            .add_attribute("allowance_value", allowance_value.to_string())
            .add_attribute("hours_to_expire", hours_to_expire.to_string()))
    }

    pub(super) fn revoke_fee_allowance(
        _deps: DepsMut<FactoryQuery>,
        sender: Addr,
        granter: String,
        grantee: String,
    ) -> Result<Response<FactoryMsg>, StdError> {
        // Ensure sender is granter
        // Note: feegrant module does not validate granter if called by a contract
        if sender.to_string() != granter {
            return Err(StdError::generic_err("granter must be the sender"));
        }

        let msg = FactoryMsg::Feegrant(FeegrantMsg::RevokeFeeAllowance {
            signer: sender.to_string(),
            granter: granter.to_owned(),
            grantee: grantee.to_owned(),
        });

        Ok(Response::new()
            .add_message(msg)
            .add_attribute("action", "revoke_fee_allowance")
            .add_attribute("granter", granter)
            .add_attribute("grantee", grantee))
    }

    /// get_sender returns the sender address for tokenfactory.
    /// If the caller of tokenfactory contract is a contract, we give that contract
    /// the option to pass in the original sender address.
    fn get_sender(
        deps: &DepsMut<FactoryQuery>,
        info: MessageInfo,
        orig_sender: Option<String>,
    ) -> Result<Addr, StdError> {
        let sender = if let Some(s) = orig_sender {
            // if the caller of tokenfactory contract is a contract
            if deps.querier.query_wasm_contract_info(&info.sender).is_ok() {
                deps.api.addr_validate(&s)?
            } else {
                info.sender
            }
        } else {
            info.sender
        };
        Ok(sender)
    }
}
