use std::marker::PhantomData;

use cosmwasm_std::testing::{MockApi, MockQuerier, MockStorage, MOCK_CONTRACT_ADDR};
use cosmwasm_std::{to_json_binary, Binary, Coin, ContractResult, OwnedDeps, SystemResult};

use tokenfactory_bindings::query::{MintersResponse, OwnerResponse, TokenfactoryQuery};

use crate::msg::QueryMsg;

pub fn mock_dependencies_with_custom_querier(
    contract_balance: &[Coin],
) -> OwnedDeps<MockStorage, MockApi, MockQuerier<QueryMsg>, QueryMsg> {
    let custom_querier: MockQuerier<QueryMsg> =
        MockQuerier::new(&[(MOCK_CONTRACT_ADDR, contract_balance)])
            .with_custom_handler(|query| SystemResult::Ok(custom_query_execute(query)));

    OwnedDeps {
        storage: MockStorage::default(),
        api: MockApi::default(),
        querier: custom_querier,
        custom_query_type: PhantomData,
    }
}

/// mock query resuls
pub fn custom_query_execute(query: &QueryMsg) -> ContractResult<Binary> {
    match query {
        QueryMsg::Tf(TokenfactoryQuery::Minters { address }) => to_json_binary(&MintersResponse {
            address: address.to_string(),
            allowance_denom: "uwfusd".to_string(),
            allowance_value: 1000,
        })
        .into(),
        _default => to_json_binary(&OwnerResponse {
            address: "".to_string(),
        })
        .into(),
    }
}

#[cfg(test)]
mod tests {
    use cosmwasm_std::{from_json, QuerierWrapper, QueryRequest};

    use super::*;

    #[test]
    fn custom_query_execute_minters() {
        let query = QueryMsg::Minters {
            address: "minter".to_string(),
        };
        let resp = custom_query_execute(&query).unwrap();
        let response: MintersResponse = from_json(&resp).unwrap();
        assert_eq!(response.address, "minter");
        assert_eq!(response.allowance_denom, "uwfusd");
        assert_eq!(response.allowance_value, 1000);
    }

    #[test]
    fn custom_querier() {
        let deps = mock_dependencies_with_custom_querier(&[]);
        let req: QueryRequest<_> = QueryMsg::Minters {
            address: "minter".to_string(),
        }
        .into();

        let wrapper = QuerierWrapper::new(&deps.querier);

        let resp: MintersResponse = wrapper.query(&req).unwrap();
        assert_eq!(resp.address, "minter");
    }
}
