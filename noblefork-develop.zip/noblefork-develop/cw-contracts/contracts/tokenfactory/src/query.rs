use cosmwasm_std::{to_json_binary, Binary, Deps, Env, StdResult};
use tokenfactory_bindings::querier::FQuerier;
use tokenfactory_bindings::query::{BankQuery, FactoryQuery, FeegrantQuery, TokenfactoryQuery};

use crate::msg::QueryMsg;
use crate::state::CONFIG;
#[allow(unused_imports)]
use cosmwasm_std::entry_point;

#[cfg_attr(not(feature = "library"), entry_point)]
pub fn query(deps: Deps<FactoryQuery>, env: Env, msg: QueryMsg) -> StdResult<Binary> {
    let tf_q = FQuerier::new(&deps.querier);
    let is_tf = CONFIG.load(deps.storage)?.is_tf;
    match msg {
        QueryMsg::Tf(tf) => match tf {
            TokenfactoryQuery::Params {} => to_json_binary(&tf_q.params(is_tf)?),
            TokenfactoryQuery::Owner {} => to_json_binary(&tf_q.owner(is_tf)?),
            TokenfactoryQuery::MasterMinter {} => to_json_binary(&tf_q.master_minter(is_tf)?),
            TokenfactoryQuery::MinterController { address } => {
                to_json_binary(&tf_q.minter_controller(address, is_tf)?)
            }
            TokenfactoryQuery::AllMinterControllers {} => {
                to_json_binary(&tf_q.all_minter_controllers(is_tf)?)
            }
            TokenfactoryQuery::MintingDenom {} => to_json_binary(&tf_q.minting_denom(is_tf)?),
            TokenfactoryQuery::Minters { address } => {
                to_json_binary(&tf_q.minters(address, is_tf)?)
            }
            TokenfactoryQuery::AllMinters {} => to_json_binary(&tf_q.all_minters(is_tf)?),
            TokenfactoryQuery::Blacklister {} => to_json_binary(&tf_q.blacklister(is_tf)?),
            TokenfactoryQuery::Pauser {} => to_json_binary(&tf_q.pauser(is_tf)?),
            TokenfactoryQuery::Blacklisted { address } => {
                to_json_binary(&tf_q.blacklisted(address, is_tf)?)
            }
            TokenfactoryQuery::AllBlacklisted {} => to_json_binary(&tf_q.all_blacklisted(is_tf)?),
            TokenfactoryQuery::Paused {} => to_json_binary(&tf_q.paused(is_tf)?),
        },
        QueryMsg::Bank(bank) => match bank {
            BankQuery::DenomMetadata { denom } => to_json_binary(&tf_q.denom_metadata(denom)?),
            BankQuery::AllDenomMetadata {} => to_json_binary(&tf_q.all_denom_metadata()?),
            BankQuery::FindDenomMetadata { base_denom, denom } => {
                to_json_binary(&tf_q.find_denom_metadata(base_denom, denom)?)
            }
            BankQuery::FindMetadataForDenom { denom } => {
                to_json_binary(&tf_q.find_metadata_for_denom(denom)?)
            }
        },
        QueryMsg::Feegrant(feegrant) => match feegrant {
            FeegrantQuery::FeeBasicAllowance { granter, grantee } => {
                to_json_binary(&tf_q.fee_basic_allowance(granter, grantee)?)
            }
        },
        /*
        QueryMsg::Params {} => to_json_binary(&tf_q.params(is_tf)?),
        QueryMsg::Owner {} => to_json_binary(&tf_q.owner(is_tf)?),
        QueryMsg::MasterMinter {} => to_json_binary(&tf_q.master_minter(is_tf)?),
        QueryMsg::MinterController { address } => to_json_binary(&tf_q.minter_controller(address, is_tf)?),
        QueryMsg::AllMinterControllers {} => to_json_binary(&tf_q.all_minter_controllers(is_tf)?),
        QueryMsg::MintingDenom {} => to_json_binary(&tf_q.minting_denom(is_tf)?),
        QueryMsg::Minters { address } => to_json_binary(&tf_q.minters(address, is_tf)?),
        QueryMsg::AllMinters {} => to_json_binary(&tf_q.all_minters(is_tf)?),
        QueryMsg::Blacklister {} => to_json_binary(&tf_q.blacklister(is_tf)?),
        QueryMsg::Pauser {} => to_json_binary(&tf_q.pauser(is_tf)?),
        QueryMsg::Blacklisted { address } => to_json_binary(&tf_q.blacklisted(address, is_tf)?),
        QueryMsg::AllBlacklisted {} => to_json_binary(&tf_q.all_blacklisted(is_tf)?),
        QueryMsg::Paused {} => to_json_binary(&tf_q.paused(is_tf)?),
        */
        QueryMsg::Config {} => to_json_binary(&query::get_config(deps, env)?),
    }
}

#[allow(clippy::module_inception)]
mod query {
    use cosmwasm_std::{Deps, Env, StdResult};

    use tokenfactory_bindings::query::FactoryQuery;

    use crate::state::{Config, CONFIG};

    pub(super) fn get_config(deps: Deps<FactoryQuery>, _env: Env) -> StdResult<Config> {
        let config = CONFIG.load(deps.storage)?;
        Ok(config)
    }
}
