use cosmwasm_schema::cw_serde;
use cosmwasm_std::CustomQuery;

use tokenfactory_bindings::query::{BankQuery, FeegrantQuery, TokenfactoryQuery};

#[cw_serde]
pub struct InstantiateMsg {
    pub is_tf: bool,
}

#[cw_serde]
pub enum ExecuteMsg {
    Tf(TokenfactoryContractMsg),
    Feegrant(FeegrantContractMsg),
}

#[cw_serde]
pub enum TokenfactoryContractMsg {
    UpdateMasterMinter {
        address: String,
    },
    ConfigureMinterController {
        controller: String,
        minter: String,
    },
    RemoveMinterController {
        controller: String,
    },
    ConfigureMinter {
        address: String,
        allowance_denom: String,
        allowance_value: u64,
    },
    RemoveMinter {
        address: String,
    },
    UpdateBlacklister {
        address: String,
    },
    Blacklist {
        address: String,
    },
    Unblacklist {
        address: String,
    },
    UpdatePauser {
        address: String,
    },
    Pause {},
    Unpause {},
    Mint {
        // if called by another contract such as aurum Fund,
        //  the orig_sender is the address of the caller of the other contract
        orig_sender: Option<String>,
        // beneficiary address
        address: String,
        denom: String,
        value: u64,
    },
    Burn {
        // if called by another contract such as aurum Fund,
        //  the orig_sender is the address of the caller of the other contract
        orig_sender: Option<String>,
        denom: String,
        value: u64,
    },
}

#[cw_serde]
pub enum FeegrantContractMsg {
    GrantFeeBasicAllowance {
        granter: String,
        grantee: String,
        allowance_denom: String,
        allowance_value: u64,
        hours_to_expire: u64,
    },
    RevokeFeeAllowance {
        granter: String,
        grantee: String,
    },
}

#[cw_serde]
pub enum QueryMsg {
    Tf(TokenfactoryQuery),
    Bank(BankQuery),
    Feegrant(FeegrantQuery),
    Config {},
}

impl CustomQuery for QueryMsg {}
impl cosmwasm_std::CustomMsg for QueryMsg {}
