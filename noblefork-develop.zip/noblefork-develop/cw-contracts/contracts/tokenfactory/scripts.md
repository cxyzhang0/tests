# scripts for tokenfactory smart contract
## build wasm
```shell
cd tokenfactory
## build wasm
# rust 1.69.0 will produce valid wasm. 
# rust 1.70.0+ need to run wasm-opt with --signext-lowering
RUSTFLAGS='-C link-arg=-s' cargo wasm -v

# in order to use 1.70+, we need to run wasm-opt with --signext-lowering
#  refs: https://github.com/CosmWasm/cosmwasm/issues/1727   https://github.com/CosmWasm/optimizer/blob/v0.14.0/optimize.sh

# validate wasm will fail if built with rust 1.70.0+
# note: 2024-4-21 - built with 1.76.0 and the check passed. good news but is that expected?
cosmwasm-check ./target/wasm32-unknown-unknown/release/tokenfactory.wasm --available-capabilities "tokenfactory, fiattokenfactory, iterator, staking, cosmwasm_1_1, cosmwasm_1_2, cosmwasm_1_3" 

# optimize wasm to produce tokenfactory_optimized.wasm and also to support 1.70.0+ build
wasm-opt -Os --signext-lowering ./target/wasm32-unknown-unknown/release/tokenfactory.wasm -o ./target/wasm32-unknown-unknown/release/tokenfactory_optimized.wasm

# validate tokenfactory_optimized.wasm will pass
cosmwasm-check ./target/wasm32-unknown-unknown/release/tokenfactory_optimized.wasm --available-capabilities "tokenfactory, fiattokenfactory, iterator, staking, cosmwasm_1_1, cosmwasm_1_2, cosmwasm_1_3" 

# schema
cargo run schema
```

## Deploy on noblefork chain
See https://github.com/wfblockchain/noblefork/blob/main/scripts.md .