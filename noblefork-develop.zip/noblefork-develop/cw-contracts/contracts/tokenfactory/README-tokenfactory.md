# tokenfactory smart contract
integrate cosmwasm with the native tokenfactory on noblefork chain. it works together with [bindins](../../packages/tokenfactory-bindings) to enable tokenfactory smart contract.

## See [examples](scripts.md) for more information.

