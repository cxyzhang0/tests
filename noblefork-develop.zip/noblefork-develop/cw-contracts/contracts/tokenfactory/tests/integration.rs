use cosmwasm_std::{coins, Coin, Response, SystemResult};
use cosmwasm_vm::internals::check_wasm;
use cosmwasm_vm::testing::{
    execute, instantiate, mock_env, mock_info, mock_instance, mock_instance_options,
    mock_instance_with_options, MockApi, MockInstanceOptions, MockQuerier, MockStorage,
    MOCK_CONTRACT_ADDR,
};
use cosmwasm_vm::{Backend, Instance, InstanceOptions};
use std::collections::HashSet;
use tokenfactory::msg::{ExecuteMsg, InstantiateMsg, QueryMsg};
use tokenfactory::test::custom_query_execute;
use tokenfactory_bindings::msg::TokenfactoryMsg;

static WASM: &[u8] =
    include_bytes!("../../../../target/wasm32-unknown-unknown/release/tokenfactory_optimized.wasm");

pub fn mock_dependencies_with_custom_querier(
    contract_balance: &[Coin],
) -> Backend<MockApi, MockStorage, MockQuerier<QueryMsg>> {
    let custom_querier: MockQuerier<QueryMsg> =
        MockQuerier::new(&[(MOCK_CONTRACT_ADDR, contract_balance)])
            .with_custom_handler(|query| SystemResult::Ok(custom_query_execute(query)));

    Backend {
        api: MockApi::default().with_prefix("wf"),
        storage: MockStorage::default(),
        querier: custom_querier,
    }
}

pub fn mock_dependencies_with_custom_querier_and_balances(
    balances: &[(&str, &[Coin])],
) -> Backend<MockApi, MockStorage, MockQuerier<QueryMsg>> {
    let custom_querier: MockQuerier<QueryMsg> = MockQuerier::new(balances)
        .with_custom_handler(|query| SystemResult::Ok(custom_query_execute(query)));

    Backend {
        api: MockApi::default().with_prefix("wf"),
        storage: MockStorage::default(),
        querier: custom_querier,
    }
}

/// this tests the tokenfactory contract instantiation.
#[test]
fn it_instantiate() {
    let mut ac = HashSet::new();
    ac.insert("tokenfactory".to_string());
    ac.insert("iterator".to_string());
    ac.insert("staking".to_string());

    let mut deps = mock_instance_with_options(
        WASM,
        MockInstanceOptions {
            contract_balance: Some(&[]),
            available_capabilities: ac,
            ..Default::default()
        },
    );

    let msg = InstantiateMsg {};
    let info = mock_info("owner", &coins(1000, "uwfusd"));

    let resp: Response = instantiate(&mut deps, mock_env(), info, msg).unwrap();

    assert_eq!(0, resp.messages.len());
    assert_eq!(1, resp.attributes.len());
    assert_eq!("action", resp.attributes[0].key);
    assert_eq!("instantiate", resp.attributes[0].value);
}

/// this tests the mint response message and attributes.
/// for address validation, the account prefix is hardcoded to cosmwasm.
/// TODO: do the same test with cw-multi-test.
#[test]
fn it_mint() {
    let mut ac = HashSet::new();
    ac.insert("tokenfactory".to_string());
    ac.insert("iterator".to_string());
    ac.insert("staking".to_string());

    let mut deps = mock_instance_with_options(
        WASM,
        MockInstanceOptions {
            contract_balance: Some(&[]),
            available_capabilities: ac,
            ..Default::default()
        },
    );

    let msg = InstantiateMsg {};
    let info = mock_info("owner", &coins(1000, "uwfusd"));

    let _resp: Response = instantiate(&mut deps, mock_env(), info, msg).unwrap();

    let msg = ExecuteMsg::Mint {
        orig_sender: Some("minter".to_string()),
        address: "cosmwasm1y5xncqtnlkc7fgclald3kkerq63c287w6mf597".to_string(),
        denom: "uwfusd".to_string(),
        value: 10,
    };
    let info = mock_info("minter", &[]);
    let resp: Response<TokenfactoryMsg> = execute(&mut deps, mock_env(), info, msg).unwrap();

    assert_eq!(1, resp.messages.len());
    assert_eq!(
        resp.attributes
            .iter()
            .find(|attr| attr.key == "action")
            .unwrap()
            .value,
        "mint"
    );
    assert_eq!(
        resp.attributes
            .iter()
            .find(|attr| attr.key == "address")
            .unwrap()
            .value,
        "cosmwasm1y5xncqtnlkc7fgclald3kkerq63c287w6mf597"
    );
    assert_eq!(
        resp.attributes
            .iter()
            .find(|attr| attr.key == "denom")
            .unwrap()
            .value,
        "uwfusd"
    );
    assert_eq!(
        resp.attributes
            .iter()
            .find(|attr| attr.key == "value")
            .unwrap()
            .value,
        "10"
    );
}

/// this tests the mint response message and attributes.
/// for address validation, the account prefix is wf as set in
/// mock_dependencies_with_custom_querier or
/// mock_dependencies_with_custom_querier_and_balances.
/// TODO: do the same test with cw-multi-test.
#[test]
fn it_mint_wf() {
    let mut ac = HashSet::new();
    ac.insert("tokenfactory".to_string());
    ac.insert("iterator".to_string());
    ac.insert("staking".to_string());

    check_wasm(WASM, &ac).unwrap();

    let custom = mock_dependencies_with_custom_querier(&[]);
    let (instance_options, memory_limit) = mock_instance_options();
    let mut deps = Instance::from_code(
        WASM,
        custom,
        instance_options as InstanceOptions,
        memory_limit,
    )
    .unwrap();

    let msg = InstantiateMsg {};
    let info = mock_info("owner", &coins(1000, "uwfusd"));

    let _resp: Response = instantiate(&mut deps, mock_env(), info, msg).unwrap();

    let msg = ExecuteMsg::Mint {
        orig_sender: Some("minter".to_string()),
        address: "wf12qa3auxen76763lr26vkpa42cl63qzq6wgj9hf".to_string(),
        denom: "uwfusd".to_string(),
        value: 10,
    };
    let info = mock_info("minter", &[]);
    let resp: Response<TokenfactoryMsg> = execute(&mut deps, mock_env(), info, msg).unwrap();

    assert_eq!(1, resp.messages.len());
    assert_eq!(
        resp.attributes
            .iter()
            .find(|attr| attr.key == "action")
            .unwrap()
            .value,
        "mint"
    );
    assert_eq!(
        resp.attributes
            .iter()
            .find(|attr| attr.key == "address")
            .unwrap()
            .value,
        "wf12qa3auxen76763lr26vkpa42cl63qzq6wgj9hf"
    );
    assert_eq!(
        resp.attributes
            .iter()
            .find(|attr| attr.key == "denom")
            .unwrap()
            .value,
        "uwfusd"
    );
    assert_eq!(
        resp.attributes
            .iter()
            .find(|attr| attr.key == "value")
            .unwrap()
            .value,
        "10"
    );
}
