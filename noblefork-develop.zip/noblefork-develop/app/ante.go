package app

import (
	"errors"

	sdkerrors "cosmossdk.io/errors"
	storetypes "cosmossdk.io/store/types"
	circuitante "cosmossdk.io/x/circuit/ante"
	"github.com/CosmWasm/wasmd/x/wasm"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/cosmos/cosmos-sdk/types/bech32"
	"github.com/cosmos/cosmos-sdk/x/auth/ante"
	banktypes "github.com/cosmos/cosmos-sdk/x/bank/types"
	paramtypes "github.com/cosmos/cosmos-sdk/x/params/types"
	transfertypes "github.com/cosmos/ibc-go/v8/modules/apps/transfer/types"
	ibckeeper "github.com/cosmos/ibc-go/v8/modules/core/keeper"
	fiattokenfactory "github.com/wfblockchain/noble-fiattokenfactory/x/fiattokenfactory/keeper"
	fiattokenfactorytypes "github.com/wfblockchain/noble-fiattokenfactory/x/fiattokenfactory/types"
	forwardingkeeper "github.com/wfblockchain/noblechain/v5/x/forwarding/keeper"
	tokenfactory "github.com/wfblockchain/noblechain/v5/x/tokenfactory/keeper"
	tokenfactorytypes "github.com/wfblockchain/noblechain/v5/x/tokenfactory/types"
)

type HandlerOptions struct {
	ante.HandlerOptions
	CircuitKeeper          circuitante.CircuitBreaker
	tokenFactoryKeeper     *tokenfactory.Keeper
	fiatTokenFactoryKeeper *fiattokenfactory.Keeper
	IBCKeeper              *ibckeeper.Keeper
	GlobalFeeSubspace      paramtypes.Subspace
	StakingSubspace        paramtypes.Subspace
	ForwardingKeeper       *forwardingkeeper.Keeper
	WasmConfig             *wasm.Config
	Keys                   map[string]*storetypes.KVStoreKey
	TXCounterStoreKey      *storetypes.KVStoreKey
}

type IsPausedDecorator struct {
	tokenFactory     *tokenfactory.Keeper
	fiatTokenFactory *fiattokenfactory.Keeper
}

func NewIsPausedDecorator(tf *tokenfactory.Keeper, ctf *fiattokenfactory.Keeper) IsPausedDecorator {
	return IsPausedDecorator{
		tokenFactory:     tf,
		fiatTokenFactory: ctf,
	}
}

func (ad IsPausedDecorator) AnteHandle(ctx sdk.Context, tx sdk.Tx, simulate bool, next sdk.AnteHandler) (newCtx sdk.Context, err error) {
	msgs := tx.GetMsgs()
	for _, m := range msgs {
		switch m := m.(type) {
		case *banktypes.MsgSend, *banktypes.MsgMultiSend, *transfertypes.MsgTransfer:
			switch m := m.(type) {
			case *banktypes.MsgSend:
				for _, c := range m.Amount {
					paused, err := checkPausedStatebyTokenFactory(ctx, c, ad.tokenFactory, ad.fiatTokenFactory)
					if paused {
						return ctx, sdkerrors.Wrapf(err, "can not perform token transfers")
					}
				}
			case *banktypes.MsgMultiSend:
				for _, i := range m.Inputs {
					for _, c := range i.Coins {
						paused, err := checkPausedStatebyTokenFactory(ctx, c, ad.tokenFactory, ad.fiatTokenFactory)
						if paused {
							return ctx, sdkerrors.Wrapf(err, "can not perform token transfers")
						}
					}
				}
			case *transfertypes.MsgTransfer:
				paused, err := checkPausedStatebyTokenFactory(ctx, m.Token, ad.tokenFactory, ad.fiatTokenFactory)
				if paused {
					return ctx, sdkerrors.Wrapf(err, "can not perform token transfers")
				}
			default:
				continue
			}
		default:
			continue
		}
	}
	return next(ctx, tx, simulate)
}

func checkPausedStatebyTokenFactory(ctx sdk.Context, c sdk.Coin, tf *tokenfactory.Keeper, ctf *fiattokenfactory.Keeper) (bool, *sdkerrors.Error) {
	tfMintingDenom := tf.GetMintingDenom(ctx)
	if c.Denom == tfMintingDenom.Denom {
		paused := tf.GetPaused(ctx)
		if paused.Paused {
			return true, tokenfactorytypes.ErrPaused
		}
	}
	ctfMintingDenom := ctf.GetMintingDenom(ctx)
	if c.Denom == ctfMintingDenom.Denom {
		paused := ctf.GetPaused(ctx)
		if paused.Paused {
			return true, fiattokenfactorytypes.ErrPaused
		}
	}
	return false, nil
}

type IsBlacklistedDecorator struct {
	tokenfactory     *tokenfactory.Keeper
	fiattokenfactory *fiattokenfactory.Keeper
}

func NewIsBlacklistedDecorator(tf *tokenfactory.Keeper, ctf *fiattokenfactory.Keeper) IsBlacklistedDecorator {
	return IsBlacklistedDecorator{
		tokenfactory:     tf,
		fiattokenfactory: ctf,
	}
}

func (ad IsBlacklistedDecorator) AnteHandle(ctx sdk.Context, tx sdk.Tx, simulate bool, next sdk.AnteHandler) (newCtx sdk.Context, err error) {
	msgs := tx.GetMsgs()
	for _, m := range msgs {
		switch m := m.(type) {
		case *banktypes.MsgSend, *banktypes.MsgMultiSend, *transfertypes.MsgTransfer:
			switch m := m.(type) {
			case *banktypes.MsgSend:
				for _, c := range m.Amount {
					addresses := []string{m.ToAddress, m.FromAddress}
					blacklisted, address, err := checkForBlacklistedAddressByTokenFactory(ctx, addresses, c, ad.tokenfactory, ad.fiattokenfactory)
					if blacklisted {
						return ctx, sdkerrors.Wrapf(err, "an address (%s) is blacklisted and can not send or receive tokens", address)
					}
					if err != nil {
						return ctx, sdkerrors.Wrapf(err, "error decoding address (%s)", address)
					}
				}
			case *banktypes.MsgMultiSend:
				for _, i := range m.Inputs {
					for _, c := range i.Coins {
						addresses := []string{i.Address}
						blacklisted, address, err := checkForBlacklistedAddressByTokenFactory(ctx, addresses, c, ad.tokenfactory, ad.fiattokenfactory)
						if blacklisted {
							return ctx, sdkerrors.Wrapf(err, "an address (%s) is blacklisted and can not send or receive tokens", address)
						}
						if err != nil {
							return ctx, sdkerrors.Wrapf(err, "error decoding address (%s)", address)
						}
					}
				}
				for _, o := range m.Outputs {
					for _, c := range o.Coins {
						addresses := []string{o.Address}
						blacklisted, address, err := checkForBlacklistedAddressByTokenFactory(ctx, addresses, c, ad.tokenfactory, ad.fiattokenfactory)
						if blacklisted {
							return ctx, sdkerrors.Wrapf(err, "an address (%s) is blacklisted and can not send or receive tokens", address)
						}
						if err != nil {
							return ctx, sdkerrors.Wrapf(err, "error decoding address (%s)", address)
						}
					}
				}
			case *transfertypes.MsgTransfer:
				addresses := []string{m.Sender, m.Receiver}
				blacklisted, address, err := checkForBlacklistedAddressByTokenFactory(ctx, addresses, m.Token, ad.tokenfactory, ad.fiattokenfactory)
				if blacklisted {
					return ctx, sdkerrors.Wrapf(err, "an address (%s) is blacklisted and can not send or receive tokens", address)
				}
				if err != nil {
					return ctx, sdkerrors.Wrapf(err, "error decoding address (%s)", address)
				}
			}
		default:
			continue
		}
	}
	return next(ctx, tx, simulate)
}

// checkForBlacklistedAddressByTokenFactory first checks if the denom being transacted is a mintable asset from a TokenFactory,
// if it is, it checks if the addresses involved in the tx are blacklisted by that specific TokenFactory.
func checkForBlacklistedAddressByTokenFactory(ctx sdk.Context, addresses []string, c sdk.Coin, tf *tokenfactory.Keeper, ctf *fiattokenfactory.Keeper) (blacklisted bool, blacklistedAddress string, err error) {
	tfMintingDenom := tf.GetMintingDenom(ctx)
	if c.Denom == tfMintingDenom.Denom {
		for _, address := range addresses {
			_, addressBz, err := bech32.DecodeAndConvert(address)
			if err != nil {
				return false, address, err
			}
			_, found := tf.GetBlacklisted(ctx, addressBz)
			if found {
				return true, address, tokenfactorytypes.ErrUnauthorized
			}
		}
	}
	ctfMintingDenom := ctf.GetMintingDenom(ctx)
	if c.Denom == ctfMintingDenom.Denom {
		for _, address := range addresses {
			_, addressBz, err := bech32.DecodeAndConvert(address)
			if err != nil {
				return false, address, err
			}
			_, found := ctf.GetBlacklisted(ctx, addressBz)
			if found {
				return true, address, fiattokenfactorytypes.ErrUnauthorized
			}
		}
	}
	return false, "", nil
}

func NewAnteHandler(options HandlerOptions) (sdk.AnteHandler, error) {
	if options.AccountKeeper == nil {
		return nil, errors.New("account keeper is required for ante builder")
	}

	if options.BankKeeper == nil {
		return nil, errors.New("bank keeper is required for ante builder")
	}

	if options.SignModeHandler == nil {
		return nil, errors.New("sign mode handler is required for ante builder")
	}

	anteDecorators := []sdk.AnteDecorator{
		ante.NewSetUpContextDecorator(), // outermost AnteDecorator. SetUpContext must be called first
		circuitante.NewCircuitBreakerDecorator(options.CircuitKeeper),
		ante.NewExtensionOptionsDecorator(options.ExtensionOptionChecker),
		ante.NewValidateBasicDecorator(),
		ante.NewTxTimeoutHeightDecorator(),
		ante.NewValidateMemoDecorator(options.AccountKeeper),
		ante.NewConsumeGasForTxSizeDecorator(options.AccountKeeper),
		ante.NewDeductFeeDecorator(options.AccountKeeper, options.BankKeeper, options.FeegrantKeeper, options.TxFeeChecker),
		ante.NewSetPubKeyDecorator(options.AccountKeeper), // SetPubKeyDecorator must be called before all signature verification decorators
		ante.NewValidateSigCountDecorator(options.AccountKeeper),
		ante.NewSigGasConsumeDecorator(options.AccountKeeper, options.SigGasConsumer),
		ante.NewSigVerificationDecorator(options.AccountKeeper, options.SignModeHandler),
		ante.NewIncrementSequenceDecorator(options.AccountKeeper),
	}

	return sdk.ChainAnteDecorators(anteDecorators...), nil
}
