## build 
```shell
# build binary into ./bin
make build

# install binary into $GOPATH/bin
make install
```
## test
```shell
# gentle start
./bin/tfd --home ./play_wallet_tmkms_sh/tokenfactory-1 start --pruning=nothing --grpc-web.enable=false --grpc.address="0.0.0.0:9090" --trace --log_level=trace
# destructive start
./play_wallet_tmkms.sh

# set up environment
source ./chains_wallet_tmkms.env

# validator set
tfd query staking validators $NODE_HOME --output json | jq
tfd tendermint show-validator $NODE_HOME

#tfd tx bank send $VALIDATOR $USER1 10stake $NODE_CHAIN $NODE_HOME $KEYRING -y
#tfd tx bank send validator $USER1 10stake $NODE_CHAIN $NODE_HOME $KEYRING -y
#tfd tx bank send validator $USER1 10stake $NODE_HOME $KEYRING -y

tfd tx bank send validator $MASTERMINTER 100000000stake $NODE_HOME $KEYRING -y

# balances
tfd q bank balances $VALIDATOR $NODE_CHAIN
tfd q bank balances $OWNER $NODE_CHAIN
tfd q bank balances $MASTERMINTER $NODE_CHAIN
tfd q bank balances $MINTERCONTROLLER $NODE_CHAIN
tfd q bank balances $MINTER $NODE_CHAIN
tfd q bank balances $BLACKLISTER $NODE_CHAIN
tfd q bank balances $PASER $NODE_CHAIN

tfd q bank balances $USA $NODE_CHAIN
tfd q bank balances $CAN $NODE_CHAIN
tfd q bank balances $USER1 $NODE_CHAIN
tfd q bank balances $USER2 $NODE_CHAIN

tfd q bank total $NODE_CHAIN

tfd q bank denom-metadata --denom cent $NODE_CHAIN
tfd q bank denom-metadata --denom uwfusd $NODE_CHAIN
grpcurl -plaintext \                                                                                                                                                                      ──(Wed,May08)─┘
    localhost:9090 \
    cosmos.bank.v1beta1.Query/DenomsMetadata


# query tx
tfd q tx 56676ED260F2C48E92690DC801AB83FCBAE4E848FA464D3D4A58D5114CC1B353 $NODE_CHAIN  

# query tokenfactory
## roles
### params
tfd q tokenfactory params $NODE_HOME

### owner: one per tokenfactory
tfd q tokenfactory show-owner $NODE_HOME
tfd q fiat-tokenfactory show-owner $NODE_HOME

### masterminter: one per tokenfactory
tfd q tokenfactory show-master-minter $NODE_HOME
tfd q fiat-tokenfactory show-master-minter $NODE_HOME

### mintercontroller: each address can be only once per tokenfactory, i.e., the pair (controller, minter) is unique in controller
tfd q tokenfactory show-minter-controller $MINTERCONTROLLER $NODE_HOME
## bug: query result is independent of controller address
tfd q tokenfactory list-minter-controller $MINTERCONTROLLER $NODE_HOME

### minting denom
tfd q tokenfactory show-minting-denom $NODE_CHAIN
tfd q fiat-tokenfactory show-minting-denom $NODE_CHAIN

### minter: always paired with a mintercontroller
tfd q tokenfactory show-minters $MINTER $NODE_CHAIN
## bug: query result is independent of controller address; this may be all minters
tfd q tokenfactory list-minters $MINTERCONTROLLER $NODE_CHAIN

### blacklister: one per tokenfactory
tfd q tokenfactory show-blacklister $NODE_CHAIN

### pauser: one per tokenfactory
tfd q tokenfactory show-pauser $NODE_CHAIN
## states
tfd q tokenfactory show-blacklisted $USER $NODE_CHAIN
tfd q tokenfactory list-blacklisted $BLACKLISTER $NODE_CHAIN

tfd q tokenfactory show-paused $NODE_CHAIN

# ***** NO tx can be executed via daemon because the keys are in HSM
# tx tokenfactory 
## owner
## TODO: update-owner does not change the owner
tfd tx tokenfactory update-owner $TF2_OWNER --from tf1_owner $NODE_CHAIN $NODE_HOME $KEYRING -y # --trace --log_level=trace
## TODO: Error: unknown command "noble1h8jmqsfl4mlmaqmul3malxtmsmzcved9e0sdmg" for "nobled tx tokenfactory accept-owner"
tfd tx tokenfactory accept-owner $TF2_OWNER --from tf1_owner $NODE_CHAIN $NODE_HOME $KEYRING -y # --trace --log_level=trace

## masterminter
tfd tx tokenfactory update-master-minter $USER --from tf1_owner $NODE_CHAIN $NODE_HOME $KEYRING -y
tfd tx tokenfactory update-master-minter $MASTERMINTER --from tf1_owner $NODE_CHAIN $NODE_HOME $KEYRING -y

## mintercontroller
tfd tx tokenfactory configure-minter-controller $MINTERCONTROLLER $USER --from masterminter $NODE_CHAIN $NODE_HOME $KEYRING -y
tfd tx tokenfactory configure-minter-controller $MINTERCONTROLLER $MINTER --from masterminter $NODE_CHAIN $NODE_HOME $KEYRING -y
tfd tx tokenfactory configure-minter-controller $USER $MINTER --from masterminter $NODE_CHAIN $NODE_HOME $KEYRING -y

tfd tx tokenfactory remove-minter-controller $USER --from masterminter $NODE_CHAIN $NODE_HOME $KEYRING -y

## minter
tfd tx tokenfactory configure-minter $MINTER 10000uwfusd --from mintercontroller $NODE_CHAIN $NODE_HOME $KEYRING -y

tfd tx tokenfactory remove-minter $MINTER --from mintercontroller $NODE_CHAIN $NODE_HOME $KEYRING -y

tfd tx tokenfactory configure-minter $MINTER 1000uwfusd --from mintercontroller $NODE_CHAIN $NODE_HOME $KEYRING -y

## blacklister and blacklist
tfd tx tokenfactory update-blacklister $USER --from tf1_owner $NODE_CHAIN $NODE_HOME $KEYRING -y

tfd tx tokenfactory update-blacklister $BLACKLISTER --from tf1_owner $NODE_CHAIN $NODE_HOME $KEYRING -y

tfd tx tokenfactory blacklist $USER --from blacklister $NODE_CHAIN $NODE_HOME $KEYRING -y

tfd tx tokenfactory unblacklist $USER --from blacklister $NODE_CHAIN $NODE_HOME $KEYRING -y

## pauser and pause
tfd tx tokenfactory update-pauser $USER --from tf1_owner $NODE_CHAIN $NODE_HOME $KEYRING -y

tfd tx tokenfactory update-pauser $PAUSER --from tf1_owner $NODE_CHAIN $NODE_HOME $KEYRING -y

tfd tx tokenfactory pause --from pauser $NODE_CHAIN $NODE_HOME $KEYRING -y

tfd tx tokenfactory unpause --from pauser $NODE_CHAIN $NODE_HOME $KEYRING -y

## mint and burn
tfd tx tokenfactory mint $USER 10uwfusd --from minter $NODE_CHAIN $NODE_HOME $KEYRING -y

tfd tx bank send $USER $MINTER 10uwfusd --from user $NODE_CHAIN $NODE_HOME $KEYRING -y
tfd tx tokenfactory burn 10uwfusd --from minter $NODE_CHAIN $NODE_HOME $KEYRING -y
```

## run cosmwasm tokenfactory contract
```shell
# upload wasm code and get $CODE_ID: two steps
STORE=$(tfd tx wasm store ../../../rust/cosmos/wfdc2/target/wasm32-unknown-unknown/release/tokenfactory_optimized.wasm --from faucet $TXFLAG $KEYRING $NODE_HOME -y -b sync --output json) && \
TX_HASH=$(echo $STORE | jq -r '.txhash') && \
echo "$TX_HASH" && \
sleep 5 && \
TX=$(tfd q tx $TX_HASH $NODE_CHAIN --output json) && \
CODE_ID=$(echo $TX | jq -r '.logs[0].events[-1].attributes[1].value') && \
echo $CODE_ID

# 1

# instantiate and get CONTRACT_ADDRESS: two steps
INIT=$(jq -n --arg is_tf "true" '{ "is_tf": $is_tf | test("true") }') && \
echo $INIT && \
RES=$(tfd tx wasm instantiate $CODE_ID "$INIT" --from faucet --label "tf" --no-admin $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
sleep 5 && \
CONTRACT_ADDRESS=$(tfd query wasm list-contract-by-code $CODE_ID $NODE_CHAIN --output json | jq -r '.contracts[-1]') && \
echo $CONTRACT_ADDRESS

## wf14hj2tavq8fpesdwxxcu44rty3hh90vhujrvcmstl4zr3txmfvw9s2s4a5q from code 1

# queries
## config raw data
tfd q wasm contract-state raw $CONTRACT_ADDRESS "config" --ascii 

JSON=$(jq -n '{ config: {} }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n '{ tf: { params: {} } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n '{ tf: { owner: {} } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n '{ tf: { master_minter: {} } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n --arg address "$MINTERCONTROLLER" '{ tf: { minter_controller: { address: $address } } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n '{ tf: { all_minter_controllers: {} } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n --arg address "$MINTER" '{ tf: { minting_denom: {} } }') && \
echo $JSON && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n --arg address "$MINTER" '{ tf: { minters: { address: $address } } }') && \
echo $JSON && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n '{ tf: { all_minters: {} } }') && \
echo $JSON && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n '{ tf: { blacklister: {} } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

## being empty shows some error
JSON=$(jq -n --arg address "$USER" '{ tf: { blacklisted: { address: $address } } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

## being empty shows some error
JSON=$(jq -n '{ tf: { all_blacklisted: {} } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n '{ tf: { pauser: {} } }') && \
echo $JSON && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n '{ tf: { paused: {} } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

## denom_metadata
JSON=$(jq -n --arg denom "cent" '{ bank: { denom_metadata: { denom: $denom} } }') && \
echo $JSON && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n --arg denom "uwfusd" '{ bank: { denom_metadata: { denom: $denom} } }') && \
echo $JSON && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

## all_denom_metadata
JSON=$(jq -n  '{ bank: { all_denom_metadata: { } } }') && \
echo $JSON && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

## find_denom_metadata
JSON=$(jq -n --arg base_denom "cent" --arg denom "USD" '{ bank: { find_denom_metadata: { base_denom: $base_denom, denom: $denom} } }') && \
echo $JSON && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n --arg base_denom "uwfusd" --arg denom "wfusd" '{ bank: { find_denom_metadata: { base_denom: $base_denom, denom: $denom} } }') && \
echo $JSON && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

## find_metadata_for_denom
JSON=$(jq -n --arg denom "USD" '{ bank: { find_metadata_for_denom: { denom: $denom} } }') && \
echo $JSON && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n --arg denom "wfusd" '{ bank: { find_metadata_for_denom: { denom: $denom} } }') && \
echo $JSON && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n --arg granter "$FAUCET" --arg grantee "$OWNER" '{ feegrant: { fee_basic_allowance: { "granter": $granter, "grantee": $grantee } } }') && \
echo $JSON && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

# ***** NO tx can be executed via daemon because the keys are in HSM
# execute txs
## update_master_minter
#JSON=$(jq -n --arg address "$USER" \
JSON=$(jq -n --arg address "$MASTERMINTER" \
'{ "update_master_minter": { "address": $address } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from tf1_owner $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

## configure_minter_controller
JSON=$(jq -n --arg controller "$MINTERCONTROLLER" --arg minter "$MINTER" \
'{ "configure_minter_controller": { "controller": $controller, "minter": $minter } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from masterminter $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

## remove_minter_controller
JSON=$(jq -n --arg controller "$MINTERCONTROLLER" \
'{ "remove_minter_controller": { "controller": $controller } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from masterminter $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

## configure_minter
JSON=$(jq -n --arg address "$MINTER" --arg allowance_denom "uwfusd" --arg allowance_value 500 \
'{ "configure_minter": { "address": $address, "allowance_denom": $allowance_denom, "allowance_value": $allowance_value | tonumber } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from mintercontroller $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

## remove_minter
JSON=$(jq -n --arg address "$MINTER" \
'{ "remove_minter": { "address": $address } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from mintercontroller $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

## update_blacklister
JSON=$(jq -n --arg address "$BLACKLISTER" \
'{ "update_blacklister": { "address": $address } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from tf1_owner $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

## blacklist
JSON=$(jq -n --arg address "$USER" \
'{ "blacklist": { "address": $address } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from blacklister $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

## unblacklist
JSON=$(jq -n --arg address "$USER" \
'{ "unblacklist": { "address": $address } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from blacklister $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

## update_pauser
JSON=$(jq -n --arg address "$PAUSER" \
'{ "update_pauser": { "address": $address } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from tf1_owner $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

## pause
JSON=$(jq -n \
'{ "pause": { } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from pauser $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

## unpause
JSON=$(jq -n \
'{ "unpause": { } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from pauser $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

## mint
### minting decreases minter's allowance
JSON=$(jq -n --arg address "$USER" --arg denom "uwfusd" --arg value 10 \
'{ "mint": { "address": $address, "denom": $denom, "value": $value | tonumber } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from minter $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $JSON && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

## burn
### burning does not increase minter's allowance
tfd tx bank send $USER $MINTER 10uwfusd --from user $NODE_CHAIN $NODE_HOME $KEYRING -y

JSON=$(jq -n --arg address "$USER" --arg denom "uwfusd" --arg value 10 \
'{ "burn": { "denom": $denom, "value": $value | tonumber } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from minter $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq


# feegrant
## grant
## TODO: why any --from can do the grant.
JSON=$(jq -n --arg granter "$FAUCET" --arg grantee "$USER" --arg denom "stake" --arg value 1000000 --arg hours_to_expire 10 \
'{ feegrant: { "grant_fee_basic_allowance": 
{ "granter": $granter, "grantee": $grantee, "allowance_denom": $denom, 
"allowance_value": $value | tonumber, "hours_to_expire": $hours_to_expire | tonumber } } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from tf2_owner $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq && \
sleep 5 && \
TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq


```

