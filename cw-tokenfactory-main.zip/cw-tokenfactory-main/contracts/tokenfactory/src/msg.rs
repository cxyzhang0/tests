use cosmwasm_schema::cw_serde;
use cosmwasm_std::CustomQuery;
use tokenfactory_bindings::query::{BankQuery, DenomMetadata, FeegrantQuery, TokenfactoryQuery};
#[cw_serde]
pub struct InstantiateMsg {
    pub is_tf: bool,
}

#[cw_serde]
pub enum ExecuteMsg {
    Tf(TokenfactoryContractMsg),
    Redeem {
        // if called by another contract such as aurum Fund,
        //  the orig_sender is the address of the caller of the other contract
        orig_sender: Option<String>,
        minter_address: String,
        denom: String,
        // value in String instead of u128 because caller (such as jq) may not be able to handle u128
        value: String,
    },
    Feegrant(FeegrantContractMsg),
    AddTrustedCaller {
        addr: String,
    },
    RemoveTrustedCaller {
        addr: String,
    },
}

#[cw_serde]
pub enum TokenfactoryContractMsg {
    UpdateMasterMinter {
        address: String,
    },
    ConfigureMinterController {
        controller: String,
        minter: String,
    },
    RemoveMinterController {
        controller: String,
        minter: String,
    },
    ConfigureMinter {
        address: String,
        allowance_denom: String,
        // allowance_value in String instead of u128 because caller (such as jq) may not be able to handle u128
        allowance_value: String,
    },
    RemoveMinter {
        address: String,
        denom: String,
    },
    UpdateBlacklister {
        address: String,
    },
    Blacklist {
        address: String,
    },
    Unblacklist {
        address: String,
    },
    UpdatePauser {
        address: String,
    },
    Pause {},
    Unpause {},
    Mint {
        // if called by another contract such as aurum Fund,
        //  the orig_sender is the address of the caller of the other contract
        orig_sender: Option<String>,
        // beneficiary address
        address: String,
        denom: String,
        // value in String instead of u128 because caller (such as jq) may not be able to handle u128
        value: String,
    },
    Burn {
        // if called by another contract such as aurum Fund,
        //  the orig_sender is the address of the caller of the other contract
        orig_sender: Option<String>,
        denom: String,
        // value in String instead of u128 because caller (such as jq) may not be able to handle u128
        value: String,
    },
    SetDenomMetadata {
        orig_sender: Option<String>,
        metadata: DenomMetadata,
    },
}

#[cw_serde]
pub enum FeegrantContractMsg {
    GrantFeeBasicAllowance {
        granter: String,
        grantee: String,
        allowance_denom: String,
        // allowance_value in String instead of u128 because caller (such as jq) may not be able to handle u128
        allowance_value: String,
        hours_to_expire: u64,
    },
    RevokeFeeAllowance {
        granter: String,
        grantee: String,
    },
}

#[cw_serde]
pub enum QueryMsg {
    Tf(TokenfactoryQuery),
    Bank(BankQuery),
    Feegrant(FeegrantQuery),
    Config {},
    IsTrustedCaller { addr: String },
    AllTrustedCallers {},
}

#[cw_serde]
pub struct IsTrustedCallerResponse {
    pub addr: String,
    pub trusted: bool,
}

#[cw_serde]
pub struct AllTrustedCallersResponse {
    pub callers: Vec<IsTrustedCallerResponse>,
}

/// Versioned migration message.
///
/// Each variant corresponds to a **single-step** migration to a specific
/// contract release. Every allowed migration — whether it changes state or
/// not — has a dedicated helper function in `migrate.rs`.
///
/// # How it works
///
/// The `migrate` entry point (in `migrate.rs`):
///
/// 1. Loads the stored `cw2` contract version as the **source of truth**.
/// 2. Matches on `((prev_ver.major, prev_ver.minor), (new_ver.major, new_ver.minor))`
///    — the version pair only, **not** the `MigrateMsg` variant. Using
///    `(major, minor)` tuples avoids ambiguity when the major version bumps
///    and minor resets to `0`
///    (e.g. `0.9.x → 1.0.x` is distinct from `1.9.x → 2.0.x`).
/// 3. Each version pair dispatches to its `migrate_vX_to_vY` helper.
/// 4. The helper validates that the `MigrateMsg` variant is correct
///    (the sole enforcement, since the outer match gates only on the
///    version pair).
/// 5. Unrecognised version pairs are rejected via a catch-all error arm.
///
/// # Adding a new migration (checklist for future developers)
///
/// 1. **Bump `CONTRACT_VERSION`** in `contract.rs` (the `Cargo.toml` version).
/// 2. **Add a new variant** below (e.g. `V3 { new_param: String }`).
///    Even for code-only releases with no state changes, add a variant.
/// 3. **Add a match arm** in the `migrate` entry point (in `migrate.rs`)
///    for the version pair:
///    ```ignore
///    ((0, 2), (0, 3)) => migrate_v02_to_v03(deps.storage, deps.api, &msg)?,
///    ```
/// 4. **Write a `migrate_vX_to_vY` helper** in `migrate.rs` that:
///    - Validates that `msg` is the expected `MigrateMsg` variant.
///    - Applies state transformations (if any).
///    - For code-only releases, validation is the only logic needed.
/// 5. **Check dependency migrations** — if you bumped `cw-ownable`, `cw2`,
///    or any other library that changed its storage schema, call their
///    migration helper inside the same function.
/// 6. **Write tests** that seed storage with the old schema, run `migrate`,
///    and assert the new schema is correct.
///
/// # Why single-step only?
///
/// Each `migrate_vX_to_vY` function is compiled into the **vY binary** and
/// may freely use vY's production types for its output. If multi-version
/// jumps were supported (e.g. v1→v3 in one shot), intermediate migration
/// functions would need to define both input **and** output schemas inline
/// (since the production types reflect v3, not v2). This creates a
/// maintenance burden and semantic divergence. Single-step migrations avoid
/// this entirely.
///
/// # CLI usage
///
/// ```bash
/// # Migrate from v0.2.x to v0.3.0 (state migration)
/// $BINARY tx wasm migrate $CONTRACT $V3_CODE_ID '{"v3":{}}' --from=$ADMIN
///
/// # Then migrate from v0.3.x to v0.4.0 (state migration, with parameters)
/// # $BINARY tx wasm migrate $CONTRACT $V4_CODE_ID '{"v4":{"new_param":"value"}}' --from=$ADMIN
///
/// # Patch upgrade (code-only)
/// $BINARY tx wasm migrate $CONTRACT $V3_PATCH_CODE_ID '{"no_op":{}}' --from=$ADMIN
/// ```
#[cw_serde]
pub enum MigrateMsg {
    /// Patch-level (code-only) upgrade. No state changes.
    /// Use this for any migration where `(major, minor)` is unchanged.
    NoOp {},
    /// Migration to v0.3.0 (from v0.2.x).
    ///
    /// State changes introduced in this release:
    /// - `Config.owner` removed — ownership now managed by `cw-ownable`.
    /// - Added `TRUSTED_CONTRACT_CALLERS` map to `state.rs` (starts empty).
    ///
    /// No extra parameters required — all new state has sensible defaults.
    V3 {},
    // -------------------------------------------------------------------------
    // Future migration variants — uncomment and fill in when needed.
    // Every release gets a variant, even code-only upgrades.
    // -------------------------------------------------------------------------
    //
    // /// Migration to v0.4.0 (from v0.3.x).
    // ///
    // /// State changes introduced in this release:
    // /// - (Describe what changed in state.rs / new Items / Maps / schema changes.)
    // /// - (Describe any dependency upgrades that changed storage layout.)
    // ///
    // /// Parameters:
    // /// - `new_param`: (Explain why this can't be derived from on-chain state.)
    // V4 {
    //     new_param: String,
    // },
}

impl CustomQuery for QueryMsg {}
impl cosmwasm_std::CustomMsg for QueryMsg {}
