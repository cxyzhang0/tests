use cosmwasm_schema::{cw_serde};
use cosmwasm_std::CustomQuery;
use tokenfactory_bindings::query::{BankQuery, DenomMetadata, FeegrantQuery, TokenfactoryQuery};
#[cw_serde]
pub struct InstantiateMsg {
    pub is_tf: bool,
}

#[cw_serde]
pub enum ExecuteMsg {
    Tf(TokenfactoryContractMsg),
    Redeem {
        // if called by another contract such as aurum Fund,
        //  the orig_sender is the address of the caller of the other contract
        orig_sender: Option<String>,
        minter_address: String,
        denom: String,
        // value in String instead of u128 because caller (such as jq) may not be able to handle u128
        value: String,
    },
    Feegrant(FeegrantContractMsg),
}

#[cw_serde]
pub enum TokenfactoryContractMsg {
    UpdateMasterMinter {
        address: String,
    },
    ConfigureMinterController {
        controller: String,
        minter: String,
    },
    RemoveMinterController {
        controller: String,
        minter: String,
    },
    ConfigureMinter {
        address: String,
        allowance_denom: String,
        // allowance_value in String instead of u128 because caller (such as jq) may not be able to handle u128
        allowance_value: String,
    },
    RemoveMinter {
        address: String,
        denom: String,
    },
    UpdateBlacklister {
        address: String,
    },
    Blacklist {
        address: String,
    },
    Unblacklist {
        address: String,
    },
    UpdatePauser {
        address: String,
    },
    Pause {},
    Unpause {},
    Mint {
        // if called by another contract such as aurum Fund,
        //  the orig_sender is the address of the caller of the other contract
        orig_sender: Option<String>,
        // beneficiary address
        address: String,
        denom: String,
        // value in String instead of u128 because caller (such as jq) may not be able to handle u128
        value: String,
    },
    Burn {
        // if called by another contract such as aurum Fund,
        //  the orig_sender is the address of the caller of the other contract
        orig_sender: Option<String>,
        denom: String,
        // value in String instead of u128 because caller (such as jq) may not be able to handle u128
        value: String,
    },
    SetDenomMetadata {
        orig_sender: Option<String>,
        metadata: DenomMetadata,
    },
}

#[cw_serde]
pub enum FeegrantContractMsg {
    GrantFeeBasicAllowance {
        granter: String,
        grantee: String,
        allowance_denom: String,
        // allowance_value in String instead of u128 because caller (such as jq) may not be able to handle u128
        allowance_value: String,
        hours_to_expire: u64,
    },
    RevokeFeeAllowance {
        granter: String,
        grantee: String,
    },
}

#[cw_serde]
pub enum QueryMsg {
    Tf(TokenfactoryQuery),
    Bank(BankQuery),
    Feegrant(FeegrantQuery),
    Config {},
}

impl CustomQuery for QueryMsg {}
impl cosmwasm_std::CustomMsg for QueryMsg {}
