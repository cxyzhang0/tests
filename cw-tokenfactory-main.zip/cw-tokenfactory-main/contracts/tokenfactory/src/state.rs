use cosmwasm_schema::cw_serde;
use cosmwasm_std::Addr;
use cw_storage_plus::{Item, Map};

pub const CONFIG: Item<Config> = Item::new("config");

/// Whitelist of contract addresses allowed to pass `orig_sender` when calling
/// this contract on behalf of another user.
///
/// - **Key**: validated contract `Addr`
/// - **Value**: `bool` — `true` means the contract is currently trusted;
///   `false` means it was previously trusted but has been revoked.
///
/// Only contract addresses (not normal user accounts) may be added.
/// Entries are never deleted; revocation sets the value to `false`.
pub const TRUSTED_CONTRACT_CALLERS: Map<&Addr, bool> = Map::new("trusted_contract_callers");

#[cw_serde]
pub struct Config {
    // whether is tokenfactory vs fiat-tokenfactory
    pub is_tf: bool,
}
