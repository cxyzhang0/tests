use std::marker::PhantomData;

use cosmwasm_std::testing::{MockApi, MockQuerier, MockStorage, MOCK_CONTRACT_ADDR};
use cosmwasm_std::{to_json_binary, Binary, Coin, ContractResult, OwnedDeps, SystemResult};

use tokenfactory_bindings::query::{MintersResponse, OwnerResponse, TokenfactoryQuery};

use crate::msg::QueryMsg;

pub fn mock_dependencies_with_custom_querier(
    contract_balance: &[Coin],
) -> OwnedDeps<MockStorage, MockApi, MockQuerier<QueryMsg>, QueryMsg> {
    let custom_querier: MockQuerier<QueryMsg> =
        MockQuerier::new(&[(MOCK_CONTRACT_ADDR, contract_balance)])
            .with_custom_handler(|query| SystemResult::Ok(custom_query_execute(query)));

    OwnedDeps {
        storage: MockStorage::default(),
        api: MockApi::default(),
        querier: custom_querier,
        custom_query_type: PhantomData,
    }
}

/// mock query resuls
pub fn custom_query_execute(query: &QueryMsg) -> ContractResult<Binary> {
    match query {
        QueryMsg::Tf(TokenfactoryQuery::Minters { address, denom }) => {
            to_json_binary(&MintersResponse {
                address: address.to_string(),
                allowance: Coin::new(1000u128, denom),
            })
            .into()
        }
        _default => to_json_binary(&OwnerResponse {
            address: "".to_string(),
        })
        .into(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use cosmwasm_std::{from_json, QuerierWrapper, QueryRequest};
    use tokenfactory_bindings::query::TokenfactoryQuery::Minters;

    #[test]
    fn custom_query_execute_minters() {
        let query = QueryMsg::Tf(Minters {
            address: "minter".to_string(),
            denom: "uwfUSD".to_string(),
        });
        let resp = custom_query_execute(&query).unwrap();
        let response: MintersResponse = from_json(&resp).unwrap();
        assert_eq!(response.address, "minter");
        assert_eq!(response.allowance.denom, "uwfUSD");
        assert_eq!(response.allowance.amount.to_string(), "1000");
    }

    #[test]
    fn custom_querier() {
        let deps = mock_dependencies_with_custom_querier(&[]);
        let req: QueryRequest<_> = QueryMsg::Tf(Minters {
            address: "minter".to_string(),
            denom: "uwfUSD".to_string(),
        })
        .into();

        let wrapper = QuerierWrapper::new(&deps.querier);

        let resp: MintersResponse = wrapper.query(&req).unwrap();
        assert_eq!(resp.address, "minter");
    }
}

#[cfg(test)]
mod trusted_caller_tests {
    use cosmwasm_std::testing::{message_info, mock_env, MockApi, MockQuerier, MockStorage};
    use cosmwasm_std::{Addr, Api, OwnedDeps};
    use cw_ownable::initialize_owner;
    use std::marker::PhantomData;
    use tokenfactory_bindings::query::FactoryQuery;

    use crate::contract::execute;
    use crate::msg::{AllTrustedCallersResponse, ExecuteMsg, IsTrustedCallerResponse, TokenfactoryContractMsg};
    use crate::state::{Config, CONFIG, TRUSTED_CONTRACT_CALLERS};

    fn mock_dependencies_factory(
    ) -> OwnedDeps<MockStorage, MockApi, MockQuerier<FactoryQuery>, FactoryQuery> {
        OwnedDeps {
            storage: MockStorage::default(),
            api: MockApi::default().with_prefix("wf"),
            querier: MockQuerier::<FactoryQuery>::new(&[]),
            custom_query_type: PhantomData,
        }
    }

    fn init_storage_with_owner(store: &mut dyn cosmwasm_std::Storage, owner: &str) {
        CONFIG
            .save(store, &Config { is_tf: true })
            .unwrap();
        initialize_owner(store, &MockApi::default().with_prefix("wf"), Some(owner)).unwrap();
    }

    fn bech32_addr(hrp: &str) -> String {
        use bech32::{Bech32, primitives::hrp::Hrp};
        let data = vec![0u8; 20];
        bech32::encode::<Bech32>(Hrp::parse(hrp).unwrap(), &data)
            .unwrap()
            .to_string()
    }

    fn bech32_addr_with_seed(hrp: &str, seed: u8) -> String {
        use bech32::{Bech32, primitives::hrp::Hrp};
        let data = vec![seed; 20];
        bech32::encode::<Bech32>(Hrp::parse(hrp).unwrap(), &data)
            .unwrap()
            .to_string()
    }

    // --- add_trusted_caller tests ---

    #[test]
    fn add_trusted_caller_rejects_non_owner() {
        let mut deps = mock_dependencies_factory();
        let owner = bech32_addr("wf");
        init_storage_with_owner(deps.as_mut().storage, &owner);

        let non_owner = bech32_addr_with_seed("wf", 1);
        let info = message_info(&Addr::unchecked(&non_owner), &[]);
        let msg = ExecuteMsg::AddTrustedCaller {
            addr: bech32_addr_with_seed("wf", 2),
        };

        let err = execute(deps.as_mut(), mock_env(), info, msg).unwrap_err();
        assert!(err.to_string().to_lowercase().contains("owner"));
    }

    #[test]
    fn add_trusted_caller_rejects_non_contract_address() {
        let mut deps = mock_dependencies_factory();
        let owner = bech32_addr("wf");
        init_storage_with_owner(deps.as_mut().storage, &owner);

        let info = message_info(&Addr::unchecked(&owner), &[]);
        let user_addr = bech32_addr_with_seed("wf", 3);
        let msg = ExecuteMsg::AddTrustedCaller {
            addr: user_addr,
        };

        let err = execute(deps.as_mut(), mock_env(), info, msg).unwrap_err();
        assert!(err.to_string().contains("not a contract"));
    }

    #[test]
    fn add_trusted_caller_rejects_invalid_bech32() {
        let mut deps = mock_dependencies_factory();
        let owner = bech32_addr("wf");
        init_storage_with_owner(deps.as_mut().storage, &owner);

        let info = message_info(&Addr::unchecked(&owner), &[]);
        let msg = ExecuteMsg::AddTrustedCaller {
            addr: "not-a-valid-address".to_string(),
        };

        let err = execute(deps.as_mut(), mock_env(), info, msg).unwrap_err();
        assert!(err.to_string().to_lowercase().contains("error") || err.to_string().to_lowercase().contains("invalid"));
    }

    // --- remove_trusted_caller tests ---

    #[test]
    fn remove_trusted_caller_rejects_non_owner() {
        let mut deps = mock_dependencies_factory();
        let owner = bech32_addr("wf");
        init_storage_with_owner(deps.as_mut().storage, &owner);

        let non_owner = bech32_addr_with_seed("wf", 1);
        let info = message_info(&Addr::unchecked(&non_owner), &[]);
        let msg = ExecuteMsg::RemoveTrustedCaller {
            addr: bech32_addr_with_seed("wf", 2),
        };

        let err = execute(deps.as_mut(), mock_env(), info, msg).unwrap_err();
        assert!(err.to_string().to_lowercase().contains("owner"));
    }

    #[test]
    fn remove_trusted_caller_sets_existing_true_to_false() {
        let mut deps = mock_dependencies_factory();
        let owner = bech32_addr("wf");
        init_storage_with_owner(deps.as_mut().storage, &owner);

        let contract_addr = deps.api.addr_validate(&bech32_addr_with_seed("wf", 5)).unwrap();
        TRUSTED_CONTRACT_CALLERS
            .save(deps.as_mut().storage, &contract_addr, &true)
            .unwrap();

        let info = message_info(&Addr::unchecked(&owner), &[]);
        let msg = ExecuteMsg::RemoveTrustedCaller {
            addr: contract_addr.to_string(),
        };
        execute(deps.as_mut(), mock_env(), info, msg).unwrap();

        let val = TRUSTED_CONTRACT_CALLERS
            .load(deps.as_ref().storage, &contract_addr)
            .unwrap();
        assert!(!val);
    }

    #[test]
    fn remove_trusted_caller_noop_when_already_false() {
        let mut deps = mock_dependencies_factory();
        let owner = bech32_addr("wf");
        init_storage_with_owner(deps.as_mut().storage, &owner);

        let contract_addr = deps.api.addr_validate(&bech32_addr_with_seed("wf", 5)).unwrap();
        TRUSTED_CONTRACT_CALLERS
            .save(deps.as_mut().storage, &contract_addr, &false)
            .unwrap();

        let info = message_info(&Addr::unchecked(&owner), &[]);
        let msg = ExecuteMsg::RemoveTrustedCaller {
            addr: contract_addr.to_string(),
        };
        execute(deps.as_mut(), mock_env(), info, msg).unwrap();

        let val = TRUSTED_CONTRACT_CALLERS
            .load(deps.as_ref().storage, &contract_addr)
            .unwrap();
        assert!(!val);
    }

    #[test]
    fn remove_trusted_caller_noop_when_never_added() {
        let mut deps = mock_dependencies_factory();
        let owner = bech32_addr("wf");
        init_storage_with_owner(deps.as_mut().storage, &owner);

        let info = message_info(&Addr::unchecked(&owner), &[]);
        let msg = ExecuteMsg::RemoveTrustedCaller {
            addr: bech32_addr_with_seed("wf", 7),
        };
        let res = execute(deps.as_mut(), mock_env(), info, msg);
        assert!(res.is_ok());
    }

    #[test]
    fn remove_trusted_caller_rejects_invalid_bech32() {
        let mut deps = mock_dependencies_factory();
        let owner = bech32_addr("wf");
        init_storage_with_owner(deps.as_mut().storage, &owner);

        let info = message_info(&Addr::unchecked(&owner), &[]);
        let msg = ExecuteMsg::RemoveTrustedCaller {
            addr: "invalid-addr".to_string(),
        };

        let err = execute(deps.as_mut(), mock_env(), info, msg).unwrap_err();
        assert!(err.to_string().to_lowercase().contains("error") || err.to_string().to_lowercase().contains("invalid"));
    }

    // --- is_trusted_caller query tests ---

    #[test]
    fn is_trusted_caller_returns_true_for_trusted() {
        let mut deps = mock_dependencies_factory();
        init_storage_with_owner(deps.as_mut().storage, &bech32_addr("wf"));

        let contract_addr = deps.api.addr_validate(&bech32_addr_with_seed("wf", 5)).unwrap();
        TRUSTED_CONTRACT_CALLERS
            .save(deps.as_mut().storage, &contract_addr, &true)
            .unwrap();

        let bin = crate::query::query(
            deps.as_ref(),
            mock_env(),
            crate::msg::QueryMsg::IsTrustedCaller {
                addr: contract_addr.to_string(),
            },
        )
            .unwrap();
        let resp: IsTrustedCallerResponse = cosmwasm_std::from_json(&bin).unwrap();
        assert!(resp.trusted);
        assert_eq!(resp.addr, contract_addr.to_string());
    }

    #[test]
    fn is_trusted_caller_returns_false_for_revoked() {
        let mut deps = mock_dependencies_factory();
        init_storage_with_owner(deps.as_mut().storage, &bech32_addr("wf"));

        let contract_addr = deps.api.addr_validate(&bech32_addr_with_seed("wf", 5)).unwrap();
        TRUSTED_CONTRACT_CALLERS
            .save(deps.as_mut().storage, &contract_addr, &false)
            .unwrap();

        let bin = crate::query::query(
            deps.as_ref(),
            mock_env(),
            crate::msg::QueryMsg::IsTrustedCaller {
                addr: contract_addr.to_string(),
            },
        )
            .unwrap();
        let resp: IsTrustedCallerResponse = cosmwasm_std::from_json(&bin).unwrap();
        assert!(!resp.trusted);
    }

    #[test]
    fn is_trusted_caller_returns_false_for_unknown_address() {
        let mut deps = mock_dependencies_factory();
        init_storage_with_owner(deps.as_mut().storage, &bech32_addr("wf"));

        let bin = crate::query::query(
            deps.as_ref(),
            mock_env(),
            crate::msg::QueryMsg::IsTrustedCaller {
                addr: bech32_addr_with_seed("wf", 99),
            },
        )
            .unwrap();
        let resp: IsTrustedCallerResponse = cosmwasm_std::from_json(&bin).unwrap();
        assert!(!resp.trusted);
    }

    // --- all_trusted_callers query tests ---

    #[test]
    fn all_trusted_callers_returns_empty_when_none_added() {
        let mut deps = mock_dependencies_factory();
        init_storage_with_owner(deps.as_mut().storage, &bech32_addr("wf"));

        let bin = crate::query::query(
            deps.as_ref(),
            mock_env(),
            crate::msg::QueryMsg::AllTrustedCallers {},
        )
            .unwrap();
        let resp: AllTrustedCallersResponse = cosmwasm_std::from_json(&bin).unwrap();
        assert!(resp.callers.is_empty());
    }

    #[test]
    fn all_trusted_callers_returns_all_entries_with_status() {
        let mut deps = mock_dependencies_factory();
        init_storage_with_owner(deps.as_mut().storage, &bech32_addr("wf"));

        let addr1 = deps.api.addr_validate(&bech32_addr_with_seed("wf", 1)).unwrap();
        let addr2 = deps.api.addr_validate(&bech32_addr_with_seed("wf", 2)).unwrap();
        TRUSTED_CONTRACT_CALLERS.save(deps.as_mut().storage, &addr1, &true).unwrap();
        TRUSTED_CONTRACT_CALLERS.save(deps.as_mut().storage, &addr2, &true).unwrap();

        let bin = crate::query::query(
            deps.as_ref(),
            mock_env(),
            crate::msg::QueryMsg::AllTrustedCallers {},
        )
            .unwrap();
        let resp: AllTrustedCallersResponse = cosmwasm_std::from_json(&bin).unwrap();
        assert_eq!(resp.callers.len(), 2);
        assert!(resp.callers.iter().all(|c| c.trusted));
    }

    #[test]
    fn all_trusted_callers_includes_revoked_entries() {
        let mut deps = mock_dependencies_factory();
        init_storage_with_owner(deps.as_mut().storage, &bech32_addr("wf"));

        let addr1 = deps.api.addr_validate(&bech32_addr_with_seed("wf", 1)).unwrap();
        let addr2 = deps.api.addr_validate(&bech32_addr_with_seed("wf", 2)).unwrap();
        TRUSTED_CONTRACT_CALLERS.save(deps.as_mut().storage, &addr1, &true).unwrap();
        TRUSTED_CONTRACT_CALLERS.save(deps.as_mut().storage, &addr2, &false).unwrap();

        let bin = crate::query::query(
            deps.as_ref(),
            mock_env(),
            crate::msg::QueryMsg::AllTrustedCallers {},
        )
            .unwrap();
        let resp: AllTrustedCallersResponse = cosmwasm_std::from_json(&bin).unwrap();
        assert_eq!(resp.callers.len(), 2);
        let revoked_count = resp.callers.iter().filter(|c| !c.trusted).count();
        assert_eq!(revoked_count, 1);
    }

    // --- get_sender integration tests ---

    #[test]
    fn mint_uses_orig_sender_when_caller_is_trusted() {
        let mut deps = mock_dependencies_factory();
        init_storage_with_owner(deps.as_mut().storage, &bech32_addr("wf"));

        let caller = deps.api.addr_validate(&bech32_addr_with_seed("wf", 10)).unwrap();
        TRUSTED_CONTRACT_CALLERS.save(deps.as_mut().storage, &caller, &true).unwrap();

        let orig = bech32_addr_with_seed("wf", 20);
        let dest = bech32_addr_with_seed("wf", 30);
        let info = message_info(&caller, &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::Mint {
            orig_sender: Some(orig.clone()),
            address: dest,
            denom: "uwfUSD".to_string(),
            value: "10".to_string(),
        });

        let res = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        let sender_attr = res
            .attributes
            .iter()
            .find(|a| a.key.contains("sender"))
            .unwrap();
        assert_eq!(sender_attr.value, orig);
    }

    #[test]
    fn mint_ignores_orig_sender_when_caller_is_not_trusted() {
        let mut deps = mock_dependencies_factory();
        init_storage_with_owner(deps.as_mut().storage, &bech32_addr("wf"));

        let caller = deps.api.addr_validate(&bech32_addr_with_seed("wf", 10)).unwrap();
        // caller is NOT in the trusted map

        let orig = bech32_addr_with_seed("wf", 20);
        let dest = bech32_addr_with_seed("wf", 30);
        let info = message_info(&caller, &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::Mint {
            orig_sender: Some(orig),
            address: dest,
            denom: "uwfUSD".to_string(),
            value: "10".to_string(),
        });

        let res = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        let sender_attr = res
            .attributes
            .iter()
            .find(|a| a.key.contains("sender"))
            .unwrap();
        assert_eq!(sender_attr.value, caller.to_string());
    }

    #[test]
    fn mint_ignores_orig_sender_when_caller_is_revoked() {
        let mut deps = mock_dependencies_factory();
        init_storage_with_owner(deps.as_mut().storage, &bech32_addr("wf"));

        let caller = deps.api.addr_validate(&bech32_addr_with_seed("wf", 10)).unwrap();
        TRUSTED_CONTRACT_CALLERS.save(deps.as_mut().storage, &caller, &false).unwrap();

        let orig = bech32_addr_with_seed("wf", 20);
        let dest = bech32_addr_with_seed("wf", 30);
        let info = message_info(&caller, &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::Mint {
            orig_sender: Some(orig),
            address: dest,
            denom: "uwfUSD".to_string(),
            value: "10".to_string(),
        });

        let res = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        let sender_attr = res
            .attributes
            .iter()
            .find(|a| a.key.contains("sender"))
            .unwrap();
        assert_eq!(sender_attr.value, caller.to_string());
    }

    #[test]
    fn remove_trusted_caller_response_attributes() {
        let mut deps = mock_dependencies_factory();
        let owner = bech32_addr("wf");
        init_storage_with_owner(deps.as_mut().storage, &owner);

        let contract_addr = deps.api.addr_validate(&bech32_addr_with_seed("wf", 5)).unwrap();
        TRUSTED_CONTRACT_CALLERS
            .save(deps.as_mut().storage, &contract_addr, &true)
            .unwrap();

        let info = message_info(&Addr::unchecked(&owner), &[]);
        let msg = ExecuteMsg::RemoveTrustedCaller {
            addr: contract_addr.to_string(),
        };
        let res = execute(deps.as_mut(), mock_env(), info, msg).unwrap();

        let action_attr = res
            .attributes
            .iter()
            .find(|a| a.key.contains("action"))
            .unwrap();
        assert_eq!(action_attr.value, "remove_trusted_caller");

        let addr_attr = res
            .attributes
            .iter()
            .find(|a| a.key.contains("addr"))
            .unwrap();
        assert_eq!(addr_attr.value, contract_addr.to_string());
    }

    #[test]
    fn remove_then_query_shows_false() {
        let mut deps = mock_dependencies_factory();
        let owner = bech32_addr("wf");
        init_storage_with_owner(deps.as_mut().storage, &owner);

        let contract_addr = deps.api.addr_validate(&bech32_addr_with_seed("wf", 5)).unwrap();
        TRUSTED_CONTRACT_CALLERS
            .save(deps.as_mut().storage, &contract_addr, &true)
            .unwrap();

        let info = message_info(&Addr::unchecked(&owner), &[]);
        let msg = ExecuteMsg::RemoveTrustedCaller {
            addr: contract_addr.to_string(),
        };
        execute(deps.as_mut(), mock_env(), info, msg).unwrap();

        let bin = crate::query::query(
            deps.as_ref(),
            mock_env(),
            crate::msg::QueryMsg::IsTrustedCaller {
                addr: contract_addr.to_string(),
            },
        )
            .unwrap();
        let resp: IsTrustedCallerResponse = cosmwasm_std::from_json(&bin).unwrap();
        assert!(!resp.trusted);
    }
}


