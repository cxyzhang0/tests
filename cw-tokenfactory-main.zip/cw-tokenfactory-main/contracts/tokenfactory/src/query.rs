use cosmwasm_std::{to_json_binary, Binary, Deps, Env, StdResult};
use tokenfactory_bindings::querier::FQuerier;
use tokenfactory_bindings::query::{BankQuery, FactoryQuery, FeegrantQuery, TokenfactoryQuery};

use crate::msg::QueryMsg;
use crate::state::CONFIG;
#[allow(unused_imports)]
use cosmwasm_std::entry_point;

#[cfg_attr(not(feature = "library"), entry_point)]
pub fn query(deps: Deps<FactoryQuery>, env: Env, msg: QueryMsg) -> StdResult<Binary> {
    let tf_q = FQuerier::new(&deps.querier);
    let is_tf = CONFIG.load(deps.storage)?.is_tf;
    match msg {
        QueryMsg::Tf(tf) => match tf {
            TokenfactoryQuery::Params {} => to_json_binary(&tf_q.params(is_tf)?),
            TokenfactoryQuery::Owner {} => to_json_binary(&tf_q.owner(is_tf)?),
            TokenfactoryQuery::MasterMinter {} => to_json_binary(&tf_q.master_minter(is_tf)?),
            TokenfactoryQuery::MinterController { controller, minter } => {
                to_json_binary(&tf_q.minter_controller(controller, minter, is_tf)?)
            }
            TokenfactoryQuery::AllMinterControllers {} => {
                to_json_binary(&tf_q.all_minter_controllers(is_tf)?)
            }
            TokenfactoryQuery::MintingDenom { denom } => to_json_binary(&tf_q.minting_denom(denom, is_tf)?),
            TokenfactoryQuery::AllMintingDenoms {} => to_json_binary(&tf_q.all_minting_denoms(is_tf)?),
            TokenfactoryQuery::Minters { address, denom } => {
                to_json_binary(&tf_q.minters(address, denom, is_tf)?)
            }
            TokenfactoryQuery::AllMinters {} => to_json_binary(&tf_q.all_minters(is_tf)?),
            TokenfactoryQuery::Blacklister {} => to_json_binary(&tf_q.blacklister(is_tf)?),
            TokenfactoryQuery::Pauser {} => to_json_binary(&tf_q.pauser(is_tf)?),
            TokenfactoryQuery::Blacklisted { address } => {
                to_json_binary(&tf_q.blacklisted(address, is_tf)?)
            }
            TokenfactoryQuery::AllBlacklisted {} => to_json_binary(&tf_q.all_blacklisted(is_tf)?),
            TokenfactoryQuery::Paused {} => to_json_binary(&tf_q.paused(is_tf)?),
        },
        QueryMsg::Bank(bank) => match bank {
            BankQuery::DenomMetadata { denom } => to_json_binary(&tf_q.denom_metadata(denom)?),
            BankQuery::AllDenomMetadata {} => to_json_binary(&tf_q.all_denom_metadata()?),
            BankQuery::FindDenomMetadata { base_denom, denom } => {
                to_json_binary(&tf_q.find_denom_metadata(base_denom, denom)?)
            }
            BankQuery::FindMetadataForDenom { denom } => {
                to_json_binary(&tf_q.find_metadata_for_denom(denom)?)
            }
        },
        QueryMsg::Feegrant(feegrant) => match feegrant {
            FeegrantQuery::FeeBasicAllowance { granter, grantee } => {
                to_json_binary(&tf_q.fee_basic_allowance(granter, grantee)?)
            }
        },
        /*
        QueryMsg::Params {} => to_json_binary(&tf_q.params(is_tf)?),
        QueryMsg::Owner {} => to_json_binary(&tf_q.owner(is_tf)?),
        QueryMsg::MasterMinter {} => to_json_binary(&tf_q.master_minter(is_tf)?),
        QueryMsg::MinterController { address } => to_json_binary(&tf_q.minter_controller(address, is_tf)?),
        QueryMsg::AllMinterControllers {} => to_json_binary(&tf_q.all_minter_controllers(is_tf)?),
        QueryMsg::MintingDenom {} => to_json_binary(&tf_q.minting_denom(is_tf)?),
        QueryMsg::Minters { address } => to_json_binary(&tf_q.minters(address, is_tf)?),
        QueryMsg::AllMinters {} => to_json_binary(&tf_q.all_minters(is_tf)?),
        QueryMsg::Blacklister {} => to_json_binary(&tf_q.blacklister(is_tf)?),
        QueryMsg::Pauser {} => to_json_binary(&tf_q.pauser(is_tf)?),
        QueryMsg::Blacklisted { address } => to_json_binary(&tf_q.blacklisted(address, is_tf)?),
        QueryMsg::AllBlacklisted {} => to_json_binary(&tf_q.all_blacklisted(is_tf)?),
        QueryMsg::Paused {} => to_json_binary(&tf_q.paused(is_tf)?),
        */
        QueryMsg::Config {} => to_json_binary(&query::get_config(deps, env)?),
    }
}

#[allow(clippy::module_inception)]
mod query {
    use cosmwasm_std::{Deps, Env, StdResult};

    use tokenfactory_bindings::query::FactoryQuery;

    use crate::state::{Config, CONFIG};

    pub(super) fn get_config(deps: Deps<FactoryQuery>, _env: Env) -> StdResult<Config> {
        let config = CONFIG.load(deps.storage)?;
        Ok(config)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use cosmwasm_std::{testing::{mock_env, MockApi, MockQuerier, MockStorage}, from_binary, OwnedDeps, Addr};
    use std::marker::PhantomData;
    use crate::state::Config;

    // Same pattern you used for contract.rs (custom query type)
    fn mock_dependencies_factory(
    ) -> OwnedDeps<MockStorage, MockApi, MockQuerier<FactoryQuery>, FactoryQuery> {
        OwnedDeps {
            storage: MockStorage::default(),
            api: MockApi::default(),
            querier: MockQuerier::<FactoryQuery>::new(&[]),
            custom_query_type: PhantomData,
        }
    }

    fn init_storage(store: &mut dyn cosmwasm_std::Storage) {
        CONFIG
            .save(
                store,
                &Config {
                    owner: Addr::unchecked("owner"),
                    is_tf: true,
                },
            )
            .unwrap();
    }

    #[test]
    fn query_config_returns_saved_config() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let bin = query(deps.as_ref(), mock_env(), QueryMsg::Config {}).unwrap();

        // Common pattern: ConfigResponse { master_minter: String, fee_granter: String }
        let resp: Config = from_binary(&bin).unwrap();
        assert!(resp.is_tf);
    }

    #[test]
    fn query_config_is_deterministic() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let a = query(deps.as_ref(), mock_env(), QueryMsg::Config {}).unwrap();
        let b = query(deps.as_ref(), mock_env(), QueryMsg::Config {}).unwrap();
        assert_eq!(a, b);
    }
}

#[cfg(test)]
mod tests2 {
    use super::*;

    use std::marker::PhantomData;

    use cosmwasm_std::{
        from_json, to_json_binary, Binary, Coin, ContractResult, OwnedDeps, SystemResult,
        testing::{MockApi, MockQuerier, MockStorage},
    };
    use cosmwasm_std::testing::mock_env;
    use tokenfactory_bindings::query::{
        BankQuery, BlacklistedResponse, DenomMetadata, DenomMetadataResponse, DenomUnit,
        FactoryQuery, FeeBasicAllowanceResponse, FeeBasicGrant, FeegrantQuery, MintingDenomResponse,
        OwnerResponse, TokenfactoryQuery,
    };

    use crate::state::{Config, CONFIG};

    fn mock_deps_with_factory_handler(
    ) -> OwnedDeps<MockStorage, MockApi, MockQuerier<FactoryQuery>, FactoryQuery> {
        let querier: MockQuerier<FactoryQuery> =
            MockQuerier::new(&[]).with_custom_handler(|q| SystemResult::Ok(factory_query_execute(q)));

        OwnedDeps {
            storage: MockStorage::default(),
            api: MockApi::default(),
            querier,
            custom_query_type: PhantomData,
        }
    }

    fn init_storage(store: &mut dyn cosmwasm_std::Storage) {
        CONFIG
            .save(
                store,
                &Config {
                    owner: cosmwasm_std::Addr::unchecked("owner"),
                    is_tf: true,
                },
            )
            .unwrap();
    }

    fn factory_query_execute(q: &FactoryQuery) -> ContractResult<Binary> {
        match q {
            FactoryQuery::Tf(tf) => match tf {
                TokenfactoryQuery::Owner {} => to_json_binary(&OwnerResponse {
                    address: "owner_from_mock".to_string(),
                })
                    .into(),

                TokenfactoryQuery::MintingDenom { denom } => to_json_binary(&MintingDenomResponse {
                    denom: denom.clone(),
                })
                    .into(),

                TokenfactoryQuery::Blacklisted { address } => to_json_binary(&BlacklistedResponse {
                    address: address.clone(),
                })
                    .into(),

                // Anything else: return a harmless default response that won’t be deserialized by our tests
                _ => to_json_binary(&OwnerResponse {
                    address: "default".to_string(),
                })
                    .into(),
            },

            FactoryQuery::Bank(bank) => match bank {
                BankQuery::DenomMetadata { denom } => {
                    let md = DenomMetadata {
                        description: "mock".to_string(),
                        denom_units: vec![DenomUnit {
                            denom: denom.clone(),
                            exponent: Some(0),
                            aliases: None,
                        }],
                        base: denom.clone(),
                        display: denom.clone(),
                        name: "MockToken".to_string(),
                        symbol: "MOCK".to_string(),
                        uri: None,
                        uri_hash: None,
                    };

                    to_json_binary(&DenomMetadataResponse { metadata: md }).into()
                }

                // Not used by these tests
                _ => to_json_binary(&DenomMetadataResponse {
                    metadata: DenomMetadata {
                        description: "default".to_string(),
                        denom_units: vec![DenomUnit {
                            denom: "default".to_string(),
                            exponent: Some(0),
                            aliases: None,
                        }],
                        base: "default".to_string(),
                        display: "default".to_string(),
                        name: "Default".to_string(),
                        symbol: "DEF".to_string(),
                        uri: None,
                        uri_hash: None,
                    },
                })
                    .into(),
            },

            FactoryQuery::Feegrant(fg) => match fg {
                FeegrantQuery::FeeBasicAllowance { granter, grantee } => {
                    to_json_binary(&FeeBasicAllowanceResponse {
                        allowance: FeeBasicGrant {
                            granter: granter.clone(),
                            grantee: grantee.clone(),
                            allowance: Coin::new(123u128, "uatom"),
                            expiration: "never".to_string(),
                        },
                    })
                        .into()
                }
            },
        }
    }

    #[test]
    fn query_tf_owner_routes_to_fquerier() {
        let mut deps = mock_deps_with_factory_handler();
        init_storage(deps.as_mut().storage);

        let bin = query(
            deps.as_ref(),
            mock_env(),
            QueryMsg::Tf(TokenfactoryQuery::Owner {}),
        )
            .unwrap();

        let resp: OwnerResponse = from_json(&bin).unwrap();
        assert_eq!(resp.address, "owner_from_mock");
    }

    #[test]
    fn query_tf_minting_denom_routes_to_fquerier() {
        let mut deps = mock_deps_with_factory_handler();
        init_storage(deps.as_mut().storage);

        let bin = query(
            deps.as_ref(),
            mock_env(),
            QueryMsg::Tf(TokenfactoryQuery::MintingDenom {
                denom: "uwfUSD".to_string(),
            }),
        )
            .unwrap();

        let resp: MintingDenomResponse = from_json(&bin).unwrap();
        assert_eq!(resp.denom, "uwfUSD");
    }

    #[test]
    fn query_tf_blacklisted_routes_to_fquerier() {
        let mut deps = mock_deps_with_factory_handler();
        init_storage(deps.as_mut().storage);

        let bin = query(
            deps.as_ref(),
            mock_env(),
            QueryMsg::Tf(TokenfactoryQuery::Blacklisted {
                address: "addr1".to_string(),
            }),
        )
            .unwrap();

        let resp: BlacklistedResponse = from_json(&bin).unwrap();
        assert_eq!(resp.address, "addr1");
    }

    #[test]
    fn query_bank_denom_metadata_routes_to_fquerier() {
        let mut deps = mock_deps_with_factory_handler();
        init_storage(deps.as_mut().storage);

        let bin = query(
            deps.as_ref(),
            mock_env(),
            QueryMsg::Bank(BankQuery::DenomMetadata {
                denom: "uwfUSD".to_string(),
            }),
        )
            .unwrap();

        let resp: DenomMetadataResponse = from_json(&bin).unwrap();
        assert_eq!(resp.metadata.base, "uwfUSD");
        assert_eq!(resp.metadata.symbol, "MOCK");
    }

    #[test]
    fn query_feegrant_basic_allowance_routes_to_fquerier() {
        let mut deps = mock_deps_with_factory_handler();
        init_storage(deps.as_mut().storage);

        let bin = query(
            deps.as_ref(),
            mock_env(),
            QueryMsg::Feegrant(FeegrantQuery::FeeBasicAllowance {
                granter: "granter1".to_string(),
                grantee: "grantee1".to_string(),
            }),
        )
            .unwrap();

        let resp: FeeBasicAllowanceResponse = from_json(&bin).unwrap();
        assert_eq!(resp.allowance.granter, "granter1");
        assert_eq!(resp.allowance.grantee, "grantee1");
        assert_eq!(resp.allowance.allowance.amount.to_string(), "123");
        assert_eq!(resp.allowance.allowance.denom, "uatom");
    }

    #[test]
    fn query_config_returns_saved_config() {
        let mut deps = mock_deps_with_factory_handler();
        init_storage(deps.as_mut().storage);

        let bin = query(deps.as_ref(), mock_env(), QueryMsg::Config {}).unwrap();
        let cfg: Config = from_json(&bin).unwrap();

        assert_eq!(cfg.owner, cosmwasm_std::Addr::unchecked("owner"));
        assert!(cfg.is_tf);
    }
}

