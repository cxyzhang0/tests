#[cfg(not(feature = "library"))]
use cosmwasm_std::entry_point;
use cosmwasm_std::{DepsMut, Env, MessageInfo, Response, StdError, StdResult};
use cw2::set_contract_version;
use cw_ownable::initialize_owner;
use tokenfactory_bindings::msg::{FactoryMsg, FeegrantMsg, TokenfactoryMsg};
use tokenfactory_bindings::query::FactoryQuery;

use crate::msg::{ExecuteMsg, FeegrantContractMsg, InstantiateMsg, TokenfactoryContractMsg};
use crate::state::{Config, CONFIG};

pub(crate) const CONTRACT_NAME: &str = "crates.io:tokenfactory-integration";
pub(crate) const CONTRACT_VERSION: &str = env!("CARGO_PKG_VERSION");

#[cfg_attr(not(feature = "library"), entry_point)]
pub fn instantiate(
    deps: DepsMut,
    _env: Env,
    info: MessageInfo,
    msg: InstantiateMsg,
) -> StdResult<Response> {
    set_contract_version(deps.storage, CONTRACT_NAME, CONTRACT_VERSION)?;
    initialize_owner(deps.storage, deps.api, Some(info.sender.as_str()))?;

    let config = Config { is_tf: msg.is_tf };
    CONFIG.save(deps.storage, &config)?;

    Ok(Response::new()
        .add_attribute(
            format!("{}_{}", crate::PACKAGE_NAME, "action"),
            "instantiate",
        )
        .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "owner"), info.sender)
        .add_attribute(
            format!("{}_{}", crate::PACKAGE_NAME, "is_tf"),
            msg.is_tf.to_string(),
        ))
}

#[cfg_attr(not(feature = "library"), entry_point)]
pub fn execute(
    deps: DepsMut<FactoryQuery>,
    env: Env,
    info: MessageInfo,
    msg: ExecuteMsg,
) -> Result<Response<FactoryMsg>, StdError> {
    let is_tf = CONFIG.load(deps.storage)?.is_tf;
    match msg {
        ExecuteMsg::Tf(TokenfactoryContractMsg::UpdateMasterMinter { address }) => {
            execute::update_master_minter(info.sender, address, is_tf)
        }
        ExecuteMsg::Tf(TokenfactoryContractMsg::ConfigureMinterController {
            controller,
            minter,
        }) => execute::configure_minter_controller(info.sender, controller, minter, is_tf),
        ExecuteMsg::Tf(TokenfactoryContractMsg::RemoveMinterController { controller, minter }) => {
            execute::remove_minter_controller(info.sender, controller, minter, is_tf)
        }
        ExecuteMsg::Tf(TokenfactoryContractMsg::ConfigureMinter {
            address,
            allowance_denom,
            allowance_value,
        }) => execute::configure_minter(
            info.sender,
            address,
            allowance_denom,
            allowance_value,
            is_tf,
        ),
        ExecuteMsg::Tf(TokenfactoryContractMsg::RemoveMinter { address, denom }) => {
            execute::remove_minter(info.sender, address, denom, is_tf)
        }
        ExecuteMsg::Tf(TokenfactoryContractMsg::UpdateBlacklister { address }) => {
            execute::update_blacklister(info.sender, address, is_tf)
        }
        ExecuteMsg::Tf(TokenfactoryContractMsg::Blacklist { address }) => {
            execute::blacklist(info.sender, address, is_tf)
        }
        ExecuteMsg::Tf(TokenfactoryContractMsg::Unblacklist { address }) => {
            execute::unblacklist(info.sender, address, is_tf)
        }
        ExecuteMsg::Tf(TokenfactoryContractMsg::UpdatePauser { address }) => {
            execute::update_pauser(info.sender, address, is_tf)
        }
        ExecuteMsg::Tf(TokenfactoryContractMsg::Pause {}) => execute::pause(info.sender, is_tf),
        ExecuteMsg::Tf(TokenfactoryContractMsg::Unpause {}) => execute::unpause(info.sender, is_tf),
        ExecuteMsg::Tf(TokenfactoryContractMsg::Mint {
            orig_sender,
            address,
            denom,
            value,
        }) => execute::mint(deps, env, info, orig_sender, address, denom, value, is_tf),
        ExecuteMsg::Tf(TokenfactoryContractMsg::Burn {
            orig_sender,
            denom,
            value,
        }) => execute::burn(deps, env, info, orig_sender, denom, value, is_tf),
        ExecuteMsg::Tf(TokenfactoryContractMsg::SetDenomMetadata {
            orig_sender,
            metadata,
        }) => execute::set_denom_metadata(deps, env, info, orig_sender, metadata),
        ExecuteMsg::Redeem {
            orig_sender,
            minter_address,
            denom,
            value,
        } => execute::redeem(
            deps,
            env,
            info,
            orig_sender,
            minter_address,
            denom,
            value,
            is_tf,
        ),
        ExecuteMsg::Feegrant(FeegrantContractMsg::GrantFeeBasicAllowance {
            granter,
            grantee,
            allowance_denom,
            allowance_value,
            hours_to_expire,
        }) => execute::grant_fee_basic_allowance(
            deps,
            info.sender,
            granter,
            grantee,
            allowance_denom,
            allowance_value,
            hours_to_expire,
        ),
        ExecuteMsg::Feegrant(FeegrantContractMsg::RevokeFeeAllowance { granter, grantee }) => {
            execute::revoke_fee_allowance(deps, info.sender, granter, grantee)
        }
        ExecuteMsg::AddTrustedCaller { addr } => execute::add_trusted_caller(deps, info, addr),
        ExecuteMsg::RemoveTrustedCaller { addr } => {
            execute::remove_trusted_caller(deps, info, addr)
        }
    }
}

pub mod execute {
    use cosmwasm_std::{Addr, BankMsg, Coin};

    use super::*;
    use crate::state::TRUSTED_CONTRACT_CALLERS;
    use tokenfactory_bindings::msg::FactoryMsg;
    use tokenfactory_bindings::query::{DenomMetadata, FactoryQuery};

    pub(super) fn update_master_minter(
        sender: Addr,
        address: String,
        _: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let msg = {
            FactoryMsg::Tf(TokenfactoryMsg::UpdateMasterMinter {
                signer: sender.to_string(),
                address: address.to_owned(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "action"),
                "update_master_minter",
            )
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "address"), address))
    }

    pub(super) fn configure_minter_controller(
        sender: Addr,
        controller: String,
        minter: String,
        _: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let msg = {
            FactoryMsg::Tf(TokenfactoryMsg::ConfigureMinterController {
                signer: sender.to_string(),
                controller: controller.to_owned(),
                minter: minter.to_owned(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "action"),
                "configure_minter_controller",
            )
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "controller"),
                controller,
            )
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "minter"), minter))
    }

    pub(super) fn remove_minter_controller(
        sender: Addr,
        controller: String,
        minter: String,
        _: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let msg = {
            FactoryMsg::Tf(TokenfactoryMsg::RemoveMinterController {
                signer: sender.to_string(),
                controller: controller.to_owned(),
                minter: minter.to_owned(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "action"),
                "remove_minter_controller",
            )
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "controller"),
                controller,
            )
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "minter"), minter))
    }

    pub(super) fn configure_minter(
        sender: Addr,
        address: String,
        allowance_denom: String,
        allowance_value: String,
        _: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let allowance_value: u128 = allowance_value
            .parse()
            .map_err(|_| StdError::generic_err("allowance_value must be a valid u128 number"))?;

        let allowance = Coin::new(allowance_value, allowance_denom);

        let msg = {
            FactoryMsg::Tf(TokenfactoryMsg::ConfigureMinter {
                signer: sender.to_string(),
                address: address.to_owned(),
                allowance: allowance.to_owned(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "action"),
                "configure_minter",
            )
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "address"), address)
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "allowance_amount"),
                allowance.amount.to_string(),
            )
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "allowance_denom"),
                allowance.denom.to_string(),
            ))
    }

    pub(super) fn remove_minter(
        sender: Addr,
        address: String,
        denom: String,
        _: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let msg = {
            FactoryMsg::Tf(TokenfactoryMsg::RemoveMinter {
                signer: sender.to_string(),
                address: address.to_owned(),
                denom: denom.to_owned(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "action"),
                "remove_minter",
            )
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "address"), address)
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "denom"), denom))
    }

    pub(super) fn update_blacklister(
        sender: Addr,
        address: String,
        _: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let msg = {
            FactoryMsg::Tf(TokenfactoryMsg::UpdateBlacklister {
                signer: sender.to_string(),
                address: address.to_owned(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "action"),
                "update_blacklister",
            )
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "address"), address))
    }

    pub(super) fn blacklist(
        sender: Addr,
        address: String,
        _: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let msg = {
            FactoryMsg::Tf(TokenfactoryMsg::Blacklist {
                signer: sender.to_string(),
                address: address.to_owned(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "action"), "blacklist")
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "address"), address))
    }

    pub(super) fn unblacklist(
        sender: Addr,
        address: String,
        _: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let msg = {
            FactoryMsg::Tf(TokenfactoryMsg::Unblacklist {
                signer: sender.to_string(),
                address: address.to_owned(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "action"),
                "unblacklist",
            )
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "address"), address))
    }

    pub(super) fn update_pauser(
        sender: Addr,
        address: String,
        _: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let msg = {
            FactoryMsg::Tf(TokenfactoryMsg::UpdatePauser {
                signer: sender.to_string(),
                address: address.to_owned(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "action"),
                "update_pauser",
            )
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "address"), address))
    }

    pub(super) fn pause(sender: Addr, _: bool) -> Result<Response<FactoryMsg>, StdError> {
        let msg = {
            FactoryMsg::Tf(TokenfactoryMsg::Pause {
                signer: sender.to_string(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "action"), "pause"))
    }

    pub(super) fn unpause(sender: Addr, _: bool) -> Result<Response<FactoryMsg>, StdError> {
        let msg = {
            FactoryMsg::Tf(TokenfactoryMsg::Unpause {
                signer: sender.to_string(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "action"), "unpause"))
    }

    #[allow(clippy::too_many_arguments)]
    pub(super) fn mint(
        deps: DepsMut<FactoryQuery>,
        _env: Env,
        info: MessageInfo,
        orig_sender: Option<String>,
        address: String,
        denom: String,
        value: String,
        _: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let sender = get_sender(&deps, info, orig_sender)?;

        deps.api.addr_validate(&address)?;

        let value: u128 = value
            .parse()
            .map_err(|_| StdError::generic_err("value must be a valid u128 number"))?;

        let amount = Coin::new(value, denom);

        let msg = {
            FactoryMsg::Tf(TokenfactoryMsg::Mint {
                signer: sender.to_string(),
                address: address.to_owned(),
                amount: amount.to_owned(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "action"), "mint")
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "sender"), sender)
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "address"), address)
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "amount"),
                amount.amount.to_string(),
            )
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "denom"),
                amount.denom.to_string(),
            ))
    }

    pub(super) fn burn(
        deps: DepsMut<FactoryQuery>,
        _env: Env,
        info: MessageInfo,
        orig_sender: Option<String>,
        denom: String,
        value: String,
        _: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let sender = get_sender(&deps, info, orig_sender)?;

        let value: u128 = value
            .parse()
            .map_err(|_| StdError::generic_err("value must be a valid u128 number"))?;

        let amount = Coin::new(value, denom);

        let msg = {
            FactoryMsg::Tf(TokenfactoryMsg::Burn {
                signer: sender.to_string(),
                amount: amount.to_owned(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "action"), "burn")
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "sender"),
                sender.to_string(),
            )
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "amount"),
                amount.amount.to_string(),
            )
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "denom"),
                amount.denom.to_string(),
            ))
    }

    pub(super) fn set_denom_metadata(
        deps: DepsMut<FactoryQuery>,
        _env: Env,
        info: MessageInfo,
        orig_sender: Option<String>,
        metadata: DenomMetadata,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let sender = get_sender(&deps, info, orig_sender)?;

        let msg = FactoryMsg::Tf(TokenfactoryMsg::SetDenomMetadata {
            signer: sender.to_string(),
            metadata: metadata.clone(),
        });
        Ok(Response::new()
            .add_message(msg)
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "action"),
                "set_denom_metadata",
            )
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "sender"), sender)
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "metadata"),
                metadata.display,
            ))
    }

    #[allow(clippy::too_many_arguments)]
    pub(super) fn redeem(
        deps: DepsMut<FactoryQuery>,
        _env: Env,
        info: MessageInfo,
        orig_sender: Option<String>,
        minter_address: String,
        denom: String,
        value: String,
        _: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        // NOTE: sender is only used for attribute in the response, the actual sender of the burn message is the minter.
        let sender = get_sender(&deps, info.clone(), orig_sender)?;

        deps.api.addr_validate(&minter_address)?;

        let value: u128 = value
            .parse()
            .map_err(|_| StdError::generic_err("value must be a valid u128 number"))?;

        // make sure paid amount = value
        let paid = cw_utils::may_pay(&info, &denom)
            .map_err(|e| StdError::generic_err(e.to_string()))?
            .u128();
        if paid != value {
            return Err(StdError::generic_err(format!(
                "paid amount {} does not match value {}",
                paid, value
            )));
        }

        let amount = Coin::new(value, denom.to_string());

        let bank_msg = BankMsg::Send {
            to_address: minter_address.clone(),
            amount: vec![amount.clone()],
        };

        // for burn, we set orig_sender to the beneficiary which is the minter
        let burn_msg = {
            FactoryMsg::Tf(TokenfactoryMsg::Burn {
                signer: minter_address.to_string(),
                amount: amount.to_owned(),
            })
        };

        // todo: how can MsgSend return Response<FactoryMsg>?
        Ok(Response::new()
            .add_message(bank_msg)
            .add_message(burn_msg)
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "action"), "redeem")
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "sender"), sender)
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "minter_address"),
                minter_address,
            )
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "amount"),
                amount.amount.to_string(),
            )
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "denom"),
                amount.denom.to_string(),
            ))
    }

    pub(super) fn grant_fee_basic_allowance(
        _deps: DepsMut<FactoryQuery>,
        sender: Addr,
        granter: String,
        grantee: String,
        allowance_denom: String,
        allowance_value: String,
        hours_to_expire: u64,
    ) -> Result<Response<FactoryMsg>, StdError> {
        // Ensure sender is granter
        // Note: feegrant module does not validate granter if called by a contract
        if sender.to_string() != granter {
            return Err(StdError::generic_err("granter must be the sender"));
        }

        let allowance_value: u128 = allowance_value
            .parse()
            .map_err(|_| StdError::generic_err("allowance_value must be a valid u128 number"))?;

        let allowance = Coin::new(allowance_value, allowance_denom);

        let msg = FactoryMsg::Feegrant(FeegrantMsg::GrantFeeBasicAllowance {
            signer: sender.to_string(),
            granter: granter.to_owned(),
            grantee: grantee.to_owned(),
            allowance: allowance.to_owned(),
            hours_to_expire,
        });

        Ok(Response::new()
            .add_message(msg)
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "action"),
                "grant_fee_basic_allowance",
            )
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "granter"), granter)
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "grantee"), grantee)
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "allowance"),
                allowance.to_string(),
            )
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "hours_to_expire"),
                hours_to_expire.to_string(),
            ))
    }

    pub(super) fn revoke_fee_allowance(
        _deps: DepsMut<FactoryQuery>,
        sender: Addr,
        granter: String,
        grantee: String,
    ) -> Result<Response<FactoryMsg>, StdError> {
        // Ensure sender is granter
        // Note: feegrant module does not validate granter if called by a contract
        if sender.to_string() != granter {
            return Err(StdError::generic_err("granter must be the sender"));
        }

        let msg = FactoryMsg::Feegrant(FeegrantMsg::RevokeFeeAllowance {
            signer: sender.to_string(),
            granter: granter.to_owned(),
            grantee: grantee.to_owned(),
        });

        Ok(Response::new()
            .add_message(msg)
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "action"),
                "revoke_fee_allowance",
            )
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "granter"), granter)
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "grantee"), grantee))
    }

    /// Adds a contract address to the trusted callers whitelist.
    ///
    /// # Requirements
    /// - Only the contract owner may call this.
    /// - The `addr` must be a valid bech32 address **and** a deployed contract
    ///   (not a normal user account). This is verified by querying the chain
    ///   for wasm contract info.
    ///
    /// # Behavior
    /// - If the address already exists in the map, its value is overwritten to `true`.
    /// - If the address does not exist, a new entry is created with value `true`.
    ///
    /// # Errors
    /// - Returns an error if the caller is not the contract owner.
    /// - Returns an error if `addr` fails bech32 validation.
    /// - Returns an error if `addr` is not a contract address on-chain.
    pub(super) fn add_trusted_caller(
        deps: DepsMut<FactoryQuery>,
        info: MessageInfo,
        addr: String,
    ) -> Result<Response<FactoryMsg>, StdError> {
        cw_ownable::assert_owner(deps.storage, &info.sender)
            .map_err(|e| StdError::generic_err(e.to_string()))?;

        let validated = deps.api.addr_validate(&addr)?;

        // Ensure the address is a contract, not a normal account
        deps.querier
            .query_wasm_contract_info(validated.as_str())
            .map_err(|_| {
                StdError::generic_err(format!("address {} is not a contract", validated))
            })?;

        TRUSTED_CONTRACT_CALLERS.save(deps.storage, &validated, &true)?;

        Ok(Response::new()
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "action"),
                "add_trusted_caller",
            )
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "addr"), validated))
    }

    /// Removes a contract address from the trusted callers whitelist by setting
    /// its value to `false`.
    ///
    /// # Requirements
    /// - Only the contract owner may call this.
    /// - The `addr` must be a valid bech32 address.
    ///
    /// # Behavior
    /// - If the address exists and is currently `true`, it is set to `false`.
    /// - If the address does not exist or is already `false`, this is a no-op
    ///   (no storage write occurs, but the response is still returned).
    ///
    /// # Note
    /// The entry is **not** removed from storage; it remains with a `false`
    /// value so that `all_trusted_callers` can report previously-trusted
    /// addresses as inactive.
    ///
    /// # Errors
    /// - Returns an error if the caller is not the contract owner.
    /// - Returns an error if `addr` fails bech32 validation.
    pub(super) fn remove_trusted_caller(
        deps: DepsMut<FactoryQuery>,
        info: MessageInfo,
        addr: String,
    ) -> Result<Response<FactoryMsg>, StdError> {
        cw_ownable::assert_owner(deps.storage, &info.sender)
            .map_err(|e| StdError::generic_err(e.to_string()))?;

        let validated = deps.api.addr_validate(&addr)?;
        let current = TRUSTED_CONTRACT_CALLERS
            .may_load(deps.storage, &validated)?
            .unwrap_or(false);
        if current {
            TRUSTED_CONTRACT_CALLERS.save(deps.storage, &validated, &false)?;
        }

        Ok(Response::new()
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "action"),
                "remove_trusted_caller",
            )
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "addr"), validated))
    }

    /// get_sender returns the sender address for tokenfactory.
    /// If the caller of tokenfactory contract is a trusted contract, we give that contract
    /// the option to pass in the original sender address.
    fn get_sender(
        deps: &DepsMut<FactoryQuery>,
        info: MessageInfo,
        orig_sender: Option<String>,
    ) -> Result<Addr, StdError> {
        let sender = if let Some(s) = orig_sender {
            // Only trust orig_sender if the immediate caller is a whitelisted contract
            let is_trusted = TRUSTED_CONTRACT_CALLERS
                .may_load(deps.storage, &info.sender)?
                .unwrap_or(false);
            if is_trusted {
                deps.api.addr_validate(&s)?
            } else {
                info.sender
            }
        } else {
            info.sender
        };
        Ok(sender)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use bech32::Bech32;
    use cosmwasm_std::testing::message_info;
    use cosmwasm_std::{coins, Addr, Api, Storage};
    use cosmwasm_std::{
        testing::{mock_env, MockApi, MockQuerier, MockStorage},
        OwnedDeps,
    };
    use std::marker::PhantomData;
    use tokenfactory_bindings::query::DenomMetadata;

    const ADDR: &str = "wf1nvcy5hz3d55lnndhsnhzs4rpu86dpk046h7dnt";
    // At the top of the test module, add a constant for the owner
    fn bech32_addr(hrp: &str) -> String {
        use bech32::primitives::hrp::Hrp;
        // 20 bytes is typical (like an account address payload)
        let data = vec![0u8; 20];
        bech32::encode::<Bech32>(Hrp::parse(hrp).unwrap(), &data)
            .unwrap()
            .to_string()
    }

    // Custom deps for DepsMut<FactoryQuery>
    fn mock_dependencies_factory(
    ) -> OwnedDeps<MockStorage, MockApi, MockQuerier<FactoryQuery>, FactoryQuery> {
        OwnedDeps {
            storage: MockStorage::default(),
            api: MockApi::default().with_prefix("wf"),
            querier: MockQuerier::<FactoryQuery>::new(&[]),
            custom_query_type: PhantomData,
        }
    }

    fn init_storage(store: &mut dyn Storage) {
        CONFIG.save(store, &Config { is_tf: true }).unwrap();
    }

    #[test]
    fn instantiate_works() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let cfg = CONFIG.load(&deps.storage).unwrap();
        assert!(cfg.is_tf);
    }

    #[test]
    fn update_master_minter_success_updates_state() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("owner"), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::UpdateMasterMinter {
            address: ADDR.to_string(),
        });

        let res = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        // Usually one message emitted to tokenfactory; at minimum, should not error
        assert!(!res.attributes.is_empty());

        let cfg = CONFIG.load(deps.as_ref().storage).unwrap();
        assert!(cfg.is_tf);
    }

    #[test]
    fn update_master_minter_unauthorized() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("owner"), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::UpdateMasterMinter {
            address: bech32_addr("wf"),
        });

        let resp = execute(deps.as_mut(), mock_env(), info, msg).unwrap();

        eprint!("resp: {:?}", resp);
    }

    #[test]
    fn configure_mintercontroller_success() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("masterminter"), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::ConfigureMinterController {
            controller: bech32_addr("wf").to_string(),
            minter: ADDR.to_string(),
        });

        let res = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        // Usually one message emitted to tokenfactory; at minimum, should not error
        assert!(!res.attributes.is_empty());

        let cfg = CONFIG.load(deps.as_ref().storage).unwrap();
        assert!(cfg.is_tf);
    }

    #[test]
    fn remove_mintercontroller_success() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("masterminter"), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::RemoveMinterController {
            controller: bech32_addr("wf").to_string(),
            minter: ADDR.to_string(),
        });

        let res = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        // Usually one message emitted to tokenfactory; at minimum, should not error
        assert!(!res.attributes.is_empty());

        let cfg = CONFIG.load(deps.as_ref().storage).unwrap();
        assert!(cfg.is_tf);
    }
    #[test]
    fn configure_minter_parse_error() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("master"), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::ConfigureMinter {
            address: "minter".to_string(),
            allowance_value: "not-a-number".into(),
            allowance_denom: "".to_string(),
        });

        let err = execute(deps.as_mut(), mock_env(), info, msg).unwrap_err();
        assert_eq!(
            err.to_string(),
            "Generic error: allowance_value must be a valid u128 number"
        );
    }

    #[test]
    fn configure_minter() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("mintercontroller"), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::ConfigureMinter {
            address: ADDR.to_string(),
            allowance_value: "100".to_string(),
            allowance_denom: "".to_string(),
        });

        let resp = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        eprint!("resp: {:?}", resp);
    }

    #[test]
    fn configure_minter_success_emits_message() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("master"), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::ConfigureMinter {
            address: ADDR.to_string(),
            allowance_value: "100".to_string(),
            allowance_denom: "".to_string(),
        });

        let res = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        // Should send at least one chain message (tokenfactory configure minter)
        assert!(!res.messages.is_empty());
    }

    #[test]
    fn remove_minter() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("mintercontroller"), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::RemoveMinter {
            address: ADDR.to_string(),
            denom: "uwfUSD".to_string(),
        });

        let resp = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        eprint!("resp: {:?}", resp);
    }

    #[test]
    fn update_blacklister() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("owner"), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::UpdateBlacklister {
            address: ADDR.to_string(),
        });

        let resp = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        eprint!("resp: {:?}", resp);
    }

    #[test]
    fn blacklist() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("blacklister"), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::Blacklist {
            address: hex::encode(ADDR.as_bytes()),
        });

        let resp = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        eprint!("resp: {:?}", resp);
    }

    #[test]
    fn unblacklist() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("blacklister"), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::Unblacklist {
            address: hex::encode(ADDR.as_bytes()),
        });

        let resp = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        eprint!("resp: {:?}", resp);
    }

    #[test]
    fn update_pauser() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("owner"), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::UpdatePauser {
            address: ADDR.to_string(),
        });

        let resp = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        eprint!("resp: {:?}", resp);
    }

    #[test]
    fn pause() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("pauser"), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::Pause {});

        let resp = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        eprint!("resp: {:?}", resp);
    }

    #[test]
    fn unpause() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("pauser"), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::Unpause {});

        let resp = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        eprint!("resp: {:?}", resp);
    }

    #[test]
    fn burn() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked(bech32_addr("wf").as_str()), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::Burn {
            denom: "uwfUSD".into(),
            value: "10".into(),
            orig_sender: Some(ADDR.to_string()),
        });

        let resp = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        eprint!("resp: {:?}", resp);
    }

    #[test]
    fn mint() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked(bech32_addr("wf").as_str()), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::Mint {
            denom: "uwfUSD".into(),
            value: "10".into(),
            orig_sender: Some(ADDR.to_string()),
            address: ADDR.to_string(),
        });

        let resp = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        eprint!("resp: {:?}", resp);
    }

    #[test]
    fn redeem_fails_on_wrong_funds() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked(ADDR), &coins(5, "uwfUSD"));
        let msg = ExecuteMsg::Redeem {
            orig_sender: None,
            minter_address: ADDR.to_string(),
            denom: "uwfUSD".into(),
            value: "10".into(),
        };

        let err = execute(deps.as_mut(), mock_env(), info, msg).unwrap_err();
        assert_eq!(
            err.to_string(),
            "Generic error: paid amount 5 does not match value 10"
        );
    }

    #[test]
    fn redeem_success_emits_messages() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked(ADDR), &coins(10, "uwfUSD"));
        let msg = ExecuteMsg::Redeem {
            orig_sender: None,
            minter_address: ADDR.to_string(),
            denom: "uwfUSD".into(),
            value: "10".into(),
        };

        let res = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        assert_eq!(res.messages.len(), 2); // burn + bank send
    }

    #[test]
    fn feegrant_rejects_unauthorized() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked(ADDR), &[]);
        let msg = ExecuteMsg::Feegrant(FeegrantContractMsg::RevokeFeeAllowance {
            granter: "granter".to_string(),
            grantee: ADDR.to_string(),
        });

        let err = execute(deps.as_mut(), mock_env(), info, msg).unwrap_err();
        assert_eq!(
            err.to_string(),
            "Generic error: granter must be the sender".to_string()
        );
    }

    #[test]
    fn feegrant_revoke_success() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("granter"), &[]);
        let msg = ExecuteMsg::Feegrant(FeegrantContractMsg::RevokeFeeAllowance {
            granter: "granter".to_string(),
            grantee: "grantee".into(),
        });

        let res = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        assert_eq!(res.messages.len(), 1);
    }

    #[test]
    fn mint_ok() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        // most tokenfactory minting is restricted to controller/master/minter
        let info = message_info(&Addr::unchecked(ADDR), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::Mint {
            orig_sender: None,
            denom: "uwfUSD".to_string(),
            value: "10".to_string(),
            address: bech32_addr("wf").to_string(),
        });

        let resp = execute(deps.as_mut(), mock_env(), info, msg).unwrap();

        eprint!("resp: {:?}", resp);
    }

    #[test]
    fn mint_success_emits_message() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        // If master is allowed, this should work.
        let info = message_info(&Addr::unchecked("minter"), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::Mint {
            orig_sender: None,
            denom: "uwfUSD".to_string(),
            value: "10".to_string(),
            address: ADDR.to_string(),
        });

        let res = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        assert!(!res.messages.is_empty());
    }

    #[test]
    fn redeem_wrong_denom_funds_fails() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        // Pay the wrong denom so you exercise denom-check logic (often separate from amount-check)
        let info = message_info(&Addr::unchecked("user"), &coins(10, "wrongdenom"));
        let msg = ExecuteMsg::Redeem {
            orig_sender: None,
            minter_address: ADDR.to_string(), // <- bech32-valid
            denom: "uwfUSD".to_string(),
            value: "10".to_string(),
        };

        let err = execute(deps.as_mut(), mock_env(), info, msg).unwrap_err();
        let s = err.to_string().to_lowercase();
        assert!(s.contains("fund") || s.contains("denom") || s.contains("invalid"));
    }

    #[test]
    fn redeem_success_emits_burn_and_send() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("user"), &coins(10, "uwfUSD"));
        let msg = ExecuteMsg::Redeem {
            orig_sender: None,
            minter_address: ADDR.to_string(), // <- bech32-valid
            denom: "uwfUSD".to_string(),
            value: "10".to_string(),
        };

        let res = execute(deps.as_mut(), mock_env(), info, msg).unwrap();

        // - burn tokenfactory
        // - bank send out (or another chain msg)
        assert!(res.messages.len() >= 2);
    }

    #[test]
    fn feegrant_grant_unauthorized() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("not-granter"), &[]);
        let msg = ExecuteMsg::Feegrant(FeegrantContractMsg::GrantFeeBasicAllowance {
            granter: ADDR.to_string(),
            grantee: bech32_addr("wf").to_string(),
            allowance_denom: "uwfUSD".to_string(),
            allowance_value: "10".to_string(),
            hours_to_expire: 24,
        });

        let err = execute(deps.as_mut(), mock_env(), info, msg).unwrap_err();
        assert_eq!(
            err.to_string().to_lowercase(),
            "generic error: granter must be the sender"
        );
    }

    #[test]
    fn feegrant_grant_success_emits_message() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("granter"), &[]);
        let msg = ExecuteMsg::Feegrant(FeegrantContractMsg::GrantFeeBasicAllowance {
            granter: "granter".to_string(),
            grantee: bech32_addr("wf").to_string(),
            allowance_denom: "uwfUSD".to_string(),
            allowance_value: "10".to_string(),
            hours_to_expire: 0,
        });

        let res = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        assert_eq!(res.messages.len(), 1);
    }

    #[test]
    fn set_denom_metadata() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("granter"), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::SetDenomMetadata {
            orig_sender: None,
            metadata: DenomMetadata {
                description: "".to_string(),
                denom_units: vec![],
                base: "".to_string(),
                display: "".to_string(),
                name: "".to_string(),
                symbol: "".to_string(),
                uri: None,
                uri_hash: None,
            },
        });

        let res = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        assert_eq!(res.messages.len(), 1);
    }

    use tokenfactory_bindings::query::FactoryQuery;

    // ---------------------------------------------------------------------------
    // Helper: build deps with a wasm querier that recognises specific contracts
    // ---------------------------------------------------------------------------
    fn mock_deps_with_wasm_contracts(
        contract_addrs: Vec<String>,
    ) -> OwnedDeps<MockStorage, MockApi, MockQuerier<FactoryQuery>, FactoryQuery> {
        use cosmwasm_std::{ContractInfoResponse, SystemError, SystemResult, WasmQuery};

        let mut deps = OwnedDeps {
            storage: MockStorage::default(),
            api: MockApi::default().with_prefix("wf"),
            querier: MockQuerier::<FactoryQuery>::new(&[]),
            custom_query_type: PhantomData,
        };

        deps.querier
            .update_wasm(move |wasm_query| match wasm_query {
                WasmQuery::ContractInfo { contract_addr }
                    if contract_addrs.contains(contract_addr) =>
                {
                    let info = ContractInfoResponse::new(
                        1u64,
                        Addr::unchecked("creator"),
                        None::<Addr>,
                        false,
                        None::<String>,
                    );

                    SystemResult::Ok(cosmwasm_std::ContractResult::Ok(
                        cosmwasm_std::to_json_binary(&info).unwrap(),
                    ))
                }
                _ => SystemResult::Err(SystemError::NoSuchContract {
                    addr: "unknown".into(),
                }),
            });

        deps
    }

    fn setup_owner(
        deps: &mut OwnedDeps<MockStorage, MockApi, MockQuerier<FactoryQuery>, FactoryQuery>,
        owner: &str,
    ) {
        init_storage(&mut deps.storage);
        initialize_owner(&mut deps.storage, &deps.api, Some(owner)).unwrap();
    }

    fn bech32_addr_with_seed(hrp: &str, seed: u8) -> String {
        use bech32::primitives::hrp::Hrp;
        let data = vec![seed; 20];
        bech32::encode::<Bech32>(Hrp::parse(hrp).unwrap(), &data)
            .unwrap()
            .to_string()
    }

    // ===========================================================================
    // add_trusted_caller tests
    // ===========================================================================

    #[test]
    fn add_trusted_caller_success() {
        use crate::state::TRUSTED_CONTRACT_CALLERS;

        let owner_addr = bech32_addr_with_seed("wf", 1);
        let contract_addr = bech32_addr_with_seed("wf", 2);
        let mut deps = mock_deps_with_wasm_contracts(vec![contract_addr.clone()]);
        setup_owner(&mut deps, &owner_addr);

        let info = message_info(&Addr::unchecked(&owner_addr), &[]);
        let msg = ExecuteMsg::AddTrustedCaller {
            addr: contract_addr.clone(),
        };

        let res = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        assert!(res
            .attributes
            .iter()
            .any(|a| a.value == "add_trusted_caller"));
        assert!(res.attributes.iter().any(|a| a.value == contract_addr));

        let validated = deps.api.addr_validate(&contract_addr).unwrap();
        let trusted = TRUSTED_CONTRACT_CALLERS
            .load(deps.as_ref().storage, &validated)
            .unwrap();
        assert!(trusted);
    }

    #[test]
    fn add_trusted_caller_not_owner_fails() {
        let owner_addr = bech32_addr_with_seed("wf", 1);
        let contract_addr = bech32_addr_with_seed("wf", 2);
        let mut deps = mock_deps_with_wasm_contracts(vec![contract_addr.clone()]);
        setup_owner(&mut deps, &owner_addr);

        let info = message_info(&Addr::unchecked("not_owner"), &[]);
        let msg = ExecuteMsg::AddTrustedCaller {
            addr: contract_addr,
        };

        let err = execute(deps.as_mut(), mock_env(), info, msg).unwrap_err();
        let err_str = err.to_string().to_lowercase();
        assert!(
            err_str.contains("owner") || err_str.contains("not the contract's current owner"),
            "expected ownership error, got: {err}"
        );
    }

    #[test]
    fn add_trusted_caller_invalid_address_fails() {
        let owner_addr = bech32_addr_with_seed("wf", 1);
        let contract_addr = bech32_addr_with_seed("wf", 2);
        let mut deps = mock_deps_with_wasm_contracts(vec![contract_addr.clone()]);
        setup_owner(&mut deps, &owner_addr);

        let info = message_info(&Addr::unchecked(&owner_addr), &[]);
        let msg = ExecuteMsg::AddTrustedCaller {
            addr: "not-a-valid-bech32".to_string(),
        };

        let err = execute(deps.as_mut(), mock_env(), info, msg).unwrap_err();
        let err_str = err.to_string().to_lowercase();
        assert!(
            err_str.contains("addr") || err_str.contains("decoding") || err_str.contains("invalid"),
            "expected address validation error, got: {err}"
        );
    }

    #[test]
    fn add_trusted_caller_not_a_contract_fails() {
        // Address is valid bech32 but NOT in the wasm contracts list
        let not_owner_addr = bech32_addr_with_seed("wf", 99);
        let non_contract_addr = bech32_addr_with_seed("wf", 100);
        let mut deps = mock_deps_with_wasm_contracts(vec![]); // no contracts registered
        setup_owner(&mut deps, &not_owner_addr);

        let info = message_info(&Addr::unchecked(&not_owner_addr), &[]);
        let msg = ExecuteMsg::AddTrustedCaller {
            addr: non_contract_addr.clone(),
        };

        let err = execute(deps.as_mut(), mock_env(), info, msg).unwrap_err();
        assert!(
            err.to_string().contains("is not a contract"),
            "expected 'is not a contract' error, got: {err}"
        );
    }

    #[test]
    fn add_trusted_caller_overwrite_existing() {
        use crate::state::TRUSTED_CONTRACT_CALLERS;

        let owner_addr = bech32_addr_with_seed("wf", 1);
        let contract_addr = bech32_addr_with_seed("wf", 2);
        let mut deps = mock_deps_with_wasm_contracts(vec![contract_addr.clone()]);
        setup_owner(&mut deps, &owner_addr);

        let validated = deps.api.addr_validate(&contract_addr).unwrap();

        // Pre-seed with false (previously removed)
        TRUSTED_CONTRACT_CALLERS
            .save(deps.as_mut().storage, &validated, &false)
            .unwrap();

        let info = message_info(&Addr::unchecked(&owner_addr), &[]);
        let msg = ExecuteMsg::AddTrustedCaller {
            addr: contract_addr,
        };

        execute(deps.as_mut(), mock_env(), info, msg).unwrap();

        let trusted = TRUSTED_CONTRACT_CALLERS
            .load(deps.as_ref().storage, &validated)
            .unwrap();
        assert!(trusted, "should overwrite false → true");
    }

    // ===========================================================================
    // remove_trusted_caller tests
    // ===========================================================================

    #[test]
    fn remove_trusted_caller_success() {
        use crate::state::TRUSTED_CONTRACT_CALLERS;

        let owner_addr = bech32_addr_with_seed("wf", 1);
        let contract_addr = bech32_addr_with_seed("wf", 2);
        let mut deps = mock_deps_with_wasm_contracts(vec![contract_addr.clone()]);
        setup_owner(&mut deps, &owner_addr);

        let validated = deps.api.addr_validate(&contract_addr).unwrap();

        // Pre-seed as trusted
        TRUSTED_CONTRACT_CALLERS
            .save(deps.as_mut().storage, &validated, &true)
            .unwrap();

        let info = message_info(&Addr::unchecked(&owner_addr), &[]);
        let msg = ExecuteMsg::RemoveTrustedCaller {
            addr: contract_addr.clone(),
        };

        let res = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        assert!(res
            .attributes
            .iter()
            .any(|a| a.value == "remove_trusted_caller"));

        let trusted = TRUSTED_CONTRACT_CALLERS
            .load(deps.as_ref().storage, &validated)
            .unwrap();
        assert!(!trusted, "should be set to false after removal");
    }

    #[test]
    fn remove_trusted_caller_not_owner_fails() {
        let owner_addr = bech32_addr_with_seed("wf", 1);
        let contract_addr = bech32_addr_with_seed("wf", 2);
        let mut deps = mock_deps_with_wasm_contracts(vec![contract_addr.clone()]);
        setup_owner(&mut deps, &owner_addr);

        let not_owner_addr = bech32_addr_with_seed("wf", 99);
        let info = message_info(&Addr::unchecked(&not_owner_addr), &[]);
        let msg = ExecuteMsg::RemoveTrustedCaller {
            addr: contract_addr,
        };

        let err = execute(deps.as_mut(), mock_env(), info, msg).unwrap_err();
        let err_str = err.to_string().to_lowercase();
        assert!(
            err_str.contains("owner") || err_str.contains("not the contract's current owner"),
            "expected ownership error, got: {err}"
        );
    }

    #[test]
    fn remove_trusted_caller_nonexistent_is_noop() {
        use crate::state::TRUSTED_CONTRACT_CALLERS;

        let owner_addr = bech32_addr_with_seed("wf", 1);
        let contract_addr = bech32_addr_with_seed("wf", 2);
        let mut deps = mock_deps_with_wasm_contracts(vec![contract_addr.clone()]);
        setup_owner(&mut deps, &owner_addr);

        let validated = deps.api.addr_validate(&contract_addr).unwrap();

        // No entry in storage at all
        let info = message_info(&Addr::unchecked(&owner_addr), &[]);
        let msg = ExecuteMsg::RemoveTrustedCaller {
            addr: contract_addr,
        };

        let res = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        assert!(res
            .attributes
            .iter()
            .any(|a| a.value == "remove_trusted_caller"));

        // Should not have created an entry
        let val = TRUSTED_CONTRACT_CALLERS
            .may_load(deps.as_ref().storage, &validated)
            .unwrap();
        assert_eq!(val, None, "should not write anything for nonexistent entry");
    }

    #[test]
    fn remove_trusted_caller_already_false_is_noop() {
        use crate::state::TRUSTED_CONTRACT_CALLERS;

        let owner_addr = bech32_addr_with_seed("wf", 1);
        let contract_addr = bech32_addr_with_seed("wf", 2);
        let mut deps = mock_deps_with_wasm_contracts(vec![contract_addr.clone()]);
        setup_owner(&mut deps, &owner_addr);

        let validated = deps.api.addr_validate(&contract_addr).unwrap();

        // Pre-seed as already false
        TRUSTED_CONTRACT_CALLERS
            .save(deps.as_mut().storage, &validated, &false)
            .unwrap();

        let info = message_info(&Addr::unchecked(&owner_addr), &[]);
        let msg = ExecuteMsg::RemoveTrustedCaller {
            addr: contract_addr,
        };

        let res = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        assert!(res
            .attributes
            .iter()
            .any(|a| a.value == "remove_trusted_caller"));

        let trusted = TRUSTED_CONTRACT_CALLERS
            .load(deps.as_ref().storage, &validated)
            .unwrap();
        assert!(!trusted, "should remain false");
    }

    #[test]
    fn remove_trusted_caller_invalid_address_fails() {
        let owner_addr = bech32_addr_with_seed("wf", 1);
        let contract_addr = bech32_addr_with_seed("wf", 2);
        let mut deps = mock_deps_with_wasm_contracts(vec![contract_addr.clone()]);
        setup_owner(&mut deps, &owner_addr);

        let info = message_info(&Addr::unchecked(&owner_addr), &[]);
        let msg = ExecuteMsg::RemoveTrustedCaller {
            addr: "not-valid-bech32".to_string(),
        };

        let err = execute(deps.as_mut(), mock_env(), info, msg).unwrap_err();
        let err_str = err.to_string().to_lowercase();
        assert!(
            err_str.contains("addr") || err_str.contains("decoding") || err_str.contains("invalid"),
            "expected address validation error, got: {err}"
        );
    }
}
