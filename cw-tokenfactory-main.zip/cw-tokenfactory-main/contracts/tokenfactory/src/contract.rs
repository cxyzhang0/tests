#[cfg(not(feature = "library"))]
use cosmwasm_std::entry_point;
use cosmwasm_std::{DepsMut, Env, MessageInfo, Response, StdError, StdResult};
use cw2::set_contract_version;

use tokenfactory_bindings::msg::{FactoryMsg, FeegrantMsg, TokenfactoryMsg};
use tokenfactory_bindings::query::FactoryQuery;

use crate::msg::{ExecuteMsg, FeegrantContractMsg, InstantiateMsg, TokenfactoryContractMsg};
use crate::state::{Config, CONFIG};

const CONTRACT_NAME: &str = "crates.io:tokenfactory-integration";
const CONTRACT_VERSION: &str = env!("CARGO_PKG_VERSION");

#[cfg_attr(not(feature = "library"), entry_point)]
pub fn instantiate(
    deps: DepsMut,
    _env: Env,
    info: MessageInfo,
    msg: InstantiateMsg,
) -> StdResult<Response> {
    set_contract_version(deps.storage, CONTRACT_NAME, CONTRACT_VERSION)?;

    let config = Config {
        owner: info.sender.to_owned(),
        is_tf: msg.is_tf,
    };
    CONFIG.save(deps.storage, &config)?;

    Ok(Response::new()
        .add_attribute(
            format!("{}_{}", crate::PACKAGE_NAME, "action"),
            "instantiate",
        )
        .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "owner"), info.sender)
        .add_attribute(
            format!("{}_{}", crate::PACKAGE_NAME, "is_tf"),
            msg.is_tf.to_string(),
        ))
}

#[cfg_attr(not(feature = "library"), entry_point)]
pub fn execute(
    deps: DepsMut<FactoryQuery>,
    env: Env,
    info: MessageInfo,
    msg: ExecuteMsg,
) -> Result<Response<FactoryMsg>, StdError> {
    let is_tf = CONFIG.load(deps.storage)?.is_tf;
    match msg {
        ExecuteMsg::Tf(TokenfactoryContractMsg::UpdateMasterMinter { address }) => {
            execute::update_master_minter(info.sender, address, is_tf)
        }
        ExecuteMsg::Tf(TokenfactoryContractMsg::ConfigureMinterController {
            controller,
            minter,
        }) => execute::configure_minter_controller(info.sender, controller, minter, is_tf),
        ExecuteMsg::Tf(TokenfactoryContractMsg::RemoveMinterController { controller, minter }) => {
            execute::remove_minter_controller(info.sender, controller, minter, is_tf)
        }
        ExecuteMsg::Tf(TokenfactoryContractMsg::ConfigureMinter {
            address,
            allowance_denom,
            allowance_value,
        }) => execute::configure_minter(
            info.sender,
            address,
            allowance_denom,
            allowance_value,
            is_tf,
        ),
        ExecuteMsg::Tf(TokenfactoryContractMsg::RemoveMinter { address, denom }) => {
            execute::remove_minter(info.sender, address, denom, is_tf)
        }
        ExecuteMsg::Tf(TokenfactoryContractMsg::UpdateBlacklister { address }) => {
            execute::update_blacklister(info.sender, address, is_tf)
        }
        ExecuteMsg::Tf(TokenfactoryContractMsg::Blacklist { address }) => {
            execute::blacklist(info.sender, address, is_tf)
        }
        ExecuteMsg::Tf(TokenfactoryContractMsg::Unblacklist { address }) => {
            execute::unblacklist(info.sender, address, is_tf)
        }
        ExecuteMsg::Tf(TokenfactoryContractMsg::UpdatePauser { address }) => {
            execute::update_pauser(info.sender, address, is_tf)
        }
        ExecuteMsg::Tf(TokenfactoryContractMsg::Pause {}) => execute::pause(info.sender, is_tf),
        ExecuteMsg::Tf(TokenfactoryContractMsg::Unpause {}) => execute::unpause(info.sender, is_tf),
        ExecuteMsg::Tf(TokenfactoryContractMsg::Mint {
            orig_sender,
            address,
            denom,
            value,
        }) => execute::mint(deps, env, info, orig_sender, address, denom, value, is_tf),
        ExecuteMsg::Tf(TokenfactoryContractMsg::Burn {
            orig_sender,
            denom,
            value,
        }) => execute::burn(deps, env, info, orig_sender, denom, value, is_tf),
        ExecuteMsg::Tf(TokenfactoryContractMsg::SetDenomMetadata {
            orig_sender,
            metadata,
        }) => execute::set_denom_metadata(deps, env, info, orig_sender, metadata),
        ExecuteMsg::Redeem {
            orig_sender,
            minter_address,
            denom,
            value,
        } => execute::redeem(
            deps,
            env,
            info,
            orig_sender,
            minter_address,
            denom,
            value,
            is_tf,
        ),
        ExecuteMsg::Feegrant(FeegrantContractMsg::GrantFeeBasicAllowance {
            granter,
            grantee,
            allowance_denom,
            allowance_value,
            hours_to_expire,
        }) => execute::grant_fee_basic_allowance(
            deps,
            info.sender,
            granter,
            grantee,
            allowance_denom,
            allowance_value,
            hours_to_expire,
        ),
        ExecuteMsg::Feegrant(FeegrantContractMsg::RevokeFeeAllowance { granter, grantee }) => {
            execute::revoke_fee_allowance(deps, info.sender, granter, grantee)
        }
    }
}

pub mod execute {
    use cosmwasm_std::{Addr, BankMsg, Coin};

    use super::*;
    use tokenfactory_bindings::msg::FactoryMsg;
    use tokenfactory_bindings::query::{DenomMetadata, FactoryQuery};

    pub(super) fn update_master_minter(
        sender: Addr,
        address: String,
        _: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let msg = {
            FactoryMsg::Tf(TokenfactoryMsg::UpdateMasterMinter {
                signer: sender.to_string(),
                address: address.to_owned(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "action"),
                "update_master_minter",
            )
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "address"), address))
    }

    pub(super) fn configure_minter_controller(
        sender: Addr,
        controller: String,
        minter: String,
        _: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let msg = {
            FactoryMsg::Tf(TokenfactoryMsg::ConfigureMinterController {
                signer: sender.to_string(),
                controller: controller.to_owned(),
                minter: minter.to_owned(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "action"),
                "configure_minter_controller",
            )
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "controller"),
                controller,
            )
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "minter"), minter))
    }

    pub(super) fn remove_minter_controller(
        sender: Addr,
        controller: String,
        minter: String,
        _: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let msg = {
            FactoryMsg::Tf(TokenfactoryMsg::RemoveMinterController {
                signer: sender.to_string(),
                controller: controller.to_owned(),
                minter: minter.to_owned(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "action"),
                "remove_minter_controller",
            )
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "controller"),
                controller,
            )
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "minter"), minter))
    }

    pub(super) fn configure_minter(
        sender: Addr,
        address: String,
        allowance_denom: String,
        allowance_value: String,
        _: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let allowance_value: u128 = allowance_value
            .parse()
            .map_err(|_| StdError::generic_err("allowance_value must be a valid u128 number"))?;

        let allowance = Coin::new(allowance_value, allowance_denom);

        let msg = {
            FactoryMsg::Tf(TokenfactoryMsg::ConfigureMinter {
                signer: sender.to_string(),
                address: address.to_owned(),
                allowance: allowance.to_owned(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "action"),
                "configure_minter",
            )
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "address"), address)
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "allowance_amount"),
                allowance.amount.to_string(),
            )
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "allowance_denom"),
                allowance.denom.to_string(),
            ))
    }

    pub(super) fn remove_minter(
        sender: Addr,
        address: String,
        denom: String,
        _: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let msg = {
            FactoryMsg::Tf(TokenfactoryMsg::RemoveMinter {
                signer: sender.to_string(),
                address: address.to_owned(),
                denom: denom.to_owned(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "action"),
                "remove_minter",
            )
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "address"), address)
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "denom"), denom))
    }

    pub(super) fn update_blacklister(
        sender: Addr,
        address: String,
        _: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let msg = {
            FactoryMsg::Tf(TokenfactoryMsg::UpdateBlacklister {
                signer: sender.to_string(),
                address: address.to_owned(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "action"),
                "update_blacklister",
            )
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "address"), address))
    }

    pub(super) fn blacklist(
        sender: Addr,
        address: String,
        _: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let msg = {
            FactoryMsg::Tf(TokenfactoryMsg::Blacklist {
                signer: sender.to_string(),
                address: address.to_owned(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "action"), "blacklist")
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "address"), address))
    }

    pub(super) fn unblacklist(
        sender: Addr,
        address: String,
        _: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let msg = {
            FactoryMsg::Tf(TokenfactoryMsg::Unblacklist {
                signer: sender.to_string(),
                address: address.to_owned(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "action"),
                "unblacklist",
            )
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "address"), address))
    }

    pub(super) fn update_pauser(
        sender: Addr,
        address: String,
        _: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let msg = {
            FactoryMsg::Tf(TokenfactoryMsg::UpdatePauser {
                signer: sender.to_string(),
                address: address.to_owned(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "action"),
                "update_pauser",
            )
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "address"), address))
    }

    pub(super) fn pause(sender: Addr, _: bool) -> Result<Response<FactoryMsg>, StdError> {
        let msg = {
            FactoryMsg::Tf(TokenfactoryMsg::Pause {
                signer: sender.to_string(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "action"), "pause"))
    }

    pub(super) fn unpause(sender: Addr, _: bool) -> Result<Response<FactoryMsg>, StdError> {
        let msg = {
            FactoryMsg::Tf(TokenfactoryMsg::Unpause {
                signer: sender.to_string(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "action"), "unpause"))
    }

    #[allow(clippy::too_many_arguments)]
    pub(super) fn mint(
        deps: DepsMut<FactoryQuery>,
        _env: Env,
        info: MessageInfo,
        orig_sender: Option<String>,
        address: String,
        denom: String,
        value: String,
        _: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let sender = get_sender(&deps, info, orig_sender)?;

        deps.api.addr_validate(&address)?;

        let value: u128 = value
            .parse()
            .map_err(|_| StdError::generic_err("value must be a valid u128 number"))?;

        let amount = Coin::new(value, denom);

        let msg = {
            FactoryMsg::Tf(TokenfactoryMsg::Mint {
                signer: sender.to_string(),
                address: address.to_owned(),
                amount: amount.to_owned(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "action"), "mint")
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "sender"), sender)
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "address"), address)
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "amount"),
                amount.amount.to_string(),
            )
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "denom"),
                amount.denom.to_string(),
            ))
    }

    pub(super) fn burn(
        deps: DepsMut<FactoryQuery>,
        _env: Env,
        info: MessageInfo,
        orig_sender: Option<String>,
        denom: String,
        value: String,
        _: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let sender = get_sender(&deps, info, orig_sender)?;

        let value: u128 = value
            .parse()
            .map_err(|_| StdError::generic_err("value must be a valid u128 number"))?;

        let amount = Coin::new(value, denom);

        let msg = {
            FactoryMsg::Tf(TokenfactoryMsg::Burn {
                signer: sender.to_string(),
                amount: amount.to_owned(),
            })
        };
        Ok(Response::new()
            .add_message(msg)
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "action"), "burn")
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "sender"),
                sender.to_string(),
            )
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "amount"),
                amount.amount.to_string(),
            )
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "denom"),
                amount.denom.to_string(),
            ))
    }

    pub(super) fn set_denom_metadata(
        deps: DepsMut<FactoryQuery>,
        _env: Env,
        info: MessageInfo,
        orig_sender: Option<String>,
        metadata: DenomMetadata,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let sender = get_sender(&deps, info, orig_sender)?;

        let msg = FactoryMsg::Tf(TokenfactoryMsg::SetDenomMetadata {
            signer: sender.to_string(),
            metadata: metadata.clone(),
        });
        Ok(Response::new()
            .add_message(msg)
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "action"),
                "set_denom_metadata",
            )
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "sender"), sender)
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "metadata"),
                metadata.display,
            ))
    }

    #[allow(clippy::too_many_arguments)]
    pub(super) fn redeem(
        deps: DepsMut<FactoryQuery>,
        _env: Env,
        info: MessageInfo,
        orig_sender: Option<String>,
        minter_address: String,
        denom: String,
        value: String,
        _: bool,
    ) -> Result<Response<FactoryMsg>, StdError> {
        let sender = get_sender(&deps, info.clone(), orig_sender)?;

        deps.api.addr_validate(&minter_address)?;

        let value: u128 = value
            .parse()
            .map_err(|_| StdError::generic_err("value must be a valid u128 number"))?;

        // make sure paid amount = value
        let paid = cw_utils::may_pay(&info, &denom)
            .map_err(|e| StdError::generic_err(e.to_string()))?
            .u128();
        if paid != value {
            return Err(StdError::generic_err(format!(
                "paid amount {} does not match value {}",
                paid, value
            )));
        }

        let amount = Coin::new(value, denom.to_string());

        let bank_msg = BankMsg::Send {
            to_address: minter_address.clone(),
            amount: vec![amount.clone()],
        };

        // for burn, we set orig_sender to the beneficiary which is the minter
        let burn_msg = {
            FactoryMsg::Tf(TokenfactoryMsg::Burn {
                signer: minter_address.to_string(),
                amount: amount.to_owned(),
            })
        };

        // todo: how can MsgSend return Response<FactoryMsg>?
        Ok(Response::new()
            .add_message(bank_msg)
            .add_message(burn_msg)
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "action"), "redeem")
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "sender"), sender)
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "minter_address"),
                minter_address,
            )
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "amount"),
                amount.amount.to_string(),
            )
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "denom"),
                amount.denom.to_string(),
            ))
    }

    pub(super) fn grant_fee_basic_allowance(
        _deps: DepsMut<FactoryQuery>,
        sender: Addr,
        granter: String,
        grantee: String,
        allowance_denom: String,
        allowance_value: String,
        hours_to_expire: u64,
    ) -> Result<Response<FactoryMsg>, StdError> {
        // Ensure sender is granter
        // Note: feegrant module does not validate granter if called by a contract
        if sender.to_string() != granter {
            return Err(StdError::generic_err("granter must be the sender"));
        }

        let allowance_value: u128 = allowance_value
            .parse()
            .map_err(|_| StdError::generic_err("allowance_value must be a valid u128 number"))?;

        let allowance = Coin::new(allowance_value, allowance_denom);

        let msg = FactoryMsg::Feegrant(FeegrantMsg::GrantFeeBasicAllowance {
            signer: sender.to_string(),
            granter: granter.to_owned(),
            grantee: grantee.to_owned(),
            allowance: allowance.to_owned(),
            hours_to_expire,
        });

        Ok(Response::new()
            .add_message(msg)
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "action"),
                "grant_fee_basic_allowance",
            )
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "granter"), granter)
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "grantee"), grantee)
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "allowance"),
                allowance.to_string(),
            )
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "hours_to_expire"),
                hours_to_expire.to_string(),
            ))
    }

    pub(super) fn revoke_fee_allowance(
        _deps: DepsMut<FactoryQuery>,
        sender: Addr,
        granter: String,
        grantee: String,
    ) -> Result<Response<FactoryMsg>, StdError> {
        // Ensure sender is granter
        // Note: feegrant module does not validate granter if called by a contract
        if sender.to_string() != granter {
            return Err(StdError::generic_err("granter must be the sender"));
        }

        let msg = FactoryMsg::Feegrant(FeegrantMsg::RevokeFeeAllowance {
            signer: sender.to_string(),
            granter: granter.to_owned(),
            grantee: grantee.to_owned(),
        });

        Ok(Response::new()
            .add_message(msg)
            .add_attribute(
                format!("{}_{}", crate::PACKAGE_NAME, "action"),
                "revoke_fee_allowance",
            )
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "granter"), granter)
            .add_attribute(format!("{}_{}", crate::PACKAGE_NAME, "grantee"), grantee))
    }

    /// get_sender returns the sender address for tokenfactory.
    /// If the caller of tokenfactory contract is a contract, we give that contract
    /// the option to pass in the original sender address.
    fn get_sender(
        deps: &DepsMut<FactoryQuery>,
        info: MessageInfo,
        orig_sender: Option<String>,
    ) -> Result<Addr, StdError> {
        let sender = if let Some(s) = orig_sender {
            // if the caller of tokenfactory contract is a contract
            if deps.querier.query_wasm_contract_info(&info.sender).is_ok() {
                deps.api.addr_validate(&s)?
            } else {
                info.sender
            }
        } else {
            info.sender
        };
        Ok(sender)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use bech32::Bech32;
    use cosmwasm_std::testing::message_info;
    use cosmwasm_std::{coins, Addr, Storage};
    use cosmwasm_std::{
        testing::{mock_env, MockApi, MockQuerier, MockStorage},
        OwnedDeps,
    };
    use std::marker::PhantomData;
    use tokenfactory_bindings::query::DenomMetadata;

    const ADDR: &str = "wf1nvcy5hz3d55lnndhsnhzs4rpu86dpk046h7dnt";
    fn bech32_addr(hrp: &str) -> String {
        use bech32::primitives::hrp::Hrp;
        // 20 bytes is typical (like an account address payload)
        let data = vec![0u8; 20];
        bech32::encode::<Bech32>(Hrp::parse(hrp).unwrap(), &data)
            .unwrap()
            .to_string()
    }

    // Custom deps for DepsMut<FactoryQuery>
    fn mock_dependencies_factory(
    ) -> OwnedDeps<MockStorage, MockApi, MockQuerier<FactoryQuery>, FactoryQuery> {
        OwnedDeps {
            storage: MockStorage::default(),
            api: MockApi::default().with_prefix("wf"),
            querier: MockQuerier::<FactoryQuery>::new(&[]),
            custom_query_type: PhantomData,
        }
    }

    fn init_storage(store: &mut dyn Storage) {
        CONFIG
            .save(
                store,
                &Config {
                    owner: Addr::unchecked("owner"),
                    is_tf: true,
                },
            )
            .unwrap();
    }

    #[test]
    fn instantiate_works() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let cfg = CONFIG.load(&deps.storage).unwrap();
        assert!(cfg.is_tf);
    }

    #[test]
    fn update_master_minter_success_updates_state() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("owner"), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::UpdateMasterMinter {
            address: ADDR.to_string(),
        });

        let res = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        // Usually one message emitted to tokenfactory; at minimum, should not error
        assert!(!res.attributes.is_empty());

        let cfg = CONFIG.load(deps.as_ref().storage).unwrap();
        assert_eq!(cfg.owner, Addr::unchecked("owner"));
    }

    #[test]
    fn update_master_minter_unauthorized() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("owner"), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::UpdateMasterMinter {
            address: bech32_addr("wf"),
        });

        let resp = execute(deps.as_mut(), mock_env(), info, msg).unwrap();

        eprint!("resp: {:?}", resp);
    }

    #[test]
    fn configure_mintercontroller_success() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("masterminter"), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::ConfigureMinterController {
            controller: bech32_addr("wf").to_string(),
            minter: ADDR.to_string(),
        });

        let res = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        // Usually one message emitted to tokenfactory; at minimum, should not error
        assert!(!res.attributes.is_empty());

        let cfg = CONFIG.load(deps.as_ref().storage).unwrap();
        assert_eq!(cfg.owner, Addr::unchecked("owner"));
    }

    #[test]
    fn remove_mintercontroller_success() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("masterminter"), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::RemoveMinterController {
            controller: bech32_addr("wf").to_string(),
            minter: ADDR.to_string(),
        });

        let res = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        // Usually one message emitted to tokenfactory; at minimum, should not error
        assert!(!res.attributes.is_empty());

        let cfg = CONFIG.load(deps.as_ref().storage).unwrap();
        assert_eq!(cfg.owner, Addr::unchecked("owner"));
    }
    #[test]
    fn configure_minter_parse_error() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("master"), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::ConfigureMinter {
            address: "minter".to_string(),
            allowance_value: "not-a-number".into(),
            allowance_denom: "".to_string(),
        });

        let err = execute(deps.as_mut(), mock_env(), info, msg).unwrap_err();
        assert_eq!(
            err.to_string(),
            "Generic error: allowance_value must be a valid u128 number"
        );
    }

    #[test]
    fn configure_minter() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("mintercontroller"), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::ConfigureMinter {
            address: ADDR.to_string(),
            allowance_value: "100".to_string(),
            allowance_denom: "".to_string(),
        });

        let resp = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        eprint!("resp: {:?}", resp);
    }

    #[test]
    fn configure_minter_success_emits_message() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("master"), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::ConfigureMinter {
            address: ADDR.to_string(),
            allowance_value: "100".to_string(),
            allowance_denom: "".to_string(),
        });

        let res = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        // Should send at least one chain message (tokenfactory configure minter)
        assert!(!res.messages.is_empty());
    }

    #[test]
    fn remove_minter() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("mintercontroller"), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::RemoveMinter {
            address: ADDR.to_string(),
            denom: "uwfUSD".to_string(),
        });

        let resp = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        eprint!("resp: {:?}", resp);
    }

    #[test]
    fn update_blacklister() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("owner"), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::UpdateBlacklister {
            address: ADDR.to_string(),
        });

        let resp = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        eprint!("resp: {:?}", resp);
    }

    #[test]
    fn blacklist() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("blacklister"), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::Blacklist {
            address: hex::encode(ADDR.as_bytes()),
        });

        let resp = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        eprint!("resp: {:?}", resp);
    }

    #[test]
    fn unblacklist() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("blacklister"), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::Unblacklist {
            address: hex::encode(ADDR.as_bytes()),
        });

        let resp = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        eprint!("resp: {:?}", resp);
    }

    #[test]
    fn update_pauser() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("owner"), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::UpdatePauser {
            address: ADDR.to_string(),
        });

        let resp = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        eprint!("resp: {:?}", resp);
    }

    #[test]
    fn pause() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("pauser"), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::Pause {});

        let resp = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        eprint!("resp: {:?}", resp);
    }

    #[test]
    fn unpause() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("pauser"), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::Unpause {});

        let resp = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        eprint!("resp: {:?}", resp);
    }

    #[test]
    fn burn() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked(bech32_addr("wf").as_str()), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::Burn {
            denom: "uwfUSD".into(),
            value: "10".into(),
            orig_sender: Some(ADDR.to_string()),
        });

        let resp = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        eprint!("resp: {:?}", resp);
    }

    #[test]
    fn mint() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked(bech32_addr("wf").as_str()), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::Mint {
            denom: "uwfUSD".into(),
            value: "10".into(),
            orig_sender: Some(ADDR.to_string()),
            address: ADDR.to_string(),
        });

        let resp = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        eprint!("resp: {:?}", resp);
    }

    #[test]
    fn redeem_fails_on_wrong_funds() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked(ADDR), &coins(5, "uwfUSD"));
        let msg = ExecuteMsg::Redeem {
            orig_sender: None,
            minter_address: ADDR.to_string(),
            denom: "uwfUSD".into(),
            value: "10".into(),
        };

        let err = execute(deps.as_mut(), mock_env(), info, msg).unwrap_err();
        assert_eq!(
            err.to_string(),
            "Generic error: paid amount 5 does not match value 10"
        );
    }

    #[test]
    fn redeem_success_emits_messages() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked(ADDR), &coins(10, "uwfUSD"));
        let msg = ExecuteMsg::Redeem {
            orig_sender: None,
            minter_address: ADDR.to_string(),
            denom: "uwfUSD".into(),
            value: "10".into(),
        };

        let res = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        assert_eq!(res.messages.len(), 2); // burn + bank send
    }

    #[test]
    fn feegrant_rejects_unauthorized() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked(ADDR), &[]);
        let msg = ExecuteMsg::Feegrant(FeegrantContractMsg::RevokeFeeAllowance {
            granter: "granter".to_string(),
            grantee: ADDR.to_string(),
        });

        let err = execute(deps.as_mut(), mock_env(), info, msg).unwrap_err();
        assert_eq!(
            err.to_string(),
            "Generic error: granter must be the sender".to_string()
        );
    }

    #[test]
    fn feegrant_revoke_success() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("granter"), &[]);
        let msg = ExecuteMsg::Feegrant(FeegrantContractMsg::RevokeFeeAllowance {
            granter: "granter".to_string(),
            grantee: "grantee".into(),
        });

        let res = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        assert_eq!(res.messages.len(), 1);
    }

    #[test]
    fn mint_ok() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        // most tokenfactory minting is restricted to controller/master/minter
        let info = message_info(&Addr::unchecked(ADDR), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::Mint {
            orig_sender: None,
            denom: "uwfUSD".to_string(),
            value: "10".to_string(),
            address: bech32_addr("wf").to_string(),
        });

        let resp = execute(deps.as_mut(), mock_env(), info, msg).unwrap();

        eprint!("resp: {:?}", resp);
    }

    #[test]
    fn mint_success_emits_message() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        // If master is allowed, this should work.
        let info = message_info(&Addr::unchecked("minter"), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::Mint {
            orig_sender: None,
            denom: "uwfUSD".to_string(),
            value: "10".to_string(),
            address: ADDR.to_string(),
        });

        let res = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        assert!(!res.messages.is_empty());
    }

    #[test]
    fn redeem_wrong_denom_funds_fails() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        // Pay the wrong denom so you exercise denom-check logic (often separate from amount-check)
        let info = message_info(&Addr::unchecked("user"), &coins(10, "wrongdenom"));
        let msg = ExecuteMsg::Redeem {
            orig_sender: None,
            minter_address: ADDR.to_string(), // <- bech32-valid
            denom: "uwfUSD".to_string(),
            value: "10".to_string(),
        };

        let err = execute(deps.as_mut(), mock_env(), info, msg).unwrap_err();
        let s = err.to_string().to_lowercase();
        assert!(s.contains("fund") || s.contains("denom") || s.contains("invalid"));
    }

    #[test]
    fn redeem_success_emits_burn_and_send() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("user"), &coins(10, "uwfUSD"));
        let msg = ExecuteMsg::Redeem {
            orig_sender: None,
            minter_address: ADDR.to_string(), // <- bech32-valid
            denom: "uwfUSD".to_string(),
            value: "10".to_string(),
        };

        let res = execute(deps.as_mut(), mock_env(), info, msg).unwrap();

        // - burn tokenfactory
        // - bank send out (or another chain msg)
        assert!(res.messages.len() >= 2);
    }

    #[test]
    fn feegrant_grant_unauthorized() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("not-granter"), &[]);
        let msg = ExecuteMsg::Feegrant(FeegrantContractMsg::GrantFeeBasicAllowance {
            granter: ADDR.to_string(),
            grantee: bech32_addr("wf").to_string(),
            allowance_denom: "uwfUSD".to_string(),
            allowance_value: "10".to_string(),
            hours_to_expire: 24,
        });

        let err = execute(deps.as_mut(), mock_env(), info, msg).unwrap_err();
        assert_eq!(
            err.to_string().to_lowercase(),
            "generic error: granter must be the sender"
        );
    }

    #[test]
    fn feegrant_grant_success_emits_message() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("granter"), &[]);
        let msg = ExecuteMsg::Feegrant(FeegrantContractMsg::GrantFeeBasicAllowance {
            granter: "granter".to_string(),
            grantee: bech32_addr("wf").to_string(),
            allowance_denom: "uwfUSD".to_string(),
            allowance_value: "10".to_string(),
            hours_to_expire: 0,
        });

        let res = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        assert_eq!(res.messages.len(), 1);
    }

    #[test]
    fn set_denom_metadata() {
        let mut deps = mock_dependencies_factory();
        init_storage(deps.as_mut().storage);

        let info = message_info(&Addr::unchecked("granter"), &[]);
        let msg = ExecuteMsg::Tf(TokenfactoryContractMsg::SetDenomMetadata {
            orig_sender: None,
            metadata: DenomMetadata {
                description: "".to_string(),
                denom_units: vec![],
                base: "".to_string(),
                display: "".to_string(),
                name: "".to_string(),
                symbol: "".to_string(),
                uri: None,
                uri_hash: None,
            },
        });

        let res = execute(deps.as_mut(), mock_env(), info, msg).unwrap();
        assert_eq!(res.messages.len(), 1);
    }
}
