//! Contract migration module.
//!
//! Contains the `migrate` entry point and all version-specific migration
//! helpers. See [`MigrateMsg`](crate::msg::MigrateMsg) for the full
//! design rationale, conventions, and developer checklist.
//!
//! # Convention
//!
//! - The `migrate` entry point matches on the
//!   `((prev_major, prev_minor), (new_major, new_minor))` version pair —
//!   **not** on the `MigrateMsg` variant.
//! - Every allowed migration — whether it changes state or not — dispatches
//!   to a dedicated `migrate_vX_to_vY` helper.
//! - The helper is responsible for validating the `MigrateMsg` variant
//!   (the sole enforcement, since the outer match gates only on the
//!   version pair).

#[cfg(not(feature = "library"))]
use cosmwasm_std::entry_point;
use cosmwasm_std::{DepsMut, Env, Response, StdError, StdResult};
use cw2::set_contract_version;
use cw_storage_plus::Item;
use semver::Version;

use crate::contract::{CONTRACT_NAME, CONTRACT_VERSION};
use crate::msg::MigrateMsg;
use crate::state::{Config, CONFIG};

/// Contract migration entry point.
///
/// This function is called exactly once per `MsgMigrateContract` transaction.
/// It is the **single place** responsible for all storage transformations —
/// both this contract's own state and any dependency state (e.g. `cw-ownable`,
/// `cw2`).
///
/// # Single-step enforcement
///
/// Only single-step migrations are supported. The function matches on the
/// `((prev_major, prev_minor), (new_major, new_minor))` version pair —
/// **not** on the `MigrateMsg` variant. Using `(major, minor)` tuples avoids
/// ambiguity when the major version bumps and minor resets to `0`
/// (e.g. `(0, 9) → (1, 0)` is distinct from `(1, 9) → (2, 0)`).
///
/// Every allowed migration — whether it changes state or not — dispatches
/// to a dedicated `migrate_vX_to_vY` helper. The helper is responsible for
/// validating the `MigrateMsg` variant it receives.
///
/// # Adding a new migration step
///
/// 1. Add a match arm for the version pair:
///    ```ignore
///    ((0, 3), (0, 4)) => migrate_v03_to_v04(deps.storage, deps.api, &msg)?,
///    ```
/// 2. Write a `migrate_vX_to_vY` helper in this module that:
///    - Validates the `MigrateMsg` variant (the sole enforcement, since
///      the outer match gates only on the version pair).
///    - Applies state transformations (if any).
///    - For code-only releases, validation is the only logic needed.
/// 3. If a dependency (e.g. `cw-ownable`) changed its storage schema in
///    the same release, call its migration helper inside `migrate_vX_to_vY`.
/// 4. `set_contract_version` is called **once** at the end, after the
///    migration step completes.
#[cfg_attr(not(feature = "library"), entry_point)]
pub fn migrate(
    deps: DepsMut,
    _env: Env,
    msg: MigrateMsg,
) -> StdResult<Response> {
    let prev = cw2::get_contract_version(deps.storage)?;

    if prev.contract != CONTRACT_NAME {
        return Err(StdError::generic_err(format!(
            "cannot migrate: expected contract '{}', got '{}'",
            CONTRACT_NAME, prev.contract
        )));
    }

    let prev_ver: Version = prev
        .version
        .parse()
        .map_err(|_| StdError::generic_err(format!("invalid stored version: {}", prev.version)))?;

    let new_ver: Version = CONTRACT_VERSION
        .parse()
        .map_err(|_| StdError::generic_err(format!("invalid new version: {}", CONTRACT_VERSION)))?;

    if prev_ver >= new_ver {
        return Err(StdError::generic_err(format!(
            "cannot migrate: current version {} is >= new version {}",
            prev_ver, new_ver
        )));
    }

    // Dispatch by (major, minor) version pair.
    // Each arm delegates to a helper that validates the MigrateMsg variant.
    match ((prev_ver.major, prev_ver.minor), (new_ver.major, new_ver.minor)) {
        ((0, 2), (0, 3)) => migrate_v02_to_v03(deps.storage, deps.api, &msg)?,
        // ((0, 3), (0, 4)) => migrate_v03_to_v04(deps.storage, deps.api, &msg)?,

        // Patch-level upgrade: same (major, minor), only patch differs.
        // The `prev_ver < new_ver` guard above already ensures the patch
        // version actually increased. No state changes needed.
        (prev, new) if prev == new => {
            // Validate that the caller sent the no-op variant.
            #[allow(unreachable_patterns)]
            match msg {
                MigrateMsg::V3 {} => {} // current minor — adjust when minor bumps
                _ => {
                    return Err(StdError::generic_err(
                        "patch-level migration requires the current version's MigrateMsg variant",
                    ));
                }
            }
        }
        _ => {
            return Err(StdError::generic_err(format!(
                "unsupported migration path: {} → {}. \
                 Migrate one version at a time.",
                prev_ver, new_ver
            )));
        }
    }

    set_contract_version(deps.storage, CONTRACT_NAME, CONTRACT_VERSION)?;

    Ok(Response::new()
        .add_attribute("action", "migrate")
        .add_attribute("from", prev_ver.to_string())
        .add_attribute("to", new_ver.to_string()))
}

// ===========================================================================
// Version-specific migration helpers
// ===========================================================================

/// Migrate state from v0.2.x to v0.3.0.
///
/// # Validation
///
/// Validates that `msg` is `MigrateMsg::V3 {}`. The `migrate` entry point
/// gates only on the version pair, so this check is the sole enforcement
/// that the operator sent the correct `MigrateMsg` variant.
///
/// # Changes
///
/// - **`Config.owner`** removed — ownership is now managed by `cw-ownable`.
///   This function reads the old `Config`, extracts `owner`, initialises
///   `cw-ownable` with that address, and re-saves `Config` without the field.
/// - **`TRUSTED_CONTRACT_CALLERS`**: new `Map<&Addr, bool>` — starts empty,
///   no migration action needed.
///
/// # Production types
///
/// Since this function only exists in the v0.3.0 binary (single-step
/// migration), it safely uses the production `CONFIG` item for its output.
fn migrate_v02_to_v03(
    storage: &mut dyn cosmwasm_std::Storage,
    api: &dyn cosmwasm_std::Api,
    msg: &MigrateMsg,
) -> StdResult<()> {
    use cosmwasm_schema::cw_serde;
    use cosmwasm_std::Addr;

    // Validate that the correct MigrateMsg variant was provided.
    // The `migrate` entry point gates only on the version pair, so this
    // is the sole enforcement of the correct variant.
    #[allow(unreachable_patterns)]
    let _ = match msg {
        MigrateMsg::V3 {} => msg,
        _ =>
            return Err(StdError::generic_err(
                "migrate_v02_to_v03 requires MigrateMsg::V3 {}",
            ))
    };

    // Define the old v1 Config inline (had an `owner` field).
    #[cw_serde]
    struct ConfigV1 {
        pub owner: Addr,
        pub is_tf: bool,
    }

    let item_v1: Item<ConfigV1> = Item::new("config");
    let old = item_v1.load(storage)?;

    // Initialize cw-ownable with the old owner address.
    cw_ownable::initialize_owner(storage, api, Some(old.owner.as_str()))
        .map_err(|e| StdError::generic_err(format!("failed to init cw-ownable: {e}")))?;

    // Re-save Config without the owner field (v2 schema).
    CONFIG.save(storage, &Config { is_tf: old.is_tf })?;

    Ok(())
}

// ---------------------------------------------------------------------------
// Future migration helpers — uncomment and implement when needed.
// Every release gets a helper, even code-only upgrades.
// ---------------------------------------------------------------------------
//
// /// Migrate state from v0.3.x to v0.4.0.
// ///
// /// # Validation
// ///
// /// Validates that `msg` is `MigrateMsg::V4 { .. }`.
// ///
// /// # Changes
// ///
// /// - (Describe state changes.)
// /// - (Describe dependency schema changes.)
// ///
// /// # Production types
// ///
// /// Since this function only exists in the v0.4.0 binary (single-step
// /// migration), it safely uses the production `CONFIG` item for its output.
// fn migrate_v03_to_v04(
//     _storage: &mut dyn cosmwasm_std::Storage,
//     _api: &dyn cosmwasm_std::Api,
//     _msg: &MigrateMsg,
// ) -> StdResult<()> {
//     #[allow(unreachable_patterns)]
//     let _ = match _msg {
//         MigrateMsg::V4 { .. } => _msg,
//         _ =>
//             return Err(StdError::generic_err(
//                 "migrate_v03_to_v04 requires MigrateMsg::V4 { .. }",
//             ))
//     };
//
//     // Extract params:
//     //   let MigrateMsg::V3 { new_param } = _msg else { unreachable!() };
//     //
//     //   // ... apply state changes using new_param ...
//
//     Ok(())
// }

#[cfg(test)]
mod tests {
    use super::*;
    use cosmwasm_schema::cw_serde;
    use cosmwasm_std::testing::{mock_env, MockApi, MockQuerier, MockStorage};
    use cosmwasm_std::{Addr, Api, OwnedDeps};
    use cw2::{get_contract_version, set_contract_version};
    use cw_storage_plus::Item;
    use std::marker::PhantomData;

    fn mock_deps() -> OwnedDeps<MockStorage, MockApi, MockQuerier> {
        OwnedDeps {
            storage: MockStorage::default(),
            api: MockApi::default().with_prefix("wf"),
            querier: MockQuerier::new(&[]),
            custom_query_type: PhantomData,
        }
    }

    fn bech32_addr_with_seed(seed: u8) -> String {
        use bech32::{Bech32, primitives::hrp::Hrp};
        let data = vec![seed; 20];
        bech32::encode::<Bech32>(Hrp::parse("wf").unwrap(), &data)
            .unwrap()
            .to_string()
    }

    /// Seed storage with v0.2.0 state: cw2 version + old Config (with `owner` field).
    fn seed_v2_state(storage: &mut dyn cosmwasm_std::Storage, owner: &str) {
        set_contract_version(storage, CONTRACT_NAME, "0.2.0").unwrap();

        #[cw_serde]
        struct ConfigV1 {
            pub owner: Addr,
            pub is_tf: bool,
        }

        let item_v1: Item<ConfigV1> = Item::new("config");
        item_v1
            .save(
                storage,
                &ConfigV1 {
                    owner: Addr::unchecked(owner),
                    is_tf: true,
                },
            )
            .unwrap();
    }

    /// Seed storage with v0.3.x state: cw2 version + current Config + cw-ownable.
    /// Used for patch-upgrade tests.
    fn seed_v3_state(deps: &mut OwnedDeps<MockStorage, MockApi, MockQuerier>, version: &str) {
        set_contract_version(deps.as_mut().storage, CONTRACT_NAME, version).unwrap();
        CONFIG.save(deps.as_mut().storage, &Config { is_tf: true }).unwrap();
        cw_ownable::initialize_owner(
            deps.as_mut().storage,
            &MockApi::default().with_prefix("wf"),
            Some(&bech32_addr_with_seed(1)),
        )
            .unwrap();
    }

    // === Entry point: version validation ===

    #[test]
    fn rejects_wrong_contract_name() {
        let mut deps = mock_deps();
        set_contract_version(deps.as_mut().storage, "wrong-contract", "0.1.0").unwrap();

        let err = migrate(deps.as_mut(), mock_env(), MigrateMsg::V3 {}).unwrap_err();
        assert!(err.to_string().contains("expected contract"));
    }

    #[test]
    fn rejects_same_version() {
        let mut deps = mock_deps();
        set_contract_version(deps.as_mut().storage, CONTRACT_NAME, CONTRACT_VERSION).unwrap();

        let err = migrate(deps.as_mut(), mock_env(), MigrateMsg::V3 {}).unwrap_err();
        assert!(err.to_string().contains(">="));
    }

    #[test]
    fn rejects_newer_stored_version() {
        let mut deps = mock_deps();
        set_contract_version(deps.as_mut().storage, CONTRACT_NAME, "99.0.0").unwrap();

        let err = migrate(deps.as_mut(), mock_env(), MigrateMsg::V3 {}).unwrap_err();
        assert!(err.to_string().contains(">="));
    }

    #[test]
    fn rejects_unsupported_version_pair() {
        let mut deps = mock_deps();
        set_contract_version(deps.as_mut().storage, CONTRACT_NAME, "0.0.1").unwrap();

        let err = migrate(deps.as_mut(), mock_env(), MigrateMsg::V3 {}).unwrap_err();
        assert!(err.to_string().contains("unsupported migration path"));
    }

    // === Schema v0.2.x → v0.3.0: happy path ===

    #[test]
    fn v02_to_v03_migrates_owner_to_cw_ownable() {
        let mut deps = mock_deps();
        let owner = bech32_addr_with_seed(42);
        seed_v2_state(deps.as_mut().storage, &owner);

        let res = migrate(deps.as_mut(), mock_env(), MigrateMsg::V3 {}).unwrap();
        assert!(res.attributes.iter().any(|a| a.key == "action" && a.value == "migrate"));
        assert!(res.attributes.iter().any(|a| a.key == "from" && a.value == "0.2.0"));
        assert!(res.attributes.iter().any(|a| a.key == "to" && a.value == CONTRACT_VERSION));

        let ownership = cw_ownable::get_ownership(deps.as_ref().storage).unwrap();
        assert_eq!(ownership.owner.unwrap().to_string(), owner);
    }

    #[test]
    fn v02_to_v03_removes_owner_from_config() {
        let mut deps = mock_deps();
        let owner = bech32_addr_with_seed(42);
        seed_v2_state(deps.as_mut().storage, &owner);

        migrate(deps.as_mut(), mock_env(), MigrateMsg::V3 {}).unwrap();

        let cfg = CONFIG.load(deps.as_ref().storage).unwrap();
        assert!(cfg.is_tf);
    }

    #[test]
    fn v02_to_v03_updates_cw2_version() {
        let mut deps = mock_deps();
        seed_v2_state(deps.as_mut().storage, &bech32_addr_with_seed(1));

        migrate(deps.as_mut(), mock_env(), MigrateMsg::V3 {}).unwrap();

        let info = get_contract_version(deps.as_ref().storage).unwrap();
        assert_eq!(info.contract, CONTRACT_NAME);
        assert_eq!(info.version, CONTRACT_VERSION);
    }

    #[test]
    fn v02_to_v03_preserves_is_tf_false() {
        let mut deps = mock_deps();
        let owner = bech32_addr_with_seed(42);
        set_contract_version(deps.as_mut().storage, CONTRACT_NAME, "0.2.0").unwrap();

        #[cw_serde]
        struct ConfigV1 {
            pub owner: Addr,
            pub is_tf: bool,
        }
        let item_v1: Item<ConfigV1> = Item::new("config");
        item_v1
            .save(
                deps.as_mut().storage,
                &ConfigV1 {
                    owner: Addr::unchecked(&owner),
                    is_tf: false,
                },
            )
            .unwrap();

        migrate(deps.as_mut(), mock_env(), MigrateMsg::V3 {}).unwrap();

        let cfg = CONFIG.load(deps.as_ref().storage).unwrap();
        assert!(!cfg.is_tf);
    }

    #[test]
    fn v02_to_v03_trusted_callers_map_starts_empty() {
        use crate::state::TRUSTED_CONTRACT_CALLERS;

        let mut deps = mock_deps();
        seed_v2_state(deps.as_mut().storage, &bech32_addr_with_seed(1));

        migrate(deps.as_mut(), mock_env(), MigrateMsg::V3 {}).unwrap();

        let addr = deps.api.addr_validate(&bech32_addr_with_seed(99)).unwrap();
        let val = TRUSTED_CONTRACT_CALLERS
            .may_load(deps.as_ref().storage, &addr)
            .unwrap();
        assert!(val.is_none());
    }

    // === Schema v0.2.x → v0.3.0: patch version compatibility ===

    #[test]
    fn v02_patch_to_v03_succeeds() {
        let mut deps = mock_deps();
        let owner = bech32_addr_with_seed(42);
        set_contract_version(deps.as_mut().storage, CONTRACT_NAME, "0.2.5").unwrap();

        #[cw_serde]
        struct ConfigV1 {
            pub owner: Addr,
            pub is_tf: bool,
        }
        let item_v1: Item<ConfigV1> = Item::new("config");
        item_v1
            .save(
                deps.as_mut().storage,
                &ConfigV1 {
                    owner: Addr::unchecked(&owner),
                    is_tf: true,
                },
            )
            .unwrap();

        let res = migrate(deps.as_mut(), mock_env(), MigrateMsg::V3 {});
        assert!(res.is_ok());
    }

    // === migrate_v02_to_v03 helper: MigrateMsg variant validation ===

    #[test]
    fn v02_to_v03_helper_accepts_correct_variant() {
        let mut deps = mock_deps();
        let owner = bech32_addr_with_seed(42);
        seed_v2_state(deps.as_mut().storage, &owner);

        let api = MockApi::default().with_prefix("wf");
        let result = migrate_v02_to_v03(deps.as_mut().storage, &api, &MigrateMsg::V3 {});
        assert!(result.is_ok());
    }

    // Uncomment when a second MigrateMsg variant exists (e.g. V4):
    //
    // #[test]
    // fn v02_to_v03_helper_rejects_wrong_variant() {
    //     let mut deps = mock_deps();
    //     let owner = bech32_addr_with_seed(42);
    //     seed_v2_state(deps.as_mut().storage, &owner);
    //
    //     let api = MockApi::default().with_prefix("wf");
    //     let err = migrate_v02_to_v03(deps.as_mut().storage, &api, &MigrateMsg::V4 {})
    //         .unwrap_err();
    //     assert!(err.to_string().contains("migrate_v02_to_v03 requires MigrateMsg::V3"));
    // }
    //
    // #[test]
    // fn patch_upgrade_rejects_wrong_variant() {
    //     let mut deps = mock_deps();
    //     let current: Version = CONTRACT_VERSION.parse().unwrap();
    //     if current.patch < 1 { return; }
    //
    //     let prev = format!("{}.{}.0", current.major, current.minor);
    //     seed_v3_state(&mut deps, &prev);
    //
    //     let err = migrate(deps.as_mut(), mock_env(), MigrateMsg::V4 {}).unwrap_err();
    //     assert!(err.to_string().contains("patch-level migration requires"));
    // }

    // === Double migration prevention ===

    #[test]
    fn cannot_migrate_twice() {
        let mut deps = mock_deps();
        seed_v2_state(deps.as_mut().storage, &bech32_addr_with_seed(1));

        migrate(deps.as_mut(), mock_env(), MigrateMsg::V3 {}).unwrap();

        let err = migrate(deps.as_mut(), mock_env(), MigrateMsg::V3 {}).unwrap_err();
        assert!(err.to_string().contains(">=") || err.to_string().contains("unsupported"));
    }

    // === Patch-level upgrade (same major.minor) ===

    #[test]
    fn patch_upgrade_same_minor_succeeds() {
        let mut deps = mock_deps();
        let current: Version = CONTRACT_VERSION.parse().unwrap();

        // This test is only meaningful when CONTRACT_VERSION has patch >= 1.
        if current.patch < 1 {
            return;
        }

        let prev = format!("{}.{}.0", current.major, current.minor);
        seed_v3_state(&mut deps, &prev);

        let res = migrate(deps.as_mut(), mock_env(), MigrateMsg::V3 {});
        assert!(res.is_ok());

        let info = get_contract_version(deps.as_ref().storage).unwrap();
        assert_eq!(info.version, CONTRACT_VERSION);
    }

    #[test]
    fn patch_upgrade_updates_cw2_version() {
        let mut deps = mock_deps();
        let current: Version = CONTRACT_VERSION.parse().unwrap();

        if current.patch < 1 {
            return;
        }

        let prev = format!("{}.{}.0", current.major, current.minor);
        seed_v3_state(&mut deps, &prev);

        migrate(deps.as_mut(), mock_env(), MigrateMsg::V3 {}).unwrap();

        let info = get_contract_version(deps.as_ref().storage).unwrap();
        assert_eq!(info.contract, CONTRACT_NAME);
        assert_eq!(info.version, CONTRACT_VERSION);
    }

    #[test]
    fn patch_upgrade_returns_correct_attributes() {
        let mut deps = mock_deps();
        let current: Version = CONTRACT_VERSION.parse().unwrap();

        if current.patch < 1 {
            return;
        }

        let prev = format!("{}.{}.0", current.major, current.minor);
        seed_v3_state(&mut deps, &prev);

        let res = migrate(deps.as_mut(), mock_env(), MigrateMsg::V3 {}).unwrap();
        assert!(res.attributes.iter().any(|a| a.key == "action" && a.value == "migrate"));
        assert!(res.attributes.iter().any(|a| a.key == "from" && a.value == prev));
        assert!(res.attributes.iter().any(|a| a.key == "to" && a.value == CONTRACT_VERSION));
    }

    #[test]
    fn patch_upgrade_does_not_alter_config() {
        let mut deps = mock_deps();
        let current: Version = CONTRACT_VERSION.parse().unwrap();

        if current.patch < 1 {
            return;
        }

        let prev = format!("{}.{}.0", current.major, current.minor);
        seed_v3_state(&mut deps, &prev);

        let cfg_before = CONFIG.load(deps.as_ref().storage).unwrap();
        migrate(deps.as_mut(), mock_env(), MigrateMsg::V3 {}).unwrap();
        let cfg_after = CONFIG.load(deps.as_ref().storage).unwrap();

        assert_eq!(cfg_before.is_tf, cfg_after.is_tf);
    }

    #[test]
    fn patch_upgrade_does_not_alter_ownership() {
        let mut deps = mock_deps();
        let current: Version = CONTRACT_VERSION.parse().unwrap();

        if current.patch < 1 {
            return;
        }

        let prev = format!("{}.{}.0", current.major, current.minor);
        seed_v3_state(&mut deps, &prev);

        let owner_before = cw_ownable::get_ownership(deps.as_ref().storage).unwrap();
        migrate(deps.as_mut(), mock_env(), MigrateMsg::V3 {}).unwrap();
        let owner_after = cw_ownable::get_ownership(deps.as_ref().storage).unwrap();

        assert_eq!(owner_before.owner, owner_after.owner);
    }
}