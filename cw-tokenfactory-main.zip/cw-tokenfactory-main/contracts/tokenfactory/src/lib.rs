pub use tokenfactory_bindings::query::*;

pub mod contract;
pub mod msg;
pub mod query;
pub mod state;
#[cfg(not(target_arch = "wasm32"))]
pub mod test;

pub const PACKAGE_NAME: &str = env!("CARGO_PKG_NAME");