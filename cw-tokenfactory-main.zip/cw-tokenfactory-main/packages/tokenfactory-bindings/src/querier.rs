use crate::query::{AllBlacklistedResponse, AllDenomMetadataResponse, AllMinterControllersResponse, AllMintersResponse, AllMintingDenomsResponse, BankQuery, BlacklistedResponse, BlacklisterResponse, DenomMetadataResponse, FactoryQuery, FeeBasicAllowanceResponse, FeegrantQuery, FindDenomMetadataResponse, MasterMinterResponse, MinterControllerResponse, MintersResponse, MintingDenomResponse, OwnerResponse, ParamsResponse, PausedResponse, PauserResponse, TokenfactoryQuery};
use cosmwasm_std::{QuerierWrapper, StdResult};

/// This query wrapper pattern eases the use of custom query types.
pub struct FQuerier<'a> {
    querier: &'a QuerierWrapper<'a, FactoryQuery>,
}

impl<'a> FQuerier<'a> {
    pub fn new(querier: &'a QuerierWrapper<'a, FactoryQuery>) -> Self {
        FQuerier { querier }
    }

    pub fn params(&self, _: bool) -> StdResult<ParamsResponse> {
        let q = {
            let q = TokenfactoryQuery::Params {};
            FactoryQuery::Tf(q)
        };
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
        
    }

    pub fn owner(&self, _: bool) -> StdResult<OwnerResponse> {
        let q =  {
            FactoryQuery::Tf(TokenfactoryQuery::Owner {})
        };
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn master_minter(&self, _: bool) -> StdResult<MasterMinterResponse> {
        let q = {
            FactoryQuery::Tf(TokenfactoryQuery::MasterMinter {})
        };
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn minter_controller(
        &self,
        controller: String,
        minter: String,
        _: bool,
    ) -> StdResult<MinterControllerResponse> {
        let q = {
            FactoryQuery::Tf(TokenfactoryQuery::MinterController { controller, minter })
        };
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn all_minter_controllers(&self, _: bool) -> StdResult<AllMinterControllersResponse> {
        let q = {
            FactoryQuery::Tf(TokenfactoryQuery::AllMinterControllers {})
        };
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn minting_denom(&self, denom: String, _: bool) -> StdResult<MintingDenomResponse> {
        let q = {
            FactoryQuery::Tf(TokenfactoryQuery::MintingDenom { denom })
        };
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn all_minting_denoms(&self, _: bool) -> StdResult<AllMintingDenomsResponse> {
        let q = {
            FactoryQuery::Tf(TokenfactoryQuery::AllMintingDenoms {})
        };
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }
    
    pub fn minters(&self, address: String, denom: String, _: bool) -> StdResult<MintersResponse> {
        let q = {
            FactoryQuery::Tf(TokenfactoryQuery::Minters { address, denom })
        };
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn all_minters(&self, _: bool) -> StdResult<AllMintersResponse> {
        let q = {
            FactoryQuery::Tf(TokenfactoryQuery::AllMinters {})
        };
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn blacklister(&self, _: bool) -> StdResult<BlacklisterResponse> {
        let q = {
            FactoryQuery::Tf(TokenfactoryQuery::Blacklister {})
        };
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn pauser(&self, _: bool) -> StdResult<PauserResponse> {
        let q = {
            FactoryQuery::Tf(TokenfactoryQuery::Pauser {})
        };
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn blacklisted(&self, address: String, _: bool) -> StdResult<BlacklistedResponse> {
        let q = {
            FactoryQuery::Tf(TokenfactoryQuery::Blacklisted { address })
        };
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn all_blacklisted(&self, _: bool) -> StdResult<AllBlacklistedResponse> {
        let q = {
            FactoryQuery::Tf(TokenfactoryQuery::AllBlacklisted {})
        };
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn paused(&self, _: bool) -> StdResult<PausedResponse> {
        let q = {
            FactoryQuery::Tf(TokenfactoryQuery::Paused {})
        };
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn denom_metadata(&self, denom: String) -> StdResult<DenomMetadataResponse> {
        let q = FactoryQuery::Bank(BankQuery::DenomMetadata { denom });
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn all_denom_metadata(&self) -> StdResult<AllDenomMetadataResponse> {
        let q = FactoryQuery::Bank(BankQuery::AllDenomMetadata {});
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn find_denom_metadata(
        &self,
        base_denom: String,
        denom: String,
    ) -> StdResult<FindDenomMetadataResponse> {
        let q = FactoryQuery::Bank(BankQuery::FindDenomMetadata { base_denom, denom });
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn find_metadata_for_denom(&self, denom: String) -> StdResult<FindDenomMetadataResponse> {
        let q = FactoryQuery::Bank(BankQuery::FindMetadataForDenom { denom });
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }

    pub fn fee_basic_allowance(
        &self,
        granter: String,
        grantee: String,
    ) -> StdResult<FeeBasicAllowanceResponse> {
        let q = FactoryQuery::Feegrant(FeegrantQuery::FeeBasicAllowance { granter, grantee });
        let request = FactoryQuery::into(q);
        self.querier.query(&request)
    }
}
