# cw-tokenfactory
It provides bindings and contract/query wrappers for x/tokenfactory, and some APIs for x/bank and x/feegrant.

## Notes:
* Mutex: tokio suggests using futures::lock::Mutex instead of std::sync::Mutex. We attempted to replace the latter with the former in wallet_svc - in wallet_svc crate proper, it is doable but in dependencies pkcs11 (sdk) and cosmos-pkcs11, the std version is used. We need to look deeper there.
>* One thing we can do is since tsstrio feature does not depend on pkcs11, we use futures' Mutex for it.