# cw-tokenfactory
It provides bindings and contract/query wrappers for x/tokenfactory, and some APIs for x/bank and x/feegrant.

## tests
### unit tests
```shell
cargo test
```
### integration tests
> - manual integration tests are in ./tests folder.

### coverage
```shell
cargo llvm-cov --html
open target/llvm-cov/html/index.html
```shell


## apply linting
```shell
# Optimize Imports for the whole workspace: right-click on the workspace root folder in RustRover IDE and select Optimize Imports.
# unfortunately, the above does not remove unused imports.

# check the whole workspace. it will show unused imports, among other things.
# manually remove unused imports.
cargo check --workspace --features=p11hsm --no-default-features 
cargo check --workspace --features=tsstrio --no-default-features 

# Reformat the whole workspace: right-click on the workspace root folder in RustRover IDE and select Reformat Code.
# Or run the following commands.
cargo fmt --all --check # it will display the proposed changes.
cargo fmt --all

# clippy the whole workspace; review recommendations and make appropriate changes.
cargo clippy --workspace
# or clippy an individual package
cargo clippy -p tokenfactory
cargo clippy -p tokenfactory-bindings

```

## Notes:
* Mutex: tokio suggests using futures::lock::Mutex instead of std::sync::Mutex. We attempted to replace the latter with the former in wallet_svc - in wallet_svc crate proper, it is doable but in dependencies pkcs11 (sdk) and cosmos-pkcs11, the std version is used. We need to look deeper there.
>* One thing we can do is since tsstrio feature does not depend on pkcs11, we use futures' Mutex for it.