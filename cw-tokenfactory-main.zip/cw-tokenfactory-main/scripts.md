# scripts for tokenfactory smart contract
## build wasm
```shell
## build wasm
# rust 1.69.0 will produce valid wasm. 
# rust 1.70.0+ need to run wasm-opt with --signext-lowering
RUSTFLAGS='-C link-arg=-s' cargo wasm -v

# in order to use 1.70+, we need to run wasm-opt with --signext-lowering
#  refs: https://github.com/CosmWasm/cosmwasm/issues/1727   https://github.com/CosmWasm/optimizer/blob/v0.14.0/optimize.sh

# validate wasm will fail if built with rust 1.70.0+
# note: 2026-01-04 - built with 1.80.0 and the check passed. good news but is that expected?
cosmwasm-check \
  ./target/wasm32-unknown-unknown/release/tokenfactory.wasm \
  --available-capabilities "tokenfactory, iterator, staking, cosmwasm_1_1, cosmwasm_1_2, cosmwasm_1_3" 

# optimize wasm to produce tokenfactory_optimized.wasm and also to support 1.70.0+ build
# 1.87.0+ fails.
wasm-opt -Os --signext-lowering \
  ./target/wasm32-unknown-unknown/release/tokenfactory.wasm \
  -o ./target/wasm32-unknown-unknown/release/tokenfactory_optimized.wasm
# this is more optimized that the above. similar to cosmwasm/workspace-optimizer
wasm-opt -Oz --strip-debug \
  ./target/wasm32-unknown-unknown/release/tokenfactory.wasm \
  -o ./target/wasm32-unknown-unknown/release/tokenfactory_optimized.wasm

# validate tokenfactory_optimized.wasm will pass
cosmwasm-check \
  ./target/wasm32-unknown-unknown/release/tokenfactory_optimized.wasm \
  --available-capabilities "tokenfactory, iterator, staking, cosmwasm_1_1, cosmwasm_1_2, cosmwasm_1_3" 

# schema
cd ./contracts/tokenfactory
cargo run schema
```

## Deploy on noblefork chain
See https://github.com/wfblockchain/noblefork/blob/main/scripts.md .

## tests
### unit tests
```shell
cargo test
```
### integration tests
> - manual integration tests are in ./tests folder.

### coverage
```shell
cargo cov --html
cargo llvm-cov --html
open target/llvm-cov/html/index.html
```

## apply linting
```shell
# Optimize Imports for the whole workspace: right-click on the workspace root folder in RustRover IDE and select Optimize Imports.
# unfortunately, the above does not remove unused imports.

# check the whole workspace. it will show unused imports, among other things.
# manually remove unused imports.
cargo check --workspace --features=p11hsm --no-default-features 
cargo check --workspace --features=tsstrio --no-default-features 

# Reformat the whole workspace: right-click on the workspace root folder in RustRover IDE and select Reformat Code.
# Or run the following commands.
cargo fmt --all --check # it will display the proposed changes.
cargo fmt --all

# clippy the whole workspace; review recommendations and make appropriate changes.
cargo clippy --workspace
# or clippy an individual package
cargo clippy -p tokenfactory
cargo clippy -p tokenfactory-bindings

```

## Useful commands
```shell
zip -r cw_tokenfactory.zip Cargo.toml Cargo.lock contracts packages \
    -x "**/schema/**" \
    -x .DS_Store
```
