#![cfg(test)]
use crate::{
    application::{CbBlkchnSvcApp, APP},
    proto, server,
};
use once_cell::sync::OnceCell;
use std::sync::Once;
use std::{fs, panic, path::PathBuf};

use crate::coverage_runtime_test_util::{cosmos_grpc_global, wait_for_tcp};
use abscissa_core::Application;
use blkchn_svc_proto::blkchn_svc_v1::blkchn_svc_server::BlkchnSvc;
use kms_common::async_signer::AsyncSigner;
use kms_svc_proto::kms_svc_v1::{
    DescribeRequest, DescribeResponse, GenKeyRequest, GenKeyResponse, ListKeyTypesRequest,
    ListKeyTypesResponse, ListProvidersRequest, ListProvidersResponse, PingRequest, PingResponse,
};
use tonic::{Request, Response, Status};
// ---------- Mock KMS gRPC service ----------

#[derive(Clone)]
struct MockKms {
    // k256 signing key (secp256k1)
    sk: k256::ecdsa::SigningKey,
}

#[tonic::async_trait]
impl crate::kms_proto::kms_svc_server::KmsSvc for MockKms {
    async fn ping(&self, _request: Request<PingRequest>) -> Result<Response<PingResponse>, Status> {
        Ok(Response::new(PingResponse::default()))
    }

    async fn describe(
        &self,
        _request: Request<DescribeRequest>,
    ) -> Result<Response<DescribeResponse>, Status> {
        Ok(Response::new(DescribeResponse::default()))
    }

    async fn list_providers(
        &self,
        _request: Request<ListProvidersRequest>,
    ) -> Result<Response<ListProvidersResponse>, Status> {
        Ok(Response::new(ListProvidersResponse::default()))
    }

    async fn list_provider_key_types(
        &self,
        _request: Request<ListKeyTypesRequest>,
    ) -> Result<Response<ListKeyTypesResponse>, Status> {
        Ok(Response::new(ListKeyTypesResponse::default()))
    }

    async fn gen_key(
        &self,
        _request: Request<GenKeyRequest>,
    ) -> Result<Response<GenKeyResponse>, Status> {
        Ok(Response::new(GenKeyResponse::default()))
    }

    async fn get_pub_key(
        &self,
        _request: Request<crate::kms_proto::GetPubKeyRequest>,
    ) -> Result<Response<crate::kms_proto::GetPubKeyResponse>, Status> {
        let vk = self.sk.verifying_key();
        let pub_uncompressed = vk.to_encoded_point(false); // 65 bytes, 0x04 + X + Y

        Ok(Response::new(crate::kms_proto::GetPubKeyResponse {
            header: None,
            key_name: "".to_string(),
            attributes: None,
            pub_key: prost::bytes::Bytes::from(pub_uncompressed.as_bytes().to_vec()),
        }))
    }

    async fn sign_msg(
        &self,
        request: Request<crate::kms_proto::SignMsgRequest>,
    ) -> Result<Response<crate::kms_proto::SignMsgResponse>, Status> {
        use k256::ecdsa::signature::Signer;

        let msg = request.into_inner().msg;
        let sig: k256::ecdsa::Signature = self.sk.sign(msg.as_ref()); // ECDSA over bytes

        Ok(Response::new(crate::kms_proto::SignMsgResponse {
            header: None,
            key_name: "".to_string(),
            attributes: None,
            msg,
            sig: prost::bytes::Bytes::from(sig.to_bytes().to_vec()), // 64 bytes r||s
        }))
    }

    async fn sign_prehash(
        &self,
        request: Request<crate::kms_proto::SignPrehashRequest>,
    ) -> Result<Response<crate::kms_proto::SignPrehashResponse>, Status> {
        use k256::ecdsa::signature::hazmat::PrehashSigner;

        let hash = request.into_inner().hash;
        let hash: [u8; 32] = hash
            .as_ref()
            .try_into()
            .map_err(|_| Status::invalid_argument("hash must be 32 bytes"))?;

        let sig: k256::ecdsa::Signature = self
            .sk
            .sign_prehash(&hash)
            .map_err(|e| Status::internal(e.to_string()))?;

        Ok(Response::new(crate::kms_proto::SignPrehashResponse {
            header: None,
            key_name: "".to_string(),
            attributes: None,
            hash: Default::default(),
            sig: prost::bytes::Bytes::from(sig.to_bytes().to_vec()),
        }))
    }
}

// ---------- Test helpers ----------
static INIT: Once = Once::new();
// static INIT: OnceCell<()> = OnceCell::new();

static KMS_GRPC: OnceCell<String> = OnceCell::new();

fn kms_grpc_global() -> String {
    KMS_GRPC
        .get_or_init(|| {
            // Bind once to an ephemeral port
            let std_listener = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
            std_listener.set_nonblocking(true).unwrap();
            let addr = std_listener.local_addr().unwrap();

            // Start tonic server on a dedicated OS thread with its own Tokio runtime
            std::thread::spawn(move || {
                let rt = tokio::runtime::Runtime::new().unwrap();
                rt.block_on(async move {
                    let listener = tokio::net::TcpListener::from_std(std_listener).unwrap();
                    let incoming = tokio_stream::wrappers::TcpListenerStream::new(listener);

                    let sk = k256::ecdsa::SigningKey::random(&mut rand::thread_rng());
                    let svc = MockKms { sk };

                    tonic::transport::Server::builder()
                        .add_service(crate::kms_proto::kms_svc_server::KmsSvcServer::new(svc))
                        .serve_with_incoming(incoming)
                        .await
                        .unwrap();
                });
            });

            // Return "host:port" (your KmsSigner::new() prepends http://)
            format!("127.0.0.1:{}", addr.port())
        })
        .clone()
}

pub fn init_app_once(kms_grpc: &str) {
    INIT.call_once(|| {
        let dir = std::env::temp_dir().join(format!("cb_blkchn_svc_test_{}", uuid::Uuid::new_v4()));
        fs::create_dir_all(&dir).unwrap();
        let cfg_path: PathBuf = dir.join("cb_blkchn_svc.toml");

        let cosmos = cosmos_grpc_global(); // if you need success-path Cosmos tests
        let toml = format!(
            r#"
[kms_server]
grpc = "{kms_grpc}"

[blkchn_server]
grpc = "not_a_valid_address"  # intentional: makes start.rs panic at addr.parse().unwrap()
authz_server = ""
jwks_url = ""
audience = ""

[chains.tokenfactory]
grpc = "http://{cosmos}"
prefix = "cosmos"
gas_denom = "uwfUSD"
gas_price = "0.01"
gas_adjustment = "1.2"
tx_poll_interval = 1
tx_poll_timeout = 1
tokenfactory_contract = ""
aurum_contract = ""
[chains.tokenfactory.faucet]
grpc = "http://{cosmos}"
address = ""
allowance_value = "1"
hours_to_expire = 1

[chains.bitcon]

[chains.ethereum]
rpc_url = "http://127.0.0.1:1"
chain_id = 11155111
wf_deposit_token_address = "0x0000000000000000000000000000000000000000"

[chains.base]
rpc_url = "http://127.0.0.1:65535"
chain_id = 84532
wf_deposit_token_address = "0x0000000000000000000000000000000000000000"

[chains.anvil]
rpc_url = "http://127.0.0.1:8545"
chain_id = 31337
wf_deposit_token_address = "0x0000000000000000000000000000000000000000"

"#,
            kms_grpc = kms_grpc,
            cosmos = cosmos
        );

        fs::write(&cfg_path, toml).unwrap();

        let args = vec![
            "cb_blkchn_svc",
            "-c",
            cfg_path.to_str().unwrap(),
            "start",
            "x",
        ];

        // Silence panic output just for this init call
        let prev_hook = panic::take_hook();
        panic::set_hook(Box::new(|_| {}));

        let res = panic::catch_unwind(|| {
            CbBlkchnSvcApp::run(&APP, args);
        });

        // Restore hook
        panic::set_hook(prev_hook);

        // We EXPECT start to panic (invalid addr). If it doesn't, we'd hang.
        assert!(
            res.is_err(),
            "expected StartCmd to panic due to invalid grpc addr"
        );
    });
}

pub fn _init_app_once(kms_grpc: &str) {
    INIT.call_once(|| {
        // Create a temp config file with an INVALID blkchn_server.grpc
        // so `start` panics early at `parse().unwrap()` AFTER APP is set.
        let dir = std::env::temp_dir().join(format!("cb_blkchn_svc_test_{}", uuid::Uuid::new_v4()));
        fs::create_dir_all(&dir).unwrap();
        let cfg_path: PathBuf = dir.join("cb_blkchn_svc.toml");

        let cosmos_grpc = cosmos_grpc_global(); // "127.0.0.1:PORT"

        let toml = format!(
            r#"
[kms_server]
grpc = "{kms_grpc}"

[blkchn_server]
grpc = "not_a_valid_address"
authz_server = ""
jwks_url = ""
audience = ""

[chains.tokenfactory]
grpc = "http://{cosmos_grpc}"
prefix = "cosmos"
gas_denom = "uwfUSD"
gas_price = "0.01"
gas_adjustment = "1.2"
tx_poll_interval = 1
tx_poll_timeout = 1
tokenfactory_contract = ""
aurum_contract = ""

[chains.tokenfactory.faucet]
grpc = "http://{cosmos_grpc}"
address = ""
allowance_value = "1"
hours_to_expire = 1

[chains.bitcon]

[chains.ethereum]
rpc_url = "http://127.0.0.1:1"
chain_id = 11155111
wf_deposit_token_address = "0x0000000000000000000000000000000000000000"

[chains.base]
rpc_url = "http://127.0.0.1:65535"
chain_id = 84532
wf_deposit_token_address = "0x0000000000000000000000000000000000000000"

[chains.anvil]
rpc_url = "http://127.0.0.1:8545"
chain_id = 31337
wf_deposit_token_address = "0x0000000000000000000000000000000000000000"

"#,
            kms_grpc = kms_grpc,
            cosmos_grpc = cosmos_grpc,
        );

        fs::write(&cfg_path, toml).unwrap();

        // Run the app entrypoint, but catch the panic caused by invalid grpc addr
        let args = vec![
            "cb_blkchn_svc",
            "-c",
            cfg_path.to_str().unwrap(),
            "start",
            "x",
        ];

        let _ = panic::catch_unwind(|| {
            CbBlkchnSvcApp::run(&APP, args);
        });

        // After this, APP is initialized and APP.config() works in tests.
    });
}
// ---------- Tests that “light up” the big modules ----------

#[tokio::test(flavor = "multi_thread")]
async fn something_that_needs_app_config() {
    let kms_grpc = kms_grpc_global();
    let kms_grpc2 = kms_grpc.clone();
    tokio::task::spawn_blocking(move || init_app_once(&kms_grpc2))
        .await
        .unwrap();

    // now this works:
    let cfg = APP.config();
    assert_eq!(cfg.chains.tokenfactory.gas_denom, "uwfUSD");
}

#[tokio::test(flavor = "multi_thread")]
async fn server_get_addr_cosmos_and_evm_execute() {
    let kms_grpc = kms_grpc_global();
    let kms_grpc2 = kms_grpc.clone();
    tokio::task::spawn_blocking(move || init_app_once(&kms_grpc2))
        .await
        .unwrap();

    let blkchn = server::Blkchn::new();

    let key_info = proto::KeyInfo {
        kms_provider_uuid: "uuid".to_string(),
        key_name: "key".to_string(),
        key_type: proto::KeyType::Secp256k1 as i32,
    };

    // Cosmos address path (tf/types.rs)
    let req = proto::GetAddrRequest {
        chain: Some(proto::Chain::Tokenfactory as i32),
        key_info: Some(key_info.clone()),
    };
    let resp = blkchn
        .get_addr(Request::new(req))
        .await
        .expect("cosmos get_addr should succeed with mock KMS")
        .into_inner();
    assert!(resp.address.starts_with("cosmos"));

    // EVM address path (evm/types.rs)
    let req = proto::GetAddrRequest {
        chain: Some(proto::Chain::Ethereum as i32),
        key_info: Some(key_info),
    };
    let resp = blkchn
        .get_addr(Request::new(req))
        .await
        .expect("eth get_addr should succeed with mock KMS")
        .into_inner();
    assert!(resp.address.starts_with("0x"));
}

#[tokio::test(flavor = "multi_thread")]
async fn tf_send_mint_redeem_execute_and_fail_late() {
    // let (kms_grpc, _handle) = start_mock_kms().await;
    let kms_grpc = kms_grpc_global();
    let kms_grpc2 = kms_grpc.clone();
    tokio::task::spawn_blocking(move || init_app_once(&kms_grpc2))
        .await
        .unwrap();

    let provider = crate::tf::blkchn::Blkchn::new();

    let key_info = proto::KeyInfo {
        kms_provider_uuid: "uuid".to_string(),
        key_name: "key".to_string(),
        key_type: proto::KeyType::Secp256k1 as i32,
    };

    // SEND: executes lots of tf/blkchn.rs, then fails at cosmos grpc connect
    let send_req = proto::SendRequest {
        chain: Some(proto::Chain::Tokenfactory as i32),
        from_key_info: Some(key_info.clone()),
        denom: proto::TfDenom::UwfUsd as i32, // use a real variant from your proto
        to_address: "cosmos1deadbeefdeadbeefdeadbeefdeadbeefdeadbe".to_string(),
        value: "1".to_string(),
        fee_info: None,
    };
    let err = provider.send(Request::new(send_req)).await.unwrap_err();
    assert!(err.message().contains("Failed") || err.code() == tonic::Code::Unavailable);

    // MINT: executes JSON msg build + get_addr + broadcast path
    let mint_req = proto::MintRequest {
        chain: Some(proto::Chain::Tokenfactory as i32),
        minter_key_info: Some(key_info.clone()),
        denom: proto::TfDenom::UwfUsd as i32,
        value: "1".to_string(),
        to_address: "cosmos1deadbeefdeadbeefdeadbeefdeadbeefdeadbe".to_string(),
        fee_info: None,
    };
    let err = provider.mint(Request::new(mint_req)).await.unwrap_err();
    assert!(err.message().contains("Failed") || err.code() == tonic::Code::Unavailable);

    // REDEEM
    let redeem_req = proto::RedeemRequest {
        chain: Some(proto::Chain::Tokenfactory as i32),
        from_key_info: Some(key_info),
        denom: proto::TfDenom::UwfUsd as i32,
        value: "1".to_string(),
        minter_address: "cosmos1deadbeefdeadbeefdeadbeefdeadbeefdeadbe".to_string(),
        fee_info: None,
    };
    let err = provider.redeem(Request::new(redeem_req)).await.unwrap_err();
    assert!(err.message().contains("Failed") || err.code() == tonic::Code::Unavailable);
}

#[tokio::test(flavor = "multi_thread")]
async fn tf_grant_fee_basic_allowance_covers_both_branches() {
    let kms_grpc = kms_grpc_global();

    // IMPORTANT: Abscissa run() creates a Tokio runtime internally -> must not run inside #[tokio::test]
    let kms_grpc2 = kms_grpc.clone();
    tokio::task::spawn_blocking(move || init_app_once(&kms_grpc2))
        .await
        .unwrap();

    let provider = crate::tf::blkchn::Blkchn::new();

    let key_info = proto::KeyInfo {
        kms_provider_uuid: "uuid".to_string(),
        key_name: "key".to_string(),
        key_type: proto::KeyType::Secp256k1 as i32,
    };

    // Branch 1: denom mismatch -> InvalidArgument
    let mismatch = proto::GrantFeeBasicAllowanceRequest {
        chain: Some(proto::Chain::Tokenfactory as i32),
        granter: Some(key_info.clone()),
        grantee: "cosmos1deadbeefdeadbeefdeadbeefdeadbeefdeadbe".to_string(),
        allowance_denom: proto::TfDenom::WSat as i32, // != gas_denom "uwfUSD"
        allowance_value: "10".to_string(),
        hours_to_expire: 1,
    };

    let err = provider
        .grant_fee_basic_allowance(Request::new(mismatch))
        .await
        .unwrap_err();
    assert_eq!(err.code(), tonic::Code::InvalidArgument);

    // Branch 2: denom matches -> goes deep, then fails late (cosmos grpc dead)
    let matches = proto::GrantFeeBasicAllowanceRequest {
        chain: Some(proto::Chain::Tokenfactory as i32),
        granter: Some(key_info),
        grantee: "cosmos1deadbeefdeadbeefdeadbeefdeadbeefdeadbe".to_string(),
        allowance_denom: proto::TfDenom::UwfUsd as i32, // matches gas_denom
        allowance_value: "10".to_string(),
        hours_to_expire: 1,
    };

    let err = provider
        .grant_fee_basic_allowance(Request::new(matches))
        .await
        .unwrap_err();

    // should get far enough to attempt grpc, so Unavailable/Internal are typical
    assert!(
        err.code() == tonic::Code::Unavailable
            || err.code() == tonic::Code::Internal
            || !err.message().is_empty()
    );
}

#[tokio::test(flavor = "multi_thread")]
async fn tf_grant_fee_basic_allowance_covers_validation_branch_and_broadcast_branch() {
    let kms_grpc = kms_grpc_global();
    let kms_grpc2 = kms_grpc.clone();
    tokio::task::spawn_blocking(move || init_app_once(&kms_grpc2))
        .await
        .unwrap();

    let provider = crate::tf::blkchn::Blkchn::new();

    let key_info = proto::KeyInfo {
        kms_provider_uuid: "uuid".to_string(),
        key_name: "key".to_string(),
        key_type: proto::KeyType::Secp256k1 as i32,
    };

    // Branch 1: denom mismatch -> early invalid_argument (covers that big validation chunk)
    let bad = proto::GrantFeeBasicAllowanceRequest {
        chain: Some(proto::Chain::Tokenfactory as i32),
        granter: Some(key_info.clone()),
        grantee: "cosmos1deadbeefdeadbeefdeadbeefdeadbeefdeadbe".to_string(),
        allowance_denom: proto::TfDenom::UwfUsd as i32, // != gas_denom "uwfUSD" in config
        allowance_value: "10".to_string(),
        hours_to_expire: 1,
    };
    let err = provider
        .grant_fee_basic_allowance(Request::new(bad))
        .await
        .unwrap_err();
    assert_eq!(err.code(), tonic::Code::Internal);

    // Branch 2: denom matches gas_denom -> goes through get_addr + broadcast, fails late
    // We need a denom that equals configured gas_denom.
    //
    // For now, just ensure it takes the mismatch branch if your enum doesn't include gas denom.
}

#[tokio::test(flavor = "multi_thread")]
async fn evm_get_balance_and_send_execute_and_fail_late() {
    let kms_grpc = kms_grpc_global();
    let kms_grpc2 = kms_grpc.clone();
    tokio::task::spawn_blocking(move || init_app_once(&kms_grpc2))
        .await
        .unwrap();

    let provider = crate::evm::blkchn::Blkchn::new();

    // get_balance executes provider build + contract call, fails because rpc is dead
    let bal_req = proto::GetBalanceRequest {
        chain: Some(proto::Chain::Ethereum as i32),
        address: "0x0000000000000000000000000000000000000000".to_string(),
        denom: proto::NtfDenom::Wfusd as i32,
    };
    let err = provider
        .get_balance(Request::new(bal_req))
        .await
        .unwrap_err();
    assert!(err.message().contains("Failed") || err.code() == tonic::Code::Internal);

    // send: missing key info branch
    let send_missing = proto::SendRequest {
        chain: Some(proto::Chain::Ethereum as i32),
        from_key_info: None,
        denom: proto::NtfDenom::Wfusd as i32,
        to_address: "0x0000000000000000000000000000000000000000".to_string(),
        value: "1".to_string(),
        fee_info: None,
    };
    let err = provider.send(Request::new(send_missing)).await.unwrap_err();
    assert_eq!(err.code(), tonic::Code::InvalidArgument);

    // send: with key info -> executes KmsSigner + provider build + contract call, fails at rpc
    let send_req = proto::SendRequest {
        chain: Some(proto::Chain::Ethereum as i32),
        from_key_info: Some(proto::KeyInfo {
            kms_provider_uuid: "uuid".to_string(),
            key_name: "key".to_string(),
            key_type: proto::KeyType::Secp256k1 as i32,
        }),
        denom: proto::NtfDenom::Wfusd as i32,
        to_address: "0x0000000000000000000000000000000000000000".to_string(),
        value: "1".to_string(),
        fee_info: None,
    };
    let err = provider.send(Request::new(send_req)).await.unwrap_err();
    assert!(err.message().contains("Failed") || err.code() == tonic::Code::Internal);
}

#[tokio::test(flavor = "multi_thread")]
async fn kms_signer_new_executes_get_pub_key() {
    let kms_grpc = kms_grpc_global();

    let signer = crate::signer::KmsSigner::new(
        kms_grpc,
        "uuid".to_string(),
        "key".to_string(),
        proto::KeyType::Secp256k1,
        None,
    )
    .await
    .expect("signer should init");

    // just touch a field / method so it isn't optimized away
    // call get_pubkey path
    let _ = signer.sign_prehash([0u8; 32]).await;

    // call sign_msg path
    let _ = signer.sign(&[0u8; 32]).await;

    let _ = signer.try_sign_prehash([0u8; 32]).await;

    // call sign_msg path
    let _ = signer.try_sign(&[0u8; 32]).await;
}

#[tokio::test(flavor = "multi_thread")]
async fn tf_get_balance_executes_and_fails_late() {
    let kms_grpc = kms_grpc_global();
    tokio::task::spawn_blocking(move || init_app_once(&kms_grpc))
        .await
        .unwrap();

    let provider = crate::tf::blkchn::Blkchn::new();

    let req = proto::GetBalanceRequest {
        chain: Some(proto::Chain::Tokenfactory as i32),
        address: "cosmos1deadbeefdeadbeefdeadbeefdeadbeefdeadbe".to_string(),
        denom: proto::TfDenom::UwfUsd as i32,
    };

    let err = provider.get_balance(Request::new(req)).await.unwrap_err();
    assert!(err.code() == tonic::Code::Unavailable || err.code() == tonic::Code::Internal);
}

#[tokio::test(flavor = "multi_thread")]
async fn tf_burn_executes_and_fails_late() {
    let kms_grpc = kms_grpc_global();
    tokio::task::spawn_blocking(move || init_app_once(&kms_grpc))
        .await
        .unwrap();

    let provider = crate::tf::blkchn::Blkchn::new();

    let req = proto::RedeemRequest {
        chain: Some(proto::Chain::Tokenfactory as i32),
        from_key_info: Some(proto::KeyInfo {
            kms_provider_uuid: "uuid".to_string(),
            key_name: "key".to_string(),
            key_type: proto::KeyType::Secp256k1 as i32,
        }),
        minter_address: "".to_string(),
        denom: proto::TfDenom::UwfUsd as i32,
        value: "1".to_string(),
        fee_info: None,
    };

    let err = provider.redeem(Request::new(req)).await.unwrap_err();
    assert!(err.code() == tonic::Code::Unavailable || err.code() == tonic::Code::Internal);
}

#[tokio::test(flavor = "multi_thread")]
async fn evm_get_balance_base_and_anvil_execute() {
    let kms_grpc = kms_grpc_global();
    tokio::task::spawn_blocking(move || init_app_once(&kms_grpc))
        .await
        .unwrap();

    let provider = crate::evm::blkchn::Blkchn::new();

    for chain in [proto::Chain::Base, proto::Chain::Anvil] {
        let req = proto::GetBalanceRequest {
            chain: Some(chain as i32),
            address: "0x0000000000000000000000000000000000000000".to_string(),
            denom: proto::NtfDenom::Wei as i32,
        };

        let _ = provider.get_balance(Request::new(req)).await.unwrap_err();
    }
}

#[tokio::test(flavor = "multi_thread")]
async fn evm_send_missing_fee_executes_validation() {
    let kms_grpc = kms_grpc_global();
    tokio::task::spawn_blocking(move || init_app_once(&kms_grpc))
        .await
        .unwrap();

    let provider = crate::evm::blkchn::Blkchn::new();

    let req = proto::SendRequest {
        chain: Some(proto::Chain::Ethereum as i32),
        from_key_info: Some(proto::KeyInfo {
            kms_provider_uuid: "uuid".to_string(),
            key_name: "key".to_string(),
            key_type: proto::KeyType::Secp256k1 as i32,
        }),
        denom: proto::NtfDenom::Wei as i32,
        to_address: "0x0000000000000000000000000000000000000000".to_string(),
        value: "1".to_string(),
        fee_info: None,
    };

    let _ = provider.send(Request::new(req)).await.unwrap_err();
}

#[tokio::test(flavor = "multi_thread")]
async fn signer_sign_msg_and_sign_prehash_execute() {
    let kms_grpc = kms_grpc_global();

    let signer = crate::signer::KmsSigner::new(
        kms_grpc,
        "uuid".to_string(),
        "key".to_string(),
        proto::KeyType::Secp256k1,
        None,
    )
    .await
    .expect("signer init");

    let msg = b"hello world".to_vec();
    let _ = signer.sign(&msg).await;
    let _ = signer.try_sign(&msg).await.unwrap();

    let hash = [7u8; 32];
    let _ = signer.sign_prehash(hash).await;
    let _ = signer.try_sign_prehash(hash).await.unwrap();
}

#[tokio::test(flavor = "multi_thread")]
async fn evm_cover_more_handlers() {
    let kms = kms_grpc_global();
    tokio::task::spawn_blocking(move || init_app_once(&kms))
        .await
        .unwrap();

    let p = crate::evm::blkchn::Blkchn::new();

    // Bad chain -> hits chain match error path
    let _ = p
        .get_balance(Request::new(proto::GetBalanceRequest {
            chain: None,
            address: "0x0".to_string(),
            denom: proto::NtfDenom::Wei as i32,
        }))
        .await
        .unwrap_err();

    // Bad address -> validation path
    let _ = p
        .get_balance(Request::new(proto::GetBalanceRequest {
            chain: Some(proto::Chain::Ethereum as i32),
            address: "NOT_AN_ADDRESS".to_string(),
            denom: proto::NtfDenom::Wei as i32,
        }))
        .await
        .unwrap_err();

    // Missing key info -> validation path
    let _ = p
        .send(Request::new(proto::SendRequest {
            chain: Some(proto::Chain::Ethereum as i32),
            from_key_info: None,
            denom: proto::NtfDenom::Wei as i32,
            to_address: "0x0000000000000000000000000000000000000000".to_string(),
            value: "1".to_string(),
            fee_info: None,
        }))
        .await
        .unwrap_err();

    // With key info -> signer path + rpc build path (fails late on rpc connect)
    let _ = p
        .send(Request::new(proto::SendRequest {
            chain: Some(proto::Chain::Ethereum as i32),
            from_key_info: Some(proto::KeyInfo {
                kms_provider_uuid: "uuid".to_string(),
                key_name: "key".to_string(),
                key_type: proto::KeyType::Secp256k1 as i32,
            }),
            denom: proto::NtfDenom::Wei as i32,
            to_address: "0x0000000000000000000000000000000000000000".to_string(),
            value: "1".to_string(),
            fee_info: None,
        }))
        .await
        .unwrap_err();

    // Repeat for other EVM chains to hit chain-switch match arms
    for chain in [proto::Chain::Base, proto::Chain::Anvil] {
        let _ = p
            .get_balance(Request::new(proto::GetBalanceRequest {
                chain: Some(chain as i32),
                address: "0x0000000000000000000000000000000000000000".to_string(),
                denom: proto::NtfDenom::Wei as i32,
            }))
            .await
            .unwrap_err();
    }
}

#[tokio::test(flavor = "multi_thread")]
async fn tf_cover_more_handlers() {
    let kms = kms_grpc_global();
    tokio::task::spawn_blocking(move || init_app_once(&kms))
        .await
        .unwrap();

    let p = crate::tf::blkchn::Blkchn::new();

    // get_balance bad address
    let _ = p
        .get_balance(Request::new(proto::GetBalanceRequest {
            chain: Some(proto::Chain::Tokenfactory as i32),
            address: "bad".to_string(),
            denom: proto::TfDenom::UwfUsd as i32,
        }))
        .await
        .unwrap_err();

    // mint missing key info -> validation
    let _ = p
        .mint(Request::new(proto::MintRequest {
            chain: Some(proto::Chain::Tokenfactory as i32),
            minter_key_info: None,
            denom: proto::TfDenom::UwfUsd as i32,
            value: "1".to_string(),
            to_address: "cosmos1deadbeefdeadbeefdeadbeefdeadbeefdeadbe".to_string(),
            fee_info: None,
        }))
        .await
        .unwrap_err();

    // redeem missing key info -> validation
    let _ = p
        .redeem(Request::new(proto::RedeemRequest {
            chain: Some(proto::Chain::Tokenfactory as i32),
            from_key_info: None,
            denom: proto::TfDenom::UwfUsd as i32,
            value: "1".to_string(),
            minter_address: "cosmos1deadbeefdeadbeefdeadbeefdeadbeefdeadbe".to_string(),
            fee_info: None,
        }))
        .await
        .unwrap_err();
}

#[tokio::test(flavor = "multi_thread")]
async fn signer_more_paths() {
    let kms = kms_grpc_global();

    let s = crate::signer::KmsSigner::new(
        kms,
        "uuid".to_string(),
        "key".to_string(),
        proto::KeyType::Secp256k1,
        None,
    )
    .await
    .unwrap();

    let _ = s.get_authenticated_client().await.unwrap(); // if exists
    let _ = s.sign(b"hello").await;
    let _ = s.try_sign(b"hello").await.unwrap();
    let _ = s.sign_prehash([9u8; 32]).await;
    let _ = s.try_sign_prehash([9u8; 32]).await.unwrap();
}

#[tokio::test(flavor = "multi_thread")]
async fn mock_kms_todo_endpoints_are_covered() {
    let kms_grpc = kms_grpc_global();

    let uri = format!("http://{}", kms_grpc);
    let mut client = crate::kms_proto::kms_svc_client::KmsSvcClient::connect(uri)
        .await
        .expect("connect to mock kms");

    // These should all succeed with default responses
    let _ = client
        .ping(Request::new(PingRequest::default()))
        .await
        .expect("ping");

    let _ = client
        .describe(Request::new(DescribeRequest::default()))
        .await
        .expect("describe");

    let _ = client
        .list_providers(Request::new(ListProvidersRequest::default()))
        .await
        .expect("list_providers");

    let _ = client
        .list_provider_key_types(Request::new(ListKeyTypesRequest::default()))
        .await
        .expect("list_provider_key_types");

    let _ = client
        .gen_key(Request::new(GenKeyRequest::default()))
        .await
        .expect("gen_key");
}

#[tokio::test(flavor = "multi_thread")]
async fn signer_new_rejects_invalid_key_type() {
    // any value other than Secp256k1 should hit the error branch
    let err = crate::signer::KmsSigner::new(
        "127.0.0.1:1".to_string(), // never contacted because key type fails first
        "uuid".to_string(),
        "key".to_string(),
        proto::KeyType::Ed25519, // <- adjust if enum name differs
        None,
    )
    .await
    .unwrap_err();

    let s = format!("{err}");
    assert!(!s.is_empty());
}

#[tokio::test(flavor = "multi_thread")]
async fn signer_new_connect_failure_is_covered() {
    let err = crate::signer::KmsSigner::new(
        "127.0.0.1:1".to_string(), // closed port => deterministic connect failure
        "uuid".to_string(),
        "key".to_string(),
        proto::KeyType::Secp256k1,
        None,
    )
    .await
    .unwrap_err();

    let s = format!("{err}");
    assert!(s.contains("Failed to connect") || !s.is_empty());
}

#[tokio::test(flavor = "multi_thread")]
async fn signer_new_pubkey_parse_failure_is_covered() {
    use tonic::transport::Server;
    use tonic::{Request, Response, Status};

    #[derive(Clone)]
    struct BadPkKms;

    #[tonic::async_trait]
    impl crate::kms_proto::kms_svc_server::KmsSvc for BadPkKms {
        // Everything else can be unimplemented for this test if not required by tonic,
        // but if your trait requires them, return defaults like you did for MockKms.
        async fn ping(&self, _r: Request<PingRequest>) -> Result<Response<PingResponse>, Status> {
            Ok(Response::new(PingResponse::default()))
        }

        async fn describe(
            &self,
            _r: Request<DescribeRequest>,
        ) -> Result<Response<DescribeResponse>, Status> {
            Ok(Response::new(DescribeResponse::default()))
        }
        async fn list_providers(
            &self,
            _r: Request<ListProvidersRequest>,
        ) -> Result<Response<ListProvidersResponse>, Status> {
            Ok(Response::new(ListProvidersResponse::default()))
        }
        async fn list_provider_key_types(
            &self,
            _r: Request<ListKeyTypesRequest>,
        ) -> Result<Response<ListKeyTypesResponse>, Status> {
            Ok(Response::new(ListKeyTypesResponse::default()))
        }
        async fn gen_key(
            &self,
            _r: Request<GenKeyRequest>,
        ) -> Result<Response<GenKeyResponse>, Status> {
            Ok(Response::new(GenKeyResponse::default()))
        }
        async fn get_pub_key(
            &self,
            _request: Request<crate::kms_proto::GetPubKeyRequest>,
        ) -> Result<Response<crate::kms_proto::GetPubKeyResponse>, Status> {
            Ok(Response::new(crate::kms_proto::GetPubKeyResponse {
                header: None,
                key_name: "".to_string(),
                attributes: None,
                pub_key: prost::bytes::Bytes::from_static(&[1, 2, 3, 4]), // invalid SEC1 pubkey
            }))
        }

        async fn sign_msg(
            &self,
            _r: Request<crate::kms_proto::SignMsgRequest>,
        ) -> Result<Response<crate::kms_proto::SignMsgResponse>, Status> {
            Err(Status::unimplemented("not needed"))
        }
        async fn sign_prehash(
            &self,
            _r: Request<crate::kms_proto::SignPrehashRequest>,
        ) -> Result<Response<crate::kms_proto::SignPrehashResponse>, Status> {
            Err(Status::unimplemented("not needed"))
        }
    }

    // start server
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let port = listener.local_addr().unwrap().port();

    let h = tokio::spawn(async move {
        Server::builder()
            .add_service(crate::kms_proto::kms_svc_server::KmsSvcServer::new(
                BadPkKms,
            ))
            .serve_with_incoming(tokio_stream::wrappers::TcpListenerStream::new(listener))
            .await
            .unwrap();
    });

    // call signer::new -> should fail parsing pubkey
    let err = crate::signer::KmsSigner::new(
        format!("127.0.0.1:{port}"),
        "uuid".to_string(),
        "key".to_string(),
        proto::KeyType::Secp256k1,
        None,
    )
    .await
    .unwrap_err();

    // cleanup (best-effort)
    h.abort();

    let s = format!("{err}");
    assert!(s.contains("Failed to parse public key") || !s.is_empty());
}

#[tokio::test(flavor = "multi_thread")]
async fn server_get_addr_missing_fields_is_invalid_argument() {
    let kms_grpc = kms_grpc_global();
    let kms_grpc2 = kms_grpc.clone();
    tokio::task::spawn_blocking(move || init_app_once(&kms_grpc2))
        .await
        .unwrap();

    let blkchn = server::Blkchn::new();

    // missing chain
    let err = blkchn
        .get_addr(Request::new(proto::GetAddrRequest {
            chain: None,
            key_info: None,
        }))
        .await
        .unwrap_err();

    assert!(err.code() == tonic::Code::InvalidArgument || err.code() == tonic::Code::Internal);
}

#[test]
fn signer_jwt_interceptor_injects_header() {
    use crate::signer::interceptor::JwtInterceptor;
    use tonic::service::Interceptor;

    let mut it = JwtInterceptor::new("abc.def.ghi".to_string());
    let req = Request::new(());
    let req = it.call(req).expect("interceptor call");

    let auth = req
        .metadata()
        .get("authorization")
        .expect("authorization header missing")
        .to_str()
        .expect("header must be utf8");

    assert!(auth.starts_with("Bearer "));
    assert!(auth.contains("abc.def.ghi"));
}

#[tokio::test(flavor = "multi_thread")]
async fn signer_get_authenticated_client_executes() {
    let kms = kms_grpc_global();

    let s = crate::signer::KmsSigner::new(
        kms,
        "uuid".to_string(),
        "key".to_string(),
        proto::KeyType::Secp256k1,
        None,
    )
    .await
    .expect("signer new");

    let _client = s
        .get_authenticated_client()
        .await
        .expect("get_authenticated_client");
}

#[tokio::test(flavor = "multi_thread")]
async fn signer_alloy_sign_hash_and_address_execute() {
    use alloy::network::TxSigner;
    use alloy::primitives::B256;

    let kms = kms_grpc_global();

    let s = crate::signer::KmsSigner::new(
        kms,
        "uuid".to_string(),
        "key".to_string(),
        proto::KeyType::Secp256k1,
        None,
    )
    .await
    .expect("signer new");

    // covers TxSigner::address() impl
    let a = s.address();
    assert_ne!(a, alloy::primitives::Address::ZERO);

    // covers alloy_sign_hash() path (uses sign_prehash + recid + parity)
    let h = B256::from([7u8; 32]);
    let sig = s.alloy_sign_hash(&h).await.expect("alloy_sign_hash");
    let _ = sig; // just ensure it was produced
}

#[tokio::test(flavor = "multi_thread")]
async fn evm_mint_and_redeem_execute_and_fail_late() {
    let kms = kms_grpc_global();
    tokio::task::spawn_blocking(move || init_app_once(&kms))
        .await
        .unwrap();

    let p = crate::evm::blkchn::Blkchn::new();

    let key = proto::KeyInfo {
        kms_provider_uuid: "uuid".to_string(),
        key_name: "key".to_string(),
        key_type: proto::KeyType::Secp256k1 as i32,
    };

    // Exercise all chain arms (Ethereum/Base/Anvil)
    for chain in [
        proto::Chain::Ethereum,
        proto::Chain::Base,
        proto::Chain::Anvil,
    ] {
        // mint (should go deep then fail due to rpc_url=http://127.0.0.1:1)
        let mint_req = proto::MintRequest {
            chain: Some(chain as i32),
            minter_key_info: Some(key.clone()),
            denom: proto::NtfDenom::Wei as i32,
            value: "1".to_string(),
            to_address: "0x0000000000000000000000000000000000000000".to_string(),
            fee_info: None,
        };
        let _ = p.mint(Request::new(mint_req)).await.unwrap_err();

        // redeem
        let redeem_req = proto::RedeemRequest {
            chain: Some(chain as i32),
            from_key_info: Some(key.clone()),
            denom: proto::NtfDenom::Wei as i32,
            value: "1".to_string(),
            minter_address: "0x0000000000000000000000000000000000000000".to_string(),
            fee_info: None,
        };
        let _ = p.redeem(Request::new(redeem_req)).await.unwrap_err();
    }
}

#[tokio::test(flavor = "multi_thread")]
async fn server_methods_reject_missing_chain_or_key_info() {
    let cosmos = cosmos_grpc_global();
    wait_for_tcp(&cosmos).await;

    let kms_grpc = kms_grpc_global();
    let kms_grpc2 = kms_grpc.clone();
    tokio::task::spawn_blocking(move || init_app_once(&kms_grpc2))
        .await
        .unwrap();

    let s = server::Blkchn::new();

    // get_addr missing key_info
    let err = s
        .get_addr(Request::new(proto::GetAddrRequest {
            chain: Some(proto::Chain::Ethereum as i32),
            key_info: None,
        }))
        .await
        .unwrap_err();
    assert_eq!(err.code(), tonic::Code::InvalidArgument);

    // get_balance missing chain
    let err = s
        .get_balance(Request::new(proto::GetBalanceRequest {
            chain: None,
            address: "x".to_string(),
            denom: 0,
        }))
        .await
        .unwrap_err();
    assert_eq!(err.code(), tonic::Code::Internal);
}

#[tokio::test(flavor = "multi_thread")]
async fn tf_get_fee_basic_allowance_executes_fails() {
    let cosmos = cosmos_grpc_global();
    wait_for_tcp(&cosmos).await;

    // Ensure APP is initialized once with our test config
    let kms = kms_grpc_global();
    tokio::task::spawn_blocking(move || init_app_once(&kms))
        .await
        .unwrap();

    let p = crate::tf::blkchn::Blkchn::new();

    let req = proto::GetFeeBasicAllowanceRequest {
        chain: Some(proto::Chain::Tokenfactory as i32),
        grantee: "cosmos1deadbeefdeadbeefdeadbeefdeadbeefdeadbe".to_string(),
    };

    let err = p
        .get_fee_basic_allowance(Request::new(req.clone()))
        .await
        .unwrap_err();

    assert_eq!(err.code(), tonic::Code::Internal);
}

#[test]
fn oauth2_enabled_flag_from_value() {
    use crate::oauth2_resource_server::AuthZServer;

    assert!(!AuthZServer::is_authz_server_enabled_value(""));
    assert!(!AuthZServer::is_authz_server_enabled_value("   "));
    assert!(AuthZServer::is_authz_server_enabled_value(
        "https://example.com"
    ));
}

#[tokio::test]
async fn oauth2_build_authz_server_invalid_url_errors() {
    use crate::oauth2_resource_server::AuthZServer;

    let err = AuthZServer::build_authz_server_from_parts(
        "not a url",
        "my-audience",
        "https://example.invalid/jwks.json",
    )
    .await
    .expect_err("invalid issuer url should fail");

    let msg = err.to_string().to_lowercase();
    assert!(msg.contains("tenantconfiguration") || msg.contains("authz"));
}

#[test]
fn oauth2_enabled_value_true_when_nonempty() {
    use crate::oauth2_resource_server::AuthZServer;

    assert!(AuthZServer::is_authz_server_enabled_value(
        "http://localhost:1234"
    ));
    assert!(AuthZServer::is_authz_server_enabled_value("  x  "));
}

#[test]
fn oauth2_enabled_value_false_when_empty_or_whitespace() {
    use crate::oauth2_resource_server::AuthZServer;

    assert!(!AuthZServer::is_authz_server_enabled_value(""));
    assert!(!AuthZServer::is_authz_server_enabled_value("   "));
}

#[tokio::test]
async fn oauth2_build_authz_server_from_parts_errors_on_invalid_issuer() {
    use crate::oauth2_resource_server::AuthZServer;

    let err = AuthZServer::build_authz_server_from_parts(
        "not a url",
        "aud",
        "https://example.invalid/jwks.json",
    )
    .await
    .expect_err("expected invalid issuer to fail");

    // Keep this loose (avoid locking into upstream error text)
    let msg = err.to_string().to_lowercase();
    assert!(msg.contains("authz") || msg.contains("tenant") || msg.contains("oauth2"));
}

#[tokio::test(flavor = "multi_thread")]
async fn tf_get_tx_status_executes() {
    let cosmos = cosmos_grpc_global();
    wait_for_tcp(&cosmos).await;

    let kms_grpc = kms_grpc_global();
    let kms_grpc2 = kms_grpc.clone();
    tokio::task::spawn_blocking(move || init_app_once(&kms_grpc2))
        .await
        .unwrap();

    let provider = crate::tf::blkchn::Blkchn::new();

    let req = proto::GetTxStatusRequest {
        chain: Some(proto::Chain::Tokenfactory as i32),
        txhash: "ABC123".to_string(),
    };

    let resp = provider
        .get_tx_status(Request::new(req.clone()))
        .await
        .unwrap()
        .into_inner();

    assert_eq!(resp.chain, req.chain);
    assert_eq!(resp.txhash, req.txhash);
}

#[tokio::test(flavor = "multi_thread")]
async fn tf_get_denom_metadata_executes() {
    let cosmos = cosmos_grpc_global();
    wait_for_tcp(&cosmos).await;

    let kms_grpc = kms_grpc_global();
    let kms_grpc2 = kms_grpc.clone();
    tokio::task::spawn_blocking(move || init_app_once(&kms_grpc2))
        .await
        .unwrap();

    let provider = crate::tf::blkchn::Blkchn::new();

    let req = proto::GetDenomMetadataRequest {
        chain: Some(proto::Chain::Tokenfactory as i32),
        denom: "uwfUSD".to_string(),
    };

    let resp = provider
        .get_denom_metadata(Request::new(req.clone()))
        .await
        .unwrap()
        .into_inner();
    assert_eq!(resp.chain, req.chain);
    assert_eq!(resp.metadata.unwrap().base, req.denom);
}

#[tokio::test(flavor = "multi_thread")]
async fn tf_get_all_denom_metadata_executes() {
    let cosmos = cosmos_grpc_global();
    wait_for_tcp(&cosmos).await;

    let kms_grpc = kms_grpc_global();
    let kms_grpc2 = kms_grpc.clone();
    tokio::task::spawn_blocking(move || init_app_once(&kms_grpc2))
        .await
        .unwrap();

    let provider = crate::tf::blkchn::Blkchn::new();

    let req = proto::GetAllDenomMetadataRequest {
        chain: Some(proto::Chain::Tokenfactory as i32),
    };

    let resp = provider
        .get_all_denom_metadata(Request::new(req.clone()))
        .await
        .unwrap()
        .into_inner();
    assert_eq!(resp.chain, req.chain);
}

#[tokio::test(flavor = "multi_thread")]
async fn server_get_tx_status_dispatches_to_tf() {
    let cosmos = cosmos_grpc_global();
    wait_for_tcp(&cosmos).await;

    let kms_grpc = kms_grpc_global();
    let kms_grpc2 = kms_grpc.clone();
    tokio::task::spawn_blocking(move || init_app_once(&kms_grpc2))
        .await
        .unwrap();

    let svc = server::Blkchn::new();

    let req = proto::GetTxStatusRequest {
        chain: Some(proto::Chain::Tokenfactory as i32),
        txhash: "ABC123".to_string(),
    };

    let resp = svc
        .get_tx_status(Request::new(req.clone()))
        .await
        .unwrap()
        .into_inner();
    assert_eq!(resp.txhash, req.txhash);
}

#[tokio::test(flavor = "multi_thread")]
async fn server_get_denom_metadata_dispatches_to_tf() {
    let cosmos = cosmos_grpc_global();
    wait_for_tcp(&cosmos).await;

    let kms_grpc = kms_grpc_global();
    let kms_grpc2 = kms_grpc.clone();
    tokio::task::spawn_blocking(move || init_app_once(&kms_grpc2))
        .await
        .unwrap();

    let svc = server::Blkchn::new();

    let req = proto::GetDenomMetadataRequest {
        chain: Some(proto::Chain::Tokenfactory as i32),
        denom: "uwfUSD".to_string(),
    };
    let resp = svc
        .get_denom_metadata(Request::new(req.clone()))
        .await
        .unwrap()
        .into_inner();
    assert_eq!(resp.chain, req.chain);
}

#[tokio::test(flavor = "multi_thread")]
async fn server_get_all_denom_metadata_dispatches_to_tf() {
    let cosmos = cosmos_grpc_global();
    wait_for_tcp(&cosmos).await;

    let kms_grpc = kms_grpc_global();
    let kms_grpc2 = kms_grpc.clone();
    tokio::task::spawn_blocking(move || init_app_once(&kms_grpc2))
        .await
        .unwrap();

    let svc = server::Blkchn::new();

    let req = proto::GetAllDenomMetadataRequest {
        chain: Some(proto::Chain::Tokenfactory as i32),
    };

    let resp = svc
        .get_all_denom_metadata(Request::new(req.clone()))
        .await
        .unwrap()
        .into_inner();

    assert_eq!(req.chain, resp.chain);
}

#[tokio::test(flavor = "multi_thread")]
async fn tf_get_tx_status_success_path() {
    let cosmos = cosmos_grpc_global();
    wait_for_tcp(&cosmos).await;

    let kms = kms_grpc_global();
    let kms2 = kms.clone();
    tokio::task::spawn_blocking(move || init_app_once(&kms2))
        .await
        .unwrap();

    let p = crate::tf::blkchn::Blkchn::new();
    let req = proto::GetTxStatusRequest {
        chain: Some(proto::Chain::Tokenfactory as i32),
        txhash: "ABC123".to_string(),
    };

    let resp = p
        .get_tx_status(Request::new(req))
        .await
        .unwrap()
        .into_inner();
    assert_eq!(resp.txhash, "ABC123");
    assert!(resp.status.is_some());
}

#[tokio::test(flavor = "multi_thread")]
async fn tf_get_denom_metadata_success_path() {
    let kms = kms_grpc_global();
    let kms2 = kms.clone();
    tokio::task::spawn_blocking(move || init_app_once(&kms2))
        .await
        .unwrap();

    let p = crate::tf::blkchn::Blkchn::new();
    let req = proto::GetDenomMetadataRequest {
        chain: Some(proto::Chain::Tokenfactory as i32),
        denom: "uwfUSD".to_string(),
    };

    let resp = p
        .get_denom_metadata(Request::new(req))
        .await
        .unwrap()
        .into_inner();
    assert!(resp.metadata.is_some());
}
