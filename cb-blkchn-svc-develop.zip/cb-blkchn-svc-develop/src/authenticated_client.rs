use tonic::{Request, metadata::MetadataValue};

// 1. Create a newtype wrapper
//
#[derive(Clone)]
pub struct AuthenticatedClient<C>(C, Option<String>);

impl<C> AuthenticatedClient<C> {
    pub fn new(client: C, token: Option<String>) -> Self {
        Self(client, token)
    }

    // Helper method to add auth to any request
    pub fn authenticate<Req>(&self, request: Req) -> Request<Req> {
        Self::authenticate_(request, &self.1)
    }

    // Helper struct/class function to add auth to any request
    pub fn authenticate_<Req>(request: Req, token: &Option<String>) -> Request<Req> {
        let mut request = Request::new(request);
        Self::add_auth_headers(request.metadata_mut(), token);
        request
    }

    pub fn get_jwt(metadata: &tonic::metadata::MetadataMap) -> Option<String> {
        metadata
            .get("authorization")
            .and_then(|value| value.to_str().ok())
            .and_then(|s| s.strip_prefix("Bearer "))
            .map(String::from)
    }

    fn add_auth_headers(metadata: &mut tonic::metadata::MetadataMap, token: &Option<String>, ) {
        if let Some(token) = token {
            metadata.insert(
                "authorization",
                MetadataValue::try_from(format!("Bearer {}", token))
                    .expect("Invalid JWT format"),
            );
        }
    }

}

// 2. Implement Deref for direct client access
impl<C> std::ops::Deref for AuthenticatedClient<C> {
    type Target = C;

    fn deref(&self) -> &Self::Target {
        &self.0
    }
}

// 2. Implement DerefMut for direct mutable client access
impl<C> std::ops::DerefMut for AuthenticatedClient<C> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        &mut self.0
    }
}
