use crate::error::{Error, ErrorKind};
use crate::proto::{NtfDenom, TfDenom};

pub enum Denom {
    Tf(TfDenom),
    Ntf(NtfDenom),
}

impl TryFrom<String> for Denom {
    type Error = Error;

    fn try_from(value: String) -> Result<Self, Self::Error> {
        match TfDenom::from_str_name(value.as_ref()) {
            Some(denom) => Ok(Denom::Tf(denom)),
            None => {
                match NtfDenom::from_str_name(value.as_ref()) {
                    Some(denom) => Ok(Denom::Ntf(denom)),
                    None => Err(ErrorKind::InvalidData.context("Invalid denom").into()),
                }
            }
        }

        // match value.as_str() {
        //     "uwfUSD" => Ok(Denom::Tf(TfDenom::UwfUsd)),
        //     "wSAT" => Ok(Denom::Tf(TfDenom::WSat)),
        //     "wWEI" => Ok(Denom::Tf(TfDenom::WWei)),
        //     "wLAM" => Ok(Denom::Tf(TfDenom::WLam)),
        //     "SAT" => Ok(Denom::Ntf(NtfDenom::Sat)),
        //     "WEI" => Ok(Denom::Ntf(NtfDenom::Wei)),
        //     "LAM" => Ok(Denom::Ntf(NtfDenom::Lam)),
        //     _ => Err(ErrorKind::InvalidData.context("Invalid denom").into()),
        // }
    }
}