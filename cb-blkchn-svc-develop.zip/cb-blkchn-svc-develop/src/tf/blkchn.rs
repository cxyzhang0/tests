use crate::application::APP;
use crate::authenticated_client::AuthenticatedClient;
use crate::{kms_proto, proto, signer};
use abscissa_core::Application;
use cosmos_grpc_client::cosmos_sdk_proto::cosmos::bank::v1beta1::{MsgSend, QueryBalanceRequest};
use cosmos_grpc_client::cosmos_sdk_proto::cosmos::tx::v1beta1::BroadcastTxResponse;
use cosmos_grpc_client::cosmos_sdk_proto::cosmos::base::v1beta1::Coin as ProtoCoin;
use cosmos_grpc_client::cosmos_sdk_proto::cosmwasm::wasm::v1::MsgExecuteContract;
use cosmos_grpc_client::cosmos_sdk_proto::Any;
use cosmos_grpc_client::{BroadcastMode, CoinType, Decimal, GrpcClient, ProstMsgNameToAny};
use cosmrs::Denom;
use kms_commom::async_signer::AsyncSigningKey;
use std::io::Empty;
use std::str::FromStr;
use tokenfactory::{FeegrantQuery, FeeBasicAllowanceResponse};
use tokenfactory::msg::{ExecuteMsg, FeegrantContractMsg, QueryMsg, TokenfactoryContractMsg};
use tonic::transport::Channel;
use tonic::{Request, Response, Status};
use crate::proto::{FeeInfo, GetFeeBasicGrant, Chain, GetAddrRequest, GetBalanceRequest, GetBalanceResponse, GetFeeBasicAllowanceRequest, GetFeeBasicAllowanceResponse, GrantFeeBasicAllowanceRequest, GrantFeeBasicAllowanceResponse, KeyInfo, MintRequest, MintResponse, RedeemRequest, RedeemResponse, SendRequest, SendResponse, TfDenom};
use crate::proto::blkchn_svc_server::BlkchnSvc;

#[derive(Debug, Default)]
pub struct Blkchn {}

impl Blkchn {
    /// Create a new instance of Blkchn
    pub fn new() -> Self {
        Self {}
    }

    // it does not do much, so we can comment it out for now
    /*
    pub(crate) async fn broadcast_cw_tx(
        &self,
        contract: String,
        msg: Vec<u8>,
        coin: Option<ProtoCoin>,
        siger_key_info: KeyInfo,
        signer_address: String,
        jwt: Option<String>,
    ) -> Result<BroadcastTxResponse, Status> {
        let config = APP.config();

        let msg = MsgExecuteContract {
            sender: signer_address,
            contract: contract,
            msg,
            funds: coin.map_or(vec![], |c| vec![c]),
        }.build_any();

        self.broadcast_tx(msg, siger_key_info, jwt).await
    }
*/

    pub(crate) async fn broadcast_tx(
        &self,
        msg: Any,
        signer_key_info: KeyInfo,
        fee_info: Option<FeeInfo>,
        jwt: Option<String>
    ) -> Result<BroadcastTxResponse, Status> {
        let config = APP.config();

        let signer = signer::KmsSigner::new(
            config.kms_server.grpc.clone(),
            signer_key_info.kms_provider_uuid,
            signer_key_info.key_name,
            proto::KeyType::try_from(signer_key_info.key_type).unwrap(),
            jwt,
        ).await
            .map_err(|e| Status::internal(format!("Failed to create signer: {}", e)))?;

        let cosmos_grpc_client = GrpcClient::new(config.chains.tokenfactory.grpc.clone().leak())
            .await
            .map_err(|e| Status::unavailable(format!("Failed to connect to Cosmos gRPC server: {}", e)))?;

        // wallet
        let mut wallet = cosmos_wallet::cosmos_async_wallet::Wallet::from_async_signing_key(
            cosmos_grpc_client,
            AsyncSigningKey::new(Box::new(signer)),
            &config.chains.tokenfactory.prefix,
            CoinType::Cosmos,
            config.chains.tokenfactory.gas_price.parse().unwrap(),
            config.chains.tokenfactory.gas_adjustment.parse().unwrap(),
            config.chains.tokenfactory.gas_denom.clone(),
        ).await
            .map_err(|e| Status::unavailable(format!("cosmos client connection error {}", e)))?;

        let sim = wallet
            .simulate_tx(vec![msg.clone()])
            .await
            .map_err(|e| Status::internal(format!("simulation error {}", e)))?;
        let gas_info = sim.gas_info.ok_or_else(|| Status::internal("no gas info from simulation"))?;
        let gas_used = Decimal::from_str(&gas_info.gas_used.to_string())
            .map_err(|e| Status::internal(e.to_string()))?;;

        let gas_price = Decimal::from_str(&config.chains.tokenfactory.gas_price)
            .map_err(|e| Status::internal(e.to_string()))?;
        let gas_adjustment = Decimal::from_str(&config.chains.tokenfactory.gas_adjustment)
            .map_err(|e| Status::internal(e.to_string()))?;
        let gas_denom = Denom::from_str(&config.chains.tokenfactory.gas_denom)
            .map_err(|e| Status::internal(e.to_string()))?;

        // per legacy, we default to pay by fee granter if fee_info is not provided
        let fee_granter =  if match fee_info {
            Some(fee_info) => fee_info.pay_by_fee_granter,
            None => true,
        } {
            Some(cosmrs::AccountId::from_str(&config.chains.tokenfactory.faucet.address.to_string())
            .map_err(|e| Status::internal(e.to_string()))?)
        } else {
            None
        };

        let fee = cosmrs::tx::Fee {
            amount: vec![cosmrs::Coin {
                denom: gas_denom,
                // in case price = 0, we still need to pay at least 1 unit of gas_denom
                amount: (gas_used * gas_price * gas_adjustment).max(Decimal::one())
                    .to_uint_ceil()
                    .u128(),
            }],
            gas_limit: (gas_used * gas_adjustment)
                .to_uint_ceil()
                .u128() as u64,
            payer: None,
            granter: fee_granter,
        };

        let response = wallet
            .broadcast_tx(
                vec![msg],           // Vec<Any>: list of msgs to broadcast
                Some(fee), //None, // fee: Option<Fee>, if not provided the tx is simulated to calculate the fee
                None,      // memo: Option<String>
                BroadcastMode::Sync, // Broadcast mode; Block/Sync/Async
            )
            .await
            .map_err(|e| Status::internal(e.to_string()))?;

        Ok(response)
    }

    pub async fn get_balance(&self, request: Request<GetBalanceRequest>) -> Result<Response<GetBalanceResponse>, Status> {
        let config = APP.config();
        let req = request.into_inner();

        let tf_denom = TfDenom::try_from(req.denom)
            .map_err(|e| Status::invalid_argument(format!("Failed to parse denom: {}", e)))?;

        let mut cosmos_grpc_client = GrpcClient::new(config.chains.tokenfactory.grpc.clone().leak())
            .await
            .map_err(|e| Status::unavailable(format!("Failed to connect to Cosmos gRPC server: {}", e)))?;

        let bal_req = QueryBalanceRequest {
            address: req.address,
            denom: tf_denom.as_str_name().to_string(),
        };

        let resp = cosmos_grpc_client
            .clients
            .bank
            .balance(bal_req)
            .await
            .map_err(|e| Status::internal(e.to_string()))?;
        let resp = resp.into_inner();

        let (denom, value) = match resp.balance {
            Some(balance) => (balance.denom, balance.amount),
            None => ("bank balance unavailable".to_string(), "bank balance unavailable".to_string()),
        };

        let tf_denom = TfDenom::from_str_name(&denom).ok_or_else(|| Status::internal("Failed to parse denom"))?;

        Ok(Response::new(GetBalanceResponse {
            chain: Some(Chain::Tokenfactory as i32),
            denom: tf_denom as i32,
            value,
        }))
    }

    pub async fn send(&self, request: Request<SendRequest>) -> Result<Response<SendResponse>, Status> {
        let _config = APP.config();

        let jwt = AuthenticatedClient::<kms_proto::kms_svc_client::KmsSvcClient<Channel>>::get_jwt(&request.metadata());

        let req = request.into_inner();

        let tf_denom = TfDenom::try_from(req.denom)
            .map_err(|e| Status::invalid_argument(format!("Failed to parse denom: {}", e)))?;
        let denom = tf_denom.as_str_name().to_string();

        let key_info = req.from_key_info.clone().ok_or_else(|| Status::invalid_argument("Missing sender key info"))?;

        // get the signer key address
        let get_addr_req = GetAddrRequest {
            chain: None,
            key_info: Some(key_info.clone()),
        };
        let authenticated_req = AuthenticatedClient::<Empty>::authenticate_(get_addr_req, &jwt);
        // let authenticated_req = AuthenticatedClient::<kms_proto::kms_svc_client::KmsSvcClient<Channel>>::authenticate_(get_addr_req, &jwt);

        let server_blkchn = crate::server::Blkchn::new();
        let get_addr_resp = server_blkchn.get_addr(authenticated_req).await
            .map_err(|e| Status::internal(format!("Failed to get address: {}", e)))?.into_inner();

        // send message
        let msg = MsgSend {
            from_address: get_addr_resp.address,
            to_address: req.to_address,
            amount: vec![cosmos_grpc_client::cosmos_sdk_proto::cosmos::base::v1beta1::Coin {
                denom,
                amount: req.value,
            }],
        }.build_any();

        let broadcast_tx_resp = self.broadcast_tx(msg, key_info, req.fee_info, jwt).await
            .map_err(|e| Status::internal(format!("Failed to broadcast transaction: {}", e)))?;
        let tx_resp = broadcast_tx_resp.tx_response
            .ok_or_else(|| Status::internal("no tx response"))?;

        Ok(Response::new(SendResponse {
            chain: req.chain,
            txhash: tx_resp.txhash,
        }))
    }

    pub async fn mint(&self, request: Request<MintRequest>) -> Result<Response<MintResponse>, Status> {
        let config = APP.config();

        let jwt = AuthenticatedClient::<kms_proto::kms_svc_client::KmsSvcClient<Channel>>::get_jwt(&request.metadata());

        let req = request.into_inner();

        let tf_denom = TfDenom::try_from(req.denom)
            .map_err(|e| Status::invalid_argument(format!("Failed to parse denom: {}", e)))?;
        let denom = tf_denom.as_str_name().to_string();

        // get the minter key address
        let get_minter_addr_req = GetAddrRequest {
            chain: None,
            key_info: Some(req.minter_key_info.clone().ok_or_else(|| Status::invalid_argument("Missing minter key info"))?),
        };
        let authenticated_req = AuthenticatedClient::<Empty>::authenticate_(get_minter_addr_req, &jwt);

        let server_blkchn = crate::server::Blkchn::new();
        let get_minter_addr_resp = server_blkchn.get_addr(authenticated_req).await
            .map_err(|e| Status::internal(format!("Failed to get minter address: {}", e)))?.into_inner();

        let mint_msg = ExecuteMsg::Tf(TokenfactoryContractMsg::Mint {
            orig_sender: Some(get_minter_addr_resp.address.clone()),
            address: req.to_address,
            denom,
            value: req.value.to_string(),
        });

        let mint_msg = serde_json::to_vec(&mint_msg)
            .map_err(|e| Status::invalid_argument(e.to_string()))?;

        let msg = MsgExecuteContract {
            sender: get_minter_addr_resp.address,
            contract: config.chains.tokenfactory.tokenfactory_contract.to_string(),
            msg: mint_msg,
            funds: vec![],
        }.build_any();

        let broadcast_tx_resp = self.broadcast_tx(msg, req.minter_key_info.unwrap(), req.fee_info, jwt).await
            .map_err(|e| Status::internal(format!("Failed to broadcast transaction: {}", e)))?;

        let tx_resp = broadcast_tx_resp.tx_response
            .ok_or_else(|| Status::internal("no tx response"))?;

        Ok(Response::new(MintResponse {
            chain: None,
            txhash: tx_resp.txhash,
        }))
    }

    pub async fn redeem(&self, request: Request<RedeemRequest>) -> Result<Response<RedeemResponse>, Status> {
        let config = APP.config();

        let jwt = AuthenticatedClient::<kms_proto::kms_svc_client::KmsSvcClient<Channel>>::get_jwt(&request.metadata());

        let req = request.into_inner();

        let tf_denom = TfDenom::try_from(req.denom)
            .map_err(|e| Status::invalid_argument(format!("Failed to parse denom: {}", e)))?;
        let denom = tf_denom.as_str_name().to_string();

        // get the signer key address
        let get_addr_req = GetAddrRequest {
            chain: None,
            key_info: Some(req.from_key_info.clone().ok_or_else(|| Status::invalid_argument("Missing sender key info"))?),
        };
        let authenticated_req = AuthenticatedClient::<Empty>::authenticate_(get_addr_req, &jwt);
        // let authenticated_req = AuthenticatedClient::<kms_proto::kms_svc_client::KmsSvcClient<Channel>>::authenticate_(get_addr_req, &jwt);

        let server_blkchn = crate::server::Blkchn::new();
        let get_addr_resp = server_blkchn.get_addr(authenticated_req).await
            .map_err(|e| Status::internal(format!("Failed to get sender address: {}", e)))?.into_inner();

        let redeem_msg = ExecuteMsg::Redeem {
            orig_sender: Some(get_addr_resp.address.clone()),
            minter_address: req.minter_address.clone(),
            denom: denom.clone(),
            value: req.value.clone(),
        };
        let redeem_msg = serde_json::to_vec(&redeem_msg)
            .map_err(|e| Status::invalid_argument(e.to_string()))?;

        let coin = ProtoCoin {
            denom,
            amount: req.value.to_string(),
        };

        let msg = MsgExecuteContract {
            sender: get_addr_resp.address,
            contract: config.chains.tokenfactory.tokenfactory_contract.to_string(),
            msg: redeem_msg,
            funds: vec![coin],
        }.build_any();

        let broadcast_tx_resp = self.broadcast_tx(msg, req.from_key_info.unwrap(), req.fee_info, jwt).await
            .map_err(|e| Status::internal(format!("Failed to broadcast transaction: {}", e)))?;

        let tx_resp = broadcast_tx_resp.tx_response
            .ok_or_else(|| Status::internal("no tx response"))?;

        Ok(Response::new(RedeemResponse {
            chain: None,
            txhash: tx_resp.txhash,
        }))
    }

    pub async fn grant_fee_basic_allowance(&self, request: Request<GrantFeeBasicAllowanceRequest>) -> Result<Response<GrantFeeBasicAllowanceResponse>, Status> {
        let config = APP.config();

        let jwt = AuthenticatedClient::<kms_proto::kms_svc_client::KmsSvcClient<Channel>>::get_jwt(&request.metadata());

        let req = request.into_inner();

        // parse and validate denom.
        let tf_denom = TfDenom::try_from(req.allowance_denom)
            .map_err(|e| Status::invalid_argument(format!("Failed to parse denom: {}", e)))?;
        let denom = tf_denom.as_str_name().to_string();
        if denom != config.chains.tokenfactory.gas_denom {
            return Err(Status::invalid_argument(format!(
                "Invalid allowance_denom: {}, must be the same as the configured gas_denom: {}",
                denom, config.chains.tokenfactory.gas_denom
            )));
        }

        // allowance value
        let allowance_value = req.allowance_value.parse::<u128>()
            .map_err(|e| Status::invalid_argument(e.to_string()))?;
        let config_allowance_value = config.chains.tokenfactory.faucet.allowance_value.parse::<u128>()
            .map_err(|e| Status::invalid_argument(e.to_string()))?;
        let allowance_value = config_allowance_value.min(allowance_value);

        // hours to expire
        let hours_to_expire = config.chains.tokenfactory.faucet.hours_to_expire.min(req.hours_to_expire);

        // get the granter key address
        let granter_key_info = req.granter.clone().ok_or_else(|| Status::invalid_argument("Missing granter key info"))?;
        let get_granter_addr_req = GetAddrRequest {
            chain: None,
            key_info: Some(granter_key_info.clone()),
        };
        let authenticated_req = AuthenticatedClient::<Empty>::authenticate_(get_granter_addr_req, &jwt);

        let server_blkchn = crate::server::Blkchn::new();
        let get_granter_addr_resp = server_blkchn.get_addr(authenticated_req).await
            .map_err(|e| Status::internal(format!("Failed to get granter address: {}", e)))?.into_inner();

        let execute_msg = ExecuteMsg::Feegrant(FeegrantContractMsg::GrantFeeBasicAllowance {
            granter: get_granter_addr_resp.address.clone(),
            grantee: req.grantee,
            allowance_denom: denom,
            allowance_value: allowance_value.to_string(), //req.allowance_value,
            hours_to_expire,
        });

        let json_msg = serde_json::to_vec(&execute_msg)
            .map_err(|e| Status::invalid_argument(e.to_string()))?;

        let msg = MsgExecuteContract {
            sender: get_granter_addr_resp.address,
            contract: config.chains.tokenfactory.tokenfactory_contract.to_string(),
            msg: json_msg,
            funds: vec![],
        }.build_any();

        let broadcast_tx_resp = self.broadcast_tx(msg, granter_key_info, None, jwt).await
            .map_err(|e| Status::internal(format!("Failed to broadcast transaction: {}", e)))?;

        let tx_resp = broadcast_tx_resp.tx_response
            .ok_or_else(|| Status::internal("no tx response"))?;

        Ok(Response::new(GrantFeeBasicAllowanceResponse {
            chain: req.chain, //Some(Chain::Tokenfactory.into()),
            txhash: tx_resp.txhash,
        }))
    }

    pub async fn get_fee_basic_allowance(&self, request: Request<GetFeeBasicAllowanceRequest>) -> Result<Response<GetFeeBasicAllowanceResponse>, Status> {
        let config = APP.config();
        let req = request.into_inner();

        let mut cosmos_grpc_client = GrpcClient::new(config.chains.tokenfactory.grpc.clone().leak())
            .await
            .map_err(|e| Status::unavailable(format!("Failed to connect to Cosmos gRPC server: {}", e)))?;

        let query_msg = QueryMsg::Feegrant(FeegrantQuery::FeeBasicAllowance {
            granter: config.chains.tokenfactory.faucet.address.clone(),
            grantee: req.grantee,
        });

        let resp = cosmos_grpc_client
            .query_smart_contract::<QueryMsg, FeeBasicAllowanceResponse>(
                config.chains.tokenfactory.tokenfactory_contract.clone(),
                query_msg,
            )
            .await
            .map_err(|e| {
                Status::internal(e.to_string())
            })?;

        Ok(Response::new(GetFeeBasicAllowanceResponse {
            chain: req.chain,
            fee_basic_grant: Some(GetFeeBasicGrant {
                granter: resp.allowance.granter,
                grantee: resp.allowance.grantee,
                allowance_denom: resp.allowance.allowance.denom,
                allowance_value: resp.allowance.allowance.amount.to_string(),
                expiration: resp.allowance.expiration,
                }),
        }))
    }
}