use crate::application::APP;
use crate::authenticated_client::AuthenticatedClient;
use crate::proto::blkchn_svc_server::BlkchnSvc;
use crate::proto::{
    FeeInfo, GetAddrRequest, GetBalanceRequest, GetBalanceResponse,
    GetFeeBasicAllowanceRequest, GetFeeBasicAllowanceResponse, GetFeeBasicGrant,
    GrantFeeBasicAllowanceRequest,
};
use crate::proto::{
    GetAllDenomMetadataRequest, GetAllDenomMetadataResponse, GetDenomMetadataRequest,
    GetDenomMetadataResponse, GetTxStatusRequest, GetTxStatusResponse, TxStatusResponse,
};
use crate::proto::{
    KeyInfo, MintRequest, RedeemRequest, SendRequest,
    TfDenom,
};
use crate::types::convert_denom_metadata;
use crate::{kms_proto, proto, signer};
use abscissa_core::Application;
use cosmos_grpc_client::cosmos_sdk_proto::cosmos::bank::v1beta1::{
    MsgSend, QueryBalanceRequest, QueryDenomMetadataRequest, QueryDenomsMetadataRequest,
};
use cosmos_grpc_client::cosmos_sdk_proto::cosmos::feegrant::v1beta1::MsgRevokeAllowance;
use cosmos_grpc_client::cosmos_sdk_proto::cosmos::base::abci::v1beta1::TxResponse;
use cosmos_grpc_client::cosmos_sdk_proto::cosmos::base::v1beta1::Coin as ProtoCoin;
use cosmos_grpc_client::cosmos_sdk_proto::cosmos::tx::v1beta1::{
    BroadcastTxResponse, GetTxRequest,
};
use cosmos_grpc_client::cosmos_sdk_proto::cosmwasm::wasm::v1::MsgExecuteContract;
use cosmos_grpc_client::cosmos_sdk_proto::Any;
use cosmos_grpc_client::cosmos_sdk_proto::cosmos::base::tendermint::v1beta1::{GetLatestBlockRequest, GetLatestBlockResponse};
use cosmos_grpc_client::{BroadcastMode, CoinType, GrpcClient, ProstMsgNameToAny};
use kms_common::async_signer::AsyncSigningKey;
use std::io::Empty;
use tokenfactory::msg::{ExecuteMsg, FeegrantContractMsg, QueryMsg, TokenfactoryContractMsg};
use tokenfactory::{FeeBasicAllowanceResponse, FeegrantQuery};
use tonic::transport::Channel;
use tonic::{Request, Response, Status};
use blkchn_svc_proto::blkchn_svc_v1::{CommonTxResponse, RevokeFeeBasicAllowanceRequest};
use crate::proto::{ConfigureMinterRequest, GetAddrResponse, GetAllMintersRequest, GetAllMintersResponse, GetMinterRequest, GetMinterResponse, RemoveMinterRequest, SetDenomMetadataRequest, TrackingInfo};

#[derive(Debug, Default)]
pub struct Blkchn {}

/// Implement shared functions for tf Blkchn
impl Blkchn {
    /// Create a new instance of Blkchn
    pub fn new() -> Self {
        Self {}
    }

    // it does not do much, so we can comment it out for now
    /*
        pub(crate) async fn broadcast_cw_tx(
            &self,
            contract: String,
            msg: Vec<u8>,
            coin: Option<ProtoCoin>,
            siger_key_info: KeyInfo,
            signer_address: String,
            jwt: Option<String>,
        ) -> Result<BroadcastTxResponse, Status> {
            let config = APP.config();

            let msg = MsgExecuteContract {
                sender: signer_address,
                contract: contract,
                msg,
                funds: coin.map_or(vec![], |c| vec![c]),
            }.build_any();

            self.broadcast_tx(msg, siger_key_info, jwt).await
        }
    */

    async fn get_cosmos_grpc_client(&self) -> Result<GrpcClient, Status> {
        let config = APP.config();

        let cosmos_grpc_client = GrpcClient::new(config.chains.tokenfactory.grpc.clone().leak())
            .await
            .map_err(|e| {
                Status::unavailable(format!("Failed to connect to Cosmos gRPC server: {}", e))
            })?;

        Ok(cosmos_grpc_client)
    }

    fn get_tx_status_response(tx_resp: TxResponse) -> Option<TxStatusResponse> {
        Some(TxStatusResponse {
            code: tx_resp.code.to_string(),
            codespace: tx_resp.codespace,
            msg: tx_resp.raw_log,
        })
    }

    pub(crate) async fn broadcast(
        &self,
        msg: Any,
        signer_key_info: KeyInfo,
        fee_info: Option<FeeInfo>,
        jwt: Option<String>,
        tracking_info: Option<TrackingInfo>,
    ) -> Result<TxResponse, Status> {
        let resp = self
            .broadcast_tx(msg, signer_key_info, fee_info, jwt, tracking_info)
            .await
            .map_err(|e| Status::internal(format!("Failed to broadcast transaction: {}", e)))?;

        resp.tx_response.ok_or_else(|| Status::internal("no tx response"))
    }

    pub(crate) async fn broadcast_tx(
        &self,
        msg: Any,
        signer_key_info: KeyInfo,
        fee_info: Option<FeeInfo>,
        jwt: Option<String>,
        tracking_info: Option<TrackingInfo>,
    ) -> Result<BroadcastTxResponse, Status> {
        let config = APP.config();

        // per legacy, we default to pay by fee granter if fee_info is not provided
        let fee_granter = if match fee_info {
            Some(fee_info) => fee_info.pay_by_fee_granter,
            None => true,
        } {
            Some(config.chains.tokenfactory.faucet.address.clone())
        } else {
            None
        };

        let signer = signer::KmsSigner::new(
            config.kms_server.grpc.clone(),
            signer_key_info.kms_provider_uuid,
            signer_key_info.key_name,
            proto::KeyType::try_from(signer_key_info.key_type).unwrap(),
            jwt,
        )
            .await
            .map_err(|e| Status::internal(format!("Failed to create signer: {}", e)))?;

        let mut cosmos_grpc_client = self.get_cosmos_grpc_client().await?;

        let current_block_height = Self::extract_block_height(
            cosmos_grpc_client
                .clients
                .tendermint
                .get_latest_block(GetLatestBlockRequest {})
                .await
                .map_err(|e| Status::internal(format!("Failed to get current block height: {e}")))?
                .into_inner(),
        );
        let timeout_height = Self::calculate_timeout_height(
            current_block_height,
            config.chains.tokenfactory.tx_timeout_blocks,
        )?;
 /*
        // get current block height for timeout_height calculation
        let current_block_height = cosmos_grpc_client
            .clients
            .tendermint
            .get_latest_block(GetLatestBlockRequest {})
            .await
            .map_err(|e| Status::internal(format!("Failed to get current block height: {e}")))?
            .into_inner()
            .sdk_block
            .and_then(|b| b.header)    // Option<Header>
            .map(|h| h.height)          // Option<i64>
            .unwrap_or(0);
        let timeout_height = u64::try_from(current_block_height)
            .map_err(|_| Status::internal("Invalid block height"))?
            + config.chains.tokenfactory.tx_timeout_blocks;
*/
        // wallet
        let mut wallet = cosmos_wallet::cosmos_async_wallet::Wallet::from_async_signing_key(
            cosmos_grpc_client,
            AsyncSigningKey::new(Box::new(signer)),
            &config.chains.tokenfactory.prefix,
            CoinType::Cosmos,
            config.chains.tokenfactory.gas_price.parse().unwrap(),
            config.chains.tokenfactory.gas_adjustment.parse().unwrap(),
            config.chains.tokenfactory.gas_denom.clone(),
            fee_granter,
        )
            .await
            .map_err(|e| Status::unavailable(format!("cosmos client connection error {}", e)))?;

        let response = wallet
            .broadcast_tx(
                vec![msg],           // Vec<Any>: list of msgs to broadcast
                None, // fee: Option<Fee>, if not provided the tx is simulated to calculate the fee
                tracking_info.map(|t| t.tracking_id), // memo: Option<String>
                Some(timeout_height), // timeout_height: Option<u64>
                BroadcastMode::Sync, // Broadcast mode; Block/Sync/Async
            )
            .await
            .map_err(|e| Status::internal(e.to_string()))?;

        Ok(response)
    }

    async fn call_get_addr(jwt: &Option<String>, key_info: Option<KeyInfo>) -> Result<GetAddrResponse, Status> {
        let get_addr_req = GetAddrRequest {
            chain: None,
            key_info,
        };
        let authenticated_req =
            AuthenticatedClient::<Empty>::authenticate_(get_addr_req, jwt);

        let server_blkchn = crate::server::Blkchn::new();
        let get_addr_resp = server_blkchn
            .get_addr(authenticated_req)
            .await
            .map_err(|e| Status::internal(format!("Failed to get address: {}", e)))?
            .into_inner();
        Ok(get_addr_resp)
    }

    fn get_denom(denom: i32) -> Result<(TfDenom, String), Status> {
        let tf_denom = TfDenom::try_from(denom)
            .map_err(|e| Status::invalid_argument(format!("Failed to parse denom: {}", e)))?;
        let denom = tf_denom.as_str_name().to_string();
        Ok((tf_denom, denom))
    }

    /// Extract block height from a GetLatestBlockResponse
    fn extract_block_height(
        response: GetLatestBlockResponse,
    ) -> i64 {
        response
            .sdk_block
            .and_then(|b| b.header)
            .map(|h| h.height)
            .unwrap_or(0)
    }

    /// Calculate timeout_height from current block height + offset
    fn calculate_timeout_height(
        current_block_height: i64,
        tx_timeout_blocks: u64,
    ) -> Result<u64, Status> {
        let height = u64::try_from(current_block_height)
            .map_err(|_| Status::internal("Invalid block height"))?;
        Ok(height + tx_timeout_blocks)
    }

}

/// Implement the most of  BlkchnSvc trait for tf Blkchn
impl Blkchn {
    pub async fn get_balance(
        &self,
        request: Request<GetBalanceRequest>,
    ) -> Result<Response<GetBalanceResponse>, Status> {
        let req = request.into_inner();

        let (tf_denom, _) = Self::get_denom(req.denom)?;

        let bal_req = QueryBalanceRequest {
            address: req.address,
            denom: tf_denom.as_str_name().to_string(),
        };

        let mut cosmos_grpc_client = self.get_cosmos_grpc_client().await?;

        let resp = cosmos_grpc_client
            .clients
            .bank
            .balance(bal_req)
            .await
            .map_err(|e| Status::internal(e.to_string()))?;
        let resp = resp.into_inner();

        let (denom, value) = match resp.balance {
            Some(balance) => (balance.denom, balance.amount),
            None => (
                "bank balance unavailable".to_string(),
                "bank balance unavailable".to_string(),
            ),
        };

        let tf_denom = TfDenom::from_str_name(&denom)
            .ok_or_else(|| Status::internal("Failed to parse denom"))?;

        Ok(Response::new(GetBalanceResponse {
            chain: req.chain,
            denom: tf_denom as i32,
            value,
        }))
    }

    pub async fn send(
        &self,
        request: Request<SendRequest>,
    ) -> Result<Response<CommonTxResponse>, Status> {
        let _config = APP.config();

        let jwt = AuthenticatedClient::<kms_proto::kms_svc_client::KmsSvcClient<Channel>>::get_jwt(
            request.metadata(),
        );

        let req = request.into_inner();

        let (_, denom) = Self::get_denom(req.denom)?;

        let from_address = Self::call_get_addr(&jwt, req.from_key_info.clone()).await?.address;

        // send message
        let msg = MsgSend {
            from_address,
            to_address: req.to_address,
            amount: vec![
                ProtoCoin {
                    denom,
                    amount: req.value,
                },
            ],
        }
            .build_any();

        // it is safe to req.from_key_info.unwrap() because it is already checked in call_get_addr
        let tx_resp = self.broadcast(msg, req.from_key_info.unwrap(), req.fee_info, jwt, req.tracking_info.clone()).await?;

        Ok(Response::new(CommonTxResponse {
            chain: req.chain,
            txhash: tx_resp.txhash.clone(),
            tx_status: Self::get_tx_status_response(tx_resp),
            tracking_info: req.tracking_info,
        }))
    }

    pub async fn mint(
        &self,
        request: Request<MintRequest>,
    ) -> Result<Response<CommonTxResponse>, Status> {
        let config = APP.config();

        let jwt = AuthenticatedClient::<kms_proto::kms_svc_client::KmsSvcClient<Channel>>::get_jwt(
            request.metadata(),
        );

        let req = request.into_inner();

        let (_, denom) = Self::get_denom(req.denom)?;

        let minter_address = Self::call_get_addr(&jwt, req.minter_key_info.clone()).await?.address;

        let mint_msg = ExecuteMsg::Tf(TokenfactoryContractMsg::Mint {
            orig_sender: None, // orig_sender, if set, is used only if caller is a contract
            address: req.to_address,
            denom,
            value: req.value.to_string(),
        });

        let mint_msg =
            serde_json::to_vec(&mint_msg).map_err(|e| Status::invalid_argument(e.to_string()))?;

        let msg = MsgExecuteContract {
            sender: minter_address,
            contract: config.chains.tokenfactory.tokenfactory_contract.to_string(),
            msg: mint_msg,
            funds: vec![],
        }
        .build_any();

        let tx_resp = self.broadcast(msg, req.minter_key_info.unwrap(), req.fee_info, jwt, req.tracking_info.clone()).await?;

        Ok(Response::new(CommonTxResponse {
            chain: req.chain,
            txhash: tx_resp.txhash.clone(),
            tx_status: Self::get_tx_status_response(tx_resp),
            tracking_info: req.tracking_info,
        }))
    }

    pub async fn redeem(
        &self,
        request: Request<RedeemRequest>,
    ) -> Result<Response<CommonTxResponse>, Status> {
        let config = APP.config();

        let jwt = AuthenticatedClient::<kms_proto::kms_svc_client::KmsSvcClient<Channel>>::get_jwt(
            request.metadata(),
        );

        let req = request.into_inner();

        let (_, denom) = Self::get_denom(req.denom)?;

        let from_address = Self::call_get_addr(&jwt, req.from_key_info.clone()).await?.address;

        let redeem_msg = ExecuteMsg::Redeem {
            orig_sender: None, // orig_sender, if set, is used only if caller is a contract and for redeem, it only shows in event
            minter_address: req.minter_address.clone(),
            denom: denom.clone(),
            value: req.value.clone(),
        };
        let redeem_msg =
            serde_json::to_vec(&redeem_msg).map_err(|e| Status::invalid_argument(e.to_string()))?;

        let coin = ProtoCoin {
            denom,
            amount: req.value.to_string(),
        };

        let msg = MsgExecuteContract {
            sender: from_address,
            contract: config.chains.tokenfactory.tokenfactory_contract.to_string(),
            msg: redeem_msg,
            funds: vec![coin],
        }
        .build_any();

        let tx_resp = self.broadcast(msg, req.from_key_info.unwrap(), req.fee_info, jwt, req.tracking_info.clone()).await?;

        Ok(Response::new(CommonTxResponse {
            chain: req.chain,
            txhash: tx_resp.txhash.clone(),
            tx_status: Self::get_tx_status_response(tx_resp),
            tracking_info: req.tracking_info,
        }))
    }

    pub async fn grant_fee_basic_allowance(
        &self,
        request: Request<GrantFeeBasicAllowanceRequest>,
    ) -> Result<Response<CommonTxResponse>, Status> {
        let config = APP.config();

        let jwt = AuthenticatedClient::<kms_proto::kms_svc_client::KmsSvcClient<Channel>>::get_jwt(
            request.metadata(),
        );

        let req = request.into_inner();

        // parse and validate denom.
        let (_, denom) = Self::get_denom(req.allowance_denom)?;

        if denom != config.chains.tokenfactory.gas_denom {
            return Err(Status::invalid_argument(format!(
                "Invalid allowance_denom: {}, must be the same as the configured gas_denom: {}",
                denom, config.chains.tokenfactory.gas_denom
            )));
        }

        // allowance value
        let allowance_value = req
            .allowance_value
            .parse::<u128>()
            .map_err(|e| Status::invalid_argument(e.to_string()))?;
        let config_allowance_value = config
            .chains
            .tokenfactory
            .faucet
            .allowance_value
            .parse::<u128>()
            .map_err(|e| Status::invalid_argument(e.to_string()))?;
        let allowance_value = config_allowance_value.min(allowance_value);

        // hours to expire
        let hours_to_expire = config
            .chains
            .tokenfactory
            .faucet
            .hours_to_expire
            .min(req.hours_to_expire);

        let execute_msg = ExecuteMsg::Feegrant(FeegrantContractMsg::GrantFeeBasicAllowance {
            granter: config.chains.tokenfactory.faucet.address.clone(),
            grantee: req.grantee,
            allowance_denom: denom,
            allowance_value: allowance_value.to_string(),
            hours_to_expire,
        });

        let json_msg = serde_json::to_vec(&execute_msg)
            .map_err(|e| Status::invalid_argument(e.to_string()))?;

        let msg = MsgExecuteContract {
            sender: config.chains.tokenfactory.faucet.address.clone(),
            contract: config.chains.tokenfactory.tokenfactory_contract.to_string(),
            msg: json_msg,
            funds: vec![],
        }
        .build_any();

        let granter_key_info = req
            .granter_key_info
            .clone()
            .ok_or_else(|| Status::invalid_argument("Missing granter key info"))?;

        let tx_resp = self.broadcast(msg, granter_key_info, None, jwt, req.tracking_info.clone()).await?;

        Ok(Response::new(CommonTxResponse {
            chain: req.chain,
            txhash: tx_resp.txhash.clone(),
            tx_status: Self::get_tx_status_response(tx_resp),
            tracking_info: req.tracking_info,
        }))
    }

    // like send, revoke fee basic allowance does not go thru wasm.
    pub async fn revoke_fee_basic_allowance(&self, request: Request<RevokeFeeBasicAllowanceRequest>) -> Result<Response<CommonTxResponse>, Status> {
        let config = APP.config();

        let jwt = AuthenticatedClient::<kms_proto::kms_svc_client::KmsSvcClient<Channel>>::get_jwt(
            request.metadata(),
        );

        let req = request.into_inner();

        let msg = MsgRevokeAllowance {
            granter: config.chains.tokenfactory.faucet.address.clone(),
            grantee: req.grantee.clone(),
        }
            .build_any();

        let granter_key_info = req
            .granter_key_info
            .clone()
            .ok_or_else(|| Status::invalid_argument("Missing granter key info"))?;

        let tx_resp = self.broadcast(msg, granter_key_info, None, jwt, req.tracking_info.clone()).await?;

        Ok(Response::new(CommonTxResponse {
            chain: req.chain,
            txhash: tx_resp.txhash.clone(),
            tx_status: Self::get_tx_status_response(tx_resp),
            tracking_info: req.tracking_info,
        }))
    }

    pub async fn get_fee_basic_allowance(
        &self,
        request: Request<GetFeeBasicAllowanceRequest>,
    ) -> Result<Response<GetFeeBasicAllowanceResponse>, Status> {
        let config = APP.config();
        let req = request.into_inner();

        let query_msg = QueryMsg::Feegrant(FeegrantQuery::FeeBasicAllowance {
            granter: config.chains.tokenfactory.faucet.address.clone(),
            grantee: req.grantee,
        });

        let cosmos_grpc_client = self.get_cosmos_grpc_client().await?;

        let resp = cosmos_grpc_client
            .query_smart_contract::<QueryMsg, FeeBasicAllowanceResponse>(
                config.chains.tokenfactory.tokenfactory_contract.clone(),
                query_msg,
            )
            .await
            .map_err(|e| Status::internal(e.to_string()))?;

        Ok(Response::new(GetFeeBasicAllowanceResponse {
            chain: req.chain,
            fee_basic_grant: Some(GetFeeBasicGrant {
                granter: resp.allowance.granter,
                grantee: resp.allowance.grantee,
                allowance_denom: resp.allowance.allowance.denom,
                allowance_value: resp.allowance.allowance.amount.to_string(),
                expiration: resp.allowance.expiration,
            }),
        }))
    }

    pub async fn get_tx_status(
        &self,
        request: Request<GetTxStatusRequest>,
    ) -> Result<Response<GetTxStatusResponse>, Status> {
        let req = request.into_inner();

        let mut cosmos_grpc_client = self.get_cosmos_grpc_client().await?;

        match cosmos_grpc_client
            .clients
            .tx
            .get_tx(GetTxRequest {
                hash: req.txhash.clone(),
            })
            .await
        {
            Ok(resp) => {
                let resp = resp.into_inner();

                let tx_resp = match resp.tx_response {
                    Some(tx_response) => tx_response,
                    None => {
                        return Err(Status::internal("no tx response"));
                    }
                };
                Ok(Response::new(GetTxStatusResponse {
                    chain: req.chain,
                    txhash: req.txhash,
                    status: Self::get_tx_status_response(tx_resp),
                }))
            }
            Err(e) => Ok(Response::new(GetTxStatusResponse {
                chain: req.chain,
                txhash: req.txhash,
                status: Some(TxStatusResponse {
                    code: "-1".to_string(),
                    codespace: "".to_string(),
                    msg: format!("Failed to get tx status: {}", e),
                }),
            })),
        }
    }

    pub async fn set_denom_metadata(&self, request: Request<SetDenomMetadataRequest>) -> Result<Response<CommonTxResponse>, Status> {
        let config = APP.config();

        let jwt = AuthenticatedClient::<kms_proto::kms_svc_client::KmsSvcClient<Channel>>::get_jwt(
            request.metadata(),
        );

        let req = request.into_inner();

        let denom_metadata = req.metadata.ok_or_else(|| Status::invalid_argument("Missing metadata"))?;
        let set_denom_metadata_msg = ExecuteMsg::Tf(TokenfactoryContractMsg::SetDenomMetadata {
            orig_sender: None,
            metadata: tokenfactory_bindings::query::DenomMetadata {
                description: denom_metadata.description,
                denom_units: denom_metadata
                    .denom_units
                    .into_iter()
                    .map(|du| tokenfactory_bindings::query::DenomUnit {
                        denom: du.denom,
                        exponent: du.exponent,
                        aliases: if du.aliases.is_empty() {
                            None
                        } else {
                            Some(du.aliases)},
                    })
                    .collect(),
                base: denom_metadata.base,
                display: denom_metadata.display,
                name: denom_metadata.name,
                symbol: denom_metadata.symbol,
                uri: denom_metadata.uri,
                uri_hash: denom_metadata.uri_hash,
            }
        });

        let json_msg = serde_json::to_vec(&set_denom_metadata_msg)
            .map_err(|e| Status::invalid_argument(e.to_string()))?;

        let masterminter_address = Self::call_get_addr(&jwt, req.masterminter_key_info.clone()).await?.address;

        let msg = MsgExecuteContract {
            sender: masterminter_address,
            contract: config.chains.tokenfactory.tokenfactory_contract.to_string(),
            msg: json_msg,
            funds: vec![],
        }
            .build_any();

        let tx_resp = self.broadcast(msg, req.masterminter_key_info.unwrap(), req.fee_info, jwt, req.tracking_info.clone()).await?;

        Ok(Response::new(CommonTxResponse {
            chain: req.chain,
            txhash: tx_resp.txhash.clone(),
            tx_status: Self::get_tx_status_response(tx_resp),
            tracking_info: req.tracking_info,
        }))
    }

    pub async fn get_denom_metadata(
        &self,
        request: Request<GetDenomMetadataRequest>,
    ) -> Result<Response<GetDenomMetadataResponse>, Status> {
        let req = request.into_inner();

        let mut cosmos_grpc_client = self.get_cosmos_grpc_client().await?;

        let denom_metadata_req = QueryDenomMetadataRequest { denom: req.denom };

        let resp = cosmos_grpc_client
            .clients
            .bank
            .denom_metadata(denom_metadata_req)
            .await
            .map_err(|e| Status::internal(e.to_string()))?;
        let mut resp = resp.into_inner();

        Ok(Response::new(GetDenomMetadataResponse {
            chain: req.chain,
            metadata: resp.metadata.take().map(convert_denom_metadata),
        }))
    }

    pub async fn get_all_denom_metadata(
        &self,
        request: Request<GetAllDenomMetadataRequest>,
    ) -> Result<Response<GetAllDenomMetadataResponse>, Status> {
        let req = request.into_inner();

        let mut cosmos_grpc_client = self.get_cosmos_grpc_client().await?;

        let resp = cosmos_grpc_client
            .clients
            .bank
            .denoms_metadata(QueryDenomsMetadataRequest { pagination: None })
            .await
            .map_err(|e| Status::internal(e.to_string()))?;
        let resp = resp.into_inner();
        let metadata = resp
            .metadatas
            .into_iter()
            .map(convert_denom_metadata)
            .collect();

        Ok(Response::new(GetAllDenomMetadataResponse {
            chain: req.chain,
            denom_metadata: metadata,
        }))
    }

    pub async fn configure_minter(&self, request: Request<ConfigureMinterRequest>) -> Result<Response<CommonTxResponse>, Status> {
        let config = APP.config();

        let jwt = AuthenticatedClient::<kms_proto::kms_svc_client::KmsSvcClient<Channel>>::get_jwt(
            request.metadata(),
        );

        let req = request.into_inner();

        let (_, denom) = Self::get_denom(req.allowance_denom)?;

        let configure_minter_msg = ExecuteMsg::Tf(TokenfactoryContractMsg::ConfigureMinter {
            address: req.address,
            allowance_value: req.allowance_value,
            allowance_denom: denom,
        });

        let json_msg = serde_json::to_vec(&configure_minter_msg)
            .map_err(|e| Status::invalid_argument(e.to_string()))?;

        let mintercontroller_address = Self::call_get_addr(&jwt, req.mintercontroller_key_info.clone()).await?.address;

        let msg = MsgExecuteContract {
            sender: mintercontroller_address,
            contract: config.chains.tokenfactory.tokenfactory_contract.to_string(),
            msg: json_msg,
            funds: vec![],
        }
            .build_any();

        let tx_resp = self.broadcast(msg, req.mintercontroller_key_info.unwrap(), req.fee_info, jwt, req.tracking_info.clone()).await?;

        Ok(Response::new(CommonTxResponse {
            chain: req.chain,
            txhash: tx_resp.txhash.clone(),
            tx_status: Self::get_tx_status_response(tx_resp),
            tracking_info: req.tracking_info,
        }))
    }

    pub async fn remove_minter(&self, request: Request<RemoveMinterRequest>) -> Result<Response<CommonTxResponse>, Status> {
        let config = APP.config();

        let jwt = AuthenticatedClient::<kms_proto::kms_svc_client::KmsSvcClient<Channel>>::get_jwt(
            request.metadata(),
        );

        let req = request.into_inner();

        let (_, denom) = Self::get_denom(req.denom)?;

        let remove_minter_msg = ExecuteMsg::Tf(TokenfactoryContractMsg::RemoveMinter {
            address: req.address,
            denom,
        });

        let json_msg = serde_json::to_vec(&remove_minter_msg)
            .map_err(|e| Status::invalid_argument(e.to_string()))?;

        let mintercontroller_address = Self::call_get_addr(&jwt, req.mintercontroller_key_info.clone()).await?.address;

        let msg = MsgExecuteContract {
            sender: mintercontroller_address,
            contract: config.chains.tokenfactory.tokenfactory_contract.to_string(),
            msg: json_msg,
            funds: vec![],
        };

        let tx_resp = self.broadcast(msg.build_any(), req.mintercontroller_key_info.unwrap(), req.fee_info, jwt, req.tracking_info.clone()).await?;

        Ok(Response::new(CommonTxResponse {
            chain: req.chain,
            txhash: tx_resp.txhash.clone(),
            tx_status: Self::get_tx_status_response(tx_resp),
            tracking_info: req.tracking_info,
        }))
    }

    pub async fn get_minter(&self, request: Request<GetMinterRequest>) -> Result<Response<GetMinterResponse>, Status> {
        let config = APP.config();

        let req = request.into_inner();

        let cosmos_grpc_client = self.get_cosmos_grpc_client().await?;

        let query_msg = QueryMsg::Tf(tokenfactory_bindings::query::TokenfactoryQuery::Minters {
            address: req.address.clone(),
            denom: Self::get_denom(req.denom)?.1,
        });

        let resp = cosmos_grpc_client
            .query_smart_contract::<QueryMsg, tokenfactory_bindings::query::MintersResponse>(
                config.chains.tokenfactory.tokenfactory_contract.clone(),
                query_msg,
            )
            .await
            .map_err(|e| Status::internal(e.to_string()))?;

        Ok(Response::new(GetMinterResponse {
            chain: req.chain,
            address: resp.address,
            allowance_denom: resp.allowance.denom,
            allowance_value: resp.allowance.amount.to_string(),
        }))
    }

    pub async fn get_all_minters(&self, request: Request<GetAllMintersRequest>) -> Result<Response<GetAllMintersResponse>, Status> {
        let config = APP.config();

        let req = request.into_inner();

        let cosmos_grpc_client = self.get_cosmos_grpc_client().await?;

        let query_msg = QueryMsg::Tf(tokenfactory_bindings::query::TokenfactoryQuery::AllMinters {});

        let resp = cosmos_grpc_client
            .query_smart_contract::<QueryMsg, tokenfactory_bindings::query::AllMintersResponse>(
                config.chains.tokenfactory.tokenfactory_contract.clone(),
                query_msg,
            )
            .await
            .map_err(|e| Status::internal(e.to_string()))?;

        Ok(Response::new(GetAllMintersResponse {
            chain: req.chain,
            minters: resp.minters.into_iter().map(|m| GetMinterResponse {
                chain: req.chain,
                address: m.address,
                allowance_denom: m.allowance.denom,
                allowance_value: m.allowance.amount.to_string(),
            }).collect(),
        }))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use cosmos_grpc_client::cosmos_sdk_proto::cosmos::base::abci::v1beta1::TxResponse;

    #[tokio::test]
    async fn test_get_tx_status_success() {
        // This requires a running Cosmos node, so we test the helper function instead
        let tx_resp = TxResponse {
            height: 12345,
            txhash: "ABC123".to_string(),
            codespace: "bank".to_string(),
            code: 0,
            data: "".to_string(),
            raw_log: "success".to_string(),
            logs: vec![],
            info: "".to_string(),
            gas_wanted: 200000,
            gas_used: 150000,
            tx: None,
            timestamp: "2024-01-01T00:00:00Z".to_string(),
            events: vec![],
        };

        let result = Blkchn::get_tx_status_response(tx_resp);
        assert!(result.is_some());
        let status = result.unwrap();
        assert_eq!(status.code, "0");
        assert_eq!(status.codespace, "bank");
        assert_eq!(status.msg, "success");
    }

    #[tokio::test]
    async fn test_get_tx_status_error() {
        let tx_resp = TxResponse {
            height: 12345,
            txhash: "DEF456".to_string(),
            codespace: "sdk".to_string(),
            code: 5,
            data: "".to_string(),
            raw_log: "insufficient funds: 0utoken < 1000utoken".to_string(),
            logs: vec![],
            info: "".to_string(),
            gas_wanted: 200000,
            gas_used: 0,
            tx: None,
            timestamp: "2024-01-01T00:00:00Z".to_string(),
            events: vec![],
        };

        let result = Blkchn::get_tx_status_response(tx_resp);
        assert!(result.is_some());
        let status = result.unwrap();
        assert_eq!(status.code, "5");
        assert_eq!(status.codespace, "sdk");
        assert!(status.msg.contains("insufficient funds"));
    }

    #[test]
    fn test_get_error_info_non_zero_code() {
        let tx_resp = TxResponse {
            code: 32,
            codespace: "wasm".to_string(),
            raw_log: "contract execution failed".to_string(),
            ..Default::default()
        };

        let result = Blkchn::get_tx_status_response(tx_resp);
        assert!(result.is_some());
        let info = result.unwrap();
        assert_eq!(info.code, "32");
        assert_eq!(info.codespace, "wasm");
        assert_eq!(info.msg, "contract execution failed");
    }
}

#[cfg(test)]
mod denom_metadata_tests {
    use super::*;
    use crate::proto::Chain;

    #[tokio::test]
    async fn test_get_denom_metadata_request_structure() {
        let req = GetDenomMetadataRequest {
            chain: Some(Chain::Tokenfactory as i32),
            denom: "factory/wfactory1/wfusd".to_string(),
        };

        // Verify request structure
        assert_eq!(req.chain, Some(Chain::Tokenfactory as i32));
        assert!(req.denom.starts_with("factory/"));
    }

    #[tokio::test]
    async fn test_get_all_denom_metadata_request_structure() {
        let req = GetAllDenomMetadataRequest {
            chain: Some(Chain::Tokenfactory as i32),
        };

        // Verify request structure
        assert_eq!(req.chain, Some(Chain::Tokenfactory as i32));
    }
}

#[cfg(test)]
mod block_height_tests {
    use super::*;
    use cosmos_grpc_client::cosmos_sdk_proto::cosmos::base::tendermint::v1beta1::GetLatestBlockResponse;
    use cosmos_grpc_client::cosmos_sdk_proto::cosmos::base::tendermint::v1beta1::Block as SdkBlock;
    use cosmos_grpc_client::cosmos_sdk_proto::cosmos::base::tendermint::v1beta1::Header;

    #[test]
    fn test_extract_block_height_valid() {
        let response = GetLatestBlockResponse {
            block_id: None,
            block: None,
            sdk_block: Some(SdkBlock {
                header: Some(Header {
                    height: 12345,
                    ..Default::default()
                }),
                data: None,
                evidence: None,
                last_commit: None,
            }),
        };
        assert_eq!(Blkchn::extract_block_height(response), 12345);
    }

    #[test]
    fn test_extract_block_height_missing_block() {
        let response = GetLatestBlockResponse {
            block_id: None,
            block: None,
            sdk_block: None,
        };
        assert_eq!(Blkchn::extract_block_height(response), 0);
    }

    #[test]
    fn test_extract_block_height_missing_header() {
        let response = GetLatestBlockResponse {
            block_id: None,
            block: None,
            sdk_block: Some(SdkBlock {
                header: None,
                data: None,
                evidence: None,
                last_commit: None,
            }),
        };
        assert_eq!(Blkchn::extract_block_height(response), 0);
    }

    #[test]
    fn test_calculate_timeout_height_valid() {
        let result = Blkchn::calculate_timeout_height(100, 10);
        assert!(result.is_ok());
        assert_eq!(result.unwrap(), 110);
    }

    #[test]
    fn test_calculate_timeout_height_zero() {
        let result = Blkchn::calculate_timeout_height(0, 50);
        assert!(result.is_ok());
        assert_eq!(result.unwrap(), 50);
    }

    #[test]
    fn test_calculate_timeout_height_negative_fails() {
        let result = Blkchn::calculate_timeout_height(-1, 10);
        assert!(result.is_err());
        let status = result.unwrap_err();
        assert_eq!(status.code(), tonic::Code::Internal);
        assert!(status.message().contains("Invalid block height"));
    }

    #[test]
    fn test_calculate_timeout_height_large_values() {
        let result = Blkchn::calculate_timeout_height(1_000_000_000, 100);
        assert!(result.is_ok());
        assert_eq!(result.unwrap(), 1_000_000_100);
    }
}
