use crate::application::APP;
use crate::authenticated_client::AuthenticatedClient;
use crate::proto::blkchn_svc_server::BlkchnSvc;
use crate::proto::{
    Chain, FeeInfo, GetAddrRequest, GetBalanceRequest, GetBalanceResponse,
    GetFeeBasicAllowanceRequest, GetFeeBasicAllowanceResponse, GetFeeBasicGrant,
    GrantFeeBasicAllowanceRequest, GrantFeeBasicAllowanceResponse,
};
use crate::proto::{
    GetAllDenomMetadataRequest, GetAllDenomMetadataResponse, GetDenomMetadataRequest,
    GetDenomMetadataResponse, GetTxStatusRequest, GetTxStatusResponse, TxStatusResponse,
};
use crate::proto::{
    KeyInfo, MintRequest, MintResponse, RedeemRequest, RedeemResponse, SendRequest, SendResponse,
    TfDenom,
};
use crate::types::convert_denom_metadata;
use crate::{kms_proto, proto, signer};
use abscissa_core::Application;
use cosmos_grpc_client::cosmos_sdk_proto::cosmos::bank::v1beta1::{
    MsgSend, QueryBalanceRequest, QueryDenomMetadataRequest, QueryDenomsMetadataRequest,
};
use cosmos_grpc_client::cosmos_sdk_proto::cosmos::base::abci::v1beta1::TxResponse;
use cosmos_grpc_client::cosmos_sdk_proto::cosmos::base::v1beta1::Coin as ProtoCoin;
use cosmos_grpc_client::cosmos_sdk_proto::cosmos::tx::v1beta1::{
    BroadcastTxResponse, GetTxRequest,
};
use cosmos_grpc_client::cosmos_sdk_proto::cosmwasm::wasm::v1::MsgExecuteContract;
use cosmos_grpc_client::cosmos_sdk_proto::Any;
use cosmos_grpc_client::{BroadcastMode, CoinType, GrpcClient, ProstMsgNameToAny};
use kms_common::async_signer::AsyncSigningKey;
use std::io::Empty;
use tokenfactory::msg::{ExecuteMsg, FeegrantContractMsg, QueryMsg, TokenfactoryContractMsg};
use tokenfactory::{FeeBasicAllowanceResponse, FeegrantQuery};
use tonic::transport::Channel;
use tonic::{Request, Response, Status};

#[derive(Debug, Default)]
pub struct Blkchn {}

impl Blkchn {
    /// Create a new instance of Blkchn
    pub fn new() -> Self {
        Self {}
    }

    // it does not do much, so we can comment it out for now
    /*
        pub(crate) async fn broadcast_cw_tx(
            &self,
            contract: String,
            msg: Vec<u8>,
            coin: Option<ProtoCoin>,
            siger_key_info: KeyInfo,
            signer_address: String,
            jwt: Option<String>,
        ) -> Result<BroadcastTxResponse, Status> {
            let config = APP.config();

            let msg = MsgExecuteContract {
                sender: signer_address,
                contract: contract,
                msg,
                funds: coin.map_or(vec![], |c| vec![c]),
            }.build_any();

            self.broadcast_tx(msg, siger_key_info, jwt).await
        }
    */

    async fn get_cosmos_grpc_client(&self) -> Result<GrpcClient, Status> {
        let config = APP.config();

        let cosmos_grpc_client = GrpcClient::new(config.chains.tokenfactory.grpc.clone().leak())
            .await
            .map_err(|e| {
                Status::unavailable(format!("Failed to connect to Cosmos gRPC server: {}", e))
            })?;

        Ok(cosmos_grpc_client)
    }

    fn get_tx_status_response(tx_resp: TxResponse) -> Option<TxStatusResponse> {
        Some(TxStatusResponse {
            code: tx_resp.code.to_string(),
            codespace: tx_resp.codespace,
            msg: tx_resp.raw_log,
        })
    }

    pub(crate) async fn broadcast_tx(
        &self,
        msg: Any,
        signer_key_info: KeyInfo,
        fee_info: Option<FeeInfo>,
        jwt: Option<String>,
    ) -> Result<BroadcastTxResponse, Status> {
        let config = APP.config();

        // per legacy, we default to pay by fee granter if fee_info is not provided
        let fee_granter = if match fee_info {
            Some(fee_info) => fee_info.pay_by_fee_granter,
            None => true,
        } {
            Some(config.chains.tokenfactory.faucet.address.clone())
        } else {
            None
        };

        let signer = signer::KmsSigner::new(
            config.kms_server.grpc.clone(),
            signer_key_info.kms_provider_uuid,
            signer_key_info.key_name,
            proto::KeyType::try_from(signer_key_info.key_type).unwrap(),
            jwt,
        )
        .await
        .map_err(|e| Status::internal(format!("Failed to create signer: {}", e)))?;

        let cosmos_grpc_client = self.get_cosmos_grpc_client().await?;

        // wallet
        let mut wallet = cosmos_wallet::cosmos_async_wallet::Wallet::from_async_signing_key(
            cosmos_grpc_client,
            AsyncSigningKey::new(Box::new(signer)),
            &config.chains.tokenfactory.prefix,
            CoinType::Cosmos,
            config.chains.tokenfactory.gas_price.parse().unwrap(),
            config.chains.tokenfactory.gas_adjustment.parse().unwrap(),
            config.chains.tokenfactory.gas_denom.clone(),
            fee_granter,
        )
        .await
        .map_err(|e| Status::unavailable(format!("cosmos client connection error {}", e)))?;

        let response = wallet
            .broadcast_tx(
                vec![msg],           // Vec<Any>: list of msgs to broadcast
                None, // fee: Option<Fee>, if not provided the tx is simulated to calculate the fee
                None, // memo: Option<String>
                BroadcastMode::Sync, // Broadcast mode; Block/Sync/Async
            )
            .await
            .map_err(|e| Status::internal(e.to_string()))?;

        Ok(response)
    }

    pub async fn get_balance(
        &self,
        request: Request<GetBalanceRequest>,
    ) -> Result<Response<GetBalanceResponse>, Status> {
        let req = request.into_inner();

        let tf_denom = TfDenom::try_from(req.denom)
            .map_err(|e| Status::invalid_argument(format!("Failed to parse denom: {}", e)))?;

        let bal_req = QueryBalanceRequest {
            address: req.address,
            denom: tf_denom.as_str_name().to_string(),
        };

        let mut cosmos_grpc_client = self.get_cosmos_grpc_client().await?;

        let resp = cosmos_grpc_client
            .clients
            .bank
            .balance(bal_req)
            .await
            .map_err(|e| Status::internal(e.to_string()))?;
        let resp = resp.into_inner();

        let (denom, value) = match resp.balance {
            Some(balance) => (balance.denom, balance.amount),
            None => (
                "bank balance unavailable".to_string(),
                "bank balance unavailable".to_string(),
            ),
        };

        let tf_denom = TfDenom::from_str_name(&denom)
            .ok_or_else(|| Status::internal("Failed to parse denom"))?;

        Ok(Response::new(GetBalanceResponse {
            chain: Some(Chain::Tokenfactory as i32),
            denom: tf_denom as i32,
            value,
        }))
    }

    pub async fn send(
        &self,
        request: Request<SendRequest>,
    ) -> Result<Response<SendResponse>, Status> {
        let _config = APP.config();

        let jwt = AuthenticatedClient::<kms_proto::kms_svc_client::KmsSvcClient<Channel>>::get_jwt(
            request.metadata(),
        );

        let req = request.into_inner();

        let tf_denom = TfDenom::try_from(req.denom)
            .map_err(|e| Status::invalid_argument(format!("Failed to parse denom: {}", e)))?;
        let denom = tf_denom.as_str_name().to_string();

        let key_info = req
            .from_key_info
            .clone()
            .ok_or_else(|| Status::invalid_argument("Missing sender key info"))?;

        // get the signer key address
        let get_addr_req = GetAddrRequest {
            chain: None,
            key_info: Some(key_info.clone()),
        };
        let authenticated_req = AuthenticatedClient::<Empty>::authenticate_(get_addr_req, &jwt);
        // let authenticated_req = AuthenticatedClient::<kms_proto::kms_svc_client::KmsSvcClient<Channel>>::authenticate_(get_addr_req, &jwt);

        let server_blkchn = crate::server::Blkchn::new();
        let get_addr_resp = server_blkchn
            .get_addr(authenticated_req)
            .await
            .map_err(|e| Status::internal(format!("Failed to get address: {}", e)))?
            .into_inner();

        // send message
        let msg = MsgSend {
            from_address: get_addr_resp.address,
            to_address: req.to_address,
            amount: vec![
                cosmos_grpc_client::cosmos_sdk_proto::cosmos::base::v1beta1::Coin {
                    denom,
                    amount: req.value,
                },
            ],
        }
        .build_any();

        let broadcast_tx_resp = self
            .broadcast_tx(msg, key_info, req.fee_info, jwt)
            .await
            .map_err(|e| Status::internal(format!("Failed to broadcast transaction: {}", e)))?;
        let tx_resp = broadcast_tx_resp
            .tx_response
            .ok_or_else(|| Status::internal("no tx response"))?;

        Ok(Response::new(SendResponse {
            chain: req.chain,
            txhash: tx_resp.txhash.clone(),
            tx_status: Self::get_tx_status_response(tx_resp),
        }))
    }

    pub async fn mint(
        &self,
        request: Request<MintRequest>,
    ) -> Result<Response<MintResponse>, Status> {
        let config = APP.config();

        let jwt = AuthenticatedClient::<kms_proto::kms_svc_client::KmsSvcClient<Channel>>::get_jwt(
            request.metadata(),
        );

        let req = request.into_inner();

        let tf_denom = TfDenom::try_from(req.denom)
            .map_err(|e| Status::invalid_argument(format!("Failed to parse denom: {}", e)))?;
        let denom = tf_denom.as_str_name().to_string();

        // get the minter key address
        let get_minter_addr_req = GetAddrRequest {
            chain: None,
            key_info: Some(
                req.minter_key_info
                    .clone()
                    .ok_or_else(|| Status::invalid_argument("Missing minter key info"))?,
            ),
        };
        let authenticated_req =
            AuthenticatedClient::<Empty>::authenticate_(get_minter_addr_req, &jwt);

        let server_blkchn = crate::server::Blkchn::new();
        let get_minter_addr_resp = server_blkchn
            .get_addr(authenticated_req)
            .await
            .map_err(|e| Status::internal(format!("Failed to get minter address: {}", e)))?
            .into_inner();

        let mint_msg = ExecuteMsg::Tf(TokenfactoryContractMsg::Mint {
            orig_sender: Some(get_minter_addr_resp.address.clone()),
            address: req.to_address,
            denom,
            value: req.value.to_string(),
        });

        let mint_msg =
            serde_json::to_vec(&mint_msg).map_err(|e| Status::invalid_argument(e.to_string()))?;

        let msg = MsgExecuteContract {
            sender: get_minter_addr_resp.address,
            contract: config.chains.tokenfactory.tokenfactory_contract.to_string(),
            msg: mint_msg,
            funds: vec![],
        }
        .build_any();

        let broadcast_tx_resp = self
            .broadcast_tx(msg, req.minter_key_info.unwrap(), req.fee_info, jwt)
            .await
            .map_err(|e| Status::internal(format!("Failed to broadcast transaction: {}", e)))?;

        let tx_resp = broadcast_tx_resp
            .tx_response
            .ok_or_else(|| Status::internal("no tx response"))?;

        Ok(Response::new(MintResponse {
            chain: None,
            txhash: tx_resp.txhash.clone(),
            tx_status: Self::get_tx_status_response(tx_resp),
        }))
    }

    pub async fn redeem(
        &self,
        request: Request<RedeemRequest>,
    ) -> Result<Response<RedeemResponse>, Status> {
        let config = APP.config();

        let jwt = AuthenticatedClient::<kms_proto::kms_svc_client::KmsSvcClient<Channel>>::get_jwt(
            request.metadata(),
        );

        let req = request.into_inner();

        let tf_denom = TfDenom::try_from(req.denom)
            .map_err(|e| Status::invalid_argument(format!("Failed to parse denom: {}", e)))?;
        let denom = tf_denom.as_str_name().to_string();

        // get the signer key address
        let get_addr_req = GetAddrRequest {
            chain: None,
            key_info: Some(
                req.from_key_info
                    .clone()
                    .ok_or_else(|| Status::invalid_argument("Missing sender key info"))?,
            ),
        };
        let authenticated_req = AuthenticatedClient::<Empty>::authenticate_(get_addr_req, &jwt);
        // let authenticated_req = AuthenticatedClient::<kms_proto::kms_svc_client::KmsSvcClient<Channel>>::authenticate_(get_addr_req, &jwt);

        let server_blkchn = crate::server::Blkchn::new();
        let get_addr_resp = server_blkchn
            .get_addr(authenticated_req)
            .await
            .map_err(|e| Status::internal(format!("Failed to get sender address: {}", e)))?
            .into_inner();

        let redeem_msg = ExecuteMsg::Redeem {
            orig_sender: Some(get_addr_resp.address.clone()),
            minter_address: req.minter_address.clone(),
            denom: denom.clone(),
            value: req.value.clone(),
        };
        let redeem_msg =
            serde_json::to_vec(&redeem_msg).map_err(|e| Status::invalid_argument(e.to_string()))?;

        let coin = ProtoCoin {
            denom,
            amount: req.value.to_string(),
        };

        let msg = MsgExecuteContract {
            sender: get_addr_resp.address,
            contract: config.chains.tokenfactory.tokenfactory_contract.to_string(),
            msg: redeem_msg,
            funds: vec![coin],
        }
        .build_any();

        let broadcast_tx_resp = self
            .broadcast_tx(msg, req.from_key_info.unwrap(), req.fee_info, jwt)
            .await
            .map_err(|e| Status::internal(format!("Failed to broadcast transaction: {}", e)))?;

        let tx_resp = broadcast_tx_resp
            .tx_response
            .ok_or_else(|| Status::internal("no tx response"))?;

        Ok(Response::new(RedeemResponse {
            chain: None,
            txhash: tx_resp.txhash.clone(),
            tx_status: Self::get_tx_status_response(tx_resp),
        }))
    }

    pub async fn grant_fee_basic_allowance(
        &self,
        request: Request<GrantFeeBasicAllowanceRequest>,
    ) -> Result<Response<GrantFeeBasicAllowanceResponse>, Status> {
        let config = APP.config();

        let jwt = AuthenticatedClient::<kms_proto::kms_svc_client::KmsSvcClient<Channel>>::get_jwt(
            request.metadata(),
        );

        let req = request.into_inner();

        // parse and validate denom.
        let tf_denom = TfDenom::try_from(req.allowance_denom)
            .map_err(|e| Status::invalid_argument(format!("Failed to parse denom: {}", e)))?;
        let denom = tf_denom.as_str_name().to_string();
        if denom != config.chains.tokenfactory.gas_denom {
            return Err(Status::invalid_argument(format!(
                "Invalid allowance_denom: {}, must be the same as the configured gas_denom: {}",
                denom, config.chains.tokenfactory.gas_denom
            )));
        }

        // allowance value
        let allowance_value = req
            .allowance_value
            .parse::<u128>()
            .map_err(|e| Status::invalid_argument(e.to_string()))?;
        let config_allowance_value = config
            .chains
            .tokenfactory
            .faucet
            .allowance_value
            .parse::<u128>()
            .map_err(|e| Status::invalid_argument(e.to_string()))?;
        let allowance_value = config_allowance_value.min(allowance_value);

        // hours to expire
        let hours_to_expire = config
            .chains
            .tokenfactory
            .faucet
            .hours_to_expire
            .min(req.hours_to_expire);

        // get the granter key address
        let granter_key_info = req
            .granter
            .clone()
            .ok_or_else(|| Status::invalid_argument("Missing granter key info"))?;
        let get_granter_addr_req = GetAddrRequest {
            chain: None,
            key_info: Some(granter_key_info.clone()),
        };
        let authenticated_req =
            AuthenticatedClient::<Empty>::authenticate_(get_granter_addr_req, &jwt);

        let server_blkchn = crate::server::Blkchn::new();
        let get_granter_addr_resp = server_blkchn
            .get_addr(authenticated_req)
            .await
            .map_err(|e| Status::internal(format!("Failed to get granter address: {}", e)))?
            .into_inner();

        let execute_msg = ExecuteMsg::Feegrant(FeegrantContractMsg::GrantFeeBasicAllowance {
            granter: get_granter_addr_resp.address.clone(),
            grantee: req.grantee,
            allowance_denom: denom,
            allowance_value: allowance_value.to_string(), //req.allowance_value,
            hours_to_expire,
        });

        let json_msg = serde_json::to_vec(&execute_msg)
            .map_err(|e| Status::invalid_argument(e.to_string()))?;

        let msg = MsgExecuteContract {
            sender: get_granter_addr_resp.address,
            contract: config.chains.tokenfactory.tokenfactory_contract.to_string(),
            msg: json_msg,
            funds: vec![],
        }
        .build_any();

        let broadcast_tx_resp = self
            .broadcast_tx(msg, granter_key_info, None, jwt)
            .await
            .map_err(|e| Status::internal(format!("Failed to broadcast transaction: {}", e)))?;

        let tx_resp = broadcast_tx_resp
            .tx_response
            .ok_or_else(|| Status::internal("no tx response"))?;

        Ok(Response::new(GrantFeeBasicAllowanceResponse {
            chain: req.chain,
            txhash: tx_resp.txhash.clone(),
            tx_status: Self::get_tx_status_response(tx_resp),
        }))
    }

    pub async fn get_fee_basic_allowance(
        &self,
        request: Request<GetFeeBasicAllowanceRequest>,
    ) -> Result<Response<GetFeeBasicAllowanceResponse>, Status> {
        let config = APP.config();
        let req = request.into_inner();

        let query_msg = QueryMsg::Feegrant(FeegrantQuery::FeeBasicAllowance {
            granter: config.chains.tokenfactory.faucet.address.clone(),
            grantee: req.grantee,
        });

        let cosmos_grpc_client = self.get_cosmos_grpc_client().await?;

        let resp = cosmos_grpc_client
            .query_smart_contract::<QueryMsg, FeeBasicAllowanceResponse>(
                config.chains.tokenfactory.tokenfactory_contract.clone(),
                query_msg,
            )
            .await
            .map_err(|e| Status::internal(e.to_string()))?;

        Ok(Response::new(GetFeeBasicAllowanceResponse {
            chain: req.chain,
            fee_basic_grant: Some(GetFeeBasicGrant {
                granter: resp.allowance.granter,
                grantee: resp.allowance.grantee,
                allowance_denom: resp.allowance.allowance.denom,
                allowance_value: resp.allowance.allowance.amount.to_string(),
                expiration: resp.allowance.expiration,
            }),
        }))
    }

    pub async fn get_tx_status(
        &self,
        request: Request<GetTxStatusRequest>,
    ) -> Result<Response<GetTxStatusResponse>, Status> {
        let req = request.into_inner();

        let mut cosmos_grpc_client = self.get_cosmos_grpc_client().await?;

        match cosmos_grpc_client
            .clients
            .tx
            .get_tx(GetTxRequest {
                hash: req.txhash.clone(),
            })
            .await
        {
            Ok(resp) => {
                let resp = resp.into_inner();

                let tx_resp = match resp.tx_response {
                    Some(tx_response) => tx_response,
                    None => {
                        return Err(Status::internal("no tx response"));
                    }
                };
                Ok(Response::new(GetTxStatusResponse {
                    chain: req.chain,
                    txhash: req.txhash,
                    status: Self::get_tx_status_response(tx_resp),
                }))
            }
            Err(e) => Err(Status::internal(format!("Failed to get tx status: {}", e))),
        }
    }

    pub async fn get_denom_metadata(
        &self,
        request: Request<GetDenomMetadataRequest>,
    ) -> Result<Response<GetDenomMetadataResponse>, Status> {
        let req = request.into_inner();

        let mut cosmos_grpc_client = self.get_cosmos_grpc_client().await?;

        let denom_metadata_req = QueryDenomMetadataRequest { denom: req.denom };

        let resp = cosmos_grpc_client
            .clients
            .bank
            .denom_metadata(denom_metadata_req)
            .await
            .map_err(|e| Status::internal(e.to_string()))?;
        let mut resp = resp.into_inner();

        Ok(Response::new(GetDenomMetadataResponse {
            chain: req.chain,
            metadata: resp.metadata.take().map(convert_denom_metadata),
        }))
    }

    pub async fn get_all_denom_metadata(
        &self,
        request: Request<GetAllDenomMetadataRequest>,
    ) -> Result<Response<GetAllDenomMetadataResponse>, Status> {
        let req = request.into_inner();

        let mut cosmos_grpc_client = self.get_cosmos_grpc_client().await?;

        let resp = cosmos_grpc_client
            .clients
            .bank
            .denoms_metadata(QueryDenomsMetadataRequest { pagination: None })
            .await
            .map_err(|e| Status::internal(e.to_string()))?;
        let resp = resp.into_inner();
        let metadata = resp
            .metadatas
            .into_iter()
            .map(convert_denom_metadata)
            .collect();

        Ok(Response::new(GetAllDenomMetadataResponse {
            chain: req.chain,
            denom_metadata: metadata,
        }))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use cosmos_grpc_client::cosmos_sdk_proto::cosmos::base::abci::v1beta1::TxResponse;

    #[tokio::test]
    async fn test_get_tx_status_success() {
        // This requires a running Cosmos node, so we test the helper function instead
        let tx_resp = TxResponse {
            height: 12345,
            txhash: "ABC123".to_string(),
            codespace: "bank".to_string(),
            code: 0,
            data: "".to_string(),
            raw_log: "success".to_string(),
            logs: vec![],
            info: "".to_string(),
            gas_wanted: 200000,
            gas_used: 150000,
            tx: None,
            timestamp: "2024-01-01T00:00:00Z".to_string(),
            events: vec![],
        };

        let result = Blkchn::get_tx_status_response(tx_resp);
        assert!(result.is_some());
        let status = result.unwrap();
        assert_eq!(status.code, "0");
        assert_eq!(status.codespace, "bank");
        assert_eq!(status.msg, "success");
    }

    #[tokio::test]
    async fn test_get_tx_status_error() {
        let tx_resp = TxResponse {
            height: 12345,
            txhash: "DEF456".to_string(),
            codespace: "sdk".to_string(),
            code: 5,
            data: "".to_string(),
            raw_log: "insufficient funds: 0utoken < 1000utoken".to_string(),
            logs: vec![],
            info: "".to_string(),
            gas_wanted: 200000,
            gas_used: 0,
            tx: None,
            timestamp: "2024-01-01T00:00:00Z".to_string(),
            events: vec![],
        };

        let result = Blkchn::get_tx_status_response(tx_resp);
        assert!(result.is_some());
        let status = result.unwrap();
        assert_eq!(status.code, "5");
        assert_eq!(status.codespace, "sdk");
        assert!(status.msg.contains("insufficient funds"));
    }

    #[test]
    fn test_get_error_info_non_zero_code() {
        let tx_resp = TxResponse {
            code: 32,
            codespace: "wasm".to_string(),
            raw_log: "contract execution failed".to_string(),
            ..Default::default()
        };

        let result = Blkchn::get_tx_status_response(tx_resp);
        assert!(result.is_some());
        let info = result.unwrap();
        assert_eq!(info.code, "32");
        assert_eq!(info.codespace, "wasm");
        assert_eq!(info.msg, "contract execution failed");
    }
}

#[cfg(test)]
mod denom_metadata_tests {
    use super::*;

    #[tokio::test]
    async fn test_get_denom_metadata_request_structure() {
        let req = GetDenomMetadataRequest {
            chain: Some(Chain::Tokenfactory as i32),
            denom: "factory/wfactory1/wfusd".to_string(),
        };

        // Verify request structure
        assert_eq!(req.chain, Some(Chain::Tokenfactory as i32));
        assert!(req.denom.starts_with("factory/"));
    }

    #[tokio::test]
    async fn test_get_all_denom_metadata_request_structure() {
        let req = GetAllDenomMetadataRequest {
            chain: Some(Chain::Tokenfactory as i32),
        };

        // Verify request structure
        assert_eq!(req.chain, Some(Chain::Tokenfactory as i32));
    }
}
