/*
#[allow(non_camel_case_types)]
pub enum TfDenom {
    uwfUSD,
    wSAT,
    wWEI,
}
*/
use cosmrs::AccountId;
use cosmrs::bip32::secp256k1::Secp256k1;
use crate::Result;
use prost::bytes::Bytes;
use crate::error::ErrorKind;

pub fn pk_to_address(pk: &Bytes, prefix: &String) -> Result<AccountId> {
    let pk = elliptic_curve::PublicKey::<Secp256k1>::from_sec1_bytes(&pk)
        .map_err(|e| ErrorKind::InvalidData.context(format!("Failed to parse public key from KMS server: {}", e)))?;
    let vk = ecdsa::VerifyingKey::from(pk);
    let account_id = cosmrs::crypto::PublicKey::from(vk).account_id(prefix)
        .map_err(|e| ErrorKind::InvalidData.context(format!("Failed to get address from public key: {}", e)))?;

    Ok(account_id)
}