/*
#[allow(non_camel_case_types)]
pub enum TfDenom {
    uwfUSD,
    wSAT,
    wWEI,
}
*/