#![cfg(test)]

use cosmos_grpc_client::cosmos_sdk_proto::cosmos::bank::v1beta1::{
    QueryAllBalancesRequest, QueryAllBalancesResponse, QueryDenomOwnersRequest,
    QueryDenomOwnersResponse, QueryParamsRequest, QueryParamsResponse,
    QuerySpendableBalancesRequest, QuerySpendableBalancesResponse, QuerySupplyOfRequest,
    QuerySupplyOfResponse, QueryTotalSupplyRequest, QueryTotalSupplyResponse,
};
use cosmos_grpc_client::cosmos_sdk_proto::cosmos::base::tendermint::v1beta1::{
    service_server::{Service as TmService, ServiceServer as TmServiceServer},
    AbciQueryRequest, AbciQueryResponse, GetBlockByHeightRequest, GetBlockByHeightResponse,
    GetLatestBlockRequest, GetLatestBlockResponse, GetLatestValidatorSetRequest,
    GetLatestValidatorSetResponse, GetNodeInfoRequest, GetNodeInfoResponse, GetSyncingRequest,
    GetSyncingResponse, GetValidatorSetByHeightRequest, GetValidatorSetByHeightResponse,
    VersionInfo,
};
use cosmos_grpc_client::cosmos_sdk_proto::cosmos::tx::v1beta1::{
    BroadcastTxRequest, BroadcastTxResponse, GetBlockWithTxsRequest, GetBlockWithTxsResponse,
    GetTxsEventRequest, GetTxsEventResponse, SimulateRequest, SimulateResponse,
};
use once_cell::sync::OnceCell;
use std::panic;
use tonic011 as tonic;
use tonic_health011::server::health_reporter;

static COSMOS_GRPC: OnceCell<String> = OnceCell::new();

pub fn cosmos_grpc_global() -> String {
    COSMOS_GRPC
        .get_or_init(|| {
            let std_listener = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
            std_listener.set_nonblocking(true).unwrap();
            let addr = std_listener.local_addr().unwrap();

            std::thread::spawn(move || {
                let rt = tokio::runtime::Runtime::new().unwrap();
                rt.block_on(async move {
                    use tonic011 as tonic;
                    use tonic::{Request, Response, Status};
                    use tonic::transport::Server;

                    use cosmos_grpc_client::cosmos_sdk_proto::cosmos::bank::v1beta1::{
                        query_server::{Query as BankQuery, QueryServer as BankQueryServer},
                        QueryBalanceRequest, QueryBalanceResponse,
                        QueryDenomMetadataRequest, QueryDenomMetadataResponse,
                        QueryDenomsMetadataRequest, QueryDenomsMetadataResponse,
                        Metadata, DenomUnit,
                    };
                    use cosmos_grpc_client::cosmos_sdk_proto::cosmos::tx::v1beta1::{
                        service_server::{Service as TxService, ServiceServer as TxServiceServer},
                        GetTxRequest, GetTxResponse,
                    };
                    use cosmos_grpc_client::cosmos_sdk_proto::cosmos::base::abci::v1beta1::TxResponse;

                    #[derive(Clone, Default)]
                    struct MockBank;
                    #[tonic::async_trait]
                    impl BankQuery for MockBank {
                        async fn balance(
                            &self,
                            _req: Request<QueryBalanceRequest>,
                        ) -> Result<Response<QueryBalanceResponse>, Status> {
                            Ok(Response::new(QueryBalanceResponse { balance: None }))
                        }

                        async fn all_balances(&self, _request: Request<QueryAllBalancesRequest>) -> Result<Response<QueryAllBalancesResponse>, Status> {
                            Ok(Response::new(QueryAllBalancesResponse { balances: vec![], pagination: None }))
                        }

                        async fn spendable_balances(&self, _request: Request<QuerySpendableBalancesRequest>) -> Result<Response<QuerySpendableBalancesResponse>, Status> {
                            Err(Status::unimplemented("mock spendable_balances"))
                        }

                        async fn total_supply(&self, _request: Request<QueryTotalSupplyRequest>) -> Result<Response<QueryTotalSupplyResponse>, Status> {
                            Err(Status::unimplemented("mock total_supply"))
                        }

                        async fn supply_of(&self, _request: Request<QuerySupplyOfRequest>) -> Result<Response<QuerySupplyOfResponse>, Status> {
                            Err(Status::unimplemented("mock supply_of"))
                        }

                        async fn params(&self, _request: Request<QueryParamsRequest>) -> Result<Response<QueryParamsResponse>, Status> {
                            Err(Status::unimplemented("mock params"))
                        }

                        async fn denom_metadata(
                            &self,
                            req: Request<QueryDenomMetadataRequest>,
                        ) -> Result<Response<QueryDenomMetadataResponse>, Status> {
                            let denom = req.into_inner().denom;
                            let md = Metadata {
                                description: "mock".to_string(),
                                denom_units: vec![DenomUnit { denom: denom.clone(), exponent: 0, aliases: vec![] }],
                                base: denom.clone(),
                                display: denom.clone(),
                                name: "mock".to_string(),
                                symbol: "MOCK".to_string(),
                                uri: "".to_string(),
                                uri_hash: "".to_string(),
                            };
                            Ok(Response::new(QueryDenomMetadataResponse { metadata: Some(md) }))
                        }

                        async fn denoms_metadata(
                            &self,
                            _req: Request<QueryDenomsMetadataRequest>,
                        ) -> Result<Response<QueryDenomsMetadataResponse>, Status> {
                            Ok(Response::new(QueryDenomsMetadataResponse {
                                metadatas: vec![],
                                pagination: None,
                            }))
                        }

                        async fn denom_owners(&self, _request: Request<QueryDenomOwnersRequest>) -> Result<Response<QueryDenomOwnersResponse>, Status> {
                            Err(Status::unimplemented("mock denom_owners"))
                        }
                    }

                    #[derive(Clone, Default)]
                    struct MockTx;
                    #[tonic::async_trait]
                    impl TxService for MockTx {
                        async fn simulate(&self, _request: Request<SimulateRequest>) -> Result<Response<SimulateResponse>, Status> {
                            Err(Status::unimplemented("mock simulate"))
                        }

                        async fn get_tx(
                            &self,
                            req: Request<GetTxRequest>,
                        ) -> Result<Response<GetTxResponse>, Status> {
                            let hash = req.into_inner().hash;
                            let tx_resp = TxResponse {
                                height: 1,
                                txhash: hash,
                                codespace: "bank".to_string(),
                                code: 0,
                                data: "".to_string(),
                                raw_log: "ok".to_string(),
                                logs: vec![],
                                info: "".to_string(),
                                gas_wanted: 0,
                                gas_used: 0,
                                tx: None,
                                timestamp: "".to_string(),
                                events: vec![],
                            };

                            Ok(Response::new(GetTxResponse {
                                tx: None,
                                tx_response: Some(tx_resp),
                            }))
                        }

                        async fn broadcast_tx(&self, _request: Request<BroadcastTxRequest>) -> Result<Response<BroadcastTxResponse>, Status> {
                            Err(Status::unimplemented("mock broadcast_tx"))
                        }

                        async fn get_txs_event(&self, _request: Request<GetTxsEventRequest>) -> Result<Response<GetTxsEventResponse>, Status> {
                            Err(Status::unimplemented("mock get_txs_event"))
                        }

                        async fn get_block_with_txs(&self, _request: Request<GetBlockWithTxsRequest>) -> Result<Response<GetBlockWithTxsResponse>, Status> {
                            Err(Status::unimplemented("mock get_block_with_txs"))
                        }
                    }

                    #[derive(Clone, Default)]
                    struct MockTendermint;
                    #[tonic::async_trait]
                    impl TmService for MockTendermint {
                        async fn get_node_info(
                            &self,
                            _req: Request<GetNodeInfoRequest>,
                        ) -> Result<Response<GetNodeInfoResponse>, Status> {
                            // let node = tendermint_proto::v0_34::p2p::DefaultNodeInfo {
                            //     protocol_version: None,
                            //     default_node_id: "".to_string(),
                            //     listen_addr: "".to_string(),
                            //     network: "mock-chain".to_string(),
                            //     version: "".to_string(),
                            //     channels: vec![],
                            //     moniker: "".to_string(),
                            //     other: None,
                            // };
                            // Ok(Response::new(GetNodeInfoResponse {
                            //     default_node_info: Some(node),
                            //     application_version: Some(VersionInfo {
                            //         name: "mock".to_string(),
                            //         app_name: "mock".to_string(),
                            //         version: "0.0.0".to_string(),
                            //         git_commit: "".to_string(),
                            //         build_tags: "".to_string(),
                            //         go_version: "".to_string(),
                            //         build_deps: vec![],
                            //         cosmos_sdk_version: "0.0.0".to_string(),
                            //     }),
                            // }));

                            let mut ni = tendermint_proto::v0_34::p2p::DefaultNodeInfo::default();
                            ni.network = "mock-chain".to_string();

                            Ok(Response::new(GetNodeInfoResponse {
                                default_node_info: Some(ni),
                                application_version: Some(VersionInfo::default()),
                            }))
                        }

                        async fn get_syncing(&self, _request: Request<GetSyncingRequest>) -> Result<Response<GetSyncingResponse>, Status> {
                            Err(Status::unimplemented("mock get_syncing"))
                        }

                        async fn get_latest_block(&self, _request: Request<GetLatestBlockRequest>) -> Result<Response<GetLatestBlockResponse>, Status> {
                            Err(Status::unimplemented("mock get_latest_block"))
                        }

                        async fn get_block_by_height(&self, _request: Request<GetBlockByHeightRequest>) -> Result<Response<GetBlockByHeightResponse>, Status> {
                            Err(Status::unimplemented("mock get_block_by_height"))
                        }

                        async fn get_latest_validator_set(&self, _request: Request<GetLatestValidatorSetRequest>) -> Result<Response<GetLatestValidatorSetResponse>, Status> {
                            Err(Status::unimplemented("mock get_latest_validator_set"))
                        }

                        async fn get_validator_set_by_height(&self, _request: Request<GetValidatorSetByHeightRequest>) -> Result<Response<GetValidatorSetByHeightResponse>, Status> {
                            Err(Status::unimplemented("mock get_validator_set_by_height"))
                        }

                        async fn abci_query(&self, _request: Request<AbciQueryRequest>) -> Result<Response<AbciQueryResponse>, Status> {
                            Err(Status::unimplemented("mock abci_query"))
                        }
                    }


                    let (mut reporter, health_svc) = health_reporter();

                    // Mark services as serving (optional but recommended)
                    reporter
                        .set_serving::<BankQueryServer<MockBank>>()
                        .await;
                    reporter
                        .set_serving::<TxServiceServer<MockTx>>()
                        .await;

                    let listener = tokio::net::TcpListener::from_std(std_listener).unwrap();
                    let incoming = tokio_stream::wrappers::TcpListenerStream::new(listener);

                    Server::builder()
                        .add_service(TmServiceServer::new(MockTendermint::default()))
                        .add_service(health_svc)
                        .add_service(BankQueryServer::new(MockBank::default()))
                        .add_service(TxServiceServer::new(MockTx::default()))
                        .serve_with_incoming(incoming)
                        .await
                        .unwrap();
                });
            });

            format!("127.0.0.1:{}", addr.port())
        })
        .clone()
}

pub async fn wait_for_tcp(addr: &str) {
    use std::time::Duration;
    for _ in 0..200 {
        if tokio::net::TcpStream::connect(addr).await.is_ok() {
            return;
        }
        tokio::time::sleep(Duration::from_millis(10)).await;
    }
    panic!("cosmos mock never became reachable at {addr}");
}
