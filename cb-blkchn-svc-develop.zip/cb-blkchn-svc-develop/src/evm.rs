use alloy::sol;

pub mod blkchn;
pub mod types;

sol!(
    #[sol(rpc)]
    IERC20,
    "src/evm/DepositTokenV3.json",
);
