use alloy::sol;

pub mod types;
pub mod blkchn;

sol!(
   #[sol(rpc)]
   IERC20,
   "src/evm/DepositTokenV3.json",
);
