use alloy::sol;

pub mod types;
pub mod blkchn;

sol!(
   #[sol(rpc)]
   IERC20,
   "/Users/johnz/Project/solidity/cb-solidity/out/DepositTokenV3.sol/DepositTokenV3.json",
);