use cosmrs::bip32::secp256k1::ecdsa::signature::Keypair;
use cosmrs::bip32::secp256k1::Secp256k1;
use ecdsa::{Signature};
use kms_commom::async_signer::AsyncSigner;
use kms_commom::SignatureError;
use prost::bytes::Bytes;
use tonic::async_trait;
use tonic::transport::Channel;
use crate::{kms_proto};
use crate::authenticated_client::AuthenticatedClient;
use crate::error::ErrorKind;
use crate::proto::{KeyType};
use crate::Result;

pub struct KmsSigner {
    kms_grpc: String,
    kms_provider_uuid: String,
    key_name: String,
    key_type: KeyType,
    vk: ecdsa::VerifyingKey<Secp256k1>,
    jwt: Option<String>,
}

impl KmsSigner {
    pub async fn new(kms_grpc: String, kms_provider_uuid: String, key_name: String, key_type: KeyType, jwt: Option<String>) -> Result<Self> {
        let uri = format!("http://{}", &kms_grpc);

        let kms_client = kms_proto::kms_svc_client::KmsSvcClient::connect(uri)
            .await
            .map_err(|e| ErrorKind::Io.context(format!("Failed to connect to KMS server {}", e.to_string())))?;

        let mut kms_client: AuthenticatedClient<kms_proto::kms_svc_client::KmsSvcClient<Channel>> = AuthenticatedClient::new(kms_client, jwt.clone());

/*
        let channel = tonic::transport::Endpoint::new(uri)?.connect().await?;

        let kms_client = kms_proto::kms_svc_client::KmsSvcClient::connect(channel)
            .await
            .map_err(|e| ErrorKind::Io.context(format!("Failed to connect to KMS server {}", e.to_string())))?;
*/
/*
        let interceptor = interceptor::JwtInterceptor::new("your_jwt_token_here".to_string());

        let mut kms_client = kms_proto::kms_svc_client::KmsSvcClient::with_interceptor(channel, interceptor)
        // let mut kms_client = kms_proto::kms_svc_client::KmsSvcClient::connect(uri)
            .await
            .map_err(|e| ErrorKind::Io.context(format!("Failed to connect to KMS server {}", e.to_string())))?;
*/
        match key_type {
            KeyType::Secp256k1 => {},
            _ => return Err(ErrorKind::InvalidData.context("Invalid key type").into()),
        }

        let kms_req = kms_proto::GetPubKeyRequest {
            header: Some(kms_proto::Header {
                uuid: kms_provider_uuid.clone(),
                app_name: "blkchn_svc".to_string(),
            }),
            key_name: key_name.clone(),
            attributes: Some(kms_proto::KeyAttributes {
                key_type: key_type.into(),
            }),
        };
        let kms_req = kms_client.authenticate(kms_req);

        let kms_resp = kms_client.get_pub_key(kms_req).await
            .map_err(|e| ErrorKind::KmsSvcError.context(format!("Failed to get public key from KMS server: {}", e)))?.into_inner();

        let pk = elliptic_curve::PublicKey::<Secp256k1>::from_sec1_bytes(&kms_resp.pub_key)
            .map_err(|e| ErrorKind::InvalidData.context(format!("Failed to parse public key from KMS server: {}", e)))?;
        let vk = ecdsa::VerifyingKey::from(&pk);

        Ok(Self {
            kms_grpc,
            kms_provider_uuid,
            key_name,
            key_type,
            vk,
            jwt,
        })
    }

    ///
    pub async fn get_authenticated_client(&self) -> Result<AuthenticatedClient<kms_proto::kms_svc_client::KmsSvcClient<Channel>>> {
        let uri = format!("http://{}", &self.kms_grpc);

        let kms_client = kms_proto::kms_svc_client::KmsSvcClient::connect(uri)
            .await
            .map_err(|e| ErrorKind::Io.context(format!("Failed to connect to KMS server {}", e.to_string())))?;

        Ok(AuthenticatedClient::new(kms_client, self.jwt.clone()))
    }
}

impl Keypair for KmsSigner {
    type VerifyingKey = ecdsa::VerifyingKey<Secp256k1>;

    fn verifying_key(&self) -> Self::VerifyingKey {
        self.vk
    }
}

#[async_trait]
impl AsyncSigner<Secp256k1, Signature<Secp256k1>>  for KmsSigner {
    async fn try_sign(&self, msg: &[u8]) -> anyhow::Result<Signature<Secp256k1>, SignatureError> {
        // let uri = format!("http://{}", &self.kms_grpc);

        // let mut kms_client = kms_proto::kms_svc_client::KmsSvcClient::connect(uri)
        //     .await
        //     .map_err(|e| SignatureError::from_source(e))?;

        let mut kms_client = self.get_authenticated_client().await
            .map_err(|e| SignatureError::from_source(e))?;

        let kms_req = kms_proto::SignMsgRequest {
            header: Some(kms_proto::Header {
                uuid: self.kms_provider_uuid.clone(),
                app_name: "blkchn_svc".to_string(),
            }),
            key_name: self.key_name.clone(),
            attributes: Some(kms_proto::KeyAttributes {
                key_type: self.key_type.into(),
            }),
            msg: Bytes::from(msg.to_vec()),
        };
        let kms_req = kms_client.authenticate(kms_req);

        let kms_resp = kms_client.sign_msg(kms_req).await
            .map_err(|e| SignatureError::from_source(e))?.into_inner();

        let sig = Signature::<Secp256k1>::from_slice(&kms_resp.sig)?;

        Ok(sig)
    }

    async fn try_sign_prehash(&self, msg_hash: [u8; 32]) -> anyhow::Result<Signature<Secp256k1>, SignatureError> {
        // let uri = format!("http://{}", &self.kms_grpc);
        //
        // let mut kms_client = kms_proto::kms_svc_client::KmsSvcClient::connect(uri)
        //     .await
        //     .map_err(|e| SignatureError::from_source(e))?;

        let mut kms_client = self.get_authenticated_client().await
            .map_err(|e| SignatureError::from_source(e))?;

        let kms_req = kms_proto::SignPrehashRequest {
            header: Some(kms_proto::Header {
                uuid: self.kms_provider_uuid.clone(),
                app_name: "blkchn_svc".to_string(),
            }),
            key_name: self.key_name.clone(),
            attributes: Some(kms_proto::KeyAttributes {
                key_type: self.key_type.into(),
            }),
            hash: Bytes::from(msg_hash.to_vec()),
        };
        let kms_req = kms_client.authenticate(kms_req);

        let kms_resp = kms_client.sign_prehash(kms_req).await
            .map_err(|e| SignatureError::from_source(e))?.into_inner();

        let sig = Signature::<Secp256k1>::from_slice(&kms_resp.sig)?;

        Ok(sig)
    }
}

mod interceptor {
    use tonic::{Request, Status};
    use tonic::metadata::MetadataValue;
    use tonic::service::Interceptor;

    #[derive(Debug, Clone)]
    pub struct JwtInterceptor {
        token: String,
    }

    impl JwtInterceptor {
        pub fn new(token: String) -> Self {
            Self { token }
        }
    }

    impl Interceptor for JwtInterceptor {
        fn call(&mut self, mut req: Request<()>) -> Result<Request<()>, Status> {
            // Intercept the request and perform any necessary logic
            println!("Inside JwtInterceptor - Intercepted request: extensions {:?}; metadata {:?}", req.extensions(), req.metadata());

            // You can modify the request here if needed
            let token: MetadataValue<_> = format!("Bearer {}", self.token)
                .parse()
                .map_err(|e| Status::unauthenticated("Unable to parse jwt token"))?;

            req.metadata_mut().insert("authorization", token);

            Ok(req)
        }
    }
}
