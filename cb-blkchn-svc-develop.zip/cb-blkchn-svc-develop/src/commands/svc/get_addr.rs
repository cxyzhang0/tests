use crate::application::APP;
use crate::prelude::{Command, Runnable};
use crate::proto::{GetAddrRequest, KeyInfo};
use crate::server::Blkchn;
use abscissa_core::status_err;
use abscissa_core::tracing::info;
use blkchn_svc_proto::blkchn_svc_v1::blkchn_svc_server::BlkchnSvc;
use tonic::Request;

#[derive(clap::Parser, Command, Debug)]
pub struct GetAddrCmd {
    /// chain id as defined in proto
    #[clap(short = 'c', long = "chain")]
    chain: i32,
    /// kms provider UUID, part of KeyInfo
    #[clap(short = 'p', long = "provider")]
    kms_provider_uuid: String,
    /// key type as defined in proto, part of KeyInfo
    #[clap(short = 't', long = "kt")]
    key_type: i32,
    /// key name, part of KeyInfo
    #[clap(short = 'n', long = "kn")]
    key_name: String,
}

impl Runnable for GetAddrCmd {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = Blkchn::new();

            let req = Request::new(GetAddrRequest {
                chain: Some(self.chain),
                key_info: Some(KeyInfo {
                    kms_provider_uuid: self.kms_provider_uuid.clone(),
                    key_type: self.key_type,
                    key_name: self.key_name.clone(),
                }),
            });

            match svc.get_addr(req).await {
                Ok(resp) => {
                    let resp = resp.into_inner();
                    info!("***** address: {}", resp.address);
                }
                Err(e) => {
                    status_err!("failed to get address: {}", e);
                    std::process::exit(1);
                }
            }
        });
    }
}
