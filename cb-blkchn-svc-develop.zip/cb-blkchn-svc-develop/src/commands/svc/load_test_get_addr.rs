use crate::application::APP;
use crate::prelude::{Command, Runnable};
use crate::proto::{blkchn_svc_server::BlkchnSvc, Chain, GetAddrRequest, KeyInfo};
use crate::server::Blkchn;
use abscissa_core::status_err;
use abscissa_core::tracing::info;
use abscissa_tokio::tokio::sync::Semaphore;
use futures::future::join_all;
use std::sync::Arc;
use tonic::Request;

#[derive(clap::Parser, Command, Debug)]
pub struct LoadTestGetAddrCmd {
    /// kms provider UUID, part of KeyInfo
    #[clap(short = 'p', long = "provider")]
    kms_provider_uuid: String,
    /// key type as defined in proto, part of KeyInfo
    #[clap(short = 't', long = "kt")]
    key_type: i32,
    /// key name, part of KeyInfo
    #[clap(short = 'n', long = "kn")]
    key_name: String,
    /// load
    #[clap(short = 'l', long = "load", default_value = "175")]
    load: usize,
    /// max concurrency
    #[clap(short = 'm', long = "mc", default_value = "100")]
    max_concurrency: usize,
}

impl Runnable for LoadTestGetAddrCmd {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = Blkchn::new();

            let chains = [Chain::Tokenfactory, Chain::Ethereum, Chain::Base];

            let semaphore = Arc::new(Semaphore::new(self.max_concurrency)); // Limit to 32 concurrent requests

            let futures = (0..self.load).map(|i| {
                let svc = svc.clone();
                let j = i % chains.len();
                let chain: i32 = chains[j].into();
                let req = Request::new(GetAddrRequest {
                    chain: Some(chain),
                    key_info: Some(KeyInfo {
                        kms_provider_uuid: self.kms_provider_uuid.clone(),
                        key_type: self.key_type,
                        key_name: self.key_name.clone(),
                    }),
                });

                let permit = semaphore.clone().acquire_owned();
                async move {
                    let _permit = permit.await;
                    match svc.get_addr(req).await {
                        Ok(resp) => {
                            let resp = resp.into_inner();
                            info!("***** {i}th address on {chain}: {}", resp.address);
                        }
                        Err(e) => {
                            status_err!("failed to get {i}th address on {chain}: {}", e);
                            // std::process::exit(1);
                        }
                    }
                }
            });

            join_all(futures).await;
        });
    }
}
