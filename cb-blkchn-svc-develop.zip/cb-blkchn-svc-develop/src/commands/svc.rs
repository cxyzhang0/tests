mod get_addr;
mod load_test_get_addr;

use crate::commands::svc::get_addr::GetAddrCmd;
use crate::commands::svc::load_test_get_addr::LoadTestGetAddrCmd;
use crate::prelude::{Command, Runnable};

/// The `svc` subcommand
/// cli for the grpc endpoints
#[derive(clap::Parser, Command, Debug, Runnable)]
pub enum SvcCmd {
    /// The `get-addr` subcommand'
    GetAddr(GetAddrCmd),
    /// The `load-test-get-addr` subcommand'
    LoadTestGetAddr(LoadTestGetAddrCmd),
}
