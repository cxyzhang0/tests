//! `start` subcommand - example of how to write a subcommand

/// App-local prelude includes `app_reader()`/`app_writer()`/`app_config()`
/// accessors along with logging macros. Customize as you see fit.
use crate::prelude::*;
use crate::config::CbBlkchnSvcConfig;
use abscissa_core::{config, Command, FrameworkError, Runnable};
use std::net::SocketAddr;
use tower::ServiceBuilder;
use crate::proto::blkchn_svc_server::BlkchnSvcServer;

/// `start` subcommand
///
/// The `Parser` proc macro generates an option parser based on the struct
/// definition, and is defined in the `clap` crate. See their documentation
/// for a more comprehensive example:
///
/// <https://docs.rs/clap/>
#[derive(clap::Parser, Command, Debug)]
pub struct StartCmd {
    /// To whom are we saying hello?
    recipient: Vec<String>,
}

impl Runnable for StartCmd {
    /// Start the application.
    fn run(&self) {
        let blkchn = crate::server::Blkchn::default();
        let _ = abscissa_tokio::run(&APP, async {
            let config = APP.config();
            let addr: SocketAddr = config.blkchn_server.grpc.parse().unwrap();
            info!("Starting BlkchnSvc on {}", addr.clone().to_string());

            if crate::oauth2_resource_server::AuthZServer::is_authz_server_enabled() {
                let authz_server = crate::oauth2_resource_server::AuthZServer::get_authz_server()
                    .await
                    .unwrap_or_else(|e| {
                        error!("Failed to get authz server: {}", e);
                        std::process::exit(1);
                    });
                let layer = ServiceBuilder::new()
                    .layer(authz_server.into_layer())
                    .into_inner();

                tonic::transport::Server::builder()
                    .layer(layer)
                    .add_service(BlkchnSvcServer::new(blkchn))
                    .serve(addr)
                    .await
                    .unwrap();
            } else {
                tonic::transport::Server::builder()
                    .add_service(BlkchnSvcServer::new(blkchn))
                    .serve(addr)
                    .await
                    .unwrap();
            }

            // this is not reachable
            info!("BlkchnSvc started on {}", addr.to_string())
        });
    }
}

impl config::Override<CbBlkchnSvcConfig> for StartCmd {
    // Process the given command line options, overriding settings from
    // a configuration file using explicit flags taken from command-line
    // arguments.
    fn override_config(
        &self,
        config: CbBlkchnSvcConfig,
    ) -> Result<CbBlkchnSvcConfig, FrameworkError> {
        if !self.recipient.is_empty() {
            // config.hello.recipient = self.recipient.join(" ");
        }

        Ok(config)
    }
}
