use std::str::FromStr;
use abscissa_core::Application;
use cosmos_grpc_client::{BroadcastMode, CoinType, Decimal, GrpcClient, ProstMsgNameToAny};
use cosmos_grpc_client::cosmos_sdk_proto::cosmos::bank::v1beta1::MsgSend;
use cosmrs::bip32::secp256k1::Secp256k1;
use cosmrs::Denom;
use cosmrs::proto::cosmos::bank::v1beta1::QueryBalanceRequest;
use kms_commom::async_signer::AsyncSigningKey;
use tonic::{async_trait, Request, Response, Status};
use blkchn_svc_proto::blkchn_svc_v1::TfDenom;
use crate::{kms_proto, proto, signer};
use crate::proto::{GetAddrRequest, GetAddrResponse, GetBalanceRequest, GetBalanceResponse, SendRequest, SendResponse};
use crate::application::APP;
use crate::proto::blkchn_svc_server::BlkchnSvc;

/// The concrete BlkchnSvc implementation
#[derive(Debug, Default)]
pub struct Blkchn {}

#[async_trait]
impl BlkchnSvc for Blkchn {
    async fn get_addr(&self, request: Request<GetAddrRequest>) -> Result<Response<GetAddrResponse>, Status> {
        let config = APP.config();
        let req = request.into_inner();

        let uri = format!("http://{}", &config.kms_server.grpc);
        let mut kms_client = kms_proto::kms_svc_client::KmsSvcClient::connect(uri).await
            .map_err(|e| Status::unavailable(format!("Failed to connect to KMS server: {}", e)))?;

        let key_info = req.key_info.ok_or_else(|| Status::invalid_argument("Missing key info"))?;
        let key_type = proto::KeyType::try_from(key_info.key_type).map_err(|e| Status::invalid_argument(format!("Failed to parse key type: {}", e)))?;

        match key_type {
            proto::KeyType::Secp256k1 => {},
            _ => return Err(Status::invalid_argument("Invalid key type")),
        }

        let kms_req = kms_proto::GetPubKeyRequest {
            header: Some(kms_proto::Header {
                uuid: key_info.kms_provider_uuid.to_string(),
                app_name: "blkchn_svc".to_string(),
            }),
            key_name: key_info.key_name,
            attributes: Some(kms_proto::KeyAttributes {
                key_type: key_info.key_type,
            }),
        };

        let kms_resp = kms_client.get_pub_key(kms_req).await
            .map_err(|e| Status::internal(format!("Failed to get public key from KMS server: {}", e)))?.into_inner();

        let pk = elliptic_curve::PublicKey::<Secp256k1>::from_sec1_bytes(&kms_resp.pub_key)
            .map_err(|e| Status::internal(format!("Failed to parse public key from KMS server: {}", e)))?;
        let vk = ecdsa::VerifyingKey::from(&pk);
        let addr = cosmrs::crypto::PublicKey::from(vk).account_id(&config.chains.tokenfactory.prefix)
            .map_err(|e| Status::internal(format!("Failed to get address from public key: {}", e)))?;

        Ok(Response::new(GetAddrResponse {
            address: addr.to_string(),
        }))
    }

    async fn get_balance(&self, request: Request<GetBalanceRequest>) -> Result<Response<GetBalanceResponse>, Status> {
        let config = APP.config();
        let req = request.into_inner();

        let tf_denom = TfDenom::try_from(req.denom)
            .map_err(|e| Status::invalid_argument(format!("Failed to parse denom: {}", e)))?;

        let mut cosmos_grpc_client = GrpcClient::new(config.chains.tokenfactory.grpc.clone().leak())
            .await
            .map_err(|e| Status::unavailable(format!("Failed to connect to Cosmos gRPC server: {}", e)))?;

        let bal_req = QueryBalanceRequest {
            address: req.address,
            denom: tf_denom.as_str_name().to_string(),
        };

        let resp = cosmos_grpc_client
            .clients
            .bank
            .balance(bal_req)
            .await
            .map_err(|e| Status::internal(e.to_string()))?;
        let resp = resp.into_inner();

        let (denom, value) = match resp.balance {
            Some(balance) => (balance.denom, balance.amount),
            None => ("bank balance unavailable".to_string(), "bank balance unavailable".to_string()),
        };

        let tf_denom = TfDenom::from_str_name(&denom).ok_or_else(|| Status::internal("Failed to parse denom"))?;

        Ok(Response::new(GetBalanceResponse {
            denom: tf_denom as i32,
            value,
        }))
    }

    async fn send(&self, request: Request<SendRequest>) -> Result<Response<SendResponse>, Status> {
        let config = APP.config();
        let req = request.into_inner();

        let tf_denom = TfDenom::try_from(req.denom)
            .map_err(|e| Status::invalid_argument(format!("Failed to parse denom: {}", e)))?;

        // signer
        let from_key_info = req.from_key_info
            .ok_or_else(|| Status::invalid_argument("Missing sender key info"))?;
        let signer = signer::KmsSigner::new(
            config.kms_server.grpc.clone(),
            from_key_info.kms_provider_uuid,
            from_key_info.key_name,
            proto::KeyType::try_from(from_key_info.key_type).unwrap(),
        ).await
            .map_err(|e| Status::internal(format!("Failed to create signer: {}", e)))?;

        // cosmos gRPC client
        let cosmos_grpc_client = GrpcClient::new(config.chains.tokenfactory.grpc.clone().leak())
            .await
            .map_err(|e| Status::unavailable(format!("Failed to connect to Cosmos gRPC server: {}", e)))?;

        // wallet
        let mut wallet = cosmos_wallet::cosmos_async_wallet::Wallet::from_async_signing_key(
            cosmos_grpc_client,
            AsyncSigningKey::new(Box::new(signer)),
            &config.chains.tokenfactory.prefix,
            CoinType::Cosmos,
            config.chains.tokenfactory.gas_price.parse().unwrap(),
            config.chains.tokenfactory.gas_adjustment.parse().unwrap(),
            config.chains.tokenfactory.gas_denom.clone(),
        ).await
            .map_err(|e| Status::unavailable(format!("cosmos client connection error {}", e)))?;

        // send message
        let msg = MsgSend {
            from_address: wallet.account_address(),
            to_address: req.to_address,
            amount: vec![cosmos_grpc_client::cosmos_sdk_proto::cosmos::base::v1beta1::Coin {
                denom: tf_denom.as_str_name().to_string(),
                amount: req.value,
            }],
        }.build_any();

        let sim = wallet
            .simulate_tx(vec![msg.clone()])
            .await
            .map_err(|e| Status::internal(format!("simulation error {}", e)))?;

        let gas_used = Decimal::from_str(&sim.gas_info.unwrap().gas_used.to_string()).unwrap();
        let fee = cosmrs::tx::Fee {
            amount: vec![cosmrs::Coin {
                denom: Denom::from_str(&config.chains.tokenfactory.gas_denom).unwrap(),
                amount: Decimal::one().to_uint_ceil().u128(),
            }],
            gas_limit: (gas_used * Decimal::from_str(&config.chains.tokenfactory.gas_adjustment).unwrap() - Decimal::one())
                .to_uint_ceil()
                .u128() as u64,
            payer: None,
            granter: Some(cosmrs::AccountId::from_str(&config.chains.tokenfactory.faucet.address.to_string()).unwrap()),
        };

        let response = wallet
            .broadcast_tx(
                vec![msg],           // Vec<Any>: list of msgs to broadcast
                Some(fee), //None, // fee: Option<Fee>, if not provided the tx is simulated to calculate the fee
                None,      // memo: Option<String>
                BroadcastMode::Sync, // Broadcast mode; Block/Sync/Async
            )
            .await
            .map_err(|e| Status::internal(e.to_string()))?;

        let tx_response = response.tx_response
            .ok_or_else(|| Status::internal("no tx response"))?;

        Ok(Response::new(SendResponse {
            txhash: tx_response.txhash,
        }))
    }
}