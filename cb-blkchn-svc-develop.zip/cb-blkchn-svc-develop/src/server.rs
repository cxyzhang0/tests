use std::io::Empty;
use std::str::FromStr;
use abscissa_core::Application;
use cosmos_grpc_client::{BroadcastMode, CoinType, Decimal, GrpcClient, ProstMsgNameToAny};
use cosmos_grpc_client::cosmos_sdk_proto::Any;
use cosmos_grpc_client::cosmos_sdk_proto::cosmos::{
    bank::v1beta1::MsgSend, base::v1beta1::Coin as ProtoCoin,
};
use cosmrs::bip32::secp256k1::Secp256k1;
use cosmrs::Denom;
use cosmrs::proto::cosmos::bank::v1beta1::QueryBalanceRequest;
use cosmrs::proto::cosmos::tx::v1beta1::BroadcastTxResponse;
use cosmrs::proto::cosmwasm::wasm::v1::MsgExecuteContract;
use kms_commom::async_signer::AsyncSigningKey;
use tokenfactory::msg::{ExecuteMsg, TokenfactoryContractMsg};
use tonic::{async_trait, Request, Response, Status};
use tonic::transport::Channel;
use crate::{kms_proto, proto, signer};
use crate::proto::{KeyInfo, RedeemRequest, RedeemResponse, MintRequest, MintResponse, TfDenom, GetAddrRequest, GetAddrResponse, GetBalanceRequest, GetBalanceResponse, SendRequest, SendResponse};
use crate::application::APP;
use crate::authenticated_client::AuthenticatedClient;
use crate::proto::blkchn_svc_server::BlkchnSvc;

/// The concrete BlkchnSvc implementation
#[derive(Debug, Default)]
pub struct Blkchn {}

impl Blkchn {
    /// Create a new instance of Blkchn
    pub fn new() -> Self {
        Blkchn {}
    }

    // it does not do much, so we can comment it out for now
    /*
    pub(crate) async fn broadcast_cw_tx(
        &self,
        contract: String,
        msg: Vec<u8>,
        coin: Option<ProtoCoin>,
        siger_key_info: KeyInfo,
        signer_address: String,
        jwt: Option<String>,
    ) -> Result<BroadcastTxResponse, Status> {
        let config = APP.config();

        let msg = MsgExecuteContract {
            sender: signer_address,
            contract: contract,
            msg,
            funds: coin.map_or(vec![], |c| vec![c]),
        }.build_any();

        self.broadcast_tx(msg, siger_key_info, jwt).await
    }
*/

    pub(crate) async fn broadcast_tx(
        &self,
        msg: Any,
        siger_key_info: KeyInfo,
        jwt: Option<String>
    ) -> Result<BroadcastTxResponse, Status> {
        let config = APP.config();

        let signer = signer::KmsSigner::new(
            config.kms_server.grpc.clone(),
            siger_key_info.kms_provider_uuid,
            siger_key_info.key_name,
            proto::KeyType::try_from(siger_key_info.key_type).unwrap(),
            jwt,
        ).await
            .map_err(|e| Status::internal(format!("Failed to create signer: {}", e)))?;

        let cosmos_grpc_client = GrpcClient::new(config.chains.tokenfactory.grpc.clone().leak())
            .await
            .map_err(|e| Status::unavailable(format!("Failed to connect to Cosmos gRPC server: {}", e)))?;

        // wallet
        let mut wallet = cosmos_wallet::cosmos_async_wallet::Wallet::from_async_signing_key(
            cosmos_grpc_client,
            AsyncSigningKey::new(Box::new(signer)),
            &config.chains.tokenfactory.prefix,
            CoinType::Cosmos,
            config.chains.tokenfactory.gas_price.parse().unwrap(),
            config.chains.tokenfactory.gas_adjustment.parse().unwrap(),
            config.chains.tokenfactory.gas_denom.clone(),
        ).await
            .map_err(|e| Status::unavailable(format!("cosmos client connection error {}", e)))?;

        let sim = wallet
            .simulate_tx(vec![msg.clone()])
            .await
            .map_err(|e| Status::internal(format!("simulation error {}", e)))?;

        let gas_used = Decimal::from_str(&sim.gas_info.unwrap().gas_used.to_string()).unwrap();
        let fee = cosmrs::tx::Fee {
            amount: vec![cosmrs::Coin {
                denom: Denom::from_str(&config.chains.tokenfactory.gas_denom).unwrap(),
                amount: Decimal::one().to_uint_ceil().u128(),
            }],
            gas_limit: (gas_used * Decimal::from_str(&config.chains.tokenfactory.gas_adjustment).unwrap() - Decimal::one())
                .to_uint_ceil()
                .u128() as u64,
            payer: None,
            granter: Some(cosmrs::AccountId::from_str(&config.chains.tokenfactory.faucet.address.to_string()).unwrap()),
        };

        let response = wallet
            .broadcast_tx(
                vec![msg],           // Vec<Any>: list of msgs to broadcast
                Some(fee), //None, // fee: Option<Fee>, if not provided the tx is simulated to calculate the fee
                None,      // memo: Option<String>
                BroadcastMode::Sync, // Broadcast mode; Block/Sync/Async
            )
            .await
            .map_err(|e| Status::internal(e.to_string()))?;

        Ok(response)
    }

}
#[async_trait]
impl BlkchnSvc for Blkchn {
    async fn get_addr(&self, request: Request<GetAddrRequest>) -> Result<Response<GetAddrResponse>, Status> {
        let config = APP.config();

        let jwt = AuthenticatedClient::<kms_proto::kms_svc_client::KmsSvcClient<Channel>>::get_jwt(&request.metadata());

        let req = request.into_inner();

        // let uri = format!("http://{}", &config.kms_server.grpc);
        // let mut kms_client = kms_proto::kms_svc_client::KmsSvcClient::connect(uri).await
        //     .map_err(|e| Status::unavailable(format!("Failed to connect to KMS server: {}", e)))?;

        let key_info = req.key_info.ok_or_else(|| Status::invalid_argument("Missing key info"))?;
        let key_type = proto::KeyType::try_from(key_info.key_type).map_err(|e| Status::invalid_argument(format!("Failed to parse key type: {}", e)))?;

        match key_type {
            proto::KeyType::Secp256k1 => {},
            _ => return Err(Status::invalid_argument("Invalid key type")),
        }

        let signer = signer::KmsSigner::new(
            config.kms_server.grpc.clone(),
            key_info.kms_provider_uuid.clone(),
            key_info.key_name.clone(),
            proto::KeyType::try_from(key_type).unwrap(),
            jwt,
        ).await
            .map_err(|e| Status::internal(format!("Failed to create signer: {}", e)))?;

        let mut kms_client = signer.get_authenticated_client().await
            .map_err(|e| Status::internal(format!("Failed to get authenticated_client: {}", e)))?;

        let kms_req = kms_proto::GetPubKeyRequest {
            header: Some(kms_proto::Header {
                uuid: key_info.kms_provider_uuid.to_string(),
                app_name: "blkchn_svc".to_string(),
            }),
            key_name: key_info.key_name,
            attributes: Some(kms_proto::KeyAttributes {
                key_type: key_info.key_type,
            }),
        };
        let kms_req = kms_client.authenticate(kms_req);

        let kms_resp = kms_client.get_pub_key(kms_req).await
            .map_err(|e| Status::internal(format!("Failed to get public key from KMS server: {}", e)))?.into_inner();

        let pk = elliptic_curve::PublicKey::<Secp256k1>::from_sec1_bytes(&kms_resp.pub_key)
            .map_err(|e| Status::internal(format!("Failed to parse public key from KMS server: {}", e)))?;
        let vk = ecdsa::VerifyingKey::from(&pk);
        let addr = cosmrs::crypto::PublicKey::from(vk).account_id(&config.chains.tokenfactory.prefix)
            .map_err(|e| Status::internal(format!("Failed to get address from public key: {}", e)))?;

        Ok(Response::new(GetAddrResponse {
            address: addr.to_string(),
        }))
    }

    async fn get_balance(&self, request: Request<GetBalanceRequest>) -> Result<Response<GetBalanceResponse>, Status> {
        let config = APP.config();
        let req = request.into_inner();

        let tf_denom = TfDenom::try_from(req.denom)
            .map_err(|e| Status::invalid_argument(format!("Failed to parse denom: {}", e)))?;

        let mut cosmos_grpc_client = GrpcClient::new(config.chains.tokenfactory.grpc.clone().leak())
            .await
            .map_err(|e| Status::unavailable(format!("Failed to connect to Cosmos gRPC server: {}", e)))?;

        let bal_req = QueryBalanceRequest {
            address: req.address,
            denom: tf_denom.as_str_name().to_string(),
        };

        let resp = cosmos_grpc_client
            .clients
            .bank
            .balance(bal_req)
            .await
            .map_err(|e| Status::internal(e.to_string()))?;
        let resp = resp.into_inner();

        let (denom, value) = match resp.balance {
            Some(balance) => (balance.denom, balance.amount),
            None => ("bank balance unavailable".to_string(), "bank balance unavailable".to_string()),
        };

        let tf_denom = TfDenom::from_str_name(&denom).ok_or_else(|| Status::internal("Failed to parse denom"))?;

        Ok(Response::new(GetBalanceResponse {
            denom: tf_denom as i32,
            value,
        }))
    }

    async fn send(&self, request: Request<SendRequest>) -> Result<Response<SendResponse>, Status> {
        let _config = APP.config();

        let jwt = AuthenticatedClient::<kms_proto::kms_svc_client::KmsSvcClient<Channel>>::get_jwt(&request.metadata());

        let req = request.into_inner();

        let tf_denom = TfDenom::try_from(req.denom)
            .map_err(|e| Status::invalid_argument(format!("Failed to parse denom: {}", e)))?;
        let denom = tf_denom.as_str_name().to_string();

        // get the signer key address
        let get_addr_req = GetAddrRequest {
            key_info: Some(req.from_key_info.clone().ok_or_else(|| Status::invalid_argument("Missing sender key info"))?),
        };
        let authenticated_req = AuthenticatedClient::<Empty>::authenticate_(get_addr_req, &jwt);
        // let authenticated_req = AuthenticatedClient::<kms_proto::kms_svc_client::KmsSvcClient<Channel>>::authenticate_(get_addr_req, &jwt);

        let get_addr_resp = self.get_addr(authenticated_req).await
            .map_err(|e| Status::internal(format!("Failed to get address: {}", e)))?.into_inner();

        // send message
        let msg = MsgSend {
            from_address: get_addr_resp.address,
            to_address: req.to_address,
            amount: vec![cosmos_grpc_client::cosmos_sdk_proto::cosmos::base::v1beta1::Coin {
                denom,
                amount: req.value,
            }],
        }.build_any();

        let broadcast_tx_resp = self.broadcast_tx(msg, req.from_key_info.unwrap(), jwt).await
            .map_err(|e| Status::internal(format!("Failed to broadcast transaction: {}", e)))?;
/*
        // signer
        let from_key_info = req.from_key_info
            .ok_or_else(|| Status::invalid_argument("Missing sender key info"))?;
        let signer = signer::KmsSigner::new(
            config.kms_server.grpc.clone(),
            from_key_info.kms_provider_uuid,
            from_key_info.key_name,
            proto::KeyType::try_from(from_key_info.key_type).unwrap(),
            jwt,
        ).await
            .map_err(|e| Status::internal(format!("Failed to create signer: {}", e)))?;

        // cosmos gRPC client
        let cosmos_grpc_client = GrpcClient::new(config.chains.tokenfactory.grpc.clone().leak())
            .await
            .map_err(|e| Status::unavailable(format!("Failed to connect to Cosmos gRPC server: {}", e)))?;

        // wallet
        let mut wallet = cosmos_wallet::cosmos_async_wallet::Wallet::from_async_signing_key(
            cosmos_grpc_client,
            AsyncSigningKey::new(Box::new(signer)),
            &config.chains.tokenfactory.prefix,
            CoinType::Cosmos,
            config.chains.tokenfactory.gas_price.parse().unwrap(),
            config.chains.tokenfactory.gas_adjustment.parse().unwrap(),
            config.chains.tokenfactory.gas_denom.clone(),
        ).await
            .map_err(|e| Status::unavailable(format!("cosmos client connection error {}", e)))?;

        let sim = wallet
            .simulate_tx(vec![msg.clone()])
            .await
            .map_err(|e| Status::internal(format!("simulation error {}", e)))?;

        let gas_used = Decimal::from_str(&sim.gas_info.unwrap().gas_used.to_string()).unwrap();
        let fee = cosmrs::tx::Fee {
            amount: vec![cosmrs::Coin {
                denom: Denom::from_str(&config.chains.tokenfactory.gas_denom).unwrap(),
                amount: Decimal::one().to_uint_ceil().u128(),
            }],
            gas_limit: (gas_used * Decimal::from_str(&config.chains.tokenfactory.gas_adjustment).unwrap() - Decimal::one())
                .to_uint_ceil()
                .u128() as u64,
            payer: None,
            granter: Some(cosmrs::AccountId::from_str(&config.chains.tokenfactory.faucet.address.to_string()).unwrap()),
        };

        let response = wallet
            .broadcast_tx(
                vec![msg],           // Vec<Any>: list of msgs to broadcast
                Some(fee), //None, // fee: Option<Fee>, if not provided the tx is simulated to calculate the fee
                None,      // memo: Option<String>
                BroadcastMode::Sync, // Broadcast mode; Block/Sync/Async
            )
            .await
            .map_err(|e| Status::internal(e.to_string()))?;
*/
        let tx_resp = broadcast_tx_resp.tx_response
            .ok_or_else(|| Status::internal("no tx response"))?;

        Ok(Response::new(SendResponse {
            txhash: tx_resp.txhash,
        }))
    }

    async fn mint(&self, request: Request<MintRequest>) -> Result<Response<MintResponse>, Status> {
        let config = APP.config();

        let jwt = AuthenticatedClient::<kms_proto::kms_svc_client::KmsSvcClient<Channel>>::get_jwt(&request.metadata());

        let req = request.into_inner();

        let tf_denom = TfDenom::try_from(req.denom)
            .map_err(|e| Status::invalid_argument(format!("Failed to parse denom: {}", e)))?;
        let denom = tf_denom.as_str_name().to_string();

        // get the minter key address
        let get_minter_addr_req = GetAddrRequest {
            key_info: Some(req.minter_key_info.clone().ok_or_else(|| Status::invalid_argument("Missing minter key info"))?),
        };
        let authenticated_req = AuthenticatedClient::<Empty>::authenticate_(get_minter_addr_req, &jwt);
        let get_minter_addr_resp = self.get_addr(authenticated_req).await
            .map_err(|e| Status::internal(format!("Failed to get minter address: {}", e)))?.into_inner();

        let mint_msg = ExecuteMsg::Tf(TokenfactoryContractMsg::Mint {
            orig_sender: Some(get_minter_addr_resp.address.clone()),
            address: req.to_address,
            denom,
            value: req.value.to_string(),
        });

        let mint_msg = serde_json::to_vec(&mint_msg)
            .map_err(|e| Status::invalid_argument(e.to_string()))?;

        let msg = MsgExecuteContract {
            sender: get_minter_addr_resp.address,
            contract: config.chains.tokenfactory.tokenfactory_contract.to_string(),
            msg: mint_msg,
            funds: vec![],
        }.build_any();

        let broadcast_tx_resp = self.broadcast_tx(msg, req.minter_key_info.unwrap(), jwt).await
            .map_err(|e| Status::internal(format!("Failed to broadcast transaction: {}", e)))?;

        let tx_resp = broadcast_tx_resp.tx_response
            .ok_or_else(|| Status::internal("no tx response"))?;

        Ok(Response::new(MintResponse {
            txhash: tx_resp.txhash,
        }))
    }

    async fn redeem(&self, request: Request<RedeemRequest>) -> Result<Response<RedeemResponse>, Status> {
        let config = APP.config();

        let jwt = AuthenticatedClient::<kms_proto::kms_svc_client::KmsSvcClient<Channel>>::get_jwt(&request.metadata());

        let req = request.into_inner();

        let tf_denom = TfDenom::try_from(req.denom)
            .map_err(|e| Status::invalid_argument(format!("Failed to parse denom: {}", e)))?;
        let denom = tf_denom.as_str_name().to_string();

        // get the signer key address
        let get_addr_req = GetAddrRequest {
            key_info: Some(req.from_key_info.clone().ok_or_else(|| Status::invalid_argument("Missing sender key info"))?),
        };
        let authenticated_req = AuthenticatedClient::<Empty>::authenticate_(get_addr_req, &jwt);
        // let authenticated_req = AuthenticatedClient::<kms_proto::kms_svc_client::KmsSvcClient<Channel>>::authenticate_(get_addr_req, &jwt);

        let get_addr_resp = self.get_addr(authenticated_req).await
            .map_err(|e| Status::internal(format!("Failed to get sender address: {}", e)))?.into_inner();

        let redeem_msg = ExecuteMsg::Redeem {
            orig_sender: Some(get_addr_resp.address.clone()),
            minter_address: req.minter_address.clone(),
            denom: denom.clone(),
            value: req.value.clone(),
        };
        let redeem_msg = serde_json::to_vec(&redeem_msg)
            .map_err(|e| Status::invalid_argument(e.to_string()))?;

        let coin = ProtoCoin {
            denom,
            amount: req.value.to_string(),
        };

        let msg = MsgExecuteContract {
            sender: get_addr_resp.address,
            contract: config.chains.tokenfactory.tokenfactory_contract.to_string(),
            msg: redeem_msg,
            funds: vec![coin],
        }.build_any();

        let broadcast_tx_resp = self.broadcast_tx(msg, req.from_key_info.unwrap(), jwt).await
            .map_err(|e| Status::internal(format!("Failed to broadcast transaction: {}", e)))?;

        let tx_resp = broadcast_tx_resp.tx_response
            .ok_or_else(|| Status::internal("no tx response"))?;

        Ok(Response::new(RedeemResponse {
            txhash: tx_resp.txhash,
        }))
    }
}