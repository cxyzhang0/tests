use crate::application::APP;
use crate::authenticated_client::AuthenticatedClient;
use crate::proto::blkchn_svc_server::BlkchnSvc;
use crate::proto::{
    Chain, CommonTxResponse, ConfigureMinterRequest, CrossChainSendRequest, CrossChainSendResponse,
    GetAddrRequest, GetAddrResponse, GetAllDenomMetadataRequest, GetAllDenomMetadataResponse,
    GetAllMintersRequest, GetAllMintersResponse, GetBalanceRequest, GetBalanceResponse,
    GetDenomMetadataRequest, GetDenomMetadataResponse, GetFeeBasicAllowanceRequest,
    GetFeeBasicAllowanceResponse, GetMinterRequest, GetMinterResponse, GetTxStatusRequest,
    GetTxStatusResponse, GrantFeeBasicAllowanceRequest, MintRequest, RedeemRequest,
    RemoveMinterRequest, RevokeFeeBasicAllowanceRequest, SendRequest, SetDenomMetadataRequest,
};
use crate::signer;
use crate::types::ChainType;
use crate::{kms_proto, proto};
use abscissa_core::Application;
use tonic::transport::Channel;
use tonic::{async_trait, Request, Response, Status};

/// The concrete BlkchnSvc implementation
#[derive(Clone, Debug, Default)]
pub struct Blkchn {}

impl Blkchn {
    /// Create a new instance of Blkchn
    pub fn new() -> Self {
        Blkchn {}
    }

    pub fn get_chain(chain: Option<i32>) -> Result<Chain, Status> {
        let chain = Chain::try_from(chain.unwrap_or(Chain::Tokenfactory.into()))
            .map_err(|e| Status::invalid_argument(format!("invalid chain: {}", e)))?;
        Ok(chain)
    }

    pub fn get_chain_type(chain: Option<i32>) -> Result<ChainType, Status> {
        let chain = Self::get_chain(chain)?;
        let chain_type = ChainType::from(chain);

        Ok(chain_type)
    }
}
#[async_trait]
impl BlkchnSvc for Blkchn {
    async fn get_addr(
        &self,
        request: Request<GetAddrRequest>,
    ) -> Result<Response<GetAddrResponse>, Status> {
        let config = APP.config();

        let jwt = AuthenticatedClient::<kms_proto::kms_svc_client::KmsSvcClient<Channel>>::get_jwt(
            request.metadata(),
        );

        let req = request.into_inner();

        let key_info = req
            .key_info
            .ok_or_else(|| Status::invalid_argument("Missing key info"))?;
        let key_type = proto::KeyType::try_from(key_info.key_type)
            .map_err(|e| Status::invalid_argument(format!("Failed to parse key type: {}", e)))?;

        match key_type {
            proto::KeyType::Secp256k1 => {}
            _ => return Err(Status::invalid_argument("Invalid key type")),
        }

        let signer = signer::KmsSigner::new(
            config.kms_server.grpc.clone(),
            key_info.kms_provider_uuid.clone(),
            key_info.key_name.clone(),
            key_type,
            jwt,
        )
        .await
        .map_err(|e| Status::internal(format!("Failed to create signer: {}", e)))?;

        let mut kms_client = signer
            .get_authenticated_client()
            .await
            .map_err(|e| Status::internal(format!("Failed to get authenticated_client: {}", e)))?;

        let kms_req = kms_proto::GetPubKeyRequest {
            header: Some(kms_proto::Header {
                uuid: key_info.kms_provider_uuid.to_string(),
                app_name: "blkchn_svc".to_string(),
            }),
            key_name: key_info.key_name,
            attributes: Some(kms_proto::KeyAttributes {
                key_type: key_info.key_type,
            }),
        };
        let kms_req = kms_client.authenticate(kms_req);

        let kms_resp = kms_client
            .get_pub_key(kms_req)
            .await
            .map_err(|e| {
                Status::internal(format!("Failed to get public key from KMS server: {}", e))
            })?
            .into_inner();

        let chain_type = Self::get_chain_type(req.chain)?;

        let addr = match chain_type {
            ChainType::Cosmos => {
                let account_id = crate::tf::types::pk_to_address(&kms_resp.pub_key, &config.chains.tokenfactory.prefix)
                    .map_err(|e| Status::internal(format!("Failed to parse public key from KMS server or get address from public key: {}", e)))?;
                account_id.to_string()
            }
            ChainType::Evm => {
                let address = crate::evm::types::pk_to_address(&kms_resp.pub_key)
                    .map_err(|e| Status::internal(format!("Failed to parse public key from KMS server or get address from public key: {}", e)))?;
                address.to_string()
            }
            _ => {
                return Err(Status::invalid_argument(format!(
                    "chain type {:?} not supported",
                    chain_type
                )))
            }
        };

        Ok(Response::new(GetAddrResponse {
            chain: req.chain,
            address: addr,
        }))
    }

    async fn get_balance(
        &self,
        request: Request<GetBalanceRequest>,
    ) -> Result<Response<GetBalanceResponse>, Status> {
        // let config = APP.config();
        let req = request.get_ref();

        let chain_type = Self::get_chain_type(req.chain)?;

        match chain_type {
            ChainType::Cosmos => {
                let provider = crate::tf::blkchn::Blkchn::new();
                provider.get_balance(request).await
            }
            ChainType::Evm => {
                let provider = crate::evm::blkchn::Blkchn::new();
                provider.get_balance(request).await
            }
            _ => Err(Status::invalid_argument(format!(
                "chain type {:?} not supported",
                chain_type
            ))),
        }
    }

    async fn send(
        &self,
        request: Request<SendRequest>,
    ) -> Result<Response<CommonTxResponse>, Status> {
        let req = request.get_ref();

        let chain_type = Self::get_chain_type(req.chain)?;

        match chain_type {
            ChainType::Cosmos => {
                let provider = crate::tf::blkchn::Blkchn::new();
                provider.send(request).await
            }
            ChainType::Evm => {
                let provider = crate::evm::blkchn::Blkchn::new();
                provider.send(request).await
            }
            _ => Err(Status::invalid_argument(format!(
                "chain type {:?} not supported",
                chain_type
            ))),
        }
    }

    async fn mint(
        &self,
        request: Request<MintRequest>,
    ) -> Result<Response<CommonTxResponse>, Status> {
        let req = request.get_ref();

        let chain_type = Self::get_chain_type(req.chain)?;

        match chain_type {
            ChainType::Cosmos => {
                let provider = crate::tf::blkchn::Blkchn::new();
                provider.mint(request).await
            }
            ChainType::Evm => {
                let provider = crate::evm::blkchn::Blkchn::new();
                provider.mint(request).await
            }
            _ => Err(Status::invalid_argument(format!(
                "chain type {:?} not supported",
                chain_type
            ))),
        }
    }

    async fn redeem(
        &self,
        request: Request<RedeemRequest>,
    ) -> Result<Response<CommonTxResponse>, Status> {
        let req = request.get_ref();

        let chain_type = Self::get_chain_type(req.chain)?;

        match chain_type {
            ChainType::Cosmos => {
                let provider = crate::tf::blkchn::Blkchn::new();
                provider.redeem(request).await
            }
            ChainType::Evm => {
                let provider = crate::evm::blkchn::Blkchn::new();
                provider.redeem(request).await
            }
            _ => Err(Status::invalid_argument(format!(
                "chain type {:?} not supported",
                chain_type
            ))),
        }
    }

    async fn cross_chain_send(
        &self,
        request: Request<CrossChainSendRequest>,
    ) -> Result<Response<CrossChainSendResponse>, Status> {
        let jwt =
            AuthenticatedClient::<proto::blkchn_svc_client::BlkchnSvcClient<Channel>>::get_jwt(
                request.metadata(),
            );

        let req = request.get_ref();

        let from_chain = Self::get_chain(Some(req.from_chain))?;
        let from_chain_type = ChainType::from(from_chain);

        let to_chain = Self::get_chain(Some(req.to_chain))?;
        let to_chain_type = ChainType::from(to_chain);

        if from_chain == to_chain {
            return Err(Status::invalid_argument(format!(
                "source chain {:?} and target chain {:?} must be different",
                from_chain, to_chain
            )));
        }

        // construct authenticated RedeemRequest
        let redeem_req = match from_chain_type {
            ChainType::Cosmos | ChainType::Evm => {
                let req = RedeemRequest {
                    chain: Some(req.from_chain),
                    from_key_info: req.from_key_info.clone(),
                    denom: req.from_denom,
                    value: req.from_value.clone(),
                    minter_address: req.from_minter_address.clone(),
                    fee_info: req.from_fee_info.clone(),
                    tracking_info: None,
                };
                AuthenticatedClient::<proto::blkchn_svc_client::BlkchnSvcClient<Channel>>::authenticate_(req, &jwt)
            }
            _ => {
                return Err(Status::invalid_argument(format!(
                    "chain type {:?} not supported",
                    from_chain_type
                )))
            }
        };

        let from_hash = match from_chain_type {
            ChainType::Cosmos => {
                let provider = crate::tf::blkchn::Blkchn::new();
                let resp = provider.redeem(redeem_req).await?.into_inner();
                resp.txhash
            }
            ChainType::Evm => {
                let provider = crate::evm::blkchn::Blkchn::new();
                let resp = provider.redeem(redeem_req).await?.into_inner();
                resp.txhash
            }
            _ => {
                return Err(Status::invalid_argument(format!(
                    "chain type {:?} not supported",
                    from_chain_type
                )))
            }
        };

        // construct authenticated MintRequest
        let mint_req = match to_chain_type {
            ChainType::Cosmos | ChainType::Evm => {
                let req = MintRequest {
                    chain: Some(req.to_chain),
                    minter_key_info: req.to_minter_key_info.clone(),
                    denom: req.to_denom,
                    value: req.to_value.clone(),
                    to_address: req.to_address.clone(),
                    fee_info: req.to_fee_info.clone(),
                    tracking_info: None,
                };
                AuthenticatedClient::<proto::blkchn_svc_client::BlkchnSvcClient<Channel>>::authenticate_(req, &jwt)
            }
            _ => {
                return Err(Status::invalid_argument(format!(
                    "chain type {:?} not supported",
                    from_chain_type
                )))
            }
        };
        let to_hash = match to_chain_type {
            ChainType::Cosmos => {
                let provider = crate::tf::blkchn::Blkchn::new();
                let resp = provider.mint(mint_req).await?.into_inner();
                resp.txhash
            }
            ChainType::Evm => {
                let provider = crate::evm::blkchn::Blkchn::new();
                let resp = provider.mint(mint_req).await?.into_inner();
                resp.txhash
            }
            _ => {
                return Err(Status::invalid_argument(format!(
                    "chain type {:?} not supported",
                    from_chain_type
                )))
            }
        };

        Ok(Response::new(CrossChainSendResponse {
            from_chain: req.from_chain,
            from_txhash: from_hash,
            from_tx_status: None,
            to_chain: req.to_chain,
            to_txhash: to_hash,
            to_tx_status: None,
        }))
    }

    async fn grant_fee_basic_allowance(
        &self,
        request: Request<GrantFeeBasicAllowanceRequest>,
    ) -> Result<Response<CommonTxResponse>, Status> {
        let req = request.get_ref();

        let chain_type = Self::get_chain_type(req.chain)?;

        match chain_type {
            ChainType::Cosmos => {
                let provider = crate::tf::blkchn::Blkchn::new();
                provider.grant_fee_basic_allowance(request).await
            }
            _ => Err(Status::invalid_argument(format!(
                "chain type {:?} not supported",
                chain_type
            ))),
        }
    }

    async fn revoke_fee_basic_allowance(
        &self,
        request: Request<RevokeFeeBasicAllowanceRequest>,
    ) -> Result<Response<CommonTxResponse>, Status> {
        let req = request.get_ref();

        let chain_type = Self::get_chain_type(req.chain)?;

        match chain_type {
            ChainType::Cosmos => {
                let provider = crate::tf::blkchn::Blkchn::new();
                provider.revoke_fee_basic_allowance(request).await
            }
            _ => Err(Status::invalid_argument(format!(
                "chain type {:?} not supported",
                chain_type
            ))),
        }
    }

    async fn get_fee_basic_allowance(
        &self,
        request: Request<GetFeeBasicAllowanceRequest>,
    ) -> Result<Response<GetFeeBasicAllowanceResponse>, Status> {
        let req = request.get_ref();

        let chain_type = Self::get_chain_type(req.chain)?;

        match chain_type {
            ChainType::Cosmos => {
                let provider = crate::tf::blkchn::Blkchn::new();
                provider.get_fee_basic_allowance(request).await
            }
            _ => Err(Status::invalid_argument(format!(
                "chain type {:?} not supported",
                chain_type
            ))),
        }
    }

    async fn get_tx_status(
        &self,
        request: Request<GetTxStatusRequest>,
    ) -> Result<Response<GetTxStatusResponse>, Status> {
        let req = request.get_ref();

        let chain_type = Self::get_chain_type(req.chain)?;

        match chain_type {
            ChainType::Cosmos => {
                let provider = crate::tf::blkchn::Blkchn::new();
                provider.get_tx_status(request).await
            }
            _ => Err(Status::invalid_argument(format!(
                "chain type {:?} not supported",
                chain_type
            ))),
        }
    }

    async fn set_denom_metadata(
        &self,
        request: Request<SetDenomMetadataRequest>,
    ) -> Result<Response<CommonTxResponse>, Status> {
        let req = request.get_ref();

        let chain_type = Self::get_chain_type(req.chain)?;

        match chain_type {
            ChainType::Cosmos => {
                let provider = crate::tf::blkchn::Blkchn::new();
                provider.set_denom_metadata(request).await
            }
            _ => Err(Status::invalid_argument(format!(
                "chain type {chain_type:?} not supported",
            ))),
        }
    }

    async fn get_denom_metadata(
        &self,
        request: Request<GetDenomMetadataRequest>,
    ) -> Result<Response<GetDenomMetadataResponse>, Status> {
        let req = request.get_ref();

        let chain_type = Self::get_chain_type(req.chain)?;

        match chain_type {
            ChainType::Cosmos => {
                let provider = crate::tf::blkchn::Blkchn::new();
                provider.get_denom_metadata(request).await
            }
            _ => Err(Status::invalid_argument(format!(
                "chain type {:?} not supported",
                chain_type
            ))),
        }
    }

    async fn get_all_denom_metadata(
        &self,
        request: Request<GetAllDenomMetadataRequest>,
    ) -> Result<Response<GetAllDenomMetadataResponse>, Status> {
        let req = request.get_ref();

        let chain_type = Self::get_chain_type(req.chain)?;

        match chain_type {
            ChainType::Cosmos => {
                let provider = crate::tf::blkchn::Blkchn::new();
                provider.get_all_denom_metadata(request).await
            }
            _ => Err(Status::invalid_argument(format!(
                "chain type {:?} not supported",
                chain_type
            ))),
        }
    }

    async fn configure_minter(
        &self,
        request: Request<ConfigureMinterRequest>,
    ) -> Result<Response<CommonTxResponse>, Status> {
        let req = request.get_ref();

        let chain_type = Self::get_chain_type(req.chain)?;

        match chain_type {
            ChainType::Cosmos => {
                let provider = crate::tf::blkchn::Blkchn::new();
                provider.configure_minter(request).await
            }
            _ => Err(Status::invalid_argument(format!(
                "chain type {chain_type:?} not supported",
            ))),
        }
    }

    async fn remove_minter(
        &self,
        request: Request<RemoveMinterRequest>,
    ) -> Result<Response<CommonTxResponse>, Status> {
        let req = request.get_ref();

        let chain_type = Self::get_chain_type(req.chain)?;

        match chain_type {
            ChainType::Cosmos => {
                let provider = crate::tf::blkchn::Blkchn::new();
                provider.remove_minter(request).await
            }
            _ => Err(Status::invalid_argument(format!(
                "chain type {chain_type:?} not supported",
            ))),
        }
    }

    async fn get_minter(
        &self,
        request: Request<GetMinterRequest>,
    ) -> Result<Response<GetMinterResponse>, Status> {
        let req = request.get_ref();

        let chain_type = Self::get_chain_type(req.chain)?;

        match chain_type {
            ChainType::Cosmos => {
                let provider = crate::tf::blkchn::Blkchn::new();
                provider.get_minter(request).await
            }
            _ => Err(Status::invalid_argument(format!(
                "chain type {:?} not supported",
                chain_type
            ))),
        }
    }

    async fn get_all_minters(
        &self,
        request: Request<GetAllMintersRequest>,
    ) -> Result<Response<GetAllMintersResponse>, Status> {
        let req = request.get_ref();

        let chain_type = Self::get_chain_type(req.chain)?;

        match chain_type {
            ChainType::Cosmos => {
                let provider = crate::tf::blkchn::Blkchn::new();
                provider.get_all_minters(request).await
            }
            _ => Err(Status::invalid_argument(format!(
                "chain type {:?} not supported",
                chain_type
            ))),
        }
    }
}
