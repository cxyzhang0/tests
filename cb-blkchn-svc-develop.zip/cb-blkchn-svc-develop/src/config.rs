//! CbBlkchnSvc Config
//!
//! See instructions in `commands.rs` to specify the path to your
//! application's configuration file and/or command-line options
//! for specifying it.

mod blkchn_server;
mod chains;

use serde::{Deserialize, Serialize};
use crate::config::blkchn_server::BlkchnServerConfig;
use crate::config::chains::ChainsConfig;

/// CbBlkchnSvc Configuration
#[derive(Clone, Debug, Default, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct CbBlkchnSvcConfig {
    /// this server's configuration
    pub blkchn_server: BlkchnServerConfig,

    /// kms server's configuration
    pub kms_server: KmsServerConfig,

    /// configuration for the various blockchains to be connected to
    pub chains: ChainsConfig,

}

/// Kms Server Configuration
#[derive(Clone, Debug, Default, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct KmsServerConfig {
    /// grpc
    pub grpc: String,
}
