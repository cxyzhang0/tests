use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Default, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ChainsConfig {
    pub tokenfactory: TokenFactoryConfig,

    pub bitcon: BitconConfig,

    pub ethereum: EthereumConfig,
}

#[derive(Clone, Debug, Default, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct TokenFactoryConfig {
    pub grpc: String,
    pub prefix: String,
    // pub denom: String,
    pub gas_denom: String,
    pub gas_price: String,
    pub gas_adjustment: String,
    pub tx_poll_interval: u64,
    pub tx_poll_timeout: u64,
    pub tokenfactory_contract: String,
    pub aurum_contract: String,
    pub faucet: FaucetConfig
}

#[derive(Clone, Debug, Default, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct FaucetConfig {
    pub grpc: String,
    pub address: String,
}

#[derive(Clone, Debug, Default, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct BitconConfig {}

#[derive(Clone, Debug, Default, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct EthereumConfig {}