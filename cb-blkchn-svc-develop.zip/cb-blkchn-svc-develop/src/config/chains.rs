use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Default, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ChainsConfig {
    pub tokenfactory: TokenFactoryConfig,

    pub bitcon: BitconConfig,

    pub ethereum: EthereumConfig,

    pub base: EthereumConfig,

    pub anvil: EthereumConfig,
}

#[derive(Clone, Debug, Default, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct TokenFactoryConfig {
    pub grpc: String,
    pub prefix: String,
    pub gas_denom: String,
    pub gas_price: String,
    pub gas_adjustment: String,
    pub tx_timeout_blocks: u64,
    pub tokenfactory_contract: String,
    pub aurum_contract: String,
    pub faucet: FaucetConfig,
}

#[derive(Clone, Debug, Default, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct FaucetConfig {
    pub address: String,
    pub allowance_value: String,
    pub hours_to_expire: u64,
}

#[derive(Clone, Debug, Default, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct BitconConfig {}

#[derive(Clone, Debug, Default, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct EthereumConfig {
    pub rpc_url: String,
    pub chain_id: u64,
    pub wf_deposit_token_address: String,
}
