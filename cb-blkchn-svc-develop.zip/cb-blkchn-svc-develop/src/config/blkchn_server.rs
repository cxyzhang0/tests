use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Default, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct BlkchnServerConfig {
    /// The URL of the blockchain server
    pub grpc: String,
}