use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Default, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct BlkchnServerConfig {
    /// The URL of the blockchain server
    pub grpc: String,
    /// URL for authz server
    pub authz_server: String,
    /// blkchn svc audience in JWT
    pub audience: String,
}