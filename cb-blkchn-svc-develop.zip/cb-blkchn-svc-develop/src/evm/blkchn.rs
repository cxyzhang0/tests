use crate::application::APP;
use crate::authenticated_client::AuthenticatedClient;
use crate::evm::IERC20;
use crate::{kms_proto, proto, signer};
use abscissa_core::Application;
use alloy::network::{EthereumWallet, TxSigner};
use alloy::primitives::Address;
use alloy::providers::ProviderBuilder;
use hex::ToHex;
use proto::{
    Chain, GetBalanceRequest, GetBalanceResponse, KeyInfo, MintRequest, MintResponse, NtfDenom,
    RedeemRequest, RedeemResponse, SendRequest, SendResponse,
};
use tonic::transport::Channel;
use tonic::{Request, Response, Status};

#[derive(Debug, Default)]
pub struct Blkchn {}

impl Blkchn {
    pub fn new() -> Self {
        Self {}
    }

    // return (rpc_url, contract_address)
    fn get_chain_params(chain: Chain) -> Result<(String, Address), Status> {
        let config = APP.config();

        match chain {
            Chain::Ethereum => {
                let token: Address = config
                    .chains
                    .ethereum
                    .wf_deposit_token_address
                    .clone()
                    .parse()
                    .map_err(|e| {
                        Status::invalid_argument(format!("token address parse error: {}", e))
                    })?;
                Ok((config.chains.ethereum.rpc_url.clone(), token))
            }
            Chain::Base => {
                let token: Address = config
                    .chains
                    .base
                    .wf_deposit_token_address
                    .clone()
                    .parse()
                    .map_err(|e| {
                        Status::invalid_argument(format!("token address parse error: {}", e))
                    })?;
                Ok((config.chains.base.rpc_url.clone(), token))
            }
            Chain::Anvil => {
                let token: Address = config
                    .chains
                    .anvil
                    .wf_deposit_token_address
                    .clone()
                    .parse()
                    .map_err(|e| {
                        Status::invalid_argument(format!("token address parse error: {}", e))
                    })?;
                Ok((config.chains.anvil.rpc_url.clone(), token))
            }
            _ => Err(Status::invalid_argument("Unsupported chain")),
        }
    }

    async fn get_ethereum_wallet(
        key_info: KeyInfo,
        jwt: Option<String>,
    ) -> Result<EthereumWallet, Status> {
        let config = APP.config();
        let signer = signer::KmsSigner::new(
            config.kms_server.grpc.clone(),
            key_info.kms_provider_uuid,
            key_info.key_name,
            proto::KeyType::try_from(key_info.key_type).unwrap(),
            jwt,
        )
        .await
        .map_err(|e| Status::internal(format!("Failed to create HsmSigner: {}", e)))?;

        let _signer_addr = signer.address();

        // Wrap signer in EthereumWallet and create provider
        let wallet = EthereumWallet::new(std::sync::Arc::new(signer));

        Ok(wallet)
    }

    pub async fn get_balance(
        &self,
        request: Request<GetBalanceRequest>,
    ) -> Result<Response<GetBalanceResponse>, Status> {
        let req = request.into_inner();

        let chain = crate::server::Blkchn::get_chain(req.chain)?;

        let (rpc_url, contract_address) = Self::get_chain_params(chain)?;

        let provider = ProviderBuilder::new().connect_http(
            rpc_url
                .parse()
                .map_err(|e| Status::invalid_argument(format!("Invalid rpc_url - {}", e)))?,
        );

        let erc20 = IERC20::new(contract_address, provider);

        let wallet: Address = req
            .address
            .parse()
            .map_err(|e| Status::invalid_argument(format!("Invalid address - {}", e)))?;

        let balance = erc20
            .balanceOf(wallet)
            .call()
            .await
            .map_err(|e| Status::internal(format!("Failed to get balance: {}", e)))?;

        Ok(Response::new(GetBalanceResponse {
            chain: req.chain,
            denom: NtfDenom::Wfusd as i32,
            value: balance.to_string(),
        }))
    }

    pub async fn send(
        &self,
        request: Request<SendRequest>,
    ) -> Result<Response<SendResponse>, Status> {
        let jwt = AuthenticatedClient::<kms_proto::kms_svc_client::KmsSvcClient<Channel>>::get_jwt(
            request.metadata(),
        );

        let req = request.into_inner();

        let chain = crate::server::Blkchn::get_chain(req.chain)?;

        let (rpc_url, contract_address) = Self::get_chain_params(chain)?;

        let signer_key_info = req
            .from_key_info
            .ok_or(Status::invalid_argument("Missing from_key_info"))?;
        let wallet = Self::get_ethereum_wallet(signer_key_info, jwt).await?;

        let provider = ProviderBuilder::new()
            .wallet(std::sync::Arc::new(wallet))
            .connect_http(
                rpc_url
                    .parse()
                    .map_err(|e| Status::invalid_argument(format!("Invalid rpc_url - {}", e)))?,
            );

        let erc20 = IERC20::new(contract_address, &provider);

        let recipient: Address = req
            .to_address
            .parse()
            .map_err(|e| Status::invalid_argument(format!("Invalid to_address: {}", e)))?;
        let amount: alloy::primitives::U256 = req
            .value
            .parse()
            .map_err(|e| Status::invalid_argument(format!("Invalid amount: {}", e)))?;

        let pending_tx = erc20
            .transfer(recipient, amount)
            .send()
            .await
            .map_err(|e| Status::internal(format!("Failed to send transaction: {}", e)))?;

        Ok(Response::new(SendResponse {
            chain: req.chain,
            txhash: format!("0x{}", pending_tx.tx_hash().encode_hex::<String>()),
            tx_status: None,
        }))
    }

    pub async fn mint(
        &self,
        request: Request<MintRequest>,
    ) -> Result<Response<MintResponse>, Status> {
        let jwt = AuthenticatedClient::<kms_proto::kms_svc_client::KmsSvcClient<Channel>>::get_jwt(
            request.metadata(),
        );

        let req = request.into_inner();

        let chain = crate::server::Blkchn::get_chain(req.chain)?;

        let (rpc_url, contract_address) = Self::get_chain_params(chain)?;

        let signer_key_info = req
            .minter_key_info
            .ok_or(Status::invalid_argument("Missing minter_key_info"))?;
        let wallet = Self::get_ethereum_wallet(signer_key_info, jwt).await?;

        let provider = ProviderBuilder::new()
            .wallet(std::sync::Arc::new(wallet))
            .connect_http(
                rpc_url
                    .parse()
                    .map_err(|e| Status::invalid_argument(format!("Invalid rpc_url - {}", e)))?,
            );

        let erc20 = IERC20::new(contract_address, &provider);

        let recipient: Address = req
            .to_address
            .parse()
            .map_err(|e| Status::invalid_argument(format!("Invalid to_address: {}", e)))?;
        let amount: alloy::primitives::U256 = req
            .value
            .parse()
            .map_err(|e| Status::invalid_argument(format!("Invalid amount: {}", e)))?;

        let pending_tx = erc20
            .mint(recipient, amount)
            .send()
            .await
            .map_err(|e| Status::internal(format!("Failed to mint transaction: {}", e)))?;

        Ok(Response::new(MintResponse {
            chain: req.chain,
            txhash: format!("0x{}", pending_tx.tx_hash().encode_hex::<String>()),
            tx_status: None,
        }))
    }

    pub async fn redeem(
        &self,
        request: Request<RedeemRequest>,
    ) -> Result<Response<RedeemResponse>, Status> {
        let jwt = AuthenticatedClient::<kms_proto::kms_svc_client::KmsSvcClient<Channel>>::get_jwt(
            request.metadata(),
        );

        let req = request.into_inner();

        let chain = crate::server::Blkchn::get_chain(req.chain)?;

        let (rpc_url, contract_address) = Self::get_chain_params(chain)?;

        let signer_key_info = req
            .from_key_info
            .ok_or(Status::invalid_argument("Missing from_key_info"))?;
        let wallet = Self::get_ethereum_wallet(signer_key_info, jwt).await?;

        let provider = ProviderBuilder::new()
            .wallet(std::sync::Arc::new(wallet))
            .connect_http(
                rpc_url
                    .parse()
                    .map_err(|e| Status::invalid_argument(format!("Invalid rpc_url - {}", e)))?,
            );

        let erc20 = IERC20::new(contract_address, &provider);

        let amount: alloy::primitives::U256 = req
            .value
            .parse()
            .map_err(|e| Status::invalid_argument(format!("Invalid amount: {}", e)))?;

        let pending_tx = erc20
            .burn(amount)
            .send()
            .await
            .map_err(|e| Status::internal(format!("Failed to burn transaction: {}", e)))?;

        Ok(Response::new(RedeemResponse {
            chain: req.chain,
            txhash: format!("0x{}", pending_tx.tx_hash().encode_hex::<String>()),
            tx_status: None,
        }))
    }
}
