use alloy::primitives::Address;
use anyhow::{anyhow, Result};
use tiny_keccak::{Hasher, Keccak};
use k256::ecdsa::{Signature as K256Sig, VerifyingKey, RecoveryId};

// pubkey (uncompressed) to Ethereum address
pub fn pk_to_address(pubkey: &[u8]) -> Result<Address> {
    let mut keccak = Keccak::v256();
    let mut hash = [0u8; 32];
    keccak.update(&pubkey[1..]); // skip 0x04 for uncompressed
    keccak.finalize(&mut hash);
    Ok(Address::from_slice(&hash[12..]))
}

/// Try all 4 recovery ids and match against known public key.
pub fn compute_recovery_id_k256(
    hash: [u8; 32],
    sig: &K256Sig,
    // sig: &[u8],
    pub_key_uncompressed: &[u8],
) -> Result<u8> {
    if pub_key_uncompressed.len() != 65 || pub_key_uncompressed[0] != 0x04 {
        return Err(anyhow!("expected 65-byte uncompressed pubkey starting with 0x04"));
    }
    // Try all combinations of (is_y_odd, is_x_reduced)
    for (recid, (y_odd, x_red)) in
        [(false, false), (true, false), (false, true), (true, true)].into_iter().enumerate()
    {
        let rid = RecoveryId::new(y_odd, x_red);
        if let Ok(vk) = VerifyingKey::recover_from_prehash(&hash, &sig, rid) {
            let recovered_bytes = vk.to_encoded_point(false).as_bytes().to_vec();
            if recovered_bytes == pub_key_uncompressed {
                return Ok(recid as u8); // map to 0..=3
            }
        }
    }

    Err(anyhow!("no matching recovery id"))
}
