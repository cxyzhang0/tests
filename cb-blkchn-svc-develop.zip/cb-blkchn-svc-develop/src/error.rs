//! Error types

use abscissa_core::error::{BoxError, Context};
use std::{
    fmt::{self, Display},
    io,
    ops::Deref,
};
use thiserror::Error;

/// Kinds of errors
#[derive(Copy, Clone, Debug, Eq, Error, PartialEq)]
pub enum ErrorKind {
    /// Error in configuration file
    #[error("config error")]
    Config,

    /// Input/output error
    #[error("I/O error")]
    Io,

    /// invalid data
    #[error("invalid data")]
    InvalidData,

    /// kms svc error
    #[error("kms svc error")]
    KmsSvcError,

    /// Authorization error
    #[error("authorization error")]
    AuthZError,
}

impl ErrorKind {
    /// Create an error context from this error
    pub fn context(self, source: impl Into<BoxError>) -> Context<ErrorKind> {
        Context::new(self, Some(source.into()))
    }
}

/// Error type
#[derive(Debug)]
pub struct Error(Box<Context<ErrorKind>>);

impl Deref for Error {
    type Target = Context<ErrorKind>;

    fn deref(&self) -> &Context<ErrorKind> {
        &self.0
    }
}

impl Display for Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

impl std::error::Error for Error {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        self.0.source()
    }
}

impl From<ErrorKind> for Error {
    fn from(kind: ErrorKind) -> Self {
        Context::new(kind, None).into()
    }
}

impl From<Context<ErrorKind>> for Error {
    fn from(context: Context<ErrorKind>) -> Self {
        Error(Box::new(context))
    }
}

impl From<io::Error> for Error {
    fn from(err: io::Error) -> Self {
        ErrorKind::Io.context(err).into()
    }
}

#[cfg(test)]
mod error_tests {
    use crate::error::{Error, ErrorKind};
    use abscissa_core::error::Context;
    use std::error::Error as _;

    #[test]
    fn errorkind_context_and_display() {
        let ctx: Context<ErrorKind> = ErrorKind::InvalidData.context("boom");
        let err: Error = ctx.into();

        // make sure Display + source path executed
        let s = format!("{err}");
        assert!(!s.is_empty());
        assert!(err.source().is_some());
    }

    #[test]
    fn from_errorkind_into_error() {
        let err: Error = ErrorKind::Config.into();
        let s = format!("{err}");
        assert!(s.contains("config") || !s.is_empty());
    }

    #[test]
    fn from_io_error_into_error() {
        use std::io;

        let io_err = io::Error::new(io::ErrorKind::Other, "io-fail");
        let err: Error = io_err.into();

        let s = format!("{err}");
        assert!(!s.is_empty());
        assert!(err.source().is_some());
    }
}
