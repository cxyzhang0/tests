## run the OIDC provider server to test the JWT middleware
> see cb-kms-svc/Developer.md or for more details, ~/Project/rust/tower-oauth2-resource-server/examples/tonic-example/README.md.

## cli
```shell
cargo run -- -h
# note: make sure port for authz_server in cb_blkchn_svc.toml is set to the OIDC provider port above, e.g. 55002.
cargo run --release -- -c cb_blkchn_svc.toml start 
RUST_BACKTRACE=1 cargo run --release -- -c cb_blkchn_svc.toml start 
RUST_BACKTRACE=full cargo run --release -- -c cb_blkchn_svc.toml start

./target/release/cb_blkchn_svc -c cb_blkchn_svc.toml start

# cli - need to turn off authz_server on kms_svc because cli does not provide a JWT.
## get addr
cargo run --release -- -c cb_blkchn_svc.toml svc get-addr -c 0 -p "2b6a375b-93f9-4590-a38d-3a79f8062c8f" -t 0 -n "Slot Token 0/wfdc2/user1/1"
## load test get addr
cargo run --release -- -c cb_blkchn_svc.toml svc load-test-get-addr -l 100 --mc 50 -p "2b6a375b-93f9-4590-a38d-3a79f8062c8f" -t 0 -n "Slot Token 0/wfdc2/user1/1"
### use default load (175) and max concurrency (100)
./target/release/cb_blkchn_svc -c cb_blkchn_svc.toml svc get-addr -p "2b6a375b-93f9-4590-a38d-3a79f8062c8f" -t 0 -n "Slot Token 0/wfdc2/user1/1"
./target/release/cb_blkchn_svc -c cb_blkchn_svc.toml svc get-addr -p "2b6a375b-93f9-4590-a38d-3a79f8062c8f" -t 0 -n "Slot Token 0/wfdc2/user1/1"
./target/release/cb_blkchn_svc -c cb_blkchn_svc.toml svc get-addr -p "2b6a375b-93f9-4590-a38d-3a79f8062c8f" -t 0 -n "Slot Token 0/wfdc2/user1/1"
### use max concurrency (100)
./target/release/cb_blkchn_svc -c cb_blkchn_svc.toml svc load-test-get-addr -l 1000 -p "2b6a375b-93f9-4590-a38d-3a79f8062c8f" -t 0 -n "Slot Token 0/wfdc2/user1/1"
./target/release/cb_blkchn_svc -c cb_blkchn_svc.toml svc load-test-get-addr -l 1000 -p "2b6a375b-93f9-4590-a38d-3a79f8062c8f" -t 0 -n "Slot Token 0/wfdc2/user1/1"
./target/release/cb_blkchn_svc -c cb_blkchn_svc.toml svc load-test-get-addr -l 1000 -p "2b6a375b-93f9-4590-a38d-3a79f8062c8f" -t 0 -n "Slot Token 0/wfdc2/user1/1"
### large max concurrency may result in transport failures
./target/release/cb_blkchn_svc -c cb_blkchn_svc.toml svc load-test-get-addr -l 1000 --mc 175 -p "2b6a375b-93f9-4590-a38d-3a79f8062c8f" -t 0 -n "Slot Token 0/wfdc2/user1/1"

```

## grpcurl
```shell
grpcurl \
	-plaintext \
	-H 'Authorization':'Bearer eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJMM0Q4ektFdk5YOTRaakpHZ25jM3NCRHhpY1ZMeGVQamlzZDlsMVh0ZU9JIn0.eyJleHAiOjE3Njc2NjQxODAsImlhdCI6MTc2NzYyODE4MCwianRpIjoiZTY0ZmNiMzUtZjY2Zi00MGMwLWE4N2QtNDIyMTM2YmE2MjhjIiwiaXNzIjoiaHR0cDovL2xvY2FsaG9zdDo1NTAwMi9yZWFsbXMvdG9ycyIsImF1ZCI6WyJ0b3JzLWV4YW1wbGUiLCJhY2NvdW50Il0sInN1YiI6ImYyMjM5OWY5LWEzYTQtNDIyZi1hNWIyLWIyNGJhOGM3YzFiNiIsInR5cCI6IkJlYXJlciIsImF6cCI6InRvcnMtZXhhbXBsZSIsInNpZCI6ImFiMGQxMTQyLWU4OTUtNGRkYi1iOGU0LTIxZmQ3OGI4YjI4MyIsImFjciI6IjEiLCJhbGxvd2VkLW9yaWdpbnMiOlsiLyoiXSwicmVhbG1fYWNjZXNzIjp7InJvbGVzIjpbImRlZmF1bHQtcm9sZXMtdG9ycyIsIm9mZmxpbmVfYWNjZXNzIiwidW1hX2F1dGhvcml6YXRpb24iXX0sInJlc291cmNlX2FjY2VzcyI6eyJhY2NvdW50Ijp7InJvbGVzIjpbIm1hbmFnZS1hY2NvdW50IiwibWFuYWdlLWFjY291bnQtbGlua3MiLCJ2aWV3LXByb2ZpbGUiXX19LCJzY29wZSI6Im9wZW5pZCBwcm9maWxlIGVtYWlsIiwiZW1haWxfdmVyaWZpZWQiOmZhbHNlLCJuYW1lIjoiVXNlciBFeGFtcGxlIiwicHJlZmVycmVkX3VzZXJuYW1lIjoidXNlckBleGFtcGxlLmNvbSIsImdpdmVuX25hbWUiOiJVc2VyIiwiZmFtaWx5X25hbWUiOiJFeGFtcGxlIiwiZW1haWwiOiJ1c2VyQGV4YW1wbGUuY29tIn0.BduW3CrjbSzU1d4QTPPZW-AMj2iMG4Zfazt-WbTcMBY0m4aw6Q47MY5cpyd-EiLiDnCGNN_0wq7BJzIJAabfKgqAdQ-rhq-qsZFu6EImnqVk7s2a_i1YvydLU1WR9O3Hpk3mvrC1lQq4VKgRpsxSzSx5F3oGbpU5nZfqKAfhNZJgFSvxcUksvaOP8CFU93EeiAB2N5mmebrMvJ3xf-kQ94bSAd3bX0sGSrL25yjk5-d5yAO8-1BDqL6AFCa88EDiiqXh-SxzRiRpZ8VNGDzIQYkTOFCVKNOAkK5M1gmiPqLC_9lITDqf-glttUPvCcXAKgWmc1romFyKSrtFPudkVg' \
	-emit-defaults \
	-proto '/Users/johnz/Project/rust/cb-blkchn-svc/proto/blkchn-svc/v1/service.proto' \
	-import-path '/Users/johnz/Project/rust/cb-blkchn-svc/proto/blkchn-svc/v1' \
	-import-path '/Users/johnz/Project/rust/cosmos/wfdc2/proto/wfdc2/wallet/v1' \
	-import-path '/Users/johnz/Project/rust/cosmos/wfdc2/proto' \
	-import-path '/Users/johnz/Project/rust/cb-kms-service/proto/kms-service/v1' \
	-import-path '/Users/johnz/Project/rust/cb-kms-service/proto/kms-service' \
	-import-path '/Users/johnz/Project/rust/cb-kms-service/proto' \
	-import-path '/Users/johnz/Project/rust/cb-kms-svc/proto/kms-svc' \
	-import-path '/Users/johnz/Project/rust/cb-kms-svc/proto' \
	-import-path '/Users/johnz/Project/rust/cb-blkchn-svc/proto' \
	-d '{"chain":"Tokenfactory","address":"wf18jvphye4nnlxs4j2p6py3w3ct30emuuq2h7w9q","denom":"uwfGBP"}' \
	'localhost:8002' \
	blkchn_svc_v1.BlkchnSvc.GetBalance

grpcurl \
	-plaintext \
	-H 'Authorization':'Bearer eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJMM0Q4ektFdk5YOTRaakpHZ25jM3NCRHhpY1ZMeGVQamlzZDlsMVh0ZU9JIn0.eyJleHAiOjE3Njc2NjQxODAsImlhdCI6MTc2NzYyODE4MCwianRpIjoiZTY0ZmNiMzUtZjY2Zi00MGMwLWE4N2QtNDIyMTM2YmE2MjhjIiwiaXNzIjoiaHR0cDovL2xvY2FsaG9zdDo1NTAwMi9yZWFsbXMvdG9ycyIsImF1ZCI6WyJ0b3JzLWV4YW1wbGUiLCJhY2NvdW50Il0sInN1YiI6ImYyMjM5OWY5LWEzYTQtNDIyZi1hNWIyLWIyNGJhOGM3YzFiNiIsInR5cCI6IkJlYXJlciIsImF6cCI6InRvcnMtZXhhbXBsZSIsInNpZCI6ImFiMGQxMTQyLWU4OTUtNGRkYi1iOGU0LTIxZmQ3OGI4YjI4MyIsImFjciI6IjEiLCJhbGxvd2VkLW9yaWdpbnMiOlsiLyoiXSwicmVhbG1fYWNjZXNzIjp7InJvbGVzIjpbImRlZmF1bHQtcm9sZXMtdG9ycyIsIm9mZmxpbmVfYWNjZXNzIiwidW1hX2F1dGhvcml6YXRpb24iXX0sInJlc291cmNlX2FjY2VzcyI6eyJhY2NvdW50Ijp7InJvbGVzIjpbIm1hbmFnZS1hY2NvdW50IiwibWFuYWdlLWFjY291bnQtbGlua3MiLCJ2aWV3LXByb2ZpbGUiXX19LCJzY29wZSI6Im9wZW5pZCBwcm9maWxlIGVtYWlsIiwiZW1haWxfdmVyaWZpZWQiOmZhbHNlLCJuYW1lIjoiVXNlciBFeGFtcGxlIiwicHJlZmVycmVkX3VzZXJuYW1lIjoidXNlckBleGFtcGxlLmNvbSIsImdpdmVuX25hbWUiOiJVc2VyIiwiZmFtaWx5X25hbWUiOiJFeGFtcGxlIiwiZW1haWwiOiJ1c2VyQGV4YW1wbGUuY29tIn0.BduW3CrjbSzU1d4QTPPZW-AMj2iMG4Zfazt-WbTcMBY0m4aw6Q47MY5cpyd-EiLiDnCGNN_0wq7BJzIJAabfKgqAdQ-rhq-qsZFu6EImnqVk7s2a_i1YvydLU1WR9O3Hpk3mvrC1lQq4VKgRpsxSzSx5F3oGbpU5nZfqKAfhNZJgFSvxcUksvaOP8CFU93EeiAB2N5mmebrMvJ3xf-kQ94bSAd3bX0sGSrL25yjk5-d5yAO8-1BDqL6AFCa88EDiiqXh-SxzRiRpZ8VNGDzIQYkTOFCVKNOAkK5M1gmiPqLC_9lITDqf-glttUPvCcXAKgWmc1romFyKSrtFPudkVg' \
	-emit-defaults \
	-proto '/Users/johnz/Project/rust/cb-blkchn-svc/proto/blkchn-svc/v1/service.proto' \
	-import-path '/Users/johnz/Project/rust/cb-blkchn-svc/proto/blkchn-svc/v1' \
	-import-path '/Users/johnz/Project/rust/cosmos/wfdc2/proto/wfdc2/wallet/v1' \
	-import-path '/Users/johnz/Project/rust/cosmos/wfdc2/proto' \
	-import-path '/Users/johnz/Project/rust/cb-kms-service/proto/kms-service/v1' \
	-import-path '/Users/johnz/Project/rust/cb-kms-service/proto/kms-service' \
	-import-path '/Users/johnz/Project/rust/cb-kms-service/proto' \
	-import-path '/Users/johnz/Project/rust/cb-kms-svc/proto/kms-svc' \
	-import-path '/Users/johnz/Project/rust/cb-kms-svc/proto' \
	-import-path '/Users/johnz/Project/rust/cb-blkchn-svc/proto' \
	-d '{"chain":"Tokenfactory","grantee":"wf16f4zjgvu0m5msxh552vx9wqcv78hru9j50ymdj"}' \
	'localhost:8002' \
	blkchn_svc_v1.BlkchnSvc.GetFeeBasicAllowance
	
grpcurl \
	-plaintext \
	-H 'Authorization':'Bearer eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJMM0Q4ektFdk5YOTRaakpHZ25jM3NCRHhpY1ZMeGVQamlzZDlsMVh0ZU9JIn0.eyJleHAiOjE3Njc2NjQxODAsImlhdCI6MTc2NzYyODE4MCwianRpIjoiZTY0ZmNiMzUtZjY2Zi00MGMwLWE4N2QtNDIyMTM2YmE2MjhjIiwiaXNzIjoiaHR0cDovL2xvY2FsaG9zdDo1NTAwMi9yZWFsbXMvdG9ycyIsImF1ZCI6WyJ0b3JzLWV4YW1wbGUiLCJhY2NvdW50Il0sInN1YiI6ImYyMjM5OWY5LWEzYTQtNDIyZi1hNWIyLWIyNGJhOGM3YzFiNiIsInR5cCI6IkJlYXJlciIsImF6cCI6InRvcnMtZXhhbXBsZSIsInNpZCI6ImFiMGQxMTQyLWU4OTUtNGRkYi1iOGU0LTIxZmQ3OGI4YjI4MyIsImFjciI6IjEiLCJhbGxvd2VkLW9yaWdpbnMiOlsiLyoiXSwicmVhbG1fYWNjZXNzIjp7InJvbGVzIjpbImRlZmF1bHQtcm9sZXMtdG9ycyIsIm9mZmxpbmVfYWNjZXNzIiwidW1hX2F1dGhvcml6YXRpb24iXX0sInJlc291cmNlX2FjY2VzcyI6eyJhY2NvdW50Ijp7InJvbGVzIjpbIm1hbmFnZS1hY2NvdW50IiwibWFuYWdlLWFjY291bnQtbGlua3MiLCJ2aWV3LXByb2ZpbGUiXX19LCJzY29wZSI6Im9wZW5pZCBwcm9maWxlIGVtYWlsIiwiZW1haWxfdmVyaWZpZWQiOmZhbHNlLCJuYW1lIjoiVXNlciBFeGFtcGxlIiwicHJlZmVycmVkX3VzZXJuYW1lIjoidXNlckBleGFtcGxlLmNvbSIsImdpdmVuX25hbWUiOiJVc2VyIiwiZmFtaWx5X25hbWUiOiJFeGFtcGxlIiwiZW1haWwiOiJ1c2VyQGV4YW1wbGUuY29tIn0.BduW3CrjbSzU1d4QTPPZW-AMj2iMG4Zfazt-WbTcMBY0m4aw6Q47MY5cpyd-EiLiDnCGNN_0wq7BJzIJAabfKgqAdQ-rhq-qsZFu6EImnqVk7s2a_i1YvydLU1WR9O3Hpk3mvrC1lQq4VKgRpsxSzSx5F3oGbpU5nZfqKAfhNZJgFSvxcUksvaOP8CFU93EeiAB2N5mmebrMvJ3xf-kQ94bSAd3bX0sGSrL25yjk5-d5yAO8-1BDqL6AFCa88EDiiqXh-SxzRiRpZ8VNGDzIQYkTOFCVKNOAkK5M1gmiPqLC_9lITDqf-glttUPvCcXAKgWmc1romFyKSrtFPudkVg' \
	-emit-defaults \
	-proto '/Users/johnz/Project/rust/cb-blkchn-svc/proto/blkchn-svc/v1/service.proto' \
	-import-path '/Users/johnz/Project/rust/cb-blkchn-svc/proto/blkchn-svc/v1' \
	-import-path '/Users/johnz/Project/rust/cosmos/wfdc2/proto/wfdc2/wallet/v1' \
	-import-path '/Users/johnz/Project/rust/cosmos/wfdc2/proto' \
	-import-path '/Users/johnz/Project/rust/cb-kms-service/proto/kms-service/v1' \
	-import-path '/Users/johnz/Project/rust/cb-kms-service/proto/kms-service' \
	-import-path '/Users/johnz/Project/rust/cb-kms-service/proto' \
	-import-path '/Users/johnz/Project/rust/cb-kms-svc/proto/kms-svc' \
	-import-path '/Users/johnz/Project/rust/cb-kms-svc/proto' \
	-import-path '/Users/johnz/Project/rust/cb-blkchn-svc/proto' \
	-d '{"chain":"Tokenfactory","denom":"wSAT"}' \
	'localhost:8002' \
	blkchn_svc_v1.BlkchnSvc.GetDenomMetadata	
````

## apply linting
```shell
# Optimize Imports for the whole workspace: right-click on the workspace root folder in RustRover IDE and select Optimize Imports.
# unfortunately, the above does not remove unused imports.

# check the whole workspace. it will show unused imports, among other things.
# manually remove unused imports.
cargo check --workspace --all-features  
cargo check --all-features  

# Reformat the whole workspace: right-click on the workspace root folder in RustRover IDE and select Reformat Code.
# Or run the following commands.
cargo fmt --all --check # it will display the proposed changes.
cargo fmt --all

# clippy the whole workspace; review recommendations and make appropriate changes.
cargo clippy --workspace --all-features
## pedantic is too strict, but the docs recommendation may be worth it.
cargo clippy --workspace --all-features -- --warn clippy::pedantic

# fix clippy recommendations: may need to export __CARGO_FIX_YOLO=1
cargo fix #--allow-dirty --allow-staged
cargo clippy --fix #--allow-dirty -- -Dwarnings  

# sonar clippy report
cargo clippy --message-format=json > ./temp/clippy-report.json
cargo sonar --clippy --clippy-path=./temp/clippy-report.json --sonar-path ./temp/sonar-issues.json
```

```shell
## Test Coverage - llvm-cov
```shell
# test default features - alias cov-default-features
cargo cov-default-features
cargo cov-default-features2

cargo cov-default-features --html
open target/llvm-cov/html/index.html      

cargo cov-all-features

# test all features - w/o alias
cargo llvm-cov -vv --text \
  --ignore-filename-regex '.*(/gen/|/src/proto_build/).*' \
  --workspace

cargo llvm-cov \
  --ignore-filename-regex '.*(/gen/|/src/proto_build/).*' \
  --workspace

```

## Test Coverage - tarpaulin
> - .tarpaulin.toml is used to configure tarpaulin options.
```shell
# test default features using .tarpaulin.toml for exclusions
cargo tarpaulin
# test default features with inline exclusions
cargo tarpaulin \
  --exclude-files "gen/**" "src/proto_build/**" \
  --out Html
# this may fail to due to mpc.  
cargo tarpaulin \
  --exclude-files "gen/**" "src/proto_build/**" \
  --all-features --workspace \
  --out Html  
```

## misc
```shell
zip -r cb_blkchn_svc.zip Cargo.toml Cargo.lock src/ \
    -x "src/proto_build/*" \
    -x "src/proto_build.rs" \
    -x "src/.DS_Store"

zip -r root-folder.zip . \
  -x "target/*" \
  -x "gen/*" \
  -x "src/proto_build/*" \
  -x ".idea/*" \
  -x ".git/*"
```