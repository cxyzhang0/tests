## run the OIDC provider server to test the JWT middleware
> see cb-kms-svc/Developer.md or for more details, ~/Project/rust/tower-oauth2-resource-server/examples/tonic-example/README.md.

```shell
cargo run -- -h
# note: make sure port for authz_server in cb_blkchn_svc.toml is set to the OIDC provider port above, e.g. 55002.
cargo run --release -- -c cb_blkchn_svc.toml start 
RUST_BACKTRACE=1 cargo run --release -- -c cb_blkchn_svc.toml start 
RUST_BACKTRACE=full cargo run --release -- -c cb_blkchn_svc.toml start

./target/release/cb_blkchn_svc -c cb_blkchn_svc.toml start

# cli - need to turn off authz_server on kms_svc because cli does not provide a JWT.
## get addr
cargo run --release -- -c cb_blkchn_svc.toml svc get-addr -c 0 -p "2b6a375b-93f9-4590-a38d-3a79f8062c8f" -t 0 -n "Slot Token 0/wfdc2/user1/1"
## load test get addr
cargo run --release -- -c cb_blkchn_svc.toml svc load-test-get-addr -l 100 --mc 50 -p "2b6a375b-93f9-4590-a38d-3a79f8062c8f" -t 0 -n "Slot Token 0/wfdc2/user1/1"
### use default load (175) and max concurrency (100)
./target/release/cb_blkchn_svc -c cb_blkchn_svc.toml svc get-addr -p "2b6a375b-93f9-4590-a38d-3a79f8062c8f" -t 0 -n "Slot Token 0/wfdc2/user1/1"
./target/release/cb_blkchn_svc -c cb_blkchn_svc.toml svc get-addr -p "2b6a375b-93f9-4590-a38d-3a79f8062c8f" -t 0 -n "Slot Token 0/wfdc2/user1/1"
./target/release/cb_blkchn_svc -c cb_blkchn_svc.toml svc get-addr -p "2b6a375b-93f9-4590-a38d-3a79f8062c8f" -t 0 -n "Slot Token 0/wfdc2/user1/1"
### use max concurrency (100)
./target/release/cb_blkchn_svc -c cb_blkchn_svc.toml svc load-test-get-addr -l 1000 -p "2b6a375b-93f9-4590-a38d-3a79f8062c8f" -t 0 -n "Slot Token 0/wfdc2/user1/1"
./target/release/cb_blkchn_svc -c cb_blkchn_svc.toml svc load-test-get-addr -l 1000 -p "2b6a375b-93f9-4590-a38d-3a79f8062c8f" -t 0 -n "Slot Token 0/wfdc2/user1/1"
./target/release/cb_blkchn_svc -c cb_blkchn_svc.toml svc load-test-get-addr -l 1000 -p "2b6a375b-93f9-4590-a38d-3a79f8062c8f" -t 0 -n "Slot Token 0/wfdc2/user1/1"
### large max concurrency may result in transport failures
./target/release/cb_blkchn_svc -c cb_blkchn_svc.toml svc load-test-get-addr -l 1000 --mc 175 -p "2b6a375b-93f9-4590-a38d-3a79f8062c8f" -t 0 -n "Slot Token 0/wfdc2/user1/1"

```

## apply linting
```shell
# Optimize Imports for the whole workspace: right-click on the workspace root folder in RustRover IDE and select Optimize Imports.
# unfortunately, the above does not remove unused imports.

# check the whole workspace. it will show unused imports, among other things.
# manually remove unused imports.
cargo check --workspace --all-features  
cargo check --all-features  

# Reformat the whole workspace: right-click on the workspace root folder in RustRover IDE and select Reformat Code.
# Or run the following commands.
cargo fmt --all --check # it will display the proposed changes.
cargo fmt --all

# clippy the whole workspace; review recommendations and make appropriate changes.
cargo clippy --workspace --all-features
## pedantic is too strict, but the docs recommendation may be worth it.
cargo clippy --workspace --all-features -- --warn clippy::pedantic

# fix clippy recommendations: may need to export __CARGO_FIX_YOLO=1
cargo fix #--allow-dirty --allow-staged
cargo clippy --fix #--allow-dirty -- -Dwarnings  
```

## Test Coverage - llvm-cov
```shell
# test default features - alias cov-default-features
cargo cov-default-features
cargo cov-default-features2

cargo cov-default-features --html
open target/llvm-cov/html/index.html      

cargo cov-all-features

# test all features - w/o alias
cargo llvm-cov -vv --text \
  --ignore-filename-regex '.*(/gen/|/src/proto_build/).*' \
  --workspace

cargo llvm-cov \
  --ignore-filename-regex '.*(/gen/|/src/proto_build/).*' \
  --workspace

```

## Test Coverage - tarpaulin
> - .tarpaulin.toml is used to configure tarpaulin options.
```shell
# test default features using .tarpaulin.toml for exclusions
cargo tarpaulin
# test default features with inline exclusions
cargo tarpaulin \
  --exclude-files "gen/**" "src/proto_build/**" \
  --out Html
# this may fail to due to mpc.  
cargo tarpaulin \
  --exclude-files "gen/**" "src/proto_build/**" \
  --all-features --workspace \
  --out Html  
```

## misc
```shell
zip -r cb_blkchn_svc.zip Cargo.toml Cargo.lock src/ \
    -x "src/proto_build/*" \
    -x "src/proto_build.rs" \
    -x "src/.DS_Store"

zip -r root-folder.zip . \
  -x "target/*" \
  -x "gen/*" \
  -x "src/proto_build/*" \
  -x ".idea/*" \
  -x ".git/*"
```