```shell definitions
# chain: 0 = tokenfactory, 1 = bitcoin, 20 = ethereum, 21 = base, 22 = anvil, 50 = solana
# tf denom -  0: uwfUSD; 1: wSAT; 2: wWEI; 3: wLAM
# ntf denom - 0: WFUSD; 1: SAT; 2: WEI; 3: LAM
```
```json GetAddr
{
    "chain": 0,
    "key_info": {
        "key_name": "Slot Token 0/wfdc2/user1/1",
        "key_type": 0,
        "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
    }
}
```
```json GetBalance
{
    "chain": 21,
    "address": "0x24330a631c444117bbb40F79CB8BC22c30250DfD",
    "denom": 0
}
```
```json Send
{
    "chain": 21,
    "value": "1",
    "denom": 0,
    "from_key_info": {
        "key_name": "Slot Token 0/wfdc2/user1/1",
        "key_type": "Secp256k1",
        "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
    },
    "to_address": "0xD35f20c5F239D67d8fFC655D9721d09cfBe1f3DE"
}
```
```json Mint
 {
  "chain": 21,
  "value": "1",
  "denom": 0,
  "minter_key_info": {
    "key_name": "Slot Token 0/wfdc2/minter/1",
    "key_type": "Secp256k1",
    "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
  },
  "to_address": "0x24330a631c444117bbb40F79CB8BC22c30250DfD"
}
```
```json Redeem
{
    "chain": 21,
    "value": "1",
    "denom": 0,
    "from_key_info": {
        "key_name": "Slot Token 0/wfdc2/user1/1",
        "key_type": "Secp256k1",
        "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
    },
    "minter_address": "0xF8b03faDab2d85126D1d4a0281c5f7129b4776a8"
}
```
```json CrossChainSend from evm to tf
{
    "from_chain": 21,
    "from_value": "1",
    "from_denom": 0,
    "from_key_info": {
        "key_name": "Slot Token 0/wfdc2/user1/1",
        "key_type": "Secp256k1",
        "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
    },
    "from_minter_address": "0xF8b03faDab2d85126D1d4a0281c5f7129b4776a8",
    "to_chain": 0,
    "to_value": "1",
    "to_denom": 0,
    "to_minter_key_info": {
        "key_name": "Slot Token 0/wfdc2/minter/1",
        "key_type": "Secp256k1",
        "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
    },
    "to_address": "wf18jvphye4nnlxs4j2p6py3w3ct30emuuq2h7w9q"
}
```
```json CrossChainSend from tf to evm
{
    "from_chain": 0,
    "from_value": "1",
    "from_denom": 0,
    "from_key_info": {
        "key_name": "Slot Token 0/wfdc2/user1/1",
        "key_type": "Secp256k1",
        "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
    },
    "from_minter_address": "wf1kzegqsp06gfsyzkxxzpgfalakl3y2uydphn0qv",
    "to_chain": 21,
    "to_value": "1",
    "to_denom": 0,
    "to_minter_key_info": {
        "key_name": "Slot Token 0/wfdc2/minter/1",
        "key_type": "Secp256k1",
        "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
    },
    "to_address": "0x24330a631c444117bbb40F79CB8BC22c30250DfD"
}
```