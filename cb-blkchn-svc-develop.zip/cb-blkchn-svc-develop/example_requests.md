```shell definitions
```
```json GetAddr
{
    "chain": "Tokenfactory",
    "key_info": {
        "key_name": "Slot Token 0/wfdc2/user1/1",
        "key_type": "Secp256k1",
        "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
    }
}
```
```json GetBalance
{
  "chain": "Base",
  "address": "0x24330a631c444117bbb40F79CB8BC22c30250DfD",
  "denom": "uwfUSD"
}
```
```json send with default chain and with fee info
{
    "value": "10",
    "denom": "uwfUSD",
    "from_key_info": {
        "key_name": "Slot Token 0/wfdc2/user1/1",
        "key_type": "Secp256k1",
        "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
    },
    "to_address": "wf13s7azh9xj3x83amz22tr4z73c4dyj0rvej9my4",
    "fee_info": {
        "pay_by_fee_granter": true
    }
}
```
```json Send
{
  "chain": "Base",
  "value": "1",
  "denom": "uwfUSD",
  "from_key_info": {
    "key_name": "Slot Token 0/wfdc2/user1/1",
    "key_type": "Secp256k1",
    "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
  },
  "to_address": "0xD35f20c5F239D67d8fFC655D9721d09cfBe1f3DE"
}
```
```json Mint on default Tokenfactory chain with fee info
{
  "value": "8",
  "denom": "uwfUSD",
  "minter_key_info": {
    "key_name": "Slot Token 0/wfdc2/minter/1",
    "key_type": "Secp256k1",
    "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
  },
  "to_address": "wf18jvphye4nnlxs4j2p6py3w3ct30emuuq2h7w9q",
  "fee_info": {
    "pay_by_fee_granter": true
  }
} 
```
```json Mint
{
  "chain": "Base",
  "value": "1",
  "denom": "uwfUSD",
  "minter_key_info": {
    "key_name": "Slot Token 0/wfdc2/minter/1",
    "key_type": "Secp256k1",
    "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
  },
  "to_address": "0x24330a631c444117bbb40F79CB8BC22c30250DfD"
} 
```
```json Redeem on default chain with fee info
{
    "value": "1",
    "denom": "uwfUSD",
    "from_key_info": {
        "key_name": "Slot Token 0/wfdc2/usa/1",
        "key_type": "Secp256k1",
        "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
    },
    "minter_address": "wf1kzegqsp06gfsyzkxxzpgfalakl3y2uydphn0qv",
    "fee_info": {
        "pay_by_fee_granter": true
    }
}
```
```json Redeem
{
  "chain": "Base",
  "value": "1",
  "denom": 0,
  "from_key_info": {
    "key_name": "Slot Token 0/wfdc2/user1/1",
    "key_type": "Secp256k1",
    "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
  },
  "minter_address": "0xF8b03faDab2d85126D1d4a0281c5f7129b4776a8"
}
```
```json CrossChainSend from evm to tf
{
  "from_chain": "Base",
  "from_value": "1",
  "from_denom": "uwfUSD",
  "from_key_info": {
    "key_name": "Slot Token 0/wfdc2/user1/1",
    "key_type": "Secp256k1",
    "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
  },
  "from_minter_address": "0xF8b03faDab2d85126D1d4a0281c5f7129b4776a8",
  "to_chain": "Tokenfactory",
  "to_value": "1",
  "to_denom": "uwfUSD",
  "to_minter_key_info": {
    "key_name": "Slot Token 0/wfdc2/minter/1",
    "key_type": "Secp256k1",
    "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
  },
  "to_address": "wf18jvphye4nnlxs4j2p6py3w3ct30emuuq2h7w9q"
}
```
```json CrossChainSend from tf to evm
{
  "from_chain": "Tokenfactory",
  "from_value": "1",
  "from_denom": "uwfUSD",
  "from_key_info": {
    "key_name": "Slot Token 0/wfdc2/user1/1",
    "key_type": "Secp256k1",
    "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
  },
  "from_minter_address": "wf1kzegqsp06gfsyzkxxzpgfalakl3y2uydphn0qv",
  "to_chain": "Base",
  "to_value": "1",
  "to_denom": "uwfUSD",
  "to_minter_key_info": {
    "key_name": "Slot Token 0/wfdc2/minter/1",
    "key_type": "Secp256k1",
    "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
  },
  "to_address": "0x24330a631c444117bbb40F79CB8BC22c30250DfD"
}
```
```json GrantFeeBasicAllowance
{
    "chain": "Tokenfactory",
    "allowance_denom": "uwfUSD",
    "allowance_value": "2000000",
    "grantee": "wf12atm0klmhpp6mp768gf0esxmwcjx8mmazagyvf", 
    "granter": {
        "key_name": "Slot Token 0/wfdc2/faucet/1",
        "key_type": "Secp256k1",
        "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
    },
    "hours_to_expire": "2400"
}
```
```json query GetFeeBasicAllowance
{
    "chain": "Tokenfactory",
    "grantee": "wf12atm0klmhpp6mp768gf0esxmwcjx8mmazagyvf"
}
```