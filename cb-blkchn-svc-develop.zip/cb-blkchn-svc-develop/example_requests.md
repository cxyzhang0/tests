```shell definitions
```
```json GetAddr
{
    "chain": "Tokenfactory",
    "key_info": {
        "key_name": "Slot Token 0/wfdc2/user1/1",
        "key_type": "Secp256k1",
        "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
    }
}
```
```json GetBalance
{
  "chain": "Base",
  "address": "0x24330a631c444117bbb40F79CB8BC22c30250DfD",
  "denom": "uwfUSD"
}
```
```json send
{
    "chain": "Tokenfactory",
    "from_key_info": {
        "key_name": "Slot Token 0/wfdc2/user1/1",
        "key_type": "Secp256k1",
        "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
    },
    "to_address": "wf13s7azh9xj3x83amz22tr4z73c4dyj0rvej9my4",
    "value": "10",
    "denom": "uwfGBP",
    "fee_info": {
        "pay_by_fee_granter": true
    },
    "tracking_info": {
      "tracking_id": "{{$guid}}"
    }
}
```
```json Send
{
  "chain": "Base",
  "value": "1",
  "denom": "uwfUSD",
  "from_key_info": {
    "key_name": "Slot Token 0/wfdc2/user1/1",
    "key_type": "Secp256k1",
    "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
  },
  "to_address": "0xD35f20c5F239D67d8fFC655D9721d09cfBe1f3DE"
}
```
```json Mint
{
  "chain": "Tokenfactory",
  "minter_key_info": {
    "key_name": "Slot Token 0/wfdc2/minter/1",
    "key_type": "Secp256k1",
    "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
  },
  "to_address": "wf18jvphye4nnlxs4j2p6py3w3ct30emuuq2h7w9q",
  "value": "100",
  "denom": "uwfGBP",
  "fee_info": {
    "pay_by_fee_granter": true
  },
  "tracking_info": {
    "tracking_id": "{{$guid}}"
  }
} 
```
```json Mint
{
  "chain": "Base",
  "value": "1",
  "denom": "uwfUSD",
  "minter_key_info": {
    "key_name": "Slot Token 0/wfdc2/minter/1",
    "key_type": "Secp256k1",
    "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
  },
  "to_address": "0x24330a631c444117bbb40F79CB8BC22c30250DfD"
} 
```
```json Redeem
{
    "chain": "Tokenfactory",
    "from_key_info": {
        "key_name": "Slot Token 0/wfdc2/usa/1",
        "key_type": "Secp256k1",
        "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
    },
    "minter_address": "wf1kzegqsp06gfsyzkxxzpgfalakl3y2uydphn0qv",
    "value": "100",
    "denom": "uwfGBP",
    "fee_info": {
        "pay_by_fee_granter": true
    },
    "tracking_info": {
      "tracking_id": "{{$guid}}"
    }
}
```
```json Redeem
{
  "chain": "Base",
  "value": "1",
  "denom": 0,
  "from_key_info": {
    "key_name": "Slot Token 0/wfdc2/user1/1",
    "key_type": "Secp256k1",
    "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
  },
  "minter_address": "0xF8b03faDab2d85126D1d4a0281c5f7129b4776a8"
}
```
```json CrossChainSend from evm to tf
{
  "from_chain": "Base",
  "from_value": "1",
  "from_denom": "uwfUSD",
  "from_key_info": {
    "key_name": "Slot Token 0/wfdc2/user1/1",
    "key_type": "Secp256k1",
    "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
  },
  "from_minter_address": "0xF8b03faDab2d85126D1d4a0281c5f7129b4776a8",
  "to_chain": "Tokenfactory",
  "to_value": "1",
  "to_denom": "uwfUSD",
  "to_minter_key_info": {
    "key_name": "Slot Token 0/wfdc2/minter/1",
    "key_type": "Secp256k1",
    "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
  },
  "to_address": "wf18jvphye4nnlxs4j2p6py3w3ct30emuuq2h7w9q"
}
```
```json CrossChainSend from tf to evm
{
  "from_chain": "Tokenfactory",
  "from_value": "1",
  "from_denom": "uwfUSD",
  "from_key_info": {
    "key_name": "Slot Token 0/wfdc2/user1/1",
    "key_type": "Secp256k1",
    "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
  },
  "from_minter_address": "wf1kzegqsp06gfsyzkxxzpgfalakl3y2uydphn0qv",
  "to_chain": "Base",
  "to_value": "1",
  "to_denom": "uwfUSD",
  "to_minter_key_info": {
    "key_name": "Slot Token 0/wfdc2/minter/1",
    "key_type": "Secp256k1",
    "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
  },
  "to_address": "0x24330a631c444117bbb40F79CB8BC22c30250DfD"
}
```
```json GrantFeeBasicAllowance
{
    "chain": "Tokenfactory",
    "grantee": "wf12atm0klmhpp6mp768gf0esxmwcjx8mmazagyvf", 
    "granter": {
        "key_name": "Slot Token 0/wfdc2/faucet/1",
        "key_type": "Secp256k1",
        "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
    },
    "allowance_denom": "uwfUSD",
    "allowance_value": "2000000",
    "hours_to_expire": "2400",
    "tracking_info": {
      "tracking_id": "{{$guid}}"
    }
}
```
```json RevokeFeeBasicAllowance
{
    "chain": "Tokenfactory",
    "grantee": "wf16f4zjgvu0m5msxh552vx9wqcv78hru9j50ymdj",
    "granter_key_info": {
        "key_name": "Slot Token 0/wfdc2/faucet/1",
        "key_type": "Secp256k1",
        "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
    },
    "tracking_info": {
        "tracking_id": "{{$guid}}"
    }
}
```
```json query GetFeeBasicAllowance
{
    "chain": "Tokenfactory",
    "grantee": "wf12atm0klmhpp6mp768gf0esxmwcjx8mmazagyvf"
}
```
```json GetTxStatus
{
    "chain": "Tokenfactory",
    "txhash": "AC9FD0209E782F18F817375BB9B3848EA23C8578206271BA45A0DF03056D9EE7"
}
```
```json SetDenomMetadata
{
    "chain": "Tokenfactory",
    "masterminter_key_info": {
        "key_name": "Slot Token 0/wfdc2/masterminter/1",
        "key_type": "Secp256k1",
        "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
    },
    "metadata": {
        "denom_units": [
            {
                "aliases": [],
                "denom": "uwfGBP",
                "exponent": 0
            },
            {
                "aliases": [
                    "Penny"
                ],
                "denom": "wfPENNY",
                "exponent": 4
            },
            {
                "aliases": [
                    "GBP"
                ],
                "denom": "wfGBP",
                "exponent": 6
            }
        ],
        "description": "WF Tokenized GBP Deposits Issued on Tokenfactory",
        "base": "uwfGBP",
        "display": "wfGBP",
        "name": "Tokenized GBP Deposits",
        "symbol": "wfGBP",
        "uri": "",
        "uri_hash": ""
    },
     "fee_info": {
        "pay_by_fee_granter": true
    },
   "tracking_info": {
        "tracking_id": "{{$guid}}"
    }
}
```
```json GetDenomMetadata
{
    "chain": "Tokenfactory",
    "denom": "uwfGBP"
}
```
```json GetAllDenomMetadata
{
    "chain": "Tokenfactory"
}
```
```json ConfigureMinter
{
    "chain": "Tokenfactory",
    "address": "wf1kzegqsp06gfsyzkxxzpgfalakl3y2uydphn0qv",
    "mintercontroller_key_info": {
        "key_name": "Slot Token 0/wfdc2/mintercontroller/1",
        "key_type": "Secp256k1",
        "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
    },
    "allowance_denom": "uwfGBP",
    "allowance_value": "2000000000",
    "fee_info": {
        "pay_by_fee_granter": true
    },
    "tracking_info": {
        "tracking_id": "{{$guid}}"
    }
}
```
```json RemoveMinter
{
    "chain": "Tokenfactory",
    "address": "wf1kzegqsp06gfsyzkxxzpgfalakl3y2uydphn0qv",
    "mintercontroller_key_info": {
        "key_name": "Slot Token 0/wfdc2/mintercontroller/1",
        "key_type": "Secp256k1",
        "kms_provider_uuid": "{{kms-p11hsm-softhsm-provider}}"
    },
    "denom": "uwfGBP",
    "fee_info": {
        "pay_by_fee_granter": true
    },
    "tracking_info": {
        "tracking_id": "{{$guid}}"
    }
}
```