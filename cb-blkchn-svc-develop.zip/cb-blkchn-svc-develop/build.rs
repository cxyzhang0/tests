use std::path::PathBuf;

fn main() {
    let out_dir = PathBuf::from("src/proto_build");
    // let out_dir = PathBuf::from(env::var("OUT_DIR").unwrap());
    tonic_build::configure()
        .out_dir(out_dir.clone())
        .file_descriptor_set_path(out_dir.join("blkchn_svc_descriptor.bin"))
        .protoc_arg("--experimental_allow_proto3_optional")
        .compile_protos(&["proto/blkchn-svc/v1/service.proto"], &["proto"])
        .unwrap();
}
