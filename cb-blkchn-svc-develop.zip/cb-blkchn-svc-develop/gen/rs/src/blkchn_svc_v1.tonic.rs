// @generated
/// Generated client implementations.
pub mod blkchn_svc_client {
    #![allow(unused_variables, dead_code, missing_docs, clippy::let_unit_value)]
    use tonic::codegen::*;
    use tonic::codegen::http::Uri;
    ///
    #[derive(Debug, Clone)]
    pub struct BlkchnSvcClient<T> {
        inner: tonic::client::Grpc<T>,
    }
    impl BlkchnSvcClient<tonic::transport::Channel> {
        /// Attempt to create a new client by connecting to a given endpoint.
        pub async fn connect<D>(dst: D) -> Result<Self, tonic::transport::Error>
        where
            D: TryInto<tonic::transport::Endpoint>,
            D::Error: Into<StdError>,
        {
            let conn = tonic::transport::Endpoint::new(dst)?.connect().await?;
            Ok(Self::new(conn))
        }
    }
    impl<T> BlkchnSvcClient<T>
    where
        T: tonic::client::GrpcService<tonic::body::BoxBody>,
        T::Error: Into<StdError>,
        T::ResponseBody: Body<Data = Bytes> + Send + 'static,
        <T::ResponseBody as Body>::Error: Into<StdError> + Send,
    {
        pub fn new(inner: T) -> Self {
            let inner = tonic::client::Grpc::new(inner);
            Self { inner }
        }
        pub fn with_origin(inner: T, origin: Uri) -> Self {
            let inner = tonic::client::Grpc::with_origin(inner, origin);
            Self { inner }
        }
        pub fn with_interceptor<F>(
            inner: T,
            interceptor: F,
        ) -> BlkchnSvcClient<InterceptedService<T, F>>
        where
            F: tonic::service::Interceptor,
            T::ResponseBody: Default,
            T: tonic::codegen::Service<
                http::Request<tonic::body::BoxBody>,
                Response = http::Response<
                    <T as tonic::client::GrpcService<tonic::body::BoxBody>>::ResponseBody,
                >,
            >,
            <T as tonic::codegen::Service<
                http::Request<tonic::body::BoxBody>,
            >>::Error: Into<StdError> + Send + Sync,
        {
            BlkchnSvcClient::new(InterceptedService::new(inner, interceptor))
        }
        /// Compress requests with the given encoding.
        ///
        /// This requires the server to support it otherwise it might respond with an
        /// error.
        #[must_use]
        pub fn send_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.inner = self.inner.send_compressed(encoding);
            self
        }
        /// Enable decompressing responses.
        #[must_use]
        pub fn accept_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.inner = self.inner.accept_compressed(encoding);
            self
        }
        /// Limits the maximum size of a decoded message.
        ///
        /// Default: `4MB`
        #[must_use]
        pub fn max_decoding_message_size(mut self, limit: usize) -> Self {
            self.inner = self.inner.max_decoding_message_size(limit);
            self
        }
        /// Limits the maximum size of an encoded message.
        ///
        /// Default: `usize::MAX`
        #[must_use]
        pub fn max_encoding_message_size(mut self, limit: usize) -> Self {
            self.inner = self.inner.max_encoding_message_size(limit);
            self
        }
        ///
        pub async fn get_addr(
            &mut self,
            request: impl tonic::IntoRequest<super::GetAddrRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetAddrResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/blkchn_svc_v1.BlkchnSvc/GetAddr",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("blkchn_svc_v1.BlkchnSvc", "GetAddr"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn get_balance(
            &mut self,
            request: impl tonic::IntoRequest<super::GetBalanceRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetBalanceResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/blkchn_svc_v1.BlkchnSvc/GetBalance",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("blkchn_svc_v1.BlkchnSvc", "GetBalance"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn send(
            &mut self,
            request: impl tonic::IntoRequest<super::SendRequest>,
        ) -> std::result::Result<
            tonic::Response<super::CommonTxResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/blkchn_svc_v1.BlkchnSvc/Send",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("blkchn_svc_v1.BlkchnSvc", "Send"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn mint(
            &mut self,
            request: impl tonic::IntoRequest<super::MintRequest>,
        ) -> std::result::Result<
            tonic::Response<super::CommonTxResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/blkchn_svc_v1.BlkchnSvc/Mint",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("blkchn_svc_v1.BlkchnSvc", "Mint"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn redeem(
            &mut self,
            request: impl tonic::IntoRequest<super::RedeemRequest>,
        ) -> std::result::Result<
            tonic::Response<super::CommonTxResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/blkchn_svc_v1.BlkchnSvc/Redeem",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("blkchn_svc_v1.BlkchnSvc", "Redeem"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn cross_chain_send(
            &mut self,
            request: impl tonic::IntoRequest<super::CrossChainSendRequest>,
        ) -> std::result::Result<
            tonic::Response<super::CrossChainSendResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/blkchn_svc_v1.BlkchnSvc/CrossChainSend",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("blkchn_svc_v1.BlkchnSvc", "CrossChainSend"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn grant_fee_basic_allowance(
            &mut self,
            request: impl tonic::IntoRequest<super::GrantFeeBasicAllowanceRequest>,
        ) -> std::result::Result<
            tonic::Response<super::CommonTxResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/blkchn_svc_v1.BlkchnSvc/GrantFeeBasicAllowance",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new("blkchn_svc_v1.BlkchnSvc", "GrantFeeBasicAllowance"),
                );
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn revoke_fee_basic_allowance(
            &mut self,
            request: impl tonic::IntoRequest<super::RevokeFeeBasicAllowanceRequest>,
        ) -> std::result::Result<
            tonic::Response<super::CommonTxResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/blkchn_svc_v1.BlkchnSvc/RevokeFeeBasicAllowance",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new("blkchn_svc_v1.BlkchnSvc", "RevokeFeeBasicAllowance"),
                );
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn get_fee_basic_allowance(
            &mut self,
            request: impl tonic::IntoRequest<super::GetFeeBasicAllowanceRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetFeeBasicAllowanceResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/blkchn_svc_v1.BlkchnSvc/GetFeeBasicAllowance",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new("blkchn_svc_v1.BlkchnSvc", "GetFeeBasicAllowance"),
                );
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn get_tx_status(
            &mut self,
            request: impl tonic::IntoRequest<super::GetTxStatusRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetTxStatusResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/blkchn_svc_v1.BlkchnSvc/GetTxStatus",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("blkchn_svc_v1.BlkchnSvc", "GetTxStatus"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn set_denom_metadata(
            &mut self,
            request: impl tonic::IntoRequest<super::SetDenomMetadataRequest>,
        ) -> std::result::Result<
            tonic::Response<super::CommonTxResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/blkchn_svc_v1.BlkchnSvc/SetDenomMetadata",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("blkchn_svc_v1.BlkchnSvc", "SetDenomMetadata"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn get_denom_metadata(
            &mut self,
            request: impl tonic::IntoRequest<super::GetDenomMetadataRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetDenomMetadataResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/blkchn_svc_v1.BlkchnSvc/GetDenomMetadata",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("blkchn_svc_v1.BlkchnSvc", "GetDenomMetadata"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn get_all_denom_metadata(
            &mut self,
            request: impl tonic::IntoRequest<super::GetAllDenomMetadataRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetAllDenomMetadataResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/blkchn_svc_v1.BlkchnSvc/GetAllDenomMetadata",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new("blkchn_svc_v1.BlkchnSvc", "GetAllDenomMetadata"),
                );
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn configure_minter(
            &mut self,
            request: impl tonic::IntoRequest<super::ConfigureMinterRequest>,
        ) -> std::result::Result<
            tonic::Response<super::CommonTxResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/blkchn_svc_v1.BlkchnSvc/ConfigureMinter",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("blkchn_svc_v1.BlkchnSvc", "ConfigureMinter"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn remove_minter(
            &mut self,
            request: impl tonic::IntoRequest<super::RemoveMinterRequest>,
        ) -> std::result::Result<
            tonic::Response<super::CommonTxResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/blkchn_svc_v1.BlkchnSvc/RemoveMinter",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("blkchn_svc_v1.BlkchnSvc", "RemoveMinter"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn get_minter(
            &mut self,
            request: impl tonic::IntoRequest<super::GetMinterRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetMinterResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/blkchn_svc_v1.BlkchnSvc/GetMinter",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("blkchn_svc_v1.BlkchnSvc", "GetMinter"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn get_all_minters(
            &mut self,
            request: impl tonic::IntoRequest<super::GetAllMintersRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetAllMintersResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/blkchn_svc_v1.BlkchnSvc/GetAllMinters",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("blkchn_svc_v1.BlkchnSvc", "GetAllMinters"));
            self.inner.unary(req, path, codec).await
        }
    }
}
/// Generated server implementations.
pub mod blkchn_svc_server {
    #![allow(unused_variables, dead_code, missing_docs, clippy::let_unit_value)]
    use tonic::codegen::*;
    /// Generated trait containing gRPC methods that should be implemented for use with BlkchnSvcServer.
    #[async_trait]
    pub trait BlkchnSvc: Send + Sync + 'static {
        ///
        async fn get_addr(
            &self,
            request: tonic::Request<super::GetAddrRequest>,
        ) -> std::result::Result<tonic::Response<super::GetAddrResponse>, tonic::Status>;
        ///
        async fn get_balance(
            &self,
            request: tonic::Request<super::GetBalanceRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetBalanceResponse>,
            tonic::Status,
        >;
        ///
        async fn send(
            &self,
            request: tonic::Request<super::SendRequest>,
        ) -> std::result::Result<
            tonic::Response<super::CommonTxResponse>,
            tonic::Status,
        >;
        ///
        async fn mint(
            &self,
            request: tonic::Request<super::MintRequest>,
        ) -> std::result::Result<
            tonic::Response<super::CommonTxResponse>,
            tonic::Status,
        >;
        ///
        async fn redeem(
            &self,
            request: tonic::Request<super::RedeemRequest>,
        ) -> std::result::Result<
            tonic::Response<super::CommonTxResponse>,
            tonic::Status,
        >;
        ///
        async fn cross_chain_send(
            &self,
            request: tonic::Request<super::CrossChainSendRequest>,
        ) -> std::result::Result<
            tonic::Response<super::CrossChainSendResponse>,
            tonic::Status,
        >;
        ///
        async fn grant_fee_basic_allowance(
            &self,
            request: tonic::Request<super::GrantFeeBasicAllowanceRequest>,
        ) -> std::result::Result<
            tonic::Response<super::CommonTxResponse>,
            tonic::Status,
        >;
        ///
        async fn revoke_fee_basic_allowance(
            &self,
            request: tonic::Request<super::RevokeFeeBasicAllowanceRequest>,
        ) -> std::result::Result<
            tonic::Response<super::CommonTxResponse>,
            tonic::Status,
        >;
        ///
        async fn get_fee_basic_allowance(
            &self,
            request: tonic::Request<super::GetFeeBasicAllowanceRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetFeeBasicAllowanceResponse>,
            tonic::Status,
        >;
        ///
        async fn get_tx_status(
            &self,
            request: tonic::Request<super::GetTxStatusRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetTxStatusResponse>,
            tonic::Status,
        >;
        ///
        async fn set_denom_metadata(
            &self,
            request: tonic::Request<super::SetDenomMetadataRequest>,
        ) -> std::result::Result<
            tonic::Response<super::CommonTxResponse>,
            tonic::Status,
        >;
        ///
        async fn get_denom_metadata(
            &self,
            request: tonic::Request<super::GetDenomMetadataRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetDenomMetadataResponse>,
            tonic::Status,
        >;
        ///
        async fn get_all_denom_metadata(
            &self,
            request: tonic::Request<super::GetAllDenomMetadataRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetAllDenomMetadataResponse>,
            tonic::Status,
        >;
        ///
        async fn configure_minter(
            &self,
            request: tonic::Request<super::ConfigureMinterRequest>,
        ) -> std::result::Result<
            tonic::Response<super::CommonTxResponse>,
            tonic::Status,
        >;
        ///
        async fn remove_minter(
            &self,
            request: tonic::Request<super::RemoveMinterRequest>,
        ) -> std::result::Result<
            tonic::Response<super::CommonTxResponse>,
            tonic::Status,
        >;
        ///
        async fn get_minter(
            &self,
            request: tonic::Request<super::GetMinterRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetMinterResponse>,
            tonic::Status,
        >;
        ///
        async fn get_all_minters(
            &self,
            request: tonic::Request<super::GetAllMintersRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetAllMintersResponse>,
            tonic::Status,
        >;
    }
    ///
    #[derive(Debug)]
    pub struct BlkchnSvcServer<T: BlkchnSvc> {
        inner: _Inner<T>,
        accept_compression_encodings: EnabledCompressionEncodings,
        send_compression_encodings: EnabledCompressionEncodings,
        max_decoding_message_size: Option<usize>,
        max_encoding_message_size: Option<usize>,
    }
    struct _Inner<T>(Arc<T>);
    impl<T: BlkchnSvc> BlkchnSvcServer<T> {
        pub fn new(inner: T) -> Self {
            Self::from_arc(Arc::new(inner))
        }
        pub fn from_arc(inner: Arc<T>) -> Self {
            let inner = _Inner(inner);
            Self {
                inner,
                accept_compression_encodings: Default::default(),
                send_compression_encodings: Default::default(),
                max_decoding_message_size: None,
                max_encoding_message_size: None,
            }
        }
        pub fn with_interceptor<F>(
            inner: T,
            interceptor: F,
        ) -> InterceptedService<Self, F>
        where
            F: tonic::service::Interceptor,
        {
            InterceptedService::new(Self::new(inner), interceptor)
        }
        /// Enable decompressing requests with the given encoding.
        #[must_use]
        pub fn accept_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.accept_compression_encodings.enable(encoding);
            self
        }
        /// Compress responses with the given encoding, if the client supports it.
        #[must_use]
        pub fn send_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.send_compression_encodings.enable(encoding);
            self
        }
        /// Limits the maximum size of a decoded message.
        ///
        /// Default: `4MB`
        #[must_use]
        pub fn max_decoding_message_size(mut self, limit: usize) -> Self {
            self.max_decoding_message_size = Some(limit);
            self
        }
        /// Limits the maximum size of an encoded message.
        ///
        /// Default: `usize::MAX`
        #[must_use]
        pub fn max_encoding_message_size(mut self, limit: usize) -> Self {
            self.max_encoding_message_size = Some(limit);
            self
        }
    }
    impl<T, B> tonic::codegen::Service<http::Request<B>> for BlkchnSvcServer<T>
    where
        T: BlkchnSvc,
        B: Body + Send + 'static,
        B::Error: Into<StdError> + Send + 'static,
    {
        type Response = http::Response<tonic::body::BoxBody>;
        type Error = std::convert::Infallible;
        type Future = BoxFuture<Self::Response, Self::Error>;
        fn poll_ready(
            &mut self,
            _cx: &mut Context<'_>,
        ) -> Poll<std::result::Result<(), Self::Error>> {
            Poll::Ready(Ok(()))
        }
        fn call(&mut self, req: http::Request<B>) -> Self::Future {
            let inner = self.inner.clone();
            match req.uri().path() {
                "/blkchn_svc_v1.BlkchnSvc/GetAddr" => {
                    #[allow(non_camel_case_types)]
                    struct GetAddrSvc<T: BlkchnSvc>(pub Arc<T>);
                    impl<T: BlkchnSvc> tonic::server::UnaryService<super::GetAddrRequest>
                    for GetAddrSvc<T> {
                        type Response = super::GetAddrResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetAddrRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as BlkchnSvc>::get_addr(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetAddrSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/blkchn_svc_v1.BlkchnSvc/GetBalance" => {
                    #[allow(non_camel_case_types)]
                    struct GetBalanceSvc<T: BlkchnSvc>(pub Arc<T>);
                    impl<
                        T: BlkchnSvc,
                    > tonic::server::UnaryService<super::GetBalanceRequest>
                    for GetBalanceSvc<T> {
                        type Response = super::GetBalanceResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetBalanceRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as BlkchnSvc>::get_balance(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetBalanceSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/blkchn_svc_v1.BlkchnSvc/Send" => {
                    #[allow(non_camel_case_types)]
                    struct SendSvc<T: BlkchnSvc>(pub Arc<T>);
                    impl<T: BlkchnSvc> tonic::server::UnaryService<super::SendRequest>
                    for SendSvc<T> {
                        type Response = super::CommonTxResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::SendRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as BlkchnSvc>::send(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = SendSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/blkchn_svc_v1.BlkchnSvc/Mint" => {
                    #[allow(non_camel_case_types)]
                    struct MintSvc<T: BlkchnSvc>(pub Arc<T>);
                    impl<T: BlkchnSvc> tonic::server::UnaryService<super::MintRequest>
                    for MintSvc<T> {
                        type Response = super::CommonTxResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::MintRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as BlkchnSvc>::mint(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = MintSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/blkchn_svc_v1.BlkchnSvc/Redeem" => {
                    #[allow(non_camel_case_types)]
                    struct RedeemSvc<T: BlkchnSvc>(pub Arc<T>);
                    impl<T: BlkchnSvc> tonic::server::UnaryService<super::RedeemRequest>
                    for RedeemSvc<T> {
                        type Response = super::CommonTxResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::RedeemRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as BlkchnSvc>::redeem(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = RedeemSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/blkchn_svc_v1.BlkchnSvc/CrossChainSend" => {
                    #[allow(non_camel_case_types)]
                    struct CrossChainSendSvc<T: BlkchnSvc>(pub Arc<T>);
                    impl<
                        T: BlkchnSvc,
                    > tonic::server::UnaryService<super::CrossChainSendRequest>
                    for CrossChainSendSvc<T> {
                        type Response = super::CrossChainSendResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::CrossChainSendRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as BlkchnSvc>::cross_chain_send(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = CrossChainSendSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/blkchn_svc_v1.BlkchnSvc/GrantFeeBasicAllowance" => {
                    #[allow(non_camel_case_types)]
                    struct GrantFeeBasicAllowanceSvc<T: BlkchnSvc>(pub Arc<T>);
                    impl<
                        T: BlkchnSvc,
                    > tonic::server::UnaryService<super::GrantFeeBasicAllowanceRequest>
                    for GrantFeeBasicAllowanceSvc<T> {
                        type Response = super::CommonTxResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GrantFeeBasicAllowanceRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as BlkchnSvc>::grant_fee_basic_allowance(&inner, request)
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GrantFeeBasicAllowanceSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/blkchn_svc_v1.BlkchnSvc/RevokeFeeBasicAllowance" => {
                    #[allow(non_camel_case_types)]
                    struct RevokeFeeBasicAllowanceSvc<T: BlkchnSvc>(pub Arc<T>);
                    impl<
                        T: BlkchnSvc,
                    > tonic::server::UnaryService<super::RevokeFeeBasicAllowanceRequest>
                    for RevokeFeeBasicAllowanceSvc<T> {
                        type Response = super::CommonTxResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<
                                super::RevokeFeeBasicAllowanceRequest,
                            >,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as BlkchnSvc>::revoke_fee_basic_allowance(
                                        &inner,
                                        request,
                                    )
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = RevokeFeeBasicAllowanceSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/blkchn_svc_v1.BlkchnSvc/GetFeeBasicAllowance" => {
                    #[allow(non_camel_case_types)]
                    struct GetFeeBasicAllowanceSvc<T: BlkchnSvc>(pub Arc<T>);
                    impl<
                        T: BlkchnSvc,
                    > tonic::server::UnaryService<super::GetFeeBasicAllowanceRequest>
                    for GetFeeBasicAllowanceSvc<T> {
                        type Response = super::GetFeeBasicAllowanceResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetFeeBasicAllowanceRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as BlkchnSvc>::get_fee_basic_allowance(&inner, request)
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetFeeBasicAllowanceSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/blkchn_svc_v1.BlkchnSvc/GetTxStatus" => {
                    #[allow(non_camel_case_types)]
                    struct GetTxStatusSvc<T: BlkchnSvc>(pub Arc<T>);
                    impl<
                        T: BlkchnSvc,
                    > tonic::server::UnaryService<super::GetTxStatusRequest>
                    for GetTxStatusSvc<T> {
                        type Response = super::GetTxStatusResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetTxStatusRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as BlkchnSvc>::get_tx_status(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetTxStatusSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/blkchn_svc_v1.BlkchnSvc/SetDenomMetadata" => {
                    #[allow(non_camel_case_types)]
                    struct SetDenomMetadataSvc<T: BlkchnSvc>(pub Arc<T>);
                    impl<
                        T: BlkchnSvc,
                    > tonic::server::UnaryService<super::SetDenomMetadataRequest>
                    for SetDenomMetadataSvc<T> {
                        type Response = super::CommonTxResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::SetDenomMetadataRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as BlkchnSvc>::set_denom_metadata(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = SetDenomMetadataSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/blkchn_svc_v1.BlkchnSvc/GetDenomMetadata" => {
                    #[allow(non_camel_case_types)]
                    struct GetDenomMetadataSvc<T: BlkchnSvc>(pub Arc<T>);
                    impl<
                        T: BlkchnSvc,
                    > tonic::server::UnaryService<super::GetDenomMetadataRequest>
                    for GetDenomMetadataSvc<T> {
                        type Response = super::GetDenomMetadataResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetDenomMetadataRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as BlkchnSvc>::get_denom_metadata(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetDenomMetadataSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/blkchn_svc_v1.BlkchnSvc/GetAllDenomMetadata" => {
                    #[allow(non_camel_case_types)]
                    struct GetAllDenomMetadataSvc<T: BlkchnSvc>(pub Arc<T>);
                    impl<
                        T: BlkchnSvc,
                    > tonic::server::UnaryService<super::GetAllDenomMetadataRequest>
                    for GetAllDenomMetadataSvc<T> {
                        type Response = super::GetAllDenomMetadataResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetAllDenomMetadataRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as BlkchnSvc>::get_all_denom_metadata(&inner, request)
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetAllDenomMetadataSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/blkchn_svc_v1.BlkchnSvc/ConfigureMinter" => {
                    #[allow(non_camel_case_types)]
                    struct ConfigureMinterSvc<T: BlkchnSvc>(pub Arc<T>);
                    impl<
                        T: BlkchnSvc,
                    > tonic::server::UnaryService<super::ConfigureMinterRequest>
                    for ConfigureMinterSvc<T> {
                        type Response = super::CommonTxResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::ConfigureMinterRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as BlkchnSvc>::configure_minter(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = ConfigureMinterSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/blkchn_svc_v1.BlkchnSvc/RemoveMinter" => {
                    #[allow(non_camel_case_types)]
                    struct RemoveMinterSvc<T: BlkchnSvc>(pub Arc<T>);
                    impl<
                        T: BlkchnSvc,
                    > tonic::server::UnaryService<super::RemoveMinterRequest>
                    for RemoveMinterSvc<T> {
                        type Response = super::CommonTxResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::RemoveMinterRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as BlkchnSvc>::remove_minter(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = RemoveMinterSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/blkchn_svc_v1.BlkchnSvc/GetMinter" => {
                    #[allow(non_camel_case_types)]
                    struct GetMinterSvc<T: BlkchnSvc>(pub Arc<T>);
                    impl<
                        T: BlkchnSvc,
                    > tonic::server::UnaryService<super::GetMinterRequest>
                    for GetMinterSvc<T> {
                        type Response = super::GetMinterResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetMinterRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as BlkchnSvc>::get_minter(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetMinterSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/blkchn_svc_v1.BlkchnSvc/GetAllMinters" => {
                    #[allow(non_camel_case_types)]
                    struct GetAllMintersSvc<T: BlkchnSvc>(pub Arc<T>);
                    impl<
                        T: BlkchnSvc,
                    > tonic::server::UnaryService<super::GetAllMintersRequest>
                    for GetAllMintersSvc<T> {
                        type Response = super::GetAllMintersResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetAllMintersRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as BlkchnSvc>::get_all_minters(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetAllMintersSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                _ => {
                    Box::pin(async move {
                        Ok(
                            http::Response::builder()
                                .status(200)
                                .header("grpc-status", "12")
                                .header("content-type", "application/grpc")
                                .body(empty_body())
                                .unwrap(),
                        )
                    })
                }
            }
        }
    }
    impl<T: BlkchnSvc> Clone for BlkchnSvcServer<T> {
        fn clone(&self) -> Self {
            let inner = self.inner.clone();
            Self {
                inner,
                accept_compression_encodings: self.accept_compression_encodings,
                send_compression_encodings: self.send_compression_encodings,
                max_decoding_message_size: self.max_decoding_message_size,
                max_encoding_message_size: self.max_encoding_message_size,
            }
        }
    }
    impl<T: BlkchnSvc> Clone for _Inner<T> {
        fn clone(&self) -> Self {
            Self(Arc::clone(&self.0))
        }
    }
    impl<T: std::fmt::Debug> std::fmt::Debug for _Inner<T> {
        fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
            write!(f, "{:?}", self.0)
        }
    }
    impl<T: BlkchnSvc> tonic::server::NamedService for BlkchnSvcServer<T> {
        const NAME: &'static str = "blkchn_svc_v1.BlkchnSvc";
    }
}
