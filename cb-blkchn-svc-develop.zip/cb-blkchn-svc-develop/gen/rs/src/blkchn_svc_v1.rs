// @generated
// TokenType is replaced by TfDenom and NtfDenom

//
// enum TokenType {
// // ("wfusd")
// Wfusd = 0;
// // ("btc")
// Btc = 1;
// // ("ether")
// Ether = 2;
// }

#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct KeyInfo {
    #[prost(string, tag="1")]
    pub kms_provider_uuid: ::prost::alloc::string::String,
    #[prost(enumeration="KeyType", tag="2")]
    pub key_type: i32,
    #[prost(string, tag="3")]
    pub key_name: ::prost::alloc::string::String,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum KeyType {
    /// ("Secp256k1")
    Secp256k1 = 0,
    /// ("Ed25519")
    Ed25519 = 1,
    /// ("Secp256r1")
    Secp256r1 = 2,
    /// ("Rsa2048")
    Rsa2048 = 3,
    /// ("Aes")
    Aes = 4,
}
impl KeyType {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            KeyType::Secp256k1 => "Secp256k1",
            KeyType::Ed25519 => "Ed25519",
            KeyType::Secp256r1 => "Secp256r1",
            KeyType::Rsa2048 => "Rsa2048",
            KeyType::Aes => "Aes",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "Secp256k1" => Some(Self::Secp256k1),
            "Ed25519" => Some(Self::Ed25519),
            "Secp256r1" => Some(Self::Secp256r1),
            "Rsa2048" => Some(Self::Rsa2048),
            "Aes" => Some(Self::Aes),
            _ => None,
        }
    }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum TfDenom {
    /// ("uwfUSD")
    UwfUsd = 0,
    /// ("wSAT")
    WSat = 1,
    /// ("wWEI")
    WWei = 2,
    /// ("wLAM")
    WLam = 3,
}
impl TfDenom {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            TfDenom::UwfUsd => "uwfUSD",
            TfDenom::WSat => "wSAT",
            TfDenom::WWei => "wWEI",
            TfDenom::WLam => "wLAM",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "uwfUSD" => Some(Self::UwfUsd),
            "wSAT" => Some(Self::WSat),
            "wWEI" => Some(Self::WWei),
            "wLAM" => Some(Self::WLam),
            _ => None,
        }
    }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum NtfDenom {
    /// ("Dummy")
    Dummy = 0,
    /// ("SAT")
    Sat = 1,
    /// ("WEI")
    Wei = 2,
    /// ("LAM")
    Lam = 3,
}
impl NtfDenom {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            NtfDenom::Dummy => "Dummy",
            NtfDenom::Sat => "SAT",
            NtfDenom::Wei => "WEI",
            NtfDenom::Lam => "LAM",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "Dummy" => Some(Self::Dummy),
            "SAT" => Some(Self::Sat),
            "WEI" => Some(Self::Wei),
            "LAM" => Some(Self::Lam),
            _ => None,
        }
    }
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetAddrRequest {
    ///     TokenType token_type = 1;
    #[prost(message, optional, tag="2")]
    pub key_info: ::core::option::Option<KeyInfo>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetAddrResponse {
    #[prost(string, tag="1")]
    pub address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetBalanceRequest {
    #[prost(enumeration="TfDenom", tag="1")]
    pub denom: i32,
    #[prost(string, tag="2")]
    pub address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetBalanceResponse {
    #[prost(enumeration="TfDenom", tag="1")]
    pub denom: i32,
    #[prost(string, tag="2")]
    pub value: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MintRequest {
    ///   TokenType token_type = 1;
    ///
    /// KeyInfo of the minter
    #[prost(message, optional, tag="2")]
    pub minter_key_info: ::core::option::Option<KeyInfo>,
    #[prost(string, tag="3")]
    pub to_address: ::prost::alloc::string::String,
    #[prost(enumeration="TfDenom", tag="4")]
    pub denom: i32,
    #[prost(string, tag="5")]
    pub value: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MintResponse {
    #[prost(string, tag="1")]
    pub txhash: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RedeemRequest {
    ///   TokenType token_type = 1;
    ///
    /// KeyInfo of the wallet from which tokens are removed for redemption
    #[prost(message, optional, tag="2")]
    pub from_key_info: ::core::option::Option<KeyInfo>,
    #[prost(string, tag="3")]
    pub minter_address: ::prost::alloc::string::String,
    #[prost(enumeration="TfDenom", tag="4")]
    pub denom: i32,
    #[prost(string, tag="5")]
    pub value: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RedeemResponse {
    #[prost(string, tag="1")]
    pub txhash: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SendRequest {
    ///   TokenType token_type = 1;
    #[prost(message, optional, tag="2")]
    pub from_key_info: ::core::option::Option<KeyInfo>,
    #[prost(string, tag="3")]
    pub to_address: ::prost::alloc::string::String,
    #[prost(enumeration="TfDenom", tag="4")]
    pub denom: i32,
    #[prost(string, tag="5")]
    pub value: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SendResponse {
    #[prost(string, tag="1")]
    pub txhash: ::prost::alloc::string::String,
}
include!("blkchn_svc_v1.serde.rs");
include!("blkchn_svc_v1.tonic.rs");
// @@protoc_insertion_point(module)