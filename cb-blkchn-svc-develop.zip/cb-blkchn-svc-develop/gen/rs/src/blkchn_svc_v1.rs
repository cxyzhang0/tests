// @generated
//
// enum TokenType {
// // ("wfusd")
// Wfusd = 0;
// // ("btc")
// Btc = 1;
// // ("ether")
// Ether = 2;
// }

#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct KeyInfo {
    #[prost(string, tag="1")]
    pub kms_provider_uuid: ::prost::alloc::string::String,
    #[prost(enumeration="KeyType", tag="2")]
    pub key_type: i32,
    #[prost(string, tag="3")]
    pub key_name: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct FeeInfo {
    #[prost(bool, tag="1")]
    pub pay_by_fee_granter: bool,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum KeyType {
    /// ("Secp256k1")
    Secp256k1 = 0,
    /// ("Ed25519")
    Ed25519 = 1,
    /// ("Secp256r1")
    Secp256r1 = 2,
    /// ("Rsa2048")
    Rsa2048 = 3,
    /// ("Aes")
    Aes = 4,
}
impl KeyType {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            KeyType::Secp256k1 => "Secp256k1",
            KeyType::Ed25519 => "Ed25519",
            KeyType::Secp256r1 => "Secp256r1",
            KeyType::Rsa2048 => "Rsa2048",
            KeyType::Aes => "Aes",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "Secp256k1" => Some(Self::Secp256k1),
            "Ed25519" => Some(Self::Ed25519),
            "Secp256r1" => Some(Self::Secp256r1),
            "Rsa2048" => Some(Self::Rsa2048),
            "Aes" => Some(Self::Aes),
            _ => None,
        }
    }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum TfDenom {
    /// ("uwfUSD")
    UwfUsd = 0,
    /// ("wSAT")
    WSat = 1,
    /// ("wWEI")
    WWei = 2,
    /// ("wLAM")
    WLam = 3,
}
impl TfDenom {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            TfDenom::UwfUsd => "uwfUSD",
            TfDenom::WSat => "wSAT",
            TfDenom::WWei => "wWEI",
            TfDenom::WLam => "wLAM",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "uwfUSD" => Some(Self::UwfUsd),
            "wSAT" => Some(Self::WSat),
            "wWEI" => Some(Self::WWei),
            "wLAM" => Some(Self::WLam),
            _ => None,
        }
    }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum NtfDenom {
    /// ("WFUSD")
    Wfusd = 0,
    /// ("SAT")
    Sat = 1,
    /// ("WEI")
    Wei = 2,
    /// ("LAM")
    Lam = 3,
}
impl NtfDenom {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            NtfDenom::Wfusd => "WFUSD",
            NtfDenom::Sat => "SAT",
            NtfDenom::Wei => "WEI",
            NtfDenom::Lam => "LAM",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "WFUSD" => Some(Self::Wfusd),
            "SAT" => Some(Self::Sat),
            "WEI" => Some(Self::Wei),
            "LAM" => Some(Self::Lam),
            _ => None,
        }
    }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum Chain {
    /// ("Tokenfactory")
    Tokenfactory = 0,
    /// ("Bitcoin")
    Bitcoin = 1,
    /// ("Ethereum")
    Ethereum = 20,
    /// ("Base")
    Base = 21,
    /// ("anvil")
    Anvil = 22,
    /// ("Solana")
    Solana = 50,
}
impl Chain {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            Chain::Tokenfactory => "Tokenfactory",
            Chain::Bitcoin => "Bitcoin",
            Chain::Ethereum => "Ethereum",
            Chain::Base => "Base",
            Chain::Anvil => "Anvil",
            Chain::Solana => "Solana",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "Tokenfactory" => Some(Self::Tokenfactory),
            "Bitcoin" => Some(Self::Bitcoin),
            "Ethereum" => Some(Self::Ethereum),
            "Base" => Some(Self::Base),
            "Anvil" => Some(Self::Anvil),
            "Solana" => Some(Self::Solana),
            _ => None,
        }
    }
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct CrossChainSendRequest {
    #[prost(enumeration="Chain", tag="1")]
    pub from_chain: i32,
    #[prost(message, optional, tag="2")]
    pub from_key_info: ::core::option::Option<KeyInfo>,
    #[prost(string, tag="3")]
    pub from_minter_address: ::prost::alloc::string::String,
    #[prost(enumeration="TfDenom", tag="4")]
    pub from_denom: i32,
    #[prost(string, tag="5")]
    pub from_value: ::prost::alloc::string::String,
    #[prost(enumeration="Chain", tag="11")]
    pub to_chain: i32,
    #[prost(message, optional, tag="12")]
    pub to_minter_key_info: ::core::option::Option<KeyInfo>,
    #[prost(string, tag="13")]
    pub to_address: ::prost::alloc::string::String,
    #[prost(enumeration="TfDenom", tag="14")]
    pub to_denom: i32,
    #[prost(string, tag="15")]
    pub to_value: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct CrossChainSendResponse {
    #[prost(enumeration="Chain", tag="1")]
    pub from_chain: i32,
    #[prost(string, tag="2")]
    pub from_txhash: ::prost::alloc::string::String,
    #[prost(enumeration="Chain", tag="3")]
    pub to_chain: i32,
    #[prost(string, tag="4")]
    pub to_txhash: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GrantFeeBasicAllowanceRequest {
    #[prost(enumeration="Chain", optional, tag="1")]
    pub chain: ::core::option::Option<i32>,
    #[prost(message, optional, tag="2")]
    pub granter: ::core::option::Option<KeyInfo>,
    #[prost(string, tag="3")]
    pub grantee: ::prost::alloc::string::String,
    #[prost(enumeration="TfDenom", tag="4")]
    pub allowance_denom: i32,
    #[prost(string, tag="5")]
    pub allowance_value: ::prost::alloc::string::String,
    #[prost(uint64, tag="6")]
    pub hours_to_expire: u64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GrantFeeBasicAllowanceResponse {
    #[prost(enumeration="Chain", optional, tag="1")]
    pub chain: ::core::option::Option<i32>,
    #[prost(string, tag="2")]
    pub txhash: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetFeeBasicAllowanceRequest {
    #[prost(enumeration="Chain", optional, tag="1")]
    pub chain: ::core::option::Option<i32>,
    #[prost(string, tag="2")]
    pub grantee: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetFeeBasicAllowanceResponse {
    #[prost(enumeration="Chain", optional, tag="1")]
    pub chain: ::core::option::Option<i32>,
    #[prost(message, optional, tag="2")]
    pub fee_basic_grant: ::core::option::Option<GetFeeBasicGrant>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetFeeBasicGrant {
    #[prost(string, tag="1")]
    pub granter: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub grantee: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub allowance_denom: ::prost::alloc::string::String,
    #[prost(string, tag="4")]
    pub allowance_value: ::prost::alloc::string::String,
    #[prost(string, tag="5")]
    pub expiration: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetAddrRequest {
    #[prost(enumeration="Chain", optional, tag="1")]
    pub chain: ::core::option::Option<i32>,
    ///     TokenType token_type = 1;
    #[prost(message, optional, tag="2")]
    pub key_info: ::core::option::Option<KeyInfo>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetAddrResponse {
    #[prost(enumeration="Chain", optional, tag="1")]
    pub chain: ::core::option::Option<i32>,
    #[prost(string, tag="2")]
    pub address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetBalanceRequest {
    #[prost(enumeration="Chain", optional, tag="1")]
    pub chain: ::core::option::Option<i32>,
    #[prost(enumeration="TfDenom", tag="2")]
    pub denom: i32,
    #[prost(string, tag="3")]
    pub address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetBalanceResponse {
    #[prost(enumeration="Chain", optional, tag="1")]
    pub chain: ::core::option::Option<i32>,
    #[prost(enumeration="TfDenom", tag="2")]
    pub denom: i32,
    #[prost(string, tag="3")]
    pub value: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MintRequest {
    #[prost(enumeration="Chain", optional, tag="1")]
    pub chain: ::core::option::Option<i32>,
    /// KeyInfo of the minter
    #[prost(message, optional, tag="2")]
    pub minter_key_info: ::core::option::Option<KeyInfo>,
    #[prost(string, tag="3")]
    pub to_address: ::prost::alloc::string::String,
    #[prost(enumeration="TfDenom", tag="4")]
    pub denom: i32,
    #[prost(string, tag="5")]
    pub value: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MintResponse {
    #[prost(enumeration="Chain", optional, tag="1")]
    pub chain: ::core::option::Option<i32>,
    #[prost(string, tag="2")]
    pub txhash: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RedeemRequest {
    #[prost(enumeration="Chain", optional, tag="1")]
    pub chain: ::core::option::Option<i32>,
    /// KeyInfo of the wallet from which tokens are removed for redemption
    #[prost(message, optional, tag="2")]
    pub from_key_info: ::core::option::Option<KeyInfo>,
    #[prost(string, tag="3")]
    pub minter_address: ::prost::alloc::string::String,
    #[prost(enumeration="TfDenom", tag="4")]
    pub denom: i32,
    #[prost(string, tag="5")]
    pub value: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RedeemResponse {
    #[prost(enumeration="Chain", optional, tag="1")]
    pub chain: ::core::option::Option<i32>,
    #[prost(string, tag="2")]
    pub txhash: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SendRequest {
    #[prost(enumeration="Chain", optional, tag="1")]
    pub chain: ::core::option::Option<i32>,
    #[prost(message, optional, tag="2")]
    pub from_key_info: ::core::option::Option<KeyInfo>,
    #[prost(string, tag="3")]
    pub to_address: ::prost::alloc::string::String,
    #[prost(enumeration="TfDenom", tag="4")]
    pub denom: i32,
    #[prost(string, tag="5")]
    pub value: ::prost::alloc::string::String,
    #[prost(message, optional, tag="6")]
    pub fee_info: ::core::option::Option<FeeInfo>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SendResponse {
    #[prost(enumeration="Chain", optional, tag="1")]
    pub chain: ::core::option::Option<i32>,
    #[prost(string, tag="2")]
    pub txhash: ::prost::alloc::string::String,
}
include!("blkchn_svc_v1.serde.rs");
include!("blkchn_svc_v1.tonic.rs");
// @@protoc_insertion_point(module)