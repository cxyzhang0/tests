// @generated
impl serde::Serialize for Chain {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        let variant = match self {
            Self::Tokenfactory => "Tokenfactory",
            Self::Bitcoin => "Bitcoin",
            Self::Ethereum => "Ethereum",
            Self::Base => "Base",
            Self::Anvil => "Anvil",
            Self::Solana => "Solana",
        };
        serializer.serialize_str(variant)
    }
}
impl<'de> serde::Deserialize<'de> for Chain {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "Tokenfactory",
            "Bitcoin",
            "Ethereum",
            "Base",
            "Anvil",
            "Solana",
        ];

        struct GeneratedVisitor;

        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = Chain;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                write!(formatter, "expected one of: {:?}", &FIELDS)
            }

            fn visit_i64<E>(self, v: i64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Signed(v), &self)
                    })
            }

            fn visit_u64<E>(self, v: u64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Unsigned(v), &self)
                    })
            }

            fn visit_str<E>(self, value: &str) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                match value {
                    "Tokenfactory" => Ok(Chain::Tokenfactory),
                    "Bitcoin" => Ok(Chain::Bitcoin),
                    "Ethereum" => Ok(Chain::Ethereum),
                    "Base" => Ok(Chain::Base),
                    "Anvil" => Ok(Chain::Anvil),
                    "Solana" => Ok(Chain::Solana),
                    _ => Err(serde::de::Error::unknown_variant(value, FIELDS)),
                }
            }
        }
        deserializer.deserialize_any(GeneratedVisitor)
    }
}
impl serde::Serialize for CrossChainSendRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.from_chain != 0 {
            len += 1;
        }
        if self.from_key_info.is_some() {
            len += 1;
        }
        if !self.from_minter_address.is_empty() {
            len += 1;
        }
        if self.from_denom != 0 {
            len += 1;
        }
        if !self.from_value.is_empty() {
            len += 1;
        }
        if self.to_chain != 0 {
            len += 1;
        }
        if self.to_minter_key_info.is_some() {
            len += 1;
        }
        if !self.to_address.is_empty() {
            len += 1;
        }
        if self.to_denom != 0 {
            len += 1;
        }
        if !self.to_value.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.CrossChainSendRequest", len)?;
        if self.from_chain != 0 {
            let v = Chain::try_from(self.from_chain)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", self.from_chain)))?;
            struct_ser.serialize_field("fromChain", &v)?;
        }
        if let Some(v) = self.from_key_info.as_ref() {
            struct_ser.serialize_field("fromKeyInfo", v)?;
        }
        if !self.from_minter_address.is_empty() {
            struct_ser.serialize_field("fromMinterAddress", &self.from_minter_address)?;
        }
        if self.from_denom != 0 {
            let v = TfDenom::try_from(self.from_denom)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", self.from_denom)))?;
            struct_ser.serialize_field("fromDenom", &v)?;
        }
        if !self.from_value.is_empty() {
            struct_ser.serialize_field("fromValue", &self.from_value)?;
        }
        if self.to_chain != 0 {
            let v = Chain::try_from(self.to_chain)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", self.to_chain)))?;
            struct_ser.serialize_field("toChain", &v)?;
        }
        if let Some(v) = self.to_minter_key_info.as_ref() {
            struct_ser.serialize_field("toMinterKeyInfo", v)?;
        }
        if !self.to_address.is_empty() {
            struct_ser.serialize_field("toAddress", &self.to_address)?;
        }
        if self.to_denom != 0 {
            let v = TfDenom::try_from(self.to_denom)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", self.to_denom)))?;
            struct_ser.serialize_field("toDenom", &v)?;
        }
        if !self.to_value.is_empty() {
            struct_ser.serialize_field("toValue", &self.to_value)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for CrossChainSendRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "from_chain",
            "fromChain",
            "from_key_info",
            "fromKeyInfo",
            "from_minter_address",
            "fromMinterAddress",
            "from_denom",
            "fromDenom",
            "from_value",
            "fromValue",
            "to_chain",
            "toChain",
            "to_minter_key_info",
            "toMinterKeyInfo",
            "to_address",
            "toAddress",
            "to_denom",
            "toDenom",
            "to_value",
            "toValue",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            FromChain,
            FromKeyInfo,
            FromMinterAddress,
            FromDenom,
            FromValue,
            ToChain,
            ToMinterKeyInfo,
            ToAddress,
            ToDenom,
            ToValue,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "fromChain" | "from_chain" => Ok(GeneratedField::FromChain),
                            "fromKeyInfo" | "from_key_info" => Ok(GeneratedField::FromKeyInfo),
                            "fromMinterAddress" | "from_minter_address" => Ok(GeneratedField::FromMinterAddress),
                            "fromDenom" | "from_denom" => Ok(GeneratedField::FromDenom),
                            "fromValue" | "from_value" => Ok(GeneratedField::FromValue),
                            "toChain" | "to_chain" => Ok(GeneratedField::ToChain),
                            "toMinterKeyInfo" | "to_minter_key_info" => Ok(GeneratedField::ToMinterKeyInfo),
                            "toAddress" | "to_address" => Ok(GeneratedField::ToAddress),
                            "toDenom" | "to_denom" => Ok(GeneratedField::ToDenom),
                            "toValue" | "to_value" => Ok(GeneratedField::ToValue),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = CrossChainSendRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.CrossChainSendRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<CrossChainSendRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut from_chain__ = None;
                let mut from_key_info__ = None;
                let mut from_minter_address__ = None;
                let mut from_denom__ = None;
                let mut from_value__ = None;
                let mut to_chain__ = None;
                let mut to_minter_key_info__ = None;
                let mut to_address__ = None;
                let mut to_denom__ = None;
                let mut to_value__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::FromChain => {
                            if from_chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("fromChain"));
                            }
                            from_chain__ = Some(map_.next_value::<Chain>()? as i32);
                        }
                        GeneratedField::FromKeyInfo => {
                            if from_key_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("fromKeyInfo"));
                            }
                            from_key_info__ = map_.next_value()?;
                        }
                        GeneratedField::FromMinterAddress => {
                            if from_minter_address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("fromMinterAddress"));
                            }
                            from_minter_address__ = Some(map_.next_value()?);
                        }
                        GeneratedField::FromDenom => {
                            if from_denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("fromDenom"));
                            }
                            from_denom__ = Some(map_.next_value::<TfDenom>()? as i32);
                        }
                        GeneratedField::FromValue => {
                            if from_value__.is_some() {
                                return Err(serde::de::Error::duplicate_field("fromValue"));
                            }
                            from_value__ = Some(map_.next_value()?);
                        }
                        GeneratedField::ToChain => {
                            if to_chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("toChain"));
                            }
                            to_chain__ = Some(map_.next_value::<Chain>()? as i32);
                        }
                        GeneratedField::ToMinterKeyInfo => {
                            if to_minter_key_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("toMinterKeyInfo"));
                            }
                            to_minter_key_info__ = map_.next_value()?;
                        }
                        GeneratedField::ToAddress => {
                            if to_address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("toAddress"));
                            }
                            to_address__ = Some(map_.next_value()?);
                        }
                        GeneratedField::ToDenom => {
                            if to_denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("toDenom"));
                            }
                            to_denom__ = Some(map_.next_value::<TfDenom>()? as i32);
                        }
                        GeneratedField::ToValue => {
                            if to_value__.is_some() {
                                return Err(serde::de::Error::duplicate_field("toValue"));
                            }
                            to_value__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(CrossChainSendRequest {
                    from_chain: from_chain__.unwrap_or_default(),
                    from_key_info: from_key_info__,
                    from_minter_address: from_minter_address__.unwrap_or_default(),
                    from_denom: from_denom__.unwrap_or_default(),
                    from_value: from_value__.unwrap_or_default(),
                    to_chain: to_chain__.unwrap_or_default(),
                    to_minter_key_info: to_minter_key_info__,
                    to_address: to_address__.unwrap_or_default(),
                    to_denom: to_denom__.unwrap_or_default(),
                    to_value: to_value__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.CrossChainSendRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for CrossChainSendResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.from_chain != 0 {
            len += 1;
        }
        if !self.from_txhash.is_empty() {
            len += 1;
        }
        if self.to_chain != 0 {
            len += 1;
        }
        if !self.to_txhash.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.CrossChainSendResponse", len)?;
        if self.from_chain != 0 {
            let v = Chain::try_from(self.from_chain)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", self.from_chain)))?;
            struct_ser.serialize_field("fromChain", &v)?;
        }
        if !self.from_txhash.is_empty() {
            struct_ser.serialize_field("fromTxhash", &self.from_txhash)?;
        }
        if self.to_chain != 0 {
            let v = Chain::try_from(self.to_chain)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", self.to_chain)))?;
            struct_ser.serialize_field("toChain", &v)?;
        }
        if !self.to_txhash.is_empty() {
            struct_ser.serialize_field("toTxhash", &self.to_txhash)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for CrossChainSendResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "from_chain",
            "fromChain",
            "from_txhash",
            "fromTxhash",
            "to_chain",
            "toChain",
            "to_txhash",
            "toTxhash",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            FromChain,
            FromTxhash,
            ToChain,
            ToTxhash,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "fromChain" | "from_chain" => Ok(GeneratedField::FromChain),
                            "fromTxhash" | "from_txhash" => Ok(GeneratedField::FromTxhash),
                            "toChain" | "to_chain" => Ok(GeneratedField::ToChain),
                            "toTxhash" | "to_txhash" => Ok(GeneratedField::ToTxhash),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = CrossChainSendResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.CrossChainSendResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<CrossChainSendResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut from_chain__ = None;
                let mut from_txhash__ = None;
                let mut to_chain__ = None;
                let mut to_txhash__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::FromChain => {
                            if from_chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("fromChain"));
                            }
                            from_chain__ = Some(map_.next_value::<Chain>()? as i32);
                        }
                        GeneratedField::FromTxhash => {
                            if from_txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("fromTxhash"));
                            }
                            from_txhash__ = Some(map_.next_value()?);
                        }
                        GeneratedField::ToChain => {
                            if to_chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("toChain"));
                            }
                            to_chain__ = Some(map_.next_value::<Chain>()? as i32);
                        }
                        GeneratedField::ToTxhash => {
                            if to_txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("toTxhash"));
                            }
                            to_txhash__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(CrossChainSendResponse {
                    from_chain: from_chain__.unwrap_or_default(),
                    from_txhash: from_txhash__.unwrap_or_default(),
                    to_chain: to_chain__.unwrap_or_default(),
                    to_txhash: to_txhash__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.CrossChainSendResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetAddrRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if self.key_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.GetAddrRequest", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if let Some(v) = self.key_info.as_ref() {
            struct_ser.serialize_field("keyInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetAddrRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "key_info",
            "keyInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            KeyInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "keyInfo" | "key_info" => Ok(GeneratedField::KeyInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetAddrRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.GetAddrRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetAddrRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut key_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::KeyInfo => {
                            if key_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("keyInfo"));
                            }
                            key_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(GetAddrRequest {
                    chain: chain__,
                    key_info: key_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.GetAddrRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetAddrResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.address.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.GetAddrResponse", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.address.is_empty() {
            struct_ser.serialize_field("address", &self.address)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetAddrResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "address",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Address,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "address" => Ok(GeneratedField::Address),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetAddrResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.GetAddrResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetAddrResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut address__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Address => {
                            if address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("address"));
                            }
                            address__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetAddrResponse {
                    chain: chain__,
                    address: address__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.GetAddrResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetBalanceRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if self.denom != 0 {
            len += 1;
        }
        if !self.address.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.GetBalanceRequest", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if self.denom != 0 {
            let v = TfDenom::try_from(self.denom)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", self.denom)))?;
            struct_ser.serialize_field("denom", &v)?;
        }
        if !self.address.is_empty() {
            struct_ser.serialize_field("address", &self.address)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetBalanceRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "denom",
            "address",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Denom,
            Address,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "denom" => Ok(GeneratedField::Denom),
                            "address" => Ok(GeneratedField::Address),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetBalanceRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.GetBalanceRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetBalanceRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut denom__ = None;
                let mut address__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Denom => {
                            if denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("denom"));
                            }
                            denom__ = Some(map_.next_value::<TfDenom>()? as i32);
                        }
                        GeneratedField::Address => {
                            if address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("address"));
                            }
                            address__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetBalanceRequest {
                    chain: chain__,
                    denom: denom__.unwrap_or_default(),
                    address: address__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.GetBalanceRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetBalanceResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if self.denom != 0 {
            len += 1;
        }
        if !self.value.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.GetBalanceResponse", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if self.denom != 0 {
            let v = TfDenom::try_from(self.denom)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", self.denom)))?;
            struct_ser.serialize_field("denom", &v)?;
        }
        if !self.value.is_empty() {
            struct_ser.serialize_field("value", &self.value)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetBalanceResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "denom",
            "value",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Denom,
            Value,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "denom" => Ok(GeneratedField::Denom),
                            "value" => Ok(GeneratedField::Value),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetBalanceResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.GetBalanceResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetBalanceResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut denom__ = None;
                let mut value__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Denom => {
                            if denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("denom"));
                            }
                            denom__ = Some(map_.next_value::<TfDenom>()? as i32);
                        }
                        GeneratedField::Value => {
                            if value__.is_some() {
                                return Err(serde::de::Error::duplicate_field("value"));
                            }
                            value__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetBalanceResponse {
                    chain: chain__,
                    denom: denom__.unwrap_or_default(),
                    value: value__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.GetBalanceResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for KeyInfo {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.kms_provider_uuid.is_empty() {
            len += 1;
        }
        if self.key_type != 0 {
            len += 1;
        }
        if !self.key_name.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.KeyInfo", len)?;
        if !self.kms_provider_uuid.is_empty() {
            struct_ser.serialize_field("kmsProviderUuid", &self.kms_provider_uuid)?;
        }
        if self.key_type != 0 {
            let v = KeyType::try_from(self.key_type)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", self.key_type)))?;
            struct_ser.serialize_field("keyType", &v)?;
        }
        if !self.key_name.is_empty() {
            struct_ser.serialize_field("keyName", &self.key_name)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for KeyInfo {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "kms_provider_uuid",
            "kmsProviderUuid",
            "key_type",
            "keyType",
            "key_name",
            "keyName",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            KmsProviderUuid,
            KeyType,
            KeyName,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "kmsProviderUuid" | "kms_provider_uuid" => Ok(GeneratedField::KmsProviderUuid),
                            "keyType" | "key_type" => Ok(GeneratedField::KeyType),
                            "keyName" | "key_name" => Ok(GeneratedField::KeyName),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = KeyInfo;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.KeyInfo")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<KeyInfo, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut kms_provider_uuid__ = None;
                let mut key_type__ = None;
                let mut key_name__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::KmsProviderUuid => {
                            if kms_provider_uuid__.is_some() {
                                return Err(serde::de::Error::duplicate_field("kmsProviderUuid"));
                            }
                            kms_provider_uuid__ = Some(map_.next_value()?);
                        }
                        GeneratedField::KeyType => {
                            if key_type__.is_some() {
                                return Err(serde::de::Error::duplicate_field("keyType"));
                            }
                            key_type__ = Some(map_.next_value::<KeyType>()? as i32);
                        }
                        GeneratedField::KeyName => {
                            if key_name__.is_some() {
                                return Err(serde::de::Error::duplicate_field("keyName"));
                            }
                            key_name__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(KeyInfo {
                    kms_provider_uuid: kms_provider_uuid__.unwrap_or_default(),
                    key_type: key_type__.unwrap_or_default(),
                    key_name: key_name__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.KeyInfo", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for KeyType {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        let variant = match self {
            Self::Secp256k1 => "Secp256k1",
            Self::Ed25519 => "Ed25519",
            Self::Secp256r1 => "Secp256r1",
            Self::Rsa2048 => "Rsa2048",
            Self::Aes => "Aes",
        };
        serializer.serialize_str(variant)
    }
}
impl<'de> serde::Deserialize<'de> for KeyType {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "Secp256k1",
            "Ed25519",
            "Secp256r1",
            "Rsa2048",
            "Aes",
        ];

        struct GeneratedVisitor;

        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = KeyType;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                write!(formatter, "expected one of: {:?}", &FIELDS)
            }

            fn visit_i64<E>(self, v: i64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Signed(v), &self)
                    })
            }

            fn visit_u64<E>(self, v: u64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Unsigned(v), &self)
                    })
            }

            fn visit_str<E>(self, value: &str) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                match value {
                    "Secp256k1" => Ok(KeyType::Secp256k1),
                    "Ed25519" => Ok(KeyType::Ed25519),
                    "Secp256r1" => Ok(KeyType::Secp256r1),
                    "Rsa2048" => Ok(KeyType::Rsa2048),
                    "Aes" => Ok(KeyType::Aes),
                    _ => Err(serde::de::Error::unknown_variant(value, FIELDS)),
                }
            }
        }
        deserializer.deserialize_any(GeneratedVisitor)
    }
}
impl serde::Serialize for MintRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if self.minter_key_info.is_some() {
            len += 1;
        }
        if !self.to_address.is_empty() {
            len += 1;
        }
        if self.denom != 0 {
            len += 1;
        }
        if !self.value.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.MintRequest", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if let Some(v) = self.minter_key_info.as_ref() {
            struct_ser.serialize_field("minterKeyInfo", v)?;
        }
        if !self.to_address.is_empty() {
            struct_ser.serialize_field("toAddress", &self.to_address)?;
        }
        if self.denom != 0 {
            let v = TfDenom::try_from(self.denom)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", self.denom)))?;
            struct_ser.serialize_field("denom", &v)?;
        }
        if !self.value.is_empty() {
            struct_ser.serialize_field("value", &self.value)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for MintRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "minter_key_info",
            "minterKeyInfo",
            "to_address",
            "toAddress",
            "denom",
            "value",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            MinterKeyInfo,
            ToAddress,
            Denom,
            Value,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "minterKeyInfo" | "minter_key_info" => Ok(GeneratedField::MinterKeyInfo),
                            "toAddress" | "to_address" => Ok(GeneratedField::ToAddress),
                            "denom" => Ok(GeneratedField::Denom),
                            "value" => Ok(GeneratedField::Value),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = MintRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.MintRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<MintRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut minter_key_info__ = None;
                let mut to_address__ = None;
                let mut denom__ = None;
                let mut value__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::MinterKeyInfo => {
                            if minter_key_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("minterKeyInfo"));
                            }
                            minter_key_info__ = map_.next_value()?;
                        }
                        GeneratedField::ToAddress => {
                            if to_address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("toAddress"));
                            }
                            to_address__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Denom => {
                            if denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("denom"));
                            }
                            denom__ = Some(map_.next_value::<TfDenom>()? as i32);
                        }
                        GeneratedField::Value => {
                            if value__.is_some() {
                                return Err(serde::de::Error::duplicate_field("value"));
                            }
                            value__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(MintRequest {
                    chain: chain__,
                    minter_key_info: minter_key_info__,
                    to_address: to_address__.unwrap_or_default(),
                    denom: denom__.unwrap_or_default(),
                    value: value__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.MintRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for MintResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.txhash.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.MintResponse", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for MintResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "txhash",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Txhash,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "txhash" => Ok(GeneratedField::Txhash),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = MintResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.MintResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<MintResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut txhash__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(MintResponse {
                    chain: chain__,
                    txhash: txhash__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.MintResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for NtfDenom {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        let variant = match self {
            Self::Wfusd => "WFUSD",
            Self::Sat => "SAT",
            Self::Wei => "WEI",
            Self::Lam => "LAM",
        };
        serializer.serialize_str(variant)
    }
}
impl<'de> serde::Deserialize<'de> for NtfDenom {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "WFUSD",
            "SAT",
            "WEI",
            "LAM",
        ];

        struct GeneratedVisitor;

        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = NtfDenom;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                write!(formatter, "expected one of: {:?}", &FIELDS)
            }

            fn visit_i64<E>(self, v: i64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Signed(v), &self)
                    })
            }

            fn visit_u64<E>(self, v: u64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Unsigned(v), &self)
                    })
            }

            fn visit_str<E>(self, value: &str) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                match value {
                    "WFUSD" => Ok(NtfDenom::Wfusd),
                    "SAT" => Ok(NtfDenom::Sat),
                    "WEI" => Ok(NtfDenom::Wei),
                    "LAM" => Ok(NtfDenom::Lam),
                    _ => Err(serde::de::Error::unknown_variant(value, FIELDS)),
                }
            }
        }
        deserializer.deserialize_any(GeneratedVisitor)
    }
}
impl serde::Serialize for RedeemRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if self.from_key_info.is_some() {
            len += 1;
        }
        if !self.minter_address.is_empty() {
            len += 1;
        }
        if self.denom != 0 {
            len += 1;
        }
        if !self.value.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.RedeemRequest", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if let Some(v) = self.from_key_info.as_ref() {
            struct_ser.serialize_field("fromKeyInfo", v)?;
        }
        if !self.minter_address.is_empty() {
            struct_ser.serialize_field("minterAddress", &self.minter_address)?;
        }
        if self.denom != 0 {
            let v = TfDenom::try_from(self.denom)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", self.denom)))?;
            struct_ser.serialize_field("denom", &v)?;
        }
        if !self.value.is_empty() {
            struct_ser.serialize_field("value", &self.value)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for RedeemRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "from_key_info",
            "fromKeyInfo",
            "minter_address",
            "minterAddress",
            "denom",
            "value",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            FromKeyInfo,
            MinterAddress,
            Denom,
            Value,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "fromKeyInfo" | "from_key_info" => Ok(GeneratedField::FromKeyInfo),
                            "minterAddress" | "minter_address" => Ok(GeneratedField::MinterAddress),
                            "denom" => Ok(GeneratedField::Denom),
                            "value" => Ok(GeneratedField::Value),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = RedeemRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.RedeemRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<RedeemRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut from_key_info__ = None;
                let mut minter_address__ = None;
                let mut denom__ = None;
                let mut value__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::FromKeyInfo => {
                            if from_key_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("fromKeyInfo"));
                            }
                            from_key_info__ = map_.next_value()?;
                        }
                        GeneratedField::MinterAddress => {
                            if minter_address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("minterAddress"));
                            }
                            minter_address__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Denom => {
                            if denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("denom"));
                            }
                            denom__ = Some(map_.next_value::<TfDenom>()? as i32);
                        }
                        GeneratedField::Value => {
                            if value__.is_some() {
                                return Err(serde::de::Error::duplicate_field("value"));
                            }
                            value__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(RedeemRequest {
                    chain: chain__,
                    from_key_info: from_key_info__,
                    minter_address: minter_address__.unwrap_or_default(),
                    denom: denom__.unwrap_or_default(),
                    value: value__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.RedeemRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for RedeemResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.txhash.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.RedeemResponse", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for RedeemResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "txhash",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Txhash,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "txhash" => Ok(GeneratedField::Txhash),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = RedeemResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.RedeemResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<RedeemResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut txhash__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(RedeemResponse {
                    chain: chain__,
                    txhash: txhash__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.RedeemResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for SendRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if self.from_key_info.is_some() {
            len += 1;
        }
        if !self.to_address.is_empty() {
            len += 1;
        }
        if self.denom != 0 {
            len += 1;
        }
        if !self.value.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.SendRequest", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if let Some(v) = self.from_key_info.as_ref() {
            struct_ser.serialize_field("fromKeyInfo", v)?;
        }
        if !self.to_address.is_empty() {
            struct_ser.serialize_field("toAddress", &self.to_address)?;
        }
        if self.denom != 0 {
            let v = TfDenom::try_from(self.denom)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", self.denom)))?;
            struct_ser.serialize_field("denom", &v)?;
        }
        if !self.value.is_empty() {
            struct_ser.serialize_field("value", &self.value)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for SendRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "from_key_info",
            "fromKeyInfo",
            "to_address",
            "toAddress",
            "denom",
            "value",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            FromKeyInfo,
            ToAddress,
            Denom,
            Value,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "fromKeyInfo" | "from_key_info" => Ok(GeneratedField::FromKeyInfo),
                            "toAddress" | "to_address" => Ok(GeneratedField::ToAddress),
                            "denom" => Ok(GeneratedField::Denom),
                            "value" => Ok(GeneratedField::Value),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = SendRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.SendRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<SendRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut from_key_info__ = None;
                let mut to_address__ = None;
                let mut denom__ = None;
                let mut value__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::FromKeyInfo => {
                            if from_key_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("fromKeyInfo"));
                            }
                            from_key_info__ = map_.next_value()?;
                        }
                        GeneratedField::ToAddress => {
                            if to_address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("toAddress"));
                            }
                            to_address__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Denom => {
                            if denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("denom"));
                            }
                            denom__ = Some(map_.next_value::<TfDenom>()? as i32);
                        }
                        GeneratedField::Value => {
                            if value__.is_some() {
                                return Err(serde::de::Error::duplicate_field("value"));
                            }
                            value__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(SendRequest {
                    chain: chain__,
                    from_key_info: from_key_info__,
                    to_address: to_address__.unwrap_or_default(),
                    denom: denom__.unwrap_or_default(),
                    value: value__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.SendRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for SendResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.txhash.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.SendResponse", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for SendResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "txhash",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Txhash,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "txhash" => Ok(GeneratedField::Txhash),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = SendResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.SendResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<SendResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut txhash__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(SendResponse {
                    chain: chain__,
                    txhash: txhash__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.SendResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for TfDenom {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        let variant = match self {
            Self::UwfUsd => "uwfUSD",
            Self::WSat => "wSAT",
            Self::WWei => "wWEI",
            Self::WLam => "wLAM",
        };
        serializer.serialize_str(variant)
    }
}
impl<'de> serde::Deserialize<'de> for TfDenom {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "uwfUSD",
            "wSAT",
            "wWEI",
            "wLAM",
        ];

        struct GeneratedVisitor;

        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = TfDenom;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                write!(formatter, "expected one of: {:?}", &FIELDS)
            }

            fn visit_i64<E>(self, v: i64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Signed(v), &self)
                    })
            }

            fn visit_u64<E>(self, v: u64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Unsigned(v), &self)
                    })
            }

            fn visit_str<E>(self, value: &str) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                match value {
                    "uwfUSD" => Ok(TfDenom::UwfUsd),
                    "wSAT" => Ok(TfDenom::WSat),
                    "wWEI" => Ok(TfDenom::WWei),
                    "wLAM" => Ok(TfDenom::WLam),
                    _ => Err(serde::de::Error::unknown_variant(value, FIELDS)),
                }
            }
        }
        deserializer.deserialize_any(GeneratedVisitor)
    }
}
