// @generated
impl serde::Serialize for BlacklistRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.address.is_empty() {
            len += 1;
        }
        if self.blacklister_key_info.is_some() {
            len += 1;
        }
        if self.chain.is_some() {
            len += 1;
        }
        if self.fee_info.is_some() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.BlacklistRequest", len)?;
        if !self.address.is_empty() {
            struct_ser.serialize_field("address", &self.address)?;
        }
        if let Some(v) = self.blacklister_key_info.as_ref() {
            struct_ser.serialize_field("blacklisterKeyInfo", v)?;
        }
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if let Some(v) = self.fee_info.as_ref() {
            struct_ser.serialize_field("feeInfo", v)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for BlacklistRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "address",
            "blacklister_key_info",
            "blacklisterKeyInfo",
            "chain",
            "fee_info",
            "feeInfo",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Address,
            BlacklisterKeyInfo,
            Chain,
            FeeInfo,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "address" => Ok(GeneratedField::Address),
                            "blacklisterKeyInfo" | "blacklister_key_info" => Ok(GeneratedField::BlacklisterKeyInfo),
                            "chain" => Ok(GeneratedField::Chain),
                            "feeInfo" | "fee_info" => Ok(GeneratedField::FeeInfo),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = BlacklistRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.BlacklistRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<BlacklistRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut address__ = None;
                let mut blacklister_key_info__ = None;
                let mut chain__ = None;
                let mut fee_info__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Address => {
                            if address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("address"));
                            }
                            address__ = Some(map_.next_value()?);
                        }
                        GeneratedField::BlacklisterKeyInfo => {
                            if blacklister_key_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("blacklisterKeyInfo"));
                            }
                            blacklister_key_info__ = map_.next_value()?;
                        }
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::FeeInfo => {
                            if fee_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("feeInfo"));
                            }
                            fee_info__ = map_.next_value()?;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(BlacklistRequest {
                    address: address__.unwrap_or_default(),
                    blacklister_key_info: blacklister_key_info__,
                    chain: chain__,
                    fee_info: fee_info__,
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.BlacklistRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for BlacklistResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.txhash.is_empty() {
            len += 1;
        }
        if self.tx_status.is_some() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.BlacklistResponse", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        if let Some(v) = self.tx_status.as_ref() {
            struct_ser.serialize_field("txStatus", v)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for BlacklistResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "txhash",
            "tx_status",
            "txStatus",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Txhash,
            TxStatus,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "txhash" => Ok(GeneratedField::Txhash),
                            "txStatus" | "tx_status" => Ok(GeneratedField::TxStatus),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = BlacklistResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.BlacklistResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<BlacklistResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut txhash__ = None;
                let mut tx_status__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                        GeneratedField::TxStatus => {
                            if tx_status__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txStatus"));
                            }
                            tx_status__ = map_.next_value()?;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(BlacklistResponse {
                    chain: chain__,
                    txhash: txhash__.unwrap_or_default(),
                    tx_status: tx_status__,
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.BlacklistResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for Chain {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        let variant = match self {
            Self::Tokenfactory => "Tokenfactory",
            Self::Bitcoin => "Bitcoin",
            Self::Ethereum => "Ethereum",
            Self::Base => "Base",
            Self::Anvil => "Anvil",
            Self::Solana => "Solana",
        };
        serializer.serialize_str(variant)
    }
}
impl<'de> serde::Deserialize<'de> for Chain {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "Tokenfactory",
            "Bitcoin",
            "Ethereum",
            "Base",
            "Anvil",
            "Solana",
        ];

        struct GeneratedVisitor;

        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = Chain;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                write!(formatter, "expected one of: {:?}", &FIELDS)
            }

            fn visit_i64<E>(self, v: i64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Signed(v), &self)
                    })
            }

            fn visit_u64<E>(self, v: u64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Unsigned(v), &self)
                    })
            }

            fn visit_str<E>(self, value: &str) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                match value {
                    "Tokenfactory" => Ok(Chain::Tokenfactory),
                    "Bitcoin" => Ok(Chain::Bitcoin),
                    "Ethereum" => Ok(Chain::Ethereum),
                    "Base" => Ok(Chain::Base),
                    "Anvil" => Ok(Chain::Anvil),
                    "Solana" => Ok(Chain::Solana),
                    _ => Err(serde::de::Error::unknown_variant(value, FIELDS)),
                }
            }
        }
        deserializer.deserialize_any(GeneratedVisitor)
    }
}
impl serde::Serialize for CommonTxResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.txhash.is_empty() {
            len += 1;
        }
        if self.tx_status.is_some() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.CommonTxResponse", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        if let Some(v) = self.tx_status.as_ref() {
            struct_ser.serialize_field("txStatus", v)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for CommonTxResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "txhash",
            "tx_status",
            "txStatus",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Txhash,
            TxStatus,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "txhash" => Ok(GeneratedField::Txhash),
                            "txStatus" | "tx_status" => Ok(GeneratedField::TxStatus),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = CommonTxResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.CommonTxResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<CommonTxResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut txhash__ = None;
                let mut tx_status__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                        GeneratedField::TxStatus => {
                            if tx_status__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txStatus"));
                            }
                            tx_status__ = map_.next_value()?;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(CommonTxResponse {
                    chain: chain__,
                    txhash: txhash__.unwrap_or_default(),
                    tx_status: tx_status__,
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.CommonTxResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for ConfigureMinterControllerRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.controller.is_empty() {
            len += 1;
        }
        if !self.minter.is_empty() {
            len += 1;
        }
        if self.masterminter_key_info.is_some() {
            len += 1;
        }
        if self.chain.is_some() {
            len += 1;
        }
        if self.fee_info.is_some() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.ConfigureMinterControllerRequest", len)?;
        if !self.controller.is_empty() {
            struct_ser.serialize_field("controller", &self.controller)?;
        }
        if !self.minter.is_empty() {
            struct_ser.serialize_field("minter", &self.minter)?;
        }
        if let Some(v) = self.masterminter_key_info.as_ref() {
            struct_ser.serialize_field("masterminterKeyInfo", v)?;
        }
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if let Some(v) = self.fee_info.as_ref() {
            struct_ser.serialize_field("feeInfo", v)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for ConfigureMinterControllerRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "controller",
            "minter",
            "masterminter_key_info",
            "masterminterKeyInfo",
            "chain",
            "fee_info",
            "feeInfo",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Controller,
            Minter,
            MasterminterKeyInfo,
            Chain,
            FeeInfo,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "controller" => Ok(GeneratedField::Controller),
                            "minter" => Ok(GeneratedField::Minter),
                            "masterminterKeyInfo" | "masterminter_key_info" => Ok(GeneratedField::MasterminterKeyInfo),
                            "chain" => Ok(GeneratedField::Chain),
                            "feeInfo" | "fee_info" => Ok(GeneratedField::FeeInfo),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = ConfigureMinterControllerRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.ConfigureMinterControllerRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<ConfigureMinterControllerRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut controller__ = None;
                let mut minter__ = None;
                let mut masterminter_key_info__ = None;
                let mut chain__ = None;
                let mut fee_info__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Controller => {
                            if controller__.is_some() {
                                return Err(serde::de::Error::duplicate_field("controller"));
                            }
                            controller__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Minter => {
                            if minter__.is_some() {
                                return Err(serde::de::Error::duplicate_field("minter"));
                            }
                            minter__ = Some(map_.next_value()?);
                        }
                        GeneratedField::MasterminterKeyInfo => {
                            if masterminter_key_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("masterminterKeyInfo"));
                            }
                            masterminter_key_info__ = map_.next_value()?;
                        }
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::FeeInfo => {
                            if fee_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("feeInfo"));
                            }
                            fee_info__ = map_.next_value()?;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(ConfigureMinterControllerRequest {
                    controller: controller__.unwrap_or_default(),
                    minter: minter__.unwrap_or_default(),
                    masterminter_key_info: masterminter_key_info__,
                    chain: chain__,
                    fee_info: fee_info__,
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.ConfigureMinterControllerRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for ConfigureMinterControllerResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.txhash.is_empty() {
            len += 1;
        }
        if self.tx_status.is_some() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.ConfigureMinterControllerResponse", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        if let Some(v) = self.tx_status.as_ref() {
            struct_ser.serialize_field("txStatus", v)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for ConfigureMinterControllerResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "txhash",
            "tx_status",
            "txStatus",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Txhash,
            TxStatus,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "txhash" => Ok(GeneratedField::Txhash),
                            "txStatus" | "tx_status" => Ok(GeneratedField::TxStatus),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = ConfigureMinterControllerResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.ConfigureMinterControllerResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<ConfigureMinterControllerResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut txhash__ = None;
                let mut tx_status__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                        GeneratedField::TxStatus => {
                            if tx_status__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txStatus"));
                            }
                            tx_status__ = map_.next_value()?;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(ConfigureMinterControllerResponse {
                    chain: chain__,
                    txhash: txhash__.unwrap_or_default(),
                    tx_status: tx_status__,
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.ConfigureMinterControllerResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for ConfigureMinterRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.address.is_empty() {
            len += 1;
        }
        if self.allowance_denom != 0 {
            len += 1;
        }
        if !self.allowance_value.is_empty() {
            len += 1;
        }
        if self.mintercontroller_key_info.is_some() {
            len += 1;
        }
        if self.chain.is_some() {
            len += 1;
        }
        if self.fee_info.is_some() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.ConfigureMinterRequest", len)?;
        if !self.address.is_empty() {
            struct_ser.serialize_field("address", &self.address)?;
        }
        if self.allowance_denom != 0 {
            let v = TfDenom::try_from(self.allowance_denom)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", self.allowance_denom)))?;
            struct_ser.serialize_field("allowanceDenom", &v)?;
        }
        if !self.allowance_value.is_empty() {
            struct_ser.serialize_field("allowanceValue", &self.allowance_value)?;
        }
        if let Some(v) = self.mintercontroller_key_info.as_ref() {
            struct_ser.serialize_field("mintercontrollerKeyInfo", v)?;
        }
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if let Some(v) = self.fee_info.as_ref() {
            struct_ser.serialize_field("feeInfo", v)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for ConfigureMinterRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "address",
            "allowance_denom",
            "allowanceDenom",
            "allowance_value",
            "allowanceValue",
            "mintercontroller_key_info",
            "mintercontrollerKeyInfo",
            "chain",
            "fee_info",
            "feeInfo",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Address,
            AllowanceDenom,
            AllowanceValue,
            MintercontrollerKeyInfo,
            Chain,
            FeeInfo,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "address" => Ok(GeneratedField::Address),
                            "allowanceDenom" | "allowance_denom" => Ok(GeneratedField::AllowanceDenom),
                            "allowanceValue" | "allowance_value" => Ok(GeneratedField::AllowanceValue),
                            "mintercontrollerKeyInfo" | "mintercontroller_key_info" => Ok(GeneratedField::MintercontrollerKeyInfo),
                            "chain" => Ok(GeneratedField::Chain),
                            "feeInfo" | "fee_info" => Ok(GeneratedField::FeeInfo),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = ConfigureMinterRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.ConfigureMinterRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<ConfigureMinterRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut address__ = None;
                let mut allowance_denom__ = None;
                let mut allowance_value__ = None;
                let mut mintercontroller_key_info__ = None;
                let mut chain__ = None;
                let mut fee_info__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Address => {
                            if address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("address"));
                            }
                            address__ = Some(map_.next_value()?);
                        }
                        GeneratedField::AllowanceDenom => {
                            if allowance_denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("allowanceDenom"));
                            }
                            allowance_denom__ = Some(map_.next_value::<TfDenom>()? as i32);
                        }
                        GeneratedField::AllowanceValue => {
                            if allowance_value__.is_some() {
                                return Err(serde::de::Error::duplicate_field("allowanceValue"));
                            }
                            allowance_value__ = Some(map_.next_value()?);
                        }
                        GeneratedField::MintercontrollerKeyInfo => {
                            if mintercontroller_key_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("mintercontrollerKeyInfo"));
                            }
                            mintercontroller_key_info__ = map_.next_value()?;
                        }
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::FeeInfo => {
                            if fee_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("feeInfo"));
                            }
                            fee_info__ = map_.next_value()?;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(ConfigureMinterRequest {
                    address: address__.unwrap_or_default(),
                    allowance_denom: allowance_denom__.unwrap_or_default(),
                    allowance_value: allowance_value__.unwrap_or_default(),
                    mintercontroller_key_info: mintercontroller_key_info__,
                    chain: chain__,
                    fee_info: fee_info__,
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.ConfigureMinterRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for ConfigureMinterResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.txhash.is_empty() {
            len += 1;
        }
        if self.tx_status.is_some() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.ConfigureMinterResponse", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        if let Some(v) = self.tx_status.as_ref() {
            struct_ser.serialize_field("txStatus", v)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for ConfigureMinterResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "txhash",
            "tx_status",
            "txStatus",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Txhash,
            TxStatus,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "txhash" => Ok(GeneratedField::Txhash),
                            "txStatus" | "tx_status" => Ok(GeneratedField::TxStatus),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = ConfigureMinterResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.ConfigureMinterResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<ConfigureMinterResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut txhash__ = None;
                let mut tx_status__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                        GeneratedField::TxStatus => {
                            if tx_status__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txStatus"));
                            }
                            tx_status__ = map_.next_value()?;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(ConfigureMinterResponse {
                    chain: chain__,
                    txhash: txhash__.unwrap_or_default(),
                    tx_status: tx_status__,
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.ConfigureMinterResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for CrossChainSendRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.from_chain != 0 {
            len += 1;
        }
        if self.from_key_info.is_some() {
            len += 1;
        }
        if !self.from_minter_address.is_empty() {
            len += 1;
        }
        if self.from_denom != 0 {
            len += 1;
        }
        if !self.from_value.is_empty() {
            len += 1;
        }
        if self.from_fee_info.is_some() {
            len += 1;
        }
        if self.to_chain != 0 {
            len += 1;
        }
        if self.to_minter_key_info.is_some() {
            len += 1;
        }
        if !self.to_address.is_empty() {
            len += 1;
        }
        if self.to_denom != 0 {
            len += 1;
        }
        if !self.to_value.is_empty() {
            len += 1;
        }
        if self.to_fee_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.CrossChainSendRequest", len)?;
        if self.from_chain != 0 {
            let v = Chain::try_from(self.from_chain)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", self.from_chain)))?;
            struct_ser.serialize_field("fromChain", &v)?;
        }
        if let Some(v) = self.from_key_info.as_ref() {
            struct_ser.serialize_field("fromKeyInfo", v)?;
        }
        if !self.from_minter_address.is_empty() {
            struct_ser.serialize_field("fromMinterAddress", &self.from_minter_address)?;
        }
        if self.from_denom != 0 {
            let v = TfDenom::try_from(self.from_denom)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", self.from_denom)))?;
            struct_ser.serialize_field("fromDenom", &v)?;
        }
        if !self.from_value.is_empty() {
            struct_ser.serialize_field("fromValue", &self.from_value)?;
        }
        if let Some(v) = self.from_fee_info.as_ref() {
            struct_ser.serialize_field("fromFeeInfo", v)?;
        }
        if self.to_chain != 0 {
            let v = Chain::try_from(self.to_chain)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", self.to_chain)))?;
            struct_ser.serialize_field("toChain", &v)?;
        }
        if let Some(v) = self.to_minter_key_info.as_ref() {
            struct_ser.serialize_field("toMinterKeyInfo", v)?;
        }
        if !self.to_address.is_empty() {
            struct_ser.serialize_field("toAddress", &self.to_address)?;
        }
        if self.to_denom != 0 {
            let v = TfDenom::try_from(self.to_denom)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", self.to_denom)))?;
            struct_ser.serialize_field("toDenom", &v)?;
        }
        if !self.to_value.is_empty() {
            struct_ser.serialize_field("toValue", &self.to_value)?;
        }
        if let Some(v) = self.to_fee_info.as_ref() {
            struct_ser.serialize_field("toFeeInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for CrossChainSendRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "from_chain",
            "fromChain",
            "from_key_info",
            "fromKeyInfo",
            "from_minter_address",
            "fromMinterAddress",
            "from_denom",
            "fromDenom",
            "from_value",
            "fromValue",
            "from_fee_info",
            "fromFeeInfo",
            "to_chain",
            "toChain",
            "to_minter_key_info",
            "toMinterKeyInfo",
            "to_address",
            "toAddress",
            "to_denom",
            "toDenom",
            "to_value",
            "toValue",
            "to_fee_info",
            "toFeeInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            FromChain,
            FromKeyInfo,
            FromMinterAddress,
            FromDenom,
            FromValue,
            FromFeeInfo,
            ToChain,
            ToMinterKeyInfo,
            ToAddress,
            ToDenom,
            ToValue,
            ToFeeInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "fromChain" | "from_chain" => Ok(GeneratedField::FromChain),
                            "fromKeyInfo" | "from_key_info" => Ok(GeneratedField::FromKeyInfo),
                            "fromMinterAddress" | "from_minter_address" => Ok(GeneratedField::FromMinterAddress),
                            "fromDenom" | "from_denom" => Ok(GeneratedField::FromDenom),
                            "fromValue" | "from_value" => Ok(GeneratedField::FromValue),
                            "fromFeeInfo" | "from_fee_info" => Ok(GeneratedField::FromFeeInfo),
                            "toChain" | "to_chain" => Ok(GeneratedField::ToChain),
                            "toMinterKeyInfo" | "to_minter_key_info" => Ok(GeneratedField::ToMinterKeyInfo),
                            "toAddress" | "to_address" => Ok(GeneratedField::ToAddress),
                            "toDenom" | "to_denom" => Ok(GeneratedField::ToDenom),
                            "toValue" | "to_value" => Ok(GeneratedField::ToValue),
                            "toFeeInfo" | "to_fee_info" => Ok(GeneratedField::ToFeeInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = CrossChainSendRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.CrossChainSendRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<CrossChainSendRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut from_chain__ = None;
                let mut from_key_info__ = None;
                let mut from_minter_address__ = None;
                let mut from_denom__ = None;
                let mut from_value__ = None;
                let mut from_fee_info__ = None;
                let mut to_chain__ = None;
                let mut to_minter_key_info__ = None;
                let mut to_address__ = None;
                let mut to_denom__ = None;
                let mut to_value__ = None;
                let mut to_fee_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::FromChain => {
                            if from_chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("fromChain"));
                            }
                            from_chain__ = Some(map_.next_value::<Chain>()? as i32);
                        }
                        GeneratedField::FromKeyInfo => {
                            if from_key_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("fromKeyInfo"));
                            }
                            from_key_info__ = map_.next_value()?;
                        }
                        GeneratedField::FromMinterAddress => {
                            if from_minter_address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("fromMinterAddress"));
                            }
                            from_minter_address__ = Some(map_.next_value()?);
                        }
                        GeneratedField::FromDenom => {
                            if from_denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("fromDenom"));
                            }
                            from_denom__ = Some(map_.next_value::<TfDenom>()? as i32);
                        }
                        GeneratedField::FromValue => {
                            if from_value__.is_some() {
                                return Err(serde::de::Error::duplicate_field("fromValue"));
                            }
                            from_value__ = Some(map_.next_value()?);
                        }
                        GeneratedField::FromFeeInfo => {
                            if from_fee_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("fromFeeInfo"));
                            }
                            from_fee_info__ = map_.next_value()?;
                        }
                        GeneratedField::ToChain => {
                            if to_chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("toChain"));
                            }
                            to_chain__ = Some(map_.next_value::<Chain>()? as i32);
                        }
                        GeneratedField::ToMinterKeyInfo => {
                            if to_minter_key_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("toMinterKeyInfo"));
                            }
                            to_minter_key_info__ = map_.next_value()?;
                        }
                        GeneratedField::ToAddress => {
                            if to_address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("toAddress"));
                            }
                            to_address__ = Some(map_.next_value()?);
                        }
                        GeneratedField::ToDenom => {
                            if to_denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("toDenom"));
                            }
                            to_denom__ = Some(map_.next_value::<TfDenom>()? as i32);
                        }
                        GeneratedField::ToValue => {
                            if to_value__.is_some() {
                                return Err(serde::de::Error::duplicate_field("toValue"));
                            }
                            to_value__ = Some(map_.next_value()?);
                        }
                        GeneratedField::ToFeeInfo => {
                            if to_fee_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("toFeeInfo"));
                            }
                            to_fee_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(CrossChainSendRequest {
                    from_chain: from_chain__.unwrap_or_default(),
                    from_key_info: from_key_info__,
                    from_minter_address: from_minter_address__.unwrap_or_default(),
                    from_denom: from_denom__.unwrap_or_default(),
                    from_value: from_value__.unwrap_or_default(),
                    from_fee_info: from_fee_info__,
                    to_chain: to_chain__.unwrap_or_default(),
                    to_minter_key_info: to_minter_key_info__,
                    to_address: to_address__.unwrap_or_default(),
                    to_denom: to_denom__.unwrap_or_default(),
                    to_value: to_value__.unwrap_or_default(),
                    to_fee_info: to_fee_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.CrossChainSendRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for CrossChainSendResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.from_chain != 0 {
            len += 1;
        }
        if !self.from_txhash.is_empty() {
            len += 1;
        }
        if self.from_tx_status.is_some() {
            len += 1;
        }
        if self.to_chain != 0 {
            len += 1;
        }
        if !self.to_txhash.is_empty() {
            len += 1;
        }
        if self.to_tx_status.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.CrossChainSendResponse", len)?;
        if self.from_chain != 0 {
            let v = Chain::try_from(self.from_chain)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", self.from_chain)))?;
            struct_ser.serialize_field("fromChain", &v)?;
        }
        if !self.from_txhash.is_empty() {
            struct_ser.serialize_field("fromTxhash", &self.from_txhash)?;
        }
        if let Some(v) = self.from_tx_status.as_ref() {
            struct_ser.serialize_field("fromTxStatus", v)?;
        }
        if self.to_chain != 0 {
            let v = Chain::try_from(self.to_chain)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", self.to_chain)))?;
            struct_ser.serialize_field("toChain", &v)?;
        }
        if !self.to_txhash.is_empty() {
            struct_ser.serialize_field("toTxhash", &self.to_txhash)?;
        }
        if let Some(v) = self.to_tx_status.as_ref() {
            struct_ser.serialize_field("toTxStatus", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for CrossChainSendResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "from_chain",
            "fromChain",
            "from_txhash",
            "fromTxhash",
            "from_tx_status",
            "fromTxStatus",
            "to_chain",
            "toChain",
            "to_txhash",
            "toTxhash",
            "to_tx_status",
            "toTxStatus",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            FromChain,
            FromTxhash,
            FromTxStatus,
            ToChain,
            ToTxhash,
            ToTxStatus,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "fromChain" | "from_chain" => Ok(GeneratedField::FromChain),
                            "fromTxhash" | "from_txhash" => Ok(GeneratedField::FromTxhash),
                            "fromTxStatus" | "from_tx_status" => Ok(GeneratedField::FromTxStatus),
                            "toChain" | "to_chain" => Ok(GeneratedField::ToChain),
                            "toTxhash" | "to_txhash" => Ok(GeneratedField::ToTxhash),
                            "toTxStatus" | "to_tx_status" => Ok(GeneratedField::ToTxStatus),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = CrossChainSendResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.CrossChainSendResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<CrossChainSendResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut from_chain__ = None;
                let mut from_txhash__ = None;
                let mut from_tx_status__ = None;
                let mut to_chain__ = None;
                let mut to_txhash__ = None;
                let mut to_tx_status__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::FromChain => {
                            if from_chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("fromChain"));
                            }
                            from_chain__ = Some(map_.next_value::<Chain>()? as i32);
                        }
                        GeneratedField::FromTxhash => {
                            if from_txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("fromTxhash"));
                            }
                            from_txhash__ = Some(map_.next_value()?);
                        }
                        GeneratedField::FromTxStatus => {
                            if from_tx_status__.is_some() {
                                return Err(serde::de::Error::duplicate_field("fromTxStatus"));
                            }
                            from_tx_status__ = map_.next_value()?;
                        }
                        GeneratedField::ToChain => {
                            if to_chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("toChain"));
                            }
                            to_chain__ = Some(map_.next_value::<Chain>()? as i32);
                        }
                        GeneratedField::ToTxhash => {
                            if to_txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("toTxhash"));
                            }
                            to_txhash__ = Some(map_.next_value()?);
                        }
                        GeneratedField::ToTxStatus => {
                            if to_tx_status__.is_some() {
                                return Err(serde::de::Error::duplicate_field("toTxStatus"));
                            }
                            to_tx_status__ = map_.next_value()?;
                        }
                    }
                }
                Ok(CrossChainSendResponse {
                    from_chain: from_chain__.unwrap_or_default(),
                    from_txhash: from_txhash__.unwrap_or_default(),
                    from_tx_status: from_tx_status__,
                    to_chain: to_chain__.unwrap_or_default(),
                    to_txhash: to_txhash__.unwrap_or_default(),
                    to_tx_status: to_tx_status__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.CrossChainSendResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for DenomMetadata {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.description.is_empty() {
            len += 1;
        }
        if !self.denom_units.is_empty() {
            len += 1;
        }
        if !self.base.is_empty() {
            len += 1;
        }
        if !self.display.is_empty() {
            len += 1;
        }
        if !self.name.is_empty() {
            len += 1;
        }
        if !self.symbol.is_empty() {
            len += 1;
        }
        if self.uri.is_some() {
            len += 1;
        }
        if self.uri_hash.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.DenomMetadata", len)?;
        if !self.description.is_empty() {
            struct_ser.serialize_field("description", &self.description)?;
        }
        if !self.denom_units.is_empty() {
            struct_ser.serialize_field("denomUnits", &self.denom_units)?;
        }
        if !self.base.is_empty() {
            struct_ser.serialize_field("base", &self.base)?;
        }
        if !self.display.is_empty() {
            struct_ser.serialize_field("display", &self.display)?;
        }
        if !self.name.is_empty() {
            struct_ser.serialize_field("name", &self.name)?;
        }
        if !self.symbol.is_empty() {
            struct_ser.serialize_field("symbol", &self.symbol)?;
        }
        if let Some(v) = self.uri.as_ref() {
            struct_ser.serialize_field("uri", v)?;
        }
        if let Some(v) = self.uri_hash.as_ref() {
            struct_ser.serialize_field("uriHash", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for DenomMetadata {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "description",
            "denom_units",
            "denomUnits",
            "base",
            "display",
            "name",
            "symbol",
            "uri",
            "uri_hash",
            "uriHash",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Description,
            DenomUnits,
            Base,
            Display,
            Name,
            Symbol,
            Uri,
            UriHash,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "description" => Ok(GeneratedField::Description),
                            "denomUnits" | "denom_units" => Ok(GeneratedField::DenomUnits),
                            "base" => Ok(GeneratedField::Base),
                            "display" => Ok(GeneratedField::Display),
                            "name" => Ok(GeneratedField::Name),
                            "symbol" => Ok(GeneratedField::Symbol),
                            "uri" => Ok(GeneratedField::Uri),
                            "uriHash" | "uri_hash" => Ok(GeneratedField::UriHash),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = DenomMetadata;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.DenomMetadata")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<DenomMetadata, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut description__ = None;
                let mut denom_units__ = None;
                let mut base__ = None;
                let mut display__ = None;
                let mut name__ = None;
                let mut symbol__ = None;
                let mut uri__ = None;
                let mut uri_hash__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Description => {
                            if description__.is_some() {
                                return Err(serde::de::Error::duplicate_field("description"));
                            }
                            description__ = Some(map_.next_value()?);
                        }
                        GeneratedField::DenomUnits => {
                            if denom_units__.is_some() {
                                return Err(serde::de::Error::duplicate_field("denomUnits"));
                            }
                            denom_units__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Base => {
                            if base__.is_some() {
                                return Err(serde::de::Error::duplicate_field("base"));
                            }
                            base__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Display => {
                            if display__.is_some() {
                                return Err(serde::de::Error::duplicate_field("display"));
                            }
                            display__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Name => {
                            if name__.is_some() {
                                return Err(serde::de::Error::duplicate_field("name"));
                            }
                            name__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Symbol => {
                            if symbol__.is_some() {
                                return Err(serde::de::Error::duplicate_field("symbol"));
                            }
                            symbol__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Uri => {
                            if uri__.is_some() {
                                return Err(serde::de::Error::duplicate_field("uri"));
                            }
                            uri__ = map_.next_value()?;
                        }
                        GeneratedField::UriHash => {
                            if uri_hash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("uriHash"));
                            }
                            uri_hash__ = map_.next_value()?;
                        }
                    }
                }
                Ok(DenomMetadata {
                    description: description__.unwrap_or_default(),
                    denom_units: denom_units__.unwrap_or_default(),
                    base: base__.unwrap_or_default(),
                    display: display__.unwrap_or_default(),
                    name: name__.unwrap_or_default(),
                    symbol: symbol__.unwrap_or_default(),
                    uri: uri__,
                    uri_hash: uri_hash__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.DenomMetadata", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for DenomUnit {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.denom.is_empty() {
            len += 1;
        }
        if self.exponent.is_some() {
            len += 1;
        }
        if !self.aliases.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.DenomUnit", len)?;
        if !self.denom.is_empty() {
            struct_ser.serialize_field("denom", &self.denom)?;
        }
        if let Some(v) = self.exponent.as_ref() {
            struct_ser.serialize_field("exponent", v)?;
        }
        if !self.aliases.is_empty() {
            struct_ser.serialize_field("aliases", &self.aliases)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for DenomUnit {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "denom",
            "exponent",
            "aliases",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Denom,
            Exponent,
            Aliases,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "denom" => Ok(GeneratedField::Denom),
                            "exponent" => Ok(GeneratedField::Exponent),
                            "aliases" => Ok(GeneratedField::Aliases),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = DenomUnit;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.DenomUnit")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<DenomUnit, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut denom__ = None;
                let mut exponent__ = None;
                let mut aliases__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Denom => {
                            if denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("denom"));
                            }
                            denom__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Exponent => {
                            if exponent__.is_some() {
                                return Err(serde::de::Error::duplicate_field("exponent"));
                            }
                            exponent__ = 
                                map_.next_value::<::std::option::Option<::pbjson::private::NumberDeserialize<_>>>()?.map(|x| x.0)
                            ;
                        }
                        GeneratedField::Aliases => {
                            if aliases__.is_some() {
                                return Err(serde::de::Error::duplicate_field("aliases"));
                            }
                            aliases__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(DenomUnit {
                    denom: denom__.unwrap_or_default(),
                    exponent: exponent__,
                    aliases: aliases__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.DenomUnit", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for FeeInfo {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.pay_by_fee_granter {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.FeeInfo", len)?;
        if self.pay_by_fee_granter {
            struct_ser.serialize_field("payByFeeGranter", &self.pay_by_fee_granter)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for FeeInfo {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "pay_by_fee_granter",
            "payByFeeGranter",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            PayByFeeGranter,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "payByFeeGranter" | "pay_by_fee_granter" => Ok(GeneratedField::PayByFeeGranter),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = FeeInfo;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.FeeInfo")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<FeeInfo, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut pay_by_fee_granter__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::PayByFeeGranter => {
                            if pay_by_fee_granter__.is_some() {
                                return Err(serde::de::Error::duplicate_field("payByFeeGranter"));
                            }
                            pay_by_fee_granter__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(FeeInfo {
                    pay_by_fee_granter: pay_by_fee_granter__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.FeeInfo", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetAddrRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if self.key_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.GetAddrRequest", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if let Some(v) = self.key_info.as_ref() {
            struct_ser.serialize_field("keyInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetAddrRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "key_info",
            "keyInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            KeyInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "keyInfo" | "key_info" => Ok(GeneratedField::KeyInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetAddrRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.GetAddrRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetAddrRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut key_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::KeyInfo => {
                            if key_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("keyInfo"));
                            }
                            key_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(GetAddrRequest {
                    chain: chain__,
                    key_info: key_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.GetAddrRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetAddrResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.address.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.GetAddrResponse", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.address.is_empty() {
            struct_ser.serialize_field("address", &self.address)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetAddrResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "address",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Address,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "address" => Ok(GeneratedField::Address),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetAddrResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.GetAddrResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetAddrResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut address__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Address => {
                            if address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("address"));
                            }
                            address__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetAddrResponse {
                    chain: chain__,
                    address: address__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.GetAddrResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetAllDenomMetadataRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.GetAllDenomMetadataRequest", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetAllDenomMetadataRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetAllDenomMetadataRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.GetAllDenomMetadataRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetAllDenomMetadataRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                    }
                }
                Ok(GetAllDenomMetadataRequest {
                    chain: chain__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.GetAllDenomMetadataRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetAllDenomMetadataResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.denom_metadata.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.GetAllDenomMetadataResponse", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.denom_metadata.is_empty() {
            struct_ser.serialize_field("denomMetadata", &self.denom_metadata)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetAllDenomMetadataResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "denom_metadata",
            "denomMetadata",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            DenomMetadata,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "denomMetadata" | "denom_metadata" => Ok(GeneratedField::DenomMetadata),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetAllDenomMetadataResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.GetAllDenomMetadataResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetAllDenomMetadataResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut denom_metadata__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::DenomMetadata => {
                            if denom_metadata__.is_some() {
                                return Err(serde::de::Error::duplicate_field("denomMetadata"));
                            }
                            denom_metadata__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetAllDenomMetadataResponse {
                    chain: chain__,
                    denom_metadata: denom_metadata__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.GetAllDenomMetadataResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetAllMintersRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.GetAllMintersRequest", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetAllMintersRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetAllMintersRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.GetAllMintersRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetAllMintersRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                    }
                }
                Ok(GetAllMintersRequest {
                    chain: chain__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.GetAllMintersRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetAllMintersResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.minters.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.GetAllMintersResponse", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.minters.is_empty() {
            struct_ser.serialize_field("minters", &self.minters)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetAllMintersResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "minters",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Minters,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "minters" => Ok(GeneratedField::Minters),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetAllMintersResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.GetAllMintersResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetAllMintersResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut minters__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Minters => {
                            if minters__.is_some() {
                                return Err(serde::de::Error::duplicate_field("minters"));
                            }
                            minters__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetAllMintersResponse {
                    chain: chain__,
                    minters: minters__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.GetAllMintersResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetBalanceRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if self.denom != 0 {
            len += 1;
        }
        if !self.address.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.GetBalanceRequest", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if self.denom != 0 {
            let v = TfDenom::try_from(self.denom)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", self.denom)))?;
            struct_ser.serialize_field("denom", &v)?;
        }
        if !self.address.is_empty() {
            struct_ser.serialize_field("address", &self.address)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetBalanceRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "denom",
            "address",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Denom,
            Address,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "denom" => Ok(GeneratedField::Denom),
                            "address" => Ok(GeneratedField::Address),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetBalanceRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.GetBalanceRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetBalanceRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut denom__ = None;
                let mut address__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Denom => {
                            if denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("denom"));
                            }
                            denom__ = Some(map_.next_value::<TfDenom>()? as i32);
                        }
                        GeneratedField::Address => {
                            if address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("address"));
                            }
                            address__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetBalanceRequest {
                    chain: chain__,
                    denom: denom__.unwrap_or_default(),
                    address: address__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.GetBalanceRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetBalanceResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if self.denom != 0 {
            len += 1;
        }
        if !self.value.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.GetBalanceResponse", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if self.denom != 0 {
            let v = TfDenom::try_from(self.denom)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", self.denom)))?;
            struct_ser.serialize_field("denom", &v)?;
        }
        if !self.value.is_empty() {
            struct_ser.serialize_field("value", &self.value)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetBalanceResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "denom",
            "value",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Denom,
            Value,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "denom" => Ok(GeneratedField::Denom),
                            "value" => Ok(GeneratedField::Value),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetBalanceResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.GetBalanceResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetBalanceResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut denom__ = None;
                let mut value__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Denom => {
                            if denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("denom"));
                            }
                            denom__ = Some(map_.next_value::<TfDenom>()? as i32);
                        }
                        GeneratedField::Value => {
                            if value__.is_some() {
                                return Err(serde::de::Error::duplicate_field("value"));
                            }
                            value__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetBalanceResponse {
                    chain: chain__,
                    denom: denom__.unwrap_or_default(),
                    value: value__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.GetBalanceResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetDenomMetadataRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.denom.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.GetDenomMetadataRequest", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.denom.is_empty() {
            struct_ser.serialize_field("denom", &self.denom)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetDenomMetadataRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "denom",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Denom,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "denom" => Ok(GeneratedField::Denom),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetDenomMetadataRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.GetDenomMetadataRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetDenomMetadataRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut denom__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Denom => {
                            if denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("denom"));
                            }
                            denom__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetDenomMetadataRequest {
                    chain: chain__,
                    denom: denom__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.GetDenomMetadataRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetDenomMetadataResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if self.metadata.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.GetDenomMetadataResponse", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if let Some(v) = self.metadata.as_ref() {
            struct_ser.serialize_field("metadata", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetDenomMetadataResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "metadata",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Metadata,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "metadata" => Ok(GeneratedField::Metadata),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetDenomMetadataResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.GetDenomMetadataResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetDenomMetadataResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut metadata__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Metadata => {
                            if metadata__.is_some() {
                                return Err(serde::de::Error::duplicate_field("metadata"));
                            }
                            metadata__ = map_.next_value()?;
                        }
                    }
                }
                Ok(GetDenomMetadataResponse {
                    chain: chain__,
                    metadata: metadata__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.GetDenomMetadataResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetFeeBasicAllowanceRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.grantee.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.GetFeeBasicAllowanceRequest", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.grantee.is_empty() {
            struct_ser.serialize_field("grantee", &self.grantee)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetFeeBasicAllowanceRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "grantee",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Grantee,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "grantee" => Ok(GeneratedField::Grantee),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetFeeBasicAllowanceRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.GetFeeBasicAllowanceRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetFeeBasicAllowanceRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut grantee__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Grantee => {
                            if grantee__.is_some() {
                                return Err(serde::de::Error::duplicate_field("grantee"));
                            }
                            grantee__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetFeeBasicAllowanceRequest {
                    chain: chain__,
                    grantee: grantee__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.GetFeeBasicAllowanceRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetFeeBasicAllowanceResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if self.fee_basic_grant.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.GetFeeBasicAllowanceResponse", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if let Some(v) = self.fee_basic_grant.as_ref() {
            struct_ser.serialize_field("feeBasicGrant", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetFeeBasicAllowanceResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "fee_basic_grant",
            "feeBasicGrant",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            FeeBasicGrant,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "feeBasicGrant" | "fee_basic_grant" => Ok(GeneratedField::FeeBasicGrant),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetFeeBasicAllowanceResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.GetFeeBasicAllowanceResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetFeeBasicAllowanceResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut fee_basic_grant__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::FeeBasicGrant => {
                            if fee_basic_grant__.is_some() {
                                return Err(serde::de::Error::duplicate_field("feeBasicGrant"));
                            }
                            fee_basic_grant__ = map_.next_value()?;
                        }
                    }
                }
                Ok(GetFeeBasicAllowanceResponse {
                    chain: chain__,
                    fee_basic_grant: fee_basic_grant__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.GetFeeBasicAllowanceResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetFeeBasicGrant {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.granter.is_empty() {
            len += 1;
        }
        if !self.grantee.is_empty() {
            len += 1;
        }
        if !self.allowance_denom.is_empty() {
            len += 1;
        }
        if !self.allowance_value.is_empty() {
            len += 1;
        }
        if !self.expiration.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.GetFeeBasicGrant", len)?;
        if !self.granter.is_empty() {
            struct_ser.serialize_field("granter", &self.granter)?;
        }
        if !self.grantee.is_empty() {
            struct_ser.serialize_field("grantee", &self.grantee)?;
        }
        if !self.allowance_denom.is_empty() {
            struct_ser.serialize_field("allowanceDenom", &self.allowance_denom)?;
        }
        if !self.allowance_value.is_empty() {
            struct_ser.serialize_field("allowanceValue", &self.allowance_value)?;
        }
        if !self.expiration.is_empty() {
            struct_ser.serialize_field("expiration", &self.expiration)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetFeeBasicGrant {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "granter",
            "grantee",
            "allowance_denom",
            "allowanceDenom",
            "allowance_value",
            "allowanceValue",
            "expiration",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Granter,
            Grantee,
            AllowanceDenom,
            AllowanceValue,
            Expiration,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "granter" => Ok(GeneratedField::Granter),
                            "grantee" => Ok(GeneratedField::Grantee),
                            "allowanceDenom" | "allowance_denom" => Ok(GeneratedField::AllowanceDenom),
                            "allowanceValue" | "allowance_value" => Ok(GeneratedField::AllowanceValue),
                            "expiration" => Ok(GeneratedField::Expiration),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetFeeBasicGrant;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.GetFeeBasicGrant")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetFeeBasicGrant, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut granter__ = None;
                let mut grantee__ = None;
                let mut allowance_denom__ = None;
                let mut allowance_value__ = None;
                let mut expiration__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Granter => {
                            if granter__.is_some() {
                                return Err(serde::de::Error::duplicate_field("granter"));
                            }
                            granter__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Grantee => {
                            if grantee__.is_some() {
                                return Err(serde::de::Error::duplicate_field("grantee"));
                            }
                            grantee__ = Some(map_.next_value()?);
                        }
                        GeneratedField::AllowanceDenom => {
                            if allowance_denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("allowanceDenom"));
                            }
                            allowance_denom__ = Some(map_.next_value()?);
                        }
                        GeneratedField::AllowanceValue => {
                            if allowance_value__.is_some() {
                                return Err(serde::de::Error::duplicate_field("allowanceValue"));
                            }
                            allowance_value__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Expiration => {
                            if expiration__.is_some() {
                                return Err(serde::de::Error::duplicate_field("expiration"));
                            }
                            expiration__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetFeeBasicGrant {
                    granter: granter__.unwrap_or_default(),
                    grantee: grantee__.unwrap_or_default(),
                    allowance_denom: allowance_denom__.unwrap_or_default(),
                    allowance_value: allowance_value__.unwrap_or_default(),
                    expiration: expiration__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.GetFeeBasicGrant", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetMinterRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.address.is_empty() {
            len += 1;
        }
        if self.denom != 0 {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.GetMinterRequest", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.address.is_empty() {
            struct_ser.serialize_field("address", &self.address)?;
        }
        if self.denom != 0 {
            let v = TfDenom::try_from(self.denom)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", self.denom)))?;
            struct_ser.serialize_field("denom", &v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetMinterRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "address",
            "denom",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Address,
            Denom,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "address" => Ok(GeneratedField::Address),
                            "denom" => Ok(GeneratedField::Denom),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetMinterRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.GetMinterRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetMinterRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut address__ = None;
                let mut denom__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Address => {
                            if address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("address"));
                            }
                            address__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Denom => {
                            if denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("denom"));
                            }
                            denom__ = Some(map_.next_value::<TfDenom>()? as i32);
                        }
                    }
                }
                Ok(GetMinterRequest {
                    chain: chain__,
                    address: address__.unwrap_or_default(),
                    denom: denom__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.GetMinterRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetMinterResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.address.is_empty() {
            len += 1;
        }
        if !self.allowance_denom.is_empty() {
            len += 1;
        }
        if !self.allowance_value.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.GetMinterResponse", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.address.is_empty() {
            struct_ser.serialize_field("address", &self.address)?;
        }
        if !self.allowance_denom.is_empty() {
            struct_ser.serialize_field("allowanceDenom", &self.allowance_denom)?;
        }
        if !self.allowance_value.is_empty() {
            struct_ser.serialize_field("allowanceValue", &self.allowance_value)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetMinterResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "address",
            "allowance_denom",
            "allowanceDenom",
            "allowance_value",
            "allowanceValue",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Address,
            AllowanceDenom,
            AllowanceValue,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "address" => Ok(GeneratedField::Address),
                            "allowanceDenom" | "allowance_denom" => Ok(GeneratedField::AllowanceDenom),
                            "allowanceValue" | "allowance_value" => Ok(GeneratedField::AllowanceValue),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetMinterResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.GetMinterResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetMinterResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut address__ = None;
                let mut allowance_denom__ = None;
                let mut allowance_value__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Address => {
                            if address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("address"));
                            }
                            address__ = Some(map_.next_value()?);
                        }
                        GeneratedField::AllowanceDenom => {
                            if allowance_denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("allowanceDenom"));
                            }
                            allowance_denom__ = Some(map_.next_value()?);
                        }
                        GeneratedField::AllowanceValue => {
                            if allowance_value__.is_some() {
                                return Err(serde::de::Error::duplicate_field("allowanceValue"));
                            }
                            allowance_value__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetMinterResponse {
                    chain: chain__,
                    address: address__.unwrap_or_default(),
                    allowance_denom: allowance_denom__.unwrap_or_default(),
                    allowance_value: allowance_value__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.GetMinterResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetTxStatusRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.txhash.is_empty() {
            len += 1;
        }
        if self.broadcast_height.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.GetTxStatusRequest", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        if let Some(v) = self.broadcast_height.as_ref() {
            #[allow(clippy::needless_borrow)]
            struct_ser.serialize_field("broadcastHeight", ToString::to_string(&v).as_str())?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetTxStatusRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "txhash",
            "broadcast_height",
            "broadcastHeight",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Txhash,
            BroadcastHeight,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "txhash" => Ok(GeneratedField::Txhash),
                            "broadcastHeight" | "broadcast_height" => Ok(GeneratedField::BroadcastHeight),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetTxStatusRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.GetTxStatusRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetTxStatusRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut txhash__ = None;
                let mut broadcast_height__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                        GeneratedField::BroadcastHeight => {
                            if broadcast_height__.is_some() {
                                return Err(serde::de::Error::duplicate_field("broadcastHeight"));
                            }
                            broadcast_height__ = 
                                map_.next_value::<::std::option::Option<::pbjson::private::NumberDeserialize<_>>>()?.map(|x| x.0)
                            ;
                        }
                    }
                }
                Ok(GetTxStatusRequest {
                    chain: chain__,
                    txhash: txhash__.unwrap_or_default(),
                    broadcast_height: broadcast_height__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.GetTxStatusRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetTxStatusResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.txhash.is_empty() {
            len += 1;
        }
        if self.status.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.GetTxStatusResponse", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        if let Some(v) = self.status.as_ref() {
            struct_ser.serialize_field("status", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetTxStatusResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "txhash",
            "status",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Txhash,
            Status,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "txhash" => Ok(GeneratedField::Txhash),
                            "status" => Ok(GeneratedField::Status),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetTxStatusResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.GetTxStatusResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetTxStatusResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut txhash__ = None;
                let mut status__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Status => {
                            if status__.is_some() {
                                return Err(serde::de::Error::duplicate_field("status"));
                            }
                            status__ = map_.next_value()?;
                        }
                    }
                }
                Ok(GetTxStatusResponse {
                    chain: chain__,
                    txhash: txhash__.unwrap_or_default(),
                    status: status__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.GetTxStatusResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GrantFeeBasicAllowanceRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if self.granter_key_info.is_some() {
            len += 1;
        }
        if !self.grantee.is_empty() {
            len += 1;
        }
        if self.allowance_denom != 0 {
            len += 1;
        }
        if !self.allowance_value.is_empty() {
            len += 1;
        }
        if self.hours_to_expire != 0 {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.GrantFeeBasicAllowanceRequest", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if let Some(v) = self.granter_key_info.as_ref() {
            struct_ser.serialize_field("granterKeyInfo", v)?;
        }
        if !self.grantee.is_empty() {
            struct_ser.serialize_field("grantee", &self.grantee)?;
        }
        if self.allowance_denom != 0 {
            let v = TfDenom::try_from(self.allowance_denom)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", self.allowance_denom)))?;
            struct_ser.serialize_field("allowanceDenom", &v)?;
        }
        if !self.allowance_value.is_empty() {
            struct_ser.serialize_field("allowanceValue", &self.allowance_value)?;
        }
        if self.hours_to_expire != 0 {
            #[allow(clippy::needless_borrow)]
            struct_ser.serialize_field("hoursToExpire", ToString::to_string(&self.hours_to_expire).as_str())?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GrantFeeBasicAllowanceRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "granter_key_info",
            "granterKeyInfo",
            "grantee",
            "allowance_denom",
            "allowanceDenom",
            "allowance_value",
            "allowanceValue",
            "hours_to_expire",
            "hoursToExpire",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            GranterKeyInfo,
            Grantee,
            AllowanceDenom,
            AllowanceValue,
            HoursToExpire,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "granterKeyInfo" | "granter_key_info" => Ok(GeneratedField::GranterKeyInfo),
                            "grantee" => Ok(GeneratedField::Grantee),
                            "allowanceDenom" | "allowance_denom" => Ok(GeneratedField::AllowanceDenom),
                            "allowanceValue" | "allowance_value" => Ok(GeneratedField::AllowanceValue),
                            "hoursToExpire" | "hours_to_expire" => Ok(GeneratedField::HoursToExpire),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GrantFeeBasicAllowanceRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.GrantFeeBasicAllowanceRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GrantFeeBasicAllowanceRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut granter_key_info__ = None;
                let mut grantee__ = None;
                let mut allowance_denom__ = None;
                let mut allowance_value__ = None;
                let mut hours_to_expire__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::GranterKeyInfo => {
                            if granter_key_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("granterKeyInfo"));
                            }
                            granter_key_info__ = map_.next_value()?;
                        }
                        GeneratedField::Grantee => {
                            if grantee__.is_some() {
                                return Err(serde::de::Error::duplicate_field("grantee"));
                            }
                            grantee__ = Some(map_.next_value()?);
                        }
                        GeneratedField::AllowanceDenom => {
                            if allowance_denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("allowanceDenom"));
                            }
                            allowance_denom__ = Some(map_.next_value::<TfDenom>()? as i32);
                        }
                        GeneratedField::AllowanceValue => {
                            if allowance_value__.is_some() {
                                return Err(serde::de::Error::duplicate_field("allowanceValue"));
                            }
                            allowance_value__ = Some(map_.next_value()?);
                        }
                        GeneratedField::HoursToExpire => {
                            if hours_to_expire__.is_some() {
                                return Err(serde::de::Error::duplicate_field("hoursToExpire"));
                            }
                            hours_to_expire__ = 
                                Some(map_.next_value::<::pbjson::private::NumberDeserialize<_>>()?.0)
                            ;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(GrantFeeBasicAllowanceRequest {
                    chain: chain__,
                    granter_key_info: granter_key_info__,
                    grantee: grantee__.unwrap_or_default(),
                    allowance_denom: allowance_denom__.unwrap_or_default(),
                    allowance_value: allowance_value__.unwrap_or_default(),
                    hours_to_expire: hours_to_expire__.unwrap_or_default(),
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.GrantFeeBasicAllowanceRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GrantFeeBasicAllowanceResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.txhash.is_empty() {
            len += 1;
        }
        if self.tx_status.is_some() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.GrantFeeBasicAllowanceResponse", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        if let Some(v) = self.tx_status.as_ref() {
            struct_ser.serialize_field("txStatus", v)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GrantFeeBasicAllowanceResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "txhash",
            "tx_status",
            "txStatus",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Txhash,
            TxStatus,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "txhash" => Ok(GeneratedField::Txhash),
                            "txStatus" | "tx_status" => Ok(GeneratedField::TxStatus),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GrantFeeBasicAllowanceResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.GrantFeeBasicAllowanceResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GrantFeeBasicAllowanceResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut txhash__ = None;
                let mut tx_status__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                        GeneratedField::TxStatus => {
                            if tx_status__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txStatus"));
                            }
                            tx_status__ = map_.next_value()?;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(GrantFeeBasicAllowanceResponse {
                    chain: chain__,
                    txhash: txhash__.unwrap_or_default(),
                    tx_status: tx_status__,
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.GrantFeeBasicAllowanceResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for InstantiateTfContractRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.code_id != 0 {
            len += 1;
        }
        if !self.label.is_empty() {
            len += 1;
        }
        if self.is_tf {
            len += 1;
        }
        if self.chain.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.InstantiateTfContractRequest", len)?;
        if self.code_id != 0 {
            #[allow(clippy::needless_borrow)]
            struct_ser.serialize_field("codeId", ToString::to_string(&self.code_id).as_str())?;
        }
        if !self.label.is_empty() {
            struct_ser.serialize_field("label", &self.label)?;
        }
        if self.is_tf {
            struct_ser.serialize_field("isTf", &self.is_tf)?;
        }
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for InstantiateTfContractRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "code_id",
            "codeId",
            "label",
            "is_tf",
            "isTf",
            "chain",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            CodeId,
            Label,
            IsTf,
            Chain,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "codeId" | "code_id" => Ok(GeneratedField::CodeId),
                            "label" => Ok(GeneratedField::Label),
                            "isTf" | "is_tf" => Ok(GeneratedField::IsTf),
                            "chain" => Ok(GeneratedField::Chain),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = InstantiateTfContractRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.InstantiateTfContractRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<InstantiateTfContractRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut code_id__ = None;
                let mut label__ = None;
                let mut is_tf__ = None;
                let mut chain__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::CodeId => {
                            if code_id__.is_some() {
                                return Err(serde::de::Error::duplicate_field("codeId"));
                            }
                            code_id__ = 
                                Some(map_.next_value::<::pbjson::private::NumberDeserialize<_>>()?.0)
                            ;
                        }
                        GeneratedField::Label => {
                            if label__.is_some() {
                                return Err(serde::de::Error::duplicate_field("label"));
                            }
                            label__ = Some(map_.next_value()?);
                        }
                        GeneratedField::IsTf => {
                            if is_tf__.is_some() {
                                return Err(serde::de::Error::duplicate_field("isTf"));
                            }
                            is_tf__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                    }
                }
                Ok(InstantiateTfContractRequest {
                    code_id: code_id__.unwrap_or_default(),
                    label: label__.unwrap_or_default(),
                    is_tf: is_tf__.unwrap_or_default(),
                    chain: chain__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.InstantiateTfContractRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for InstantiateTfContractResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.txhash.is_empty() {
            len += 1;
        }
        if self.tx_status.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.InstantiateTfContractResponse", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        if let Some(v) = self.tx_status.as_ref() {
            struct_ser.serialize_field("txStatus", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for InstantiateTfContractResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "txhash",
            "tx_status",
            "txStatus",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Txhash,
            TxStatus,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "txhash" => Ok(GeneratedField::Txhash),
                            "txStatus" | "tx_status" => Ok(GeneratedField::TxStatus),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = InstantiateTfContractResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.InstantiateTfContractResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<InstantiateTfContractResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut txhash__ = None;
                let mut tx_status__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                        GeneratedField::TxStatus => {
                            if tx_status__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txStatus"));
                            }
                            tx_status__ = map_.next_value()?;
                        }
                    }
                }
                Ok(InstantiateTfContractResponse {
                    chain: chain__,
                    txhash: txhash__.unwrap_or_default(),
                    tx_status: tx_status__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.InstantiateTfContractResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for KeyInfo {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.kms_provider_uuid.is_empty() {
            len += 1;
        }
        if self.key_type != 0 {
            len += 1;
        }
        if !self.key_name.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.KeyInfo", len)?;
        if !self.kms_provider_uuid.is_empty() {
            struct_ser.serialize_field("kmsProviderUuid", &self.kms_provider_uuid)?;
        }
        if self.key_type != 0 {
            let v = KeyType::try_from(self.key_type)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", self.key_type)))?;
            struct_ser.serialize_field("keyType", &v)?;
        }
        if !self.key_name.is_empty() {
            struct_ser.serialize_field("keyName", &self.key_name)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for KeyInfo {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "kms_provider_uuid",
            "kmsProviderUuid",
            "key_type",
            "keyType",
            "key_name",
            "keyName",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            KmsProviderUuid,
            KeyType,
            KeyName,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "kmsProviderUuid" | "kms_provider_uuid" => Ok(GeneratedField::KmsProviderUuid),
                            "keyType" | "key_type" => Ok(GeneratedField::KeyType),
                            "keyName" | "key_name" => Ok(GeneratedField::KeyName),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = KeyInfo;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.KeyInfo")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<KeyInfo, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut kms_provider_uuid__ = None;
                let mut key_type__ = None;
                let mut key_name__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::KmsProviderUuid => {
                            if kms_provider_uuid__.is_some() {
                                return Err(serde::de::Error::duplicate_field("kmsProviderUuid"));
                            }
                            kms_provider_uuid__ = Some(map_.next_value()?);
                        }
                        GeneratedField::KeyType => {
                            if key_type__.is_some() {
                                return Err(serde::de::Error::duplicate_field("keyType"));
                            }
                            key_type__ = Some(map_.next_value::<KeyType>()? as i32);
                        }
                        GeneratedField::KeyName => {
                            if key_name__.is_some() {
                                return Err(serde::de::Error::duplicate_field("keyName"));
                            }
                            key_name__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(KeyInfo {
                    kms_provider_uuid: kms_provider_uuid__.unwrap_or_default(),
                    key_type: key_type__.unwrap_or_default(),
                    key_name: key_name__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.KeyInfo", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for KeyType {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        let variant = match self {
            Self::Secp256k1 => "Secp256k1",
            Self::Ed25519 => "Ed25519",
            Self::Secp256r1 => "Secp256r1",
            Self::Rsa2048 => "Rsa2048",
            Self::Aes => "Aes",
        };
        serializer.serialize_str(variant)
    }
}
impl<'de> serde::Deserialize<'de> for KeyType {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "Secp256k1",
            "Ed25519",
            "Secp256r1",
            "Rsa2048",
            "Aes",
        ];

        struct GeneratedVisitor;

        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = KeyType;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                write!(formatter, "expected one of: {:?}", &FIELDS)
            }

            fn visit_i64<E>(self, v: i64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Signed(v), &self)
                    })
            }

            fn visit_u64<E>(self, v: u64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Unsigned(v), &self)
                    })
            }

            fn visit_str<E>(self, value: &str) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                match value {
                    "Secp256k1" => Ok(KeyType::Secp256k1),
                    "Ed25519" => Ok(KeyType::Ed25519),
                    "Secp256r1" => Ok(KeyType::Secp256r1),
                    "Rsa2048" => Ok(KeyType::Rsa2048),
                    "Aes" => Ok(KeyType::Aes),
                    _ => Err(serde::de::Error::unknown_variant(value, FIELDS)),
                }
            }
        }
        deserializer.deserialize_any(GeneratedVisitor)
    }
}
impl serde::Serialize for MintRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if self.minter_key_info.is_some() {
            len += 1;
        }
        if !self.to_address.is_empty() {
            len += 1;
        }
        if self.denom != 0 {
            len += 1;
        }
        if !self.value.is_empty() {
            len += 1;
        }
        if self.fee_info.is_some() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.MintRequest", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if let Some(v) = self.minter_key_info.as_ref() {
            struct_ser.serialize_field("minterKeyInfo", v)?;
        }
        if !self.to_address.is_empty() {
            struct_ser.serialize_field("toAddress", &self.to_address)?;
        }
        if self.denom != 0 {
            let v = TfDenom::try_from(self.denom)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", self.denom)))?;
            struct_ser.serialize_field("denom", &v)?;
        }
        if !self.value.is_empty() {
            struct_ser.serialize_field("value", &self.value)?;
        }
        if let Some(v) = self.fee_info.as_ref() {
            struct_ser.serialize_field("feeInfo", v)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for MintRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "minter_key_info",
            "minterKeyInfo",
            "to_address",
            "toAddress",
            "denom",
            "value",
            "fee_info",
            "feeInfo",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            MinterKeyInfo,
            ToAddress,
            Denom,
            Value,
            FeeInfo,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "minterKeyInfo" | "minter_key_info" => Ok(GeneratedField::MinterKeyInfo),
                            "toAddress" | "to_address" => Ok(GeneratedField::ToAddress),
                            "denom" => Ok(GeneratedField::Denom),
                            "value" => Ok(GeneratedField::Value),
                            "feeInfo" | "fee_info" => Ok(GeneratedField::FeeInfo),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = MintRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.MintRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<MintRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut minter_key_info__ = None;
                let mut to_address__ = None;
                let mut denom__ = None;
                let mut value__ = None;
                let mut fee_info__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::MinterKeyInfo => {
                            if minter_key_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("minterKeyInfo"));
                            }
                            minter_key_info__ = map_.next_value()?;
                        }
                        GeneratedField::ToAddress => {
                            if to_address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("toAddress"));
                            }
                            to_address__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Denom => {
                            if denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("denom"));
                            }
                            denom__ = Some(map_.next_value::<TfDenom>()? as i32);
                        }
                        GeneratedField::Value => {
                            if value__.is_some() {
                                return Err(serde::de::Error::duplicate_field("value"));
                            }
                            value__ = Some(map_.next_value()?);
                        }
                        GeneratedField::FeeInfo => {
                            if fee_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("feeInfo"));
                            }
                            fee_info__ = map_.next_value()?;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(MintRequest {
                    chain: chain__,
                    minter_key_info: minter_key_info__,
                    to_address: to_address__.unwrap_or_default(),
                    denom: denom__.unwrap_or_default(),
                    value: value__.unwrap_or_default(),
                    fee_info: fee_info__,
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.MintRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for MintResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.txhash.is_empty() {
            len += 1;
        }
        if self.tx_status.is_some() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.MintResponse", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        if let Some(v) = self.tx_status.as_ref() {
            struct_ser.serialize_field("txStatus", v)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for MintResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "txhash",
            "tx_status",
            "txStatus",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Txhash,
            TxStatus,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "txhash" => Ok(GeneratedField::Txhash),
                            "txStatus" | "tx_status" => Ok(GeneratedField::TxStatus),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = MintResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.MintResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<MintResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut txhash__ = None;
                let mut tx_status__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                        GeneratedField::TxStatus => {
                            if tx_status__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txStatus"));
                            }
                            tx_status__ = map_.next_value()?;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(MintResponse {
                    chain: chain__,
                    txhash: txhash__.unwrap_or_default(),
                    tx_status: tx_status__,
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.MintResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for NtfDenom {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        let variant = match self {
            Self::Wfusd => "WFUSD",
            Self::Sat => "SAT",
            Self::Wei => "WEI",
            Self::Lam => "LAM",
        };
        serializer.serialize_str(variant)
    }
}
impl<'de> serde::Deserialize<'de> for NtfDenom {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "WFUSD",
            "SAT",
            "WEI",
            "LAM",
        ];

        struct GeneratedVisitor;

        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = NtfDenom;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                write!(formatter, "expected one of: {:?}", &FIELDS)
            }

            fn visit_i64<E>(self, v: i64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Signed(v), &self)
                    })
            }

            fn visit_u64<E>(self, v: u64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Unsigned(v), &self)
                    })
            }

            fn visit_str<E>(self, value: &str) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                match value {
                    "WFUSD" => Ok(NtfDenom::Wfusd),
                    "SAT" => Ok(NtfDenom::Sat),
                    "WEI" => Ok(NtfDenom::Wei),
                    "LAM" => Ok(NtfDenom::Lam),
                    _ => Err(serde::de::Error::unknown_variant(value, FIELDS)),
                }
            }
        }
        deserializer.deserialize_any(GeneratedVisitor)
    }
}
impl serde::Serialize for PauseRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.pauser_key_info.is_some() {
            len += 1;
        }
        if self.chain.is_some() {
            len += 1;
        }
        if self.fee_info.is_some() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.PauseRequest", len)?;
        if let Some(v) = self.pauser_key_info.as_ref() {
            struct_ser.serialize_field("pauserKeyInfo", v)?;
        }
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if let Some(v) = self.fee_info.as_ref() {
            struct_ser.serialize_field("feeInfo", v)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for PauseRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "pauser_key_info",
            "pauserKeyInfo",
            "chain",
            "fee_info",
            "feeInfo",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            PauserKeyInfo,
            Chain,
            FeeInfo,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "pauserKeyInfo" | "pauser_key_info" => Ok(GeneratedField::PauserKeyInfo),
                            "chain" => Ok(GeneratedField::Chain),
                            "feeInfo" | "fee_info" => Ok(GeneratedField::FeeInfo),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = PauseRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.PauseRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<PauseRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut pauser_key_info__ = None;
                let mut chain__ = None;
                let mut fee_info__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::PauserKeyInfo => {
                            if pauser_key_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("pauserKeyInfo"));
                            }
                            pauser_key_info__ = map_.next_value()?;
                        }
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::FeeInfo => {
                            if fee_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("feeInfo"));
                            }
                            fee_info__ = map_.next_value()?;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(PauseRequest {
                    pauser_key_info: pauser_key_info__,
                    chain: chain__,
                    fee_info: fee_info__,
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.PauseRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for PauseResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.txhash.is_empty() {
            len += 1;
        }
        if self.tx_status.is_some() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.PauseResponse", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        if let Some(v) = self.tx_status.as_ref() {
            struct_ser.serialize_field("txStatus", v)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for PauseResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "txhash",
            "tx_status",
            "txStatus",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Txhash,
            TxStatus,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "txhash" => Ok(GeneratedField::Txhash),
                            "txStatus" | "tx_status" => Ok(GeneratedField::TxStatus),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = PauseResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.PauseResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<PauseResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut txhash__ = None;
                let mut tx_status__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                        GeneratedField::TxStatus => {
                            if tx_status__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txStatus"));
                            }
                            tx_status__ = map_.next_value()?;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(PauseResponse {
                    chain: chain__,
                    txhash: txhash__.unwrap_or_default(),
                    tx_status: tx_status__,
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.PauseResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for RedeemRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if self.from_key_info.is_some() {
            len += 1;
        }
        if !self.minter_address.is_empty() {
            len += 1;
        }
        if self.denom != 0 {
            len += 1;
        }
        if !self.value.is_empty() {
            len += 1;
        }
        if self.fee_info.is_some() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.RedeemRequest", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if let Some(v) = self.from_key_info.as_ref() {
            struct_ser.serialize_field("fromKeyInfo", v)?;
        }
        if !self.minter_address.is_empty() {
            struct_ser.serialize_field("minterAddress", &self.minter_address)?;
        }
        if self.denom != 0 {
            let v = TfDenom::try_from(self.denom)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", self.denom)))?;
            struct_ser.serialize_field("denom", &v)?;
        }
        if !self.value.is_empty() {
            struct_ser.serialize_field("value", &self.value)?;
        }
        if let Some(v) = self.fee_info.as_ref() {
            struct_ser.serialize_field("feeInfo", v)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for RedeemRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "from_key_info",
            "fromKeyInfo",
            "minter_address",
            "minterAddress",
            "denom",
            "value",
            "fee_info",
            "feeInfo",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            FromKeyInfo,
            MinterAddress,
            Denom,
            Value,
            FeeInfo,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "fromKeyInfo" | "from_key_info" => Ok(GeneratedField::FromKeyInfo),
                            "minterAddress" | "minter_address" => Ok(GeneratedField::MinterAddress),
                            "denom" => Ok(GeneratedField::Denom),
                            "value" => Ok(GeneratedField::Value),
                            "feeInfo" | "fee_info" => Ok(GeneratedField::FeeInfo),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = RedeemRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.RedeemRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<RedeemRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut from_key_info__ = None;
                let mut minter_address__ = None;
                let mut denom__ = None;
                let mut value__ = None;
                let mut fee_info__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::FromKeyInfo => {
                            if from_key_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("fromKeyInfo"));
                            }
                            from_key_info__ = map_.next_value()?;
                        }
                        GeneratedField::MinterAddress => {
                            if minter_address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("minterAddress"));
                            }
                            minter_address__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Denom => {
                            if denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("denom"));
                            }
                            denom__ = Some(map_.next_value::<TfDenom>()? as i32);
                        }
                        GeneratedField::Value => {
                            if value__.is_some() {
                                return Err(serde::de::Error::duplicate_field("value"));
                            }
                            value__ = Some(map_.next_value()?);
                        }
                        GeneratedField::FeeInfo => {
                            if fee_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("feeInfo"));
                            }
                            fee_info__ = map_.next_value()?;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(RedeemRequest {
                    chain: chain__,
                    from_key_info: from_key_info__,
                    minter_address: minter_address__.unwrap_or_default(),
                    denom: denom__.unwrap_or_default(),
                    value: value__.unwrap_or_default(),
                    fee_info: fee_info__,
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.RedeemRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for RedeemResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.txhash.is_empty() {
            len += 1;
        }
        if self.tx_status.is_some() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.RedeemResponse", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        if let Some(v) = self.tx_status.as_ref() {
            struct_ser.serialize_field("txStatus", v)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for RedeemResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "txhash",
            "tx_status",
            "txStatus",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Txhash,
            TxStatus,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "txhash" => Ok(GeneratedField::Txhash),
                            "txStatus" | "tx_status" => Ok(GeneratedField::TxStatus),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = RedeemResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.RedeemResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<RedeemResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut txhash__ = None;
                let mut tx_status__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                        GeneratedField::TxStatus => {
                            if tx_status__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txStatus"));
                            }
                            tx_status__ = map_.next_value()?;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(RedeemResponse {
                    chain: chain__,
                    txhash: txhash__.unwrap_or_default(),
                    tx_status: tx_status__,
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.RedeemResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for RemoveMinterControllerRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.controller.is_empty() {
            len += 1;
        }
        if !self.minter.is_empty() {
            len += 1;
        }
        if self.masterminter_key_info.is_some() {
            len += 1;
        }
        if self.chain.is_some() {
            len += 1;
        }
        if self.fee_info.is_some() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.RemoveMinterControllerRequest", len)?;
        if !self.controller.is_empty() {
            struct_ser.serialize_field("controller", &self.controller)?;
        }
        if !self.minter.is_empty() {
            struct_ser.serialize_field("minter", &self.minter)?;
        }
        if let Some(v) = self.masterminter_key_info.as_ref() {
            struct_ser.serialize_field("masterminterKeyInfo", v)?;
        }
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if let Some(v) = self.fee_info.as_ref() {
            struct_ser.serialize_field("feeInfo", v)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for RemoveMinterControllerRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "controller",
            "minter",
            "masterminter_key_info",
            "masterminterKeyInfo",
            "chain",
            "fee_info",
            "feeInfo",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Controller,
            Minter,
            MasterminterKeyInfo,
            Chain,
            FeeInfo,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "controller" => Ok(GeneratedField::Controller),
                            "minter" => Ok(GeneratedField::Minter),
                            "masterminterKeyInfo" | "masterminter_key_info" => Ok(GeneratedField::MasterminterKeyInfo),
                            "chain" => Ok(GeneratedField::Chain),
                            "feeInfo" | "fee_info" => Ok(GeneratedField::FeeInfo),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = RemoveMinterControllerRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.RemoveMinterControllerRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<RemoveMinterControllerRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut controller__ = None;
                let mut minter__ = None;
                let mut masterminter_key_info__ = None;
                let mut chain__ = None;
                let mut fee_info__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Controller => {
                            if controller__.is_some() {
                                return Err(serde::de::Error::duplicate_field("controller"));
                            }
                            controller__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Minter => {
                            if minter__.is_some() {
                                return Err(serde::de::Error::duplicate_field("minter"));
                            }
                            minter__ = Some(map_.next_value()?);
                        }
                        GeneratedField::MasterminterKeyInfo => {
                            if masterminter_key_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("masterminterKeyInfo"));
                            }
                            masterminter_key_info__ = map_.next_value()?;
                        }
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::FeeInfo => {
                            if fee_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("feeInfo"));
                            }
                            fee_info__ = map_.next_value()?;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(RemoveMinterControllerRequest {
                    controller: controller__.unwrap_or_default(),
                    minter: minter__.unwrap_or_default(),
                    masterminter_key_info: masterminter_key_info__,
                    chain: chain__,
                    fee_info: fee_info__,
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.RemoveMinterControllerRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for RemoveMinterControllerResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.txhash.is_empty() {
            len += 1;
        }
        if self.tx_status.is_some() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.RemoveMinterControllerResponse", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        if let Some(v) = self.tx_status.as_ref() {
            struct_ser.serialize_field("txStatus", v)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for RemoveMinterControllerResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "txhash",
            "tx_status",
            "txStatus",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Txhash,
            TxStatus,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "txhash" => Ok(GeneratedField::Txhash),
                            "txStatus" | "tx_status" => Ok(GeneratedField::TxStatus),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = RemoveMinterControllerResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.RemoveMinterControllerResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<RemoveMinterControllerResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut txhash__ = None;
                let mut tx_status__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                        GeneratedField::TxStatus => {
                            if tx_status__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txStatus"));
                            }
                            tx_status__ = map_.next_value()?;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(RemoveMinterControllerResponse {
                    chain: chain__,
                    txhash: txhash__.unwrap_or_default(),
                    tx_status: tx_status__,
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.RemoveMinterControllerResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for RemoveMinterRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.address.is_empty() {
            len += 1;
        }
        if self.denom != 0 {
            len += 1;
        }
        if self.mintercontroller_key_info.is_some() {
            len += 1;
        }
        if self.chain.is_some() {
            len += 1;
        }
        if self.fee_info.is_some() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.RemoveMinterRequest", len)?;
        if !self.address.is_empty() {
            struct_ser.serialize_field("address", &self.address)?;
        }
        if self.denom != 0 {
            let v = TfDenom::try_from(self.denom)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", self.denom)))?;
            struct_ser.serialize_field("denom", &v)?;
        }
        if let Some(v) = self.mintercontroller_key_info.as_ref() {
            struct_ser.serialize_field("mintercontrollerKeyInfo", v)?;
        }
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if let Some(v) = self.fee_info.as_ref() {
            struct_ser.serialize_field("feeInfo", v)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for RemoveMinterRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "address",
            "denom",
            "mintercontroller_key_info",
            "mintercontrollerKeyInfo",
            "chain",
            "fee_info",
            "feeInfo",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Address,
            Denom,
            MintercontrollerKeyInfo,
            Chain,
            FeeInfo,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "address" => Ok(GeneratedField::Address),
                            "denom" => Ok(GeneratedField::Denom),
                            "mintercontrollerKeyInfo" | "mintercontroller_key_info" => Ok(GeneratedField::MintercontrollerKeyInfo),
                            "chain" => Ok(GeneratedField::Chain),
                            "feeInfo" | "fee_info" => Ok(GeneratedField::FeeInfo),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = RemoveMinterRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.RemoveMinterRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<RemoveMinterRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut address__ = None;
                let mut denom__ = None;
                let mut mintercontroller_key_info__ = None;
                let mut chain__ = None;
                let mut fee_info__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Address => {
                            if address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("address"));
                            }
                            address__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Denom => {
                            if denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("denom"));
                            }
                            denom__ = Some(map_.next_value::<TfDenom>()? as i32);
                        }
                        GeneratedField::MintercontrollerKeyInfo => {
                            if mintercontroller_key_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("mintercontrollerKeyInfo"));
                            }
                            mintercontroller_key_info__ = map_.next_value()?;
                        }
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::FeeInfo => {
                            if fee_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("feeInfo"));
                            }
                            fee_info__ = map_.next_value()?;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(RemoveMinterRequest {
                    address: address__.unwrap_or_default(),
                    denom: denom__.unwrap_or_default(),
                    mintercontroller_key_info: mintercontroller_key_info__,
                    chain: chain__,
                    fee_info: fee_info__,
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.RemoveMinterRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for RemoveMinterResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.txhash.is_empty() {
            len += 1;
        }
        if self.tx_status.is_some() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.RemoveMinterResponse", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        if let Some(v) = self.tx_status.as_ref() {
            struct_ser.serialize_field("txStatus", v)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for RemoveMinterResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "txhash",
            "tx_status",
            "txStatus",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Txhash,
            TxStatus,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "txhash" => Ok(GeneratedField::Txhash),
                            "txStatus" | "tx_status" => Ok(GeneratedField::TxStatus),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = RemoveMinterResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.RemoveMinterResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<RemoveMinterResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut txhash__ = None;
                let mut tx_status__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                        GeneratedField::TxStatus => {
                            if tx_status__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txStatus"));
                            }
                            tx_status__ = map_.next_value()?;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(RemoveMinterResponse {
                    chain: chain__,
                    txhash: txhash__.unwrap_or_default(),
                    tx_status: tx_status__,
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.RemoveMinterResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for RevokeFeeBasicAllowanceRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if self.granter_key_info.is_some() {
            len += 1;
        }
        if !self.grantee.is_empty() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.RevokeFeeBasicAllowanceRequest", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if let Some(v) = self.granter_key_info.as_ref() {
            struct_ser.serialize_field("granterKeyInfo", v)?;
        }
        if !self.grantee.is_empty() {
            struct_ser.serialize_field("grantee", &self.grantee)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for RevokeFeeBasicAllowanceRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "granter_key_info",
            "granterKeyInfo",
            "grantee",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            GranterKeyInfo,
            Grantee,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "granterKeyInfo" | "granter_key_info" => Ok(GeneratedField::GranterKeyInfo),
                            "grantee" => Ok(GeneratedField::Grantee),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = RevokeFeeBasicAllowanceRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.RevokeFeeBasicAllowanceRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<RevokeFeeBasicAllowanceRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut granter_key_info__ = None;
                let mut grantee__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::GranterKeyInfo => {
                            if granter_key_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("granterKeyInfo"));
                            }
                            granter_key_info__ = map_.next_value()?;
                        }
                        GeneratedField::Grantee => {
                            if grantee__.is_some() {
                                return Err(serde::de::Error::duplicate_field("grantee"));
                            }
                            grantee__ = Some(map_.next_value()?);
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(RevokeFeeBasicAllowanceRequest {
                    chain: chain__,
                    granter_key_info: granter_key_info__,
                    grantee: grantee__.unwrap_or_default(),
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.RevokeFeeBasicAllowanceRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for RevokeFeeBasicAllowanceResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.common_tx_response.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.RevokeFeeBasicAllowanceResponse", len)?;
        if let Some(v) = self.common_tx_response.as_ref() {
            struct_ser.serialize_field("commonTxResponse", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for RevokeFeeBasicAllowanceResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "common_tx_response",
            "commonTxResponse",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            CommonTxResponse,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "commonTxResponse" | "common_tx_response" => Ok(GeneratedField::CommonTxResponse),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = RevokeFeeBasicAllowanceResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.RevokeFeeBasicAllowanceResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<RevokeFeeBasicAllowanceResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut common_tx_response__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::CommonTxResponse => {
                            if common_tx_response__.is_some() {
                                return Err(serde::de::Error::duplicate_field("commonTxResponse"));
                            }
                            common_tx_response__ = map_.next_value()?;
                        }
                    }
                }
                Ok(RevokeFeeBasicAllowanceResponse {
                    common_tx_response: common_tx_response__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.RevokeFeeBasicAllowanceResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for SendRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if self.from_key_info.is_some() {
            len += 1;
        }
        if !self.to_address.is_empty() {
            len += 1;
        }
        if self.denom != 0 {
            len += 1;
        }
        if !self.value.is_empty() {
            len += 1;
        }
        if self.fee_info.is_some() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.SendRequest", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if let Some(v) = self.from_key_info.as_ref() {
            struct_ser.serialize_field("fromKeyInfo", v)?;
        }
        if !self.to_address.is_empty() {
            struct_ser.serialize_field("toAddress", &self.to_address)?;
        }
        if self.denom != 0 {
            let v = TfDenom::try_from(self.denom)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", self.denom)))?;
            struct_ser.serialize_field("denom", &v)?;
        }
        if !self.value.is_empty() {
            struct_ser.serialize_field("value", &self.value)?;
        }
        if let Some(v) = self.fee_info.as_ref() {
            struct_ser.serialize_field("feeInfo", v)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for SendRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "from_key_info",
            "fromKeyInfo",
            "to_address",
            "toAddress",
            "denom",
            "value",
            "fee_info",
            "feeInfo",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            FromKeyInfo,
            ToAddress,
            Denom,
            Value,
            FeeInfo,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "fromKeyInfo" | "from_key_info" => Ok(GeneratedField::FromKeyInfo),
                            "toAddress" | "to_address" => Ok(GeneratedField::ToAddress),
                            "denom" => Ok(GeneratedField::Denom),
                            "value" => Ok(GeneratedField::Value),
                            "feeInfo" | "fee_info" => Ok(GeneratedField::FeeInfo),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = SendRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.SendRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<SendRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut from_key_info__ = None;
                let mut to_address__ = None;
                let mut denom__ = None;
                let mut value__ = None;
                let mut fee_info__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::FromKeyInfo => {
                            if from_key_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("fromKeyInfo"));
                            }
                            from_key_info__ = map_.next_value()?;
                        }
                        GeneratedField::ToAddress => {
                            if to_address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("toAddress"));
                            }
                            to_address__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Denom => {
                            if denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("denom"));
                            }
                            denom__ = Some(map_.next_value::<TfDenom>()? as i32);
                        }
                        GeneratedField::Value => {
                            if value__.is_some() {
                                return Err(serde::de::Error::duplicate_field("value"));
                            }
                            value__ = Some(map_.next_value()?);
                        }
                        GeneratedField::FeeInfo => {
                            if fee_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("feeInfo"));
                            }
                            fee_info__ = map_.next_value()?;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(SendRequest {
                    chain: chain__,
                    from_key_info: from_key_info__,
                    to_address: to_address__.unwrap_or_default(),
                    denom: denom__.unwrap_or_default(),
                    value: value__.unwrap_or_default(),
                    fee_info: fee_info__,
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.SendRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for SendResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.txhash.is_empty() {
            len += 1;
        }
        if self.tx_status.is_some() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.SendResponse", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        if let Some(v) = self.tx_status.as_ref() {
            struct_ser.serialize_field("txStatus", v)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for SendResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "txhash",
            "tx_status",
            "txStatus",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Txhash,
            TxStatus,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "txhash" => Ok(GeneratedField::Txhash),
                            "txStatus" | "tx_status" => Ok(GeneratedField::TxStatus),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = SendResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.SendResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<SendResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut txhash__ = None;
                let mut tx_status__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                        GeneratedField::TxStatus => {
                            if tx_status__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txStatus"));
                            }
                            tx_status__ = map_.next_value()?;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(SendResponse {
                    chain: chain__,
                    txhash: txhash__.unwrap_or_default(),
                    tx_status: tx_status__,
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.SendResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for SetDenomMetadataRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.metadata.is_some() {
            len += 1;
        }
        if self.masterminter_key_info.is_some() {
            len += 1;
        }
        if self.chain.is_some() {
            len += 1;
        }
        if self.fee_info.is_some() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.SetDenomMetadataRequest", len)?;
        if let Some(v) = self.metadata.as_ref() {
            struct_ser.serialize_field("metadata", v)?;
        }
        if let Some(v) = self.masterminter_key_info.as_ref() {
            struct_ser.serialize_field("masterminterKeyInfo", v)?;
        }
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if let Some(v) = self.fee_info.as_ref() {
            struct_ser.serialize_field("feeInfo", v)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for SetDenomMetadataRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "metadata",
            "masterminter_key_info",
            "masterminterKeyInfo",
            "chain",
            "fee_info",
            "feeInfo",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Metadata,
            MasterminterKeyInfo,
            Chain,
            FeeInfo,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "metadata" => Ok(GeneratedField::Metadata),
                            "masterminterKeyInfo" | "masterminter_key_info" => Ok(GeneratedField::MasterminterKeyInfo),
                            "chain" => Ok(GeneratedField::Chain),
                            "feeInfo" | "fee_info" => Ok(GeneratedField::FeeInfo),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = SetDenomMetadataRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.SetDenomMetadataRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<SetDenomMetadataRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut metadata__ = None;
                let mut masterminter_key_info__ = None;
                let mut chain__ = None;
                let mut fee_info__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Metadata => {
                            if metadata__.is_some() {
                                return Err(serde::de::Error::duplicate_field("metadata"));
                            }
                            metadata__ = map_.next_value()?;
                        }
                        GeneratedField::MasterminterKeyInfo => {
                            if masterminter_key_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("masterminterKeyInfo"));
                            }
                            masterminter_key_info__ = map_.next_value()?;
                        }
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::FeeInfo => {
                            if fee_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("feeInfo"));
                            }
                            fee_info__ = map_.next_value()?;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(SetDenomMetadataRequest {
                    metadata: metadata__,
                    masterminter_key_info: masterminter_key_info__,
                    chain: chain__,
                    fee_info: fee_info__,
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.SetDenomMetadataRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for SetDenomMetadataResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.txhash.is_empty() {
            len += 1;
        }
        if self.tx_status.is_some() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.SetDenomMetadataResponse", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        if let Some(v) = self.tx_status.as_ref() {
            struct_ser.serialize_field("txStatus", v)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for SetDenomMetadataResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "txhash",
            "tx_status",
            "txStatus",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Txhash,
            TxStatus,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "txhash" => Ok(GeneratedField::Txhash),
                            "txStatus" | "tx_status" => Ok(GeneratedField::TxStatus),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = SetDenomMetadataResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.SetDenomMetadataResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<SetDenomMetadataResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut txhash__ = None;
                let mut tx_status__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                        GeneratedField::TxStatus => {
                            if tx_status__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txStatus"));
                            }
                            tx_status__ = map_.next_value()?;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(SetDenomMetadataResponse {
                    chain: chain__,
                    txhash: txhash__.unwrap_or_default(),
                    tx_status: tx_status__,
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.SetDenomMetadataResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for StoreCodeRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.wasm_file.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.StoreCodeRequest", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.wasm_file.is_empty() {
            struct_ser.serialize_field("wasmFile", &self.wasm_file)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for StoreCodeRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "wasm_file",
            "wasmFile",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            WasmFile,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "wasmFile" | "wasm_file" => Ok(GeneratedField::WasmFile),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = StoreCodeRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.StoreCodeRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<StoreCodeRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut wasm_file__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::WasmFile => {
                            if wasm_file__.is_some() {
                                return Err(serde::de::Error::duplicate_field("wasmFile"));
                            }
                            wasm_file__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(StoreCodeRequest {
                    chain: chain__,
                    wasm_file: wasm_file__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.StoreCodeRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for StoreCodeResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.txhash.is_empty() {
            len += 1;
        }
        if self.tx_status.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.StoreCodeResponse", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        if let Some(v) = self.tx_status.as_ref() {
            struct_ser.serialize_field("txStatus", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for StoreCodeResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "txhash",
            "tx_status",
            "txStatus",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Txhash,
            TxStatus,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "txhash" => Ok(GeneratedField::Txhash),
                            "txStatus" | "tx_status" => Ok(GeneratedField::TxStatus),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = StoreCodeResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.StoreCodeResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<StoreCodeResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut txhash__ = None;
                let mut tx_status__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                        GeneratedField::TxStatus => {
                            if tx_status__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txStatus"));
                            }
                            tx_status__ = map_.next_value()?;
                        }
                    }
                }
                Ok(StoreCodeResponse {
                    chain: chain__,
                    txhash: txhash__.unwrap_or_default(),
                    tx_status: tx_status__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.StoreCodeResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for TfDenom {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        let variant = match self {
            Self::UwfUsd => "uwfUSD",
            Self::WSat => "wSAT",
            Self::WWei => "wWEI",
            Self::WLam => "wLAM",
            Self::UwfGbp => "uwfGBP",
        };
        serializer.serialize_str(variant)
    }
}
impl<'de> serde::Deserialize<'de> for TfDenom {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "uwfUSD",
            "wSAT",
            "wWEI",
            "wLAM",
            "uwfGBP",
        ];

        struct GeneratedVisitor;

        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = TfDenom;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                write!(formatter, "expected one of: {:?}", &FIELDS)
            }

            fn visit_i64<E>(self, v: i64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Signed(v), &self)
                    })
            }

            fn visit_u64<E>(self, v: u64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Unsigned(v), &self)
                    })
            }

            fn visit_str<E>(self, value: &str) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                match value {
                    "uwfUSD" => Ok(TfDenom::UwfUsd),
                    "wSAT" => Ok(TfDenom::WSat),
                    "wWEI" => Ok(TfDenom::WWei),
                    "wLAM" => Ok(TfDenom::WLam),
                    "uwfGBP" => Ok(TfDenom::UwfGbp),
                    _ => Err(serde::de::Error::unknown_variant(value, FIELDS)),
                }
            }
        }
        deserializer.deserialize_any(GeneratedVisitor)
    }
}
impl serde::Serialize for TrackingInfo {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.tracking_id.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.TrackingInfo", len)?;
        if !self.tracking_id.is_empty() {
            struct_ser.serialize_field("trackingId", &self.tracking_id)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for TrackingInfo {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "tracking_id",
            "trackingId",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            TrackingId,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "trackingId" | "tracking_id" => Ok(GeneratedField::TrackingId),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = TrackingInfo;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.TrackingInfo")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<TrackingInfo, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut tracking_id__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::TrackingId => {
                            if tracking_id__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingId"));
                            }
                            tracking_id__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(TrackingInfo {
                    tracking_id: tracking_id__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.TrackingInfo", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for TxStatusResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.code.is_empty() {
            len += 1;
        }
        if !self.codespace.is_empty() {
            len += 1;
        }
        if !self.msg.is_empty() {
            len += 1;
        }
        if self.broadcast_height != 0 {
            len += 1;
        }
        if self.current_height != 0 {
            len += 1;
        }
        if self.tx_height != 0 {
            len += 1;
        }
        if self.timeout_height != 0 {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.TxStatusResponse", len)?;
        if !self.code.is_empty() {
            struct_ser.serialize_field("code", &self.code)?;
        }
        if !self.codespace.is_empty() {
            struct_ser.serialize_field("codespace", &self.codespace)?;
        }
        if !self.msg.is_empty() {
            struct_ser.serialize_field("msg", &self.msg)?;
        }
        if self.broadcast_height != 0 {
            #[allow(clippy::needless_borrow)]
            struct_ser.serialize_field("broadcastHeight", ToString::to_string(&self.broadcast_height).as_str())?;
        }
        if self.current_height != 0 {
            #[allow(clippy::needless_borrow)]
            struct_ser.serialize_field("currentHeight", ToString::to_string(&self.current_height).as_str())?;
        }
        if self.tx_height != 0 {
            #[allow(clippy::needless_borrow)]
            struct_ser.serialize_field("txHeight", ToString::to_string(&self.tx_height).as_str())?;
        }
        if self.timeout_height != 0 {
            #[allow(clippy::needless_borrow)]
            struct_ser.serialize_field("timeoutHeight", ToString::to_string(&self.timeout_height).as_str())?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for TxStatusResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "code",
            "codespace",
            "msg",
            "broadcast_height",
            "broadcastHeight",
            "current_height",
            "currentHeight",
            "tx_height",
            "txHeight",
            "timeout_height",
            "timeoutHeight",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Code,
            Codespace,
            Msg,
            BroadcastHeight,
            CurrentHeight,
            TxHeight,
            TimeoutHeight,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "code" => Ok(GeneratedField::Code),
                            "codespace" => Ok(GeneratedField::Codespace),
                            "msg" => Ok(GeneratedField::Msg),
                            "broadcastHeight" | "broadcast_height" => Ok(GeneratedField::BroadcastHeight),
                            "currentHeight" | "current_height" => Ok(GeneratedField::CurrentHeight),
                            "txHeight" | "tx_height" => Ok(GeneratedField::TxHeight),
                            "timeoutHeight" | "timeout_height" => Ok(GeneratedField::TimeoutHeight),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = TxStatusResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.TxStatusResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<TxStatusResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut code__ = None;
                let mut codespace__ = None;
                let mut msg__ = None;
                let mut broadcast_height__ = None;
                let mut current_height__ = None;
                let mut tx_height__ = None;
                let mut timeout_height__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Code => {
                            if code__.is_some() {
                                return Err(serde::de::Error::duplicate_field("code"));
                            }
                            code__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Codespace => {
                            if codespace__.is_some() {
                                return Err(serde::de::Error::duplicate_field("codespace"));
                            }
                            codespace__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Msg => {
                            if msg__.is_some() {
                                return Err(serde::de::Error::duplicate_field("msg"));
                            }
                            msg__ = Some(map_.next_value()?);
                        }
                        GeneratedField::BroadcastHeight => {
                            if broadcast_height__.is_some() {
                                return Err(serde::de::Error::duplicate_field("broadcastHeight"));
                            }
                            broadcast_height__ = 
                                Some(map_.next_value::<::pbjson::private::NumberDeserialize<_>>()?.0)
                            ;
                        }
                        GeneratedField::CurrentHeight => {
                            if current_height__.is_some() {
                                return Err(serde::de::Error::duplicate_field("currentHeight"));
                            }
                            current_height__ = 
                                Some(map_.next_value::<::pbjson::private::NumberDeserialize<_>>()?.0)
                            ;
                        }
                        GeneratedField::TxHeight => {
                            if tx_height__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txHeight"));
                            }
                            tx_height__ = 
                                Some(map_.next_value::<::pbjson::private::NumberDeserialize<_>>()?.0)
                            ;
                        }
                        GeneratedField::TimeoutHeight => {
                            if timeout_height__.is_some() {
                                return Err(serde::de::Error::duplicate_field("timeoutHeight"));
                            }
                            timeout_height__ = 
                                Some(map_.next_value::<::pbjson::private::NumberDeserialize<_>>()?.0)
                            ;
                        }
                    }
                }
                Ok(TxStatusResponse {
                    code: code__.unwrap_or_default(),
                    codespace: codespace__.unwrap_or_default(),
                    msg: msg__.unwrap_or_default(),
                    broadcast_height: broadcast_height__.unwrap_or_default(),
                    current_height: current_height__.unwrap_or_default(),
                    tx_height: tx_height__.unwrap_or_default(),
                    timeout_height: timeout_height__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.TxStatusResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for UnblacklistRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.address.is_empty() {
            len += 1;
        }
        if self.blacklister_key_info.is_some() {
            len += 1;
        }
        if self.chain.is_some() {
            len += 1;
        }
        if self.fee_info.is_some() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.UnblacklistRequest", len)?;
        if !self.address.is_empty() {
            struct_ser.serialize_field("address", &self.address)?;
        }
        if let Some(v) = self.blacklister_key_info.as_ref() {
            struct_ser.serialize_field("blacklisterKeyInfo", v)?;
        }
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if let Some(v) = self.fee_info.as_ref() {
            struct_ser.serialize_field("feeInfo", v)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for UnblacklistRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "address",
            "blacklister_key_info",
            "blacklisterKeyInfo",
            "chain",
            "fee_info",
            "feeInfo",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Address,
            BlacklisterKeyInfo,
            Chain,
            FeeInfo,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "address" => Ok(GeneratedField::Address),
                            "blacklisterKeyInfo" | "blacklister_key_info" => Ok(GeneratedField::BlacklisterKeyInfo),
                            "chain" => Ok(GeneratedField::Chain),
                            "feeInfo" | "fee_info" => Ok(GeneratedField::FeeInfo),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = UnblacklistRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.UnblacklistRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<UnblacklistRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut address__ = None;
                let mut blacklister_key_info__ = None;
                let mut chain__ = None;
                let mut fee_info__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Address => {
                            if address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("address"));
                            }
                            address__ = Some(map_.next_value()?);
                        }
                        GeneratedField::BlacklisterKeyInfo => {
                            if blacklister_key_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("blacklisterKeyInfo"));
                            }
                            blacklister_key_info__ = map_.next_value()?;
                        }
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::FeeInfo => {
                            if fee_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("feeInfo"));
                            }
                            fee_info__ = map_.next_value()?;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(UnblacklistRequest {
                    address: address__.unwrap_or_default(),
                    blacklister_key_info: blacklister_key_info__,
                    chain: chain__,
                    fee_info: fee_info__,
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.UnblacklistRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for UnblacklistResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.txhash.is_empty() {
            len += 1;
        }
        if self.tx_status.is_some() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.UnblacklistResponse", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        if let Some(v) = self.tx_status.as_ref() {
            struct_ser.serialize_field("txStatus", v)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for UnblacklistResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "txhash",
            "tx_status",
            "txStatus",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Txhash,
            TxStatus,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "txhash" => Ok(GeneratedField::Txhash),
                            "txStatus" | "tx_status" => Ok(GeneratedField::TxStatus),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = UnblacklistResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.UnblacklistResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<UnblacklistResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut txhash__ = None;
                let mut tx_status__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                        GeneratedField::TxStatus => {
                            if tx_status__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txStatus"));
                            }
                            tx_status__ = map_.next_value()?;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(UnblacklistResponse {
                    chain: chain__,
                    txhash: txhash__.unwrap_or_default(),
                    tx_status: tx_status__,
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.UnblacklistResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for UnpauseRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.pauser_key_info.is_some() {
            len += 1;
        }
        if self.chain.is_some() {
            len += 1;
        }
        if self.fee_info.is_some() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.UnpauseRequest", len)?;
        if let Some(v) = self.pauser_key_info.as_ref() {
            struct_ser.serialize_field("pauserKeyInfo", v)?;
        }
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if let Some(v) = self.fee_info.as_ref() {
            struct_ser.serialize_field("feeInfo", v)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for UnpauseRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "pauser_key_info",
            "pauserKeyInfo",
            "chain",
            "fee_info",
            "feeInfo",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            PauserKeyInfo,
            Chain,
            FeeInfo,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "pauserKeyInfo" | "pauser_key_info" => Ok(GeneratedField::PauserKeyInfo),
                            "chain" => Ok(GeneratedField::Chain),
                            "feeInfo" | "fee_info" => Ok(GeneratedField::FeeInfo),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = UnpauseRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.UnpauseRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<UnpauseRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut pauser_key_info__ = None;
                let mut chain__ = None;
                let mut fee_info__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::PauserKeyInfo => {
                            if pauser_key_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("pauserKeyInfo"));
                            }
                            pauser_key_info__ = map_.next_value()?;
                        }
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::FeeInfo => {
                            if fee_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("feeInfo"));
                            }
                            fee_info__ = map_.next_value()?;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(UnpauseRequest {
                    pauser_key_info: pauser_key_info__,
                    chain: chain__,
                    fee_info: fee_info__,
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.UnpauseRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for UnpauseResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.txhash.is_empty() {
            len += 1;
        }
        if self.tx_status.is_some() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.UnpauseResponse", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        if let Some(v) = self.tx_status.as_ref() {
            struct_ser.serialize_field("txStatus", v)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for UnpauseResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "txhash",
            "tx_status",
            "txStatus",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Txhash,
            TxStatus,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "txhash" => Ok(GeneratedField::Txhash),
                            "txStatus" | "tx_status" => Ok(GeneratedField::TxStatus),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = UnpauseResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.UnpauseResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<UnpauseResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut txhash__ = None;
                let mut tx_status__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                        GeneratedField::TxStatus => {
                            if tx_status__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txStatus"));
                            }
                            tx_status__ = map_.next_value()?;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(UnpauseResponse {
                    chain: chain__,
                    txhash: txhash__.unwrap_or_default(),
                    tx_status: tx_status__,
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.UnpauseResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for UpdateBlacklisterRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.address.is_empty() {
            len += 1;
        }
        if self.owner_key_info.is_some() {
            len += 1;
        }
        if self.chain.is_some() {
            len += 1;
        }
        if self.fee_info.is_some() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.UpdateBlacklisterRequest", len)?;
        if !self.address.is_empty() {
            struct_ser.serialize_field("address", &self.address)?;
        }
        if let Some(v) = self.owner_key_info.as_ref() {
            struct_ser.serialize_field("ownerKeyInfo", v)?;
        }
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if let Some(v) = self.fee_info.as_ref() {
            struct_ser.serialize_field("feeInfo", v)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for UpdateBlacklisterRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "address",
            "owner_key_info",
            "ownerKeyInfo",
            "chain",
            "fee_info",
            "feeInfo",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Address,
            OwnerKeyInfo,
            Chain,
            FeeInfo,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "address" => Ok(GeneratedField::Address),
                            "ownerKeyInfo" | "owner_key_info" => Ok(GeneratedField::OwnerKeyInfo),
                            "chain" => Ok(GeneratedField::Chain),
                            "feeInfo" | "fee_info" => Ok(GeneratedField::FeeInfo),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = UpdateBlacklisterRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.UpdateBlacklisterRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<UpdateBlacklisterRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut address__ = None;
                let mut owner_key_info__ = None;
                let mut chain__ = None;
                let mut fee_info__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Address => {
                            if address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("address"));
                            }
                            address__ = Some(map_.next_value()?);
                        }
                        GeneratedField::OwnerKeyInfo => {
                            if owner_key_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("ownerKeyInfo"));
                            }
                            owner_key_info__ = map_.next_value()?;
                        }
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::FeeInfo => {
                            if fee_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("feeInfo"));
                            }
                            fee_info__ = map_.next_value()?;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(UpdateBlacklisterRequest {
                    address: address__.unwrap_or_default(),
                    owner_key_info: owner_key_info__,
                    chain: chain__,
                    fee_info: fee_info__,
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.UpdateBlacklisterRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for UpdateBlacklisterResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.txhash.is_empty() {
            len += 1;
        }
        if self.tx_status.is_some() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.UpdateBlacklisterResponse", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        if let Some(v) = self.tx_status.as_ref() {
            struct_ser.serialize_field("txStatus", v)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for UpdateBlacklisterResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "txhash",
            "tx_status",
            "txStatus",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Txhash,
            TxStatus,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "txhash" => Ok(GeneratedField::Txhash),
                            "txStatus" | "tx_status" => Ok(GeneratedField::TxStatus),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = UpdateBlacklisterResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.UpdateBlacklisterResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<UpdateBlacklisterResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut txhash__ = None;
                let mut tx_status__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                        GeneratedField::TxStatus => {
                            if tx_status__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txStatus"));
                            }
                            tx_status__ = map_.next_value()?;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(UpdateBlacklisterResponse {
                    chain: chain__,
                    txhash: txhash__.unwrap_or_default(),
                    tx_status: tx_status__,
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.UpdateBlacklisterResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for UpdateMasterMinterRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.address.is_empty() {
            len += 1;
        }
        if self.owner_key_info.is_some() {
            len += 1;
        }
        if self.chain.is_some() {
            len += 1;
        }
        if self.fee_info.is_some() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.UpdateMasterMinterRequest", len)?;
        if !self.address.is_empty() {
            struct_ser.serialize_field("address", &self.address)?;
        }
        if let Some(v) = self.owner_key_info.as_ref() {
            struct_ser.serialize_field("ownerKeyInfo", v)?;
        }
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if let Some(v) = self.fee_info.as_ref() {
            struct_ser.serialize_field("feeInfo", v)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for UpdateMasterMinterRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "address",
            "owner_key_info",
            "ownerKeyInfo",
            "chain",
            "fee_info",
            "feeInfo",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Address,
            OwnerKeyInfo,
            Chain,
            FeeInfo,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "address" => Ok(GeneratedField::Address),
                            "ownerKeyInfo" | "owner_key_info" => Ok(GeneratedField::OwnerKeyInfo),
                            "chain" => Ok(GeneratedField::Chain),
                            "feeInfo" | "fee_info" => Ok(GeneratedField::FeeInfo),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = UpdateMasterMinterRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.UpdateMasterMinterRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<UpdateMasterMinterRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut address__ = None;
                let mut owner_key_info__ = None;
                let mut chain__ = None;
                let mut fee_info__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Address => {
                            if address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("address"));
                            }
                            address__ = Some(map_.next_value()?);
                        }
                        GeneratedField::OwnerKeyInfo => {
                            if owner_key_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("ownerKeyInfo"));
                            }
                            owner_key_info__ = map_.next_value()?;
                        }
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::FeeInfo => {
                            if fee_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("feeInfo"));
                            }
                            fee_info__ = map_.next_value()?;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(UpdateMasterMinterRequest {
                    address: address__.unwrap_or_default(),
                    owner_key_info: owner_key_info__,
                    chain: chain__,
                    fee_info: fee_info__,
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.UpdateMasterMinterRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for UpdateMasterMinterResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.txhash.is_empty() {
            len += 1;
        }
        if self.tx_status.is_some() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.UpdateMasterMinterResponse", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        if let Some(v) = self.tx_status.as_ref() {
            struct_ser.serialize_field("txStatus", v)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for UpdateMasterMinterResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "txhash",
            "tx_status",
            "txStatus",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Txhash,
            TxStatus,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "txhash" => Ok(GeneratedField::Txhash),
                            "txStatus" | "tx_status" => Ok(GeneratedField::TxStatus),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = UpdateMasterMinterResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.UpdateMasterMinterResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<UpdateMasterMinterResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut txhash__ = None;
                let mut tx_status__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                        GeneratedField::TxStatus => {
                            if tx_status__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txStatus"));
                            }
                            tx_status__ = map_.next_value()?;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(UpdateMasterMinterResponse {
                    chain: chain__,
                    txhash: txhash__.unwrap_or_default(),
                    tx_status: tx_status__,
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.UpdateMasterMinterResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for UpdatePauserRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.address.is_empty() {
            len += 1;
        }
        if self.owner_key_info.is_some() {
            len += 1;
        }
        if self.chain.is_some() {
            len += 1;
        }
        if self.fee_info.is_some() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.UpdatePauserRequest", len)?;
        if !self.address.is_empty() {
            struct_ser.serialize_field("address", &self.address)?;
        }
        if let Some(v) = self.owner_key_info.as_ref() {
            struct_ser.serialize_field("ownerKeyInfo", v)?;
        }
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if let Some(v) = self.fee_info.as_ref() {
            struct_ser.serialize_field("feeInfo", v)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for UpdatePauserRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "address",
            "owner_key_info",
            "ownerKeyInfo",
            "chain",
            "fee_info",
            "feeInfo",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Address,
            OwnerKeyInfo,
            Chain,
            FeeInfo,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "address" => Ok(GeneratedField::Address),
                            "ownerKeyInfo" | "owner_key_info" => Ok(GeneratedField::OwnerKeyInfo),
                            "chain" => Ok(GeneratedField::Chain),
                            "feeInfo" | "fee_info" => Ok(GeneratedField::FeeInfo),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = UpdatePauserRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.UpdatePauserRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<UpdatePauserRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut address__ = None;
                let mut owner_key_info__ = None;
                let mut chain__ = None;
                let mut fee_info__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Address => {
                            if address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("address"));
                            }
                            address__ = Some(map_.next_value()?);
                        }
                        GeneratedField::OwnerKeyInfo => {
                            if owner_key_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("ownerKeyInfo"));
                            }
                            owner_key_info__ = map_.next_value()?;
                        }
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::FeeInfo => {
                            if fee_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("feeInfo"));
                            }
                            fee_info__ = map_.next_value()?;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(UpdatePauserRequest {
                    address: address__.unwrap_or_default(),
                    owner_key_info: owner_key_info__,
                    chain: chain__,
                    fee_info: fee_info__,
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.UpdatePauserRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for UpdatePauserResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.chain.is_some() {
            len += 1;
        }
        if !self.txhash.is_empty() {
            len += 1;
        }
        if self.tx_status.is_some() {
            len += 1;
        }
        if self.tracking_info.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("blkchn_svc_v1.UpdatePauserResponse", len)?;
        if let Some(v) = self.chain.as_ref() {
            let v = Chain::try_from(*v)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", *v)))?;
            struct_ser.serialize_field("chain", &v)?;
        }
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        if let Some(v) = self.tx_status.as_ref() {
            struct_ser.serialize_field("txStatus", v)?;
        }
        if let Some(v) = self.tracking_info.as_ref() {
            struct_ser.serialize_field("trackingInfo", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for UpdatePauserResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "chain",
            "txhash",
            "tx_status",
            "txStatus",
            "tracking_info",
            "trackingInfo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Chain,
            Txhash,
            TxStatus,
            TrackingInfo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "chain" => Ok(GeneratedField::Chain),
                            "txhash" => Ok(GeneratedField::Txhash),
                            "txStatus" | "tx_status" => Ok(GeneratedField::TxStatus),
                            "trackingInfo" | "tracking_info" => Ok(GeneratedField::TrackingInfo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = UpdatePauserResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct blkchn_svc_v1.UpdatePauserResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<UpdatePauserResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut chain__ = None;
                let mut txhash__ = None;
                let mut tx_status__ = None;
                let mut tracking_info__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Chain => {
                            if chain__.is_some() {
                                return Err(serde::de::Error::duplicate_field("chain"));
                            }
                            chain__ = map_.next_value::<::std::option::Option<Chain>>()?.map(|x| x as i32);
                        }
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                        GeneratedField::TxStatus => {
                            if tx_status__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txStatus"));
                            }
                            tx_status__ = map_.next_value()?;
                        }
                        GeneratedField::TrackingInfo => {
                            if tracking_info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingInfo"));
                            }
                            tracking_info__ = map_.next_value()?;
                        }
                    }
                }
                Ok(UpdatePauserResponse {
                    chain: chain__,
                    txhash: txhash__.unwrap_or_default(),
                    tx_status: tx_status__,
                    tracking_info: tracking_info__,
                })
            }
        }
        deserializer.deserialize_struct("blkchn_svc_v1.UpdatePauserResponse", FIELDS, GeneratedVisitor)
    }
}
