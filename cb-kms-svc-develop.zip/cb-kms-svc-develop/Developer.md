## run the OIDC provider server to test the JWT middleware
```shell
# see ~/Project/rust/tower-oauth2-resource-server/examples/tonic-example/README.md
## all scripts are there. 
###  specifically, the following start a local instance of Keycloak OIDC provider [Keycloak](https://www.keycloak.org/).
#### it outputs the port it runs on.
RUST_LOG=info RUN_TONIC=false cargo run -p tonic-example

### get a valid JWT from OIDC server (that should satisfy the middleware validation)  
#### JWT accessTokenLifespan is 1000 minutes (60000 seconds), defined in examples-util/realm.json
#### OIDC_PORT is from the above script output, e.g. 55002. each start increments the port by 3.
OIDC_PORT=55002 
JWT=$(curl -X POST localhost:$OIDC_PORT/realms/tors/protocol/openid-connect/token \
    -H "Content-Type: application/x-www-form-urlencoded" \
    -d "grant_type=password&client_id=tors-example&username=user@example.com&password=password&scope=openid&client_secret=SGkkbV1nCLfKfr0Zxyig6isRgT1RdK2q" \
    | jq -r '.access_token')    
echo $JWT  
```

## run blckchn-svc service
```shell
cargo run -- -h
# note: make sure port for authz_server in cb_blkchn_svc.toml is set to the OIDC provider port above, e.g. 55002.
cargo run --release -- -c cb_kms_svc.toml start 
RUST_BACKTRACE=1 cargo run --release -- -c cb_kms_svc.toml start 
RUST_BACKTRACE=full cargo run --release -- -c cb_kms_svc.toml start --release

./target/release/cb_kms_svc -c cb_kms_svc.toml start
```


## apply linting
```shell
# Optimize Imports for the whole workspace: right-click on the workspace root folder in RustRover IDE and select Optimize Imports.
# unfortunately, the above does not remove unused imports.

# check the whole workspace. it will show unused imports, among other things.
# manually remove unused imports.
cargo check --workspace --all-features  
cargo check --all-features  

# Reformat the whole workspace: right-click on the workspace root folder in RustRover IDE and select Reformat Code.
# Or run the following commands.
cargo fmt --all --check # it will display the proposed changes.
cargo fmt --all

# clippy the whole workspace; review recommendations and make appropriate changes.
cargo clippy --workspace --all-features
## pedantic is too strict, but the docs recommendation may be worth it.
cargo clippy --workspace --all-features -- --warn clippy::pedantic

# fix clippy recommendations: may need to export __CARGO_FIX_YOLO=1
cargo fix #--allow-dirty --allow-staged
cargo clippy --fix #--allow-dirty -- -Dwarnings  
```