// @generated
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct Header {
    /// unique identifier of the provider
    ///
    /// // type of provider requested
    /// kms_service_v1.ProviderType provider_type = 1;
    #[prost(string, tag="1")]
    pub uuid: ::prost::alloc::string::String,
    /// original application that made the request
    #[prost(string, tag="2")]
    pub app_name: ::prost::alloc::string::String,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum ProviderType {
    /// ("Core provider")
    Core = 0,
    /// ("Software based Crypto Provider")
    SoftCrypto = 1,
    /// ("Pkcs11 HSM based Crypto Provider")
    P11Hsm = 2,
    /// ("MPC TSS based Crypto Provider")
    MpcTss = 3,
}
impl ProviderType {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            ProviderType::Core => "Core",
            ProviderType::SoftCrypto => "SoftCrypto",
            ProviderType::P11Hsm => "P11Hsm",
            ProviderType::MpcTss => "MpcTss",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "Core" => Some(Self::Core),
            "SoftCrypto" => Some(Self::SoftCrypto),
            "P11Hsm" => Some(Self::P11Hsm),
            "MpcTss" => Some(Self::MpcTss),
            _ => None,
        }
    }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum KeyType {
    /// ("Secp256k1")
    Secp256k1 = 0,
    /// ("Ed25519")
    Ed25519 = 1,
    /// ("Secp256r1")
    Secp256r1 = 2,
    /// ("Rsa2048")
    Rsa2048 = 3,
    /// ("Aes")
    Aes = 4,
}
impl KeyType {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            KeyType::Secp256k1 => "Secp256k1",
            KeyType::Ed25519 => "Ed25519",
            KeyType::Secp256r1 => "Secp256r1",
            KeyType::Rsa2048 => "Rsa2048",
            KeyType::Aes => "Aes",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "Secp256k1" => Some(Self::Secp256k1),
            "Ed25519" => Some(Self::Ed25519),
            "Secp256r1" => Some(Self::Secp256r1),
            "Rsa2048" => Some(Self::Rsa2048),
            "Aes" => Some(Self::Aes),
            _ => None,
        }
    }
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ProviderInfo {
    #[prost(string, tag="1")]
    pub uuid: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub description: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub vendor: ::prost::alloc::string::String,
    #[prost(string, tag="4")]
    pub semver: ::prost::alloc::string::String,
    ///   uint32 version_maj = 4;
    ///   uint32 version_min = 5;
    ///   uint32 version_rev = 6;
    #[prost(enumeration="ProviderType", tag="5")]
    pub provider_type: i32,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ListProvidersRequest {
    #[prost(message, optional, tag="1")]
    pub header: ::core::option::Option<Header>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ListProvidersResponse {
    #[prost(message, optional, tag="1")]
    pub header: ::core::option::Option<Header>,
    #[prost(message, repeated, tag="2")]
    pub providers: ::prost::alloc::vec::Vec<ProviderInfo>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct DescribeRequest {
    #[prost(message, optional, tag="1")]
    pub header: ::core::option::Option<Header>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct DescribeResponse {
    #[prost(message, optional, tag="1")]
    pub header: ::core::option::Option<Header>,
    #[prost(message, optional, tag="2")]
    pub body: ::core::option::Option<describe_response::Body>,
}
/// Nested message and enum types in `DescribeResponse`.
pub mod describe_response {
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
    pub struct Body {
        #[prost(message, optional, tag="1")]
        pub provider: ::core::option::Option<super::ProviderInfo>,
        #[prost(enumeration="super::KeyType", repeated, tag="2")]
        pub key_types: ::prost::alloc::vec::Vec<i32>,
    }
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct KeyAttributes {
    #[prost(enumeration="KeyType", tag="1")]
    pub key_type: i32,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GenKeyRequest {
    #[prost(message, optional, tag="1")]
    pub header: ::core::option::Option<Header>,
    /// for p11, use prefix/keyring/key/version format
    #[prost(string, optional, tag="2")]
    pub key_name: ::core::option::Option<::prost::alloc::string::String>,
    #[prost(message, optional, tag="3")]
    pub attributes: ::core::option::Option<KeyAttributes>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GenKeyResponse {
    #[prost(message, optional, tag="1")]
    pub header: ::core::option::Option<Header>,
    /// p11 format: prefix/keyring/key/version; mpc tss format: key_id
    #[prost(string, tag="2")]
    pub key_name: ::prost::alloc::string::String,
    ///   bytes pub_key = 4;
    #[prost(message, optional, tag="3")]
    pub attributes: ::core::option::Option<KeyAttributes>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetPubKeyRequest {
    #[prost(message, optional, tag="1")]
    pub header: ::core::option::Option<Header>,
    /// for p11, use prefix/keyring/key/version format
    #[prost(string, tag="2")]
    pub key_name: ::prost::alloc::string::String,
    #[prost(message, optional, tag="3")]
    pub attributes: ::core::option::Option<KeyAttributes>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetPubKeyResponse {
    #[prost(message, optional, tag="1")]
    pub header: ::core::option::Option<Header>,
    /// p11 format: prefix/keyring/key/version; mpc tss format: key_id
    #[prost(string, tag="2")]
    pub key_name: ::prost::alloc::string::String,
    #[prost(message, optional, tag="3")]
    pub attributes: ::core::option::Option<KeyAttributes>,
    #[prost(bytes="bytes", tag="4")]
    pub pub_key: ::prost::bytes::Bytes,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ListKeyTypesRequest {
    #[prost(message, optional, tag="1")]
    pub header: ::core::option::Option<Header>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ListKeyTypesResponse {
    #[prost(message, optional, tag="1")]
    pub header: ::core::option::Option<Header>,
    #[prost(message, repeated, tag="2")]
    pub provider_key_types: ::prost::alloc::vec::Vec<list_key_types_response::ProviderKeyType>,
}
/// Nested message and enum types in `ListKeyTypesResponse`.
pub mod list_key_types_response {
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
    pub struct ProviderKeyType {
        #[prost(string, tag="1")]
        pub uuid: ::prost::alloc::string::String,
        #[prost(enumeration="super::KeyType", repeated, tag="2")]
        pub key_types: ::prost::alloc::vec::Vec<i32>,
    }
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct PingRequest {
    #[prost(message, optional, tag="1")]
    pub header: ::core::option::Option<Header>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct PingResponse {
    #[prost(message, optional, tag="1")]
    pub header: ::core::option::Option<Header>,
    #[prost(string, tag="2")]
    pub pong: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SignMsgRequest {
    #[prost(message, optional, tag="1")]
    pub header: ::core::option::Option<Header>,
    #[prost(string, tag="2")]
    pub key_name: ::prost::alloc::string::String,
    #[prost(message, optional, tag="3")]
    pub attributes: ::core::option::Option<KeyAttributes>,
    #[prost(bytes="bytes", tag="4")]
    pub msg: ::prost::bytes::Bytes,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SignMsgResponse {
    #[prost(message, optional, tag="1")]
    pub header: ::core::option::Option<Header>,
    #[prost(string, tag="2")]
    pub key_name: ::prost::alloc::string::String,
    #[prost(message, optional, tag="3")]
    pub attributes: ::core::option::Option<KeyAttributes>,
    #[prost(bytes="bytes", tag="4")]
    pub msg: ::prost::bytes::Bytes,
    #[prost(bytes="bytes", tag="5")]
    pub sig: ::prost::bytes::Bytes,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SignPrehashRequest {
    #[prost(message, optional, tag="1")]
    pub header: ::core::option::Option<Header>,
    #[prost(string, tag="2")]
    pub key_name: ::prost::alloc::string::String,
    #[prost(message, optional, tag="3")]
    pub attributes: ::core::option::Option<KeyAttributes>,
    #[prost(bytes="bytes", tag="4")]
    pub hash: ::prost::bytes::Bytes,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SignPrehashResponse {
    #[prost(message, optional, tag="1")]
    pub header: ::core::option::Option<Header>,
    #[prost(string, tag="2")]
    pub key_name: ::prost::alloc::string::String,
    #[prost(message, optional, tag="3")]
    pub attributes: ::core::option::Option<KeyAttributes>,
    #[prost(bytes="bytes", tag="4")]
    pub hash: ::prost::bytes::Bytes,
    #[prost(bytes="bytes", tag="5")]
    pub sig: ::prost::bytes::Bytes,
}
include!("kms_svc_v1.serde.rs");
include!("kms_svc_v1.tonic.rs");
// @@protoc_insertion_point(module)