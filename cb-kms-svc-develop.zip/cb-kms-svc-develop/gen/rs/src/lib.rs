// pub mod kms_svc_v1; // why is this not working?
pub mod r#kms_svc_v1; // why is r# needed?