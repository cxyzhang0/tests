## install buf
```shell
brew install bufbuild/buf/buf
```

## code generate with buf generate
```shell
# run in top level directory
buf lint
buf format
## generate code from .proto fiels in the directories defined in buf.work.yaml
buf generate --template ./proto/buf.gen.yaml
buf generate --template ./proto/buf.gen.yaml --debug -v 
## generate code from the proto/kms-svc/v1 folder in the absence of buf.work.yaml
##  but if buf.work.yaml is present, the directory must be consistent with the buf.work.yaml
buf generate proto --template ./proto/buf.gen.yaml
buf generate proto --template ./proto/buf.gen.yaml --debug -v

```

## code generate with build.rs
See kms/build.rs for example. It is simple but no serde or openapi.