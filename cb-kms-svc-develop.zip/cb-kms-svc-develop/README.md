# Coreblock KMS Service

gRPC service for key management with both PKCS11 HSM and MPC TSS backends.

## Getting Started

This application is authored using [Abscissa], a Rust application framework.

For more information, see:

[Documentation]

[Abscissa]: https://github.com/iqlusioninc/abscissa
[Documentation]: https://docs.rs/abscissa_core/
