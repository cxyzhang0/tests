use abscissa_core::Application;
use tower_oauth2_resource_server::server::OAuth2ResourceServer;
use tower_oauth2_resource_server::tenant::TenantConfiguration;
use crate::application::APP;
use crate::error::{Error, ErrorKind};

#[derive(Default)]
pub(crate) struct AuthZServer;

impl AuthZServer {
    pub(crate) fn is_authz_server_enabled() -> bool {
        let config = APP.config();
        !config.providers.core.authz_server.is_empty()
    }

    pub(crate) async fn get_authz_server() -> Result<OAuth2ResourceServer, Error> {
        let config = APP.config();

        let oauth2_resource_server = <OAuth2ResourceServer>::builder()
            .add_tenant(
                TenantConfiguration::builder(config.providers.core.authz_server.clone())
                    .audiences(&[&config.providers.core.audience])
                    .jwks_url(config.providers.core.jwks_url.clone())
                    .build()
                    .await
                    .map_err(|e| ErrorKind::AuthZError.context(format!("Failed to build TenantConfiguration: {}", e)))?
            )
            .build()
            .await
            .map_err(|e| ErrorKind::AuthZError.context(format!("Failed to build OAuth2ResourceServer: {}", e)))?;

        Ok(oauth2_resource_server)
    }

}


