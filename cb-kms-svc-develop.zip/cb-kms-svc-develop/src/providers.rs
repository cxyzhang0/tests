/// core provider module
pub mod core;
/// soft crypto provider module 
pub mod softcrypto;
/// pkcs11 hsm provider module
pub mod p11hsm;
/// mpc tss provider module
#[cfg(feature = "mpctss-provider")]
pub mod mpctss;

use crate::config::CbKmsSvcConfig;
use crate::error::ErrorKind;
use crate::prelude::trace;
use crate::proto::{ListKeyTypesRequest, ListKeyTypesResponse, describe_response, DescribeRequest, DescribeResponse, GenKeyRequest, GenKeyResponse, GetPubKeyRequest, GetPubKeyResponse, ListProvidersRequest, ListProvidersResponse, PingRequest, PingResponse, SignMsgRequest, SignMsgResponse, SignPrehashRequest, SignPrehashResponse};
use crate::Result;
use std::fmt;
use tonic::async_trait;

/// The ProviderIdentity struct specifies a unique uuid-name
/// combination to form a unique provider identity.
// Q: what is the use of ProviderIdentity?
// A: one use: persistent layer stores keys by provider identity
#[derive(Debug, Clone, PartialEq, Eq, Hash, Default)]
pub struct ProviderIdentity {
    /// The uuid of the provider
    uuid: String,
    /// The name of the provider set in the config, defaults to a suitable name.
    name: String,
}

impl fmt::Display for ProviderIdentity {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "ProviderIdentity: [uuid=\"{}\", name=\"{}\"]",
            self.uuid, self.name
        )
    }
}

impl ProviderIdentity {
    /// Creates a new instance of ProviderIdentity.
    pub fn new(uuid: String, name: String) -> ProviderIdentity {
        ProviderIdentity { uuid, name }
    }

    /// Get the uuid of the provider
    #[allow(dead_code)]
    pub fn uuid(&self) -> &String {
        &self.uuid
    }

    /// Get the name of the provider
    #[allow(dead_code)]
    pub fn name(&self) -> &String {
        &self.name
    }
}

/// trait all providers must implement including the service core itself
/// it does not have to use the wire protocol, but it does so for convenience
#[async_trait]
pub trait Provide {
    /// ping the core service
    async fn ping(&self, _req: PingRequest) -> Result<PingResponse> {
        trace!("ping ingress");
        Err(ErrorKind::NotSupported.into())
    }

    /// native describe the current provider without following the wire protocol
    fn native_describe(&self, _app_config: &CbKmsSvcConfig) -> Result<describe_response::Body> {
        trace!("describe ingress");
        Err(ErrorKind::NotSupported.into())
    }

    /// describe the current provider
    fn describe(&self, _req: DescribeRequest) -> Result<DescribeResponse> {
        trace!("describe ingress");
        Err(ErrorKind::NotSupported.into())
    }

    /// list all providers by the core service
    fn list_providers(&self, _req: ListProvidersRequest) -> Result<ListProvidersResponse> {
        trace!("list_providers ingress");
        Err(ErrorKind::NotSupported.into())
    }
    
    /// list current or all providers key types
    fn list_provider_key_types(&self, _req: ListKeyTypesRequest) -> Result<ListKeyTypesResponse> {
        trace!("list_provider_key_types ingress");
        Err(ErrorKind::NotSupported.into())
    }
    
    /// generate a new key
    async fn gen_key(&self, _req: GenKeyRequest) -> Result<GenKeyResponse> {
        trace!("gen_key ingress");
        Err(ErrorKind::NotSupported.into())
    }

    /// sign a message
    async fn sign_msg(&self, _req: SignMsgRequest) -> Result<SignMsgResponse> {
        trace!("sign_msg ingress");
        Err(ErrorKind::NotSupported.into())
    }

    /// sign a hash
    async fn sign_prehash(&self, _req: SignPrehashRequest) -> Result<SignPrehashResponse> {
        trace!("sign_msg ingress");
        Err(ErrorKind::NotSupported.into())
    }
    
    /// get public key
    async fn get_pub_key(&self, _req: GetPubKeyRequest) -> Result<GetPubKeyResponse> {
        trace!("get_pub_key ingress");
        Err(ErrorKind::NotSupported.into())
    }
    
}