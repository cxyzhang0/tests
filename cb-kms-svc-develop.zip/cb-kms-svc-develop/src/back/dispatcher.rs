use crate::error::ErrorKind;
use crate::providers::Provide;
use crate::Result;
use derivative::Derivative;
use std::collections::HashMap;
use std::sync::Arc;
use tonic::async_trait;
use uuid::Uuid;
use crate::proto::{ListKeyTypesRequest, ListKeyTypesResponse};

/// dispatcher to the provider
///
/// it finds the provider to handle the request, specifically based on the request header
///
/// it owns all the registered providers
///
/// todo: currently it supports one provider per type. future enhancement may support multiple providers per type distinguished by uuid.
#[derive(Derivative)]
#[derivative(Debug, Default)]
pub struct Dispatcher {
    #[derivative(Debug = "ignore")]
    providers: HashMap<Uuid, Arc<dyn Provide + Send + Sync>>,
}

impl Dispatcher {
    /// get the provider per the request header
    pub fn get_provider(&self, header: &crate::proto::Header) -> Result<Arc<dyn Provide + Send + Sync>> {
        let uuid = Uuid::parse_str(&header.uuid)?;

        Ok(Arc::clone(self.providers.get(&uuid).ok_or_else(|| ErrorKind::ProviderNotRegistered.context("test"))?))
    }
    
}

/// Dispatch implements Provide trait trivially by delegating to the provider
/// it follows the wire protocol
/// it does not have to implement the Provide trait itself, but it does so for convenience,
/// since Provide does not have to follow the wire protocol even though it does currently.
#[async_trait]
impl Provide for Dispatcher {
    async fn ping(&self, req: crate::proto::PingRequest) -> Result<crate::proto::PingResponse> {
        let provider = self.get_provider(req.header.as_ref().unwrap())?;

        provider.ping(req).await
    }

    fn describe(&self, req: crate::proto::DescribeRequest) -> Result<crate::proto::DescribeResponse> {
        let provider = self.get_provider(req.header.as_ref().unwrap())?;

        provider.describe(req)
    }

    fn list_providers(&self, req: crate::proto::ListProvidersRequest) -> Result<crate::proto::ListProvidersResponse> {
        let provider = self.get_provider(req.header.as_ref().unwrap())?;

        provider.list_providers(req)
    }

    fn list_provider_key_types(&self, req: ListKeyTypesRequest) -> Result<ListKeyTypesResponse> {
        let provider = self.get_provider(req.header.as_ref().unwrap())?;

        provider.list_provider_key_types(req)
    }
    
    async fn gen_key(&self, req: crate::proto::GenKeyRequest) -> Result<crate::proto::GenKeyResponse> {
        let provider = self.get_provider(req.header.as_ref().unwrap())?;

        provider.gen_key(req).await
    }

    async fn sign_msg(&self, req: crate::proto::SignMsgRequest) -> Result<crate::proto::SignMsgResponse> {
        let provider = self.get_provider(req.header.as_ref().unwrap())?;

        provider.sign_msg(req).await
    }

    async fn sign_prehash(&self, req: crate::proto::SignPrehashRequest) -> Result<crate::proto::SignPrehashResponse> {
        let provider = self.get_provider(req.header.as_ref().unwrap())?;

        provider.sign_prehash(req).await
    }

    async fn get_pub_key(&self, req: crate::proto::GetPubKeyRequest) -> Result<crate::proto::GetPubKeyResponse> {
        let provider = self.get_provider(req.header.as_ref().unwrap())?;

        provider.get_pub_key(req).await
    }
}

/// dispatcher builder
#[derive(Default)]
pub struct DispatcherBuilder {
    providers: Option<HashMap<Uuid, Arc<dyn Provide + Send + Sync>>>,
}

impl DispatcherBuilder {
    /// create a new dispatcher builder
    pub fn new() -> Self {
        DispatcherBuilder { providers: None }
    }

    /// add a provider to the dispatcher
    pub fn with_provider(
        mut self,
        provider_uuid: Uuid,
        provider: Arc<dyn Provide + Send + Sync>
    ) -> Self {
        let mut providers = self.providers.unwrap_or_default();
        let _ = providers.insert(provider_uuid, provider);
        self.providers = Some(providers);

        self
    }

    /// add multiple providers to the dispatcher in one call
    #[allow(dead_code)]
    pub fn with_providers(
        mut self,
        new_providers: HashMap<Uuid, Arc<dyn Provide + Send + Sync>>
    ) -> Self {
        let mut providers = self.providers.unwrap_or_default();
        providers.extend(new_providers);
        self.providers = Some(providers);

        self
    }

    /// build the builder into a dispatcher
    pub fn build(self) -> Result<Dispatcher> {
        Ok(Dispatcher {
            providers: self.providers.ok_or_else(|| ErrorKind::InvalidData.context("providers is missing"))?,
        })
    }
}