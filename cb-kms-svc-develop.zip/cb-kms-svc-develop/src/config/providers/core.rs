use serde::{Deserialize, Serialize};

/// Core service configuration
#[derive(Clone, Default, Deserialize, Serialize, Debug)]
#[serde(deny_unknown_fields)]
pub struct CoreConfig {
    /// Name of the core service
    pub name: String,
    /// UUID of the core service
    pub uuid: String,
    /// grpc server
    pub grpc: String,
    /// URL for authz server
    pub authz_server: String,
    /// blkchn svc audience in JWT
    pub audience: String,
}