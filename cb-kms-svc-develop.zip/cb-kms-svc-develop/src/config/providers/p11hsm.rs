use serde::{Deserialize, Serialize};

/// P11 HSM provider config
#[derive(Clone, Deserialize, Serialize, Debug)]
#[serde(deny_unknown_fields)]
pub struct P11hsmConfig {
    /// name may be used to describe the vendor, e.g. futurex-1, softhsm-1, etc
    /// note: even for the same vendor, there could be multiple such config 
    /// - e.g., one for each different version of the driver
    pub name: String,

    /// provider version
    pub semver: String,

    /// evn var name for pkcs11 library file path
    /// so that the module file path can be retrieved from env var
    /// e.g., for FX, it is "FXPKCS11_MODULE"
    pub env_module: Option<String>,

    /// pkcs11 library binary file path
    pub module: Option<String>,

    /// pkcs11 config env var name
    /// e.g., for FX, it is "FXPKCS11_CFG"
    pub env_cfg: String,

    /// pkcs11 config file path
    pub cfg: String,

    /// list of hsms with the same driver
    /// e.g., one for each token slot. FX config can have up to 5 token slots
    /// each such logical slot can be a partition, or a different HSM
    #[serde(default)]
    pub hsms: Vec<HsmConfig>,    
}

/// hsms
#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct HsmConfig {
    /// uuid: system-wide unique within the whole kms service
    pub uuid: String,
    
    /// pkcs11 token label to identify the slot
    /// e.g., "Slot Token 0"
    pub token_label: String,

    /// pkcs11 user pin
    pub user_pin: String,
    
    /// whether to use it
    pub enabled: bool,

}