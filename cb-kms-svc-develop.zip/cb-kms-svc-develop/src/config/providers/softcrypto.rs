use serde::{Deserialize, Serialize};

/// Sofware based provider configuration
#[derive(Clone, Default, Deserialize, Serialize, Debug)]
#[serde(deny_unknown_fields)]
pub struct SoftcryptoConfig {
    /// Provider name
    pub name: String,
    /// Provider UUID
    pub uuid: String,
    /// whether the provider is enabled
    pub enabled: bool,
}