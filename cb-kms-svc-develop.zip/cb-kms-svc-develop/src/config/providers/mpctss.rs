use serde::{Deserialize, Serialize};

/// MPC TSS provider config
#[derive(Clone, Deserialize, Serialize, Debug)]
#[serde(deny_unknown_fields)]
pub struct MpctssConfig {
    /// name
    pub name: String,

    /// semver
    pub semver: String,

    /// uuid: unique within the whole kms service
    pub uuid: String,

    /// path to local share storage
    pub share: String,

    // /// algorithm
    // pub algorithm: String,

    /// path to user secret key (ed25519)
    pub user_sk: String,

    /// hex encoded server public key
    pub server_vk: String,

    /// server url
    pub server: String,

    /// finish server url
    pub finish_server: String,

    // /// chain path
    //pub chain_path: String,

    /// dkg endpoint
    pub keygen_endpoint: String,
    /// eddsa dkg endpoint
    pub eddsa_keygen_endpoint: String,

    /// keyshare refresh endpoint
    pub refresh_endpoint: String,
    /// eddsa keyshare refresh endpoint
    pub eddsa_refresh_endpoint: String,

    /// keyshare recovery endpoint
    pub recovery_endpoint: String,
    /// eddsa keyshare recovery endpoint
    pub eddsa_recovery_endpoint: String,

    /// dsg endpoint
    pub sign_endpoint: String,
    /// eddsa dsg endpoint
    pub eddsa_sign_endpoint: String,

    /// presign endpoint
    pub presign_endpoint: String,
    /// eddsa presign endpoint
    pub eddsa_presign_endpoint: String,

    /// finish endpoint
    pub finish_endpoint: String,
    /// eddsa finish endpoint
    pub eddsa_finish_endpoint: String,

    /// whether to use it
    pub enabled: bool,

}
