/// pkcs11 hsm provider config
pub mod p11hsm;
/// mpc tss provider config
pub mod mpctss;
/// core provider config
pub mod core;
/// soft crypto provider config
pub mod softcrypto;

use serde::{Deserialize, Serialize};
use crate::config::providers::core::CoreConfig;
use crate::config::providers::mpctss::MpctssConfig;
use crate::config::providers::p11hsm::P11hsmConfig;
use crate::config::providers::softcrypto::SoftcryptoConfig;

/// 
#[derive(Clone, Default, Deserialize, Serialize, Debug)]
#[serde(deny_unknown_fields)]
pub struct ProvidersConfig {
    /// Core service configuration
    #[serde(default)]
    pub core: CoreConfig,

    /// Software based provider configuration
    #[serde(default)]
    pub softcrypto: SoftcryptoConfig,
    
    /// list of P11 HSM provider configs
    // #[cfg(feature = "p11hsm")]
    #[serde(default)]
    pub p11hsm: Vec<P11hsmConfig>,

    /// list of MPC TSS provider configs
    #[cfg(feature = "mpctss-provider")]
    #[serde(default)]
    pub mpctss: Vec<MpctssConfig>,
}