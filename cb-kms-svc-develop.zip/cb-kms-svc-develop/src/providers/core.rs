use crate::application::APP;
use crate::proto::{list_key_types_response, ListKeyTypesRequest, ListKeyTypesResponse, describe_response, DescribeRequest, DescribeResponse, KeyType, ListProvidersRequest, ListProvidersResponse, PingRequest, PingResponse, ProviderInfo, ProviderType};
use crate::providers::{Provide, ProviderIdentity};
use abscissa_core::Application;
use std::collections::{HashMap, HashSet};
use tonic::async_trait;
use uuid::Uuid;
use crate::config::CbKmsSvcConfig;

const SUPPORTED_KEY_TYPES: [KeyType; 0] = [];

/// Core provider
#[derive(Debug, Default, Clone)]
pub struct Provider {
    provider_identity: ProviderIdentity,
    providers_info: Vec<ProviderInfo>,
    providers_key_types: HashMap<Uuid, HashSet<KeyType>>,
}

impl Provider {
    /// Create my provider info
    pub fn create_my_provider_info(app_config: &CbKmsSvcConfig) -> ProviderInfo {
        let config = &app_config.providers.core;

        ProviderInfo {
            uuid: config.uuid.clone(),
            description: "kms core".to_string(),
            vendor: config.name.clone(),
            semver: env!("CARGO_PKG_VERSION").to_string(),
            provider_type: ProviderType::Core.into(),
        }
    }
}
#[async_trait]
impl Provide for Provider {
    async fn ping(&self, req: PingRequest) -> crate::Result<PingResponse> {
        Ok(PingResponse {
            header: req.header,
            pong: self.provider_identity.to_string(),
        })
    }

    fn native_describe(&self, app_config: &CbKmsSvcConfig) -> crate::Result<describe_response::Body> {

        // Ok(describe_response::Body {
        //     provider: Some(Self::create_my_provider_info()),
        //     key_types: SUPPORTED_KEY_TYPES.map(|i| i.into()).to_vec(),
        // })

        let config = &app_config.providers.core;

        Ok(describe_response::Body {
            provider: Some(ProviderInfo {
                uuid: config.uuid.clone(),
                description: self.provider_identity.to_string(),
                vendor: config.name.clone(),
                semver: env!("CARGO_PKG_VERSION").to_string(),
                provider_type: ProviderType::SoftCrypto.into(),
            }),
            key_types: SUPPORTED_KEY_TYPES.map(|i| i.into()).to_vec(),
        })
    }
    
    fn describe(&self, req: DescribeRequest) -> crate::Result<DescribeResponse> {
        let app_config = &APP.config();
        
        Ok(DescribeResponse {
            header: req.header,
            body: Some(self.native_describe(&app_config)?),
        })
    }
    
    fn list_providers(&self, req: ListProvidersRequest) -> crate::Result<ListProvidersResponse> {
        
        Ok(ListProvidersResponse {
            header: req.header,
            providers: self.providers_info.clone(),
        })
    }

    fn list_provider_key_types(&self, req: ListKeyTypesRequest) -> crate::Result<ListKeyTypesResponse> {
        let mut v = Vec::<list_key_types_response::ProviderKeyType>::new();
        for (provider_uuid, key_types) in &self.providers_key_types {
            let provider_key_types = list_key_types_response::ProviderKeyType {
                uuid: provider_uuid.to_string(),
                key_types: key_types.iter().map(|i| i.clone().into()).collect(),
            };
            v.push(provider_key_types);
        }

        Ok(ListKeyTypesResponse {
            header: req.header,
            provider_key_types: v,
        })
    }
}

/// Builder for core provider
#[derive(Debug)]
pub struct ProviderBuilder {
    provider_identity: ProviderIdentity,
    providers_info: Vec<ProviderInfo>,
    providers_key_types: HashMap<Uuid, HashSet<KeyType>>,
}

impl ProviderBuilder {
    /// Create a new empty core ProviderBuilder
    pub fn new(app_config: &CbKmsSvcConfig) -> Self {
        let config = &app_config.providers.core;

        let provider_identity = ProviderIdentity::new(config.uuid.clone(), config.name.clone());

        ProviderBuilder {
            provider_identity,
            providers_info: Vec::new(),
            providers_key_types: HashMap::new(),
        }
    }

    /// Add a provider info to the builder
    pub fn with_provider_info(mut self, provider_info: ProviderInfo) -> Self {
        self.providers_info.push(provider_info);
        self
    }

    /// Add a provider key types to the builder
    pub fn with_provider_key_types(mut self, provider_uuid: Uuid, key_types: HashSet<KeyType>) -> Self {
        self.providers_key_types.insert(provider_uuid, key_types);
        self
    }

    /// Build into a core Provider
    // this build for core will be called last after all other providers are built
    pub fn build(self, app_config: &CbKmsSvcConfig) -> crate::Result<Provider> {
        let config = &app_config.providers.core;
        
        let mut providers_info = self.providers_info;
        providers_info.push(Provider::create_my_provider_info(&app_config));
        
        let mut providers_key_types = self.providers_key_types;
        providers_key_types.insert(config.uuid.clone().parse()?, SUPPORTED_KEY_TYPES.iter().cloned().collect());
        
        Ok(Provider {
            provider_identity: self.provider_identity,
            providers_info,
            providers_key_types,
        })
    }
}