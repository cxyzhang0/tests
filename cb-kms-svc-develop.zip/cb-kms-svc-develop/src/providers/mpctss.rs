use crate::application::APP;
use crate::config::providers::mpctss::MpctssConfig;
use crate::config::CbKmsSvcConfig;
use crate::error::ErrorKind;
use crate::prelude::trace;
use crate::proto::{list_key_types_response, describe_response, DescribeRequest, DescribeResponse, GenKeyRequest, GenKeyResponse, GetPubKeyRequest, GetPubKeyResponse, KeyAttributes, KeyType, ListKeyTypesRequest, ListKeyTypesResponse, PingRequest, PingResponse, SignMsgRequest, SignMsgResponse, SignPrehashRequest, SignPrehashResponse};
use crate::providers::{Provide, ProviderIdentity};
use crate::Result;
use abscissa_core::Application;
use derivative::Derivative;
use mpctss::sdk::TrioSDK;
use mpctss::traits::MpcTssSDK;
use prost::bytes::Bytes;
use tonic::async_trait;
use uuid::Uuid;

const SUPPORTED_KEY_TYPES: [KeyType; 2] = [
    KeyType::Secp256k1,
    KeyType::Ed25519,
];

/// mpctss provider
#[derive(Derivative)]
#[derivative(Debug)]
pub struct Provider {
    uuid: Uuid,
    provider_identity: ProviderIdentity,
    // sdk: TrioSDK, // cannot have sdk here because it is mutable
}

impl Provider {
    /// Creates a new instance of Provider.
    fn new(uuid: Uuid, provider_identity: ProviderIdentity) -> Provider {
        Provider {
            uuid,
            provider_identity,
            // sdk,
        }
    }

    // get mpctss config for a given uuid
    // note: need to pass in CbKmsServiceConfig because it is also used in Application.after_config
    // where APP.config() is not available.
    fn get_mpctss_config(uuid: Uuid, app_config: &CbKmsSvcConfig) -> Result<MpctssConfig> {
        if let Some(c) = app_config.providers.mpctss.iter().find(|c| c.uuid == uuid.to_string()) {
            return Ok(c.clone());
        }

        Err(ErrorKind::Config.context(format!("mpctss config is not found for {uuid}.")).into())
    }

    fn load_sdk_without_share(&self, key_attrs: &KeyAttributes) -> Result<TrioSDK> {
        let mpctss_config = Self::get_mpctss_config(self.uuid, &APP.config())?;

        let sdk = TrioSDK::default()
            .add_user_sk_from_file(mpctss_config.user_sk.parse().map_err(|e| ErrorKind::InvalidData.context(format!("{e}")))?)
            .add_server_vk(mpctss_config.server_vk.as_str())
            .add_server_url(mpctss_config.server.parse().map_err(|e| ErrorKind::InvalidData.context(format!("{e}")))?)
            .add_finish_server_url(mpctss_config.finish_server.parse().map_err(|e| ErrorKind::InvalidData.context(format!("{e}")))?)
            .add_chain_path("m");

        // algo
        // KeyType to CryptographAlgorithm conversion is straightforward because they have the same variants
        let key_type = KeyType::try_from(key_attrs.key_type)?;

        let sdk = match key_type {
            KeyType::Secp256k1 => {
                sdk
                    .add_algorithm(KeyType::Secp256k1.as_str_name())
                    .add_keygen_endpoint(mpctss_config.keygen_endpoint.as_str())
                    .add_refresh_endpoint(mpctss_config.refresh_endpoint.as_str())
                    .add_recovery_endpoint(mpctss_config.recovery_endpoint.as_str())
                    .add_sign_endpoint(mpctss_config.sign_endpoint.as_str())
                    .add_presign_endpoint(mpctss_config.presign_endpoint.as_str())
                    .add_finish_endpoint(mpctss_config.finish_endpoint.as_str())
            },
            KeyType::Ed25519 => {
                sdk
                    .add_algorithm(KeyType::Ed25519.as_str_name())
                    .add_keygen_endpoint(mpctss_config.eddsa_keygen_endpoint.as_str())
                    .add_refresh_endpoint(mpctss_config.eddsa_refresh_endpoint.as_str())
                    .add_recovery_endpoint(mpctss_config.eddsa_recovery_endpoint.as_str())
                    .add_sign_endpoint(mpctss_config.eddsa_sign_endpoint.as_str())
                    .add_presign_endpoint(mpctss_config.eddsa_presign_endpoint.as_str())
                    .add_finish_endpoint(mpctss_config.eddsa_finish_endpoint.as_str())
            },
            _ => return Err(ErrorKind::InvalidData.context(format!("unsupported key type {}", key_type.as_str_name())).into()),
        };

        Ok(sdk)
    }

    fn load_sdk(&self, key_name: &String, key_attrs: &KeyAttributes) -> Result<TrioSDK> {
        let mpctss_config = Self::get_mpctss_config(self.uuid, &APP.config())?;

        // share storage
        let url = url::Url::parse(&mpctss_config.share).map_err(|e| ErrorKind::Config.context(e.to_string()))?;

        match url.scheme() {
            "file" => {
                // let key_name = req.key_name.as_ref().ok_or_else(|| ErrorKind::InvalidData.context("key name is required"))?;
                let share_file = format!("{}{}/{}.share", url.authority(), url.path(), key_name);
                let sdk = self.load_sdk_without_share(key_attrs)?
                    .add_share_from_file(Some(share_file.into()));  // todo: this line may panic.
                Ok(sdk)
            },
            _ => Err(ErrorKind::Config.context(format!("unsupported storage type {}", url.scheme())).into()),
        }
    }

    fn save_keyshare(&self, sdk: &TrioSDK) -> Result<usize> {
        let mpctss_config = Self::get_mpctss_config(self.uuid, &APP.config())?;

        // share storage
        let url = url::Url::parse(&mpctss_config.share).map_err(|e| ErrorKind::Config.context(e.to_string()))?;

        match url.scheme() {
            "file" => {
                let ks = sdk.share.as_ref().ok_or_else(|| ErrorKind::InvalidData.context("share is empty"))?;
                let key_name = hex::encode(ks.key_id);
                let share_file = format!("{}{}/{}.share", url.authority(), url.path(), key_name);
                let size = mpctss::utils::save_keyshare(share_file.into(), ks)?;
                Ok(size)
            },
            _ => Err(ErrorKind::Config.context(format!("unsupported storage type {}", url.scheme())).into()),
        }
    }
}

#[async_trait]
impl Provide for Provider {
    async fn ping(&self, req: PingRequest) -> Result<PingResponse> {
        Ok(PingResponse {
            header: req.header,
            pong: self.provider_identity.to_string(),
        })
    }

    fn native_describe(&self, app_config: &CbKmsSvcConfig) -> Result<describe_response::Body> {
        let mpctss_config = Self::get_mpctss_config(self.uuid, app_config)?;
        Ok(describe_response::Body {
            provider: Some(crate::proto::ProviderInfo {
                uuid: self.uuid.to_string(),
                description: self.provider_identity.to_string(),
                vendor: mpctss_config.name,
                semver: mpctss_config.semver,
                provider_type: crate::proto::ProviderType::MpcTss.into(),
            }),
            key_types: SUPPORTED_KEY_TYPES.map(|i| i.into()).to_vec(),
        })
    }

    fn describe(&self, req: DescribeRequest) -> Result<DescribeResponse> {

        Ok(DescribeResponse {
            header: req.header,
            body: Some(self.native_describe(&APP.config())?),
        })
    }

    fn list_provider_key_types(&self, req: ListKeyTypesRequest) -> Result<ListKeyTypesResponse> {
        
        Ok(ListKeyTypesResponse {
            header: req.header,
            provider_key_types: vec![list_key_types_response::ProviderKeyType {
                uuid: "".to_string(),
                key_types: SUPPORTED_KEY_TYPES.map(|i| i.into()).to_vec(),
            }],
        })
    }
    
    async fn gen_key(&self, req: GenKeyRequest) -> Result<GenKeyResponse> {
        trace!("gen_key ingress");

        let mut sdk = self.load_sdk_without_share(req.attributes.as_ref().ok_or_else(|| ErrorKind::InvalidData.context("attributes are required"))?)?;

        sdk.keygen().await?;

        // save keyshare
        self.save_keyshare(&sdk)?;

        let ks = sdk.share.ok_or_else(|| ErrorKind::InvalidData.context("share is empty"))?;

        Ok(GenKeyResponse {
            header: req.header,
            key_name: hex::encode(&ks.key_id),
            attributes: req.attributes,
        })
    }

    // sdk.do_sign will hash the message before signing
    async fn sign_msg(&self, req: SignMsgRequest) -> Result<SignMsgResponse> {
        trace!("sign_msg ingress");

        let sdk = self.load_sdk(&req.key_name, req.attributes.as_ref().ok_or_else(|| ErrorKind::InvalidData.context("attributes are required"))?)?;

        let sig = sdk.do_sign(&req.msg).await?;

        Ok(SignMsgResponse {
            header: req.header,
            key_name: req.key_name.to_string(),
            attributes: req.attributes,
            msg: req.msg,
            sig: Bytes::from(sig.0.to_vec()),
        })
    }

    async fn sign_prehash(&self, req: SignPrehashRequest) -> Result<SignPrehashResponse> {
        trace!("sign_prehash ingress");

        let sdk = self.load_sdk(&req.key_name, req.attributes.as_ref().ok_or_else(|| ErrorKind::InvalidData.context("attributes are required"))?)?;

        let hash = <[u8; 32]>::try_from(req.hash.as_ref())?;
        
        let sig = sdk.do_sign_prehash(hash).await?;

        Ok(SignPrehashResponse {
            header: req.header,
            key_name: req.key_name.to_string(),
            attributes: req.attributes,
            hash: req.hash,
            sig: Bytes::from(sig.0.to_vec()),
        })
    }

    async fn get_pub_key(&self, req: GetPubKeyRequest) -> Result<GetPubKeyResponse> {
        trace!("get_pub_key ingress");

        let sdk = self.load_sdk(&req.key_name, req.attributes.as_ref().ok_or_else(|| ErrorKind::InvalidData.context("attributes are required"))?)?;

        Ok(GetPubKeyResponse {
            header: req.header,
            key_name: req.key_name.to_string(),
            attributes: req.attributes,
            pub_key: Bytes::from(sdk.public_key().to_bytes()),
        })
    }
}


#[derive(Debug, Default)]
pub struct ProviderBuilder {
    uuid: Option<Uuid>,
    provider_identity: Option<ProviderIdentity>,
}

impl ProviderBuilder {

    pub fn with_uuid(mut self, uuid: Uuid) -> ProviderBuilder {
        self.uuid = Some(uuid);
        self
    }

    pub fn with_provider_identity(mut self, provider_identity: ProviderIdentity) -> ProviderBuilder {
        self.provider_identity = Some(provider_identity);
        self
    }

    pub fn build(self) -> Result<Provider> {
        let uuid = self.uuid.ok_or_else(|| ErrorKind::Config.context("uuid is not set"))?;
        let provider_identity = self.provider_identity.ok_or_else(|| ErrorKind::Config.context("provider_identity is not set"))?;

        Ok(Provider::new(
            uuid,
            provider_identity
        ))
    }
}
