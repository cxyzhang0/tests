use crate::application::APP;
use crate::config::providers::p11hsm::{HsmConfig, P11hsmConfig};
use crate::config::CbKmsSvcConfig;
use crate::error::ErrorKind;
use crate::prelude::{trace};
use crate::proto::{list_key_types_response, ListKeyTypesRequest, ListKeyTypesResponse, GenKeyRequest, GenKeyResponse, GetPubKeyRequest, GetPubKeyResponse, KeyType, SignMsgRequest, SignMsgResponse, SignPrehashRequest, SignPrehashResponse};
use crate::providers::{Provide, ProviderIdentity};
use crate::Result;
use abscissa_core::secret::ExposeSecret;
use abscissa_core::{Application, SecretString};
use derivative::Derivative;
use kms_commom::types::CryptographAlgorithm;
use pkcs11::{KeyLabel, SDKContext, SDK};
use prost::bytes::Bytes;
use tonic::async_trait;
use uuid::Uuid;
use zeroize::Zeroizing;

const SUPPORTED_KEY_TYPES: [KeyType; 5] = [
    KeyType::Secp256k1,
    KeyType::Ed25519,
    KeyType::Secp256r1,
    KeyType::Rsa2048,
    KeyType::Aes,
];

/// p11hsm provider
#[derive(Derivative)]
#[derivative(Debug)]
pub struct Provider {
    uuid: Uuid,
    provider_identity: ProviderIdentity,
    // we include both context and an optionally fully logged-in sdk
    // for different use cases:
    // with context only, every time we need to login - slower but more resident
    // with logged-in sdk, faster but what happens if the hsm goes down and back.
    sdk_ctx: SDKContext,
    sdk: Option<SDK>,
    user_pin: SecretString,
}

impl Provider {
    
    // get or create sdk
    // it sets self.sdk which means subsequent calls will use the same sdk
    // it uses a mut self which means the caller holds a mut self.
    // todo: we may have a use case where every time we login
    fn _get_or_create_sdk(&mut self, _hsm_config: &HsmConfig) -> Result<&SDK> {
        if self.sdk.is_none() {
            let pin = Zeroizing::new(self.user_pin.expose_secret().to_string());
            let sdk = SDK::from_context_with_login(&self.sdk_ctx, pin.as_str())?;
            self.sdk = Some(sdk);
        }
        Ok(self.sdk.as_ref().unwrap())
    }
    
    fn new(
        uuid: Uuid, 
        provider_identity: ProviderIdentity,
        sdk_ctx: SDKContext,
        sdk: Option<SDK>,
        user_pin: SecretString,) -> Self {
        Self {
            uuid,
            provider_identity,
            sdk_ctx,
            sdk,
            user_pin,
        }
    }

    // return (P11hsmConfig.name, HsmConfig) for a given provider uuid
    // note: need to pass in CbKmsServiceConfig because it is also used in Application.after_config
    // where APP.config() is not available.
    fn get_hsm_config(uuid: Uuid, app_config: &CbKmsSvcConfig) -> Result<(P11hsmConfig, HsmConfig)> {
        let p11hsm_config = &app_config.providers.p11hsm;

        for c in p11hsm_config.iter() {
            if let Some(conf) = c.hsms.iter().find(|h| h.uuid == uuid.to_string()) {
                return Ok((c.clone(), conf.clone()));
            }
        }

        Err(ErrorKind::Config.context(format!("hsm config is not found for {uuid}.")).into())
    }
}

#[async_trait]
impl Provide for Provider {
    async fn ping(&self, req: crate::proto::PingRequest) -> Result<crate::proto::PingResponse> {
        Ok(crate::proto::PingResponse {
            header: req.header,
            pong: self.provider_identity.to_string(),
        })
    }
    
    fn native_describe(&self, app_config: &CbKmsSvcConfig) -> Result<crate::proto::describe_response::Body> {
        let (p11hsm_config, _hsm_config) = Self::get_hsm_config(self.uuid, &app_config)?;
        
        Ok(crate::proto::describe_response::Body {
            provider: Some(crate::proto::ProviderInfo {
                uuid: self.uuid.to_string(),
                description: self.provider_identity.to_string(),
                vendor: p11hsm_config.name.clone(),
                semver: p11hsm_config.semver,
                provider_type: crate::proto::ProviderType::P11Hsm.into(),
            }),
            key_types: SUPPORTED_KEY_TYPES.map(|i| i.into()).to_vec(),
        })
    }
    
    fn describe(&self, req: crate::proto::DescribeRequest) -> Result<crate::proto::DescribeResponse> {
        let app_config = APP.config();
        Ok(crate::proto::DescribeResponse {
            header: req.header,
            body: Some(self.native_describe(&app_config)?),
        })
    }

    fn list_provider_key_types(&self, req: ListKeyTypesRequest) -> Result<ListKeyTypesResponse> {

        Ok(ListKeyTypesResponse {
            header: req.header,
            provider_key_types: vec![list_key_types_response::ProviderKeyType {
                uuid: "".to_string(),
                key_types: SUPPORTED_KEY_TYPES.map(|i| i.into()).to_vec(),
            }],
        })
    }
    
    async fn gen_key(&self, req: GenKeyRequest) -> Result<GenKeyResponse> {
        trace!("gen_key ingress");
        
        let key_attrs = req.attributes.clone().ok_or_else(|| ErrorKind::Config.context("attributes is not set"))?;
        
        let key_type = KeyType::try_from(key_attrs.key_type)?;
        
        // KeyType to CryptographAlgorithm conversion is straightforward because they have the same variants
        let algo = CryptographAlgorithm::from(key_type.as_str_name().to_string());
        
        // if req includes key_name, use it as a short key label, otherwise generate a random key label
        let kl = if let Some(kl) = req.key_name {
            kl
        } else {
            let header = req.header.as_ref().ok_or_else(|| ErrorKind::Config.context("header is not set"))?;
            // generate a random key label: application name/keytype/uuid/1
            format!("{}/{}/{}/1", header.app_name, key_type.as_str_name(), Uuid::new_v4())
        };

        let mut key_label = KeyLabel::from_short(kl.as_str(), algo)?;

        // if sdk is not set, create a new sdk but not set self.sdk
        // todo: this code repeats in all hsm calls. we may want to refactor it.
        let sdk = if let Some(sdk) = self.sdk.as_ref() {
            sdk
        } else {
            let pin = Zeroizing::new(self.user_pin.expose_secret().to_string());
            &SDK::from_context_with_login(&self.sdk_ctx, pin.as_str())?
        };

        // returned key_label may be different from the input key_label 
        // because the sdk detects the key label collision and generates a new key label
        // by incrementing the version number.
        let key_label = match algo {
            CryptographAlgorithm::AES => {
                let (_, new_key_label) = sdk.aes_keygen(&mut key_label, true)?;
                new_key_label
            }
            _ => {
                let (_, _, new_key_label) = sdk.keygen(&mut key_label, true)?;
                new_key_label
            }
        };
        
        Ok(GenKeyResponse {
            header: req.header,
            key_name: key_label.short_label(),
            attributes: req.attributes,
        })
    }

    /// sign a raw message
    // the signature is on the hash of the raw message.
    async fn sign_msg(&self, req: SignMsgRequest) -> Result<SignMsgResponse> {
        trace!("sign_msg ingress");
        
        let key_attrs = req.attributes.clone().ok_or_else(|| ErrorKind::Config.context("attributes is not set"))?;

        let key_type = KeyType::try_from(key_attrs.key_type)?;

        // KeyType to CryptographAlgorithm conversion is straightforward because they have the same variants
        let algo = CryptographAlgorithm::from(key_type.as_str_name().to_string());

        let key_label = KeyLabel::from_short(req.key_name.as_str(), algo)?;

        // if sdk is not set, create a new sdk 
        let sdk = if let Some(sdk) = self.sdk.as_ref() {
            sdk
        } else {
            let pin = Zeroizing::new(self.user_pin.expose_secret().to_string());
            &SDK::from_context_with_login(&self.sdk_ctx, pin.as_str())?
        };

        let bytes = match algo {
            CryptographAlgorithm::AES => {
                return Err(ErrorKind::NotSupported.into())
            }
            CryptographAlgorithm::RSA2048 | CryptographAlgorithm::Ed25519 => {
                sdk.sign(&key_label, req.msg.as_ref())?
            }
            CryptographAlgorithm::Secp256k1 => {
                sdk.sign_ecdsa::<k256::Secp256k1>(&key_label, req.msg.as_ref())?.to_vec()
            }
            CryptographAlgorithm::Secp256r1 => {
                sdk.sign_ecdsa::<p256::NistP256>(&key_label, req.msg.as_ref())?.to_vec()
            }
        };
/*        
        match algo {
            CryptographAlgorithm::AES => {
                Err(ErrorKind::NotSupported.into())
            }
            _ => {
                let bytes = sdk.sign(&key_label, req.msg.as_ref())?;
                Ok(SignMsgResponse {
                    header: req.header,
                    key_name: req.key_name,
                    attributes: req.attributes,
                    msg: req.msg,
                    sig: Bytes::from(bytes),
                })
            }
        }
*/
        Ok(SignMsgResponse {
            header: req.header,
            key_name: req.key_name,
            attributes: req.attributes,
            msg: req.msg,
            sig: Bytes::from(bytes),
        })

    }

    /// sign a hash
    async fn sign_prehash(&self, req: SignPrehashRequest) -> Result<SignPrehashResponse> {
        trace!("sign_prehash ingress");
        
        let key_attrs = req.attributes.clone().ok_or_else(|| ErrorKind::Config.context("attributes is not set"))?;

        let key_type = KeyType::try_from(key_attrs.key_type)?;

        // KeyType to CryptographAlgorithm conversion is straightforward because they have the same variants
        let algo = CryptographAlgorithm::from(key_type.as_str_name().to_string());

        let key_label = KeyLabel::from_short(req.key_name.as_str(), algo)?;

        // if sdk is not set, create a new sdk 
        let sdk = if let Some(sdk) = self.sdk.as_ref() {
            sdk
        } else {
            let pin = Zeroizing::new(self.user_pin.expose_secret().to_string());
            &SDK::from_context_with_login(&self.sdk_ctx, pin.as_str())?
        };

        let bytes = match algo {
            CryptographAlgorithm::AES => {
                return Err(ErrorKind::NotSupported.into())
            }
            CryptographAlgorithm::RSA2048 | CryptographAlgorithm::Ed25519 => {
                sdk.sign(&key_label, req.hash.as_ref())?
            }
            CryptographAlgorithm::Secp256k1 => {
                sdk.sign_ecdsa_prehash::<k256::Secp256k1>(&key_label, <[u8; 32]>::try_from(req.hash.as_ref())?)?.to_vec()
            }
            CryptographAlgorithm::Secp256r1 => {
                sdk.sign_ecdsa_prehash::<p256::NistP256>(&key_label, <[u8; 32]>::try_from(req.hash.as_ref())?)?.to_vec()
            }
        };
        
        Ok(SignPrehashResponse {
            header: req.header,
            key_name: req.key_name,
            attributes: req.attributes,
            hash: req.hash,
            sig: Bytes::from(bytes),
        })
    }

    /// get public key for ec and ed.
    /// return decoded public key bytes
    async fn get_pub_key(&self, req: GetPubKeyRequest) -> Result<GetPubKeyResponse> {
        trace!("get_pub_key ingress");
        
        let key_attrs = req.attributes.clone().ok_or_else(|| ErrorKind::Config.context("attributes is not set"))?;

        let key_type = KeyType::try_from(key_attrs.key_type)?;

        // KeyType to CryptographAlgorithm conversion is straightforward because they have the same variants
        let algo = CryptographAlgorithm::from(key_type.as_str_name().to_string());

        let key_label = KeyLabel::from_short(req.key_name.as_str(), algo)?;

        // if sdk is not set, create a new sdk 
        let sdk = if let Some(sdk) = self.sdk.as_ref() {
            sdk
        } else {
            let pin = Zeroizing::new(self.user_pin.expose_secret().to_string());
            &SDK::from_context_with_login(&self.sdk_ctx, pin.as_str())?
        };

        match algo {
            CryptographAlgorithm::AES | CryptographAlgorithm::RSA2048 => {
                Err(ErrorKind::NotSupported.into())
            }
            _ => {
                let bytes = sdk.get_decoded_public_key_bytes(&key_label)?;
                Ok(GetPubKeyResponse {
                    header: req.header,
                    key_name: req.key_name,
                    attributes: req.attributes,
                    pub_key: Bytes::from(bytes),
                })
            }
        }
    }
}
/// p11hsm provider builder
#[derive(Derivative)]
#[derivative(Debug)]
pub struct ProviderBuilder {
    uuid: Option<Uuid>,
    provider_identity: Option<ProviderIdentity>,
    sdk_ctx: Option<SDKContext>,
    sdk: Option<SDK>,
    user_pin: Option<SecretString>,
}

impl ProviderBuilder {
    /// create a new empty provider builder
    pub fn new() -> Self {
        ProviderBuilder {
            uuid: None,
            provider_identity: None,
            sdk_ctx: None,
            sdk: None,
            user_pin: None,
        }
    }
    
    /// set uuid
    pub fn with_uuid(mut self, uuid: Uuid) -> Self {
        self.uuid = Some(uuid);
        self
    }
    
    /// set provider_identity
    pub fn with_provider_identity(mut self, provider_identity: ProviderIdentity) -> Self {
        self.provider_identity = Some(provider_identity);
        self
    }
    
    /// set sdk_ctx
    pub fn with_sdk_ctx(mut self, sdk_ctx: SDKContext) -> Self {
        self.sdk_ctx = Some(sdk_ctx);
        self
    }
    
    /// set sdk
    pub fn with_sdk(mut self, sdk: SDK) -> Self {
        self.sdk = Some(sdk);
        self
    }
    
    /// set user_pin
    pub fn with_user_pin(mut self, user_pin: String) -> Self {
        self.user_pin = Some(SecretString::from(user_pin));
        self
    }
    
    /// build a p11hsm provider
    pub fn build(self) -> Result<Provider> {
        let uuid = self.uuid.ok_or_else(|| ErrorKind::Config.context("uuid is not set"))?;
        let provider_identity = self.provider_identity.ok_or_else(|| ErrorKind::Config.context("provider_identity is not set"))?;
        let sdk_ctx = self.sdk_ctx.ok_or_else(|| ErrorKind::Config.context("sdk_ctx is not set"))?;
        
        Ok(Provider::new(
            uuid, 
            provider_identity, 
            sdk_ctx, 
            self.sdk, 
            self.user_pin.ok_or_else(|| ErrorKind::Config.context("user_pin is not set"))?))
    }

    /// define the identity of the provider from config
    pub fn build_provider_identity(&self, app_config: &CbKmsSvcConfig) -> Result<ProviderIdentity> {
        let uuid = self.uuid.ok_or_else(|| ErrorKind::Config.context("uuid is not set"))?;
        
        let (p11hsm_config, hsm_config) = Provider::get_hsm_config(uuid, &app_config)?;
        
        Ok(ProviderIdentity::new(uuid.to_string(), format!("{}-{}", p11hsm_config.name, hsm_config.token_label)))
    }

    /// build sdk context from config
    pub fn build_sdk_ctx(&self, app_config: &CbKmsSvcConfig) -> Result<SDKContext> {
        let uuid = self.uuid.ok_or_else(|| ErrorKind::Config.context("uuid is not set"))?;

        let (p11hsm_config, hsm_config) = Provider::get_hsm_config(uuid, &app_config)?;
        
        let ctx = SDKContext::create_pkcs11(
            p11hsm_config.env_module.as_deref(),
            p11hsm_config.module.as_deref(),
        )?;
        
        Ok(SDKContext::from_pkcs11_label(ctx, hsm_config.token_label.as_str())?)
    }
    
    /// build sdk
    pub fn build_sdk(&self) -> Result<SDK> {
        let pin = self.user_pin.as_ref().ok_or_else(|| ErrorKind::Config.context("user_pin is not set"))?;
        let sdk_ctx = self.sdk_ctx.as_ref().ok_or_else(|| ErrorKind::Config.context("sdk_ctx is not set"))?;
        
        let sdk = SDK::from_context_with_login(sdk_ctx, pin.expose_secret().to_string().as_str())?;
        
        Ok(sdk)
    }

}

