use crate::application::APP;
use crate::proto::KeyType;
use crate::proto::{list_key_types_response, ListKeyTypesRequest, ListKeyTypesResponse, PingRequest, PingResponse, ProviderInfo, ProviderType};
use crate::providers::{Provide, ProviderIdentity};
use abscissa_core::Application;
use tonic::async_trait;
use crate::config::CbKmsSvcConfig;

const SUPPORTED_KEY_TYPES: [KeyType; 5] = [
    KeyType::Secp256k1,
    KeyType::Ed25519,
    KeyType::Secp256r1,
    KeyType::Rsa2048,
    KeyType::Aes,
];

/// soft crypto provider
#[derive(Debug)]
pub struct Provider {
    provider_identity: ProviderIdentity,
}

#[async_trait]
impl Provide for Provider {
    async fn ping(&self, req: PingRequest) -> crate::Result<PingResponse> {
        Ok(PingResponse {
            header: req.header,
            pong: self.provider_identity.to_string(),
        })
    }    
    
    fn native_describe(&self, app_config: &CbKmsSvcConfig) -> crate::Result<crate::proto::describe_response::Body> {
        let config = &app_config.providers.softcrypto;
        
        Ok(crate::proto::describe_response::Body {
            provider: Some(ProviderInfo {
                uuid: config.uuid.clone(),
                description: self.provider_identity.to_string(),
                vendor: config.name.clone(),
                semver: env!("CARGO_PKG_VERSION").to_string(),
                provider_type: ProviderType::SoftCrypto.into(),
            }),
            key_types: SUPPORTED_KEY_TYPES.map(|i| i.into()).to_vec(),
        })
    }
    
    fn describe(&self, req: crate::proto::DescribeRequest) -> crate::Result<crate::proto::DescribeResponse> {
        let app_config = &APP.config();
        
        Ok(crate::proto::DescribeResponse {
            header: req.header,
            body: Some(self.native_describe(app_config)?),
        })
    }

    fn list_provider_key_types(&self, req: ListKeyTypesRequest) -> crate::Result<ListKeyTypesResponse> {

        Ok(ListKeyTypesResponse {
            header: req.header,
            provider_key_types: vec![list_key_types_response::ProviderKeyType {
                uuid: "".to_string(),
                key_types: SUPPORTED_KEY_TYPES.map(|i| i.into()).to_vec(),
            }],
        })
    }
    
}

/// soft crypto provider builder
#[derive(Debug)]
pub struct ProviderBuilder {
    provider_identity: ProviderIdentity,
}

impl ProviderBuilder {
    /// Create a new `ProviderBuilder`
    pub fn new(app_config: &CbKmsSvcConfig) -> Self {
        let config = &app_config.providers.softcrypto;
        
        let provider_identity = ProviderIdentity::new(config.uuid.clone(), config.name.clone());
        
        ProviderBuilder {
            provider_identity,
        }
    }

    /// Build the `Provider`
    pub fn build(self) -> crate::Result<Provider> {
        Ok(Provider {
            provider_identity: self
                .provider_identity,
        })
    }
}