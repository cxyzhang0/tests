//! CbKmsService Config
//!
//! See instructions in `commands.rs` to specify the path to your
//! application's configuration file and/or command-line options
//! for specifying it.

/// configuration for all providers
pub mod providers;

use serde::{Deserialize, Serialize};
use crate::config::providers::ProvidersConfig;

/// CbKmsService Configuration
#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct CbKmsSvcConfig {
    // /// An example configuration section
    // pub hello: ExampleSection,
    
    // /// core configure
    // pub core: CoreConfig, // moved to ProvidersConfig since Core is a (special) provider too
    
    /// providers configure
    pub providers: ProvidersConfig,
}

/// Default configuration settings.
///
/// Note: if your needs are as simple as below, you can
/// use `#[derive(Default)]` on CbKmsServiceConfig instead.
impl Default for CbKmsSvcConfig {
    fn default() -> Self {
        Self {
            // hello: ExampleSection::default(),
            // core: CoreConfig::default(),
            providers: ProvidersConfig::default(),
        }
    }
}
/*
/// Example configuration section.
///
/// Delete this and replace it with your actual configuration structs.
#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ExampleSection {
    /// Example configuration value
    pub recipient: String,
}

impl Default for ExampleSection {
    fn default() -> Self {
        Self {
            recipient: "world".to_owned(),
        }
    }
}
*/