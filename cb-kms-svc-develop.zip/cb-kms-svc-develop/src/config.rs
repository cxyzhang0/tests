//! CbKmsService Config
//!
//! See instructions in `commands.rs` to specify the path to your
//! application's configuration file and/or command-line options
//! for specifying it.

/// configuration for all providers
pub mod providers;

use serde::{Deserialize, Serialize};
use crate::config::providers::ProvidersConfig;

/// CbKmsService Configuration
#[derive(Clone, Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CbKmsSvcConfig {
    /// providers configure
    pub providers: ProvidersConfig,
}

/// Default configuration settings.
///
/// Note: if your needs are as simple as below, you can
/// use `#[derive(Default)]` on CbKmsServiceConfig instead.
impl Default for CbKmsSvcConfig {
    fn default() -> Self {
        Self {
            providers: ProvidersConfig::default(),
        }
    }
}
