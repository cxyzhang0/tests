//! `start` subcommand - example of how to write a subcommand

use std::net::SocketAddr;
use std::time::Duration;
/// App-local prelude includes `app_reader()`/`app_writer()`/`app_config()`
/// accessors along with logging macros. Customize as you see fit.
use crate::prelude::*;

use crate::config::CbKmsSvcConfig;
use abscissa_core::{config, Command, FrameworkError, Runnable};
use tonic::transport::Server;
use tower::ServiceBuilder;
use crate::proto::kms_svc_server::KmsSvcServer;

/// `start` subcommand
///
/// The `Parser` proc macro generates an option parser based on the struct
/// definition, and is defined in the `clap` crate. See their documentation
/// for a more comprehensive example:
///
/// <https://docs.rs/clap/>
#[derive(clap::Parser, Command, Debug)]
pub struct StartCmd {
    // /// To whom are we saying hello?
    // recipient: Vec<String>,
}

impl Runnable for StartCmd {
    /// Start the application.
    fn run(&self) {
        // let _config = APP.config();
        // println!("Hello, {}!", &config.hello.recipient);
        let kms = crate::server::Kms::default();
        let _ = abscissa_tokio::run(&APP, async {
            let config = APP.config();
            let addr: SocketAddr = config.providers.core.grpc.parse().unwrap();
            info!("Starting KmsSvc on {}", addr.clone().to_string());
            
            let mut server = Server::builder()
                // configuration tuning: these did not help the transport error from blkchn_svc when under load
                // .initial_connection_window_size(1000000)
                // .initial_stream_window_size(1000000)
                // .http2_max_pending_accept_reset_streams(Some(1000))
                // .max_concurrent_streams(1024)
                // .concurrency_limit_per_connection(1000)
                // .http2_keepalive_interval(Some(Duration::from_secs(2)))
                // .http2_keepalive_timeout(Some(Duration::from_secs(10)))
                // .http2_adaptive_window(Some(true))
                ;
            
            if crate::oauth2_resource_server::AuthZServer::is_authz_server_enabled() {
                // If the authz server is enabled, get it and create a layer
                let authz_server = crate::oauth2_resource_server::AuthZServer::get_authz_server()
                    .await
                    .unwrap_or_else(|e| {
                        error!("Failed to get authz server: {}", e);
                        std::process::exit(1);
                    });
                let layer = ServiceBuilder::new()
                    .layer(authz_server.into_layer())
                    .into_inner();

                server
                    .layer(layer)
                    .add_service(KmsSvcServer::new(kms))
                    .serve(addr)
                    .await
                    .unwrap()
                    ;           
            }
            else {
                // If not enabled
                server
                    .add_service(KmsSvcServer::new(kms))
                    .serve(addr)
                    .await
                    .unwrap();
            };
            
            // this is not reachable
            info!("KmsSvc started on {}", addr.to_string())
        });
    }
}

impl config::Override<CbKmsSvcConfig> for StartCmd {
    // Process the given command line options, overriding settings from
    // a configuration file using explicit flags taken from command-line
    // arguments.
    fn override_config(
        &self,
        config: CbKmsSvcConfig,
    ) -> Result<CbKmsSvcConfig, FrameworkError> {
        // if !self.recipient.is_empty() {
            // config.hello.recipient = self.recipient.join(" ");
        // }

        Ok(config)
    }
}
