//! Error types

use abscissa_core::error::{BoxError, Context};
use std::{
    fmt::{self, Display},
    io,
    ops::Deref,
};
use std::array::TryFromSliceError;
use abscissa_core::{FrameworkError, FrameworkErrorKind};
use thiserror::Error;

/// Kinds of errors
#[derive(Copy, Clone, Debug, Eq, Error, PartialEq)]
pub enum ErrorKind {
    /// Error in configuration file
    #[error("config error")]
    Config,

    /// Input/output error
    #[error("I/O error")]
    Io,
    
    /// invalid data
    #[error("invalid data")]
    InvalidData,

    /// not supported error
    #[error("not supported")]
    NotSupported,

    /// not supported error
    #[error("provider does not exist")]
    ProviderDoesNotExist,

    /// provider is not registered
    #[error("provider is not registered not exist")]
    ProviderNotRegistered,

    /// not supported error
    #[error("frost enum value not recognized")]
    FrostUnknownEnumValue(i32),

    /// tonic status
    #[error("tonic status")]
    TonicStatus,

    /// uuid error
    #[error("uuid error")]
    UuidError,

    /// pkcs11 sdk error
    #[error("pkcs11 sdk error")]
    P11SDKError,

    /// anyhow error
    #[error("anyhow error")]
    AnyhowError,
}

impl ErrorKind {
    /// Create an error context from this error
    pub fn context(self, source: impl Into<BoxError>) -> Context<ErrorKind> {
        Context::new(self, Some(source.into()))
    }
}

/// Error type
#[derive(Debug)]
pub struct Error(Box<Context<ErrorKind>>);

impl Deref for Error {
    type Target = Context<ErrorKind>;

    fn deref(&self) -> &Context<ErrorKind> {
        &self.0
    }
}

impl Display for Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

impl std::error::Error for Error {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        self.0.source()
    }
}

impl From<ErrorKind> for Error {
    fn from(kind: ErrorKind) -> Self {
        Context::new(kind, None).into()
    }
}

impl From<Context<ErrorKind>> for Error {
    fn from(context: Context<ErrorKind>) -> Self {
        Error(Box::new(context))
    }
}

impl From<io::Error> for Error {
    fn from(err: io::Error) -> Self {
        ErrorKind::Io.context(err).into()
    }
}

impl From<::prost::UnknownEnumValue> for Error {
    fn from(err: ::prost::UnknownEnumValue) -> Self {
        ErrorKind::FrostUnknownEnumValue(err.0).into()
    }
}

impl From<tonic::Status> for Error {
    fn from(err: tonic::Status) -> Self {
        ErrorKind::TonicStatus.context(err).into()
    }
}

impl Into<tonic::Status> for Error {
    fn into(self) -> tonic::Status {
        tonic::Status::new(tonic::Code::Internal, self.to_string())
    }
}

impl From<uuid::Error> for Error {
    fn from(err: uuid::Error) -> Self {
        ErrorKind::UuidError.context(err).into()
    }
}

impl From<pkcs11::Error> for Error {
    fn from(err: pkcs11::Error) -> Self {
        ErrorKind::P11SDKError.context(err).into()
    }
}

impl From<TryFromSliceError> for Error {
    fn from(err: TryFromSliceError) -> Self {
        ErrorKind::InvalidData.context(err).into()
    }
}

impl Into<FrameworkError> for Error {
    fn into(self) -> FrameworkError {
        FrameworkErrorKind::ConfigError.context(self).into()
    }
}

impl From<anyhow::Error> for Error {
    fn from(err: anyhow::Error) -> Self {
        ErrorKind::AnyhowError.context(err).into()
    }
}
