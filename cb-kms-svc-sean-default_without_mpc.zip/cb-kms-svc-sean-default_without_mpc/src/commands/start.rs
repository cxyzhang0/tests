//! `start` subcommand - example of how to write a subcommand

use std::net::SocketAddr;
/// App-local prelude includes `app_reader()`/`app_writer()`/`app_config()`
/// accessors along with logging macros. Customize as you see fit.
use crate::prelude::*;

use crate::config::CbKmsSvcConfig;
use abscissa_core::{config, Command, FrameworkError, Runnable};
use tonic::transport::Server;
use crate::proto::kms_svc_server::KmsSvcServer;

/// `start` subcommand
///
/// The `Parser` proc macro generates an option parser based on the struct
/// definition, and is defined in the `clap` crate. See their documentation
/// for a more comprehensive example:
///
/// <https://docs.rs/clap/>
#[derive(clap::Parser, Command, Debug)]
pub struct StartCmd {
    // /// To whom are we saying hello?
    // recipient: Vec<String>,
}

impl Runnable for StartCmd {
    /// Start the application.
    fn run(&self) {
        // let _config = APP.config();
        // println!("Hello, {}!", &config.hello.recipient);
        let kms = crate::server::Kms::default();
        let _ = abscissa_tokio::run(&APP, async {
            let config = APP.config();
            let addr: SocketAddr = config.providers.core.grpc.parse().unwrap();
            info!("Starting KmsSvc on {}", addr.clone().to_string());
            Server::builder()
                .add_service(KmsSvcServer::new(kms))
                .serve(addr)
                .await
                .unwrap();
            info!("KmsSvc started on {}", addr.to_string())
        });   
        
    }
}

impl config::Override<CbKmsSvcConfig> for StartCmd {
    // Process the given command line options, overriding settings from
    // a configuration file using explicit flags taken from command-line
    // arguments.
    fn override_config(
        &self,
        config: CbKmsSvcConfig,
    ) -> Result<CbKmsSvcConfig, FrameworkError> {
        // if !self.recipient.is_empty() {
            // config.hello.recipient = self.recipient.join(" ");
        // }

        Ok(config)
    }
}
