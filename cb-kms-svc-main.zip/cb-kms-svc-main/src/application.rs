//! CbKmsService Abscissa Application

use std::env;
use crate::back::dispatcher::Dispatcher;
use crate::error::{Error, ErrorKind};
use crate::providers::{Provide};
use crate::{back, commands::EntryPoint, config::CbKmsSvcConfig, providers};
use abscissa_core::{application::{self, AppCell}, config::{self, CfgCell}, trace, Application, FrameworkError, StandardPaths};
use abscissa_tokio::TokioComponent;
use crate::proto::KeyType;
use std::sync::{Arc, Once};
use uuid::Uuid;
use crate::prelude::info;

/// Initialization call once
static INIT_CALL: Once = Once::new();
/// Application state
pub static APP: AppCell<CbKmsSvcApp> = AppCell::new();

/// CbKmsService Application
#[derive(Debug)]
pub struct CbKmsSvcApp {
    /// Application configuration.
    config: CfgCell<CbKmsSvcConfig>,

    /// Application state.
    state: application::State<Self>,
    
    /// provider dispatcher
    dispatcher: Arc<Dispatcher>,
    
    /// core provider
    core: providers::core::Provider,
}

/// Initialize a new application instance.
///
/// By default no configuration is loaded, and the framework state is
/// initialized to a default, empty state (no components, threads, etc).
impl Default for CbKmsSvcApp {
    fn default() -> Self {
        Self {
            config: CfgCell::default(),
            state: application::State::default(),
            dispatcher: Arc::new(Dispatcher::default()),
            core: providers::core::Provider::default(),
        }
    }
}

impl CbKmsSvcApp {
    /// borrow the APP provider dispatcher
    pub fn dispatcher(&self) -> &Dispatcher {
        &self.dispatcher
    }

    /// clone the dispatcher Arc (useful for tonic service structs)
    pub fn dispatcher_arc(&self) -> Arc<Dispatcher> {
        self.dispatcher.clone()
    }
    
    /// borrow the APP core provider
    pub fn core(&self) -> &providers::core::Provider {
        &self.core
    }
    
    /// initialize dispatcher and core states
    /// to be called only in after_config
    pub fn initialize(&mut self, app_config: &CbKmsSvcConfig) -> crate::Result<()> {
        let config = &app_config;
        // setup providers and dispatcher and core
        let mut dispatcher_builder = back::dispatcher::DispatcherBuilder::new();
        let mut core_builder = providers::core::ProviderBuilder::new(&app_config);

        // soft crypto provider
        {
            let cfg = &config.providers.softcrypto;
            let provider_builder = providers::softcrypto::ProviderBuilder::new(&app_config);

            // build provider
            let provider = provider_builder.build()?; //.map_err(|e| <Error as Into<FrameworkError>>::into(e))?;
            let discribe = provider.native_describe(&app_config)?; //.map_err(|e| <Error as Into<FrameworkError>>::into(e))?;

            let uuid = CbKmsSvcApp::convert_uuid(&cfg.uuid)?;

            // add provider to dispatcher
            dispatcher_builder = dispatcher_builder.with_provider(uuid, Arc::new(provider));

            // add provider info and provider key types to core
            core_builder = core_builder.with_provider_info(discribe.provider.ok_or_else(|| ErrorKind::ProviderDoesNotExist)?);
            core_builder = core_builder.with_provider_key_types(uuid, discribe.key_types.iter()
                .map(|i| KeyType::try_from(*i).unwrap()).collect()); // unwrap is safe here since i32 was from KeyType
        }

        // p11hsm providers
        // set env vars only once per p11hsm provider.
        INIT_CALL.call_once(|| {
            for p11hsm_config in &config.providers.p11hsm {
                info!("env::set_var - {}={}", &p11hsm_config.env_cfg, &p11hsm_config.cfg);
                env::set_var(&p11hsm_config.env_cfg, &p11hsm_config.cfg); // IDE may mistakenly flag for being unsafe, but it is safe here.
            }
        });
        for p11hsm_config in &config.providers.p11hsm {
            for hsm_config in &p11hsm_config.hsms {
                if hsm_config.enabled {
                    let mut provider_builder = providers::p11hsm::ProviderBuilder::new();
                    // uuid
                    let uuid = CbKmsSvcApp::convert_uuid(&hsm_config.uuid)?;
                    provider_builder = provider_builder.with_uuid(uuid);

                    // provider identity
                    let provider_identity = provider_builder.build_provider_identity(&app_config)?;
                    provider_builder = provider_builder.with_provider_identity(provider_identity);

                    // sdk context
                    let sdk_context = provider_builder.build_sdk_ctx(&app_config)?;
                    provider_builder = provider_builder.with_sdk_ctx(sdk_context);
                    
                    // user_pin
                    provider_builder = provider_builder.with_user_pin(
                        hsm_config.auth.pin()
                            .map_err(|e| ErrorKind::Io.context(e))?);
                    
                    // sdk
                    // set_sdk is optional; it will login and set.
                    // if not set, subsequent uses of the provider check and set
                    let sdk = provider_builder.build_sdk()?;
                    provider_builder = provider_builder.with_sdk(sdk);
                    
                    // build provider
                    let provider = provider_builder.build()?; 
                    
                    let discribe = provider.native_describe(&app_config)?;

                    // add provider to dispatcher
                    dispatcher_builder = dispatcher_builder.with_provider(uuid, Arc::new(provider));

                    // add provider info and provider key types to core
                    core_builder = core_builder.with_provider_info(discribe.provider.ok_or_else(|| ErrorKind::ProviderDoesNotExist)?);
                    core_builder = core_builder.with_provider_key_types(uuid, discribe.key_types.iter()
                        .map(|i| KeyType::try_from(*i).unwrap()).collect()); // unwrap is safe here since i32 was from KeyType
                    
                    // info!("p11hsm provider initialized {} {uuid} {} ", p11hsm_config.name, hsm_config.token_label);
                }
            }
        }

        // mpctss provider
        #[cfg(feature = "mpctss-provider")]
        for mpctss_config in &config.providers.mpctss {
            if mpctss_config.enabled {
                let mut provider_builder = providers::mpctss::ProviderBuilder::default();
                // uuid
                let uuid = CbKmsSvcApp::convert_uuid(&mpctss_config.uuid)?;
                provider_builder = provider_builder.with_uuid(uuid);

                // provider identity
                let provider_identity = ProviderIdentity::new(mpctss_config.uuid.clone(), mpctss_config.name.clone()); 
                provider_builder = provider_builder.with_provider_identity(provider_identity);
                
                let provider = provider_builder.build()?;
                let discribe = provider.native_describe(&app_config)?;
                
                // add provider to dispatcher
                dispatcher_builder = dispatcher_builder.with_provider(uuid, Arc::new(provider));
                
                // add provider info and provider key types to core
                core_builder = core_builder.with_provider_info(discribe.provider.ok_or_else(|| ErrorKind::ProviderDoesNotExist)?);
                core_builder = core_builder.with_provider_key_types(uuid, discribe.key_types.iter()
                    .map(|i| KeyType::try_from(*i).unwrap()).collect()); // unwrap is safe here since i32 was from KeyType
                
                // info!("mpctss provider initialized {} {uuid} {} ", mpctss_config.name, mpctss_config.user_pin);
            }
        }
        

        // build core
        let core = core_builder.build(&app_config)?;
        self.core = core.clone();

        // build dispatcher
        // add core provider
        let uuid = CbKmsSvcApp::convert_uuid(&config.providers.core.uuid)?;
        dispatcher_builder = dispatcher_builder.with_provider(uuid, Arc::new(core));
        
        self.dispatcher = Arc::new(dispatcher_builder.build()?);
        
        Ok(())
    }
    
    fn convert_uuid(uuid: &str) -> crate::Result<Uuid> {
        Uuid::parse_str(uuid)
            .map_err(|e| {
                // let e: Error = e.into();
                e.into()
            })
    }
}

impl Application for CbKmsSvcApp {
    /// Entrypoint command for this application.
    type Cmd = EntryPoint;

    /// Application configuration.
    type Cfg = CbKmsSvcConfig;

    /// Paths to resources within the application.
    type Paths = StandardPaths;

    /// Accessor for application configuration.
    fn config(&self) -> config::Reader<CbKmsSvcConfig> {
        self.config.read()
    }

    /// Borrow the application state immutably.
    fn state(&self) -> &application::State<Self> {
        &self.state
    }
    
    /// Register all components used by this application.
    ///
    /// If you would like to add additional components to your application
    /// beyond the default ones provided by the framework, this is the place
    /// to do so.
    fn register_components(&mut self, command: &Self::Cmd) -> Result<(), FrameworkError> {
        let mut framework_components = self.framework_components(command)?;
        framework_components.push(Box::new(TokioComponent::new()?));
        
        let mut app_components = self.state.components_mut();
        app_components.register(framework_components)
    }

    /// Post-configuration lifecycle callback.
    ///
    /// Called regardless of whether config is loaded to indicate this is the
    /// time in app lifecycle when configuration would be loaded if
    /// possible.
    fn after_config(&mut self, config: Self::Cfg) -> Result<(), FrameworkError> {
        {
            // Configure components
            let mut components = self.state.components_mut();
            components.after_config(&config)?;
            self.config.set_once(config.clone());
        }

        self.initialize(&config).map_err(|e| <Error as Into<FrameworkError>>::into(e))?;
        
        Ok(())
    }

    /// Get tracing configuration from command-line options
    fn tracing_config(&self, command: &EntryPoint) -> trace::Config {
        if command.verbose {
            trace::Config::verbose()
        } else {
            trace::Config::default()
        }
    }
}
