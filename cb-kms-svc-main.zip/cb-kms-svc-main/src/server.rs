use crate::application::APP;
use crate::error::Error;
use crate::proto::kms_svc_server::KmsSvc;
use crate::proto::{ListKeyTypesRequest, ListKeyTypesResponse, DescribeRequest, DescribeResponse, GenKeyRequest, GenKeyResponse, GetPubKeyRequest, GetPubKeyResponse, ListProvidersRequest, ListProvidersResponse, PingRequest, PingResponse, SignMsgRequest, SignMsgResponse, SignPrehashRequest, SignPrehashResponse};
use crate::providers::Provide;
use crate::back::dispatcher::Dispatcher;
use std::sync::Arc;
use tonic::{async_trait, Request, Response, Status};

/// The concrete KmsSvc implementation
#[derive(Debug, Clone)]
pub struct Kms {
    dispatcher: Arc<Dispatcher>,
}

impl Default for Kms {
    fn default() -> Self {
        Self::from_app()
    }
}

impl Kms {
    /// Construct from the global Abscissa APP (production)
    pub fn from_app() -> Self {
        Self {
            dispatcher: APP.dispatcher_arc(),
        }
    }

    /// Construct for unit tests without initializing Abscissa APP
    #[cfg(test)]
    pub(crate) fn new_for_tests(dispatcher: Arc<Dispatcher>) -> Self {
        Self { dispatcher }
    }
}
#[async_trait]
impl KmsSvc for Kms {
    async fn ping(&self, request: Request<PingRequest>) -> Result<Response<PingResponse>, Status> {
        let dispatcher = &*self.dispatcher;

        let resp = dispatcher.ping(request.into_inner()).await.map_err(|e| <Error as Into<Status>>::into(e))?;

        Ok(Response::new(resp))
    }

    async fn describe(&self, request: Request<DescribeRequest>) -> Result<Response<DescribeResponse>, Status> {
        let dispatcher = &*self.dispatcher;

        let resp = dispatcher.describe(request.into_inner()).map_err(|e| <Error as Into<Status>>::into(e))?;

        Ok(Response::new(resp))
    }

    async fn list_providers(&self, request: Request<ListProvidersRequest>) -> Result<Response<ListProvidersResponse>, Status> {
        let dispatcher = &*self.dispatcher;

        let resp = dispatcher.list_providers(request.into_inner()).map_err(|e| <Error as Into<Status>>::into(e))?;

        Ok(Response::new(resp))    
    }

    async fn list_provider_key_types(&self, request: Request<ListKeyTypesRequest>) -> Result<Response<ListKeyTypesResponse>, Status> {
        let dispatcher = &*self.dispatcher;
        
        let resp = dispatcher.list_provider_key_types(request.into_inner()).map_err(|e| <Error as Into<Status>>::into(e))?;

        Ok(Response::new(resp))
    }

    async fn gen_key(&self, request: Request<GenKeyRequest>) -> Result<Response<GenKeyResponse>, Status> {
        let dispatcher = &*self.dispatcher;

        let resp = dispatcher.gen_key(request.into_inner()).await.map_err(|e| <Error as Into<Status>>::into(e))?;

        Ok(Response::new(resp))
    }

    async fn get_pub_key(&self, request: Request<GetPubKeyRequest>) -> Result<Response<GetPubKeyResponse>, Status> {
        let dispatcher = &*self.dispatcher;

        let resp = dispatcher.get_pub_key(request.into_inner()).await.map_err(|e| <Error as Into<Status>>::into(e))?;

        Ok(Response::new(resp))
    }

    async fn sign_msg(&self, request: Request<SignMsgRequest>) -> Result<Response<SignMsgResponse>, Status> {
        let dispatcher = &*self.dispatcher;

        let resp = dispatcher.sign_msg(request.into_inner()).await.map_err(|e| <Error as Into<Status>>::into(e))?;

        Ok(Response::new(resp))
    }

    async fn sign_prehash(&self, request: Request<SignPrehashRequest>) -> Result<Response<SignPrehashResponse>, Status> {
        let dispatcher = &*self.dispatcher;

        let resp = dispatcher.sign_prehash(request.into_inner()).await.map_err(|e| <Error as Into<Status>>::into(e))?;

        Ok(Response::new(resp))
    }
}