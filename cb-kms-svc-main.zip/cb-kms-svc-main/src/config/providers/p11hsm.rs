use serde::{Deserialize, Serialize};
use kms_common::types::config::AuthConfig;

/// P11 HSM provider config
#[derive(Clone, Deserialize, Serialize, Debug, Default)]
#[serde(deny_unknown_fields)]
pub struct P11hsmConfig {
    /// name may be used to describe the vendor, e.g. futurex-1, softhsm-1, etc
    /// note: even for the same vendor, there could be multiple such config 
    /// - e.g., one for each different version of the driver
    pub name: String,

    /// provider version
    pub semver: String,

    /// evn var name for pkcs11 library file path
    /// so that the module file path can be retrieved from env var
    /// e.g., for FX, it is "FXPKCS11_MODULE"
    pub env_module: Option<String>,

    /// pkcs11 library binary file path
    pub module: Option<String>,

    /// pkcs11 config env var name
    /// e.g., for FX, it is "FXPKCS11_CFG"
    pub env_cfg: String,

    /// pkcs11 config file path
    pub cfg: String,

    /// list of hsms with the same driver
    /// e.g., one for each token slot. FX config can have up to 5 token slots
    /// each such logical slot can be a partition, or a different HSM
    #[serde(default)]
    pub hsms: Vec<HsmConfig>,    
}

/// hsms
#[derive(Clone, Debug, Deserialize, Serialize, Default)]
#[serde(deny_unknown_fields)]
pub struct HsmConfig {
    /// uuid: system-wide unique within the whole kms service
    pub uuid: String,
    
    /// pkcs11 token label to identify the slot
    /// e.g., "Slot Token 0"
    pub token_label: String,

    // replaced by auth /// pkcs11 user pin
    //pub user_pin: String,

    /// Authentication configuration
    pub auth: AuthConfig,
    
    /// whether to use it
    pub enabled: bool,

}

// cargo test --lib config::providers::p11hsm
// cargo test --lib config::providers::p11hsm -- --nocapture
// cargo test --lib config::providers::p11hsm::tests::
#[cfg(test)]
mod tests {
    use super::*;

    // cargo test --lib test_p11hsm_config_deserialization
    #[test]
    fn test_p11hsm_config_deserialization() {
        let toml = r#"
        name = "futurex-1"
        semver = "1.0.0"
        env_module = "FXPKCS11_MODULE"
        module = "/usr/lib/libfxpkcs11.so"
        env_cfg = "FXPKCS11_CFG"
        cfg = "/etc/fxpkcs11.cfg"
        hsms = []
        "#;

        let config: P11hsmConfig = toml::from_str(toml).unwrap();
        assert_eq!(config.name, "futurex-1");
        assert_eq!(config.semver, "1.0.0");
        assert_eq!(config.env_cfg, "FXPKCS11_CFG");
        assert_eq!(config.cfg, "/etc/fxpkcs11.cfg");
        assert!(config.hsms.is_empty());
    }

    #[test]
    fn test_hsm_config_with_auth() {
        let toml = r#"
        uuid = "hsm-001"
        token_label = "Slot Token 0"
        enabled = true

        [auth]
        pin = "secret123"
        "#;

        let config: HsmConfig = toml::from_str(toml).unwrap();
        assert_eq!(config.uuid, "hsm-001");
        assert_eq!(config.token_label, "Slot Token 0");
        assert!(config.enabled);
    }

    #[test]
    fn test_p11hsm_config_with_multiple_hsms() {
        let toml = r#"
        name = "softhsm-1"
        semver = "2.6.0"
        env_cfg = "SOFTHSM2_CONF"
        cfg = "/etc/softhsm2.conf"
        hsms = [
            { uuid = "hsm-001", token_label = "Token 0", auth = { pin = "pin1" }, enabled = true },
            { uuid = "hsm-002", token_label = "Token 1", auth = { pin = "pin2" }, enabled = false }
        ]
        "#;

        let config: P11hsmConfig = toml::from_str(toml).unwrap();
        assert_eq!(config.hsms.len(), 2);
        assert_eq!(config.hsms[0].uuid, "hsm-001");
        assert!(config.hsms[0].enabled);
        assert_eq!(config.hsms[1].uuid, "hsm-002");
        assert!(!config.hsms[1].enabled);
    }

    #[test]
    fn test_reject_old_user_pin_field() {
        let toml = r#"
        uuid = "hsm-001"
        token_label = "Slot Token 0"
        user_pin = "old_field"
        enabled = true

        [auth]
        pin = "secret"
        "#;

        let result: Result<HsmConfig, _> = toml::from_str(toml);
        assert!(result.is_err());
    }

    #[test]
    fn test_missing_auth_field() {
        let toml = r#"
        uuid = "hsm-001"
        token_label = "Slot Token 0"
        enabled = true
        "#;

        let result: Result<HsmConfig, _> = toml::from_str(toml);
        assert!(result.is_err());
    }

    #[test]
    fn test_clone_p11hsm_config() {
        let config = P11hsmConfig {
            name: "test".to_string(),
            semver: "1.0.0".to_string(),
            env_module: Some("TEST_MODULE".to_string()),
            module: Some("/lib/test.so".to_string()),
            env_cfg: "TEST_CFG".to_string(),
            cfg: "/etc/test.cfg".to_string(),
            hsms: vec![],
        };

        let cloned = config.clone();
        assert_eq!(config.name, cloned.name);
        assert_eq!(config.env_cfg, cloned.env_cfg);
    }

    #[test]
    fn test_hsm_config_with_pin_file() {
        use std::io::Write;
        use tempfile::NamedTempFile;

        let mut pin_file = NamedTempFile::new().unwrap();
        writeln!(pin_file, "secret_pin_from_file").unwrap();
        let pin_file_path = pin_file.path().to_str().unwrap();

        let toml = format!(
            r#"
        uuid = "hsm-003"
        token_label = "Slot Token 2"
        enabled = true

        [auth]
        pin_file = "{}"
        "#,
            pin_file_path.replace('\\', "\\\\")
        );

        let config: HsmConfig = toml::from_str(&toml).unwrap();
        assert_eq!(config.uuid, "hsm-003");
        assert_eq!(config.token_label, "Slot Token 2");
        assert!(config.enabled);
        match config.auth.pin() {
            Ok(pin) => assert_eq!(pin, "secret_pin_from_file"),
            Err(e) => panic!("Expected Ok, got Err: {}", e),
        }
    }

    #[test]
    fn test_p11hsm_config_with_pin_file_hsm() {
        use std::io::Write;
        use tempfile::NamedTempFile;

        let mut pin_file = NamedTempFile::new().unwrap();
        writeln!(pin_file, "test_pin_123").unwrap();
        let pin_file_path = pin_file.path().to_str().unwrap();

        let toml = format!(
            r#"
        name = "softhsm-1"
        semver = "2.6.0"
        env_cfg = "SOFTHSM2_CONF"
        cfg = "/etc/softhsm2.conf"
        hsms = [
            {{ uuid = "2b6a375b-93f9-4590-a38d-3a79f8062c8f", token_label = "Slot Token 0", auth = {{ pin_file = "{}" }}, enabled = true }}
        ]
        "#,
            pin_file_path.replace('\\', "\\\\")
        );

        let config: P11hsmConfig = toml::from_str(&toml).unwrap();
        assert_eq!(config.hsms.len(), 1);
        assert_eq!(config.hsms[0].uuid, "2b6a375b-93f9-4590-a38d-3a79f8062c8f");
        assert!(config.hsms[0].enabled);
        match config.hsms[0].auth.pin() {
            Ok(pin) => assert_eq!(pin, "test_pin_123"),
            Err(e) => panic!("Expected Ok, got Err: {}", e),
        }
    }
    // Add to the `tests` module (TOML tests)
    #[test]
    #[serial_test::serial]
    fn test_hsm_config_with_pin_env() {
        use std::env;

        env::set_var("TEST_PIN_ENV", "env_secret_pin");

        let toml = r#"
    uuid = "hsm-004"
    token_label = "Slot Token 3"
    enabled = true

    [auth]
    pin_env = "TEST_PIN_ENV"
    "#;

        let config: HsmConfig = toml::from_str(toml).unwrap();
        assert_eq!(config.uuid, "hsm-004");
        assert_eq!(config.token_label, "Slot Token 3");
        assert!(config.enabled);
        match config.auth.pin() {
            Ok(pin) => assert_eq!(pin, "env_secret_pin"),
            Err(e) => panic!("Expected Ok, got Err: {}", e),
        }

        env::remove_var("TEST_PIN_ENV");
    }

    #[test]
    #[serial_test::serial]
    fn test_p11hsm_config_with_pin_env_hsm() {
        use std::env;

        env::set_var("SOFTHSM2_PIN", "softhsm_env_pin");

        let toml = r#"
    name = "softhsm-1"
    semver = "2.6.0"
    env_cfg = "SOFTHSM2_CONF"
    cfg = "/etc/softhsm2.conf"
    hsms = [
        { uuid = "2b6a375b-93f9-4590-a38d-3a79f8062c8f", token_label = "Slot Token 0", auth = { pin_env = "SOFTHSM2_PIN" }, enabled = true }
    ]
    "#;

        let config: P11hsmConfig = toml::from_str(toml).unwrap();
        assert_eq!(config.hsms.len(), 1);
        assert_eq!(config.hsms[0].uuid, "2b6a375b-93f9-4590-a38d-3a79f8062c8f");
        assert!(config.hsms[0].enabled);
        match config.hsms[0].auth.pin() {
            Ok(pin) => assert_eq!(pin, "softhsm_env_pin"),
            Err(e) => panic!("Expected Ok, got Err: {}", e),
        }

        env::remove_var("SOFTHSM2_PIN");
    }
}

// cargo test --lib config::providers::p11hsm::tests_w_json::
#[cfg(test)]
mod tests_w_json {
    use super::*;

    #[test]
    fn test_p11hsm_config_deserialization() {
        let json = r#"
        {
            "name": "futurex-1",
            "semver": "1.0.0",
            "env_module": "FXPKCS11_MODULE",
            "module": "/usr/lib/libfxpkcs11.so",
            "env_cfg": "FXPKCS11_CFG",
            "cfg": "/etc/fxpkcs11.cfg",
            "hsms": []
        }
        "#;

        let config: P11hsmConfig = serde_json::from_str(json).unwrap();
        assert_eq!(config.name, "futurex-1");
        assert_eq!(config.semver, "1.0.0");
        assert_eq!(config.env_cfg, "FXPKCS11_CFG");
        assert_eq!(config.cfg, "/etc/fxpkcs11.cfg");
        assert!(config.hsms.is_empty());
    }

    #[test]
    fn test_hsm_config_with_auth() {
        let json = r#"
        {
            "uuid": "hsm-001",
            "token_label": "Slot Token 0",
            "auth": {
                "pin": "secret123"
            },
            "enabled": true
        }
        "#;

        let config: HsmConfig = serde_json::from_str(json).unwrap();
        assert_eq!(config.uuid, "hsm-001");
        assert_eq!(config.token_label, "Slot Token 0");
        assert!(config.enabled);
    }

    #[test]
    fn test_p11hsm_config_with_multiple_hsms() {
        let json = r#"
        {
            "name": "softhsm-1",
            "semver": "2.6.0",
            "env_cfg": "SOFTHSM2_CONF",
            "cfg": "/etc/softhsm2.conf",
            "hsms": [
                {
                    "uuid": "hsm-001",
                    "token_label": "Token 0",
                    "auth": {
                        "pin": "pin1"
                    },
                    "enabled": true
                },
                {
                    "uuid": "hsm-002",
                    "token_label": "Token 1",
                    "auth": {
                        "pin": "pin2"
                    },
                    "enabled": false
                }
            ]
        }
        "#;

        let config: P11hsmConfig = serde_json::from_str(json).unwrap();
        assert_eq!(config.hsms.len(), 2);
        assert_eq!(config.hsms[0].uuid, "hsm-001");
        assert!(config.hsms[0].enabled);
        assert_eq!(config.hsms[1].uuid, "hsm-002");
        assert!(!config.hsms[1].enabled);
    }

    #[test]
    fn test_reject_old_user_pin_field() {
        // Should fail due to deny_unknown_fields
        let json = r#"
        {
            "uuid": "hsm-001",
            "token_label": "Slot Token 0",
            "user_pin": "old_field",
            "auth": {
                "pin": "secret"
            },
            "enabled": true
        }
        "#;

        let result: Result<HsmConfig, _> = serde_json::from_str(json);
        assert!(result.is_err());
    }

    #[test]
    fn test_missing_auth_field() {
        // Should fail because auth is required
        let json = r#"
        {
            "uuid": "hsm-001",
            "token_label": "Slot Token 0",
            "enabled": true
        }
        "#;

        let result: Result<HsmConfig, _> = serde_json::from_str(json);
        assert!(result.is_err());
    }

    #[test]
    fn test_clone_p11hsm_config() {
        let config = P11hsmConfig {
            name: "test".to_string(),
            semver: "1.0.0".to_string(),
            env_module: Some("TEST_MODULE".to_string()),
            module: Some("/lib/test.so".to_string()),
            env_cfg: "TEST_CFG".to_string(),
            cfg: "/etc/test.cfg".to_string(),
            hsms: vec![],
        };

        let cloned = config.clone();
        assert_eq!(config.name, cloned.name);
        assert_eq!(config.env_cfg, cloned.env_cfg);
    }


    #[test]
    fn test_hsm_config_with_pin_file() {
        use std::io::Write;
        use tempfile::NamedTempFile;

        // Create a temporary file with a PIN
        let mut pin_file = NamedTempFile::new().unwrap();
        writeln!(pin_file, "secret_pin_from_file").unwrap();
        let pin_file_path = pin_file.path().to_str().unwrap();

        let json = format!(
            r#"
        {{
            "uuid": "hsm-003",
            "token_label": "Slot Token 2",
            "auth": {{
                "pin_file": "{}"
            }},
            "enabled": true
        }}
        "#,
            pin_file_path.replace('\\', "\\\\")
        );

        let config: HsmConfig = serde_json::from_str(&json).unwrap();
        assert_eq!(config.uuid, "hsm-003");
        assert_eq!(config.token_label, "Slot Token 2");
        assert!(config.enabled);
        match config.auth.pin() {
            Ok(pin) => assert_eq!(pin, "secret_pin_from_file"),
            Err(e) => panic!("Expected Ok, got Err: {}", e),
        }
    }

    #[test]
    fn test_p11hsm_config_with_pin_file_hsm() {
        use std::io::Write;
        use tempfile::NamedTempFile;

        let mut pin_file = NamedTempFile::new().unwrap();
        writeln!(pin_file, "test_pin_123").unwrap();
        let pin_file_path = pin_file.path().to_str().unwrap();

        let json = format!(
            r#"
        {{
            "name": "softhsm-1",
            "semver": "2.6.0",
            "env_cfg": "SOFTHSM2_CONF",
            "cfg": "/etc/softhsm2.conf",
            "hsms": [
                {{
                    "uuid": "2b6a375b-93f9-4590-a38d-3a79f8062c8f",
                    "token_label": "Slot Token 0",
                    "auth": {{
                        "pin_file": "{}"
                    }},
                    "enabled": true
                }}
            ]
        }}
        "#,
            pin_file_path.replace('\\', "\\\\")
        );

        let config: P11hsmConfig = serde_json::from_str(&json).unwrap();
        assert_eq!(config.hsms.len(), 1);
        assert_eq!(config.hsms[0].uuid, "2b6a375b-93f9-4590-a38d-3a79f8062c8f");
        assert!(config.hsms[0].enabled);
        match config.hsms[0].auth.pin() {
            Ok(pin) => assert_eq!(pin, "test_pin_123"),
            Err(e) => panic!("Expected Ok, got Err: {}", e),
        }
    }

    // Add to the `tests` module (TOML tests)
    #[test]
    #[serial_test::serial]
    fn test_hsm_config_with_pin_env() {
        use std::env;

        env::set_var("TEST_PIN_ENV", "env_secret_pin");

        let toml = r#"
    uuid = "hsm-004"
    token_label = "Slot Token 3"
    enabled = true

    [auth]
    pin_env = "TEST_PIN_ENV"
    "#;

        let config: HsmConfig = toml::from_str(toml).unwrap();
        assert_eq!(config.uuid, "hsm-004");
        assert_eq!(config.token_label, "Slot Token 3");
        assert!(config.enabled);
        match config.auth.pin() {
            Ok(pin) => assert_eq!(pin, "env_secret_pin"),
            Err(e) => panic!("Expected Ok, got Err: {}", e),
        }

        env::remove_var("TEST_PIN_ENV");
    }

    #[test]
    #[serial_test::serial]
    fn test_p11hsm_config_with_pin_env_hsm() {
        use std::env;

        env::set_var("SOFTHSM2_PIN", "softhsm_env_pin");

        let toml = r#"
    name = "softhsm-1"
    semver = "2.6.0"
    env_cfg = "SOFTHSM2_CONF"
    cfg = "/etc/softhsm2.conf"
    hsms = [
        { uuid = "2b6a375b-93f9-4590-a38d-3a79f8062c8f", token_label = "Slot Token 0", auth = { pin_env = "SOFTHSM2_PIN" }, enabled = true }
    ]
    "#;

        let config: P11hsmConfig = toml::from_str(toml).unwrap();
        assert_eq!(config.hsms.len(), 1);
        assert_eq!(config.hsms[0].uuid, "2b6a375b-93f9-4590-a38d-3a79f8062c8f");
        assert!(config.hsms[0].enabled);
        match config.hsms[0].auth.pin() {
            Ok(pin) => assert_eq!(pin, "softhsm_env_pin"),
            Err(e) => panic!("Expected Ok, got Err: {}", e),
        }

        env::remove_var("SOFTHSM2_PIN");
    }

}
