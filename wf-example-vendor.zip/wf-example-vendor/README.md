This workspace contains a copy of dkls23-rs/crates/dc-node-svc and shows
how to build a project that uses open-source and proprietary SL
libraries.

File .cargo/config.toml patches the SL registry to point to a vendor
copy of proprietary SL proprietary crates.

Vendor/*.crate files are output of “cargo package” command executed
from our workspace (dkls23-rs). The content of .crate file is uploaded
into our private registry.
