## hello via start
```bash
cargo run -- -c config.toml start -h
cargo run -- -c config.toml start
cargo run -- -c config.toml start "Alice", "Bob", "Charlie"
```

## keys
```bash
cargo run -- -c config.toml keys -h
cargo run -- -c config.toml keys gen-key -h
cargo run -- -c config.toml keys get-pub-key -h

cargo run -- -c config.toml keys gen-key -l "Slot Token 0/tmkms/ed25519-1/1" -a "ed25519" --persistent
cargo run -- -c config.toml keys gen-key -l "Slot Token 0/tmkms/ed25519-2/1" -a "ed25519" --persistent
cargo run -- -c config.toml keys gen-key -l "Slot Token 0/tmkms/ed25519-3/1" -a "ed25519" --persistent
cargo run -- -c config.toml keys gen-key -l "Slot Token 0/tmkms/ed25519-4/1" -a "ed25519" --persistent

cargo run -- -c config.toml keys gen-key -l "Slot Token 0/wfdc2/owner/1" -a "secp256k1" --persistent
cargo run -- -c config.toml keys gen-key -l "Slot Token 0/wfdc2/masterminter/1" -a "secp256k1" --persistent
cargo run -- -c config.toml keys gen-key -l "Slot Token 0/wfdc2/mintercontroller/1" -a "secp256k1" --persistent
cargo run -- -c config.toml keys gen-key -l "Slot Token 0/wfdc2/minter/1" -a "secp256k1" --persistent
cargo run -- -c config.toml keys gen-key -l "Slot Token 0/wfdc2/blacklister/1" -a "secp256k1" --persistent
cargo run -- -c config.toml keys gen-key -l "Slot Token 0/wfdc2/pauser/1" -a "secp256k1" --persistent
cargo run -- -c config.toml keys gen-key -l "Slot Token 0/wfdc2/usa/1" -a "secp256k1" --persistent
cargo run -- -c config.toml keys gen-key -l "Slot Token 0/wfdc2/can/1" -a "secp256k1" --persistent
cargo run -- -c config.toml keys gen-key -l "Slot Token 0/wfdc2/faucet/1" -a "secp256k1" --persistent
cargo run -- -c config.toml keys gen-key -l "Slot Token 0/wfdc2/user1/1" -a "secp256k1" --persistent
cargo run -- -c config.toml keys gen-key -l "Slot Token 0/wfdc2/user2/1" -a "secp256k1" --persistent

cargo run -- -c config.toml keys gen-key -l "Slot Token 0/test/p256/1" -a "secp256r1" --persistent

cargo run -- -c config.toml keys gen-key -l "slot-0/tsstrio-0/ed25519/1" -a "ed25519" --persistent
cargo run -- -c config.toml keys gen-key -l "slot-0/tsstrio-1/ed25519/1" -a "ed25519" --persistent
cargo run -- -c config.toml keys gen-key -l "slot-0/tsstrio-2/ed25519/1" -a "ed25519" --persistent

cargo run -- -c config.toml keys get-pub-key -l "Slot Token 0/test/p256/1" -t "account" -a "secp256r1" -p "wf"
SOFTHSM2_PIN=5678 cargo run -- -c config.toml keys get-pub-key -l "Slot Token 0/tmkms/ed25519-1/1" -t "consensus" -a "ed25519"
```
```bash
cargo build --release --features=p11hsm
alias kmstool=./target/release/kmstool
kmstool -c config.toml keys gen-key -h
kmstool -c config.toml keys get-pub-key -h

kmstool -c config.toml keys get-pub-key -l "Slot Token 0/tmkms/ed25519-1/1" -t "consensus" -a "ed25519"
kmstool -c config.toml keys get-pub-key -l "Slot Token 0/tmkms/ed25519-2/1" -t "consensus" -a "ed25519"
kmstool -c config.toml keys get-pub-key -l "Slot Token 0/tmkms/ed25519-3/1" -t "consensus" -a "ed25519"
kmstool -c config.toml keys get-pub-key -l "Slot Token 0/tmkms/ed25519-4/1" -t "consensus" -a "ed25519"

SOFTHSM2_PIN=5678 kmstool -c config.toml keys get-pub-key -l "Slot Token 0/wfdc2/owner/1" -t "account" -a "secp256k1" -p "wf"
kmstool -c config.toml keys get-pub-key -l "Slot Token 0/wfdc2/masterminter/1" -t "account" -a "secp256k1" -p "wf"
kmstool -c config.toml keys get-pub-key -l "Slot Token 0/wfdc2/mintercontroller/1" -t "account" -a "secp256k1" -p "wf"
kmstool -c config.toml keys get-pub-key -l "Slot Token 0/wfdc2/minter/1" -t "account" -a "secp256k1" -p "wf"
kmstool -c config.toml keys get-pub-key -l "Slot Token 0/wfdc2/blacklister/1" -t "account" -a "secp256k1" -p "wf"
kmstool -c config.toml keys get-pub-key -l "Slot Token 0/wfdc2/pauser/1" -t "account" -a "secp256k1" -p "wf"
kmstool -c config.toml keys get-pub-key -l "Slot Token 0/wfdc2/usa/1" -t "account" -a "secp256k1" -p "wf"
kmstool -c config.toml keys get-pub-key -l "Slot Token 0/wfdc2/can/1" -t "account" -a "secp256k1" -p "wf"
kmstool -c config.toml keys get-pub-key -l "Slot Token 0/wfdc2/faucet/1" -t "account" -a "secp256k1" -p "wf"
kmstool -c config.toml keys get-pub-key -l "Slot Token 0/wfdc2/user1/1" -t "account" -a "secp256k1" -p "wf"
kmstool -c config.toml keys get-pub-key -l "Slot Token 0/wfdc2/user2/1" -t "account" -a "secp256k1" -p "wf"

kmstool -c config.toml keys get-pub-key -l "Slot Token 0/test/p256/1" -t "account" -a "secp256r1"

kmstool -c config.toml keys get-pub-key -l "slot-0/tsstrio-0/ed25519/1" -t "consensus" -a "ed25519"
kmstool -c config.toml keys get-pub-key -l "slot-0/tsstrio-1/ed25519/1" -t "consensus" -a "ed25519"
kmstool -c config.toml keys get-pub-key -l "slot-0/tsstrio-2/ed25519/1" -t "consensus" -a "ed25519" | egrep -o 'json: (.*?);' | cut -d' ' -f2 | cut -d';' -f1
```

## Run tests
```shell
cargo test # all tests
cargo test abc # any test with abc in the name
cargo test --test acceptance # only in ./tests/acceptance.rs, ./tests is special and each .rs in it is a test module
cargo test kms_operation::tests:: --lib # only in ./src/kms_operation/tests.rs
cargo test kms_operation::tests::test_kms_operation_pub_key_k256 --lib # only test_kms_operation_pub_key_k256 in ./src/kms_operation/tests.rs

```
## Test coverage
```shell
# llvm-cov: https://lib.rs/crates/cargo-llvm-cov
cargo llvm-cov
cargo llvm-cov --html
open target/llvm-cov/html/index.html

# tarpaulin: https://lib.rs/crates/cargo-tarpaulin
cargo install cargo-tarpaulin
cargo tarpaulin
cargo tarpaulin --out Xml
cargo tarpaulin --ignore-tests --out Html
cargo tarpaulin --ignore-tests
cargo tarpaulin --ignore-tests -- test-threads=10
# exclude-files, example
cargo tarpaulin --ignore-tests --out Html -- exclude-files "./tests/acceptance.rs"

```

## apply linting
```shell
# Optimize Imports for the whole workspace: right-click on the workspace root folder in RustRover IDE and select Optimize Imports.
# unfortunately, the above does not remove unused imports.

# check the whole workspace. it will show unused imports, among other things.
# manually remove unused imports.
cargo check --workspace --all-features  
cargo check --all-features  

# Reformat the whole workspace: right-click on the workspace root folder in RustRover IDE and select Reformat Code.
# Or run the following commands.
cargo fmt --all --check # it will display the proposed changes.
cargo fmt --all

# clippy the whole workspace; review recommendations and make appropriate changes.
cargo clippy --workspace --all-features

# fix clippy recommendations: may need to export __CARGO_FIX_YOLO=1
cargo fix #--allow-dirty --allow-staged
cargo clippy --fix #--allow-dirty -- -Dwarnings  
```

## Cross compile for linux targets on MacOs
### gnu
```shell
rustup target add x86_64-unknown-linux-gnu
brew install SergioBenitez/osxct/x86_64-unknown-linux-gnu
# edit ~/.cargo/config.toml by adding
[target.x86_64-unknown-linux-gnu]
linker = "x86_64-unknown-linux-gnu-gcc"

TARGET_CC=x86_64-unknown-linux-gnu cargo build --release --features=p11hsm --target x86_64-unknown-linux-gnu --target-dir ./target-gnu
#TARGET_CC=x86_64-unknown-linux-gnu cargo build --release --features=p11hsm --target x86_64-unknown-linux-gnu --target-dir ./target-test-gnu

```