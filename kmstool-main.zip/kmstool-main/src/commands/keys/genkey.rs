use abscissa_core::{status_err, Application, Runnable};
use abscissa_core::tracing::info;
use pkcs11::{init_sdk, CryptographAlgorithm, KeyLabel, SDK};
use crate::application::APP;
use crate::prelude::Command;

#[derive(clap::Parser, Command, Debug)]
pub struct GenKeyCommand {
    /// key label in this format: `[prefix]/[key ring]/[key]/[version]`, e.g., `Slot Token 0/wfdc2/usa/1`
    #[clap(
        short = 'l', long = "kl",
        required = true,
        value_name = "key_label",
        // help_heading = "REQUIRED",
        help = "key label in this format: `[prefix]/[key ring]/[key]/[version]`"
    )]
    key_label: String,

    /// key type, account or consensus, currently not used
    // #[clap(short = 't', long = "kt")]
    // key_type: String,

    /// cryptographic algorithm, Secp256k1, Secp256r1, Ed25519, or RSA2048
    #[clap(short = 'a', long = "al")]
    algorithm: String,

    /// whether to persist the generated key depending on whether or not this flag is set.
    #[clap(long = "persistent")]
    persistent: bool,
}

impl Runnable for GenKeyCommand {
    /// Generate a new key.
    fn run(&self) {
        let config = APP.config().provider.p11hsm.clone();

        let algo = CryptographAlgorithm::from(self.algorithm.clone());

        let mut key_label = KeyLabel::from_short(&self.key_label, algo).unwrap_or_else(|e| {
            status_err!("couldn't make key label: {}", e);
            std::process::exit(1);
        });

        let ctx = init_sdk(
            &config.env_cfg,
            &config.cfg,
            config.env_module.as_deref(),
            config.module.as_deref(),
            &config.token_label,
            &config.user_pin,
        ).unwrap_or_else(|e| {
            status_err!("couldn't init sdk: {}", e);
            std::process::exit(1);
        });

        let sdk = SDK::from_context(&ctx).unwrap_or_else(|e| {
            status_err!("couldn't make sdk from context: {}", e);
            std::process::exit(1);
        });

        sdk.keygen(&mut key_label, self.persistent).unwrap_or_else(|e| {
            status_err!("couldn't generate key: {}", e);
            std::process::exit(1);
        });

        info!(
                "***** new key generated - key label: {}; algo: {:?}; persisted: {}",
                key_label.short_label(), algo, self.persistent
            );
    }
}