use abscissa_core::{status_err, Runnable};
use crate::commands::keys::KeysCommand;
use crate::commands::KmstoolCmd;
use crate::kms_operation::KmsOperation;
use crate::prelude::Command;
// use pkcs11::KeyLabel;

#[derive(clap::Parser, Clone, Command, Debug)]
pub(crate) struct GenKeyCommand {
    /// key label in this format: `[prefix]/[key ring]/[key]/[version]`, e.g., `Slot Token 0/wfdc2/usa/1`
    #[clap(
        short = 'l', long = "kl",
        required = true,
        value_name = "key_label",
        // help_heading = "REQUIRED",
        help = "key label in this format: `[prefix]/[key ring]/[key]/[version]`"
    )]
    pub(crate) key_label: String,

    /// key type, account or consensus, currently not used
    // #[clap(short = 't', long = "kt")]
    // key_type: String,

    /// cryptographic algorithm, Secp256k1, Secp256r1, Ed25519, or RSA2048
    #[clap(short = 'a', long = "al")]
    pub(crate) algorithm: String,

    /// whether to persist the generated key depending on whether or not this flag is set.
    #[clap(long = "persistent", default_value = "false")]
    pub(crate) persistent: bool,
}

impl Runnable for GenKeyCommand {
    /// Generate a new key.
    fn run(&self) {
        let cmd = self.clone();
        let cmd = KmstoolCmd::Keys(KeysCommand::GenKey(cmd));
        
        let op = KmsOperation::default_w_cmd(cmd);
        
        op.run().unwrap_or_else(|e| {
            status_err!("key gen operation failed: {}", e);
            std::process::exit(1);
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use pkcs11::{CryptographAlgorithm, KeyLabel};

    #[test]
    // todo: it does not call run() method. so what is it testing?
    fn test_valid_key_label() {
        let valid_label = "Slot Token 0/wfdc2/usa/1";
        let algo = CryptographAlgorithm::Ed25519;
        let key_label = KeyLabel::from_short(valid_label, algo).unwrap();
        assert_eq!(key_label.short_label(), valid_label);
    }

    #[test]
    fn test_invalid_key_label() {
        let cmd = GenKeyCommand {
            key_label: "wrong-label/1".to_string(),
            algorithm: "secp256k1".to_string(),
            persistent: false,
        };

        let result = std::panic::catch_unwind(|| {
            cmd.run();
        });

        // The function should panic because RSA2048 is not supported
        assert!(result.is_err());
    }
}


