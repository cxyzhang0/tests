use std::convert::TryFrom;
use abscissa_core::{status_err, Application, Runnable};
use abscissa_core::tracing::info;
use pkcs11::{init_sdk, CryptographAlgorithm, KeyLabel, SDK};
use crate::application::APP;
use crate::prelude::Command;
use cosmrs::crypto::PublicKey as CosmrsPublicKey;
use cosmrs::proto::cosmos::crypto::ed25519::PubKey as CosmosEdPubKey;
use cosmrs::crypto::PublicKey;

#[derive(clap::Parser, Command, Debug)]
pub struct GetPubKeyCommand {
    /// key label in this format: `[prefix]/[key ring]/[key]/[version]`, e.g., `Slot Token 0/wfdc2/usa/1`
    #[clap(short = 'l', long = "kl")]
    key_label: String,

    /// cryptographic algorithm, Secp256k1, Secp256r1, or Ed25519. RSA2048 is not supported
    #[clap(short = 'a', long = "al")]
    algorithm: String,

    /// key type, account or consensus
    #[clap(short = 't', long = "kt")]
    key_type: String,

    /// key type, account or consensus, currently not used
    #[clap(short = 'p', long = "prefix")]
    address_prefix: Option<String>,

}

impl Runnable for GetPubKeyCommand {
    fn run(&self) {
        let config = APP.config().provider.p11hsm.clone();

        let algo = CryptographAlgorithm::from(self.algorithm.clone());

        if algo == CryptographAlgorithm::RSA2048 {
            status_err!("RSA2048 is not supported");
            std::process::exit(1);
        }

        let key_label = KeyLabel::from_short(&self.key_label, algo).unwrap_or_else(|e| {
            status_err!("couldn't make key label: {}", e);
            std::process::exit(1);
        });

        let ctx = init_sdk(
            &config.env_cfg,
            &config.cfg,
            config.env_module.as_deref(),
            config.module.as_deref(),
            &config.token_label,
            &config.user_pin,
        ).unwrap_or_else(|e| {
            status_err!("couldn't init sdk: {}", e);
            std::process::exit(1);
        });

        let sdk = SDK::from_context(&ctx).unwrap_or_else(|e| {
            status_err!("couldn't make sdk from context: {}", e);
            std::process::exit(1);
        });

        let pk = match algo {
            CryptographAlgorithm::Secp256k1 => {
                let vk = sdk.get_k256_public_key(&key_label).unwrap_or_else(|e| {
                    status_err!("couldn't get public key: {}", e);
                    std::process::exit(1);
                });

                let pk = PublicKey::from(vk);

                if self.address_prefix.is_none() {
                    status_err!("address prefix is required for Secp256k1");
                    std::process::exit(1);
                }

                if self.key_type != "account" {
                    status_err!("key type must be account for Secp256k1");
                    std::process::exit(1);
                }

                let account_id = pk.account_id(&self.address_prefix.clone().unwrap()).unwrap();

                format!("pub key hex: {}; acct addr: {}", hex::encode(vk.to_sec1_bytes()), account_id)
            },
            CryptographAlgorithm::Secp256r1 => {
                let vk = sdk.get_p256_public_key(&key_label).unwrap_or_else(|e| {
                    status_err!("couldn't get public key: {}", e);
                    std::process::exit(1);
                });

                format!("pub key hex: {}", hex::encode(vk.to_sec1_bytes()))
            },
            CryptographAlgorithm::Ed25519 => {
                let vk = sdk.get_ed_public_key(&key_label).unwrap_or_else(|e| {
                    status_err!("couldn't get public key: {}", e);
                    std::process::exit(1);
                });

                let pub_key = CosmosEdPubKey {
                    key: vk.as_bytes().to_vec(),
                };

                let cosmos_public_key = CosmrsPublicKey::try_from(pub_key.clone()).unwrap();

                format!("pub key hex: {}; pub key json: {}", String::from_utf8(Vec::from(hex::encode(vk.as_bytes()))).unwrap(), cosmos_public_key.to_json())
            },
            _ => {
                status_err!("unsupported algorithm: {:?}", algo);
                std::process::exit(1);
            },
        };
        info!("***** key label: {}; pub key info - {}; algo: {:?}", key_label.short_label(), pk, algo);

        // this works only for ed25519
        /*
        let bytes = sdk.get_decoded_public_key_bytes(&key_label).unwrap_or_else(|e| {
            status_err!("couldn't get decoded public key bytes: {}", e);
            std::process::exit(1);
        });

        let pk = String::from_utf8(Vec::from(hex::encode(&bytes))).unwrap(); // 33 bytes or 65

        info!("***** key label: {}; pub key: {}; algo: {:?}", key_label.short_label(), pk, algo);
        // info!("***** key label: {}; pub key: {}; acct addr: {}", key_label.short_label(), pk);
        */
    }
}
