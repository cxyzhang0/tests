use crate::commands::keys::KeysCommand;
use crate::commands::KmstoolCmd;
use crate::kms_operation::KmsOperation;
use crate::prelude::Command;
use abscissa_core::{status_err, Runnable};

#[derive(clap::Parser, Command, Clone, Debug)]
pub(crate) struct GetPubKeyCommand {
    /// key label in this format: `[prefix]/[key ring]/[key]/[version]`, e.g., `Slot Token 0/wfdc2/usa/1`
    #[clap(short = 'l', long = "kl")]
    pub(crate) key_label: String,

    /// cryptographic algorithm, Secp256k1, Secp256r1, or Ed25519. RSA2048 is not supported
    #[clap(short = 'a', long = "al")]
    pub(crate) algorithm: String,

    /// key type, account or consensus
    #[clap(short = 't', long = "kt")]
    pub(crate) key_type: String,

    /// key type, account or consensus, currently not used
    #[clap(short = 'p', long = "prefix")]
    pub(crate) address_prefix: Option<String>,
}

impl Runnable for GetPubKeyCommand {
    fn run(&self) {
        let cmd = self.clone();
        let cmd = KmstoolCmd::Keys(KeysCommand::GetPubKey(cmd));

        let op = KmsOperation::default_w_cmd(cmd);

        op.run().unwrap_or_else(|e| {
            status_err!("get pub key operation failed: {}", e);
            std::process::exit(1);
        })

        // this works only for ed25519
        /*
        let bytes = sdk.get_decoded_public_key_bytes(&key_label).unwrap_or_else(|e| {
            status_err!("couldn't get decoded public key bytes: {}", e);
            std::process::exit(1);
        });

        let pk = String::from_utf8(Vec::from(hex::encode(&bytes))).unwrap(); // 33 bytes or 65

        info!("***** key label: {}; pub key: {}; algo: {:?}", key_label.short_label(), pk, algo);
        // info!("***** key label: {}; pub key: {}; acct addr: {}", key_label.short_label(), pk);
        */
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_unsupported_algorithm() {
        let cmd = GetPubKeyCommand {
            key_label: "Slot Token 0/wfdc2/usa/1".to_string(),
            algorithm: "RSA2048".to_string(),
            key_type: "account".to_string(),
            address_prefix: None,
        };

        let result = std::panic::catch_unwind(|| {
            cmd.run();
        });

        // The function should panic because RSA2048 is not supported
        assert!(result.is_err());
    }

    #[test]
    fn test_invalid_label() {
        let cmd = GetPubKeyCommand {
            key_label: "wrong-label/1".to_string(),
            algorithm: "Secp256k1".to_string(),
            key_type: "account".to_string(),
            address_prefix: None,
        };

        let result = std::panic::catch_unwind(|| {
            cmd.run();
        });

        // The function should panic because key_label is invalid
        assert!(result.is_err());
    }

    // these two panic during testing
    /*
    #[test]
    fn test_generate_key_command() {
        let output = ProcessCommand::new("./target/release/kmstool")
            .args(&["-c", "config.toml", "keys", "gen-key", "-l", "slot-0/test/key/1", "-a", "secp256k1"])
            .output()
            .expect("failed to execute command");

        assert!(output.status.success());
        assert!(String::from_utf8_lossy(&output.stdout).contains("new key generated"));
    }

    #[test]
    fn test_cli_keys_get_pub_key() {
        AssertCommand::cargo_bin("kmstool")
            .unwrap()
            .args(&["keys", "get-pub-key", "-l", "slot-0/tsstrio/ed25519/1", "-a", "ed25519", "-t", "consensus"])
            .assert()
            .success()
            .stdout(predicates::str::contains("pub key hex"));
    }
    */
}
