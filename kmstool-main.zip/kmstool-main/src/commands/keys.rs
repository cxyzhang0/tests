mod genkey;
mod pubkey;

use crate::commands::keys::genkey::GenKeyCommand;
use crate::commands::keys::pubkey::GetPubKeyCommand;
use crate::prelude::{Command, Runnable};


#[derive(clap::Parser, Command, Debug, Runnable)]
pub enum KeysCommand {
    /// The `gen-key` subcommand
    GenKey(GenKeyCommand),
    /// The `get-pub-key` subcommand
    GetPubKey(GetPubKeyCommand),
}
