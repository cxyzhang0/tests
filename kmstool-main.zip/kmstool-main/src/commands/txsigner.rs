pub(crate) mod txsign;

use crate::commands::txsigner::txsign::TxsignCommand;
use crate::prelude::{Command, Runnable};

#[derive(clap::Parser, Command, Debug, Runnable)]
pub enum TxsignerCommand {
    /// The `txsign` subcommand
    Txsign(TxsignCommand),
}