//! Test utilities for the `kmstool` crate.

use crate::kms_operation::SDKProvider;
use mockall::mock;
use pkcs11_sdk::KeyLabel;
mock! {
    pub SDKPrividerImpl {}
    impl SDKProvider for SDKPrividerImpl {
        fn keygen(&self, key_label: &mut KeyLabel, persistent: bool) -> Result<(), String>;

        fn get_k256_public_key(&self, key_label: &KeyLabel, key_type: String, address_prefix: Option<String>) -> Result<String, String>;

        fn get_p256_public_key(&self, key_label: &KeyLabel, key_type: String, address_prefix: Option<String>) -> Result<String, String>;

        fn get_ed_public_key(&self, key_label: &KeyLabel, key_type: String, address_prefix: Option<String>) -> Result<String, String>;

    }
}
