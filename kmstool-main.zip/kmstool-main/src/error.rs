//! Error types

use abscissa_core::error::{BoxError, Context};
use std::{
    fmt::{self, Display},
    io,
    ops::Deref,
};
use thiserror::Error;

/// Kinds of errors
#[derive(Copy, Clone, Debug, Eq, Error, PartialEq)]
pub enum ErrorKind {
    /// Error in configuration file
    #[error("config error")]
    Config,

    /// Input/output error
    #[error("I/O error")]
    Io,
}

impl ErrorKind {
    /// Create an error context from this error
    pub fn context(self, source: impl Into<BoxError>) -> Context<ErrorKind> {
        Context::new(self, Some(source.into()))
    }
}

/// Error type
#[derive(Debug)]
pub struct Error(Box<Context<ErrorKind>>);

impl Deref for Error {
    type Target = Context<ErrorKind>;

    fn deref(&self) -> &Context<ErrorKind> {
        &self.0
    }
}

impl Display for Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

impl std::error::Error for Error {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        self.0.source()
    }
}

impl From<ErrorKind> for Error {
    fn from(kind: ErrorKind) -> Self {
        Context::new(kind, None).into()
    }
}

impl From<Context<ErrorKind>> for Error {
    fn from(context: Context<ErrorKind>) -> Self {
        Error(Box::new(context))
    }
}

impl From<io::Error> for Error {
    fn from(err: io::Error) -> Self {
        ErrorKind::Io.context(err).into()
    }
}

#[cfg(test)]
mod tests {
    use std::error::Error as StdError;
    use super::*;
    use std::io;

    #[test]
    fn test_error_kind_display() {
        // Test the Display implementation for ErrorKind
        assert_eq!(ErrorKind::Config.to_string(), "config error");
        assert_eq!(ErrorKind::Io.to_string(), "I/O error");
    }

    #[test]
    fn test_error_from_error_kind() {
        // Test conversion from ErrorKind to Error
        let config_error: Error = ErrorKind::Config.into();
        assert_eq!(config_error.kind(), &ErrorKind::Config);

        let io_error: Error = ErrorKind::Io.into();
        assert_eq!(io_error.kind(), &ErrorKind::Io);
    }

    #[test]
    fn test_error_context_from_error_kind() {
        // Test creating a context from a source error
        let source_error = io::Error::new(io::ErrorKind::Other, "test io error");
        let context: Context<ErrorKind> = ErrorKind::Io.context(source_error);

        assert_eq!(context.kind(), &ErrorKind::Io);
        assert!(context.source().is_some());
        assert_eq!(context.source().unwrap().to_string(), "test io error");
    }

    #[test]
    fn test_error_from_context() {
        // Test conversion from Context<ErrorKind> to Error
        let source_error = io::Error::new(io::ErrorKind::Other, "test io error");
        let context = ErrorKind::Io.context(source_error);
        let error: Error = context.into();

        assert_eq!(error.kind(), &ErrorKind::Io);
        assert!(error.source().is_some());
        assert_eq!(error.source().unwrap().to_string(), "test io error");
    }

    #[test]
    fn test_error_from_io_error() {
        // Test conversion from io::Error to Error using From trait
        let io_error = io::Error::new(io::ErrorKind::Other, "test io error");
        let error: Error = io_error.into();

        assert_eq!(error.kind(), &ErrorKind::Io);
        assert!(error.source().is_some());
        assert_eq!(error.source().unwrap().to_string(), "test io error");
    }

    #[test]
    fn test_error_deref() {
        // Test Deref implementation for Error
        let error: Error = ErrorKind::Config.into();
        let context: &Context<ErrorKind> = &*error; // Deref to Context

        assert_eq!(context.kind(), &ErrorKind::Config);
    }

    #[test]
    fn test_error_display() {
        // Test Display implementation for Error
        let error: Error = ErrorKind::Config.into();
        assert_eq!(error.to_string(), "config error");
    }

    #[test]
    fn test_error_source() {
        // Test the source() method for Error
        let io_error = io::Error::new(io::ErrorKind::Other, "test io error");
        let error: Error = ErrorKind::Io.context(io_error).into();

        assert!(error.source().is_some());
        assert_eq!(error.source().unwrap().to_string(), "test io error");
    }
}