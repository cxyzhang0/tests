use anyhow::{anyhow, bail, Context, Result};
use base64::Engine as _;
use cosmos_sdk_proto::cosmos::tx::v1beta1::{SignDoc, Tx};
use prost::Message;
use std::{
    fs,
    path::{Path, PathBuf},
    process::Command,
};
use std::convert::TryInto;
use std::process::Stdio;
use sha2::Digest;
use tempfile::TempDir;
use tracing::{info, debug, warn};

type JsonValue = serde_json::Value;

pub trait Signer {
    fn sign_rs64_sha256_signdoc(&self, cfg: &RunConfig, sign_doc_bytes: &[u8]) -> Result<[u8; 64]>;
}

#[derive(Clone, Debug)]
pub struct RunConfig {
    pub input_unsigned_json: PathBuf,
    pub chain_id: String,
    pub account_number: u64,
    pub sequence: u64,
    pub pubkey_hex: String,
    pub output_b64: Option<PathBuf>,
    pub output_json: PathBuf,
    pub dump_pre_sig: Option<PathBuf>,
    pub chain_bin: PathBuf,
    pub encoded_tx_b64_in: Option<PathBuf>,
    pub hsm_key_label: String,
    pub chain_bin_env: Vec<(String, String)>, // extra env pairs for tfd subprocesses
}

pub fn run(cfg: &RunConfig, signer: &dyn Signer) -> Result<()> {
    // 0) Create temp dir to house all temp files including HOME for tfd subprocesses
    let sandbox = make_tfd_sandbox_home().with_context(|| "make tfd sandbox HOME")?;
    let sandbox_path = sandbox.path();

    // 1) Read unsigned JSON
    let input_text = fs::read_to_string(&cfg.input_unsigned_json)
        .with_context(|| format!("read {:?}", cfg.input_unsigned_json))?;
    let mut root: JsonValue = serde_json::from_str(&input_text)
        .with_context(|| "parse input JSON")?;

    // 2) Inject signer_infos + signatures=[]
    info!("injecting signer info into unsigned tx");
    debug!("pubkey (hex): {}", cfg.pubkey_hex);
    let pk33 = parse_pubkey33_hex(&cfg.pubkey_hex)?;
    ensure_signer_info_in_json_in_place(&mut root, &pk33, cfg.sequence)
        .with_context(|| "inject signer_infos into unsigned tx JSON")?;

    // 3) Optional dump derived pre-sig
    if let Some(p) = &cfg.dump_pre_sig {
        if let Some(parent) = p.parent() {
            fs::create_dir_all(parent).ok();
        }
        fs::write(p, serde_json::to_vec_pretty(&root)?)
            .with_context(|| format!("write {p:?}"))?;
        info!("pre-sig tx JSON written to {p:?}");
    }

    // 4) Get canonical tx bytes base64
    let encoded_b64 = if let Some(p) = &cfg.encoded_tx_b64_in {
        fs::read_to_string(p).with_context(|| format!("read {p:?}"))?
    } else {
        info!("encoding tx using tfd tx encode");
        debug!("using tfd binary at {:?}", cfg.chain_bin);

        let tmp = write_temp_json(sandbox_path, &root).with_context(|| "write temp pre-sig json")?;
        run_tfd_tx_encode(&cfg.chain_bin, &tmp, sandbox_path, &cfg.chain_bin_env)
            .with_context(|| "tfd tx encode failed")?
    };
    let encoded_b64 = encoded_b64.trim().to_string();
    if encoded_b64.is_empty() {
        bail!("empty base64 from tfd tx encode");
    }

    // 5) Decode Tx protobuf
    let tx_bytes = b64_decode(&encoded_b64).with_context(|| "base64 decode encoded tx")?;
    let mut tx = Tx::decode(tx_bytes.as_slice()).with_context(|| "decode cosmos.tx.v1beta1.Tx")?;

    let body = tx.body.as_ref().ok_or_else(|| anyhow!("Tx.body missing"))?;
    let auth = tx
        .auth_info
        .as_ref()
        .ok_or_else(|| anyhow!("Tx.auth_info missing"))?;

    // 6) Build SignDoc and sign SHA256(SignDocBytes)
    info!("building SignDoc");
    let sign_doc = SignDoc {
        body_bytes: body.encode_to_vec(),
        auth_info_bytes: auth.encode_to_vec(),
        chain_id: cfg.chain_id.clone(),
        account_number: cfg.account_number,
    };
    let sign_doc_bytes = sign_doc.encode_to_vec();
    debug!("SignDoc bytes length: {}", sign_doc_bytes.len());

    // signing hook is responsible for sha256+ecdsa over that digest
    info!("signing SignDoc via HSM");
    let sig64 = signer
        .sign_rs64_sha256_signdoc(cfg, &sign_doc_bytes)
        .with_context(|| "signer failed")?;

    // 7) Write signature into Tx
    tx.signatures = vec![sig64.to_vec()];

    // 8) Write signed json and optional: write signed base64
    let signed_tx_bytes = tx.encode_to_vec();

    let signed_b64 = base64::engine::general_purpose::STANDARD.encode(&signed_tx_bytes);
    debug!("signed_b64 length: {}", signed_b64.len());

    if let Some(output_b64) = &cfg.output_b64 {
        if let Some(parent) = output_b64.parent() {
            fs::create_dir_all(parent).ok();
        }
        fs::write(output_b64, format!("{signed_b64}\n"))
            .with_context(|| format!("write {output_b64:?}"))?;

        info!("signed tx base64 written to {output_b64:?}");
    }

    // 9) Decode signed_b64 into json or Patch CLI-shaped JSON in-place with signature and write it
    //      this is the json for offline signature validation and also the final output JSON for broadcasting
    if let Some(parent) = cfg.output_json.parent() {
        fs::create_dir_all(parent).ok();
    }

    match run_tfd_tx_decode_json(&cfg.chain_bin, &signed_b64, sandbox_path, &cfg.chain_bin_env) {
        Ok(decoded_json_bytes) => {
            fs::write(&cfg.output_json, &decoded_json_bytes)
                .with_context(|| format!("write {:?}", &cfg.output_json))?;
            debug!("signed tx JSON generated via tfd tx decode");
        }
        Err(e) => {
            warn!("tfd tx decode failed, falling back to patching: {}", e);
            patch_signature_only_in_place(&mut root, &sig64)
                .with_context(|| "patch signatures into CLI JSON")?;

            fs::write(&cfg.output_json, serde_json::to_vec_pretty(&root)?)
                .with_context(|| format!("write {:?}", &cfg.output_json))?;
            debug!("signed tx JSON generated via patching");
        }
    }
    info!("signed tx JSON written to {:?}", cfg.output_json);

    // 10) offline signature validation
    run_tfd_validate_signatures(&cfg.chain_bin, &cfg.output_json, sandbox_path, &cfg.chain_bin_env)
        .with_context(|| "offline-check: validate-signatures failed")?;
    info!("offline-check: validate-signatures passed");

    // 11) Log the tx hash which is the same as that from broadcast
    let tx_hash = sha2::Sha256::digest(&signed_tx_bytes);
    info!("tx hash: {}", hex::encode_upper(tx_hash));

    Ok(())
}

pub fn parse_pubkey33_hex(pubkey_hex: &str) -> Result<[u8; 33]> {
    let bytes = hex::decode(pubkey_hex.trim_start_matches("0x"))
        .with_context(|| "pubkey_hex must be hex")?;
    let pk33: [u8; 33] = bytes
        .try_into()
        .map_err(|_| anyhow!("pubkey must be 33 bytes (compressed secp256k1)"))?;
    Ok(pk33)
}

/// Inject signer_infos[0] for SIGN_MODE_DIRECT into unsigned CLI tx JSON.
/// Preserves fee/tip fields as-is; forces signatures=[].
pub fn ensure_signer_info_in_json_in_place(
    root: &mut JsonValue,
    pubkey_compressed: &[u8; 33],
    sequence: u64,
) -> Result<()> {
    let b64 = base64::engine::general_purpose::STANDARD;

    let root_obj = root
        .as_object_mut()
        .ok_or_else(|| anyhow!("tx root must be object"))?;

    // signatures=[]
    match root_obj.get_mut("signatures") {
        Some(v) => *v = JsonValue::Array(vec![]),
        None => {
            root_obj.insert("signatures".to_string(), JsonValue::Array(vec![]));
        }
    }

    // auth_info required
    let auth_info = root_obj
        .get_mut("auth_info")
        .ok_or_else(|| anyhow!("missing auth_info"))?;
    let auth_obj = auth_info
        .as_object_mut()
        .ok_or_else(|| anyhow!("auth_info must be object"))?;

    let pk_b64 = b64.encode(pubkey_compressed);

    let signer_infos_val = JsonValue::Array(vec![serde_json::json!({
        "public_key": {
            "@type": "/cosmos.crypto.secp256k1.PubKey",
            "key": pk_b64
        },
        "mode_info": {
            "single": {
                "mode": "SIGN_MODE_DIRECT"
            }
        },
        "sequence": sequence.to_string()
    })]);

    match auth_obj.get_mut("signer_infos") {
        Some(v) => *v = signer_infos_val,
        None => {
            auth_obj.insert("signer_infos".to_string(), signer_infos_val);
        }
    }

    if !auth_obj.contains_key("tip") {
        auth_obj.insert("tip".to_string(), JsonValue::Null);
    }

    Ok(())
}

pub fn write_temp_json(dir: &Path, root: &JsonValue) -> Result<PathBuf> {
    let path = dir.join("txsigner_pre_sig.json");
    fs::write(&path, serde_json::to_vec_pretty(root)?)
        .with_context(|| format!("write temp {path:?}"))?;
    Ok(path)
}

fn make_tfd_sandbox_home() -> Result<TempDir> {
    tempfile::Builder::new()
        .prefix("txsigner_home_")
        .tempdir()
        .context("create temp HOME for tfd subprocesses")
}

fn tfd_cmd_min_env(tfd: &Path, home: &Path, extra_env: &[(String, String)]) -> Command {
    let mut cmd = Command::new(tfd);

    // Drop huge inherited container env (prevents E2BIG).
    cmd.env_clear();

    // Optional but commonly useful in minimal containers.
    // If you *know* you never need it, you can omit.
    // cmd.env("PATH", "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin");

    // tfd needs HOME to set its default home dir.
    cmd.env("HOME", home);

    // Add user-provided envs (e.g. LD_LIBRARY_PATH)
    for (k, v) in extra_env {
        cmd.env(k, v);
    }

    // let envs: Vec<(&OsStr, Option<&OsStr>)> = cmd.get_envs().collect();
    // debug!("tfd_cmd_min_env: HOME={:?}", envs[0]);

    // Make CLI deterministic: use --home.
    cmd.arg("--home").arg(home);

    cmd
}

pub fn run_tfd_tx_encode(tfd: &PathBuf, input: &PathBuf, home: &Path, extra_env: &[(String, String)]) -> Result<String> {
    let out = tfd_cmd_min_env(tfd, home, extra_env)
        .args(["tx", "encode"])
        .arg(input)
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .output()
        .with_context(|| format!("run {tfd:?} tx encode {input:?}"))?;

    if !out.status.success() {
        bail!(
            "tfd tx encode failed:\n{}\n{}",
            String::from_utf8_lossy(&out.stderr),
            String::from_utf8_lossy(&out.stdout),
        );
    }
    String::from_utf8(out.stdout).with_context(|| "tfd tx encode output not utf8")
}

fn patch_signature_only_in_place(root: &mut JsonValue, sig64: &[u8; 64]) -> Result<()> {
    use base64::Engine as _;
    let b64 = base64::engine::general_purpose::STANDARD;

    let root_obj = root
        .as_object_mut()
        .ok_or_else(|| anyhow!("tx root must be object"))?;

    let sig_b64 = b64.encode(sig64);

    // signatures: overwrite existing array if present (keeps key position)
    match root_obj.get_mut("signatures") {
        Some(v) => *v = JsonValue::Array(vec![JsonValue::String(sig_b64)]),
        None => {
            root_obj.insert(
                "signatures".to_string(),
                JsonValue::Array(vec![JsonValue::String(sig_b64)]),
            );
        }
    }

    Ok(())
}

pub fn run_tfd_tx_decode_json(tfd: &PathBuf, tx_b64: &str, home: &Path, extra_env: &[(String, String)]) -> Result<Vec<u8>> {
    let out = tfd_cmd_min_env(tfd, home, extra_env)
        .args(["tx", "decode"])
        .arg(tx_b64)
        .args(["--output", "json"])
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .output()
        .with_context(|| format!("run {tfd:?} tx decode --output json"))?;

    if !out.status.success() {
        bail!(
            "tfd tx decode failed:\n{}\n{}",
            String::from_utf8_lossy(&out.stderr),
            String::from_utf8_lossy(&out.stdout),
        );
    }
    Ok(out.stdout)
}

pub fn run_tfd_validate_signatures(tfd: &PathBuf, signed_json: &PathBuf, home: &Path, extra_env: &[(String, String)]) -> Result<()> {
    let out = tfd_cmd_min_env(tfd, home, extra_env)
        .args(["tx", "validate-signatures"])
        .arg(signed_json)
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .output()
        .with_context(|| format!("run {tfd:?} tx validate-signatures {signed_json:?}"))?;

    if !out.status.success() {
        bail!(
            "tfd tx validate-signatures failed:\n{}\n{}",
            String::from_utf8_lossy(&out.stderr),
            String::from_utf8_lossy(&out.stdout),
        );
    }
    Ok(())
}

pub fn b64_decode(s: &str) -> Result<Vec<u8>> {
    base64::engine::general_purpose::STANDARD
        .decode(s.trim())
        .map_err(|e| anyhow!("base64 decode: {e}"))
}

#[cfg(test)]
mod tests {
    use bip32::{DerivationPath, XPrv};
    use bip39::{Language, Mnemonic};
    use sha2::{Digest, Sha256};
    use super::*;
    use tempfile::TempDir;

    struct FakeSigner;
    struct SoftSigner;
    fn softsign_from_privkey_hex(privkey_hex: &str, sign_doc_bytes: &[u8]) -> Result<Vec<u8>> {
        use k256::ecdsa::{signature::hazmat::PrehashSigner, Signature, SigningKey};
        use sha2::{Digest, Sha256};

        let sk_bytes = hex::decode(privkey_hex.trim_start_matches("0x"))
            .with_context(|| "SOFTSIGN_PRIVKEY_HEX must be hex")?;
        if sk_bytes.len() != 32 {
            bail!("SOFTSIGN_PRIVKEY_HEX must be 32 bytes, got {}", sk_bytes.len());
        }
        let mut sk_arr = [0u8; 32];
        sk_arr.copy_from_slice(&sk_bytes);

        let digest = Sha256::digest(sign_doc_bytes);
        let signing_key = SigningKey::from_bytes((&sk_arr).into()).with_context(|| "invalid secp256k1 sk")?;

        let sig: Signature = signing_key
            .sign_prehash(&digest)
            .with_context(|| "softsign failed")?;

        // low-S normalize to match Cosmos behavior
        let sig = sig.normalize_s().unwrap_or(sig);

        Ok(sig.to_bytes().to_vec()) // 64 bytes r||s
    }

    fn derive_cosmos_privkey_32(mnemonic: &str) -> Result<[u8; 32]> {
        let mnemonic = Mnemonic::parse_in(Language::English, mnemonic)
            .with_context(|| "bad mnemonic")?;

        let seed = mnemonic.to_seed(""); // 64 bytes

        let path: DerivationPath = "m/44'/118'/0'/0/0".parse().unwrap();
        let xprv = XPrv::derive_from_path(&seed, &path)
            .with_context(|| "bip32 derive failed")?;

        Ok(<[u8; 32]>::from(xprv.private_key().to_bytes()))
    }

    /// Helper used by tests to build a minimal canonical Tx bytes (protobuf) and return base64.
    fn make_minimal_encoded_tx_b64() -> Result<String> {
        use cosmos_sdk_proto::cosmos::tx::v1beta1::{AuthInfo, Tx, TxBody};
        use prost::Message;

        let tx = Tx {
            body: Some(TxBody {
                messages: vec![],
                memo: "".to_string(),
                timeout_height: 0,
                extension_options: vec![],
                non_critical_extension_options: vec![],
                ..Default::default()
            }),
            auth_info: Some(AuthInfo {
                signer_infos: vec![],
                fee: None,
                ..Default::default()
            }),
            signatures: vec![],
        };

        let bytes = tx.encode_to_vec();
        Ok(base64::engine::general_purpose::STANDARD.encode(bytes))
    }

    impl Signer for FakeSigner {
        fn sign_rs64_sha256_signdoc(&self, _cfg: &RunConfig, sign_doc_bytes: &[u8]) -> Result<[u8; 64]> {
            // Deterministic: r||s = sha256(signdoc) repeated/truncated to 64 bytes.
            // (Not a real ECDSA signature — but good enough to test plumbing end-to-end
            // when validate-signatures is mocked.)
            let h = Sha256::digest(sign_doc_bytes);
            let mut out = [0u8; 64];
            out[..32].copy_from_slice(&h);
            out[32..].copy_from_slice(&h);
            Ok(out)
        }
    }

    impl Signer for SoftSigner {
        fn sign_rs64_sha256_signdoc(&self, _cfg: &RunConfig, sign_doc_bytes: &[u8]) -> Result<[u8; 64]> {
            // Deterministic mnemonic (fine for tests)
            let mnemonic = "abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon about";

            let sk32 = derive_cosmos_privkey_32(mnemonic)?;
            let privkey_hex = hex::encode(sk32);
            let sig_vec = softsign_from_privkey_hex(&privkey_hex, sign_doc_bytes)?;
            let sig_arr: [u8; 64] = sig_vec
                .as_slice()
                .try_into()
                .map_err(|_| anyhow!("softsign returned invalid signature length"))?;

            Ok(sig_arr)
        }
    }

    fn write_fake_tfd(tmp: &tempfile::TempDir, encoded_b64: &str) -> Result<PathBuf> {
        use anyhow::{Context};
        use std::fs;
        use std::path::PathBuf;

        let p = tmp.path().join("tfd_fake.sh");

        // Note: keep it POSIX-sh compatible (no bashisms).
        // Strips a leading "--home <dir>" if present, then expects "tx <subcmd> ..."
        let script = format!(
            r#"#!/bin/sh
set -eu

# Strip optional global flags we inject from txsigner (currently --home <dir>)
ARGS="$@"
# Rebuild positional args with --home stripped
set -- "$@"
if [ "$#" -ge 2 ] && [ "$1" = "--home" ]; then
  shift
  shift
fi

if [ "$#" -lt 2 ]; then
  echo "unexpected command" 1>&2
  exit 2
fi

if [ "$1" != "tx" ]; then
  echo "unexpected command" 1>&2
  exit 2
fi
shift

SUB="$1"
shift

case "$SUB" in
  encode)
    # prints encoded base64 to stdout
    echo "{encoded_b64}"
    ;;

  decode)
    # usage: tx decode <b64> --output json
    # We don't need to validate args; just print deterministic json that looks like tfd output.
    # (txsigner only needs *some* json bytes for output_json.)
    cat <<'JSON'
{{"body":{{"messages":[],"memo":"","timeout_height":"0","unordered":false,"timeout_timestamp":null,"extension_options":[],"non_critical_extension_options":[]}},"auth_info":{{"signer_infos":[],"fee":{{"amount":[],"gas_limit":"200000","payer":"","granter":""}},"tip":null}},"signatures":[]}}
JSON
    ;;

  validate-signatures)
    # Always succeed
    exit 0
    ;;

  *)
    echo "unexpected command" 1>&2
    exit 2
    ;;
esac
"#,
        );

        fs::write(&p, script).context("write fake tfd script")?;

        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            let mut perm = fs::metadata(&p)?.permissions();
            perm.set_mode(0o755);
            fs::set_permissions(&p, perm)?;
        }

        Ok(PathBuf::from(p))
    }

    #[test]
    fn test_parse_pubkey33_hex_ok() -> Result<()> {
        let pk = "02".to_string() + &"11".repeat(32);
        let pk33 = parse_pubkey33_hex(&pk)?;
        assert_eq!(pk33[0], 0x02);
        assert_eq!(pk33.len(), 33);
        Ok(())
    }

    #[test]
    fn test_parse_pubkey33_hex_bad_len() {
        let pk = "02".to_string() + &"11".repeat(31);
        let err = parse_pubkey33_hex(&pk).unwrap_err().to_string();
        assert!(err.contains("33 bytes"));
    }

    #[test]
    fn test_ensure_signer_info_in_json_in_place() -> Result<()> {
        let mut v: JsonValue = serde_json::json!({
          "body": { "messages": [], "memo": "", "timeout_height": "0", "unordered": false, "timeout_timestamp": null, "extension_options": [], "non_critical_extension_options": [] },
          "auth_info": { "signer_infos": [], "fee": { "amount": [], "gas_limit": "200000", "payer": "", "granter": "" }, "tip": null },
          "signatures": []
        });

        let pk33 = [2u8; 33];
        ensure_signer_info_in_json_in_place(&mut v, &pk33, 7)?;

        assert_eq!(v["signatures"].as_array().unwrap().len(), 0);
        assert_eq!(v["auth_info"]["signer_infos"].as_array().unwrap().len(), 1);
        assert_eq!(v["auth_info"]["signer_infos"][0]["sequence"], "7");
        assert_eq!(v["auth_info"]["signer_infos"][0]["mode_info"]["single"]["mode"], "SIGN_MODE_DIRECT");
        Ok(())
    }

    #[test]
    fn test_write_temp_json_creates_file() -> Result<()> {
        let sandbox = make_tfd_sandbox_home()?;
        let sandbox_path = sandbox.path();

        let v: JsonValue = serde_json::json!({"hello":"world"});
        let p = write_temp_json(sandbox_path, &v)?;
        assert!(p.exists());
        Ok(())
    }

    #[test]
    fn test_b64_decode_roundtrip() -> Result<()> {
        let s = base64::engine::general_purpose::STANDARD.encode(b"abc");
        let got = b64_decode(&s)?;
        assert_eq!(got, b"abc");
        Ok(())
    }

    #[test]
    #[serial_test::serial]
    fn test_run_end_to_end_with_fake_tfd_offline_check() -> Result<()> {
        let tmp = TempDir::new()?;

        // unsigned.json
        let unsigned = tmp.path().join("unsigned.json");
        fs::write(&unsigned, serde_json::to_vec_pretty(&serde_json::json!({
          "body": { "messages": [], "memo": "", "timeout_height": "0", "unordered": false, "timeout_timestamp": null, "extension_options": [], "non_critical_extension_options": [] },
          "auth_info": { "signer_infos": [], "fee": { "amount": [], "gas_limit": "200000", "payer": "", "granter": "" }, "tip": null },
          "signatures": []
        }))?)?;

        // fake tfd
        let encoded_b64 = make_minimal_encoded_tx_b64()?;
        let tfd = write_fake_tfd(&tmp, &encoded_b64)?;

        let out_b64 = tmp.path().join("signed.b64");
        let out_json = tmp.path().join("signed.json");
        let dump_pre = tmp.path().join("pre_sig.json");

        let cfg = RunConfig {
            input_unsigned_json: unsigned,
            chain_id: "tokenfactory-1".to_string(),
            account_number: 18,
            sequence: 2,
            pubkey_hex: "02".to_string() + &"11".repeat(32),
            output_b64: Some(out_b64.clone()),
            output_json: out_json.clone(),
            dump_pre_sig: Some(dump_pre.clone()),
            // offline_check: true,
            chain_bin: tfd,
            encoded_tx_b64_in: None,
            /*
            hsm_module: Default::default(),
            hsm_env_cfg: "".to_string(),
            hsm_cfg: Default::default(),
            hsm_token_label: "".to_string(),
            */
            hsm_key_label: "".to_string(),
            chain_bin_env: vec![],
        };

        run(&cfg, &FakeSigner)?;

        assert!(out_b64.exists());
        assert!(out_json.exists());
        assert!(dump_pre.exists());

        let signed_json_text = fs::read_to_string(&out_json)?;
        assert!(signed_json_text.contains("\"signatures\""));
        Ok(())
    }

    #[test]
    #[serial_test::serial]
    fn test_run_end_to_end_with_softsigner_fake_tfd_offline_check() -> Result<()> {
        let tmp = TempDir::new()?;

        // unsigned.json
        let unsigned = tmp.path().join("unsigned.json");
        fs::write(&unsigned, serde_json::to_vec_pretty(&serde_json::json!({
          "body": { "messages": [], "memo": "", "timeout_height": "0", "unordered": false, "timeout_timestamp": null, "extension_options": [], "non_critical_extension_options": [] },
          "auth_info": { "signer_infos": [], "fee": { "amount": [], "gas_limit": "200000", "payer": "", "granter": "" }, "tip": null },
          "signatures": []
        }))?)?;

        // fake tfd
        let encoded_b64 = make_minimal_encoded_tx_b64()?;
        let tfd = write_fake_tfd(&tmp, &encoded_b64)?;

        let out_b64 = tmp.path().join("signed.b64");
        let out_json = tmp.path().join("signed.json");
        let dump_pre = tmp.path().join("pre_sig.json");

        let cfg = RunConfig {
            input_unsigned_json: unsigned,
            chain_id: "tokenfactory-1".to_string(),
            account_number: 18,
            sequence: 2,
            pubkey_hex: "02".to_string() + &"11".repeat(32),
            output_b64: Some(out_b64.clone()),
            output_json: out_json.clone(),
            dump_pre_sig: Some(dump_pre.clone()),
            // offline_check: true,
            chain_bin: tfd,
            encoded_tx_b64_in: None,
            /*
            hsm_module: Default::default(),
            hsm_env_cfg: "".to_string(),
            hsm_cfg: Default::default(),
            hsm_token_label: "".to_string(),
            */
            hsm_key_label: "".to_string(),
            chain_bin_env: vec![],
        };

        run(&cfg, &SoftSigner)?;

        assert!(out_b64.exists());
        assert!(out_json.exists());
        assert!(dump_pre.exists());

        let signed_json_text = fs::read_to_string(&out_json)?;
        assert!(signed_json_text.contains("\"signatures\""));
        Ok(())
    }

    // Tests for lines 60-61: read input file error
    #[test]
    fn test_run_input_file_not_found() {
        let tmp = TempDir::new().unwrap();
        let cfg = RunConfig {
            input_unsigned_json: PathBuf::from("/nonexistent/file.json"),
            chain_id: "test-chain".to_string(),
            account_number: 1,
            sequence: 1,
            pubkey_hex: "02".to_string() + &"11".repeat(32),
            output_b64: None,
            output_json: tmp.path().join("out.json"),
            dump_pre_sig: None,
            chain_bin: PathBuf::from("tfd"),
            encoded_tx_b64_in: None,
            hsm_key_label: "test".to_string(),
            chain_bin_env: vec![],
        };

        let result = run(&cfg, &FakeSigner);
        assert!(result.is_err());
        let err = result.unwrap_err().to_string();
        assert!(err.contains("read") || err.contains("No such file"));
    }

    // Tests for line 72: parse input JSON error
    #[test]
    #[serial_test::serial]
    fn test_run_invalid_json_input() -> Result<()> {
        let tmp = TempDir::new()?;
        let unsigned = tmp.path().join("invalid.json");
        fs::write(&unsigned, "not valid json {")?;

        let cfg = RunConfig {
            input_unsigned_json: unsigned,
            chain_id: "test-chain".to_string(),
            account_number: 1,
            sequence: 1,
            pubkey_hex: "02".to_string() + &"11".repeat(32),
            output_b64: None,
            output_json: tmp.path().join("out.json"),
            dump_pre_sig: None,
            chain_bin: PathBuf::from("tfd"),
            encoded_tx_b64_in: None,
            hsm_key_label: "test".to_string(),
            chain_bin_env: vec![],
        };

        let result = run(&cfg, &FakeSigner);
        assert!(result.is_err());
        let err = result.unwrap_err().to_string();
        assert!(err.contains("parse input JSON"));
        Ok(())
    }

    // Tests for line 78: ensure_signer_info error
    #[test]
    #[serial_test::serial]
    fn test_run_signer_info_injection_fails() -> Result<()> {
        let tmp = TempDir::new()?;
        let unsigned = tmp.path().join("bad_structure.json");
        // Missing auth_info will trigger error in ensure_signer_info_in_json_in_place
        fs::write(&unsigned, serde_json::to_vec_pretty(&serde_json::json!({
          "body": {},
          "signatures": []
        }))?)?;

        let cfg = RunConfig {
            input_unsigned_json: unsigned,
            chain_id: "test-chain".to_string(),
            account_number: 1,
            sequence: 1,
            pubkey_hex: "02".to_string() + &"11".repeat(32),
            output_b64: None,
            output_json: tmp.path().join("out.json"),
            dump_pre_sig: None,
            chain_bin: PathBuf::from("tfd"),
            encoded_tx_b64_in: None,
            hsm_key_label: "test".to_string(),
            chain_bin_env: vec![],
        };

        let result = run(&cfg, &FakeSigner);
        assert!(result.is_err());
        let err = result.unwrap_err().to_string();
        assert!(err.contains("inject signer_infos") || err.contains("missing auth_info"));
        Ok(())
    }

    // Tests for lines 90, 101: dump_pre_sig write error
    #[test]
    #[serial_test::serial]
    fn test_run_dump_pre_sig_write_error() -> Result<()> {
        let tmp = TempDir::new()?;
        let unsigned = tmp.path().join("unsigned.json");
        fs::write(&unsigned, serde_json::to_vec_pretty(&serde_json::json!({
          "body": { "messages": [] },
          "auth_info": { "signer_infos": [], "fee": { "gas_limit": "200000" } },
          "signatures": []
        }))?)?;

        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;

            // Create a read-only directory
            let readonly_dir = tmp.path().join("readonly");
            fs::create_dir(&readonly_dir)?;
            let mut perms = fs::metadata(&readonly_dir)?.permissions();
            perms.set_mode(0o444);
            fs::set_permissions(&readonly_dir, perms)?;

            let cfg = RunConfig {
                input_unsigned_json: unsigned,
                chain_id: "test-chain".to_string(),
                account_number: 1,
                sequence: 1,
                pubkey_hex: "02".to_string() + &"11".repeat(32),
                output_b64: None,
                output_json: tmp.path().join("out.json"),
                dump_pre_sig: Some(readonly_dir.join("presig.json")),
                chain_bin: PathBuf::from("tfd"),
                encoded_tx_b64_in: None,
                hsm_key_label: "test".to_string(),
                chain_bin_env: vec![],
            };

            let result = run(&cfg, &FakeSigner);

            // Clean up permissions
            let mut perms = fs::metadata(&readonly_dir)?.permissions();
            perms.set_mode(0o755);
            fs::set_permissions(&readonly_dir, perms)?;

            assert!(result.is_err());
        }
        Ok(())
    }

    // Tests for line 104: encoded_tx_b64_in read error
    #[test]
    fn test_run_encoded_tx_b64_in_not_found() {
        let tmp = TempDir::new().unwrap();
        let unsigned = tmp.path().join("unsigned.json");
        fs::write(&unsigned, serde_json::to_vec_pretty(&serde_json::json!({
          "body": { "messages": [] },
          "auth_info": { "signer_infos": [], "fee": { "gas_limit": "200000" } },
          "signatures": []
        })).unwrap()).unwrap();

        let cfg = RunConfig {
            input_unsigned_json: unsigned,
            chain_id: "test-chain".to_string(),
            account_number: 1,
            sequence: 1,
            pubkey_hex: "02".to_string() + &"11".repeat(32),
            output_b64: None,
            output_json: tmp.path().join("out.json"),
            dump_pre_sig: None,
            chain_bin: PathBuf::from("tfd"),
            encoded_tx_b64_in: Some(PathBuf::from("/nonexistent/encoded.b64")),
            hsm_key_label: "test".to_string(),
            chain_bin_env: vec![],
        };

        let result = run(&cfg, &FakeSigner);
        assert!(result.is_err());
        let err = result.unwrap_err().to_string();
        assert!(err.contains("read") || err.contains("No such file"));
    }

    // Tests for lines 112, 115: tfd tx encode errors
    #[test]
    #[serial_test::serial]
    fn test_run_tfd_encode_fails() -> Result<()> {
        let tmp = TempDir::new()?;
        let unsigned = tmp.path().join("unsigned.json");
        fs::write(&unsigned, serde_json::to_vec_pretty(&serde_json::json!({
          "body": { "messages": [] },
          "auth_info": { "signer_infos": [], "fee": { "gas_limit": "200000" } },
          "signatures": []
        }))?)?;

        // Create a fake tfd that always fails
        let tfd = tmp.path().join("bad_tfd");
        fs::write(&tfd, "#!/bin/sh\nexit 1\n")?;
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            let mut perms = fs::metadata(&tfd)?.permissions();
            perms.set_mode(0o755);
            fs::set_permissions(&tfd, perms)?;
        }

        let cfg = RunConfig {
            input_unsigned_json: unsigned,
            chain_id: "test-chain".to_string(),
            account_number: 1,
            sequence: 1,
            pubkey_hex: "02".to_string() + &"11".repeat(32),
            output_b64: None,
            output_json: tmp.path().join("out.json"),
            dump_pre_sig: None,
            chain_bin: tfd,
            encoded_tx_b64_in: None,
            hsm_key_label: "test".to_string(),
            chain_bin_env: vec![],
        };

        let result = run(&cfg, &FakeSigner);
        assert!(result.is_err());
        Ok(())
    }

    // Tests for line 132: empty base64 error
    #[test]
    #[serial_test::serial]
    fn test_run_empty_base64_from_encode() -> Result<()> {
        let tmp = TempDir::new()?;
        let unsigned = tmp.path().join("unsigned.json");
        fs::write(&unsigned, serde_json::to_vec_pretty(&serde_json::json!({
          "body": { "messages": [] },
          "auth_info": { "signer_infos": [], "fee": { "gas_limit": "200000" } },
          "signatures": []
        }))?)?;

        // Create fake tfd that outputs empty string
        let tfd = tmp.path().join("empty_tfd");
        fs::write(&tfd, "#!/bin/sh\nif [ \"$1\" = \"tx\" ] && [ \"$2\" = \"encode\" ]; then echo ''; exit 0; fi\n")?;
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            let mut perms = fs::metadata(&tfd)?.permissions();
            perms.set_mode(0o755);
            fs::set_permissions(&tfd, perms)?;
        }

        let cfg = RunConfig {
            input_unsigned_json: unsigned,
            chain_id: "test-chain".to_string(),
            account_number: 1,
            sequence: 1,
            pubkey_hex: "02".to_string() + &"11".repeat(32),
            output_b64: None,
            output_json: tmp.path().join("out.json"),
            dump_pre_sig: None,
            chain_bin: tfd,
            encoded_tx_b64_in: None,
            hsm_key_label: "test".to_string(),
            chain_bin_env: vec![],
        };

        let result = run(&cfg, &FakeSigner);
        assert!(result.is_err());
        let err = result.unwrap_err().to_string();
        assert!(err.contains("empty base64"));
        Ok(())
    }

    // Tests for line 142: base64 decode error
    #[test]
    #[serial_test::serial]
    fn test_run_invalid_base64() -> Result<()> {
        let tmp = TempDir::new()?;
        let encoded_file = tmp.path().join("encoded.b64");
        fs::write(&encoded_file, "not-valid-base64!!!")?;

        let unsigned = tmp.path().join("unsigned.json");
        fs::write(&unsigned, serde_json::to_vec_pretty(&serde_json::json!({
          "body": { "messages": [] },
          "auth_info": { "signer_infos": [], "fee": { "gas_limit": "200000" } },
          "signatures": []
        }))?)?;

        let cfg = RunConfig {
            input_unsigned_json: unsigned,
            chain_id: "test-chain".to_string(),
            account_number: 1,
            sequence: 1,
            pubkey_hex: "02".to_string() + &"11".repeat(32),
            output_b64: None,
            output_json: tmp.path().join("out.json"),
            dump_pre_sig: None,
            chain_bin: PathBuf::from("tfd"),
            encoded_tx_b64_in: Some(encoded_file),
            hsm_key_label: "test".to_string(),
            chain_bin_env: vec![],
        };

        let result = run(&cfg, &FakeSigner);
        assert!(result.is_err());
        let err = result.unwrap_err().to_string();
        assert!(err.contains("base64 decode"));
        Ok(())
    }

    // this test fails.
    // Tests for lines 178-179: Tx.body missing
    //#[test]
    //#[serial_test::serial]
    fn _test_run_tx_body_missing() -> Result<()> {
        use cosmos_sdk_proto::cosmos::tx::v1beta1::Tx;

        let tmp = TempDir::new()?;
        let unsigned = tmp.path().join("unsigned.json");
        fs::write(&unsigned, serde_json::to_vec_pretty(&serde_json::json!({
          "body": { "messages": [] },
          "auth_info": { "signer_infos": [], "fee": { "gas_limit": "200000" } },
          "signatures": []
        }))?)?;

        // Create Tx without body
        let tx = Tx {
            body: None,
            auth_info: None,
            signatures: vec![],
        };
        let tx_bytes = tx.encode_to_vec();
        let tx_b64 = base64::engine::general_purpose::STANDARD.encode(tx_bytes);

        let encoded_file = tmp.path().join("encoded.b64");
        fs::write(&encoded_file, tx_b64)?;

        let cfg = RunConfig {
            input_unsigned_json: unsigned,
            chain_id: "test-chain".to_string(),
            account_number: 1,
            sequence: 1,
            pubkey_hex: "02".to_string() + &"11".repeat(32),
            output_b64: None,
            output_json: tmp.path().join("out.json"),
            dump_pre_sig: None,
            chain_bin: PathBuf::from("tfd"),
            encoded_tx_b64_in: Some(encoded_file),
            hsm_key_label: "test".to_string(),
            chain_bin_env: vec![],
        };

        let result = run(&cfg, &FakeSigner);
        assert!(result.is_err());
        let err = result.unwrap_err().to_string();
        assert!(err.contains("Tx.body missing"));
        Ok(())
    }

    // Tests for lines 186, 189: Tx.auth_info missing
    #[test]
    #[serial_test::serial]
    fn test_run_tx_auth_info_missing() -> Result<()> {
        use cosmos_sdk_proto::cosmos::tx::v1beta1::{Tx, TxBody};

        let tmp = TempDir::new()?;
        let unsigned = tmp.path().join("unsigned.json");
        fs::write(&unsigned, serde_json::to_vec_pretty(&serde_json::json!({
          "body": { "messages": [] },
          "auth_info": { "signer_infos": [], "fee": { "gas_limit": "200000" } },
          "signatures": []
        }))?)?;

        // Create Tx with body but without auth_info
        let tx = Tx {
            body: Some(TxBody::default()),
            auth_info: None,
            signatures: vec![],
        };
        let tx_bytes = tx.encode_to_vec();
        let tx_b64 = base64::engine::general_purpose::STANDARD.encode(tx_bytes);

        let encoded_file = tmp.path().join("encoded.b64");
        fs::write(&encoded_file, tx_b64)?;

        let cfg = RunConfig {
            input_unsigned_json: unsigned,
            chain_id: "test-chain".to_string(),
            account_number: 1,
            sequence: 1,
            pubkey_hex: "02".to_string() + &"11".repeat(32),
            output_b64: None,
            output_json: tmp.path().join("out.json"),
            dump_pre_sig: None,
            chain_bin: PathBuf::from("tfd"),
            encoded_tx_b64_in: Some(encoded_file),
            hsm_key_label: "test".to_string(),
            chain_bin_env: vec![],
        };

        let result = run(&cfg, &FakeSigner);
        assert!(result.is_err());
        let err = result.unwrap_err().to_string();
        assert!(err.contains("Tx.auth_info missing"));
        Ok(())
    }

    // Tests for lines 208-209: signer error
    #[test]
    #[serial_test::serial]
    fn test_run_signer_fails() -> Result<()> {
        struct FailingSigner;
        impl Signer for FailingSigner {
            fn sign_rs64_sha256_signdoc(&self, _cfg: &RunConfig, _sign_doc_bytes: &[u8]) -> Result<[u8; 64]> {
                bail!("signer intentionally failed");
            }
        }

        let tmp = TempDir::new()?;
        let unsigned = tmp.path().join("unsigned.json");
        fs::write(&unsigned, serde_json::to_vec_pretty(&serde_json::json!({
          "body": { "messages": [] },
          "auth_info": { "signer_infos": [], "fee": { "gas_limit": "200000" } },
          "signatures": []
        }))?)?;

        let encoded_b64 = make_minimal_encoded_tx_b64()?;
        let tfd = write_fake_tfd(&tmp, &encoded_b64)?;

        let cfg = RunConfig {
            input_unsigned_json: unsigned,
            chain_id: "test-chain".to_string(),
            account_number: 1,
            sequence: 1,
            pubkey_hex: "02".to_string() + &"11".repeat(32),
            output_b64: None,
            output_json: tmp.path().join("out.json"),
            dump_pre_sig: None,
            chain_bin: tfd,
            encoded_tx_b64_in: None,
            hsm_key_label: "test".to_string(),
            chain_bin_env: vec![],
        };

        let result = run(&cfg, &FailingSigner);
        assert!(result.is_err());
        let err = result.unwrap_err().to_string();
        assert!(err.contains("signer failed") || err.contains("signer intentionally failed"));
        Ok(())
    }

    // Tests for lines 213-214, 228: output_b64 write error
    #[test]
    #[serial_test::serial]
    fn test_run_output_b64_write_error() -> Result<()> {
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;

            let tmp = TempDir::new()?;
            let unsigned = tmp.path().join("unsigned.json");
            fs::write(&unsigned, serde_json::to_vec_pretty(&serde_json::json!({
              "body": { "messages": [] },
              "auth_info": { "signer_infos": [], "fee": { "gas_limit": "200000" } },
              "signatures": []
            }))?)?;

            let encoded_b64 = make_minimal_encoded_tx_b64()?;
            let tfd = write_fake_tfd(&tmp, &encoded_b64)?;

            // Create read-only directory
            let readonly_dir = tmp.path().join("readonly");
            fs::create_dir(&readonly_dir)?;
            let mut perms = fs::metadata(&readonly_dir)?.permissions();
            perms.set_mode(0o444);
            fs::set_permissions(&readonly_dir, perms)?;

            let cfg = RunConfig {
                input_unsigned_json: unsigned,
                chain_id: "test-chain".to_string(),
                account_number: 1,
                sequence: 1,
                pubkey_hex: "02".to_string() + &"11".repeat(32),
                output_b64: Some(readonly_dir.join("signed.b64")),
                output_json: tmp.path().join("signed.json"),
                dump_pre_sig: None,
                chain_bin: tfd,
                encoded_tx_b64_in: None,
                hsm_key_label: "test".to_string(),
                chain_bin_env: vec![],
            };

            let result = run(&cfg, &FakeSigner);

            // Clean up
            let mut perms = fs::metadata(&readonly_dir)?.permissions();
            perms.set_mode(0o755);
            fs::set_permissions(&readonly_dir, perms)?;

            assert!(result.is_err());
        }
        Ok(())
    }

    // Tests for line 240: tfd tx decode error
    #[test]
    #[serial_test::serial]
    fn test_run_tfd_decode_fails() -> Result<()> {
        let tmp = TempDir::new()?;
        let unsigned = tmp.path().join("unsigned.json");
        fs::write(&unsigned, serde_json::to_vec_pretty(&serde_json::json!({
          "body": { "messages": [] },
          "auth_info": { "signer_infos": [], "fee": { "gas_limit": "200000" } },
          "signatures": []
        }))?)?;

        // Create fake tfd that fails on decode
        let tfd = tmp.path().join("decode_fail_tfd");
        let script = r#"#!/bin/sh
if [ "$1" = "tx" ] && [ "$2" = "encode" ]; then
  echo "Cg0KCwoJdGVzdF90eHR4"
  exit 0
elif [ "$1" = "tx" ] && [ "$2" = "decode" ]; then
  exit 1
fi
exit 2
"#;
        fs::write(&tfd, script)?;
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            let mut perms = fs::metadata(&tfd)?.permissions();
            perms.set_mode(0o755);
            fs::set_permissions(&tfd, perms)?;
        }

        let cfg = RunConfig {
            input_unsigned_json: unsigned,
            chain_id: "test-chain".to_string(),
            account_number: 1,
            sequence: 1,
            pubkey_hex: "02".to_string() + &"11".repeat(32),
            output_b64: None,
            output_json: tmp.path().join("out.json"),
            dump_pre_sig: None,
            chain_bin: tfd,
            encoded_tx_b64_in: None,
            hsm_key_label: "test".to_string(),
            chain_bin_env: vec![],
        };

        let result = run(&cfg, &FakeSigner);
        assert!(result.is_err());
        Ok(())
    }

    // Tests for line 258: validate-signatures error
    #[test]
    #[serial_test::serial]
    fn test_run_validate_signatures_fails() -> Result<()> {
        let tmp = TempDir::new()?;
        let unsigned = tmp.path().join("unsigned.json");
        fs::write(&unsigned, serde_json::to_vec_pretty(&serde_json::json!({
          "body": { "messages": [] },
          "auth_info": { "signer_infos": [], "fee": { "gas_limit": "200000" } },
          "signatures": []
        }))?)?;

        // Create fake tfd that fails validation
        let tfd = tmp.path().join("validate_fail_tfd");
        let script = format!(r#"#!/bin/sh
set -eu

# strip optional --home <dir>
if [ "$#" -ge 2 ] && [ "$1" = "--home" ]; then
  shift
  shift
fi

if [ "$1" = "tx" ] && [ "$2" = "encode" ]; then
  cat "$3" > /dev/null
  echo "{}"
  exit 0
elif [ "$1" = "tx" ] && [ "$2" = "decode" ]; then
  echo '{{"body":{{"messages":[]}},"auth_info":{{"signer_infos":[]}},"signatures":["AAAA"]}}'
  exit 0
elif [ "$1" = "tx" ] && [ "$2" = "validate-signatures" ]; then
  exit 1
fi
exit 2
"#, make_minimal_encoded_tx_b64()?);

        fs::write(&tfd, script)?;
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            let mut perms = fs::metadata(&tfd)?.permissions();
            perms.set_mode(0o755);
            fs::set_permissions(&tfd, perms)?;
        }

        let cfg = RunConfig {
            input_unsigned_json: unsigned,
            chain_id: "test-chain".to_string(),
            account_number: 1,
            sequence: 1,
            pubkey_hex: "02".to_string() + &"11".repeat(32),
            output_b64: None,
            output_json: tmp.path().join("out.json"),
            dump_pre_sig: None,
            chain_bin: tfd,
            encoded_tx_b64_in: None,
            hsm_key_label: "test".to_string(),
            chain_bin_env: vec![],
        };

        let result = run(&cfg, &FakeSigner);
        assert!(result.is_err());
        let err = result.unwrap_err().to_string();
        assert!(err.contains("offline-check: validate-signatures failed"), "{}", "got error: {err}");
        Ok(())
    }

    // Tests for line 275: pubkey hex decode error
    #[test]
    fn test_parse_pubkey33_hex_invalid_hex() {
        let result = parse_pubkey33_hex("not-hex-string");
        assert!(result.is_err());
        let err = result.unwrap_err().to_string();
        assert!(err.contains("pubkey_hex must be hex"));
    }

    // Additional test for ensure_signer_info - root not object (line 289)
    #[test]
    fn test_ensure_signer_info_root_not_object() {
        let mut v: JsonValue = serde_json::json!([]);
        let pk33 = [2u8; 33];
        let result = ensure_signer_info_in_json_in_place(&mut v, &pk33, 1);
        assert!(result.is_err());
        let err = result.unwrap_err().to_string();
        assert!(err.contains("tx root must be object"));
    }

    // Test for ensure_signer_info - auth_info not object (line 312)
    #[test]
    fn test_ensure_signer_info_auth_info_not_object() {
        let mut v: JsonValue = serde_json::json!({
            "auth_info": "not an object",
            "signatures": []
        });
        let pk33 = [2u8; 33];
        let result = ensure_signer_info_in_json_in_place(&mut v, &pk33, 1);
        assert!(result.is_err());
        let err = result.unwrap_err().to_string();
        assert!(err.contains("auth_info must be object"));
    }

    #[test]
    #[serial_test::serial]
    fn test_run_calls_signer_trait_and_writes_dump_pre_sig() -> Result<()> {
        use std::sync::atomic::{AtomicUsize, Ordering};

        struct CountingSigner;
        static CALLS: AtomicUsize = AtomicUsize::new(0);

        impl Signer for CountingSigner {
            fn sign_rs64_sha256_signdoc(&self, _cfg: &RunConfig, _sign_doc_bytes: &[u8]) -> Result<[u8; 64]> {
                CALLS.fetch_add(1, Ordering::SeqCst);
                Ok([7u8; 64])
            }
        }

        let tmp = TempDir::new()?;

        // unsigned.json with enough structure for signer_infos injection
        let unsigned = tmp.path().join("unsigned.json");
        fs::write(
            &unsigned,
            serde_json::to_vec_pretty(&serde_json::json!({
            "body": { "messages": [], "memo": "" },
            "auth_info": {
                "signer_infos": [],
                "fee": { "amount": [], "gas_limit": "200000", "payer": "", "granter": "" }
            },
            "signatures": []
        }))?,
        )?;

        // fake tfd that supports encode/decode/validate
        let encoded_b64 = make_minimal_encoded_tx_b64()?;
        let tfd = write_fake_tfd(&tmp, &encoded_b64)?;

        // dump_pre_sig with a parent dir that doesn't exist yet (covers parent create + write + log path)
        let dump_dir = tmp.path().join("nested").join("dir");
        let dump_pre = dump_dir.join("pre_sig.json");

        let out_b64 = tmp.path().join("signed.b64");
        let out_json = tmp.path().join("signed.json");

        let cfg = RunConfig {
            input_unsigned_json: unsigned,
            chain_id: "test-chain".to_string(),
            account_number: 1,
            sequence: 9,
            pubkey_hex: "02".to_string() + &"11".repeat(32),
            output_b64: Some(out_b64.clone()),
            output_json: out_json.clone(),
            dump_pre_sig: Some(dump_pre.clone()),
            chain_bin: tfd,
            encoded_tx_b64_in: None,
            hsm_key_label: "test".to_string(),
            chain_bin_env: vec![],
        };

        run(&cfg, &CountingSigner)?;

        assert_eq!(CALLS.load(Ordering::SeqCst), 1, "signer must be called exactly once");
        assert!(dump_pre.exists(), "dump_pre_sig file should be written");
        assert!(out_b64.exists(), "output_b64 should be written");
        assert!(out_json.exists(), "output_json should be written");
        Ok(())
    }

    #[test]
    #[serial_test::serial]
    fn test_run_encoded_tx_b64_in_trim_and_empty_rejected() -> Result<()> {
        let tmp = TempDir::new()?;

        let unsigned = tmp.path().join("unsigned.json");
        fs::write(
            &unsigned,
            serde_json::to_vec_pretty(&serde_json::json!({
            "body": { "messages": [], "memo": "" },
            "auth_info": {
                "signer_infos": [],
                "fee": { "amount": [], "gas_limit": "200000", "payer": "", "granter": "" }
            },
            "signatures": []
        }))?,
        )?;

        // Provide encoded_tx_b64_in which is only whitespace; trim() => empty => bail
        let encoded_in = tmp.path().join("encoded.b64");
        fs::write(&encoded_in, "   \n\t  ")?;

        // `chain_bin` is unused when `encoded_tx_b64_in` is present, but must exist as a path; reuse a working fake tfd.
        let encoded_b64 = make_minimal_encoded_tx_b64()?;
        let tfd = write_fake_tfd(&tmp, &encoded_b64)?;

        struct OkSigner;
        impl Signer for OkSigner {
            fn sign_rs64_sha256_signdoc(&self, _cfg: &RunConfig, _sign_doc_bytes: &[u8]) -> Result<[u8; 64]> {
                Ok([0u8; 64])
            }
        }

        let cfg = RunConfig {
            input_unsigned_json: unsigned,
            chain_id: "test-chain".to_string(),
            account_number: 1,
            sequence: 1,
            pubkey_hex: "02".to_string() + &"11".repeat(32),
            output_b64: None,
            output_json: tmp.path().join("out.json"),
            dump_pre_sig: None,
            chain_bin: tfd,
            encoded_tx_b64_in: Some(encoded_in),
            hsm_key_label: "test".to_string(),
            chain_bin_env: vec![],
        };

        let err = run(&cfg, &OkSigner).unwrap_err().to_string();
        assert!(err.contains("empty base64"), "expected empty base64 error, got: {err}", err = err);
        Ok(())
    }

    #[test]
    #[serial_test::serial]
    fn test_run_decode_tx_protobuf_fails() -> Result<()> {
        let tmp = TempDir::new()?;

        let unsigned = tmp.path().join("unsigned.json");
        fs::write(
            &unsigned,
            serde_json::to_vec_pretty(&serde_json::json!({
            "body": { "messages": [], "memo": "" },
            "auth_info": {
                "signer_infos": [],
                "fee": { "amount": [], "gas_limit": "200000", "payer": "", "granter": "" }
            },
            "signatures": []
        }))?,
        )?;

        // base64 that decodes to bytes that are not a valid Tx protobuf
        let not_a_tx_bytes = vec![0xde, 0xad, 0xbe, 0xef];
        let bad_tx_b64 = base64::engine::general_purpose::STANDARD.encode(not_a_tx_bytes);
        let encoded_in = tmp.path().join("encoded.b64");
        fs::write(&encoded_in, format!("{bad_tx_b64}\n"))?;

        // `chain_bin` not used with encoded_tx_b64_in, but set to something plausible
        let encoded_b64 = make_minimal_encoded_tx_b64()?;
        let tfd = write_fake_tfd(&tmp, &encoded_b64)?;

        struct OkSigner;
        impl Signer for OkSigner {
            fn sign_rs64_sha256_signdoc(&self, _cfg: &RunConfig, _sign_doc_bytes: &[u8]) -> Result<[u8; 64]> {
                Ok([0u8; 64])
            }
        }

        let cfg = RunConfig {
            input_unsigned_json: unsigned,
            chain_id: "test-chain".to_string(),
            account_number: 1,
            sequence: 1,
            pubkey_hex: "02".to_string() + &"11".repeat(32),
            output_b64: None,
            output_json: tmp.path().join("out.json"),
            dump_pre_sig: None,
            chain_bin: tfd,
            encoded_tx_b64_in: Some(encoded_in),
            hsm_key_label: "test".to_string(),
            chain_bin_env: vec![],
        };

        let err = run(&cfg, &OkSigner).unwrap_err().to_string();
        assert!(err.contains("decode cosmos.tx.v1beta1.Tx"), "expected Tx decode error, got: {err}", err = err);
        Ok(())
    }

    #[test]
    #[serial_test::serial]
    fn test_run_tx_body_missing_hits_expected_error() -> Result<()> {
        use cosmos_sdk_proto::cosmos::tx::v1beta1::Tx;

        let tmp = TempDir::new()?;

        let unsigned = tmp.path().join("unsigned.json");
        fs::write(
            &unsigned,
            serde_json::to_vec_pretty(&serde_json::json!({
            "body": { "messages": [], "memo": "" },
            "auth_info": {
                "signer_infos": [],
                "fee": { "amount": [], "gas_limit": "200000", "payer": "", "granter": "" }
            },
            "signatures": []
        }))?,
        )?;

        // Tx without body, but with auth_info to pass the next check
        let tx = Tx {
            body: None,
            auth_info: Some(Default::default()),
            signatures: vec![],
        };
        let tx_b64 = base64::engine::general_purpose::STANDARD.encode(tx.encode_to_vec());

        let encoded_in = tmp.path().join("encoded.b64");
        fs::write(&encoded_in, format!("{tx_b64}\n"))?;

        let encoded_b64 = make_minimal_encoded_tx_b64()?;
        let tfd = write_fake_tfd(&tmp, &encoded_b64)?;

        struct OkSigner;
        impl Signer for OkSigner {
            fn sign_rs64_sha256_signdoc(&self, _cfg: &RunConfig, _sign_doc_bytes: &[u8]) -> Result<[u8; 64]> {
                Ok([0u8; 64])
            }
        }

        let cfg = RunConfig {
            input_unsigned_json: unsigned,
            chain_id: "test-chain".to_string(),
            account_number: 1,
            sequence: 1,
            pubkey_hex: "02".to_string() + &"11".repeat(32),
            output_b64: None,
            output_json: tmp.path().join("out.json"),
            dump_pre_sig: None,
            chain_bin: tfd,
            encoded_tx_b64_in: Some(encoded_in),
            hsm_key_label: "test".to_string(),
            chain_bin_env: vec![],
        };

        let err = run(&cfg, &OkSigner).unwrap_err().to_string();
        assert!(err.contains("Tx.body missing"), "expected body missing, got: {err}", err = err);
        Ok(())
    }

    #[test]
    #[serial_test::serial]
    fn test_run_tfd_offline_signature_validation_error_is_reported() -> Result<()> {
        let tmp = TempDir::new()?;

        let unsigned = tmp.path().join("unsigned.json");
        fs::write(
            &unsigned,
            serde_json::to_vec_pretty(&serde_json::json!({
            "body": { "messages": [], "memo": "" },
            "auth_info": {
                "signer_infos": [],
                "fee": { "amount": [], "gas_limit": "200000", "payer": "", "granter": "" }
            },
            "signatures": []
        }))?,
        )?;

        // fake tfd: encode ok, decode fails (covers decode error path around run_tfd_tx_decode_json)
        let tfd = tmp.path().join("decode_fail_tfd");
        let encoded_b64 = make_minimal_encoded_tx_b64()?;
        let script = format!(
            r#"#!/bin/sh
set -eu

# strip optional --home <dir>
if [ "$#" -ge 2 ] && [ "$1" = "--home" ]; then
  shift
  shift
fi

if [ "$#" -ge 2 ] && [ "$1" = "tx" ] && [ "$2" = "encode" ]; then
  cat "$3" > /dev/null
  echo "{encoded_b64}"
  exit 0
elif [ "$#" -ge 2 ] && [ "$1" = "tx" ] && [ "$2" = "decode" ]; then
  exit 1
fi
exit 2
"#
        );

        fs::write(&tfd, script)?;
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            let mut perms = fs::metadata(&tfd)?.permissions();
            perms.set_mode(0o755);
            fs::set_permissions(&tfd, perms)?;
        }

        struct OkSigner;
        impl Signer for OkSigner {
            fn sign_rs64_sha256_signdoc(&self, _cfg: &RunConfig, _sign_doc_bytes: &[u8]) -> Result<[u8; 64]> {
                Ok([0u8; 64])
            }
        }

        let cfg = RunConfig {
            input_unsigned_json: unsigned,
            chain_id: "test-chain".to_string(),
            account_number: 1,
            sequence: 1,
            pubkey_hex: "02".to_string() + &"11".repeat(32),
            output_b64: None,
            output_json: tmp.path().join("out.json"),
            dump_pre_sig: None,
            chain_bin: tfd,
            encoded_tx_b64_in: None,
            hsm_key_label: "test".to_string(),
            chain_bin_env: vec![],
        };

        let err = run(&cfg, &OkSigner).unwrap_err().to_string();
        assert!(err.contains("offline-check"), "expected validate-signatures failed, got: {err}", err = err);
        Ok(())
    }

}

#[cfg(test)]
mod tests_1 {
    use super::*;
    use anyhow::Result;
    use prost::Message;
    use tempfile::TempDir;

    fn mk_min_unsigned_json() -> JsonValue {
        // Minimal CLI-shaped tx with required top-level structure.
        serde_json::json!({
          "body": { "messages": [], "memo": "", "timeout_height": "0", "unordered": false,
                    "timeout_timestamp": null, "extension_options": [], "non_critical_extension_options": [] },
          "auth_info": { "signer_infos": [], "fee": { "amount": [], "gas_limit": "200000", "payer": "", "granter": "" }, "tip": null },
          "signatures": []
        })
    }

    fn make_minimal_encoded_tx_b64() -> Result<String> {
        use cosmos_sdk_proto::cosmos::tx::v1beta1::{AuthInfo, Tx, TxBody};
        use prost::Message;

        let tx = Tx {
            body: Some(TxBody {
                messages: vec![],
                memo: "".to_string(),
                timeout_height: 0,
                extension_options: vec![],
                non_critical_extension_options: vec![],
                ..Default::default()
            }),
            auth_info: Some(AuthInfo {
                signer_infos: vec![],
                fee: None,
                ..Default::default()
            }),
            signatures: vec![],
        };

        let bytes = tx.encode_to_vec();
        Ok(base64::engine::general_purpose::STANDARD.encode(bytes))
    }
    struct DummySigner {
        sig: [u8; 64],
    }
    impl Signer for DummySigner {
        fn sign_rs64_sha256_signdoc(&self, _cfg: &RunConfig, _sign_doc_bytes: &[u8]) -> Result<[u8; 64]> {
            Ok(self.sig)
        }
    }

    #[test]
    fn test_parse_pubkey33_hex_ok() -> Result<()> {
        let pk = parse_pubkey33_hex(&format!("{}{}", "02", "00".repeat(32)))?;
        assert_eq!(pk.len(), 33);
        assert_eq!(pk[0], 0x02);
        Ok(())
    }

    #[test]
    fn test_parse_pubkey33_hex_err_len() {
        let err = parse_pubkey33_hex(&"02".to_string()).unwrap_err();
        let s = format!("{err:#}");
        assert!(s.contains("33 bytes"));
    }

    #[test]
    fn test_b64_decode_roundtrip() -> Result<()> {
        let bytes = b"hello world".to_vec();
        let s = base64::engine::general_purpose::STANDARD.encode(&bytes);
        let got = b64_decode(&s)?;
        assert_eq!(got, bytes);
        Ok(())
    }

    #[test]
    fn test_ensure_signer_info_in_json_in_place_injects_fields() -> Result<()> {
        let mut root = mk_min_unsigned_json();
        let pk33 = parse_pubkey33_hex(&format!("{}{}", "02", "11".repeat(32)))?;

        ensure_signer_info_in_json_in_place(&mut root, &pk33, 7)?;

        // signatures is []
        assert_eq!(root["signatures"].as_array().unwrap().len(), 0);

        // signer_infos[0].sequence == "7"
        assert_eq!(root["auth_info"]["signer_infos"][0]["sequence"], "7");

        // public_key @type present
        assert_eq!(
            root["auth_info"]["signer_infos"][0]["public_key"]["@type"],
            "/cosmos.crypto.secp256k1.PubKey"
        );

        Ok(())
    }

    #[test]
    fn test_patch_signature_only_in_place_sets_signatures() -> Result<()> {
        let mut root = mk_min_unsigned_json();
        let sig = [0xABu8; 64];
        patch_signature_only_in_place(&mut root, &sig)?;

        let arr = root["signatures"].as_array().unwrap();
        assert_eq!(arr.len(), 1);

        let s = arr[0].as_str().unwrap();
        let decoded = b64_decode(s)?;
        assert_eq!(decoded.len(), 64);
        assert!(decoded.iter().all(|b| *b == 0xAB));
        Ok(())
    }

    #[test]
    fn test_write_temp_json_writes_file() -> Result<()> {
        let td = TempDir::new()?;
        let root = mk_min_unsigned_json();
        let p = write_temp_json(td.path(), &root)?;
        assert!(p.exists());
        let text = fs::read_to_string(&p)?;
        assert!(text.contains("\"auth_info\""));
        Ok(())
    }

    #[test]
    fn test_run_signs_and_writes_b64_without_tfd() -> Result<()> {
        // This test bypasses `tfd tx encode` by supplying encoded_tx_b64_in.
        // It also avoids decode/validate by writing a tiny tx and letting decode fail (then patch path runs).
        let td = TempDir::new()?;

        // Build a minimal Tx protobuf with body/auth_info present so SignDoc can be built.
        let tx = Tx {
            body: Some(cosmos_sdk_proto::cosmos::tx::v1beta1::TxBody {
                messages: vec![],
                memo: "".to_string(),
                timeout_height: 0,
                extension_options: vec![],
                non_critical_extension_options: vec![],
                // NOTE: unordered/timeout_timestamp exist in your chain JSON,
                // but protobuf TxBody fields depend on your proto version.
                // If your generated type doesn't have these fields, this is fine.
                ..Default::default()
            }),
            auth_info: Some(cosmos_sdk_proto::cosmos::tx::v1beta1::AuthInfo {
                signer_infos: vec![],
                fee: None,
                ..Default::default()
            }),
            signatures: vec![],
        };

        let tx_bytes = tx.encode_to_vec();
        let encoded_b64 = base64::engine::general_purpose::STANDARD.encode(&tx_bytes);

        // Write unsigned json + encoded tx b64 input
        let unsigned_path = td.path().join("unsigned.json");
        fs::write(&unsigned_path, serde_json::to_vec_pretty(&mk_min_unsigned_json())?)?;

        let encoded_path = td.path().join("encoded.b64");
        fs::write(&encoded_path, format!("{encoded_b64}\n"))?;

        let out_json = td.path().join("signed.json");
        let out_b64 = td.path().join("signed.b64");

        let cfg = RunConfig {
            input_unsigned_json: unsigned_path,
            chain_id: "tokenfactory-1".to_string(),
            account_number: 18,
            sequence: 2,
            pubkey_hex: format!("{}{}", "02", "22".repeat(32)),
            output_b64: Some(out_b64.clone()),
            output_json: out_json.clone(),
            dump_pre_sig: None,
            chain_bin: PathBuf::from("tfd-does-not-exist"),
            encoded_tx_b64_in: Some(encoded_path),
            hsm_key_label: "dummy".to_string(),
            chain_bin_env: vec![],
        };

        let signer = DummySigner { sig: [0x11u8; 64] };

        // This will fail at validate-signatures (needs tfd). So we test the core pipeline
        // by calling run() *minus the validate step* would require refactor.
        //
        // Instead, we assert that if validate is required, you can make it optional in cfg.
        //
        // If you keep validate always-on, then keep this test as an example and mark ignored.
        //
        // For now: expect failure because tfd doesn't exist, but ensure files up to that point exist.
        let _ = run(&cfg, &signer);

        // signed.b64 should exist (written before decode/validate)
        assert!(out_b64.exists());
        let b64 = fs::read_to_string(&out_b64)?;
        assert!(!b64.trim().is_empty());

        Ok(())
    }

    // Optional: integration-ish test that requires a real chain binary.
    // Run with: TFD_BIN=/abs/path/to/tfd cargo test -- --nocapture
    #[test]
    fn test_tfd_helpers_if_available() -> Result<()> {
        let tfd = match std::env::var("TFD_BIN") {
            Ok(v) => PathBuf::from(v),
            Err(_) => return Ok(()), // skip if not set
        };

        let sandbox = make_tfd_sandbox_home()?;
        let home = sandbox.path();

        // Minimal tx JSON -> encode should succeed
        let td = TempDir::new()?;
        let p = td.path().join("tx.json");
        fs::write(&p, serde_json::to_vec_pretty(&mk_min_unsigned_json())?)?;

        // encode
        let b64 = run_tfd_tx_encode(&tfd, &p, home, &[])?;
        assert!(!b64.trim().is_empty());

        // decode json
        let json = run_tfd_tx_decode_json(&tfd, b64.trim(), home, &[])?;
        assert!(!json.is_empty());

        Ok(())
    }

    #[test]
    #[serial_test::serial]
    fn test_chain_bin_env_is_applied_to_tfd_subprocesses() -> anyhow::Result<()> {
        use anyhow::Result;
        use std::fs;
        use tempfile::TempDir;

        // signer that returns a deterministic signature
        struct OkSigner;
        impl Signer for OkSigner {
            fn sign_rs64_sha256_signdoc(
                &self,
                _cfg: &RunConfig,
                _sign_doc_bytes: &[u8],
            ) -> Result<[u8; 64]> {
                Ok([9u8; 64])
            }
        }

        let tmp = TempDir::new()?;

        // unsigned.json
        let unsigned = tmp.path().join("unsigned.json");
        fs::write(
            &unsigned,
            serde_json::to_vec_pretty(&serde_json::json!({
          "body": {
            "messages": [],
            "memo": "",
            "timeout_height": "0",
            "unordered": false,
            "timeout_timestamp": null,
            "extension_options": [],
            "non_critical_extension_options": []
          },
          "auth_info": {
            "signer_infos": [],
            "fee": { "amount": [], "gas_limit": "200000", "payer": "", "granter": "" },
            "tip": null
          },
          "signatures": []
        }))?,
        )?;

        // Fake tfd that asserts LD_LIBRARY_PATH=/lib is present
        let tfd = tmp.path().join("tfd_env_check.sh");
        let encoded_b64 = make_minimal_encoded_tx_b64()?;
        let script = format!(
            r#"#!/bin/sh
set -eu

# verify env is passed
if [ "${{LD_LIBRARY_PATH:-}}" != "/lib" ]; then
  echo "missing/incorrect LD_LIBRARY_PATH: '${{LD_LIBRARY_PATH:-}}'" 1>&2
  exit 3
fi

# strip optional --home <dir>
if [ "$#" -ge 2 ] && [ "$1" = "--home" ]; then
  shift
  shift
fi

if [ "$#" -lt 2 ] || [ "$1" != "tx" ]; then
  echo "unexpected command" 1>&2
  exit 2
fi
shift

SUB="$1"
shift

case "$SUB" in
  encode)
    # prints encoded base64 to stdout
    echo "{encoded_b64}"
    ;;
  decode)
    # output some JSON
    echo '{{"body":{{"messages":[]}},"auth_info":{{"signer_infos":[]}},"signatures":[]}}'
    ;;
  validate-signatures)
    exit 0
    ;;
  *)
    echo "unexpected command" 1>&2
    exit 2
    ;;
esac
"#,
        );
        fs::write(&tfd, script)?;
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            let mut perms = fs::metadata(&tfd)?.permissions();
            perms.set_mode(0o755);
            fs::set_permissions(&tfd, perms)?;
        }

        let out_json = tmp.path().join("signed.json");

        // IMPORTANT: adjust field name to whatever you added in RunConfig:
        // e.g. `chain_bin_env`, `tfd_env`, etc.
        let cfg = RunConfig {
            input_unsigned_json: unsigned,
            chain_id: "test-chain".to_string(),
            account_number: 1,
            sequence: 1,
            pubkey_hex: "02".to_string() + &"11".repeat(32),
            output_b64: None,
            output_json: out_json.clone(),
            dump_pre_sig: None,
            chain_bin: tfd,
            encoded_tx_b64_in: None,
            hsm_key_label: "test".to_string(),

            // <--- add this line using your actual new field name/type:
            chain_bin_env: vec![("LD_LIBRARY_PATH".to_string(), "/lib".to_string())],
        };

        run(&cfg, &OkSigner)?;

        assert!(out_json.exists(), "signed.json should be written if env is applied");
        Ok(())
    }

}
