use crate::application::APP;
use crate::commands::keys::KeysCommand;
use crate::commands::KmstoolCmd;
use crate::config::KmstoolConfig;
use crate::prelude::info;
use abscissa_core::{status_err, Application};
use cosmrs::crypto::PublicKey as CosmrsPublicKey;
use cosmrs::proto::cosmos::crypto::ed25519::PubKey as CosmosEdPubKey;
use pkcs11_sdk::{init_sdk, CryptographAlgorithm, KeyLabel, SDK};
use std::convert::TryFrom;
use std::sync::Arc;

pub trait SDKProvider {
    fn keygen(&self, key_label: &mut KeyLabel, persistent: bool) -> Result<(), String>;

    fn get_k256_public_key(
        &self,
        key_label: &KeyLabel,
        key_type: String,
        address_prefix: Option<String>,
    ) -> Result<String, String>;

    fn get_p256_public_key(
        &self,
        key_label: &KeyLabel,
        key_type: String,
        address_prefix: Option<String>,
    ) -> Result<String, String>;

    fn get_ed_public_key(
        &self,
        key_label: &KeyLabel,
        key_type: String,
        address_prefix: Option<String>,
    ) -> Result<String, String>;
}

// SDKProviderImpl accesses the APP configuration to access the p11hsm sdk
pub struct SDKProviderImpl {
    pub config: Arc<KmstoolConfig>,
}

// new should be used only with the APP configuration
// in most cases, use default() instead of new(*)
impl SDKProviderImpl {
    #[allow(dead_code)]
    pub fn new(config: Arc<KmstoolConfig>) -> Self {
        Self { config }
    }
}

impl Default for SDKProviderImpl {
    fn default() -> Self {
        Self {
            config: APP.config().clone(),
        }
    }
}

impl SDKProviderImpl {
    pub fn get_sdk(&self) -> Result<SDK, String> {
        let ctx = init_sdk(
            &self.config.provider.p11hsm.env_cfg,
            &self.config.provider.p11hsm.cfg,
            self.config.provider.p11hsm.env_module.as_deref(),
            self.config.provider.p11hsm.module.as_deref(),
            &self.config.provider.p11hsm.token_label,
            &self.config.provider.p11hsm.user_pin,
        )
        .map_err(|e| format!("couldn't init sdk: {}", e))?;
        SDK::from_context(ctx).map_err(|e| format!("couldn't make sdk from context: {}", e))
    }
}
impl SDKProvider for SDKProviderImpl {
    fn keygen(&self, key_label: &mut KeyLabel, persistent: bool) -> Result<(), String> {
        let sdk = self.get_sdk()?;
        sdk.keygen(key_label, persistent)
            .map_err(|e| format!("couldn't generate key: {}", e))?;

        info!(
            "***** new key generated - key label: {}; algo: {:?}; persisted: {}",
            key_label.short_label(),
            key_label.algorithm,
            persistent
        );

        Ok(())
    }

    fn get_k256_public_key(
        &self,
        key_label: &KeyLabel,
        key_type: String,
        address_prefix: Option<String>,
    ) -> Result<String, String> {
        let sdk = self
            .get_sdk()
            .map_err(|e| format!("couldn't get sdk: {}", e))?;

        let vk = sdk.get_k256_public_key(key_label).unwrap_or_else(|e| {
            status_err!("couldn't get public key: {}", e);
            std::process::exit(1);
        });

        let pk = CosmrsPublicKey::from(vk);

        if address_prefix.is_none() {
            status_err!("address prefix is required for Secp256k1");
            std::process::exit(1);
        }

        if key_type != "account" {
            status_err!("key type must be account for Secp256k1");
            std::process::exit(1);
        }

        let account_id = pk.account_id(&address_prefix.clone().unwrap()).unwrap();

        Ok(format!(
            "pub key hex: {}; acct addr: {}",
            hex::encode(vk.to_sec1_bytes()),
            account_id
        ))
    }

    fn get_p256_public_key(
        &self,
        key_label: &KeyLabel,
        _key_type: String,
        _address_prefix: Option<String>,
    ) -> Result<String, String> {
        let sdk = self
            .get_sdk()
            .map_err(|e| format!("couldn't get sdk: {}", e))?;

        let vk = sdk.get_p256_public_key(key_label).unwrap_or_else(|e| {
            status_err!("couldn't get public key: {}", e);
            std::process::exit(1);
        });

        Ok(format!("pub key hex: {}", hex::encode(vk.to_sec1_bytes())))
    }

    fn get_ed_public_key(
        &self,
        key_label: &KeyLabel,
        _key_type: String,
        _address_prefix: Option<String>,
    ) -> Result<String, String> {
        let sdk = self
            .get_sdk()
            .map_err(|e| format!("couldn't get sdk: {}", e))?;

        let vk = sdk.get_ed_public_key(key_label).unwrap_or_else(|e| {
            status_err!("couldn't get public key: {}", e);
            std::process::exit(1);
        });

        let pub_key = CosmosEdPubKey {
            key: vk.as_bytes().to_vec(),
        };

        let cosmos_public_key = CosmrsPublicKey::try_from(pub_key.clone()).unwrap();

        Ok(format!(
            "pub key hex: {}; pub key json: {}",
            String::from_utf8(Vec::from(hex::encode(vk.as_bytes()))).unwrap(),
            cosmos_public_key.to_json()
        ))
    }
}

pub struct KmsOperation {
    pub cmd: KmstoolCmd,
    #[allow(dead_code)]
    pub config: Arc<KmstoolConfig>,
    pub sdk_provider: Arc<dyn SDKProvider>,
}

impl KmsOperation {
    // new is used for unit tests which mocks SDKProvider
    #[allow(dead_code)]
    pub fn new(cmd: KmstoolCmd, config: KmstoolConfig, sdk_provider: Arc<dyn SDKProvider>) -> Self {
        Self {
            cmd,
            config: Arc::new(config),
            sdk_provider,
        }
    }

    // default_w_cmd is used for actual p11hsm operations
    pub fn default_w_cmd(cmd: KmstoolCmd) -> Self {
        Self {
            cmd,
            config: APP.config(),
            sdk_provider: Arc::new(SDKProviderImpl::default()),
        }
    }

    pub fn run(&self) -> Result<(), String> {
        match self.cmd {
            KmstoolCmd::Keys(ref cmd) => match cmd {
                KeysCommand::GenKey(ref cmd) => {
                    let algo = CryptographAlgorithm::from(cmd.algorithm.clone());
                    let mut key_label = KeyLabel::from_short(&cmd.key_label.clone(), algo)
                        .map_err(|e| format!("couldn't make key label: {}", e))?;
                    self.sdk_provider.keygen(&mut key_label, cmd.persistent)
                }
                KeysCommand::GetPubKey(ref cmd) => {
                    let algo = CryptographAlgorithm::from(cmd.algorithm.clone());

                    let key_label = KeyLabel::from_short(&cmd.key_label.clone(), algo)
                        .map_err(|e| format!("couldn't make key label: {}", e))?;

                    let pk = match algo {
                        CryptographAlgorithm::Secp256k1 => self.sdk_provider.get_k256_public_key(
                            &key_label,
                            cmd.key_type.clone(),
                            cmd.address_prefix.clone(),
                        )?,
                        CryptographAlgorithm::Secp256r1 => self.sdk_provider.get_p256_public_key(
                            &key_label,
                            cmd.key_type.clone(),
                            cmd.address_prefix.clone(),
                        )?,
                        CryptographAlgorithm::Ed25519 => self.sdk_provider.get_ed_public_key(
                            &key_label,
                            cmd.key_type.clone(),
                            cmd.address_prefix.clone(),
                        )?,
                        _ => return Err(format!("unsupported algorithm: {:?}", algo)),
                    };
                    info!(
                        "***** key label: {}; pub key info - {}; algo: {:?}",
                        key_label.short_label(),
                        pk,
                        algo
                    );

                    Ok(())
                }
            },
            KmstoolCmd::Start(ref cmd) => {
                // let config = self.config.clone();
                // println!("Hello, {}!", &config.hello.recipient);
                Err(format!("Invalid command: {:?}", cmd))
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::commands::keys::genkey::GenKeyCommand;
    use crate::commands::keys::pubkey::GetPubKeyCommand;
    use crate::commands::start::StartCmd;
    use crate::test_util::MockSDKPrividerImpl;

    #[test]
    fn test_sdk_provider_impl_new() {
        let config = KmstoolConfig::default();
        let d = SDKProviderImpl::new(Arc::new(config));
        assert!(d.config.provider.p11hsm.env_cfg.is_empty());
    }

    #[test]
    fn test_sdk_provider_impl_default_panics() {
        let result = std::panic::catch_unwind(|| {
            // This will panic because APP state is not initialized
            SDKProviderImpl::default();
        });

        // Assert that a panic occurred
        assert!(result.is_err());

        // Extract and check the panic message
        if let Err(err) = result {
            let panic_message = err
                .downcast_ref::<String>()
                .map(|s| s.as_str())
                .or_else(|| err.downcast_ref::<&str>().copied())
                .unwrap_or("<unknown panic message>");
            assert!(
                panic_message.contains("application"),
                "Unexpected panic message: {}",
                panic_message
            );
        }
    }

    #[test]
    fn test_sdk_provider_impl_get_sdk_panic() {
        let config = KmstoolConfig::default();
        let d = SDKProviderImpl::new(Arc::new(config));
        let result = std::panic::catch_unwind(|| {
            // This will panic because APP state is not initialized
            d.get_sdk()
        });

        // Assert that a panic occurred
        assert!(result.is_err());
    }

    #[test]
    fn test_sdk_provider_impl_kengen_panic() {
        let config = KmstoolConfig::default();
        let d = SDKProviderImpl::new(Arc::new(config));
        let result = std::panic::catch_unwind(|| {
            let mut key_label =
                KeyLabel::from_short("slot 0/test/key/1", CryptographAlgorithm::Secp256k1).unwrap();
            // This will panic because APP state is not initialized
            d.keygen(&mut key_label, false)
        });

        // Assert that a panic occurred
        assert!(result.is_err());
    }

    #[test]
    fn test_sdk_provider_impl_get_k256_public_key_panic() {
        let config = KmstoolConfig::default();
        let d = SDKProviderImpl::new(Arc::new(config));
        let result = std::panic::catch_unwind(|| {
            let mut key_label =
                KeyLabel::from_short("slot 0/test/key/1", CryptographAlgorithm::Secp256k1).unwrap();
            // This will panic because APP state is not initialized
            d.get_k256_public_key(
                &mut key_label,
                "account".to_string(),
                Some("wf".to_string()),
            )
        });

        // Assert that a panic occurred
        assert!(result.is_err());
    }

    #[test]
    fn test_sdk_provider_impl_get_p256_public_key_panic() {
        let config = KmstoolConfig::default();
        let d = SDKProviderImpl::new(Arc::new(config));
        let result = std::panic::catch_unwind(|| {
            let mut key_label =
                KeyLabel::from_short("slot 0/test/key/1", CryptographAlgorithm::Secp256k1).unwrap();
            // This will panic because APP state is not initialized
            d.get_p256_public_key(
                &mut key_label,
                "account".to_string(),
                Some("wf".to_string()),
            )
        });

        // Assert that a panic occurred
        assert!(result.is_err());
    }

    #[test]
    fn test_sdk_provider_impl_get_ed_public_key_panic() {
        let config = KmstoolConfig::default();
        let d = SDKProviderImpl::new(Arc::new(config));
        let result = std::panic::catch_unwind(|| {
            let mut key_label =
                KeyLabel::from_short("slot 0/test/key/1", CryptographAlgorithm::Secp256k1).unwrap();
            // This will panic because APP state is not initialized
            d.get_ed_public_key(
                &mut key_label,
                "account".to_string(),
                Some("wf".to_string()),
            )
        });

        // Assert that a panic occurred
        assert!(result.is_err());
    }

    #[test]
    fn test_invalid_start_command() {
        let sdk_provider = MockSDKPrividerImpl::new();

        let cmd = KmstoolCmd::Start(StartCmd {
            recipient: vec!["Alice".to_string()],
        });

        let kms_operation =
            KmsOperation::new(cmd, KmstoolConfig::default(), Arc::new(sdk_provider));
        let result = kms_operation.run();

        assert!(result.is_err());
    }
    #[test]
    fn test_get_sdk_init_failure_by_gen_key() {
        let mut mock_provider = MockSDKPrividerImpl::new();

        // Simulate SDK initialization failure
        mock_provider
            .expect_keygen()
            .once()
            .returning(|_, _| Err("Failed to init SDK".to_string()));

        let config = KmstoolConfig::default();

        let kms_operation = KmsOperation::new(
            KmstoolCmd::Keys(KeysCommand::GenKey(GenKeyCommand {
                key_label: "slot 0/test/key/1".to_string(),
                algorithm: "secp256k1".to_string(),
                persistent: false,
            })),
            config,
            Arc::new(mock_provider),
        );

        let result = kms_operation.run();
        assert!(result.is_err());
        assert_eq!(result.unwrap_err(), "Failed to init SDK".to_string());
    }

    #[test]
    fn test_get_sdk_init_failure_by_pub_key_k256() {
        let mut mock_provider = MockSDKPrividerImpl::new();

        // Simulate SDK initialization failure
        mock_provider
            .expect_get_k256_public_key()
            .once()
            .returning(|_, _, _| Err("Failed to init SDK".to_string()));

        let _config = KmstoolConfig::default();

        let kms_operation = KmsOperation::new(
            KmstoolCmd::Keys(KeysCommand::GetPubKey(GetPubKeyCommand {
                key_label: "slot 0/test/key/1".to_string(),
                algorithm: "secp256k1".to_string(),
                key_type: "account".to_string(),
                address_prefix: Some("wf".to_string()),
            })),
            KmstoolConfig::default(),
            Arc::new(mock_provider),
        );

        let result = kms_operation.run();
        assert!(result.is_err());
        assert_eq!(result.unwrap_err(), "Failed to init SDK".to_string());
    }

    #[test]
    fn test_get_sdk_init_failure_by_pub_key_p256() {
        let mut mock_provider = MockSDKPrividerImpl::new();

        // Simulate SDK initialization failure
        mock_provider
            .expect_get_p256_public_key()
            .once()
            .returning(|_, _, _| Err("Failed to init SDK".to_string()));

        let _config = KmstoolConfig::default();

        let kms_operation = KmsOperation::new(
            KmstoolCmd::Keys(KeysCommand::GetPubKey(GetPubKeyCommand {
                key_label: "slot 0/test/key/1".to_string(),
                algorithm: "secp256r1".to_string(),
                key_type: "account".to_string(),
                address_prefix: Some("wf".to_string()),
            })),
            KmstoolConfig::default(),
            Arc::new(mock_provider),
        );

        let result = kms_operation.run();
        assert!(result.is_err());
        assert_eq!(result.unwrap_err(), "Failed to init SDK".to_string());
    }

    #[test]
    fn test_get_sdk_init_failure_by_pub_key_ed25519() {
        let mut mock_provider = MockSDKPrividerImpl::new();

        // Simulate SDK initialization failure
        mock_provider
            .expect_get_ed_public_key()
            .once()
            .returning(|_, _, _| Err("Failed to init SDK".to_string()));

        let _config = KmstoolConfig::default();

        let kms_operation = KmsOperation::new(
            KmstoolCmd::Keys(KeysCommand::GetPubKey(GetPubKeyCommand {
                key_label: "slot 0/test/key/1".to_string(),
                algorithm: "ed25519".to_string(),
                key_type: "account".to_string(),
                address_prefix: Some("wf".to_string()),
            })),
            KmstoolConfig::default(),
            Arc::new(mock_provider),
        );

        let result = kms_operation.run();
        assert!(result.is_err());
        assert_eq!(result.unwrap_err(), "Failed to init SDK".to_string());
    }

    #[test]
    fn test_unsupported_algorithm_run() {
        let mut mock_provider = MockSDKPrividerImpl::new();

        mock_provider
            .expect_get_k256_public_key()
            .times(0)
            .returning(|_, _, _| Err("unsupported algorithm: RSA2048".to_string()));

        let _config = KmstoolConfig::default();

        let kms_operation = KmsOperation::new(
            KmstoolCmd::Keys(KeysCommand::GetPubKey(GetPubKeyCommand {
                key_label: "slot 0/test/key/1".to_string(),
                algorithm: "rsa2048".to_string(),
                key_type: "account".to_string(),
                address_prefix: Some("wf".to_string()),
            })),
            KmstoolConfig::default(),
            Arc::new(mock_provider),
        );

        let result = kms_operation.run();
        assert!(result.is_err());
        assert_eq!(
            result.unwrap_err(),
            "unsupported algorithm: RSA2048".to_string()
        );
    }

    #[test]
    fn test_kms_operation_key_gen_run() {
        let mut sdk_provider = MockSDKPrividerImpl::new();
        sdk_provider
            .expect_keygen()
            // .withf(|kl| kl.short_label() == "test/key/1" && kl.algorithm == CryptographAlgorithm::AES && true)
            .times(1)
            .returning(|_, _| Ok(()));

        let kms_operation = KmsOperation::new(
            KmstoolCmd::Keys(KeysCommand::GenKey(GenKeyCommand {
                key_label: "slot 0/test/key/1".to_string(),
                algorithm: "secp256k1".to_string(),
                persistent: false,
            })),
            KmstoolConfig::default(),
            Arc::new(sdk_provider),
        );

        assert_eq!(kms_operation.run(), Ok(()));
    }

    #[test]
    fn test_gen_key_successful() {
        let cmd = GenKeyCommand {
            key_label: "Slot Token 0/test/key/1".to_string(),
            algorithm: "Secp256k1".to_string(),
            persistent: false,
        };
        let cmd = KmstoolCmd::Keys(KeysCommand::GenKey(cmd));

        let config = KmstoolConfig::default();

        let mut mock_provider = MockSDKPrividerImpl::new();
        mock_provider
            .expect_keygen()
            .times(1)
            .returning(|_, _| Ok(()));

        let key_gen = KmsOperation::new(cmd, config, Arc::new(mock_provider));

        let res = key_gen.run();

        assert!(res.is_ok());
    }

    #[test]
    fn test_gen_key_fail() {
        let cmd = GenKeyCommand {
            key_label: "Slot Token 0/test/key/1".to_string(),
            algorithm: "Secp256k1".to_string(),
            persistent: false,
        };
        let cmd = KmstoolCmd::Keys(KeysCommand::GenKey(cmd));

        let config = KmstoolConfig::default();

        let mut mock_provider = MockSDKPrividerImpl::new();
        mock_provider
            .expect_keygen()
            .times(1)
            .returning(|_, _| Err("Failed to generate key".to_string()));

        let key_gen = KmsOperation::new(cmd, config, Arc::new(mock_provider));

        let res = key_gen.run();

        assert!(res.is_err());
    }

    #[test]
    fn test_kms_operation_pub_key_k256() {
        let mut sdk_provider = MockSDKPrividerImpl::new();
        sdk_provider
            .expect_get_k256_public_key()
            // .withf(|kl| kl.short_label() == "test/key/1" && kl.algorithm == CryptographAlgorithm::AES && true)
            .times(1)
            .returning(|_, _, _| Ok("pub key hex: 1234567890; acct addr: cosmos1".to_string()));

        let kms_operation = KmsOperation::new(
            KmstoolCmd::Keys(KeysCommand::GetPubKey(GetPubKeyCommand {
                key_label: "slot 0/test/key/1".to_string(),
                algorithm: "secp256k1".to_string(),
                key_type: "account".to_string(),
                address_prefix: Some("wf".to_string()),
            })),
            KmstoolConfig::default(),
            Arc::new(sdk_provider),
        );

        assert!(kms_operation.run().is_ok());
    }

    #[test]
    fn test_kms_operation_pub_key_p256() {
        let mut sdk_provider = MockSDKPrividerImpl::new();
        sdk_provider
            .expect_get_p256_public_key()
            // .withf(|kl| kl.short_label() == "test/key/1" && kl.algorithm == CryptographAlgorithm::AES && true)
            .times(1)
            .returning(|_, _, _| Ok("pub key hex: 1234567890; acct addr: cosmos1".to_string()));

        let kms_operation = KmsOperation::new(
            KmstoolCmd::Keys(KeysCommand::GetPubKey(GetPubKeyCommand {
                key_label: "slot 0/test/key/1".to_string(),
                algorithm: "secp256r1".to_string(),
                key_type: "account".to_string(),
                address_prefix: Some("wf".to_string()),
            })),
            KmstoolConfig::default(),
            Arc::new(sdk_provider),
        );

        assert!(kms_operation.run().is_ok());
    }

    #[test]
    fn test_kms_operation_pub_key_ed25519() {
        let mut sdk_provider = MockSDKPrividerImpl::new();
        sdk_provider
            .expect_get_ed_public_key()
            // .withf(|kl| kl.short_label() == "test/key/1" && kl.algorithm == CryptographAlgorithm::AES && true)
            .times(1)
            .returning(|_, _, _| Ok("pub key hex: 1234567890; acct addr: cosmos1".to_string()));

        let kms_operation = KmsOperation::new(
            KmstoolCmd::Keys(KeysCommand::GetPubKey(GetPubKeyCommand {
                key_label: "slot 0/test/key/1".to_string(),
                algorithm: "ed25519".to_string(),
                key_type: "account".to_string(),
                address_prefix: Some("wf".to_string()),
            })),
            KmstoolConfig::default(),
            Arc::new(sdk_provider),
        );

        assert!(kms_operation.run().is_ok());
    }
    #[test]
    fn test_kms_operation_pub_key_fail_invalid_key_label() {
        let mut sdk_provider = MockSDKPrividerImpl::new();
        sdk_provider.expect_get_k256_public_key()
            // .withf(|kl| kl.short_label() == "test/key/1" && kl.algorithm == CryptographAlgorithm::AES && true)
            .times(0)
            // .returning(|_, _, _| Err("Invalid key label".to_string()))
        ;

        let kms_operation = KmsOperation::new(
            KmstoolCmd::Keys(KeysCommand::GetPubKey(GetPubKeyCommand {
                key_label: "test/key/1".to_string(),
                algorithm: "Secp256k1".to_string(),
                key_type: "account".to_string(),
                address_prefix: None,
            })),
            KmstoolConfig::default(),
            Arc::new(sdk_provider),
        );

        assert!(kms_operation.run().is_err());
    }

    #[test]
    fn test_kms_operation_pub_key_fail_invalid_algo() {
        let mut sdk_provider = MockSDKPrividerImpl::new();
        sdk_provider.expect_get_k256_public_key()
            // .withf(|kl| kl.short_label() == "test/key/1" && kl.algorithm == CryptographAlgorithm::AES && true)
            .times(0)
            // .returning(|_, _, _| Err("Invalid algo".to_string()))
        ;

        let kms_operation = KmsOperation::new(
            KmstoolCmd::Keys(KeysCommand::GetPubKey(GetPubKeyCommand {
                key_label: "slot 0/test/key/1".to_string(),
                algorithm: "rsa2048".to_string(),
                key_type: "account".to_string(),
                address_prefix: None,
            })),
            KmstoolConfig::default(),
            Arc::new(sdk_provider),
        );

        assert!(kms_operation.run().is_err());
    }
    #[test]
    fn test_kms_operation_start_fail() {
        let sdk_provider = MockSDKPrividerImpl::new();

        let kms_operation = KmsOperation::new(
            KmstoolCmd::Start(StartCmd {
                recipient: vec!["Alice".to_string(), "Bob".to_string()],
            }),
            KmstoolConfig::default(),
            Arc::new(sdk_provider),
        );

        assert!(kms_operation.run().is_err());
    }
}
