use serde::{Deserialize, Serialize};
use crate::config::provider::p11hsm::P11hsmConfig;

mod p11hsm;

#[derive(Clone, Debug, Default, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
/// Provider configuration
pub struct ProviderConfig {
    /// PKCS11 HSM configuration
    #[cfg(feature = "p11hsm")]
    #[serde(default)]
    pub p11hsm: P11hsmConfig,

}