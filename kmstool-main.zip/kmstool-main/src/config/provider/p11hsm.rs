use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Default, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
/// Configure struct for PKCS11 HSM
pub struct P11hsmConfig {
    /// evn var name for pkcs11 library file path
    /// so that the module file path can be retrieved from env var
    /// e.g., for FX, it is "FXPKCS11_MODULE"
    pub env_module: Option<String>,

    /// pkcs11 library binary file path
    pub module: Option<String>,

    /// pkcs11 config env var name
    /// e.g., for FX, it is "FXPKCS11_CFG"
    pub env_cfg: String,

    /// pkcs11 config file path
    pub cfg: String,

    /// pkcs11 token label to identify the slot
    /// e.g., for FX, it may be "us01crypto01test.virtucrypt.com:"
    /// e.g., for SoftHSM, it may be "Slot Token 0"
    pub token_label: String,

    /// pkcs11 user pin
    pub user_pin: String,

}
