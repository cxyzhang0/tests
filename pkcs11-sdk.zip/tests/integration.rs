use std::time::Instant;
use serial_test::serial;
use pkcs11_sdk::{Result, CryptographAlgorithm, KeyLabel, SDK, secure_hash, SDKContext};
use crate::integration_common::{get_test_ctx, get_test_sdk, TOKEN_LABEL};

mod integration_common;

#[test]
#[serial]
fn it_get_mechanism_list() -> Result<()> {
    let mut ctx = get_test_ctx()?;

    let ml = ctx.get_mechanism_list()?;

    println!("mechanism list: {:#?}", ml);

    Ok(())
}

#[test]
#[serial]
fn it_keygen() -> Result<()> {
    let start  = Instant::now();
    let sdk = get_test_sdk()?;

    println!("Time elapsed after get_sdk(): {:?}", start.elapsed());

    // test keygen for ed25519
    let kls = "slot-0/tsstrio-0/ed25519/1";
    // let kls = "slot-0/tsstrio-0/ed25519-long-oid/1";
    // let kls = "go/test/id-ed25519-hsm-1/1";
    // let kls = "Slot Token 0/WIM-test/id-ed25519-hsm-1/1";
    // let kls = "Slot Token 0/spl-token/id-ed25519-hsm-1/1";
    let mut key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Ed25519)?;

    let persistent = false;

    let (public, private, key_label) = sdk.keygen(&mut key_label, persistent)?;

    println!("algo: {:?}; key_label: {}; persisted: {}; pub key handle: {:?}; priv key handle: {:?}; ", key_label.algorithm, key_label.short_label(), persistent, public, private);
    println!("Time elapsed: {:?}", start.elapsed());
    // println!("public key: {:?}; private key: {:?}; key_label: {:?}", public, private, key_label);

    // test keygen for k256
    let kls = "Slot Token 0/WIM-test/secp256k1-hsm-1/1";
    let mut key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Secp256k1)?;

    let persistent = false;

    let (public, private, key_label) = sdk.keygen(&mut key_label, persistent)?;

    println!("algo: {:?}; key_label: {}; persisted: {}; pub key handle: {:?}; priv key handle: {:?}; ", key_label.algorithm, key_label.short_label(), persistent, public, private);
    println!("Time elapsed: {:?}", start.elapsed());

    // test keygen for p256
    let kls = "Slot Token 0/WIM-test/secp256r1-hsm-1/1";
    let mut key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Secp256r1)?;

    let persistent = false;

    let (public, private, key_label) = sdk.keygen(&mut key_label, persistent)?;

    println!("algo: {:?}; key_label: {}; persisted: {}; pub key handle: {:?}; priv key handle: {:?}; ", key_label.algorithm, key_label.short_label(), persistent, public, private);
    println!("Time elapsed: {:?}", start.elapsed());

    // test keygen for rsa2048
    let kls = "Slot Token 0/WIM-test/rsa2048-hsm-1/1";
    let mut key_label = KeyLabel::from_short(kls, CryptographAlgorithm::RSA2048)?;

    let persistent = false;

    let (public, private, key_label) = sdk.keygen(&mut key_label, persistent)?;

    println!("algo: {:?}; key_label: {}; persisted: {}; pub key handle: {:?}; priv key handle: {:?}; ", key_label.algorithm, key_label.short_label(), persistent, public, private);
    println!("Time elapsed: {:?}", start.elapsed());

    sdk.close()?;
    Ok(())
}

/*
#[test]
#[serial]
fn test_get_pkcs11() -> Result<()> {
    get_pkcs11()?;
    Ok(())
}

#[test]
#[serial]
fn test_init_pins() -> Result<()> {
    let (_, _) = init_pins()?;

    Ok(())
}
*/