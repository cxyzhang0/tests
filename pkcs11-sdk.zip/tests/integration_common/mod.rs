use std::env;
use pkcs11_sdk::{Result, SDK, SDKContext, Error};
use std::sync::{Once};
use std::sync::Mutex;
use cryptoki::context::{CInitializeArgs, Pkcs11};
use cryptoki::session::{UserType};
use cryptoki::slot::Slot;
use cryptoki::types::AuthPin;
use once_cell::sync::OnceCell;

pub static ENV_SOFTHSM2_CONF: &str = "SOFTHSM2_CONF";
pub static SOFTHSM2_CONF: &str = "./lib/softhsm2.conf";
// pub static ENV_MODULE: &str = "PKCS11_SOFTHSM2_MODULE";
pub static MODULE: &str = "./lib/libsofthsm2.so";
pub static USER_PIN: &str = "5678";
// The default SO pin
pub static SO_PIN: &str = "1234";
pub static TOKEN_LABEL: &str = "Slot Token 0";

/*
Ideally, we just use SDK's init_sdk(...) to get the SDKContext.
But that assume token is already initialized.
So here we have our test-version of init_sdk_test(...).
We need to add token initialization to init_sdk_test(...) and
the rest of code is pretty much the same.
*/
struct Init {
    ctx: SDKContext,
    _sdk: Mutex<SDK>,
}
static INIT_CALL: Once = Once::new();
static INIT_CELL: OnceCell<Init> = OnceCell::new();

fn init_test_sdk() -> Result<&'static SDKContext> {
    INIT_CALL.call_once(|| {
        env::set_var(ENV_SOFTHSM2_CONF, SOFTHSM2_CONF);
    });
    let init = INIT_CELL.get_or_try_init(|| {
        let (p11, slot) = init_pins()?;

        let mut ctx = SDKContext::new(p11);

        ctx.set_slot(slot);

        // let sdk = SDK::from_context_with_login(&ctx, pin)?;
        let mut sdk = SDK::from_context(&ctx)?;

        sdk.login(USER_PIN)?;

        Ok(Init { ctx, _sdk: Mutex::new(sdk) })
    });

    init.map(|i| &i.ctx)
}

pub fn get_test_ctx() -> Result<&'static SDKContext> {

    let ctx = init_test_sdk()?;

    Ok(ctx)
}
pub fn get_test_sdk() -> Result<SDK> {

    let ctx = init_test_sdk()?;
    let sdk = SDK::from_context(&ctx)?;

    Ok(sdk)
}
fn get_test_pkcs11() -> Result<Pkcs11> {
    // Pkcs11::new(
    //     env::var(ENV_MODULE)
    //         .unwrap_or_else(|_| MODULE.to_string()),
    // )
    //     .map_err(|e| Error::from(e))
    Pkcs11::new(
        MODULE.to_string(),
    ).map_err(|e| Error::from(e))
}

fn init_pins() -> Result<(Pkcs11, Slot)> {
    // env::set_var(ENV_SOFTHSM2_CONF, SOFTHSM2_CONF);

    let pkcs11 = get_test_pkcs11()?;

    // initialize the library
    pkcs11.initialize(CInitializeArgs::OsThreads)?;

    // find a slot, get the first one
    let slot = pkcs11.get_slots_with_token()?.remove(0);

    let so_pin = AuthPin::new(SO_PIN.into());
    pkcs11.init_token(slot, &so_pin, TOKEN_LABEL)?;

    {
        // open a session
        let session = pkcs11.open_rw_session(slot)?;
        // log in the session
        session.login(UserType::So, Some(&so_pin))?;
        session.init_pin(&AuthPin::new(USER_PIN.into()))?;
    };

    Ok((pkcs11, slot))
}
