// Copyright (c) Silence Laboratories Pte. Ltd. All Rights Reserved.
// This software is licensed under the Silence Laboratories License Agreement.

use axum::{
    extract::{Json, State},
    http::StatusCode,
};
use serde::{Deserialize, Serialize};
use tokio::sync::oneshot;

use super::{HttpState, Request};
use crate::relay::KeygenResult;

/// Request payload accepted by the `/v1/keygen` endpoint.
#[derive(Deserialize)]
pub struct KeygenPayload {
    threshold: u8,
}

/// Response body returned after a successful key generation request.
#[derive(Serialize)]
pub struct KeygenResponse {
    #[serde(with = "hex::serde")]
    key_id: Vec<u8>,

    #[serde(with = "hex::serde")]
    public_key: Vec<u8>,
}

/// Handles key generation requests by forwarding them to the command loop and
/// relaying the produced key identifier back to the caller.
pub(super) async fn handler(
    State(state): State<HttpState>,
    Json(payload): Json<KeygenPayload>,
) -> Result<Json<KeygenResponse>, StatusCode> {
    tracing::info!("enter http-keygen");

    let (answer, rx) = oneshot::channel();

    state
        .req_queue
        .send(Request::Keygen {
            threshold: payload.threshold,
            answer,
        })
        .await
        .map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?;

    tracing::info!("sent request");

    let KeygenResult { key_id, public_key } =
        rx.await.map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?;

    tracing::info!("got key-id");

    Ok(Json(KeygenResponse { key_id, public_key }))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::relay::Request;

    #[tokio::test]
    async fn forwards_keygen_request_and_returns_response() {
        let (tx, mut rx) = tokio::sync::mpsc::channel(1);
        let state = HttpState::new(tx);

        let handle = tokio::spawn(async move {
            if let Some(Request::Keygen { threshold, answer }) =
                rx.recv().await
            {
                assert_eq!(threshold, 3);
                let _ = answer.send(KeygenResult {
                    key_id: vec![0xAB; 32],
                    public_key: vec![0xAC; 33],
                });
            } else {
                panic!("missing keygen request");
            }
        });

        let response =
            handler(State(state), Json(KeygenPayload { threshold: 3 }))
                .await
                .expect("handler succeeds");

        assert_eq!(response.0.key_id, &[0xAB; 32]);
        assert_eq!(response.0.public_key, &[0xAC; 33]);

        handle.await.expect("request task completes");
    }
}
