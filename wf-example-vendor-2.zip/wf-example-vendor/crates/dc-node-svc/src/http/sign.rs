// Copyright (c) Silence Laboratories Pte. Ltd. All Rights Reserved.
// This software is licensed under the Silence Laboratories License Agreement.

use axum::{
    extract::{Json, State},
    http::StatusCode,
};
use serde::{Deserialize, Serialize};
use tokio::sync::oneshot;

use super::{HttpState, Request};

/// Request payload accepted by the `/v1/sign` endpoint.
#[derive(Deserialize)]
pub struct SignPayload {
    #[serde(with = "b64")]
    message: Vec<u8>,

    #[serde(with = "hex::serde")]
    key_id: Vec<u8>,

    threshold: u8,
}

/// Response body returned once the signature is available.
#[derive(Serialize)]
pub struct SignResponse {
    #[serde(with = "hex::serde")]
    sign: Vec<u8>,
}

/// Custom base64 helper used for decoding the request message body.
pub mod b64 {
    use base64::{engine::general_purpose::STANDARD, Engine as _};
    use serde::{Deserialize, Deserializer};

    pub fn deserialize<'de, D>(d: D) -> Result<Vec<u8>, D::Error>
    where
        D: Deserializer<'de>,
    {
        let v = STANDARD
            .decode(<&str>::deserialize(d)?)
            .map_err(serde::de::Error::custom)?;

        Ok(v)
    }
}

/// Accept signing requests and forward them to the relay command loop.
pub(super) async fn handler(
    State(state): State<HttpState>,
    Json(payload): Json<SignPayload>,
) -> Result<Json<SignResponse>, StatusCode> {
    tracing::info!("enter http-sign");

    let (answer, rx) = oneshot::channel();

    state
        .req_queue
        .send(Request::Sign {
            message: payload.message,
            key_id: payload.key_id,
            threshold: payload.threshold,
            answer,
        })
        .await
        .map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?;

    tracing::info!("sent request");

    let sign = rx.await.map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?;

    tracing::info!("got sign");

    Ok(Json(SignResponse { sign }))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::relay::Request;

    #[tokio::test]
    async fn forwards_sign_request_and_returns_signature() {
        let (tx, mut rx) = tokio::sync::mpsc::channel(1);
        let state = HttpState::new(tx);

        let handle = tokio::spawn(async move {
            if let Some(Request::Sign {
                message,
                key_id,
                threshold,
                answer,
            }) = rx.recv().await
            {
                assert_eq!(message, b"payload".to_vec());
                assert_eq!(key_id, vec![0x11; 32]);
                assert_eq!(threshold, 2);
                let _ = answer.send(vec![0xCD; 65]);
            } else {
                panic!("missing sign request");
            }
        });

        let response = handler(
            State(state),
            Json(SignPayload {
                message: b"payload".to_vec(),
                key_id: vec![0x11; 32],
                threshold: 2,
            }),
        )
        .await
        .expect("handler succeeds");

        assert_eq!(response.0.sign, vec![0xCD; 65]);

        handle.await.expect("request task completes");
    }
}
