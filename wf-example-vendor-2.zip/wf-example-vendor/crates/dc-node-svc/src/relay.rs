// Copyright (c) Silence Laboratories Pte. Ltd. All Rights Reserved.
// This software is licensed under the Silence Laboratories License Agreement.

use std::{
    net::SocketAddr,
    sync::Arc,
    time::{Duration, Instant},
};

use anyhow::Context;
use ed25519_dalek::{SigningKey, VerifyingKey};
use rand::prelude::*;
use tokio::{
    net::{TcpListener, TcpStream},
    sync::{mpsc, oneshot},
    time::timeout,
};
use tokio_util::sync::CancellationToken;

use direct_relay::{
    DirectAcceptor, DirectConnector, DirectRelay, DirectRelayBuilder,
};
use simple_cloud_node::storage::{
    BaseBoxedStorage, CreateKeyshare, LoadKeyshare, SimpleStorage,
};
use simple_setup_msg::ProtocolParticipant;
use sl_messages::{
    message::{InstanceId, MsgHdr, MsgId},
    BytesMut,
};

use crate::{config::PeerConfig, setup, setup::tags};

pub(crate) const SETUPMSG_FLAG: u16 = 0x0001;
// pub const CHALLENGE_FLAG: u16 = 0x0002;

enum Command {
    Setup(BytesMut),
    // Challange(BytesMut),
}

enum ParsedMessage {
    Normal(BytesMut),
    Cmd(Command),
}

struct Acceptor {
    rx: mpsc::Receiver<TcpStream>,
}

struct Connector {
    addr: String,
    token: CancellationToken,
}

/// Requests issued by higher layers to control the distributed protocols.
pub enum Request {
    Keygen {
        threshold: u8,
        answer: oneshot::Sender<KeygenResult>,
    },

    Sign {
        message: Vec<u8>,
        key_id: Vec<u8>,
        threshold: u8,
        answer: oneshot::Sender<Vec<u8>>,
    },
}

pub struct KeygenResult {
    pub key_id: Vec<u8>,
    pub public_key: Vec<u8>,
}

impl Connector {
    /// Creates a new connector targeting the provided address.
    fn new(addr: String, token: CancellationToken) -> Self {
        Self { addr, token }
    }
}

impl DirectConnector for Connector {
    type Connection = TcpStream;

    async fn connect(&mut self) -> Option<Self::Connection> {
        while let Some(conn) = self
            .token
            .run_until_cancelled(TcpStream::connect(&self.addr))
            .await
        {
            match conn {
                Ok(s) => {
                    tracing::info!("connected to {}", self.addr);
                    if s.set_nodelay(true).is_ok() {
                        return Some(s);
                    }
                }

                Err(err) => {
                    tracing::info!("connect to {} failed: {err}", &self.addr);
                }
            }

            // TODO: implement a proper retry strategy
            tokio::time::sleep(Duration::from_secs(3)).await;
        }

        None
    }
}

impl DirectAcceptor for Acceptor {
    type Connection = TcpStream;

    async fn accept(&mut self) -> Self::Connection {
        loop {
            if let Some(conn) = self.rx.recv().await {
                let Ok(addr) = conn.peer_addr() else { continue };
                tracing::info!("accepted connection from {addr:?}");
                return conn;
            }
        }
    }
}

fn parse_message(message: BytesMut) -> ParsedMessage {
    if let Ok(hdr) = <&MsgHdr>::try_from(message.as_ref()) {
        let flags = hdr.flags() & 0x7FFF;

        if !hdr.is_one_receiver() {
            #[allow(clippy::single_match)]
            match flags {
                SETUPMSG_FLAG => {
                    return ParsedMessage::Cmd(Command::Setup(message));
                }

                _ => {}
            }
        }
    }

    ParsedMessage::Normal(message)
}

// Spawns an accept loop and returns a queue with parsed commands.
fn init_cmd_queue<A: DirectAcceptor>(
    relay: &DirectRelay,
    acceptor: A,
    cmd_queue_size: usize,
) -> mpsc::Receiver<Command> {
    let (tx, rx) = mpsc::channel(cmd_queue_size);

    relay.spawn_accept_loop(acceptor, cmd_queue_size, move || {
        let tx = tx.clone();

        move |message: BytesMut| {
            let tx = tx.clone();
            async move {
                match parse_message(message) {
                    ParsedMessage::Normal(message) => Some(message),
                    ParsedMessage::Cmd(cmd) => {
                        let _ = tx.send(cmd).await;
                        None
                    }
                }
            }
        }
    });

    rx
}

/// Main entry point wiring the HTTP request queue with the relay backend.
pub async fn main_loop(
    token: CancellationToken,
    storage: Arc<SimpleStorage<BaseBoxedStorage>>,
    node_addrs: impl IntoIterator<Item = SocketAddr>,
    peers: impl IntoIterator<Item = PeerConfig>,
    party_sk: SigningKey,
) -> anyhow::Result<mpsc::Sender<Request>> {
    let acceptor = init_acceptor(&token, node_addrs)
        .await
        .context("node acceptor")?;

    let relay = peers
        .into_iter()
        .fold(DirectRelayBuilder::new(), |builder, peer| {
            let addr = peer.address();
            let party_id = peer.party_id();

            let connector = Connector::new(addr, token.clone());

            builder.output_connection(party_id, connector, 100)
        })
        .build();
    let relay = Arc::new(relay);

    let cmd_queue = init_cmd_queue(&relay, acceptor, 100);

    let (tx, req_queue) = mpsc::channel(1);

    tokio::spawn(command_loop(
        Arc::new(party_sk),
        relay,
        req_queue,
        cmd_queue,
        storage,
        token,
    ));

    Ok(tx)
}

// Binds TCP listeners and forwards accepted sockets to the relay.
async fn init_acceptor(
    token: &CancellationToken,
    node_addrs: impl IntoIterator<Item = SocketAddr>,
) -> anyhow::Result<Acceptor> {
    let (tx, rx) = mpsc::channel(1);

    for addr in node_addrs {
        let listener = TcpListener::bind(addr).await?;
        tracing::info!("node listening on {addr}");

        let tx = tx.clone();
        let token = token.clone();
        tokio::spawn(async move {
            while let Some(Ok((stream, _remote_addr))) =
                token.run_until_cancelled(listener.accept()).await
            {
                if tx.send(stream).await.is_err() {
                    // .send() fails if `rx` is dropped, that Acceptor
                    // is dropped and we have to exit accept loop.
                    break;
                }
            }
            tracing::info!("exit accept loop");
        });
    }

    Ok(Acceptor { rx })
}

// Central dispatcher handling both API requests and relay commands.
async fn command_loop(
    party_sk: Arc<SigningKey>,
    relay: Arc<DirectRelay>,
    mut req_queue: mpsc::Receiver<Request>,
    mut cmd_queue: mpsc::Receiver<Command>,
    storage: Arc<SimpleStorage<BaseBoxedStorage>>,
    token: CancellationToken,
) {
    tracing::info!("enter command loop");

    loop {
        tokio::select! {
            _ = token.cancelled() => { break },

            req = req_queue.recv() => {
                if let Some(req) = req {
                    handle_request(party_sk.clone(), req, relay.clone(), storage.clone()).await;
                } else {
                    break;
                }
            },

            cmd = cmd_queue.recv() => {
                if let Some(cmd) = cmd {
                    handle_command(party_sk.clone(), cmd, relay.clone(), storage.clone()).await;
                } else {
                    break;
                }
            },
        }
    }

    tracing::info!("exit command loop");
}

// Processes API requests and launches the required distributed protocol.
async fn handle_request(
    party_sk: Arc<SigningKey>,
    req: Request,
    relay: Arc<DirectRelay>,
    storage: Arc<SimpleStorage<BaseBoxedStorage>>,
) {
    let party_vk = party_sk.verifying_key();

    match req {
        Request::Keygen { threshold, answer } => {
            let inst = random();
            let instance_id = InstanceId::new(inst);

            let id = MsgId::broadcast(
                &instance_id,
                party_vk.as_ref(),
                setup::SETUP_MESSAGE_TAG,
            );

            let ttl = Duration::from_secs(10);

            let Some(setup_msg) = setup::keygen::SetupBuilder::new()
                .add_tag(tags::SETUP_VK, Some(party_vk.as_ref()))
                .add_tag(tags::INSTANCE_ID, Some(&inst))
                .add_party(0, &party_vk)
                .add_parties(relay.other_parties().map(|vk| (0, vk)))
                .build_with_flags(
                    &id,
                    ttl,
                    threshold,
                    &*party_sk,
                    SETUPMSG_FLAG,
                )
            else {
                tracing::error!("invalid threshold: {threshold}");
                return;
            };

            if relay
                .broadcast_message(setup_msg.clone(), |_| true)
                .await
                .is_err()
            {
                tracing::error!("keygen setup message broadcast error");
                return;
            }

            handle_keygen(
                setup_msg.into(),
                instance_id,
                party_sk,
                party_vk,
                relay,
                storage,
                Some(answer),
            )
            .await;
        }

        Request::Sign {
            message,
            key_id,
            threshold,
            answer,
        } => {
            let Ok(key_id) = key_id.try_into() else {
                tracing::error!("invalid key_id");
                return;
            };

            let inst = random();
            let instance_id = InstanceId::new(inst);

            let id = MsgId::broadcast(
                &instance_id,
                party_vk.as_ref(),
                setup::SETUP_MESSAGE_TAG,
            );

            let ttl = Duration::from_secs(10);

            let others = relay
                .other_parties()
                .take(threshold as usize - 1)
                .map(|vk| vk.to_vec())
                .collect::<Vec<_>>();

            let Some(setup_msg) = setup::sign::SetupBuilder::new(key_id)
                .add_tag(tags::SETUP_VK, Some(party_vk.as_ref()))
                .add_tag(tags::INSTANCE_ID, Some(&inst))
                .with_message(Some(&message), setup::HashAlgo::Sha256)
                .add_party(Some(&party_vk))
                .add_party(&others)
                .build_with_flags(&id, ttl, &*party_sk, SETUPMSG_FLAG)
            else {
                tracing::error!("invalid threshold: {threshold}");
                return;
            };

            if relay
                .broadcast_message(setup_msg.clone(), |vk| {
                    others.iter().any(|n| n == vk)
                })
                .await
                .is_err()
            {
                tracing::error!("keygen setup message broadcast error");
                return;
            }

            handle_sign(
                setup_msg.into(),
                instance_id,
                party_sk,
                party_vk,
                relay,
                storage,
                Some(answer),
            )
            .await;
        }
    }
}

// Reacts to setup messages that arrive through the direct relay.
async fn handle_command(
    party_sk: Arc<SigningKey>,
    cmd: Command,
    relay: Arc<DirectRelay>,
    storage: Arc<SimpleStorage<BaseBoxedStorage>>,
) {
    let party_vk = party_sk.verifying_key();

    match cmd {
        Command::Setup(msg) => {
            let Some((magic, instance_id, setup_vk)) =
                setup::parse_message(&msg)
            else {
                tracing::info!("setup: can't parse message");
                return;
            };

            if !is_known_vk(&party_vk, &relay, &setup_vk) {
                tracing::info!("unknown setup vk");
                return;
            }

            match magic {
                tags::DKG => {
                    handle_keygen(
                        msg,
                        instance_id,
                        party_sk,
                        setup_vk,
                        relay,
                        storage,
                        None,
                    )
                    .await;
                }

                tags::DSG => {
                    handle_sign(
                        msg,
                        instance_id,
                        party_sk,
                        setup_vk,
                        relay,
                        storage,
                        None,
                    )
                    .await;
                }

                _ => {
                    tracing::info!("setup: unknown magic");
                }
            }
        }
    }
}

// Executes the key generation protocol once a setup message is validated.
async fn handle_keygen(
    setup_msg: BytesMut,
    instance_id: InstanceId,
    party_sk: Arc<SigningKey>,
    setup_vk: VerifyingKey,
    relay: Arc<DirectRelay>,
    storage: Arc<SimpleStorage<BaseBoxedStorage>>,
    answer: Option<oneshot::Sender<KeygenResult>>,
) {
    let Some(decoded) = setup::keygen::DecodedSetup::decode(
        instance_id,
        setup_msg.into(),
        &setup_vk,
    ) else {
        tracing::info!("keygen setup message decode failed");
        return;
    };

    let Some(validated) =
        setup::keygen::ValidatedSetup::from_decoded(decoded, party_sk)
    else {
        tracing::info!("keygen setup failed");
        return;
    };

    let validated = validated.with_setup_hash();
    let ttl = validated.message_ttl();

    let relay = relay.connect(&validated, 100);

    let seed = random();

    let start = Instant::now();
    tracing::info!("staring DKG ...");

    tokio::spawn(async move {
        let Ok(share) =
            timeout(ttl, dkls23::keygen::run(validated, seed, relay)).await
        else {
            tracing::error!("DKG timeout");
            return;
        };

        let share = match share {
            Ok(share) => share,
            Err(err) => {
                tracing::error!("keygen run failed {err:?}");
                return;
            }
        };

        tracing::info!(
            "key-id {} {:?}",
            hex::encode(share.key_id),
            start.elapsed()
        );

        // TODO: handle storage errors, use reconciliation protocol.
        let _ = storage.create_keyshare(&share).await;

        if let Some(answer) = answer {
            // .send() fails if client went away.
            let _ = answer.send(KeygenResult {
                key_id: share.key_id.to_vec(),
                public_key: share.public_key.to_vec(),
            });
        }
    });
}

// Executes the signing protocol once a setup message is validated.
async fn handle_sign(
    setup_msg: BytesMut,
    instance_id: InstanceId,
    party_sk: Arc<SigningKey>,
    setup_vk: VerifyingKey,
    relay: Arc<DirectRelay>,
    storage: Arc<SimpleStorage<BaseBoxedStorage>>,
    answer: Option<oneshot::Sender<Vec<u8>>>,
) {
    let Some(decoded) = setup::sign::DecodedSetup::decode(
        instance_id,
        setup_msg.into(),
        &setup_vk,
    ) else {
        tracing::info!("sign setup message decode failed");
        return;
    };

    let key_id = decoded.key_id();
    let Ok(share) = storage.load_keyshare(&key_id).await else {
        tracing::info!("can't load share {}", hex::encode(key_id));
        return;
    };

    let Some(validated) =
        setup::sign::ValidatedSetup::from_decoded(decoded, party_sk, share)
    else {
        tracing::info!("sign setup message valiation failed");
        return;
    };

    let ttl = validated.message_ttl();

    let relay = relay.connect(&validated, 100);

    let seed = random();

    let start = Instant::now();
    tracing::info!("staring DSG ...");

    let Ok(sign) =
        timeout(ttl, dkls23::sign::run(validated, seed, relay)).await
    else {
        tracing::error!("DSG timeout");
        return;
    };

    let (s, recid) = match sign {
        Ok(sing) => sing,
        Err(err) => {
            tracing::error!("sign run failed {err:?}");
            return;
        }
    };

    tracing::info!("sign {:?}", start.elapsed());

    if let Some(answer) = answer {
        let mut bytes = vec![0u8; 65];

        bytes[..64].copy_from_slice(&s.to_bytes());
        bytes[64] = recid.to_byte();

        let _ = answer.send(bytes);
    }
}

// Checks whether the provided verifying key belongs to a known participant.
fn is_known_vk(
    party_vk: &VerifyingKey,
    relay: &DirectRelay,
    setup_vk: &VerifyingKey,
) -> bool {
    if setup_vk == party_vk {
        return true;
    }

    for other_vk in relay.other_parties() {
        let other_vk = other_vk.try_into().unwrap_or_default();
        if let Ok(vk) = VerifyingKey::from_bytes(&other_vk) {
            if &vk == setup_vk {
                return true;
            }
        }
    }

    false
}

#[cfg(test)]
mod tests {
    use super::*;

    use tokio::io::DuplexStream;

    fn make_key() -> SigningKey {
        SigningKey::from_bytes(&random())
    }

    fn build_setup_message(flags: u16) -> BytesMut {
        let party_sk = make_key();
        let party_vk = party_sk.verifying_key();
        let peer_vk = make_key().verifying_key();

        let instance_bytes: [u8; 32] = random();
        let instance = InstanceId::new(instance_bytes);

        let id = MsgId::broadcast(
            &instance,
            party_vk.as_ref(),
            setup::SETUP_MESSAGE_TAG,
        );

        let setup = setup::keygen::SetupBuilder::new()
            .add_tag(setup::tags::SETUP_VK, Some(party_vk.as_ref()))
            .add_tag(setup::tags::INSTANCE_ID, Some(&instance_bytes))
            .add_party(0, &party_vk)
            .add_parties([(1, peer_vk.as_ref())])
            .build_with_flags(
                &id,
                Duration::from_secs(30),
                2,
                &party_sk,
                flags,
            )
            .expect("valid setup message");

        BytesMut::from(setup.as_ref())
    }

    #[test]
    fn parse_message_detects_setup_flag() {
        let message = build_setup_message(SETUPMSG_FLAG);
        let original = message.clone();

        match parse_message(message) {
            ParsedMessage::Cmd(Command::Setup(buf)) => {
                assert_eq!(&buf[..], &original[..]);
            }

            _ => panic!("expected setup command"),
        }
    }

    #[test]
    fn parse_message_leaves_regular_messages() {
        let message = build_setup_message(0);
        let original = message.clone();

        match parse_message(message) {
            ParsedMessage::Normal(buf) => {
                assert_eq!(&buf[..], &original[..]);
            }

            _ => panic!("expected normal message"),
        }
    }

    struct DummyConnector;

    impl DirectConnector for DummyConnector {
        type Connection = DuplexStream;

        async fn connect(&mut self) -> Option<Self::Connection> {
            None
        }
    }

    #[tokio::test(flavor = "current_thread")]
    async fn is_known_vk_detects_known_peers() {
        let local = make_key().verifying_key();
        let peer = make_key().verifying_key();
        let stranger = make_key().verifying_key();

        let relay = DirectRelayBuilder::new()
            .output_connection(peer.as_bytes().to_vec(), DummyConnector, 1)
            .build();

        assert!(is_known_vk(&local, &relay, &local));
        assert!(is_known_vk(&local, &relay, &peer));
        assert!(!is_known_vk(&local, &relay, &stranger));
    }
}
