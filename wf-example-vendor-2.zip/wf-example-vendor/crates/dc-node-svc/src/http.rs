// Copyright (c) Silence Laboratories Pte. Ltd. All Rights Reserved.
// This software is licensed under the Silence Laboratories License Agreement.

use axum::{
    extract::State,
    http::StatusCode,
    routing::{get, post, Router},
};
use tokio::sync::mpsc;

use crate::relay::Request;

mod keygen;
mod sign;

/// Shared HTTP state granting handlers access to the relay request queue.
#[derive(Clone)]
pub struct HttpState {
    req_queue: mpsc::Sender<Request>,
}

impl HttpState {
    pub fn new(req_queue: mpsc::Sender<Request>) -> Self {
        Self { req_queue }
    }
}

/// Temporary health-check handler that reports the service as not yet
/// implemented.
async fn health(State(_state): State<HttpState>) -> Result<(), StatusCode> {
    Err(StatusCode::NOT_IMPLEMENTED)
}

/// Builds the router that exposes the coordinator HTTP API.
///
/// The routing table includes a root readiness endpoint, a placeholder health
/// check, and the key generation and signing endpoints forwarded to the relay
/// subsystem.
pub fn routes(state: HttpState) -> Router {
    Router::new()
        .route("/", get(|| async { "ok" }))
        .route("/health", get(health))
        .route("/v1/keygen", post(keygen::handler))
        .route("/v1/sign", post(sign::handler))
        .with_state(state)
}
