// Copyright (c) Silence Laboratories Pte. Ltd. All Rights Reserved.
// This software is licensed under the Silence Laboratories License Agreement.

/// Configuration describing how to reach a remote party in the relay mesh.
///
/// The data is consumed by the [`relay`](crate::relay) module when it establishes TCP
/// connections to peer nodes and when it needs the corresponding party
/// identifier for routing messages.
pub struct PeerConfig {
    addr: String,
    party_id: Vec<u8>,
}

impl PeerConfig {
    /// Builds a new peer configuration with the target address and party id.
    pub fn new(addr: String, party_id: Vec<u8>) -> Self {
        Self { addr, party_id }
    }

    /// Returns the socket address of the remote peer as configured for the
    /// relay.
    pub fn address(&self) -> String {
        self.addr.clone()
    }

    /// Returns the identifier that should be used when addressing the remote
    /// party through the direct relay.
    pub fn party_id(&self) -> Vec<u8> {
        self.party_id.clone()
    }
}
