// Copyright (c) Silence Laboratories Pte. Ltd. All Rights Reserved.
// This software is licensed under the Silence Laboratories License Agreement.

use ed25519_dalek::VerifyingKey;

use simple_setup_msg::{self as setup};
use sl_messages::message::*;

pub use dkls23::setup::SETUP_MESSAGE_TAG;
pub use simple_setup_msg::{decode_tag, find_tags, tags, HashAlgo};

/// Re-exports helpers required to build and validate keygen setup
/// messages.
pub mod keygen {
    use super::*;

    pub type DecodedSetup = setup::keygen::DecodedSetup;
    pub type SetupBuilder = setup::keygen::SetupBuilder;
    pub type ValidatedSetup = setup::keygen::ValidatedSetup;
}

/// Re-exports helpers required to build and validate signing setup
/// messages.
pub mod sign {
    use super::*;

    pub type DecodedSetup = setup::sign::DecodedSetup;
    pub type SetupBuilder = setup::sign::SetupBuilder;
    pub type ValidatedSetup = setup::sign::ValidatedSetup;
}

/// Parses an incoming setup message and extracts the high-level metadata.
pub fn parse_message(
    msg: &[u8],
) -> Option<(&[u8], InstanceId, VerifyingKey)> {
    let raw_msg = msg.get(MESSAGE_HEADER_SIZE..)?;

    let magic = match setup::find_tags(raw_msg, tags::MAGIC).next()? {
        tags::DKG => tags::DKG,
        tags::DSG => tags::DSG,
        tags::QC => tags::QC,

        _ => return None,
    };

    let setup_vk = setup::decode_tag(raw_msg, tags::SETUP_VK)?;

    let instance_id = setup::decode_tag(raw_msg, tags::INSTANCE_ID)?;

    let instance_id = InstanceId::new(instance_id);

    let setup_vk = VerifyingKey::from_bytes(&setup_vk).ok()?;

    Some((magic, instance_id, setup_vk))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::relay::SETUPMSG_FLAG;
    use ed25519_dalek::SigningKey;
    use rand::random;
    use sl_messages::message::MsgId;
    use std::time::Duration;

    fn make_key() -> SigningKey {
        SigningKey::from_bytes(&random())
    }

    fn build_keygen_setup_message() -> (Vec<u8>, InstanceId, VerifyingKey) {
        let party_sk = make_key();
        let party_vk = party_sk.verifying_key();

        let peer_sk = make_key();
        let peer_vk = peer_sk.verifying_key();

        let instance_bytes: [u8; 32] = random();
        let instance = InstanceId::new(instance_bytes);

        let id =
            MsgId::broadcast(&instance, party_vk.as_ref(), SETUP_MESSAGE_TAG);

        let setup = keygen::SetupBuilder::new()
            .add_tag(tags::SETUP_VK, Some(party_vk.as_ref()))
            .add_tag(tags::INSTANCE_ID, Some(&instance_bytes))
            .add_party(0, &party_vk)
            .add_parties([(1, peer_vk.as_ref())])
            .build_with_flags(
                &id,
                Duration::from_secs(30),
                2,
                &party_sk,
                SETUPMSG_FLAG,
            )
            .expect("valid setup message");

        (setup.to_vec(), instance, party_vk)
    }

    #[test]
    fn parse_message_extracts_metadata() {
        let (setup, instance, vk) = build_keygen_setup_message();

        let (magic, parsed_instance, parsed_vk) =
            parse_message(&setup).expect("message parses");

        assert_eq!(magic, tags::DKG);
        assert_eq!(parsed_instance, instance);
        assert_eq!(parsed_vk.as_bytes(), vk.as_bytes());
    }

    #[test]
    fn parse_message_rejects_unknown_payload() {
        assert!(parse_message(&[]).is_none());
    }
}
