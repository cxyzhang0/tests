// Copyright (c) Silence Laboratories Pte. Ltd. All Rights Reserved.
// This software is licensed under the Silence Laboratories License Agreement.

use std::{env, net::ToSocketAddrs, sync::Arc};

use anyhow::Context;
use ed25519_dalek::SigningKey;
use tokio::{
    net::TcpListener,
    signal::unix::{signal, SignalKind},
    task::JoinSet,
};
use tokio_util::sync::CancellationToken;
use tracing_subscriber::{
    layer::SubscriberExt, util::SubscriberInitExt, EnvFilter,
};

use simple_cloud_node::storage::{load_base_storage, SimpleStorage};

use dc_node_svc::{config::PeerConfig, http, relay};

use http::HttpState;

fn init_shutdown_signals() -> CancellationToken {
    let root_token = CancellationToken::new();

    let sign_cancel = root_token.clone();

    let sigint = async {
        signal(SignalKind::interrupt())
            .expect("cant install SIGINT handler")
            .recv()
            .await;
        tracing::info!("SIGINT");
    };

    let sigterm = async {
        signal(SignalKind::terminate())
            .expect("cant install SIGTERM handler")
            .recv()
            .await;
        tracing::info!("SIGTERM");
    };

    tokio::spawn(async move {
        tokio::select! {
            _ = sigint => {},
            _ = sigterm => {},
        };

        sign_cancel.cancel()
    });

    root_token
}

fn init_tracing() {
    tracing_subscriber::registry()
        .with(
            EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| "info".into()),
        )
        .with(tracing_subscriber::fmt::layer())
        .init();
}

#[tokio::main(flavor = "multi_thread")]
async fn main() -> anyhow::Result<()> {
    init_tracing();

    let storage = env::var("STORAGE")
        .context("STORAGE is not set")?
        .parse()
        .context("Invalid storage")?;

    let party_sk = SigningKey::from_bytes(
        &std::fs::read(env::var("PARTY_SK").context("PARTY_SK is not set")?)
            .context("Can't read party sk")?
            .try_into()
            .map_err(|_| anyhow::Error::msg("invalid party_sk"))?,
    );

    tracing::info!(
        "party vk {}",
        hex::encode(party_sk.verifying_key().as_bytes())
    );

    let storage = Arc::new(SimpleStorage::new(
        load_base_storage(&storage)
            .await
            .context("storage create")?,
    ));

    let root_token = init_shutdown_signals();

    let node_addrs = env::var("NODE_LISTEN")
        .ok()
        .unwrap_or_else(|| String::from("localhost:5000"));

    let node_addrs = node_addrs
        .split_whitespace()
        .filter_map(|s| s.to_socket_addrs().ok())
        .flatten();

    let peers = parse_peers();

    let req_queue = relay::main_loop(
        root_token.child_token(),
        storage,
        node_addrs,
        peers,
        party_sk,
    )
    .await?;

    let app = http::routes(HttpState::new(req_queue));

    let mut servers = JoinSet::new();

    for addrs in env::var("HTTP_LISTEN")
        .ok()
        .unwrap_or_else(|| String::from("localhost:8080"))
        .split(' ')
        .map(|s| s.trim())
        .filter(|s| !s.is_empty())
    {
        for addr in addrs.to_socket_addrs()? {
            let listener = TcpListener::bind(addr).await?;
            tracing::info!("listening on {addr}");

            let app = app.clone();
            let token = root_token.clone();

            servers.spawn(async move {
                axum::serve(listener, app)
                    .with_graceful_shutdown(token.cancelled_owned())
                    .await
            });
        }
    }

    while servers.join_next().await.is_some() {}

    tracing::info!("http stopped");

    Ok(())
}

fn parse_peers() -> impl Iterator<Item = PeerConfig> {
    (1..)
        .map(|other_idx| {
            let name = format!("PEER_{other_idx}");
            let val = env::var(&name).ok()?;

            tracing::info!("peer {val}");

            let mut var = val.split_whitespace();
            let addr = var.next()?.to_string();
            let party_id = hex::decode(var.next()?).ok()?;

            Some(PeerConfig::new(addr, party_id))
        })
        .take_while(Option::is_some)
        .flatten()
}
