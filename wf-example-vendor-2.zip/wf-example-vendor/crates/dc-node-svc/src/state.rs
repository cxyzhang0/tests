// Copyright (c) Silence Laboratories Pte. Ltd. All Rights Reserved.
// This software is licensed under the Silence Laboratories License Agreement.

use std::sync::Arc;

use direct_relay::DirectRelay;
use simple_cloud_node::{
    // random::{AsyncRandomBytes, Error as RandomGenError, OsRandom},
    storage::{
        // simple::{HasKeyId, HasSessionId, KeyshareDecode, KeyshareEncoding},
        BaseBoxedStorage,
        // CreateError, CreateKeyshare, LoadError,
        // LoadKeyshare, LoadPreSign, PreparedTransaction, ReadError,
        // ReconcileKeyshare, SavePreSign,
        SimpleStorage,
        // StorageError, UpdateKeyshare,
    },
};

#[derive(Clone)]
pub struct AppState(pub(crate) Arc<Inner>);

pub(crate) struct Inner {
    storage: SimpleStorage<BaseBoxedStorage>,
    relay: DirectRelay,
}

impl AppState {
    pub fn new(
        storage: SimpleStorage<BaseBoxedStorage>,
        relay: DirectRelay,
    ) -> Self {
        Self(Arc::new(Inner { storage, relay }))
    }
}
