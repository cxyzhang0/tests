This workspace contains a copy of dkls23-rs/crates/dc-node-svc and shows
how to build a project that uses open-source and proprietary SL
libraries.

Private crates from the SL registry are unpacked into `vendor/` and resolved
through `.cargo/config.toml`. The manifests keep `registry = "sl"` for private
dependencies, and config-level patch entries redirect them to local vendored
copies. CI must use the checked-in `Cargo.lock` from the repository and does
not need access to the SL registry. Generating or updating `Cargo.lock` must be
done outside the CI environment on a machine that has access to the real SL
registry definition from `.cargo/config.toml`.

Vendor/*.crate files are output of “cargo package” command executed
from our workspace (dkls23-rs). The content of .crate file is uploaded
into our private registry.

## Manual vendoring workflow

1. Obtain the required private `.crate` file from the SL registry. If the crate
   was already fetched on a machine with SL registry access, the packaged file
   may also be available under `~/.cargo/registry/cache/`.
2. Unpack it into `vendor/<crate-name>-<version>/`.
3. If the workspace depends on that crate directly, add or update its entry in
   `[workspace.dependencies]` in `Cargo.toml` to use `registry = "sl"`.
4. Add the crate to `[patch."ssh://git@ssh.shipyard.rs/silencelaboratories/crate-index.git"]`
   in `.cargo/config.toml` so direct and transitive private dependencies
   resolve to the local unpacked copy.
5. Commit both the unpacked directory and, if useful for provenance, the
   original `.crate` file.
6. Generate or update `Cargo.lock` outside CI on a machine that has access to
   the SL registry.
7. Commit the updated `Cargo.lock` together with the vendored crate changes.
8. Validate in CI with `cargo build --frozen`. Use `--offline` too if your CI
   image already contains the crates.io index and crate tarballs.

## Docker validation

Use the Dockerfile in the repo root to validate the build in a clean container:

```sh
docker build -t wf-example-vendor-validate .
```

Notes:
- Public `sl-*` crates are resolved from crates.io and do not need vendoring
  unless you want a fully offline build.
- The repo still defines the real `sl` registry in `.cargo/config.toml` so
  dependency resolution and `Cargo.lock` refreshes can work on machines that
  have access to the SL registry.
- CI should not regenerate `Cargo.lock`; it should consume the lockfile already
  committed to the repository.
- Optional private features still need their crates vendored before those
  features can be enabled in CI.
