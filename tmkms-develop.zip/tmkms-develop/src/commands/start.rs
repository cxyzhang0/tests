//! Start the KMS

use std::{path::PathBuf, process};

use abscissa_core::Command;
use clap::Parser;

use crate::{client::Client, prelude::*, validator};

/// The `start` command
#[derive(Command, Debug, Default, Parser)]
pub struct StartCommand {
    /// path to tmkms.toml
    #[clap(short = 'c', long = "config")]
    pub config: Option<PathBuf>,

    /// enable verbose debug logging
    #[clap(short = 'v', long = "verbose")]
    pub verbose: bool,

    /// enable json logging format
    #[clap(short = 'j', long = "json")]
    pub json: bool,
}

impl Runnable for StartCommand {
    /// Run the KMS
    fn run(&self) {
        info!(
            "{} {} starting up...",
            env!("CARGO_PKG_NAME"),
            env!("CARGO_PKG_VERSION")
        );

        run_app(self.spawn_clients());
    }
}

impl StartCommand {
    /// Spawn clients from the app's configuration
    fn spawn_clients(&self) -> Vec<Client> {
        let config = APP.config();

        validator::load_config(&config).unwrap_or_else(|e| {
            status_err!("error loading configuration: {}", e);
            process::exit(1);
        });

        // Spawn the validator client threads
        config
            .validator
            .iter()
            .cloned()
            .map(Client::spawn)
            .collect()
    }
}

/// Run the application.
fn run_app(validator_clients: Vec<Client>) {
    blocking_wait(validator_clients);
}

/// Wait for clients to shut down using synchronous thread joins
fn blocking_wait(validator_clients: Vec<Client>) {
    // Wait for all of the validator client threads to exit
    debug!("Main thread waiting on clients...");

    let mut success = true;

    for client in validator_clients {
        let name = client.name().to_owned();

        if let Err(e) = client.join() {
            status_err!("client '{}' exited with error: {}", name, e);
            success = false;
        }
    }

    if success {
        info!("Shutdown completed successfully");
    } else {
        warn!("Shutdown completed with errors");
        process::exit(1);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::PathBuf;

    #[test]
    fn start_command_with_valid_config() {
        let cmd = StartCommand {
            config: Some(PathBuf::from("/path/to/valid_config.toml")),
            verbose: false,
            json: false,
        };
        let result = std::panic::catch_unwind(|| {
            cmd.run();
        });
        assert!(result.is_err());
    }

    #[test]
    fn start_command_with_no_config() {
        let cmd = StartCommand {
            config: None,
            verbose: false,
            json: false,
        };
        let result = std::panic::catch_unwind(|| {
            cmd.run();
        });
        assert!(result.is_err());
    }

    #[test]
    fn start_command_with_verbose_logging() {
        let cmd = StartCommand {
            config: Some(PathBuf::from("/path/to/valid_config.toml")),
            verbose: true,
            json: false,
        };
        let result = std::panic::catch_unwind(|| {
            cmd.run();
        });
        assert!(result.is_err());
    }

    #[test]
    fn start_command_with_invalid_config() {
        let cmd = StartCommand {
            config: Some(PathBuf::from("/path/to/invalid_config.toml")),
            verbose: false,
            json: false,
        };
        let result = std::panic::catch_unwind(|| {
            cmd.run();
        });
        assert!(result.is_err());
    }

    #[test]
    fn spawn_clients_with_valid_config() {
        let cmd = StartCommand {
            config: Some(PathBuf::from("/path/to/valid_config.toml")),
            verbose: false,
            json: false,
        };
        let result = std::panic::catch_unwind(|| {
            cmd.run();
        });
        assert!(result.is_err());
    }

    #[test]
    fn spawn_clients_with_no_config() {
        let cmd = StartCommand {
            config: None,
            verbose: false,
            json: false,
        };
        let result = std::panic::catch_unwind(|| {
            cmd.spawn_clients();
        });
        assert!(result.is_err());
    }
}
