//! Ed25519 signing keys

use std::sync::Arc;

pub use ed25519::Signature;
use tendermint::TendermintKey;

use crate::{
    error::{Error, ErrorKind::*},
    keyring::SigningProvider,
    prelude::*,
};

pub use self::{signing_key::SigningKey, verifying_key::VerifyingKey};

mod signing_key;
mod verifying_key;

/// Ed25519 signer
#[allow(clippy::redundant_allocation)]
#[derive(Clone)]
pub struct Signer {
    /// Provider for this signer
    provider: SigningProvider,

    /// Tendermint public key
    public_key: TendermintKey,

    /// Signer trait object
    signer: Arc<Box<dyn signature::Signer<Signature> + Send + Sync>>,
}

impl Signer {
    /// Create a new signer
    pub fn new(
        provider: SigningProvider,
        public_key: TendermintKey,
        signer: Box<dyn signature::Signer<Signature> + Send + Sync>,
    ) -> Self {
        Self {
            provider,
            public_key,
            signer: Arc::new(signer),
        }
    }

    /// Get the Tendermint public key for this signer
    pub fn public_key(&self) -> TendermintKey {
        self.public_key
    }

    /// Get the provider for this signer
    pub fn provider(&self) -> SigningProvider {
        self.provider
    }

    /// Sign the given message using this signer
    pub fn sign(&self, msg: &[u8]) -> Result<Signature, Error> {
        Ok(self
            .signer
            .try_sign(msg)
            .map_err(|e| format_err!(SigningError, "{}", e))?)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::testing;
    use signature::Verifier;

    #[test]
    fn signer_sign() {
        let signer = testing::ed25519::gen_signer();
        let verifying_key = testing::ed25519::get_vk_from_signer(&signer);

        let message = b"hello, world!";
        let signature = signer.sign(message).unwrap();
        verifying_key.verify(message, &signature).unwrap();
    }

    #[test]
    fn signer_public_key() {
        let signer = testing::ed25519::gen_signer();

        let public_key = signer.public_key();

        match public_key {
            TendermintKey::ConsensusKey(k) => match k {
                tendermint::PublicKey::Ed25519(pk) => {
                    assert_eq!(pk.as_bytes().len(), VerifyingKey::BYTE_SIZE)
                }
                _ => panic!("unexpected public key type"),
            },
            _ => panic!("unexpected public key type"),
        }
    }

    #[test]
    fn signer_provider() {
        let signer = testing::ed25519::gen_signer();

        let _provider = signer.provider();
    }
}
