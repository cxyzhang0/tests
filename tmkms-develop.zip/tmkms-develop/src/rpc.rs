//! Remote Procedure Calls

// TODO: docs for everything
#![allow(missing_docs)]

use crate::privval::SignableMsg;
use prost::Message as _;
use std::io::Read;
use tendermint::{chain, Proposal, Vote};
use tendermint_p2p::secret_connection::DATA_MAX_SIZE;
use tendermint_proto as proto;

use crate::{
    error::{Error, ErrorKind},
    prelude::*,
    MAX_MSG_LEN,
};

/// RPC requests to the KMS
#[derive(Debug)]
pub enum Request {
    /// Sign the given message
    SignProposal(Proposal),
    SignVote(Vote),
    ShowPublicKey,
    PingRequest,
}

impl Request {
    /// Read a request from the given readable.
    pub fn read(conn: &mut impl Read, expected_chain_id: &chain::Id) -> Result<Self, Error> {
        let mut msg_bytes: Vec<u8> = vec![];
        let msg;

        // fix for Sei: collect incoming bytes of Protobuf from incoming msg
        loop {
            let mut msg_chunk = read_msg(conn)?;
            let chunk_len = msg_chunk.len();
            msg_bytes.append(&mut msg_chunk);

            if msg_bytes.len() > MAX_MSG_LEN {
                fail!(
                    ErrorKind::IoError,
                    format!("message too long: {}", msg_bytes.len())
                )
            }

            // if we can decode it, great, break the loop
            match proto::privval::Message::decode_length_delimited(msg_bytes.as_ref()) {
                Ok(m) => {
                    msg = m.sum;
                    break;
                }
                Err(e) => {
                    // if chunk_len < DATA_MAX_SIZE (1024) we assume it was the end of the message and it is malformed
                    if chunk_len < DATA_MAX_SIZE {
                        return Err(format_err!(
                            ErrorKind::ProtocolError,
                            "malformed message packet: {}",
                            e
                        )
                        .into());
                    }
                    // otherwise, we go to start of the loop assuming next chunk(s)
                    // will fill the message
                }
            }
        }

        let (req, chain_id) = match msg {
            Some(proto::privval::message::Sum::SignVoteRequest(
                proto::privval::SignVoteRequest {
                    vote: Some(vote),
                    chain_id,
                },
            )) => (Request::SignVote(vote.try_into()?), chain_id),
            Some(proto::privval::message::Sum::SignProposalRequest(
                proto::privval::SignProposalRequest {
                    proposal: Some(proposal),
                    chain_id,
                },
            )) => (Request::SignProposal(proposal.try_into()?), chain_id),
            Some(proto::privval::message::Sum::PubKeyRequest(req)) => {
                (Request::ShowPublicKey, req.chain_id)
            }
            Some(proto::privval::message::Sum::PingRequest(_)) => {
                return Ok(Request::PingRequest);
            }
            _ => fail!(ErrorKind::ProtocolError, "invalid RPC message: {:?}", msg),
        };

        ensure!(
            expected_chain_id == &chain::Id::try_from(chain_id.as_str())?,
            ErrorKind::ChainIdError,
            "got unexpected chain ID: {} (expecting: {})",
            &chain_id,
            expected_chain_id
        );

        Ok(req)
    }

    /// Convert this request into a [`SignableMsg`].
    ///
    /// The expected `chain::Id` is used to validate the request.
    pub fn into_signable_msg(self) -> Result<SignableMsg, Error> {
        match self {
            Self::SignProposal(proposal) => Ok(proposal.into()),
            Self::SignVote(vote) => Ok(vote.into()),
            _ => fail!(
                ErrorKind::InvalidMessageError,
                "expected a signable message type: {:?}",
                self
            ),
        }
    }
}

/// RPC responses from the KMS
#[derive(Debug)]
pub enum Response {
    /// Signature response
    SignedVote(proto::privval::SignedVoteResponse),
    SignedProposal(proto::privval::SignedProposalResponse),
    Ping(proto::privval::PingResponse),
    PublicKey(proto::privval::PubKeyResponse),
}

impl Response {
    /// Encode response to bytes.
    pub fn encode(self) -> Result<Vec<u8>, Error> {
        let mut buf = Vec::new();
        let msg = match self {
            Response::SignedVote(resp) => proto::privval::message::Sum::SignedVoteResponse(resp),
            Response::SignedProposal(resp) => {
                proto::privval::message::Sum::SignedProposalResponse(resp)
            }
            Response::Ping(resp) => proto::privval::message::Sum::PingResponse(resp),
            Response::PublicKey(resp) => proto::privval::message::Sum::PubKeyResponse(resp),
        };
        proto::privval::Message { sum: Some(msg) }.encode_length_delimited(&mut buf)?;
        Ok(buf)
    }

    /// Construct an error response for a given [`SignableMsg`].
    pub fn error(msg: SignableMsg, error: proto::privval::RemoteSignerError) -> Response {
        match msg {
            SignableMsg::Proposal(_) => {
                Response::SignedProposal(proto::privval::SignedProposalResponse {
                    proposal: None,
                    error: Some(error),
                })
            }
            SignableMsg::Vote(_) => Response::SignedVote(proto::privval::SignedVoteResponse {
                vote: None,
                error: Some(error),
            }),
        }
    }
}

impl From<SignableMsg> for Response {
    fn from(msg: SignableMsg) -> Response {
        match msg {
            SignableMsg::Proposal(proposal) => {
                Response::SignedProposal(proto::privval::SignedProposalResponse {
                    proposal: Some(proposal.into()),
                    error: None,
                })
            }
            SignableMsg::Vote(vote) => Response::SignedVote(proto::privval::SignedVoteResponse {
                vote: Some(vote.into()),
                error: None,
            }),
        }
    }
}

/// Read a message from a Secret Connection
// TODO(tarcieri): extract this into Secret Connection
fn read_msg(conn: &mut impl Read) -> Result<Vec<u8>, Error> {
    let mut buf = vec![0; DATA_MAX_SIZE];
    let buf_read = conn.read(&mut buf)?;
    buf.truncate(buf_read);
    Ok(buf)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::error::ErrorKind;
    use std::io::Cursor;
    use tendermint::chain::Id as ChainId;
    #[test]
    fn read_request_invalid_chain_id() {
        let mut data = Cursor::new(vec![/* serialized SignVoteRequest data */]);
        let chain_id = ChainId::try_from("invalid-chain").unwrap();
        let result = Request::read(&mut data, &chain_id);
        assert!(result.is_err());
    }

    #[test]
    fn read_request_malformed_message() {
        let mut data = Cursor::new(vec![/* malformed data */]);
        let chain_id = ChainId::try_from("test-chain").unwrap();
        let result = Request::read(&mut data, &chain_id);
        assert!(result.is_err());
    }

    #[test]
    fn encode_response_signed_vote() {
        let response = Response::SignedVote(proto::privval::SignedVoteResponse {
            vote: None,
            error: None,
        });
        let encoded = response.encode().unwrap();
        assert!(!encoded.is_empty());
    }

    #[test]
    fn encode_response_signed_proposal() {
        let response = Response::SignedProposal(proto::privval::SignedProposalResponse {
            proposal: None,
            error: None,
        });
        let encoded = response.encode().unwrap();
        assert!(!encoded.is_empty());
    }

    #[test]
    fn encode_response_ping() {
        let response = Response::Ping(proto::privval::PingResponse {});
        let encoded = response.encode().unwrap();
        assert!(!encoded.is_empty());
    }

    #[test]
    fn encode_response_public_key() {
        let response = Response::PublicKey(proto::privval::PubKeyResponse {
            pub_key: None,
            error: None,
        });
        let encoded = response.encode().unwrap();
        assert!(!encoded.is_empty());
    }

    #[test]
    fn read_request_rejects_oversized_message() {
        // 0xFF varints never terminate in decode_length_delimited, so this
        // forces the reassembly loop to keep buffering until size guard trips.
        let mut data = Cursor::new(vec![0xFF; MAX_MSG_LEN + 1]);
        let chain_id = ChainId::try_from("test-chain").unwrap();
        let err = Request::read(&mut data, &chain_id).unwrap_err();

        assert_eq!(err.kind(), &ErrorKind::IoError);
        assert!(format!("{err}").contains("message too long"));
    }

    #[test]
    fn read_request_allows_exact_max_msg_len_boundary() {
        // Exactly MAX_MSG_LEN should not trigger the guard (`>` only).
        // The payload is still malformed and should eventually fail with
        // ProtocolError once read() reaches EOF.
        let mut data = Cursor::new(vec![0xFF; MAX_MSG_LEN]);
        let chain_id = ChainId::try_from("test-chain").unwrap();
        let err = Request::read(&mut data, &chain_id).unwrap_err();

        assert_eq!(err.kind(), &ErrorKind::ProtocolError);
    }
}
