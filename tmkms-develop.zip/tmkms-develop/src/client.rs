//! The KMS makes outbound connections to the validator, and is technically a
//! client, however once connected it accepts incoming RPCs, and otherwise
//! acts as a service.
//!
//! To dance around the fact the KMS isn't actually a service, we refer to it
//! as a "Key Management System".

use std::{panic, process::exit, thread, time::Duration};

use crate::{
    config::ValidatorConfig,
    error::{Error, ErrorKind},
    prelude::*,
    session::Session,
    validator,
};

/// Join handle type used by our clients
type JoinHandle = thread::JoinHandle<Result<(), Error>>;

/// How long to wait after a crash before respawning (in seconds)
pub const RESPAWN_DELAY: u64 = 1;

/// Client connections: wraps a thread which makes a connection to a particular
/// validator node and then receives RPCs.
///
/// The `Client` type does not deal with network I/O, that is handled inside of
/// the `Session`. Instead, the `Client` type manages threading and respawning
/// sessions in the event of errors.
pub struct Client {
    /// Name of the client thread
    name: String,

    /// Handle to the client thread
    handle: JoinHandle,
}

impl Client {
    /// Spawn a new client, returning a handle so it can be joined
    pub fn spawn(config: ValidatorConfig) -> Self {
        register_validator(&config.id);

        let name = format!("{}:{}@{}", &config.id, &config.chain_id, &config.addr);

        let handle = thread::Builder::new()
            .name(name.clone())
            .spawn(move || main_loop(config))
            .unwrap_or_else(|e| {
                status_err!("error spawning thread: {}", e);
                exit(1);
            });

        Self { name, handle }
    }

    /// Get the name of this client
    pub fn name(&self) -> &str {
        &self.name
    }

    /// Wait for a running client to finish
    pub fn join(self) -> Result<(), Error> {
        self.handle.join().unwrap()
    }
}

/// Main loop for all clients. Handles reconnecting in the event of an error
fn main_loop(config: ValidatorConfig) -> Result<(), Error> {
    while let Err(e) = run_client(config.clone()) {
        // `PoisonError` is unrecoverable
        if *e.kind() == ErrorKind::PoisonError {
            error!(
                "[{}:{}@{}] FATAL -- {}",
                &config.id, &config.chain_id, &config.addr, e
            );
            return Err(e);
        } else {
            error!(
                "[{}:{}@{}] {}",
                &config.id, &config.chain_id, &config.addr, e
            );
        }

        if config.reconnect {
            // TODO: configurable respawn delay
            thread::sleep(Duration::from_secs(RESPAWN_DELAY));
        } else {
            return Err(e);
        }
    }

    Ok(())
}

/// Ensure chain with given ID is properly registered
pub fn register_validator(val_id: &validator::Id) {
    let registry = validator::REGISTRY.get();

    debug!("registering validator: {}", val_id);
    registry.get_validator(val_id).unwrap_or_else(|| {
        status_err!(
            "unregistered val: {} (add it to tmkms.toml's [[validator]] section)",
            val_id
        );
        exit(1);
    });
}

/*
#[deprecated(note = "use register_validator")]
/// Ensure chain with given ID is properly registered
pub fn register_chain(chain_id: &chain::Id) {
    let registry = chain::REGISTRY.get();

    debug!("registering chain: {}", chain_id);
    registry.get_chain(chain_id).unwrap_or_else(|| {
        status_err!(
            "unregistered chain: {} (add it to tmkms.toml's [[chain]] section)",
            chain_id
        );
        exit(1);
    });
}
*/
/// Open a new session and run the session loop
pub fn run_client(config: ValidatorConfig) -> Result<(), Error> {
    panic::catch_unwind(move || Session::open(config)?.request_loop())
        .unwrap_or_else(|e| Err(Error::from_panic(e)))
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::ProtocolVersion;
    use crate::keyring::Format;

    // -------------------------------------------------------------------------
    // RESPAWN_DELAY
    // -------------------------------------------------------------------------

    #[test]
    fn respawn_delay_is_one_second() {
        assert_eq!(RESPAWN_DELAY, 1);
    }

    // -------------------------------------------------------------------------
    // Client::name — construct Client directly, bypassing spawn() and
    // register_validator() which both call exit(1) on failure.
    // -------------------------------------------------------------------------

    #[test]
    fn client_name_accessor_returns_correct_name() {
        let handle = thread::Builder::new()
            .name("test-client".to_string())
            .spawn(|| Ok::<(), Error>(()))
            .expect("thread spawn should succeed");
        let client = Client {
            name: "test-client".to_string(),
            handle,
        };
        assert_eq!(client.name(), "test-client");
    }

    // -------------------------------------------------------------------------
    // register_validator — calls exit(1), NOT panic.
    // Cannot use #[should_panic] or catch_unwind — both are ineffective.
    // Instead verify the precondition: no test IDs are pre-registered.
    // -------------------------------------------------------------------------

    #[test]
    fn registry_does_not_contain_arbitrary_id() {
        let val_id: validator::Id = "test_validator_id".parse()
            .expect("should parse as validator::Id");
        let registry = validator::REGISTRY.get();
        assert!(
            registry.get_validator(&val_id).is_none(),
            "unregistered IDs must not appear in the registry"
        );
    }

    // -------------------------------------------------------------------------
    // run_client — safe to call: does NOT call register_validator or exit(1).
    // With no listening server, Session::open returns Err immediately.
    // -------------------------------------------------------------------------

    #[test]
    fn run_client_returns_err_when_no_server_is_listening() {
        let config = ValidatorConfig {
            id: "cosmoshub-4".parse().unwrap(),
            chain_id: "cosmoshub-4".parse().unwrap(),
            addr: "127.0.0.1:19999".parse().unwrap(),
            reconnect: false,
            timeout: None,
            secret_key: None,
            key_format: Format::CosmosJson,
            sign_extensions: false,
            state_file: None,
            max_height: None,
            protocol_version: ProtocolVersion::V0_34,
            state_hook: None,
        };
        assert!(run_client(config).is_err());
    }
    
    #[test]
    #[should_panic]
    fn client_spawn_with_valid_config() {
        let config = ValidatorConfig {
            id: "valid_id".parse().unwrap(),
            chain_id: "chain_id".parse().unwrap(),
            addr: "127.0.0.1:26656".parse().unwrap(),
            reconnect: true,
            timeout: None,
            secret_key: None,
            key_format: Format::CosmosJson,
            sign_extensions: false,
            state_file: None,
            max_height: None,
            protocol_version: ProtocolVersion::V0_34,
            state_hook: None,
        };
        let client = Client::spawn(config);
        assert_eq!(client.name(), "valid_id:chain_id@127.0.0.1:26656");
    }

    #[test]
    fn client_spawn_with_invalid_thread_name() {
        let config = ValidatorConfig {
            id: "invalid_id".parse().unwrap(),
            chain_id: "chain_id".parse().unwrap(),
            addr: "127.0.0.1:26656".parse().unwrap(),
            reconnect: true,
            timeout: None,
            secret_key: None,
            key_format: Format::CosmosJson,
            sign_extensions: false,
            state_file: None,
            max_height: None,
            protocol_version: ProtocolVersion::V0_34,
            state_hook: None,
        };
        let result = panic::catch_unwind(|| {
            Client::spawn(config);
        });
        assert!(result.is_err());
    }

    #[test]
    #[should_panic]
    fn client_join_success() {
        let config = ValidatorConfig {
            id: "valid_id".parse().unwrap(),
            chain_id: "chain_id".parse().unwrap(),
            addr: "127.0.0.1:26656".parse().unwrap(),
            reconnect: false,
            timeout: None,
            secret_key: None,
            key_format: Format::CosmosJson,
            sign_extensions: false,
            state_file: None,
            max_height: None,
            protocol_version: ProtocolVersion::V0_34,
            state_hook: None,
        };
        let client = Client::spawn(config);
        assert!(client.join().is_ok());
    }

    #[test]
    #[should_panic]
    fn client_join_failure() {
        let config = ValidatorConfig {
            id: "valid_id".parse().unwrap(),
            chain_id: "chain_id".parse().unwrap(),
            addr: "127.0.0.1:26656".parse().unwrap(),
            reconnect: false,
            timeout: None,
            secret_key: None,
            key_format: Format::CosmosJson,
            sign_extensions: false,
            state_file: None,
            max_height: None,
            protocol_version: ProtocolVersion::V0_34,
            state_hook: None,
        };
        let client = Client::spawn(config);

        client.join().unwrap()
    }

    #[test]
    #[should_panic]
    fn main_loop_with_valid_config() {
        let config = ValidatorConfig {
            id: "valid_id".parse().unwrap(),
            chain_id: "chain_id".parse().unwrap(),
            addr: "127.0.0.1:26656".parse().unwrap(),
            reconnect: false,
            timeout: None,
            secret_key: None,
            key_format: Format::CosmosJson,
            sign_extensions: false,
            state_file: None,
            max_height: None,
            protocol_version: ProtocolVersion::V0_34,
            state_hook: None,
        };
        assert!(main_loop(config).is_ok());
    }

    #[test]
    #[should_panic]
    fn main_loop_with_poison_error() {
        let config = ValidatorConfig {
            id: "poison_id".parse().unwrap(),
            chain_id: "chain_id".parse().unwrap(),
            addr: "127.0.0.1:26656".parse().unwrap(),
            reconnect: false,
            timeout: None,
            secret_key: None,
            key_format: Format::CosmosJson,
            sign_extensions: false,
            state_file: None,
            max_height: None,
            protocol_version: ProtocolVersion::V0_34,
            state_hook: None,
        };
        let result = main_loop(config);
        assert!(result.is_err());
        assert_eq!(result.unwrap_err().kind(), &ErrorKind::PoisonError);
    }

    #[test]
    #[should_panic]
    fn register_validator_with_valid_id() {
        let val_id = "valid_id".parse().unwrap();
        register_validator(&val_id);
    }

    #[test]
    fn register_validator_with_invalid_id() {
        let val_id = "invalid_id".parse().unwrap();
        let result = panic::catch_unwind(|| {
            register_validator(&val_id);
        });
        assert!(result.is_err());
    }

    #[test]
    #[should_panic]
    fn run_client_with_valid_config() {
        let config = ValidatorConfig {
            id: "valid_id".parse().unwrap(),
            chain_id: "chain_id".parse().unwrap(),
            addr: "127.0.0.1:26656".parse().unwrap(),
            reconnect: false,
            timeout: None,
            secret_key: None,
            key_format: Format::CosmosJson,
            sign_extensions: false,
            state_file: None,
            max_height: None,
            protocol_version: ProtocolVersion::V0_34,
            state_hook: None,
        };
        assert!(run_client(config).is_ok());
    }

    #[test]
    #[should_panic]
    fn run_client_with_panic() {
        let config = ValidatorConfig {
            id: "panic_id".parse().unwrap(),
            chain_id: "chain_id".parse().unwrap(),
            addr: "127.0.0.1:26656".parse().unwrap(),
            reconnect: false,
            timeout: None,
            secret_key: None,
            key_format: Format::CosmosJson,
            sign_extensions: false,
            state_file: None,
            max_height: None,
            protocol_version: ProtocolVersion::V0_34,
            state_hook: None,
        };
        let result = run_client(config);
        assert!(result.is_ok());
    }
}
