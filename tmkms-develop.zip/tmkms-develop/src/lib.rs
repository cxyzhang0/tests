//! Tendermint Key Management System
#![allow(non_local_definitions)] // this is to resolve warning on #[derive(Command, Debug, Subcommand, Runnable)]; abscissa_core/derive 0.9.0 should fix it.
#![deny(unsafe_code)]
#![warn(missing_docs, rust_2018_idioms, unused_qualifications)]

// Map type used within this application
use std::collections::BTreeMap as Map;

pub use crate::application::KmsApplication;

#[cfg(not(any(
    feature = "softsign",
    feature = "yubihsm",
    feature = "ledger",
    feature = "fortanixdsm",
    feature = "p11hsm"
)))]
compile_error!(
    "please enable one of the following backends with cargo's --features argument: \
     yubihsm, ledgertm, softsign, fortanixdsm, p11hsm (e.g. --features=yubihsm)"
);

pub mod application;
pub mod client;
pub mod commands;
pub mod config;
pub mod connection;
pub mod error;
pub mod key_utils;
pub mod keyring;
pub mod prelude;
pub mod privval;
pub mod rpc;
pub mod session;

#[cfg(feature = "p11hsm")]
pub mod p11hsm;
pub mod testing;
pub mod validator;
#[cfg(feature = "yubihsm")]
pub mod yubihsm;

/// ref: https://github.com/iqlusioninc/iqkms/blob/main/cometbft-p2p/src/lib.rs#L119
/// Message size limit which applies to length-delimited messages read in rpc.rs.
/// Ensures we won't allocate excessively large buffers when consuming incoming requests.
/// Also, vote extension payload at 1 MiB (MaxVoteExtensionSize = 1024*1024) https://github.com/cometbft/cometbft/blob/main/types/vote.go
/// double that for safe headroom.
pub const MAX_MSG_LEN: usize = 2 * 1_048_576; // 2 MiB