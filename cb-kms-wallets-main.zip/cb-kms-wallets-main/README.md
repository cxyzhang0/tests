# Coreblock wallets for diffrerent blockchains
# > * Cosmos