## Test Coverage - llvm-cov
```shell
cargo llvm-cov --workspace --lib --tests

cargo llvm-cov --workspace --lib --tests --fail-under-lines 80

cargo llvm-cov --lib --tests --html
# open ./target/llvm-cov/html/index.html

# sonar clippy report
cargo clippy --message-format=json > ./temp/clippy-report.json
cargo sonar --clippy --clippy-path=./temp/clippy-report.json --sonar-path ./temp/sonar-issues.json

```

## Test Coverage - tarpaulin
```shell
# test with configuration in .tarpaulin.toml
cargo tarpaulin
# test default features
cargo tarpaulin --workspace --line --engine llvm
cargo tarpaulin --workspace --line --engine llvm --exclude-files "**/*_old.rs"
```

## misc
```shell
zip -r cosmos-wallet.zip . \
  -x "target/*" \
  -x ".idea/*" \
  -x ".git/*"
```