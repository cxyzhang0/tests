## Test Coverage - llvm-cov
```shell
cargo llvm-cov --workspace --lib --tests

cargo llvm-cov --workspace --lib --tests --fail-under-lines 80

cargo llvm-cov --lib --tests --html
# open ./target/llvm-cov/html/index.html

```

## Test Coverage - tarpaulin
```shell
# test with configuration in .tarpaulin.toml
cargo tarpaulin
# test default features
cargo tarpaulin --workspace --line --engine llvm
cargo tarpaulin --workspace --line --engine llvm --exclude-files "**/*_old.rs"
```

## misc
```shell
zip -r cosmos-wallet.zip . \
  -x "target/*" \
  -x ".idea/*" \
  -x ".git/*"
```