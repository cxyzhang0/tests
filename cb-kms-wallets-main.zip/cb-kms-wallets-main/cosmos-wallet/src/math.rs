use cosmwasm_std::Uint128;

pub trait IntoUint128 {
    fn as_uint128(&self) -> Uint128;
}

impl IntoUint128 for u64 {
    fn as_uint128(&self) -> Uint128 {
        Uint128::from(*self as u128)
    }
}

pub trait IntoU64 {
    fn as_u64(&self) -> u64;
}

impl IntoU64 for Uint128 {
    fn as_u64(&self) -> u64 {
        self.u128().try_into().unwrap()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn u64_to_uint128_roundtrip() {
        let x: u64 = 42;
        let y = x.as_uint128();
        assert_eq!(y.u128(), 42);
        assert_eq!(y.as_u64(), 42);
    }

    #[test]
    #[should_panic]
    fn uint128_to_u64_panics_on_overflow() {
        // Uint128 just above u64::MAX.
        let v = Uint128::from(u64::MAX as u128 + 1);
        let _ = v.as_u64();
    }
}
