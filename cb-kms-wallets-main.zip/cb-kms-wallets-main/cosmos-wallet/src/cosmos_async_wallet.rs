//! this wallet is adapted from cosmos-grpc-client::wallet::Wallet for AsyncSigningKey.
//! it matches closely with 3.0.1 version of the original Wallet.
use crate::math::{IntoU64, IntoUint128};
use crate::utils::account_address_from_async_signing_key;
use anyhow::anyhow;
use cosmos_grpc_client::cosmos_sdk_proto::cosmos::auth::v1beta1::{
    BaseAccount, QueryAccountRequest,
};
use cosmos_grpc_client::cosmos_sdk_proto::cosmos::tx::v1beta1::{
    AuthInfo, BroadcastTxRequest, BroadcastTxResponse, SimulateRequest, SimulateResponse, TxRaw,
};
use cosmos_grpc_client::cosmos_sdk_proto::prost::Message;
use cosmos_grpc_client::cosmos_sdk_proto::Any;
use cosmos_grpc_client::{
    AnyResult, BroadcastMode, CoinType, GrpcClient, IntoAnyhowResult, OkOrAny, SharedAny,
};
use cosmrs::crypto::PublicKey;
use cosmrs::tx::{Fee, Raw, SignDoc, SignerInfo};
use cosmrs::{AccountId, Coin, Denom};
use cosmwasm_std::{Decimal, Uint128};
use injective_protobuf::proto::account::EthAccount;
use kms_commom::async_signer::AsyncSigningKey;
use protobuf::Message as _;
use sha3::{Digest, Keccak256};
use std::fmt::Debug;
use std::str::FromStr;

#[non_exhaustive]
pub struct Wallet {
    coin_type: CoinType,
    pub account_address: String,
    sign_key: AsyncSigningKey,
    pub client: GrpcClient,
    pub chain_id: String,
    pub prefix: String,
    pub account_number: u64,
    pub account_sequence: u64,
    pub gas_price: Decimal,
    pub gas_adjustment: Decimal,
    pub gas_denom: String,
}
#[allow(clippy::too_many_arguments)]
impl Wallet {
    pub async fn from_async_signing_key(
        client: GrpcClient,
        sign_key: AsyncSigningKey,
        chain_prefix: impl Into<String> + Clone,
        coin_type: impl Into<u64> + Clone,
        gas_price: Decimal,
        gas_adjustment: Decimal,
        gas_denom: impl Into<String>,
    ) -> AnyResult<Wallet> {
        Wallet::finalize_wallet_creation(
            client,
            sign_key,
            chain_prefix,
            coin_type,
            gas_price,
            gas_adjustment,
            gas_denom,
        )
        .await
    }

    pub fn account_address(&self) -> String {
        account_address_from_async_signing_key(&self.sign_key, &self.prefix)
    }

    pub async fn broadcast_tx(
        &mut self,
        msgs: Vec<impl SharedAny>,
        fee: Option<Fee>,
        memo: Option<String>,
        broadacast_mode: BroadcastMode,
    ) -> AnyResult<BroadcastTxResponse> {
        let fee = if let Some(fee) = fee {
            fee
        } else {
            let gas_used = self
                .simulate_tx(msgs.clone())
                .await?
                .gas_info
                .ok_or(anyhow!("No gas info in response"))?
                .gas_used;

            Fee {
                amount: vec![Coin {
                    denom: Denom::from_str(&self.gas_denom).into_anyresult()?,
                    amount: (self.gas_price * self.gas_adjustment * gas_used.as_uint128()
                        + Uint128::one())
                    .into(),
                }],
                gas_limit: (gas_used.as_uint128() * self.gas_adjustment - Uint128::one()).as_u64(),
                payer: None,
                granter: None,
            }
        };

        let request = BroadcastTxRequest {
            tx_bytes: self
                .create_tx(msgs, fee, memo)
                .await?
                .to_bytes()
                .into_anyresult()?,
            mode: broadacast_mode.repr(),
        };

        let res = self
            .client
            .clients
            .tx
            .clone()
            .broadcast_tx(request)
            .await?
            .into_inner();

        self.account_sequence += 1;
        Ok(res)
    }

    #[allow(deprecated)]
    pub async fn simulate_tx(&self, msgs: Vec<impl SharedAny>) -> AnyResult<SimulateResponse> {
        let tx = self
            .create_tx(
                msgs,
                Fee {
                    amount: vec![],
                    gas_limit: 0,
                    granter: None,
                    payer: None,
                },
                Some("".to_string()),
            )
            .await?;

        let request = SimulateRequest {
            tx: None,
            tx_bytes: tx.to_bytes().into_anyresult()?,
        };

        Ok(self
            .client
            .clients
            .tx
            .clone()
            .simulate(request)
            .await?
            .into_inner())
    }

    pub async fn finalize_wallet_creation(
        client: GrpcClient,
        sign_key: AsyncSigningKey,
        chain_prefix: impl Into<String> + Clone,
        coin_type: impl Into<u64> + Clone,
        gas_price: Decimal,
        gas_adjustment: Decimal,
        gas_denom: impl Into<String>,
    ) -> AnyResult<Wallet> {
        let coin_type =
            CoinType::from_repr(coin_type.into()).ok_or(anyhow!("Invalid coin type"))?;

        let account_address = match coin_type {
            CoinType::Injective => {
                let pk = sign_key.verifying_key();
                let uncompressed_bytes = pk.to_encoded_point(false).to_bytes();

                let mut hasher = Keccak256::new();
                hasher.update(&uncompressed_bytes[1..]);
                let address_bytes = hasher.finalize();
                AccountId::new("inj", &address_bytes[12..])
                    .unwrap()
                    .to_string()
            }
            _ => account_address_from_async_signing_key(&sign_key, &chain_prefix.clone().into()),
        };

        let raw_res = client
            .clients
            .auth
            .clone()
            .account(QueryAccountRequest {
                address: account_address_from_async_signing_key(
                    &sign_key,
                    &chain_prefix.clone().into(),
                ),
            })
            .await
            .map(|res| res.into_inner());

        let (number, sequence) = match raw_res {
            #[allow(clippy::match_single_binding)]
            Ok(raw_res) => match coin_type {
                CoinType::Injective => EthAccount::parse_from_bytes(
                    raw_res
                        .account
                        .ok_or_any("Error unwrapping None in raw_res.account")?
                        .value
                        .as_slice(),
                )?
                .base_account
                .map(|res| (res.account_number, res.sequence))
                .unwrap_or((0, 0)),
                _ => BaseAccount::decode(
                    &raw_res
                        .account
                        .ok_or_any("Error unwrapping None in raw_res.account")?
                        .value[..],
                )
                .map(|res| (res.account_number, res.sequence))
                .unwrap_or((0, 0)),
            },
            Err(_) => (0, 0),
        };

        Ok(Wallet {
            coin_type,
            account_address,
            sign_key,
            client: client.clone(),
            chain_id: client.chain_id.clone(),
            prefix: chain_prefix.into(),
            account_number: number,
            account_sequence: sequence,
            gas_price,
            gas_adjustment,
            gas_denom: gas_denom.into(),
        })
    }

    async fn create_tx(
        &self,
        msgs: Vec<impl SharedAny>,
        fee: Fee,
        memo: Option<String>,
    ) -> AnyResult<Raw> {
        let tx_body = cosmrs::tx::BodyBuilder::new()
            // .msgs(msgs)
            .msgs(
                msgs.into_iter()
                    .map(|val| val.into_any())
                    .collect::<Vec<Any>>(),
            )
            .memo(memo.unwrap_or("".to_string()))
            .finish();

        let public_key: PublicKey = self.sign_key.verifying_key().into();

        let auth_info =
            SignerInfo::single_direct(Some(public_key), self.account_sequence).auth_info(fee);

        let mut sign_doc = SignDoc::new(
            &tx_body,
            &auth_info,
            &self.chain_id.parse().unwrap(),
            self.account_number,
        )
        .into_anyresult()?;

        let sig = match self.coin_type {
            CoinType::Injective => {
                let mut auth_info = AuthInfo::decode(sign_doc.auth_info_bytes.as_slice()).unwrap();

                for signer_info in auth_info.signer_infos.iter_mut() {
                    signer_info.public_key.as_mut().unwrap().type_url =
                        "/injective.crypto.v1beta1.ethsecp256k1.PubKey".to_string()
                }

                sign_doc.auth_info_bytes = auth_info.encode_to_vec();

                let sign_doc_bytes = sign_doc.clone().into_bytes().unwrap();

                let digest = sha3::Keccak256::new_with_prefix(sign_doc_bytes);

                let hash: [u8; 32] = digest.finalize().into();

                self.sign_key.sign_prehash(hash).await
            }
            _ => {
                let sign_doc_bytes = sign_doc.clone().into_bytes().unwrap();

                self.sign_key.sign(&sign_doc_bytes).await
            }
        };

        Ok(TxRaw {
            body_bytes: sign_doc.body_bytes,
            auth_info_bytes: sign_doc.auth_info_bytes,
            signatures: vec![sig.to_vec()],
        }
        .into())
    }
}

impl Debug for Wallet {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("Wallet")
            .field("account_address", &self.account_address())
            .field("chain_id", &self.chain_id)
            .field("prefix", &self.prefix)
            .field("account_number", &self.account_number)
            .field("account_sequence", &self.account_sequence)
            .field("gas_price", &format!("{}", &self.gas_price))
            .field("gas_adjustment", &format!("{}", &self.gas_adjustment))
            .field("gas_denom", &self.gas_denom)
            .finish()
    }
}
