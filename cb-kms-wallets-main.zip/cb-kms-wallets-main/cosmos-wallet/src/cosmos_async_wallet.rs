//! this wallet is adapted from cosmos-grpc-client::wallet::Wallet for AsyncSigningKey.
//! it matches closely with 3.0.1 version of the original Wallet.
use crate::math::{IntoU64, IntoUint128};
use crate::utils::account_address_from_async_signing_key;
use anyhow::anyhow;
use cosmos_grpc_client::cosmos_sdk_proto::cosmos::auth::v1beta1::{
    BaseAccount, QueryAccountRequest,
};
use cosmos_grpc_client::cosmos_sdk_proto::cosmos::tx::v1beta1::{
    AuthInfo as ProtoAuthInfo, BroadcastTxRequest, BroadcastTxResponse, SimulateRequest, SimulateResponse, TxRaw,
};
use cosmos_grpc_client::cosmos_sdk_proto::prost::Message;
use cosmos_grpc_client::cosmos_sdk_proto::Any;
use cosmos_grpc_client::{
    AnyResult, BroadcastMode, CoinType, GrpcClient, IntoAnyhowResult, OkOrAny, SharedAny,
};
use cosmrs::crypto::PublicKey;
use cosmrs::tx::{Fee, Raw, SignDoc, SignerInfo};
use cosmrs::{AccountId, Coin, Denom};
use cosmwasm_std::{Decimal, Uint128};
use injective_protobuf::proto::account::EthAccount;
use kms_common::async_signer::AsyncSigningKey;
use protobuf::Message as _; // necessary for EthAccount::parse_from_bytes
use sha3::{Digest, Keccak256};
use std::fmt::Debug;
use std::str::FromStr;

/// Pure helper routines extracted for unit testing.
///
/// These functions contain the deterministic logic used by the wallet (Injective address derivation,
/// fee calculation, Injective auth-info fixes, and Injective prehashing). Keeping them separate
/// allows high line coverage without requiring a live gRPC endpoint or a real signer.
/// Note: tonic gRPC server is mocked in mod wallet_tests.
pub(crate) mod helpers {
    use super::*;

    /// Convert wallet messages into protobuf `Any`.
    pub(crate) fn msgs_into_any(msgs: Vec<impl SharedAny>) -> Vec<Any> {
        msgs.into_iter().map(|m| m.into_any()).collect()
    }

    /// Build a Tx body, mirroring the wallet implementation.
    pub(crate) fn build_tx_body(msgs: Vec<Any>, memo: Option<String>) -> cosmrs::tx::Body {
        cosmrs::tx::BodyBuilder::new()
            .msgs(msgs)
            .memo(memo.unwrap_or_else(|| "".to_string()))
            .finish()
    }

    /// Build AuthInfo (SignerInfo + Fee) for a single direct signer.
    pub(crate) fn build_auth_info(public_key: PublicKey, sequence: u64, fee: Fee) -> cosmrs::tx::AuthInfo {
        SignerInfo::single_direct(Some(public_key), sequence)
            .auth_info(fee)
            .into()
    }

    /// Build a `SignDoc` from parts.
    pub(crate) fn build_sign_doc(
        tx_body: &cosmrs::tx::Body,
        auth_info: &cosmrs::tx::AuthInfo,
        chain_id: &str,
        account_number: u64,
    ) -> AnyResult<SignDoc> {
        SignDoc::new(tx_body, auth_info, &chain_id.parse().unwrap(), account_number)
            .into_anyresult()
    }

    /// Prepare the bytes to be signed for a given coin type.
    ///
    /// For Injective we must fix the pubkey type_url in auth_info_bytes and then Keccak256
    /// prehash the whole SignDoc bytes.
    pub(crate) fn prepare_signing(
        coin_type: CoinType,
        mut sign_doc: SignDoc,
    ) -> AnyResult<(SignDoc, Vec<u8>, Option<[u8; 32]>)> {
        let sign_doc_bytes = sign_doc.clone().into_bytes().unwrap();

        match coin_type {
            CoinType::Injective => {
                sign_doc.auth_info_bytes = injective_fix_auth_info_type_urls(&sign_doc.auth_info_bytes)?;
                let fixed_sign_doc_bytes = sign_doc.clone().into_bytes().unwrap();
                let hash = injective_sign_doc_prehash(&fixed_sign_doc_bytes);
                Ok((sign_doc, fixed_sign_doc_bytes, Some(hash)))
            }
            _ => Ok((sign_doc, sign_doc_bytes, None)),
        }
    }

    /// Parse account number + sequence from the auth query response.
    ///
    /// This mirrors the wallet logic, including returning (0,0) if decoding fails.
    pub(crate) fn parse_account_number_sequence(
        coin_type: CoinType,
        account_any: Option<Any>,
    ) -> AnyResult<(u64, u64)> {
        let account_any = account_any.ok_or_any("Error unwrapping None in raw_res.account")?;

        Ok(match coin_type {
            CoinType::Injective => EthAccount::parse_from_bytes(account_any.value.as_slice())?
                .base_account
                .map(|res| (res.account_number, res.sequence))
                .unwrap_or((0, 0)),
            _ => BaseAccount::decode(&account_any.value[..])
                .map(|res| (res.account_number, res.sequence))
                .unwrap_or((0, 0)),
        })
    }

    /// Derive an Injective bech32 address (`inj...`) from an uncompressed secp256k1 public key.
    ///
    /// `uncompressed_pubkey` must be 65 bytes and start with `0x04`.
    pub(crate) fn injective_address_from_uncompressed_pubkey(
        uncompressed_pubkey: &[u8],
    ) -> AnyResult<String> {
        if uncompressed_pubkey.len() != 65 || uncompressed_pubkey[0] != 0x04 {
            return Err(anyhow!(
                "expected 65-byte uncompressed pubkey starting with 0x04"
            ));
        }

        let mut hasher = Keccak256::new();
        hasher.update(&uncompressed_pubkey[1..]);
        let address_bytes = hasher.finalize();

        // last 20 bytes are the address, same as Ethereum.
        Ok(AccountId::new("inj", &address_bytes[12..])
            .map_err(|e| anyhow!(e))?
            .to_string())
    }

    /// Compute a `Fee` from gas info and wallet pricing settings.
    pub(crate) fn calc_fee(
        gas_used: u64,
        gas_price: Decimal,
        gas_adjustment: Decimal,
        gas_denom: &str,
        fee_granter: Option<String>,
    ) -> AnyResult<Fee> {
        // Matches the production code:
        // amount = gas_price * gas_adjustment * gas_used + 1
        // gas_limit = gas_used * gas_adjustment - 1
        let amount = (gas_price * gas_adjustment * gas_used.as_uint128() + Uint128::one()).into();
        let gas_limit = (gas_used.as_uint128() * gas_adjustment - Uint128::one()).as_u64();

        let granter: Option<AccountId> = match fee_granter {
            Some(granter_str) => Some(AccountId::from_str(&granter_str).map_err(|e| anyhow!(e))?),
            None => None,
        };

        Ok(Fee {
            amount: vec![Coin {
                denom: Denom::from_str(gas_denom).into_anyresult()?,
                amount,
            }],
            gas_limit,
            payer: None,
            granter,
        })
    }

    /// Injective requires the public key type URL to be the ethsecp256k1 one.
    pub(crate) fn injective_fix_auth_info_type_urls(auth_info_bytes: &[u8]) -> AnyResult<Vec<u8>> {
        let mut auth_info = ProtoAuthInfo::decode(auth_info_bytes)?;

        for signer_info in auth_info.signer_infos.iter_mut() {
            if let Some(pk) = signer_info.public_key.as_mut() {
                pk.type_url = "/injective.crypto.v1beta1.ethsecp256k1.PubKey".to_string();
            }
        }

        Ok(auth_info.encode_to_vec())
    }

    /// Injective signs a Keccak256 prehash of the SignDoc bytes.
    pub(crate) fn injective_sign_doc_prehash(sign_doc_bytes: &[u8]) -> [u8; 32] {
        let digest = sha3::Keccak256::new_with_prefix(sign_doc_bytes);
        digest.finalize().into()
    }
}

#[non_exhaustive]
pub struct Wallet {
    coin_type: CoinType,
    pub account_address: String,
    sign_key: AsyncSigningKey,
    pub client: GrpcClient,
    pub chain_id: String,
    pub prefix: String,
    pub account_number: u64,
    pub account_sequence: u64,
    pub gas_price: Decimal,
    pub gas_adjustment: Decimal,
    pub gas_denom: String,
    pub fee_granter: Option<String>,
}
#[allow(clippy::too_many_arguments)]
impl Wallet {
    pub async fn from_async_signing_key(
        client: GrpcClient,
        sign_key: AsyncSigningKey,
        chain_prefix: impl Into<String> + Clone,
        coin_type: impl Into<u64> + Clone,
        gas_price: Decimal,
        gas_adjustment: Decimal,
        gas_denom: impl Into<String>,
        fee_granter: Option<impl Into<String>>,
    ) -> AnyResult<Wallet> {
        Wallet::finalize_wallet_creation(
            client,
            sign_key,
            chain_prefix,
            coin_type,
            gas_price,
            gas_adjustment,
            gas_denom,
            fee_granter,
        )
        .await
    }

    pub fn account_address(&self) -> String {
        account_address_from_async_signing_key(&self.sign_key, &self.prefix)
    }

    pub async fn broadcast_tx(
        &mut self,
        msgs: Vec<impl SharedAny>,
        fee: Option<Fee>,
        memo: Option<String>,
        broadacast_mode: BroadcastMode,
    ) -> AnyResult<BroadcastTxResponse> {
        let fee = if let Some(fee) = fee {
            fee
        } else {
            let gas_used = self
                .simulate_tx(msgs.clone())
                .await?
                .gas_info
                .ok_or(anyhow!("No gas info in response"))?
                .gas_used;

            helpers::calc_fee(gas_used, self.gas_price, self.gas_adjustment, &self.gas_denom, self.fee_granter.clone())?
        };

        let request = BroadcastTxRequest {
            tx_bytes: self
                .create_tx(msgs, fee, memo)
                .await?
                .to_bytes()
                .into_anyresult()?,
            mode: broadacast_mode.repr(),
        };

        let res = self
            .client
            .clients
            .tx
            .clone()
            .broadcast_tx(request)
            .await?
            .into_inner();

        self.account_sequence += 1;
        Ok(res)
    }

    #[allow(deprecated)]
    pub async fn simulate_tx(&self, msgs: Vec<impl SharedAny>) -> AnyResult<SimulateResponse> {
        let tx = self
            .create_tx(
                msgs,
                Fee {
                    amount: vec![],
                    gas_limit: 0,
                    granter: None,
                    payer: None,
                },
                Some("".to_string()),
            )
            .await?;

        let request = SimulateRequest {
            tx: None,
            tx_bytes: tx.to_bytes().into_anyresult()?,
        };

        Ok(self
            .client
            .clients
            .tx
            .clone()
            .simulate(request)
            .await?
            .into_inner())
    }

    pub async fn finalize_wallet_creation(
        client: GrpcClient,
        sign_key: AsyncSigningKey,
        chain_prefix: impl Into<String> + Clone,
        coin_type: impl Into<u64> + Clone,
        gas_price: Decimal,
        gas_adjustment: Decimal,
        gas_denom: impl Into<String>,
        fee_granter: Option<impl Into<String>>,
    ) -> AnyResult<Wallet> {
        let coin_type =
            CoinType::from_repr(coin_type.into()).ok_or(anyhow!("Invalid coin type"))?;

        let account_address = match coin_type {
            CoinType::Injective => {
                let pk = sign_key.verifying_key();
                let uncompressed_bytes = pk.to_encoded_point(false).to_bytes();

                helpers::injective_address_from_uncompressed_pubkey(&uncompressed_bytes)?
            }
            _ => account_address_from_async_signing_key(&sign_key, &chain_prefix.clone().into()),
        };

        let raw_res = client
            .clients
            .auth
            .clone()
            .account(QueryAccountRequest {
                address: account_address_from_async_signing_key(
                    &sign_key,
                    &chain_prefix.clone().into(),
                ),
            })
            .await
            .map(|res| res.into_inner());

        let (number, sequence) = match raw_res {
            Ok(raw_res) => helpers::parse_account_number_sequence(coin_type.clone(), raw_res.account)?,
            Err(_) => (0, 0),
        };

        Ok(Wallet {
            coin_type,
            account_address,
            sign_key,
            client: client.clone(),
            chain_id: client.chain_id.clone(),
            prefix: chain_prefix.into(),
            account_number: number,
            account_sequence: sequence,
            gas_price,
            gas_adjustment,
            gas_denom: gas_denom.into(),
            fee_granter: fee_granter.map(|fg| fg.into()),
        })
    }

    async fn create_tx(
        &self,
        msgs: Vec<impl SharedAny>,
        fee: Fee,
        memo: Option<String>,
    ) -> AnyResult<Raw> {
        let tx_body = helpers::build_tx_body(helpers::msgs_into_any(msgs), memo);

        let public_key: PublicKey = self.sign_key.verifying_key().into();

        let auth_info: cosmrs::tx::AuthInfo =
            helpers::build_auth_info(public_key, self.account_sequence, fee).into();

        let sign_doc = helpers::build_sign_doc(&tx_body, &auth_info, &self.chain_id, self.account_number)?;

        let (sign_doc, sign_doc_bytes, prehash) = helpers::prepare_signing(self.coin_type.clone(), sign_doc)?;

        let sig = if let Some(hash) = prehash {
            self.sign_key.sign_prehash(hash).await
        } else {
            self.sign_key.sign(&sign_doc_bytes).await
        };

        Ok(TxRaw {
            body_bytes: sign_doc.body_bytes,
            auth_info_bytes: sign_doc.auth_info_bytes,
            signatures: vec![sig.to_vec()],
        }
        .into())
    }
}

impl Debug for Wallet {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("Wallet")
            .field("account_address", &self.account_address())
            .field("chain_id", &self.chain_id)
            .field("prefix", &self.prefix)
            .field("account_number", &self.account_number)
            .field("account_sequence", &self.account_sequence)
            .field("gas_price", &format!("{}", &self.gas_price))
            .field("gas_adjustment", &format!("{}", &self.gas_adjustment))
            .field("gas_denom", &self.gas_denom)
            .field("fee_granter", &self.fee_granter)
            .finish()
    }
}

#[cfg(test)]
mod tests {
    use std::str::FromStr;
    use super::helpers;
    use cosmos_grpc_client::CoinType;
    use cosmos_grpc_client::cosmos_sdk_proto::cosmos::tx::v1beta1::{AuthInfo, SignerInfo};
    use cosmos_grpc_client::cosmos_sdk_proto::cosmos::auth::v1beta1::BaseAccount;
    use cosmos_grpc_client::cosmos_sdk_proto::Any;
    use cosmos_grpc_client::cosmos_sdk_proto::prost::Message;
    use cosmrs::tx::Fee;
    use cosmrs::{AccountId, Coin, Denom};
    use cosmwasm_std::Decimal;
    use k256::ecdsa::SigningKey;
    use k256::elliptic_curve::FieldBytes;
    use k256::Secp256k1;
    use sha3::Digest;

    #[test]
    fn account_id() {
        let addr = "wf1qaeezv8jp5kyye3ykassrt5e7vucxuy0uxp4ar";
        let account_id = AccountId::from_str(addr).expect("valid account id");
        assert_eq!(account_id.prefix(), "wf");
        assert_eq!(addr.to_string(), account_id.to_string());
    }
    #[test]
    fn injective_address_from_uncompressed_pubkey_has_inj_prefix() {
        use k256::elliptic_curve::FieldBytes;
        // Deterministic key for reproducible tests.
        let sk_bytes = [1u8; 32];
        let fb: FieldBytes<Secp256k1> = sk_bytes.into();
        let signing_key = SigningKey::from_bytes(&fb).expect("valid signing key");
        let verifying_key = signing_key.verifying_key();
        let uncompressed = verifying_key.to_encoded_point(false);
        let uncompressed_bytes = uncompressed.as_bytes();

        let addr = helpers::injective_address_from_uncompressed_pubkey(uncompressed_bytes)
            .expect("address derivation works");
        assert!(addr.starts_with("inj"));
        // bech32 addresses are longer than just the prefix.
        assert!(addr.len() > 10);
    }

    #[test]
    fn injective_address_rejects_wrong_pubkey_format() {
        let bad = [0u8; 10];
        assert!(helpers::injective_address_from_uncompressed_pubkey(&bad).is_err());
    }

    #[test]
    fn calc_fee_matches_formula() {
        let gas_used = 1_000u64;
        let gas_price = Decimal::from_ratio(25u128, 1000u128); // 0.025
        let gas_adjustment = Decimal::from_ratio(12u128, 10u128); // 1.2
        let fee = helpers::calc_fee(gas_used, gas_price, gas_adjustment, "inj", None).unwrap();

        // gas_limit = gas_used * gas_adjustment - 1 = 1000*1.2 - 1 = 1199
        assert_eq!(fee.gas_limit, 1199);
        assert_eq!(fee.amount.len(), 1);

        // amount = gas_price * gas_adjustment * gas_used + 1
        //       = 0.025 * 1.2 * 1000 + 1 = 30 + 1 = 31
        assert_eq!(fee.amount[0].amount, 31);
    }

    #[test]
    fn calc_fee_rejects_bad_denom() {
        let res = helpers::calc_fee(1, Decimal::one(), Decimal::one(), "not a denom!", None);
        assert!(res.is_err());
    }

    #[test]
    fn injective_fix_auth_info_type_urls_updates_all_signers() {
        let auth = AuthInfo {
            signer_infos: vec![SignerInfo {
                public_key: Some(Any {
                    type_url: "/cosmos.crypto.secp256k1.PubKey".to_string(),
                    value: vec![],
                }),
                mode_info: None,
                sequence: 0,
            }],
            fee: None,
            tip: None,
        };

        let bytes = auth.encode_to_vec();
        let fixed = helpers::injective_fix_auth_info_type_urls(&bytes).unwrap();
        let decoded = AuthInfo::decode(fixed.as_slice()).unwrap();

        let pk = decoded.signer_infos[0].public_key.as_ref().unwrap();
        assert_eq!(
            pk.type_url,
            "/injective.crypto.v1beta1.ethsecp256k1.PubKey"
        );
    }

    #[test]
    fn injective_sign_doc_prehash_is_keccak256() {
        let msg = b"hello";
        let h1 = helpers::injective_sign_doc_prehash(msg);

        // Independent calculation.
        let mut hasher = sha3::Keccak256::new();
        hasher.update(msg);
        let h2: [u8; 32] = hasher.finalize().into();

        assert_eq!(h1, h2);
    }

    #[test]
    fn build_tx_body_sets_msgs_and_default_memo() {
        let body = helpers::build_tx_body(vec![Any { type_url: "type".into(), value: vec![1, 2, 3] }], None);
        assert_eq!(body.memo, "");
        assert_eq!(body.messages.len(), 1);
    }

    #[test]
    fn build_auth_info_roundtrips_to_proto() {
        use k256::elliptic_curve::FieldBytes;
        let sk_bytes = [2u8; 32];
        let sb: FieldBytes::<Secp256k1> = sk_bytes.into();
        let signing_key = SigningKey::from_bytes(&sb).unwrap();
        let pk = cosmrs::crypto::PublicKey::from(signing_key.verifying_key());

        let fee = Fee {
            amount: vec![Coin { denom: Denom::from_str("uatom").unwrap(), amount: 1u64.into() }],
            gas_limit: 123,
            payer: None,
            granter: None,
        };

        let auth_info = helpers::build_auth_info(pk, 7, fee);
        // It should contain one signer info.
        assert_eq!(auth_info.signer_infos.len(), 1);
        assert_eq!(auth_info.signer_infos[0].sequence, 7);
    }

    #[test]
    fn build_sign_doc_and_prepare_signing_non_injective() {
        let chain_id = "cosmoshub-4";
        let body = helpers::build_tx_body(vec![], Some("memo".to_string()));

        let sk_bytes = [3u8; 32];
        let fb: FieldBytes<Secp256k1> = sk_bytes.into();
        let signing_key = SigningKey::from_bytes(&fb).unwrap();
        let pk = cosmrs::crypto::PublicKey::from(signing_key.verifying_key());

        let fee = Fee {
            amount: vec![],
            gas_limit: 0,
            payer: None,
            granter: None,
        };
        let auth_info = helpers::build_auth_info(pk, 0, fee);

        let sign_doc = helpers::build_sign_doc(&body, &auth_info, chain_id, 42).unwrap();
        let (_sign_doc, bytes, prehash) = helpers::prepare_signing(CoinType::from_repr(118).unwrap_or(CoinType::Cosmos), sign_doc).unwrap();
        assert!(prehash.is_none());
        assert!(!bytes.is_empty());
    }

    #[test]
    fn prepare_signing_injective_sets_prehash_and_fixes_type_url() {
        let chain_id = "injective-1";
        let body = helpers::build_tx_body(vec![], None);

        let sk_bytes = [4u8; 32];
        let fb: FieldBytes<Secp256k1> = sk_bytes.into();
        let signing_key = SigningKey::from_bytes(&fb).unwrap();
        let pk = cosmrs::crypto::PublicKey::from(signing_key.verifying_key());

        let fee = Fee {
            amount: vec![],
            gas_limit: 0,
            payer: None,
            granter: None,
        };
        let auth_info: cosmrs::tx::AuthInfo = helpers::build_auth_info(pk, 0, fee).into();
        let sign_doc = helpers::build_sign_doc(&body, &auth_info, chain_id, 0).unwrap();

        let (fixed_doc, _bytes, prehash) = helpers::prepare_signing(CoinType::Injective, sign_doc).unwrap();
        assert!(prehash.is_some());

        // Verify auth_info_bytes got its type_url rewritten.
        let decoded = AuthInfo::decode(fixed_doc.auth_info_bytes.as_slice()).unwrap();
        let pk_any = decoded.signer_infos[0].public_key.as_ref().unwrap();
        assert_eq!(pk_any.type_url, "/injective.crypto.v1beta1.ethsecp256k1.PubKey");
    }

    #[test]
    fn parse_account_number_sequence_base_account_ok() {
        let base = BaseAccount {
            address: "cosmos1deadbeef".to_string(),
            pub_key: None,
            account_number: 9,
            sequence: 11,
        };
        let any = Any { type_url: "type".into(), value: base.encode_to_vec() };
        let (n, s) = helpers::parse_account_number_sequence(CoinType::Cosmos, Some(any)).unwrap();
        assert_eq!(n, 9);
        assert_eq!(s, 11);
    }

    #[test]
    fn parse_account_number_sequence_none_is_error() {
        assert!(helpers::parse_account_number_sequence(CoinType::Cosmos, None).is_err());
    }

    #[test]
    fn parse_account_number_sequence_bad_bytes_yields_zeroes() {
        let any = Any { type_url: "type".into(), value: vec![0xde, 0xad, 0xbe, 0xef] };
        let (n, s) = helpers::parse_account_number_sequence(CoinType::Cosmos, Some(any)).unwrap();
        assert_eq!((n, s), (0, 0));
    }

    #[test]
    fn parse_account_number_sequence_injective_bad_bytes_is_error() {
        let any = Any { type_url: "type".into(), value: vec![] };
        assert!(helpers::parse_account_number_sequence(CoinType::Injective, Some(any)).is_ok());
    }
}

#[cfg(test)]
mod tests_wallet {
    use super::*;
    use async_trait::async_trait;
    use k256::ecdsa::{Signature, SigningKey};
    use k256::elliptic_curve::rand_core::OsRng;
    use signature::{Keypair, Signer};

    use kms_common::async_signer::{AsyncSigner, AsyncSigningKey};
    use kms_common::SignatureError;

    use tokio::net::TcpListener;
    use tokio::sync::oneshot;
    use tonic::{transport::Server};

    // --- AUTH query proto imports ---
    use cosmos_grpc_client::cosmos_sdk_proto::cosmos::auth::v1beta1::{AddressBytesToStringRequest, AddressBytesToStringResponse, AddressStringToBytesRequest, AddressStringToBytesResponse, BaseAccount, Bech32PrefixRequest, Bech32PrefixResponse, QueryAccountAddressByIdRequest, QueryAccountAddressByIdResponse, QueryAccountsRequest, QueryAccountsResponse, QueryModuleAccountByNameRequest, QueryModuleAccountByNameResponse, QueryModuleAccountsRequest, QueryModuleAccountsResponse, QueryParamsRequest, QueryParamsResponse};
    use cosmos_grpc_client::cosmos_sdk_proto::cosmos::auth::v1beta1::query_server::{Query, QueryServer};
    use cosmos_grpc_client::cosmos_sdk_proto::cosmos::auth::v1beta1::{QueryAccountRequest, QueryAccountResponse};
    use injective_protobuf::proto::auth::BaseAccount as InjBaseAccount;
    use protobuf::Message as ProtobufMessage;
    use protobuf::SingularPtrField;
    // --- TX service proto imports ---
    use cosmos_grpc_client::cosmos_sdk_proto::cosmos::tx::v1beta1::service_server::{Service, ServiceServer};
    use cosmos_grpc_client::cosmos_sdk_proto::cosmos::tx::v1beta1::{BroadcastTxRequest, BroadcastTxResponse, GetBlockWithTxsRequest, GetBlockWithTxsResponse, GetTxRequest, GetTxResponse, GetTxsEventRequest, GetTxsEventResponse, SimulateRequest, SimulateResponse};

    // --- Any ---
    use cosmos_grpc_client::cosmos_sdk_proto::Any;
    use cosmos_grpc_client::cosmos_sdk_proto::prost::Message;

    // ---- Mock Tendermint service ----
    use cosmos_grpc_client::cosmos_sdk_proto::cosmos::base::tendermint::v1beta1::service_server::{
        Service as TmService, ServiceServer as TmServiceServer,
    };
    use cosmos_grpc_client::cosmos_sdk_proto::cosmos::base::tendermint::v1beta1::{AbciQueryRequest, AbciQueryResponse, GetBlockByHeightRequest, GetBlockByHeightResponse, GetLatestBlockRequest, GetLatestBlockResponse, GetLatestValidatorSetRequest, GetLatestValidatorSetResponse, GetNodeInfoRequest, GetNodeInfoResponse, GetSyncingRequest, GetSyncingResponse, GetValidatorSetByHeightRequest, GetValidatorSetByHeightResponse};
    use cosmos_grpc_client::cosmos_sdk_proto::tendermint::v0_34::p2p::DefaultNodeInfo;

    use cosmos_grpc_client::BroadcastMode;

    #[derive(Default)]
    struct MockTendermintService;

    #[async_trait::async_trait]
    impl TmService for MockTendermintService {
        async fn get_node_info(
            &self,
            _request: tonic::Request<GetNodeInfoRequest>,
        ) -> Result<tonic::Response<GetNodeInfoResponse>, tonic::Status> {
            // GrpcClient::new requires node info to exist.
            // The chain-id/network is commonly read from `default_node_info.network`.
            let node_info = DefaultNodeInfo {
                network: "test-chain".to_string(),
                ..Default::default()
            };

            Ok(tonic::Response::new(GetNodeInfoResponse {
                default_node_info: Some(node_info),
                ..Default::default()
            }))

            // Some clients call this instead. Returning a default response is often enough.
            // Ok(tonic::Response::new(GetNodeInfoResponse::default()))
        }

        async fn get_syncing(&self, _request: tonic::Request<GetSyncingRequest>) -> Result<tonic::Response<GetSyncingResponse>, tonic::Status> {
            Err(tonic::Status::unimplemented("mock"))
        }

        async fn get_latest_block(
            &self,
            _request: tonic::Request<GetLatestBlockRequest>,
        ) -> Result<tonic::Response<GetLatestBlockResponse>, tonic::Status> {
            // Return a minimal response. GrpcClient::new usually only needs chain_id.
            // Many SDKs pull chain_id from the block header.
            let resp = GetLatestBlockResponse::default();

            Ok(tonic::Response::new(resp))
        }

        async fn get_block_by_height(&self, _request: tonic::Request<GetBlockByHeightRequest>) -> Result<tonic::Response<GetBlockByHeightResponse>, tonic::Status> {
            Err(tonic::Status::unimplemented("mock"))
        }

        async fn get_latest_validator_set(&self, _request: tonic::Request<GetLatestValidatorSetRequest>) -> Result<tonic::Response<GetLatestValidatorSetResponse>, tonic::Status> {
            Err(tonic::Status::unimplemented("mock"))
        }

        async fn get_validator_set_by_height(&self, _request: tonic::Request<GetValidatorSetByHeightRequest>) -> Result<tonic::Response<GetValidatorSetByHeightResponse>, tonic::Status> {
            Err(tonic::Status::unimplemented("mock"))
        }

        async fn abci_query(&self, _request: tonic::Request<AbciQueryRequest>) -> Result<tonic::Response<AbciQueryResponse>, tonic::Status> {
            Err(tonic::Status::unimplemented("mock"))
        }
    }

    // ---- Mock Auth Query service ----
    #[derive(Default)]
    struct MockAuthQuery;

    #[async_trait]
    impl Query for MockAuthQuery {
        async fn accounts(&self, _request: tonic::Request<QueryAccountsRequest>) -> Result<tonic::Response<QueryAccountsResponse>, tonic::Status> {
            Err(tonic::Status::unimplemented("mock"))
        }

        async fn account(
            &self,
            request: tonic::Request<QueryAccountRequest>,
        ) -> Result<tonic::Response<QueryAccountResponse>, tonic::Status> {
            let addr = request.get_ref().address.clone();

            let base = BaseAccount {
                address: addr.clone(),
                pub_key: None,
                account_number: 7,
                sequence: 11,
            };

            if addr.starts_with("inj") {
                // Injective rust-protobuf BaseAccount
                let mut inj_base = InjBaseAccount::new();
                inj_base.address = addr.clone();
                inj_base.account_number = 7;
                inj_base.sequence = 11;
                // pub_key is optional; leave default unless wallet requires it

                // Injective EthAccount wraps BaseAccount in SingularPtrField
                let mut eth = EthAccount::new();
                eth.base_account = SingularPtrField::some(inj_base);
                eth.code_hash = vec![];

                let buf = eth.write_to_bytes().unwrap();

                let any = Any {
                    type_url: "/injective.types.v1beta1.EthAccount".to_string(),
                    value: buf,
                };

                Ok(tonic::Response::new(QueryAccountResponse { account: Some(any) }))
            } else {
                // Cosmos BaseAccount as before
                let mut buf = Vec::new();
                base.encode(&mut buf).unwrap();

                let any = Any {
                    type_url: "/cosmos.auth.v1beta1.BaseAccount".to_string(),
                    value: buf,
                };

                Ok(tonic::Response::new(QueryAccountResponse { account: Some(any) }))
            }
        }

        async fn account_address_by_id(&self, _request: tonic::Request<QueryAccountAddressByIdRequest>) -> Result<tonic::Response<QueryAccountAddressByIdResponse>, tonic::Status> {
            Err(tonic::Status::unimplemented("mock"))
        }

        async fn params(&self, _request: tonic::Request<QueryParamsRequest>) -> Result<tonic::Response<QueryParamsResponse>, tonic::Status> {
            Err(tonic::Status::unimplemented("mock"))
        }

        async fn module_accounts(&self, _request: tonic::Request<QueryModuleAccountsRequest>) -> Result<tonic::Response<QueryModuleAccountsResponse>, tonic::Status> {
            Err(tonic::Status::unimplemented("mock"))
        }

        async fn module_account_by_name(&self, _request: tonic::Request<QueryModuleAccountByNameRequest>) -> Result<tonic::Response<QueryModuleAccountByNameResponse>, tonic::Status> {
            Err(tonic::Status::unimplemented("mock"))
        }

        async fn bech32_prefix(&self, _request: tonic::Request<Bech32PrefixRequest>) -> Result<tonic::Response<Bech32PrefixResponse>, tonic::Status> {
            Err(tonic::Status::unimplemented("mock"))
        }

        async fn address_bytes_to_string(&self, _request: tonic::Request<AddressBytesToStringRequest>) -> Result<tonic::Response<AddressBytesToStringResponse>, tonic::Status> {
            Err(tonic::Status::unimplemented("mock"))
        }

        async fn address_string_to_bytes(&self, _request: tonic::Request<AddressStringToBytesRequest>) -> Result<tonic::Response<AddressStringToBytesResponse>, tonic::Status> {
            Err(tonic::Status::unimplemented("mock"))
        }
    }

    // ---- Mock Tx Service ----
    #[derive(Default)]
    struct MockTxService;

    #[async_trait]
    impl Service for MockTxService {
        async fn simulate(
            &self,
            _request: tonic::Request<SimulateRequest>,
        ) -> Result<tonic::Response<SimulateResponse>, tonic::Status> {
            // Intentionally fail (but method is executed => coverage)
            Err(tonic::Status::unavailable("simulate not available in mock"))
        }

        async fn get_tx(&self, _request: tonic::Request<GetTxRequest>) -> Result<tonic::Response<GetTxResponse>, tonic::Status> {
            Err(tonic::Status::unimplemented("mock"))
        }

        async fn broadcast_tx(
            &self,
            _request: tonic::Request<BroadcastTxRequest>,
        ) -> Result<tonic::Response<BroadcastTxResponse>, tonic::Status> {
            // Intentionally fail (but method is executed => coverage)
            Err(tonic::Status::unavailable("broadcast not available in mock"))
        }

        async fn get_txs_event(&self, _request: tonic::Request<GetTxsEventRequest>) -> Result<tonic::Response<GetTxsEventResponse>, tonic::Status> {
            Err(tonic::Status::unimplemented("mock"))
        }

        async fn get_block_with_txs(&self, _request: tonic::Request<GetBlockWithTxsRequest>) -> Result<tonic::Response<GetBlockWithTxsResponse>, tonic::Status> {
            Err(tonic::Status::unimplemented("mock"))
        }
    }

    // ---- Start server helper ----
    async fn start_mock_grpc_server() -> (String, oneshot::Sender<()>) {
        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let addr = listener.local_addr().unwrap();
        let endpoint = format!("http://{}", addr);

        let (tx_shutdown, rx_shutdown) = oneshot::channel::<()>();

        tokio::spawn(async move {
            Server::builder()
                .add_service(QueryServer::new(MockAuthQuery::default()))
                .add_service(ServiceServer::new(MockTxService::default()))
                .add_service(TmServiceServer::new(MockTendermintService::default()))
                .serve_with_incoming_shutdown(
                    tokio_stream::wrappers::TcpListenerStream::new(listener),
                    async {
                        let _ = rx_shutdown.await;
                    },
                )
                .await
                .unwrap();
        });

        (endpoint, tx_shutdown)
    }

    // ---- Test signer (local, no network) ----

    struct LocalAsyncSigner(SigningKey);

    impl Keypair for LocalAsyncSigner {
        type VerifyingKey = <SigningKey as Keypair>::VerifyingKey;

        fn verifying_key(&self) -> Self::VerifyingKey {
            *self.0.verifying_key()
        }
    }

    #[async_trait]
    impl AsyncSigner for LocalAsyncSigner {
        async fn try_sign(&self, msg: &[u8]) -> Result<Signature, SignatureError> {
            self.0.try_sign(msg)
        }

        async fn try_sign_prehash(&self, msg_hash: [u8; 32]) -> Result<Signature, SignatureError> {
            self.0.try_sign(&msg_hash)
        }
    }

    fn make_test_async_signing_key() -> AsyncSigningKey {
        let sk = SigningKey::random(&mut OsRng);
        AsyncSigningKey::new(Box::new(LocalAsyncSigner(sk)))
    }

    #[test]
    fn decimal() {
        let d = Decimal::from_ratio(1u128, 1000u128);
        assert_eq!(d.to_string(), "0.001");

        let d = Decimal::from_ratio(2u128, 1u128);
        assert_eq!(d.to_string(), "2");

        let d = Decimal::new(2u64.as_uint128());
        assert_eq!(d.to_string(), "0.000000000000000002");
    }

    // ---- Test 0: wallet creation succeeds, address/debug succeed, create_tx succeeds, other calls fail ----
    #[tokio::test]
    async fn wallet_happy_then_network_fails() {
        let (endpoint, shutdown) = start_mock_grpc_server().await;

        let client = GrpcClient::new(endpoint)
            .await
            .expect("GrpcClient connects to mock server");

        let sign_key = make_test_async_signing_key();

        let mut wallet = Wallet::from_async_signing_key(
            client,
            sign_key,
            "wf",
            118u64,         // coin type (118 cosmos, 60 injective eth-style, etc.)
            Decimal::from_ratio(1u128, 1000u128), // gas price
            Decimal::from_ratio(2u128, 1u128), // gas price
            "uwfUSD".to_string(), // fee denom / native denom (adjust)
            None::<String>,
        )
            .await
            .expect("wallet creation should succeed (auth query may fail but should be handled)");

        // 1) account_address succeeds
        let addr = wallet.account_address();
        assert!(!addr.is_empty());

        // 2) Debug fmt succeeds
        let _ = format!("{wallet:?}");

        // 3) create_tx succeeds (local signer)
        // Adjust create_tx signature + msgs type as needed.
        let msgs: Vec<cosmrs::Any> = vec![];
        let _tx_raw = wallet
            .create_tx(msgs.clone(), helpers::calc_fee(74000, wallet.gas_price, wallet.gas_adjustment, &wallet.gas_denom, wallet.fee_granter.clone()).unwrap(), Some("memo".to_string()))
            .await
            .expect("create_tx should succeed");

        // 4) other fns fail (but run)
        assert!(wallet.simulate_tx(msgs.clone()).await.is_err());
        assert!(wallet.broadcast_tx(
            msgs.clone(),
            Some(helpers::calc_fee(74000, wallet.gas_price, wallet.gas_adjustment, &wallet.gas_denom, wallet.fee_granter.clone()).unwrap()),
            Some("test memo".to_string()),
            BroadcastMode::Sync,
        ).await.is_err());

        assert!(wallet.broadcast_tx(
            msgs,
            None,
            Some("test memo".to_string()),
            BroadcastMode::Sync,
        ).await.is_err());

        // clean shutdown
        let _ = shutdown.send(());
    }

    // ---- Test 0: wallet creation succeeds, address/debug succeed, create_tx succeeds, other calls fail ----
    #[tokio::test]
    async fn inject_wallet_happy_then_network_fails() {
        let (endpoint, shutdown) = start_mock_grpc_server().await;

        let client = GrpcClient::new(endpoint)
            .await
            .expect("GrpcClient connects to mock server");

        let sign_key = make_test_async_signing_key();

        let mut wallet = Wallet::from_async_signing_key(
            client,
            sign_key,
            "inj",
            60u64,         // coin type (118 cosmos, 60 injective eth-style, etc.)
            Decimal::from_ratio(1u128, 1000u128), // gas price
            Decimal::from_ratio(2u128, 1u128), // gas price
            "uwfUSD".to_string(), // fee denom / native denom (adjust)
            None::<String>,
        )
            .await
            .expect("wallet creation should succeed (auth query may fail but should be handled)");

        // 1) account_address succeeds
        let addr = wallet.account_address();
        assert!(!addr.is_empty());

        // 2) Debug fmt succeeds
        let _ = format!("{wallet:?}");

        // 3) create_tx succeeds (local signer)
        // Adjust create_tx signature + msgs type as needed.
        let msgs: Vec<cosmrs::Any> = vec![];
        let _tx_raw = wallet
            .create_tx(msgs.clone(), helpers::calc_fee(74000, wallet.gas_price, wallet.gas_adjustment, &wallet.gas_denom, wallet.fee_granter.clone()).unwrap(), Some("memo".to_string()))
            .await
            .expect("create_tx should succeed");

        // 4) other fns fail (but run)
        assert!(wallet.simulate_tx(msgs.clone()).await.is_err());
        assert!(wallet.broadcast_tx(
            msgs.clone(),
            Some(helpers::calc_fee(74000, wallet.gas_price, wallet.gas_adjustment, &wallet.gas_denom, wallet.fee_granter.clone()).unwrap()),
            Some("test memo".to_string()),
            BroadcastMode::Sync,
        ).await.is_err());

        assert!(wallet.broadcast_tx(
            msgs,
            None,
            Some("test memo".to_string()),
            BroadcastMode::Sync,
        ).await.is_err());

        // clean shutdown
        let _ = shutdown.send(());
    }

    // ---- Test 1: construct wallet, address + Debug succeed ----
    #[tokio::test]
    async fn wallet_construct_address_and_debug_succeed() {
        let (endpoint, shutdown) = start_mock_grpc_server().await;
        let client = GrpcClient::new(endpoint)
            .await
            .expect("client construction should succeed even if RPC endpoint is unreachable");

        let sign_key = make_test_async_signing_key();

        let wallet = Wallet::from_async_signing_key(
            client,
            sign_key,
            "wf",
            118u64,         // coin type (118 cosmos, 60 injective eth-style, etc.)
            Decimal::from_ratio(1u128, 1000u128), // gas price
            Decimal::from_ratio(2u128, 1u128), // gas price
            "uwfUSD".to_string(), // fee denom / native denom (adjust)
            None::<String>,
        )
            .await
            .expect("wallet creation should succeed (auth query may fail but should be handled)");

        // account_address() should succeed deterministically
        let addr = wallet.account_address();
        assert!(!addr.is_empty());

        // Debug formatting should succeed
        let dbg = format!("{wallet:?}");
        assert!(!dbg.is_empty());
        // clean shutdown
        let _ = shutdown.send(());
    }

    // ---- Test 2: create_tx succeeds (signing is local) ----
    #[tokio::test]
    async fn wallet_create_tx_succeeds() {
        let (endpoint, shutdown) = start_mock_grpc_server().await;

        let client = GrpcClient::new(endpoint)
            .await
            .expect("client construction should succeed");

        let sign_key = make_test_async_signing_key();

        let wallet = Wallet::from_async_signing_key(
            client,
            sign_key,
            "wf",
            118u64,         // coin type (118 cosmos, 60 injective eth-style, etc.)
            Decimal::from_ratio(1u128, 1000u128), // gas price
            Decimal::from_ratio(2u128, 1u128), // gas price
            "uwfUSD".to_string(), // fee denom / native denom (adjust)
            None::<String>,
        )
            .await
            .expect("wallet creation should succeed (auth query may fail but should be handled)");

        // Build a minimal Tx body:
        let msgs: Vec<cosmrs::Any> = vec![];

        let tx_raw = wallet
            .create_tx(msgs.clone(), helpers::calc_fee(74000, wallet.gas_price, wallet.gas_adjustment, &wallet.gas_denom, wallet.fee_granter.clone()).unwrap(), Some("memo".to_string()))
            .await
            .expect("create_tx should succeed because signing is local");

        // Sanity checks: tx_raw has body/auth_info/signature bytes
        assert!(tx_raw.to_bytes().is_ok());

        // clean shutdown
        let _ = shutdown.send(());

    }

    // ---- Test 3: network functions fail (but execute Wallet impl paths) ----
    #[tokio::test]
    async fn wallet_network_calls_fail_but_execute_paths() {
        let (endpoint, shutdown) = start_mock_grpc_server().await;

        let client = GrpcClient::new(endpoint)
            .await
            .expect("client construction should succeed");

        let sign_key = make_test_async_signing_key();

        let mut wallet = Wallet::from_async_signing_key(
            client,
            sign_key,
            "wf",
            118u64,         // coin type (118 cosmos, 60 injective eth-style, etc.)
            Decimal::from_ratio(1u128, 1000u128), // gas price
            Decimal::from_ratio(2u128, 1u128), // gas price
            "uwfUSD".to_string(), // fee denom / native denom (adjust)
            Some("wf1qaeezv8jp5kyye3ykassrt5e7vucxuy0uxp4ar"),
        )
            .await
            .expect("wallet creation should succeed (auth query may fail but should be handled)");

        // Create a tx first (so simulate/broadcast have something to work with).
        let msgs: Vec<cosmrs::Any> = vec![];
        let _tx_raw = wallet
            .create_tx(msgs.clone(), helpers::calc_fee(74000, wallet.gas_price, wallet.gas_adjustment, &wallet.gas_denom, wallet.fee_granter.clone()).unwrap(), Some("memo".to_string()))
            .await
            .expect("create_tx should succeed");

        // Now call methods that will require gRPC and thus fail due to unreachable endpoint.
        // simulate
        let sim = wallet.simulate_tx(msgs.clone()).await;
        assert!(sim.is_err());

        // broadcast
        let br = wallet.broadcast_tx(
            msgs,
            Some(helpers::calc_fee(74000, wallet.gas_price, wallet.gas_adjustment, &wallet.gas_denom, wallet.fee_granter.clone()).unwrap()),
            Some("test memo".to_string()),
            BroadcastMode::Sync,
        ).await;
        assert!(br.is_err());

        let acc = wallet.account_address();
        assert!(!acc.is_empty());

        // clean shutdown
        let _ = shutdown.send(());
    }

    #[tokio::test]
    async fn mock_services_unimplemented_methods_are_covered() {
        let (endpoint, shutdown) = start_mock_grpc_server().await;

        // Build raw tonic clients directly to call the RPCs.
        // (Paths may differ slightly in your proto module; adjust imports if needed.)
        let channel = tonic::transport::Endpoint::from_shared(endpoint)
            .unwrap()
            .connect()
            .await
            .unwrap();

        let mut auth = cosmos_grpc_client::cosmos_sdk_proto::cosmos::auth::v1beta1::query_client::QueryClient::new(channel.clone());
        let mut tm = cosmos_grpc_client::cosmos_sdk_proto::cosmos::base::tendermint::v1beta1::service_client::ServiceClient::new(channel.clone());
        let mut tx = cosmos_grpc_client::cosmos_sdk_proto::cosmos::tx::v1beta1::service_client::ServiceClient::new(channel);

        // --- Auth query: call all the “unimplemented” endpoints once ---
        assert_eq!(
            auth.accounts(QueryAccountsRequest { pagination: None }).await.unwrap_err().code(),
            tonic::Code::Unimplemented
        );
        assert_eq!(
            auth.account_address_by_id(QueryAccountAddressByIdRequest { id: 1 }).await.unwrap_err().code(),
            tonic::Code::Unimplemented
        );
        assert_eq!(
            auth.params(QueryParamsRequest {}).await.unwrap_err().code(),
            tonic::Code::Unimplemented
        );
        assert_eq!(
            auth.module_accounts(QueryModuleAccountsRequest {}).await.unwrap_err().code(),
            tonic::Code::Unimplemented
        );
        assert_eq!(
            auth.module_account_by_name(QueryModuleAccountByNameRequest { name: "x".into() }).await.unwrap_err().code(),
            tonic::Code::Unimplemented
        );
        assert_eq!(
            auth.bech32_prefix(Bech32PrefixRequest {}).await.unwrap_err().code(),
            tonic::Code::Unimplemented
        );
        assert_eq!(
            auth.address_bytes_to_string(AddressBytesToStringRequest { address_bytes: vec![1,2,3] }).await.unwrap_err().code(),
            tonic::Code::Unimplemented
        );
        assert_eq!(
            auth.address_string_to_bytes(AddressStringToBytesRequest { address_string: "cosmos1x".into() }).await.unwrap_err().code(),
            tonic::Code::Unimplemented
        );

        // --- Tx service client ---

        // simulate -> Unavailable (your impl returns unavailable)
        assert_eq!(
            tx.simulate(SimulateRequest { tx: None, tx_bytes: vec![] })
                .await
                .unwrap_err()
                .code(),
            tonic::Code::Unavailable
        );

        // broadcast_tx -> Unavailable
        assert_eq!(
            tx.broadcast_tx(BroadcastTxRequest {
                tx_bytes: vec![],
                mode: 0, // BROADCAST_MODE_UNSPECIFIED is fine for a mock
            })
                .await
                .unwrap_err()
                .code(),
            tonic::Code::Unavailable
        );

        // get_tx -> Unimplemented
        assert_eq!(
            tx.get_tx(GetTxRequest { hash: "00".into() })
                .await
                .unwrap_err()
                .code(),
            tonic::Code::Unimplemented
        );

        // get_txs_event -> Unimplemented
        assert_eq!(
            tx.get_txs_event(GetTxsEventRequest {
                events: vec![],
                pagination: None,
                order_by: 0,
                page: 0,
                limit: 0,
            })
                .await
                .unwrap_err()
                .code(),
            tonic::Code::Unimplemented
        );

        // get_block_with_txs -> Unimplemented
        assert_eq!(
            tx.get_block_with_txs(GetBlockWithTxsRequest {
                height: 1,
                pagination: None,
            })
                .await
                .unwrap_err()
                .code(),
            tonic::Code::Unimplemented
        );

        // --- Tendermint service client ---

        // get_node_info -> OK (your impl returns Some(default_node_info))
        let ni = tm
            .get_node_info(GetNodeInfoRequest {})
            .await
            .expect("get_node_info should succeed");
        assert!(ni.into_inner().default_node_info.is_some());

        // get_latest_block -> OK (you return default response)
        let _ = tm
            .get_latest_block(GetLatestBlockRequest {})
            .await
            .expect("get_latest_block should succeed");

        // the rest -> Unimplemented
        assert_eq!(
            tm.get_syncing(GetSyncingRequest {})
                .await
                .unwrap_err()
                .code(),
            tonic::Code::Unimplemented
        );

        assert_eq!(
            tm.get_block_by_height(GetBlockByHeightRequest { height: 1 })
                .await
                .unwrap_err()
                .code(),
            tonic::Code::Unimplemented
        );

        assert_eq!(
            tm.get_latest_validator_set(GetLatestValidatorSetRequest { pagination: None })
                .await
                .unwrap_err()
                .code(),
            tonic::Code::Unimplemented
        );

        assert_eq!(
            tm.get_validator_set_by_height(GetValidatorSetByHeightRequest {
                height: 1,
                pagination: None,
            })
                .await
                .unwrap_err()
                .code(),
            tonic::Code::Unimplemented
        );

        assert_eq!(
            tm.abci_query(AbciQueryRequest {
                path: "".into(),
                data: vec![],
                height: 0,
                prove: false,
            })
                .await
                .unwrap_err()
                .code(),
            tonic::Code::Unimplemented
        );

        let _ = shutdown.send(());
    }

}
