use cosmwasm_std::{StdError, StdResult};

#[allow(clippy::wrong_self_convention)]
pub trait _IntoStdError: std::error::Error {
    fn into_std_error(&self) -> StdError {
        StdError::generic_err(self.to_string())
    }
}

pub trait IntoStdResult<T> {
    fn into_std_result(self) -> StdResult<T>;
}

impl<T, E> IntoStdResult<T> for Result<T, E>
where
    E: std::error::Error,
{
    fn into_std_result(self) -> StdResult<T> {
        self.map_err(|err| StdError::generic_err(err.to_string()))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fmt;

    #[derive(Debug)]
    struct DummyError;

    impl fmt::Display for DummyError {
        fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
            write!(f, "dummy")
        }
    }

    impl std::error::Error for DummyError {}

    impl _IntoStdError for DummyError {}

    #[test]
    fn into_std_error_preserves_message() {
        let e = DummyError;
        let std_err = e.into_std_error();
        assert!(std_err.to_string().contains("dummy"));
    }

    #[test]
    fn into_std_result_maps_error_to_std_error() {
        let r: Result<u32, DummyError> = Err(DummyError);
        let std_r = r.into_std_result();
        assert!(std_r.is_err());
        assert!(std_r.unwrap_err().to_string().contains("dummy"));
    }
}
