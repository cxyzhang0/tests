//! this wallet is adapted from cosmos-grpc-client::wallet::Wallet for AsyncSigningKey.
//! even though it runs against 3.0.1 of cosmos-grpc-client,
//! it matches in style with the old 0.24.0 version of the original Wallet.
use cosmos_grpc_client::cosmos_sdk_proto::cosmos::auth::v1beta1::{
    BaseAccount, QueryAccountRequest,
};
use cosmos_grpc_client::cosmos_sdk_proto::cosmos::tx::v1beta1::{
    BroadcastTxRequest, BroadcastTxResponse, SimulateRequest, SimulateResponse,
};
use cosmos_grpc_client::cosmos_sdk_proto::prost::Message;
use cosmos_grpc_client::cosmos_sdk_proto::Any;
use cosmos_grpc_client::{BroadcastMode, CoinType, GrpcClient, OkOrAny};
use cosmrs::tx::{Fee, Raw, SignDoc, SignerInfo};
use cosmrs::{proto, Coin, Denom};
use cosmwasm_std::{Decimal, StdResult, Uint128};
use injective_protobuf::proto::account::EthAccount;
use protobuf::Message as _;
use std::fmt::Debug;
use std::str::FromStr;

use crate::errors::IntoStdResult;
use crate::math::{IntoU64, IntoUint128};
use crate::utils::account_address_from_async_signing_key;
use cosmrs::crypto::PublicKey;
use kms_common::async_signer::AsyncSigningKey;

#[non_exhaustive]
pub struct Wallet {
    sign_key: AsyncSigningKey,
    // signer: MpcSigner0,
    pub chain_id: String,
    pub prefix: String,
    pub account_number: u64,
    pub account_sequence: u64,
    pub gas_price: Decimal,
    pub gas_adjustment: Decimal,
    pub gas_denom: String,
}
#[allow(clippy::too_many_arguments)]
impl Wallet {
    pub async fn from_async_signing_key(
        client: &mut GrpcClient,
        sign_key: AsyncSigningKey,
        chain_prefix: impl Into<String> + Clone,
        coin_type: impl Into<u64> + Clone,
        gas_price: Decimal,
        gas_adjustment: Decimal,
        gas_denom: impl Into<String>,
    ) -> StdResult<Wallet> {
        // let sign_key = MpcSigningKey::new(Box::new(signer));

        Wallet::finalize_wallet_creation(
            client,
            sign_key,
            chain_prefix,
            coin_type,
            gas_price,
            gas_adjustment,
            gas_denom,
        )
        .await
    }

    pub fn account_address(&self) -> String {
        account_address_from_async_signing_key(&self.sign_key, &self.prefix)
    }

    pub async fn broadcast_tx(
        &mut self,
        client: &mut GrpcClient,
        msgs: Vec<Any>,
        fee: Option<Fee>,
        memo: Option<String>,
        broadacast_mode: BroadcastMode,
    ) -> StdResult<BroadcastTxResponse> {
        let fee = if let Some(fee) = fee {
            fee
        } else {
            let gas_used = self
                .simulate_tx(client, msgs.clone())
                .await?
                .gas_info
                .unwrap()
                .gas_used;

            println!("{gas_used}");

            Fee {
                amount: vec![Coin {
                    denom: Denom::from_str(&self.gas_denom).unwrap(),
                    amount: (self.gas_price * self.gas_adjustment * gas_used.as_uint128()
                        + Uint128::one())
                    .into(),
                }],
                gas_limit: (gas_used.as_uint128() * self.gas_adjustment - Uint128::one()).as_u64(),
                payer: None,
                granter: None,
            }
        };

        let request = BroadcastTxRequest {
            tx_bytes: self.create_tx(msgs, fee, memo).await.to_bytes().unwrap(),
            mode: broadacast_mode.repr(),
        };

        let res = client
            .clients
            .tx
            .broadcast_tx(request)
            .await
            .into_std_result()?
            .into_inner();

        self.account_sequence += 1;
        Ok(res)
    }

    #[allow(deprecated)]
    pub async fn simulate_tx(
        &mut self,
        client: &mut GrpcClient,
        msgs: Vec<Any>,
    ) -> StdResult<SimulateResponse> {
        let tx = self
            .create_tx(
                msgs,
                Fee {
                    amount: vec![],
                    gas_limit: 0,
                    granter: None,
                    payer: None,
                },
                Some("".to_string()),
            )
            .await;

        let request = SimulateRequest {
            tx: None,
            tx_bytes: tx.to_bytes().unwrap(),
        };

        Ok(client
            .clients
            .tx
            .simulate(request)
            .await
            .into_std_result()?
            .into_inner())
    }

    pub async fn finalize_wallet_creation(
        client: &mut GrpcClient,
        sign_key: AsyncSigningKey,
        chain_prefix: impl Into<String> + Clone,
        coin_type: impl Into<u64> + Clone,
        gas_price: Decimal,
        gas_adjustment: Decimal,
        gas_denom: impl Into<String>,
    ) -> StdResult<Wallet> {
        let raw_res = client
            .clients
            .auth
            .account(QueryAccountRequest {
                address: account_address_from_async_signing_key(
                    &sign_key,
                    &chain_prefix.clone().into(),
                ),
            })
            .await
            .map(|res| res.into_inner())
            .into_std_result();

        let (number, sequence) = match raw_res {
            Ok(raw_res) => match CoinType::from_repr(coin_type.into()) {
                Some(CoinType::Injective) => {
                    EthAccount::parse_from_bytes(raw_res.account.unwrap().value.as_slice())
                        .into_std_result()?
                        .base_account
                        .map(|res| (res.account_number, res.sequence))
                        .unwrap_or((0, 0))
                }
                _ => BaseAccount::decode(
                    &raw_res
                        .account
                        .ok_or_any("Error unwrapping None in raw_res.account")
                        .unwrap()
                        .value[..],
                )
                .map(|res| (res.account_number, res.sequence))
                .unwrap_or((0, 0)),
                // _ => BaseAccount::from_any(&raw_res.account.unwrap())
                //     .map(|res| (res.account_number, res.sequence))
                //     .unwrap_or((0, 0)),
            },
            Err(_) => (0, 0),
        };

        Ok(Wallet {
            sign_key,
            chain_id: client.chain_id.clone(),
            prefix: chain_prefix.into(),
            account_number: number,
            account_sequence: sequence,
            gas_price,
            gas_adjustment,
            gas_denom: gas_denom.into(),
        })
    }

    async fn create_tx(&mut self, msgs: Vec<Any>, fee: Fee, memo: Option<String>) -> Raw {
        let tx_body = cosmrs::tx::BodyBuilder::new()
            .msgs(msgs)
            .memo(memo.unwrap_or("".to_string()))
            .finish();

        let public_key: PublicKey = self.sign_key.verifying_key().into();

        let auth_info =
            SignerInfo::single_direct(Some(public_key), self.account_sequence).auth_info(fee);

        let sign_doc = SignDoc::new(
            &tx_body,
            &auth_info,
            &self.chain_id.parse().unwrap(),
            self.account_number,
        )
        .unwrap();

        let sign_doc_bytes = sign_doc.clone().into_bytes().unwrap();
        let signature = self.sign_key.sign(&sign_doc_bytes).await;

        proto::cosmos::tx::v1beta1::TxRaw {
            body_bytes: sign_doc.clone().body_bytes,
            auth_info_bytes: sign_doc.auth_info_bytes,
            signatures: vec![signature.to_vec()],
        }
        .into()
    }
}

impl Debug for Wallet {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("Wallet")
            .field("account_address", &self.account_address())
            .field("chain_id", &self.chain_id)
            .field("prefix", &self.prefix)
            .field("account_number", &self.account_number)
            .field("account_sequence", &self.account_sequence)
            .field("gas_price", &format!("{}", &self.gas_price))
            .field("gas_adjustment", &format!("{}", &self.gas_adjustment))
            .field("gas_denom", &self.gas_denom)
            .finish()
    }
}
