use cosmrs::crypto::PublicKey;
use kms_common::async_signer::AsyncSigningKey;

/// Derive a bech32 account address from a Cosmos `PublicKey`.
pub(crate) fn account_address_from_pubkey(pubkey: &PublicKey, prefix: &str) -> String {
    pubkey.account_id(prefix).unwrap().into()
}

pub fn account_address_from_async_signing_key(sign_key: &AsyncSigningKey, prefix: &str) -> String {
    let public_key = PublicKey::from(sign_key.verifying_key());
    account_address_from_pubkey(&public_key, prefix)
}

#[cfg(test)]
mod tests {
    use super::*;
    use k256::ecdsa::SigningKey;

    #[test]
    fn account_address_from_pubkey_returns_prefixed_address() {
        // deterministic key
        let sk_bytes = [7u8; 32];
        let signing_key = SigningKey::from_bytes(&sk_bytes.into()).expect("valid signing key");
        let verifying_key = signing_key.verifying_key();
        let pk = PublicKey::from(verifying_key);

        let addr = account_address_from_pubkey(&pk, "cosmos");
        assert!(addr.starts_with("cosmos"));
        assert!(addr.len() > "cosmos".len() + 10);
    }
}
