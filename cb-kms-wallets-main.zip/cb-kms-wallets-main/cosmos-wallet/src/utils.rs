use cosmrs::crypto::PublicKey;
use kms_commom::async_signer::AsyncSigningKey;

pub fn account_address_from_async_signing_key(sign_key: &AsyncSigningKey, prefix: &str) -> String {
    let public_key = PublicKey::from(sign_key.verifying_key());
    public_key.account_id(prefix).unwrap().into()
}
