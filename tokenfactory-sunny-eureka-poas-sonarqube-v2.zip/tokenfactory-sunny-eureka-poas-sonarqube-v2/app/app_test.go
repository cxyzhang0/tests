package app_test

import (
	"encoding/json"
	"os"
	"path/filepath"
	"sync"
	"testing"

	"cosmossdk.io/log"
	abci "github.com/cometbft/cometbft/abci/types"
	"github.com/cosmos/cosmos-sdk/server"
	"github.com/cosmos/cosmos-sdk/server/config"
	paramtypes "github.com/cosmos/cosmos-sdk/x/params/types"
	"github.com/spf13/cast"
	"github.com/spf13/viper"
	"github.com/wfblockchain/coreblockchain/v2/app"

	tmtypes "github.com/cometbft/cometbft/proto/tendermint/types"
	dbm "github.com/cosmos/cosmos-db"
	"github.com/cosmos/cosmos-sdk/client"
	"github.com/cosmos/cosmos-sdk/server/api"
	sdktypes "github.com/cosmos/cosmos-sdk/types"
	authtypes "github.com/cosmos/cosmos-sdk/x/auth/types"
	stakingkeeper "github.com/cosmos/cosmos-sdk/x/staking/keeper"
	"github.com/cosmos/ibc-go/modules/capability/keeper"
	ibckeeper "github.com/cosmos/ibc-go/v10/modules/core/keeper"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"
	tftypes "github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"
)

type MockAppOptions struct {
	options map[string]interface{}
	mu      sync.RWMutex
}

func NewMockAppOptions(options map[string]interface{}) MockAppOptions {
	return MockAppOptions{
		options: options,
	}
}

func (m *MockAppOptions) Get(key string) interface{} {
	m.mu.RLock()
	defer m.mu.RUnlock()
	return m.options[key]
}

func TestNewApp(t *testing.T) {
	logger := log.NewNopLogger()
	db := dbm.NewMemDB()
	traceStore, err := os.Create("trace.log")
	require.NoError(t, err, "failed to create traceStore")
	defer traceStore.Close()

	appOpts := NewMockAppOptions(map[string]interface{}{
		"pruning": "default",
	})
	application := app.New(logger, db, traceStore, true, &appOpts)
	require.NotNil(t, application, "New() should return a non-nil App instance")
	require.NotNil(t, application.BaseApp, "BaseApp should be initialized")
	require.NotNil(t, application.InterfaceRegistry(), "InterfaceRegistry should be set")
	require.Equal(t, "tokenfactory", application.Name(), "App name should be correct")
}

func setupApp(t *testing.T) *app.App {
	logger := log.NewNopLogger()
	db := dbm.NewMemDB()
	tempDir := t.TempDir()

	traceStore, err := os.Create(filepath.Join(tempDir, "trace.log"))
	require.NoError(t, err, "Failed to create trace log")

	appOpts := NewMockAppOptions(map[string]interface{}{
		"pruning": "default",
		"home":    tempDir,
	})

	return app.New(logger, db, traceStore, true, &appOpts)
}

type mockAppOptions struct {
	options map[string]interface{}
}

func (m *mockAppOptions) Get(key string) interface{} {
	return m.options[key]
}

func TestSkipUpgradeHeights(t *testing.T) {
	appOpts := &mockAppOptions{
		options: map[string]interface{}{
			server.FlagUnsafeSkipUpgrades: []int{10, 20, 30},
		},
	}

	skipUpgradeHeights := make(map[int64]bool)

	for _, h := range cast.ToIntSlice(appOpts.Get(server.FlagUnsafeSkipUpgrades)) {
		skipUpgradeHeights[int64(h)] = true
	}

	require.True(t, skipUpgradeHeights[10], "Height 10 should be skipped")
	require.True(t, skipUpgradeHeights[20], "Height 20 should be skipped")
	require.True(t, skipUpgradeHeights[30], "Height 30 should be skipped")
	require.False(t, skipUpgradeHeights[40], "Height 40 should NOT be skipped")
	appOpts = &mockAppOptions{
		options: map[string]interface{}{},
	}

	skipUpgradeHeights = make(map[int64]bool)

	for _, h := range cast.ToIntSlice(appOpts.Get(server.FlagUnsafeSkipUpgrades)) {
		skipUpgradeHeights[int64(h)] = true
	}

	require.Len(t, skipUpgradeHeights, 0, "No heights should be skipped when input is empty")
	appOpts = &mockAppOptions{
		options: map[string]interface{}{
			server.FlagUnsafeSkipUpgrades: "invalid",
		},
	}

	skipUpgradeHeights = make(map[int64]bool)

	for _, h := range cast.ToIntSlice(appOpts.Get(server.FlagUnsafeSkipUpgrades)) {
		skipUpgradeHeights[int64(h)] = true
	}

	require.Len(t, skipUpgradeHeights, 0, "No heights should be skipped when input is invalid")
}

func TestGetBaseApp(t *testing.T) {
	application := setupApp(t)

	baseApp := application.GetBaseApp()
	require.NotNil(t, baseApp, "GetBaseApp should return a non-nil BaseApp instance")
}

func TestGetIBCKeeper(t *testing.T) {
	app := setupApp(t)
	ibcKeeper := app.GetIBCKeeper()
	require.NotNil(t, ibcKeeper, "IBCKeeper should not be nil")
	require.IsType(t, &ibckeeper.Keeper{}, ibcKeeper, "IBCKeeper should be of type *ibckeeper.Keeper")
}

func TestGetStakingKeeper(t *testing.T) {
	app := setupApp(t)
	stakingKeeper := app.GetStakingKeeper()
	require.NotNil(t, stakingKeeper, "StakingKeeper should not be nil")
	require.IsType(t, stakingkeeper.Keeper{}, stakingKeeper, "StakingKeeper should be of type keeper.Keeper")
}

func TestGetScopedIBCKeeper(t *testing.T) {
	app := setupApp(t)
	scopedIBCKeeper := app.GetScopedIBCKeeper()
	require.NotNil(t, scopedIBCKeeper, "ScopedIBCKeeper should not be nil")
	require.IsType(t, keeper.ScopedKeeper{}, scopedIBCKeeper, "ScopedIBCKeeper should be of type *capabilitykeeper.ScopedKeeper")
}

func TestConfigurator(t *testing.T) {
	myApp := setupApp(t)
	require.NotNil(t, myApp.Configurator(), "Configurator should not be nil")
}

func TestPreBlocker(t *testing.T) {
	myApp := setupApp(t)
	ctx := myApp.NewContext(true)
	resp, err := myApp.PreBlocker(ctx, &abci.RequestFinalizeBlock{})
	require.NoError(t, err, "PreBlocker should not return an error")
	require.NotNil(t, resp, "PreBlocker response should not be nil")
}

func TestModuleAccountAddrs(t *testing.T) {
	myApp := setupApp(t)
	modAccAddrs := myApp.ModuleAccountAddrs()
	require.NotEmpty(t, modAccAddrs, "ModuleAccountAddrs should not return an empty map")
	for acc := range app.GetMaccPerms() {
		addr := authtypes.NewModuleAddress(acc).String()
		require.True(t, modAccAddrs[addr], "Module account address should exist in the map")
	}
}

func TestBlockedModuleAccountAddrs(t *testing.T) {
	myApp := setupApp(t)
	blockedModAccAddrs := myApp.BlockedModuleAccountAddrs()
	require.NotEmpty(t, blockedModAccAddrs, "BlockedModuleAccountAddrs should not return an empty map")
	for acc := range myApp.ModuleAccountAddrs() {
		require.True(t, blockedModAccAddrs[acc], "Module account address should exist in the blocked list")
	}
}

func TestLegacyAmino(t *testing.T) {
	myApp := setupApp(t)
	legacyAmino := myApp.LegacyAmino()
	require.NotNil(t, legacyAmino, "LegacyAmino should not be nil")
}

func TestTxConfig(t *testing.T) {
	myApp := setupApp(t)
	txConfig := myApp.TxConfig()
	require.NotNil(t, txConfig, "TxConfig should not be nil")
}

func TestAutoCliOpts(t *testing.T) {
	myApp := setupApp(t)
	autoCliOpts := myApp.AutoCliOpts()
	require.NotNil(t, autoCliOpts.Modules, "AutoCliOpts Modules should not be nil")
	require.NotNil(t, autoCliOpts.ModuleOptions, "AutoCliOpts ModuleOptions should not be nil")
	require.NotNil(t, autoCliOpts.AddressCodec, "AutoCliOpts AddressCodec should not be nil")
	require.NotNil(t, autoCliOpts.ValidatorAddressCodec, "AutoCliOpts ValidatorAddressCodec should not be nil")
	require.NotNil(t, autoCliOpts.ConsensusAddressCodec, "AutoCliOpts ConsensusAddressCodec should not be nil")
}

func TestAppCodec(t *testing.T) {
	myApp := setupApp(t)

	appCodec := myApp.AppCodec()
	require.NotNil(t, appCodec, "AppCodec should not be nil")
}

func TestGetKey(t *testing.T) {
	myApp := setupApp(t)
	storeKey := authtypes.StoreKey
	key := myApp.GetKey(storeKey)
	require.NotNil(t, key, "GetKey should return a valid KVStoreKey for store: %s", storeKey)
	nonExistentKey := "nonexistent"
	nilKey := myApp.GetKey(nonExistentKey)
	require.Nil(t, nilKey, "GetKey should return nil for an unknown store key")
}

func TestGetTKey(t *testing.T) {
	myApp := setupApp(t)
	storeKey := paramtypes.TStoreKey
	key := myApp.GetTKey(storeKey)
	require.NotNil(t, key, "GetTKey should return a valid TransientStoreKey for store: %s", storeKey)
	nonExistentKey := "nonexistent"
	nilKey := myApp.GetTKey(nonExistentKey)
	require.Nil(t, nilKey, "GetTKey should return nil for an unknown store key")
}

func TestSimulationManager(t *testing.T) {
	myApp := setupApp(t)
	simManager := myApp.SimulationManager()
	require.NotNil(t, simManager, "SimulationManager should not be nil")
}

type MockModuleManager struct {
	mock.Mock
}

func TestRegisterAPIRoutes(t *testing.T) {
	var opts = viper.NewWithOptions(viper.KeyDelimiter("."))
	app := app.New(log.NewNopLogger(), dbm.NewMemDB(), nil, true, opts)

	var apiSvr *api.Server = api.New(client.Context{}, log.NewNopLogger(), nil)

	app.RegisterAPIRoutes(apiSvr, config.APIConfig{})
}

func TestRegisterTendermintService(t *testing.T) {
	var opts = viper.NewWithOptions(viper.KeyDelimiter("."))
	app := app.New(log.NewNopLogger(), dbm.NewMemDB(), nil, true, opts)

	app.RegisterTendermintService(client.Context{})
}

func TestInitChainer(t *testing.T) {
	var opts = viper.NewWithOptions(viper.KeyDelimiter("."))
	app := app.New(log.NewNopLogger(), dbm.NewMemDB(), nil, true, opts)

	genesisState := tftypes.DefaultGenesisState()
	stateBytes, err := json.MarshalIndent(genesisState, "", " ")
	require.NoError(t, err)

	// 3. Create the mock RequestInitChain
	req := abci.RequestInitChain{
		ChainId:         "test-chain-id",
		Validators:      []abci.ValidatorUpdate{}, // Can be populated if testing validator set changes
		AppStateBytes:   stateBytes,
		ConsensusParams: &tmtypes.ConsensusParams{},
	}

	//memDB, _ := dbm.NewDB("TestRegisterTendermintService", dbm.MemDBBackend, "")

	// 3. Create the top-level CommitMultiStore (CMS)
	// The `store` here is the package name of "github.com/cosmos/cosmos-sdk/store"

	/*
		mse := store.NewCommitMultiStore(memDB, log.NewNopLogger(), nil)
		storekey := storetypes.NewKVStoreKey("upgrade")
		mse.MountStoreWithDB(storekey, storetypes.StoreTypeIAVL, memDB)
	*/
	err = app.LoadLatestVersion()
	require.NoError(t, err, "LoadLatestVersion should not return an error")
	_, err = app.InitChainer(sdktypes.NewContext(nil, tmtypes.Header{}, false, log.NewNopLogger()), &req)
	require.NoError(t, err, "InitChainer should not return an error")
}
