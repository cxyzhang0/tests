package app

import (
	corestore "cosmossdk.io/core/store"
	errorsmod "cosmossdk.io/errors"
	circuitante "cosmossdk.io/x/circuit/ante"
	wasmkeeper "github.com/CosmWasm/wasmd/x/wasm/keeper"
	wasmtypes "github.com/CosmWasm/wasmd/x/wasm/types"
	"github.com/cosmos/cosmos-sdk/codec/types"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/cosmos/cosmos-sdk/x/auth/ante"
	govtypes "github.com/cosmos/cosmos-sdk/x/gov/types"
	ibcante "github.com/cosmos/ibc-go/v10/modules/core/ante"
	ibckeeper "github.com/cosmos/ibc-go/v10/modules/core/keeper"
	tferrors "github.com/wfblockchain/coreblockchain/v2/app/errors"
	"github.com/wfblockchain/coreblockchain/v2/x/poas"
	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory"
	tokenfactorykeeper "github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/keeper"
)

type HandlerOptions struct {
	ante.HandlerOptions
	CircuitKeeper         circuitante.CircuitBreaker
	tokenFactoryKeeper    *tokenfactorykeeper.Keeper
	IBCKeeper             *ibckeeper.Keeper
	WasmConfig            *wasmtypes.NodeConfig //*wasm.Config is deprecated; use *wasmtypes.NodeConfig instead
	TXCounterStoreService corestore.KVStoreService
	interfaceRegistry     types.InterfaceRegistry
}

// these are moved to x/tokenfactory/ante_tf.go
/*
type IsPausedDecorator struct {
	tokenFactory     *tokenfactorykeeper.Keeper
	fiatTokenFactory *tokenfactorykeeper.Keeper
}

func NewIsPausedDecorator(tf *tokenfactorykeeper.Keeper, ctf *tokenfactorykeeper.Keeper) IsPausedDecorator {
	return IsPausedDecorator{
		tokenFactory:     tf,
		fiatTokenFactory: ctf,
	}
}

// AnteHandle checks if the token factory is paused before processing any transaction of one of the minting tokens.
// note: circlefin fiattokenfactory has evolved and this handler mostly resembles their 2004-03 release.
func (ad IsPausedDecorator) AnteHandle(ctx sdk.Context, tx sdk.Tx, simulate bool, next sdk.AnteHandler) (newCtx sdk.Context, err error) {
	msgs := tx.GetMsgs()
	for _, m := range msgs {
		switch m := m.(type) { // this outer switch is redundant.
		case *banktypes.MsgSend, *banktypes.MsgMultiSend, *transfertypes.MsgTransfer:
			switch m := m.(type) {
			case *banktypes.MsgSend:
				for _, c := range m.Amount {
					paused, err := checkPausedStatebyTokenFactory(ctx, c, ad.tokenFactory, ad.fiatTokenFactory)
					if paused {
						return ctx, errorsmod.Wrapf(err, "can not perform token transactions")
					}
				}
			case *banktypes.MsgMultiSend:
				for _, i := range m.Inputs {
					for _, c := range i.Coins {
						paused, err := checkPausedStatebyTokenFactory(ctx, c, ad.tokenFactory, ad.fiatTokenFactory)
						if paused {
							return ctx, errorsmod.Wrapf(err, "can not perform token transactions")
						}
					}
				}
			case *transfertypes.MsgTransfer:
				paused, err := checkPausedStatebyTokenFactory(ctx, m.Token, ad.tokenFactory, ad.fiatTokenFactory)
				if paused {
					return ctx, errorsmod.Wrapf(err, "can not perform token transactions")
				}
			default:
				continue
			}
		default:
			continue
		}
	}
	return next(ctx, tx, simulate)
}

// checkPausedStatebyTokenFactory first checks if the token denom is a minting denom of the tokenfactory.
// if it is, it checks if the tokenfactory is paused. If so, it returns true with an error so the handler can stop processing the transaction.
// that means if the denom is not a minting or the factory is not paused, it returns false with no error.
func checkPausedStatebyTokenFactory(ctx sdk.Context, c sdk.Coin, tf *tokenfactorykeeper.Keeper, ctf *tokenfactory.Keeper) (bool, *errorsmod.Error) {
	tfMintingDenom, found := tf.GetMintingDenom(ctx, c.Denom)
	if found {
		if c.Denom == tfMintingDenom.Denom { // this should be always true because found is true; double check for safety
			paused := tf.GetPaused(ctx)
			if paused.Paused {
				return true, tokenfactorytypes.ErrPaused
			}
		}
			//ctfMintingDenom := ctf.GetMintingDenom(ctx)
			//if c.Denom == ctfMintingDenom.Denom {
			//	paused := ctf.GetPaused(ctx)
			//	if paused.Paused {
			//		return true, fiattokenfactorytypes.ErrPaused
			//	}
			//}
	}
	return false, nil
}

type IsBlacklistedDecorator struct {
	tokenfactory     *tokenfactory.Keeper
	fiattokenfactory *tokenfactory.Keeper
}

func NewIsBlacklistedDecorator(tf *tokenfactory.Keeper, ctf *tokenfactory.Keeper) IsBlacklistedDecorator {
	return IsBlacklistedDecorator{
		tokenfactory:     tf,
		fiattokenfactory: ctf,
	}
}

// AnteHandle checks if the addresses in the tx are blacklisted if the tx is on one of the minting tokens.
// note: circlefin fiattokenfactory has evolved and this handler mostly resembles their 2004-03 release.
func (ad IsBlacklistedDecorator) AnteHandle(ctx sdk.Context, tx sdk.Tx, simulate bool, next sdk.AnteHandler) (newCtx sdk.Context, err error) {
	msgs := tx.GetMsgs()
	for _, m := range msgs {
		switch m := m.(type) { // this outer switch is redundant.
		case *banktypes.MsgSend, *banktypes.MsgMultiSend, *transfertypes.MsgTransfer:
			switch m := m.(type) {
			case *banktypes.MsgSend:
				for _, c := range m.Amount {
					addresses := []string{m.ToAddress, m.FromAddress}
					blacklisted, address, err := checkForBlacklistedAddressByTokenFactory(ctx, addresses, c, ad.tokenfactory, ad.fiattokenfactory)
					if blacklisted {
						return ctx, errorsmod.Wrapf(err, "an address (%s) is blacklisted and can not send or receive tokens", address)
					}
					if err != nil {
						return ctx, errorsmod.Wrapf(err, "error decoding address (%s)", address)
					}
				}
			case *banktypes.MsgMultiSend:
				for _, i := range m.Inputs {
					for _, c := range i.Coins {
						addresses := []string{i.Address}
						blacklisted, address, err := checkForBlacklistedAddressByTokenFactory(ctx, addresses, c, ad.tokenfactory, ad.fiattokenfactory)
						if blacklisted {
							return ctx, errorsmod.Wrapf(err, "an address (%s) is blacklisted and can not send or receive tokens", address)
						}
						if err != nil {
							return ctx, errorsmod.Wrapf(err, "error decoding address (%s)", address)
						}
					}
				}
				for _, o := range m.Outputs {
					for _, c := range o.Coins {
						addresses := []string{o.Address}
						blacklisted, address, err := checkForBlacklistedAddressByTokenFactory(ctx, addresses, c, ad.tokenfactory, ad.fiattokenfactory)
						if blacklisted {
							return ctx, errorsmod.Wrapf(err, "an address (%s) is blacklisted and can not send or receive tokens", address)
						}
						if err != nil {
							return ctx, errorsmod.Wrapf(err, "error decoding address (%s)", address)
						}
					}
				}
			case *transfertypes.MsgTransfer:
				addresses := []string{m.Sender, m.Receiver}
				blacklisted, address, err := checkForBlacklistedAddressByTokenFactory(ctx, addresses, m.Token, ad.tokenfactory, ad.fiattokenfactory)
				if blacklisted {
					return ctx, errorsmod.Wrapf(err, "an address (%s) is blacklisted and can not send or receive tokens", address)
				}
				if err != nil {
					return ctx, errorsmod.Wrapf(err, "error decoding address (%s)", address)
				}
			}
		default:
			continue
		}
	}
	return next(ctx, tx, simulate)
}

// checkForBlacklistedAddressByTokenFactory first checks if the token denom is a minting denom of the tokenFactory,
// if it is, it checks if any address involved is blacklisted, if yes, return true, with the address and error.
// otherwise, if the denom is not a minting denom or none of the addresses is blacklisted, it returns false with no error.
// note: in case one address is not decodable, it returns false with the address and error so the calling handler will stop processing the transaction.
func checkForBlacklistedAddressByTokenFactory(ctx sdk.Context, addresses []string, c sdk.Coin, tf *tokenfactory.Keeper, ctf *tokenfactory.Keeper) (blacklisted bool, blacklistedAddress string, err error) {
	tfMintingDenom, found := tf.GetMintingDenom(ctx, c.Denom)
	if found {
		if c.Denom == tfMintingDenom.Denom {
			for _, address := range addresses {
				_, addressBz, err := bech32.DecodeAndConvert(address)
				if err != nil {
					return false, address, err
				}
				_, found := tf.GetBlacklisted(ctx, addressBz)
				if found {
					return true, address, tokenfactorytypes.ErrUnauthorized
				}
			}
		}
			//ctfMintingDenom := ctf.GetMintingDenom(ctx)
			//if c.Denom == ctfMintingDenom.Denom {
			//	for _, address := range addresses {
			//		_, addressBz, err := bech32.DecodeAndConvert(address)
			//		if err != nil {
			//			return false, address, err
			//		}
			//		_, found := ctf.GetBlacklisted(ctx, addressBz)
			//		if found {
			//			return true, address, fiattokenfactorytypes.ErrUnauthorized
			//		}
			//	}
			//}
	}
	return false, "", nil
}
*/

func NewAnteHandler(options HandlerOptions) (sdk.AnteHandler, error) {
	if options.AccountKeeper == nil {
		return nil, errorsmod.Wrap(tferrors.ErrLogic, "account keeper is required for AnteHandler")
	}
	if options.BankKeeper == nil {
		return nil, errorsmod.Wrap(tferrors.ErrLogic, "bank keeper is required for AnteHandler")
	}
	if options.SignModeHandler == nil {
		return nil, errorsmod.Wrap(tferrors.ErrLogic, "sign mode handler is required for AnteHandler")
	}
	if options.IBCKeeper == nil {
		return nil, errorsmod.Wrap(tferrors.ErrLogic, "IBC keeper is required for AnteHandler")
	}

	anteDecorators := []sdk.AnteDecorator{
		ante.NewSetUpContextDecorator(), // outermost AnteDecorator. SetUpContext must be called first

		wasmkeeper.NewLimitSimulationGasDecorator(options.WasmConfig.SimulationGasLimit), // after setup context to enforce limits early
		wasmkeeper.NewCountTXDecorator(options.TXCounterStoreService),

		// todo: test these two. for some reason, they were removed in the recent codebase as of 2025-7-15.
		//	 compare these with those in circlefin fiattokenfactory.
		tokenfactory.NewIsPausedDecorator(options.tokenFactoryKeeper, options.tokenFactoryKeeper),
		tokenfactory.NewIsBlacklistedDecorator(options.tokenFactoryKeeper, options.tokenFactoryKeeper),

		circuitante.NewCircuitBreakerDecorator(options.CircuitKeeper), // gaia does not have circuit breaker decorator.

		ante.NewExtensionOptionsDecorator(options.ExtensionOptionChecker),
		ante.NewValidateBasicDecorator(),
		ante.NewTxTimeoutHeightDecorator(),
		ante.NewValidateMemoDecorator(options.AccountKeeper),
		ante.NewConsumeGasForTxSizeDecorator(options.AccountKeeper),

		// note: gaia has a gov vote decorator. do we need it?

		// gaia does not have deduct fee decorator. is this related to feegrant? we need feegrant.
		ante.NewDeductFeeDecorator(options.AccountKeeper, options.BankKeeper, options.FeegrantKeeper, options.TxFeeChecker),

		ante.NewSetPubKeyDecorator(options.AccountKeeper), // SetPubKeyDecorator must be called before all signature verification decorators
		ante.NewValidateSigCountDecorator(options.AccountKeeper),
		ante.NewSigGasConsumeDecorator(options.AccountKeeper, options.SigGasConsumer),
		ante.NewSigVerificationDecorator(options.AccountKeeper, options.SignModeHandler),
		ante.NewIncrementSequenceDecorator(options.AccountKeeper),
		ibcante.NewRedundantRelayDecorator(options.IBCKeeper),

		poas.NewPoASDecorator(options.AccountKeeper.GetModuleAddress(govtypes.ModuleName), options.interfaceRegistry),

		// note: gaia has a fee market check decorator.
	}

	return sdk.ChainAnteDecorators(anteDecorators...), nil
}
