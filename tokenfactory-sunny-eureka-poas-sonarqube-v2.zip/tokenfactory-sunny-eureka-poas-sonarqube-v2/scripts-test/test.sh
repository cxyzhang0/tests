#!/bin/bash

set -o nounset -o errexit -o pipefail -o errtrace

trap 'echo EXITED: "$(BASH_SOURCE)" "${LINENO}"' ERR

#artifactory_proxy

echo
echo "Running"

go test -v -cover -coverprofile cover.out $@ ./...

echo go tool cover -html=cover.out

echo
echo SUCCESSFUL
echo