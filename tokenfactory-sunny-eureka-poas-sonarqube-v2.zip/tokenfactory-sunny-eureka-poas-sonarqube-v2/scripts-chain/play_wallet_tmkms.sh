#!/bin/bash

# !! PLEASE ONLY RUN THIS SCRIPT IN A TESTING ENVIRONMENT !!
#   THIS SCRIPT:
#     - Stops/starts tfd binary

# This script is meant for quick experimentation of the Tokenfactory Module and tokenfactory Chain functionality.
# - Initialize, configure and start tokenfactory chain
# - - validators' account keys are derived from mnemonics in `../scripts-july/seeds/`
# - - validator's tendermint key is pre-generated in HSM and is accessed via tmkms.
# - - - it corresponds tmkms/.tmkms-p11-val-all/tmkms-tf.toml
# - - all other keys are backed up hsm
# - - poas-specific configuration settings
# - - future eureka compatible
# - - uwfUSD as gas/staking token
# - Delagates and funds all privledged accounts for the `tokenfactory`.
# - todo: parameters hard-coded for distribution, gov, staking, slashing, mint and crisis. do we need to parameterize them?

# Run instructions
# run in root
# - ./scripts-chain/play_wallet_tmkms.sh
# - source ./scripts-chain/chains_wallet_tmkms.env


killall tfd
sleep 2
[ -d "./scripts-chain/play_wallet_tmkms_sh" ] && rm -r "./scripts-chain/play_wallet_tmkms_sh"

BINARY="./bin/tfd"
CHAIN_ID="tokenfactory-1"
CHAIN_DIR="./scripts-chain/play_wallet_tmkms_sh"
RPCPORT="26657"
P2PPORT="26656"
PROFPORT="6060"
GRPCPORT="9090"
VALIDATOR_PORT="26658"

MINIMUM_GAS_PRICE="0.001uwfUSD"

KEYRING="--keyring-backend=test"

HOME_DIR="$CHAIN_DIR/$CHAIN_ID"
NODE_HOME="--home=$HOME_DIR"
NODE_CHAIN_ID="--chain-id=$CHAIN_ID"
GAS=(--gas-prices "0.001uwfUSD" --gas "auto" --gas-adjustment 2.0)

TF_MINTING_DENOM='wfUSD'
TF_MINTING_CENT_DENOM='wfCENT'
TF_MINTING_BASEDENOM="u$TF_MINTING_DENOM"

STAKE_DENOM=$TF_MINTING_BASEDENOM
DENOM=$STAKE_DENOM

# The keys are stored in SoftHSM with labels as "Slot Token 0/wfdc2/owner/1", "Slot Token 0/wfdc2/masterminter/1", "Slot Token 0/wfdc2/mintercontroller/1", "Slot Token 0/wfdc2/minter/1", "Slot Token 0/wfdc2/blacklister/1", "Slot Token 0/wfdc2/pauser/1", "Slot Token 0/wfdc2/usa/1", "Slot Token 0/wfdc2/can/1", "Slot Token 0/wfdc2/user1/1", "Slot Token 0/wfdc2/user2/1"
# SoftHSM keys
FAUCET="wf1qaeezv8jp5kyye3ykassrt5e7vucxuy0uxp4ar" #"Slot Token 0/wfdc2/faucet/1"

TF_OWNER='wf1v939lk0wvq3daxafadvs07ekcg67am7dsyrap7'
MASTERMINTER='wf16f4zjgvu0m5msxh552vx9wqcv78hru9j50ymdj'
MINTERCONTROLLER='wf1etnzw2lhydq7dw7uz66qkxwxv9jpcsqu00w5uf'
MINTER='wf1kzegqsp06gfsyzkxxzpgfalakl3y2uydphn0qv'
BLACKLISTER='wf1009sd3s088g9wmwqag6pmghr5a429jaaq7rjdj'
PAUSER='wf1nvcy5hz3d55lnndhsnhzs4rpu86dpk046h7dnt'

USA='wf12atm0klmhpp6mp768gf0esxmwcjx8mmazagyvf'
CAN='wf1jetp404420sfvjshy9mtp7r8uy87jcym4cskda'
USER1='wf18jvphye4nnlxs4j2p6py3w3ct30emuuq2h7w9q'
USER2='wf13s7azh9xj3x83amz22tr4z73c4dyj0rvej9my4'

# The keys are stored in FX Virtucrypt with labels as "Slot Token 0/wfdc2/owner/1", "Slot Token 0/wfdc2/masterminter/1", "Slot Token 0/wfdc2/mintercontroller/1", "Slot Token 0/wfdc2/minter/1", "Slot Token 0/wfdc2/blacklister/1", "Slot Token 0/wfdc2/pauser/1", "Slot Token 0/wfdc2/usa/1", "Slot Token 0/wfdc2/can/1", "Slot Token 0/wfdc2/user1/1", "Slot Token 0/wfdc2/user2/1"
# FX keys
#TF_OWNER='wf1eakrd6mswtje95ldtqrrxw3x55srz76mqe4t0y'
#MASTERMINTER='wf1zfkmjasvwf4k0zfxc5tp6v244puv3828gd4fhh'
#MINTERCONTROLLER='wf1pwhh02knkd3f9l07ev0f4uhshfeestwhr4h9e8'
#MINTER='wf1cvfvwus3rmqak8sgf5h4fepduju6m7yukzuw8w'
#BLACKLISTER='wf1cpgjhv9lusjgrgkqvwxssngmjats6g9y7nc5l9'
#PAUSER='wf1e4rdj38zrm8gtl8xm4vdh4lvrl3e3ktqkjx8yl'

#USA='wf1n44er0cd6c33ms0x4a9k75lq0xq4uxw3th5dap'
#CAN='wf1hydfahkz2e78c9c429jhh33x39p5x2umas47d4'
#USER1='wf19vgaytzeut4apyhv8ykp5azwf4pghe7thr7n22'
#USER2='wf1jptxe988ycf8zank8cjkgsd5fmv2muhjkh9xc3'

#FAUCET="wf10jx70tt90upg5pt9yayvm6vgrmkhmzspavsfl3" #"Slot Token 0/wfdc2/faucet/1"

# Validator key - SoftHSM keys
PUBKEY_1="{\"@type\":\"/cosmos.crypto.ed25519.PubKey\",\"key\":\"zS+bYwcwtDE5ID/jSqw5KcXXyHolxrJEge7HqQNmq+Q=\"}" #Slot Token 0/tmkms/ed25519-1/1

# Validator key - FX keys
#PUBKEY_1="{\"@type\":\"/cosmos.crypto.ed25519.PubKey\",\"key\":\"9fvps1uCAV1vi7aIHQLW+IBbRvrEwRAlT1aK+DtsCU4=\"}" #Slot Token 0/tmkms/ed25519-1/1


SILENT=1

redirect() {
  if [ "$SILENT" -eq 1 ]; then
    "$@" > /dev/null 2>&1
  else
    "$@"
  fi
}

# Add dir for chain, exit if error
if ! mkdir -p "$HOME_DIR" 2>/dev/null; then
    echo "Failed to create chain folder. Aborting..."
    exit 1
fi

# genesis values
coins="1000000000$DENOM" # 10^9
delegate="100000000$DENOM" # 10^8
# we may not use faucet anymore since we are using wfUSD as gas/stake denom
FAUCET_COINS="1000000000$STAKE_DENOM" # 10^9
# prefund user accounts from faucet
FUND_COINS="1000000$STAKE_DENOM" # 10^6

echo "initializing chain ..."
$BINARY init $NODE_HOME $NODE_CHAIN_ID $CHAIN_ID
sleep 2

echo "retrieve validator mnemonics ..."
VAL_MNEMONIC=$(jq -r '.mnemonic' ./scripts-july/seeds/val_1_seed.json)
echo "retrieve validator2 mnemonics ..."
VAL2_MNEMONIC=$(jq -r '.mnemonic' ./scripts-july/seeds/val_2_seed.json)

echo "***** add validator key ..."
(echo $VAL_MNEMONIC; echo "") | $BINARY keys add validator $NODE_HOME $KEYRING --interactive --no-backup
VALIDATOR=$($BINARY keys show validator -a $NODE_HOME $KEYRING)
echo "validator address: $VALIDATOR"
sleep 1
echo "***** add validator2 key ..."
(echo $VAL2_MNEMONIC; echo "") | $BINARY keys add validator2 $NODE_HOME $KEYRING --interactive --no-backup
VALIDATOR2=$($BINARY keys show validator2 -a $NODE_HOME $KEYRING)
echo "validator2 address: $VALIDATOR2"
sleep 1


echo "***** add genesis accounts ..."
$BINARY genesis add-genesis-account "$FAUCET" $FAUCET_COINS $NODE_HOME $KEYRING
sleep 1
$BINARY genesis add-genesis-account "$VALIDATOR" $coins $NODE_HOME $KEYRING
sleep 1
$BINARY genesis add-genesis-account "$VALIDATOR2" $coins $NODE_HOME $KEYRING
sleep 1
$BINARY genesis add-genesis-account "$TF_OWNER" $FUND_COINS $NODE_HOME $KEYRING
sleep 1
$BINARY genesis add-genesis-account "$MASTERMINTER" $FUND_COINS $NODE_HOME $KEYRING
sleep 1
$BINARY genesis add-genesis-account "$MINTERCONTROLLER" $FUND_COINS $NODE_HOME $KEYRING
sleep 1
$BINARY genesis add-genesis-account "$MINTER" $FUND_COINS $NODE_HOME $KEYRING
sleep 1
$BINARY genesis add-genesis-account "$BLACKLISTER" $FUND_COINS $NODE_HOME $KEYRING
sleep 1
$BINARY genesis add-genesis-account "$PAUSER" $FUND_COINS $NODE_HOME $KEYRING
sleep 1

echo "***** add gentx ..."
$BINARY genesis gentx validator $delegate \
  --pubkey "$PUBKEY_1" \
  $NODE_HOME $KEYRING $NODE_CHAIN_ID \
  --commission-rate="0.05" --commission-max-rate="0.50"
sleep 1
$BINARY genesis collect-gentxs $NODE_HOME
sleep 1

# Run this to ensure everything worked and that the genesis file is setup correctly
echo "***** validate genesis ..."
$BINARY genesis validate-genesis $NODE_HOME

echo "Change settings in config.toml ..."
sed_in_place() {
  if sed --version >/dev/null 2>&1; then
    # GNU sed (supports `-i` without a backup suffix)
    sed -i "$@"
  else
    # BSD sed (macOS default; `-i` requires a suffix, '' = no backup)
    local script=$1
    local file=$2
    sed -i '' "$script" "$file"
  fi
}

sed_in_place 's#"tcp://127.0.0.1:26657"#"tcp://0.0.0.0:'"$RPCPORT"'"#g' "$HOME_DIR"/config/config.toml
sed_in_place 's#"tcp://0.0.0.0:26656"#"tcp://0.0.0.0:'"$P2PPORT"'"#g' "$HOME_DIR"/config/config.toml
sed_in_place 's#"localhost:6060"#"localhost:'"$P2PPORT"'"#g' "$HOME_DIR"/config/config.toml
sed_in_place 's/timeout_commit = "5s"/timeout_commit = "1s"/g' "$HOME_DIR"/config/config.toml
sed_in_place 's/timeout_propose = "3s"/timeout_propose = "1s"/g' "$HOME_DIR"/config/config.toml
sed_in_place 's/index_all_keys = false/index_all_keys = true/g' "$HOME_DIR"/config/config.toml

# validator use external tmkms
sed_in_place 's#priv_validator_laddr = ""#priv_validator_laddr = "tcp://0.0.0.0:'"$VALIDATOR_PORT"'"#g' "$HOME_DIR"/config/config.toml
## comment out the priv_validator_key_file and priv_validator_state_file settings
sed_in_place 's!priv_validator_key_file = "config/priv_validator_key.json"!#priv_validator_key_file = "config/priv_validator_key.json"!g' "$HOME_DIR"/config/config.toml
sed_in_place 's!priv_validator_state_file = "data/priv_validator_state.json"!#priv_validator_state_file = "data/priv_validator_state.json"!g' "$HOME_DIR"/config/config.toml

echo "Change settings in genesis.json ..."
# Function updates the config based on a jq argument as a string
update_test_genesis () {
  jq "$1" $HOME_DIR/config/genesis.json > $HOME_DIR/config/tmp_genesis.json && \
    mv $HOME_DIR/config/tmp_genesis.json $HOME_DIR/config/genesis.json
}

update_test_genesis '.app_state.tokenfactory.owner.address = "'$TF_OWNER'"'
update_test_genesis '.app_state.tokenfactory.mintingDenomList = [ { "denom": "'$TF_MINTING_BASEDENOM'" } ]'
#update_test_genesis '.app_state.tokenfactory.mintingDenomList = [ { "denom": "'$TF1_MINTING_BASEDENOM'" }, { "denom": "'$TF2_MINTING_BASEDENOM'" } ]'
update_test_genesis '.app_state.tokenfactory.paused.paused = false'

# Block
update_test_genesis '.consensus.params["block"]["max_gas"]="100000000"'
# bank
update_test_genesis ".app_state[\"bank\"][\"denom_metadata\"] = [
  {
    \"display\": \"$TF_MINTING_DENOM\",
    \"base\": \"$TF_MINTING_BASEDENOM\",
    \"name\": \"$TF_MINTING_DENOM\",
    \"symbol\": \"$TF_MINTING_DENOM\",
    \"description\": \"WF Deposit Token\",
    \"denom_units\": [
      { \"denom\": \"$TF_MINTING_BASEDENOM\", \"aliases\": null, \"exponent\": \"0\" },
      { \"denom\": \"$TF_MINTING_CENT_DENOM\", \"aliases\": null, \"exponent\": \"4\" },
      { \"denom\": \"$TF_MINTING_DENOM\", \"aliases\": null, \"exponent\": \"6\" }
    ]
  }
]"
#update_test_genesis '.app_state["bank"]["denom_metadata"]=[ { "display": "wfUSD", "base": "uwfUSD", "name": "wfUSD", "symbol": "wfUSD", "description": "WF Deposit Token", "denom_units": [ { "denom": "uwfUSD", "aliases": null, "exponent": "0" }, { "denom": "wfCENT", "aliases": null, "exponent": "4" }, { "denom": "wfUSD", "aliases": null, "exponent": "6" } ] } ]'
# distribution
## turn off community tax
update_test_genesis '.app_state["distribution"]["params"]["community_tax"]="0.000000000000000000"'
# gov
update_test_genesis '.app_state["gov"]["params"]["min_deposit"]=[{"denom": "uwfUSD","amount": "1000000"}]'
## for testing, shorten expedited_voting_period
update_test_genesis '.app_state["gov"]["params"]["expedited_voting_period"]="300s"'
update_test_genesis '.app_state["gov"]["params"]["expedited_min_deposit"]=[{"denom": "uwfUSD","amount": "2000000"}]'
update_test_genesis '.app_state["gov"]["voting_params"]["voting_period"]="15s"'
# staking
update_test_genesis '.app_state["staking"]["params"]["bond_denom"]="uwfUSD"'
update_test_genesis '.app_state["staking"]["params"]["min_commission_rate"]="0.050000000000000000"'
## for testing, shorten unbonding time
update_test_genesis '.app_state["staking"]["params"]["unbonding_time"]="300s"'
# slashing
update_test_genesis '.app_state["slashing"]["params"]["signed_blocks_window"]="100"'
update_test_genesis '.app_state["slashing"]["params"]["min_signed_per_window"]="0.100000000000000000"'
update_test_genesis '.app_state["slashing"]["params"]["downtime_jail_duration"]="300s"'
update_test_genesis '.app_state["slashing"]["params"]["slash_fraction_double_sign"]="0.000000000000000000"' # no need to slash, no stake uwfUSD
update_test_genesis '.app_state["slashing"]["params"]["slash_fraction_downtime"]="0.000000000000000000"'
# mint
update_test_genesis '.app_state["mint"]["params"]["mint_denom"]="uwfUSD"'
## turn off inflation
update_test_genesis '.app_state["mint"]["minter"]["inflation"]="0.000000000000000000"'
update_test_genesis '.app_state["mint"]["params"]["inflation_rate_change"]="0.000000000000000000"'
update_test_genesis '.app_state["mint"]["params"]["inflation_max"]="0.000000000000000000"'
update_test_genesis '.app_state["mint"]["params"]["inflation_min"]="0.000000000000000000"'
# crisis
update_test_genesis '.app_state["crisis"]["constant_fee"]={"denom": "uwfUSD","amount": "1000"}'

# Start
echo "***** Starting chain ..."
$BINARY start $NODE_HOME --pruning=nothing --minimum-gas-prices=$MINIMUM_GAS_PRICE --grpc-web.enable=false --grpc.address="0.0.0.0:$GRPCPORT" > "$HOME_DIR".log 2>&1 &
sleep 5

# tfd --home ./scripts-chain/play_wallet_tmkms_sh/tokenfactory-1 start --pruning=nothing --minimum-gas-prices=0.001uwfUSD --grpc-web.enable=false --grpc.address="127.0.0.1:9090" --trace --log_level=trace > $CHAIN_DIR/$CHAIN_ID.log 2>&1 &
# tfd --home ./scripts-chain/play_wallet_tmkms_sh/tokenfactory-1 start --pruning=nothing --minimum-gas-prices=0.001uwfUSD --grpc-web.enable=false --grpc.address="127.0.0.1:9090" --log_level=info > $CHAIN_DIR/$CHAIN_ID.log 2>&1 &
