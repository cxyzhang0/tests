#!/bin/bash

# !! PLEASE ONLY RUN THIS SCRIPT IN A TESTING ENVIRONMENT !!
#   THIS SCRIPT: 
#     - Stops/starts tfd binary

# This script is meant for quick experimentation of the Tokenfactory Module and tokenfactory Chain functionality.
# - Initialize, configure and start tokenfactory chain
# - - all keys are derived from mnemonics in `../scripts-july/seeds/`
# - - poas-specific configuration settings
# - - future eureka compatible
# - - uwfUSD as gas/staking token
# - Delagates and funds all privledged accounts for the `tokenfactory`.
# - todo: parameters hard-coded for distribution, gov, staking, slashing, mint and crisis. do we need to parameterize them?

# Run instructions
# run in root
# - ./scripts-chain/play.sh
# - source ./scripts-chain/chains.env


killall tfd
sleep 2
[ -d "./scripts-chain/play_sh" ] && rm -r "./scripts-chain/play_sh"

BINARY="./bin/tfd"
CHAIN_ID="tokenfactory-1"
CHAIN_DIR="./scripts-chain/play_sh"
RPCPORT="26657"
P2PPORT="26656"
PROFPORT="6060"
GRPCPORT="9090"

MINIMUM_GAS_PRICE="0.001uwfUSD"


KEYRING="--keyring-backend=test"

HOME_DIR="$CHAIN_DIR/$CHAIN_ID"
NODE_HOME="--home=$HOME_DIR"
NODE_CHAIN_ID="--chain-id=$CHAIN_ID"
GAS=(--gas-prices "0.001uwfUSD" --gas "auto" --gas-adjustment 2.0)

TF_MINTING_DENOM='wfUSD'
TF_MINTING_CENT_DENOM='wfCENT'
TF_MINTING_BASEDENOM="u$TF_MINTING_DENOM"

STAKE_DENOM=$TF_MINTING_BASEDENOM
DENOM=$STAKE_DENOM

SILENT=1

redirect() {
  if [ "$SILENT" -eq 1 ]; then
    "$@" > /dev/null 2>&1
  else
    "$@"
  fi
}

# Add dir for chain, exit if error
if ! mkdir -p "$HOME_DIR" 2>/dev/null; then
    echo "Failed to create chain folder. Aborting..."
    exit 1
fi

# genesis values
coins="1000000000$DENOM" # 10^9
delegate="100000000$DENOM" # 10^8
# we may not use faucet anymore since we are using wfUSD as gas/stake denom
FAUCET_COINS="1000000000$STAKE_DENOM" # 10^9
# prefund user accounts from faucet
FUND_COINS="1000000$STAKE_DENOM" # 10^6

echo "initializing chain ..."
$BINARY init $NODE_HOME $NODE_CHAIN_ID $CHAIN_ID
sleep 2

echo "retrieve faucet mnemonics ..."
FAUCET_MNEMONIC=$(jq -r '.mnemonic' ./scripts-july/seeds/faucet_seed.json)
echo "retrieve validator mnemonics ..."
VAL_MNEMONIC=$(jq -r '.mnemonic' ./scripts-july/seeds/val_1_seed.json)
echo "retrieve validator2 mnemonics ..."
VAL2_MNEMONIC=$(jq -r '.mnemonic' ./scripts-july/seeds/val_2_seed.json)
echo "retrieve owner mnemonics ..."
OWNER_MNEMONIC=$(jq -r '.mnemonic' ./scripts-july/seeds/xyz_1_seed.json)
echo "retrieve masterminter mnemonics ..."
MASTERMINTER_MNEMONIC=$(jq -r '.mnemonic' ./scripts-july/seeds/xyz_2_seed.json)
echo "retrieve mintercontroller mnemonics ..."
MINTERCONTROLLER_MNEMONIC=$(jq -r '.mnemonic' ./scripts-july/seeds/xyz_3_seed.json)
echo "retrieve MINTER mnemonics ..."
MINTER_MNEMONIC=$(jq -r '.mnemonic' ./scripts-july/seeds/xyz_4_seed.json)
echo "retrieve BLACKLISTER mnemonics ..."
BLACKLISTER_MNEMONIC=$(jq -r '.mnemonic' ./scripts-july/seeds/xyz_5_seed.json)
echo "retrieve PAUSER mnemonics ..."
PAUSER_MNEMONIC=$(jq -r '.mnemonic' ./scripts-july/seeds/xyz_6_seed.json)
echo "retrieve USA mnemonics ..."
USA_MNEMONIC=$(jq -r '.mnemonic' ./scripts-july/seeds/xyz_7_seed.json)
echo "retrieve CAN mnemonics ..."
CAN_MNEMONIC=$(jq -r '.mnemonic' ./scripts-july/seeds/xyz_8_seed.json)
echo "retrieve USER1 mnemonics ..."
USER1_MNEMONIC=$(jq -r '.mnemonic' ./scripts-july/seeds/xyz_9_seed.json)
echo "retrieve USER2 mnemonics ..."
USER2_MNEMONIC=$(jq -r '.mnemonic' ./scripts-july/seeds/xyz_10_seed.json)

echo "***** add faucet key ..."
(echo $FAUCET_MNEMONIC; echo "") | $BINARY keys add faucet $NODE_HOME $KEYRING --interactive --no-backup
FAUCET=$($BINARY keys show faucet -a $NODE_HOME $KEYRING)
echo "faucet address: $FAUCET"
sleep 1
echo "***** add validator key ..."
(echo $VAL_MNEMONIC; echo "") | $BINARY keys add validator $NODE_HOME $KEYRING --interactive --no-backup
VALIDATOR=$($BINARY keys show validator -a $NODE_HOME $KEYRING)
echo "validator address: $VALIDATOR"
sleep 1
echo "***** add validator2 key ..."
(echo $VAL2_MNEMONIC; echo "") | $BINARY keys add validator2 $NODE_HOME $KEYRING --interactive --no-backup
VALIDATOR2=$($BINARY keys show validator2 -a $NODE_HOME $KEYRING)
echo "validator2 address: $VALIDATOR2"
sleep 1
echo "***** add tf_owner key ..."
(echo $OWNER_MNEMONIC; echo "") | $BINARY keys add tf_owner $NODE_HOME $KEYRING --interactive --no-backup
TF_OWNER=$($BINARY keys show tf_owner -a $NODE_HOME $KEYRING)
echo "tf_owner address: $TF_OWNER"
sleep 1
echo "***** add masterminter key ..."
(echo $MASTERMINTER_MNEMONIC; echo "") | $BINARY keys add masterminter $NODE_HOME $KEYRING --interactive --no-backup
MASTERMINTER=$($BINARY keys show masterminter -a $NODE_HOME $KEYRING)
echo "masterminter address: $MASTERMINTER"
sleep 1
echo "***** add mintercontroller key ..."
(echo $MINTERCONTROLLER_MNEMONIC; echo "") | $BINARY keys add mintercontroller $NODE_HOME $KEYRING --interactive --no-backup
MINTERCONTROLLER=$($BINARY keys show mintercontroller -a $NODE_HOME $KEYRING)
echo "mintercontroller address: $MINTERCONTROLLER"
sleep 1
echo "***** add minter key ..."
(echo $MINTER_MNEMONIC; echo "") | $BINARY keys add minter $NODE_HOME $KEYRING --interactive --no-backup
MINTER=$($BINARY keys show minter -a $NODE_HOME $KEYRING)
echo "minter address: $MINTER"
sleep 1
echo "***** add blacklister key ..."
(echo $BLACKLISTER_MNEMONIC; echo "") | $BINARY keys add blacklister $NODE_HOME $KEYRING --interactive --no-backup
BLACKLISTER=$($BINARY keys show blacklister -a $NODE_HOME $KEYRING)
echo "blacklister address: $BLACKLISTER"
sleep 1
echo "***** add pauser key ..."
(echo $PAUSER_MNEMONIC; echo "") | $BINARY keys add pauser $NODE_HOME $KEYRING --interactive --no-backup
PAUSER=$($BINARY keys show pauser -a $NODE_HOME $KEYRING)
echo "pauser address: $PAUSER"
sleep 1
echo "***** add usa key ..."
(echo $USA_MNEMONIC; echo "") | $BINARY keys add usa $NODE_HOME $KEYRING --interactive --no-backup
USA=$($BINARY keys show usa -a $NODE_HOME $KEYRING)
echo "usa address: $USA"
sleep 1
echo "***** add can key ..."
(echo $CAN_MNEMONIC; echo "") | $BINARY keys add can $NODE_HOME $KEYRING --interactive --no-backup
CAN=$($BINARY keys show can -a $NODE_HOME $KEYRING)
echo "can address: $CAN"
sleep 1
echo "***** add user1 key ..."
(echo $USER1_MNEMONIC; echo "") | $BINARY keys add user1 $NODE_HOME $KEYRING --interactive --no-backup
USER1=$($BINARY keys show user1 -a $NODE_HOME $KEYRING)
echo "user1 address: $USER1"
sleep 1
echo "***** add user2 key ..."
(echo $USER2_MNEMONIC; echo "") | $BINARY keys add user2 $NODE_HOME $KEYRING --interactive --no-backup
USER2=$($BINARY keys show user2 -a $NODE_HOME $KEYRING)
echo "user2 address: $USER2"
sleep 1


echo "***** add genesis accounts ..."
$BINARY genesis add-genesis-account "$FAUCET" $FAUCET_COINS $NODE_HOME $KEYRING
sleep 1
$BINARY genesis add-genesis-account "$VALIDATOR" $coins $NODE_HOME $KEYRING
sleep 1
$BINARY genesis add-genesis-account "$VALIDATOR2" $coins $NODE_HOME $KEYRING
sleep 1
$BINARY genesis add-genesis-account "$TF_OWNER" $coins $NODE_HOME $KEYRING
sleep 1
echo "***** add gentx ..."
$BINARY genesis gentx validator $delegate $NODE_HOME $KEYRING $NODE_CHAIN_ID --commission-rate="0.05" --commission-max-rate="0.50"
sleep 1
$BINARY genesis collect-gentxs $NODE_HOME
sleep 1

# Run this to ensure everything worked and that the genesis file is setup correctly
echo "***** validate genesis ..."
$BINARY genesis validate-genesis $NODE_HOME

echo "Change settings in config.toml ..."
sed_in_place() {
  if sed --version >/dev/null 2>&1; then
    # GNU sed (supports `-i` without a backup suffix)
    sed -i "$@"
  else
    # BSD sed (macOS default; `-i` requires a suffix, '' = no backup)
    local script=$1
    local file=$2
    sed -i '' "$script" "$file"
  fi
}

sed_in_place 's#"tcp://127.0.0.1:26657"#"tcp://0.0.0.0:'"$RPCPORT"'"#g' "$HOME_DIR"/config/config.toml
sed_in_place 's#"tcp://0.0.0.0:26656"#"tcp://0.0.0.0:'"$P2PPORT"'"#g' "$HOME_DIR"/config/config.toml
sed_in_place 's#"localhost:6060"#"localhost:'"$P2PPORT"'"#g' "$HOME_DIR"/config/config.toml
sed_in_place 's/timeout_commit = "5s"/timeout_commit = "1s"/g' "$HOME_DIR"/config/config.toml
sed_in_place 's/timeout_propose = "3s"/timeout_propose = "1s"/g' "$HOME_DIR"/config/config.toml
sed_in_place 's/index_all_keys = false/index_all_keys = true/g' "$HOME_DIR"/config/config.toml

echo "Change settings in genesis.json ..."
# Function updates the config based on a jq argument as a string
update_test_genesis () {
  jq "$1" $HOME_DIR/config/genesis.json > $HOME_DIR/config/tmp_genesis.json && \
    mv $HOME_DIR/config/tmp_genesis.json $HOME_DIR/config/genesis.json
}

update_test_genesis '.app_state.tokenfactory.owner.address = "'$TF_OWNER'"'
update_test_genesis '.app_state.tokenfactory.mintingDenomList = [ { "denom": "'$TF_MINTING_BASEDENOM'" } ]'
#update_test_genesis '.app_state.tokenfactory.mintingDenomList = [ { "denom": "'$TF1_MINTING_BASEDENOM'" }, { "denom": "'$TF2_MINTING_BASEDENOM'" } ]'
update_test_genesis '.app_state.tokenfactory.paused.paused = false'

# Block
update_test_genesis '.consensus.params["block"]["max_gas"]="100000000"'
# bank
update_test_genesis ".app_state[\"bank\"][\"denom_metadata\"] = [
  {
    \"display\": \"$TF_MINTING_DENOM\",
    \"base\": \"$TF_MINTING_BASEDENOM\",
    \"name\": \"$TF_MINTING_DENOM\",
    \"symbol\": \"$TF_MINTING_DENOM\",
    \"description\": \"WF Deposit Token\",
    \"denom_units\": [
      { \"denom\": \"$TF_MINTING_BASEDENOM\", \"aliases\": null, \"exponent\": \"0\" },
      { \"denom\": \"$TF_MINTING_CENT_DENOM\", \"aliases\": null, \"exponent\": \"4\" },
      { \"denom\": \"$TF_MINTING_DENOM\", \"aliases\": null, \"exponent\": \"6\" }
    ]
  }
]"
#update_test_genesis '.app_state["bank"]["denom_metadata"]=[ { "display": "wfUSD", "base": "uwfUSD", "name": "wfUSD", "symbol": "wfUSD", "description": "WF Deposit Token", "denom_units": [ { "denom": "uwfUSD", "aliases": null, "exponent": "0" }, { "denom": "wfCENT", "aliases": null, "exponent": "4" }, { "denom": "wfUSD", "aliases": null, "exponent": "6" } ] } ]'

# distribution
## turn off community tax
update_test_genesis '.app_state["distribution"]["params"]["community_tax"]="0.000000000000000000"'
# gov
update_test_genesis '.app_state["gov"]["params"]["min_deposit"]=[{"denom": "uwfUSD","amount": "1000000"}]'
## for testing, shorten expedited_voting_period
update_test_genesis '.app_state["gov"]["params"]["expedited_voting_period"]="300s"'
update_test_genesis '.app_state["gov"]["params"]["expedited_min_deposit"]=[{"denom": "uwfUSD","amount": "2000000"}]'
update_test_genesis '.app_state["gov"]["voting_params"]["voting_period"]="15s"'
# staking
update_test_genesis '.app_state["staking"]["params"]["bond_denom"]="uwfUSD"'
update_test_genesis '.app_state["staking"]["params"]["min_commission_rate"]="0.050000000000000000"'
## for testing, shorten unbonding time
update_test_genesis '.app_state["staking"]["params"]["unbonding_time"]="300s"'
# slashing
update_test_genesis '.app_state["slashing"]["params"]["signed_blocks_window"]="100"'
update_test_genesis '.app_state["slashing"]["params"]["min_signed_per_window"]="0.100000000000000000"'
update_test_genesis '.app_state["slashing"]["params"]["downtime_jail_duration"]="300s"'
update_test_genesis '.app_state["slashing"]["params"]["slash_fraction_double_sign"]="0.000000000000000000"' # no need to slash, no stake uwfUSD
update_test_genesis '.app_state["slashing"]["params"]["slash_fraction_downtime"]="0.000000000000000000"'
# mint
update_test_genesis '.app_state["mint"]["params"]["mint_denom"]="uwfUSD"'
## turn off inflation
update_test_genesis '.app_state["mint"]["minter"]["inflation"]="0.000000000000000000"'
update_test_genesis '.app_state["mint"]["params"]["inflation_rate_change"]="0.000000000000000000"'
update_test_genesis '.app_state["mint"]["params"]["inflation_max"]="0.000000000000000000"'
update_test_genesis '.app_state["mint"]["params"]["inflation_min"]="0.000000000000000000"'
# crisis
update_test_genesis '.app_state["crisis"]["constant_fee"]={"denom": "uwfUSD","amount": "1000"}'


# Start
echo "***** Starting chain ..."
$BINARY start $NODE_HOME --pruning=nothing --minimum-gas-prices=$MINIMUM_GAS_PRICE --grpc-web.enable=false --grpc.address="0.0.0.0:$GRPCPORT" > "$HOME_DIR".log 2>&1 &
sleep 5
# Fund accounts
echo "***** Funding accounts by faucet ..."
$BINARY tx bank send faucet "$MASTERMINTER" $FUND_COINS $NODE_HOME $KEYRING "${GAS[@]}" -y
sleep 2
$BINARY tx bank send faucet "$MINTERCONTROLLER" $FUND_COINS $NODE_HOME $KEYRING "${GAS[@]}" -y
sleep 2
$BINARY tx bank send faucet "$MINTER" $FUND_COINS $NODE_HOME $KEYRING "${GAS[@]}" -y
sleep 2
$BINARY tx bank send faucet "$BLACKLISTER" $FUND_COINS $NODE_HOME $KEYRING "${GAS[@]}" -y
sleep 2
$BINARY tx bank send faucet "$PAUSER" $FUND_COINS $NODE_HOME $KEYRING "${GAS[@]}" -y
sleep 2
$BINARY tx bank send faucet "$USA" $FUND_COINS $NODE_HOME $KEYRING "${GAS[@]}" -y
sleep 2
$BINARY tx bank send faucet "$CAN" $FUND_COINS $NODE_HOME $KEYRING "${GAS[@]}" -y
sleep 2
$BINARY tx bank send faucet "$USER1" $FUND_COINS $NODE_HOME $KEYRING "${GAS[@]}" -y
sleep 2
$BINARY tx bank send faucet "$USER2" $FUND_COINS $NODE_HOME $KEYRING "${GAS[@]}" -y
sleep 2

# Delegate privledges
echo "***** Delegate roles ..."
$BINARY tx tokenfactory update-master-minter "$MASTERMINTER" --from tf_owner $NODE_HOME $KEYRING "${GAS[@]}" -y
sleep 2
$BINARY tx tokenfactory configure-minter-controller "$MINTERCONTROLLER" --from masterminter "$MINTER" $NODE_HOME $KEYRING "${GAS[@]}" -y
sleep 2
$BINARY tx tokenfactory configure-minter "$MINTER" 1000$TF_MINTING_BASEDENOM --from mintercontroller $NODE_HOME $KEYRING "${GAS[@]}" -y
sleep 2
$BINARY tx tokenfactory update-blacklister "$BLACKLISTER" --from tf_owner $NODE_HOME $KEYRING "${GAS[@]}" -y
sleep 2
$BINARY tx tokenfactory update-pauser "$PAUSER" --from tf_owner $NODE_HOME $KEYRING "${GAS[@]}" -y


# tfd --home ./scripts-chain/play_sh/tokenfactory-1 start --pruning=nothing --minimum-gas-prices=0.001uwfUSD --grpc-web.enable=false --grpc.address="127.0.0.1:9090" --trace --log_level=trace > $CHAIN_DIR/$CHAIN_ID.log 2>&1 &
# tfd --home ./scripts-chain/play_sh/tokenfactory-1 start --pruning=nothing --minimum-gas-prices=0.001uwfUSD --grpc-web.enable=false --grpc.address="127.0.0.1:9090" --log_level=info > $CHAIN_DIR/$CHAIN_ID.log 2>&1 &
