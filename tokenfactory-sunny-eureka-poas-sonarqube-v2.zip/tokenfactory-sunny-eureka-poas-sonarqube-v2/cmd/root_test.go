package cmd_test

import (
	"testing"

	"cosmossdk.io/log"
	dbm "github.com/cosmos/cosmos-db"
	"github.com/cosmos/cosmos-sdk/client/flags"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/spf13/viper"
	"github.com/stretchr/testify/assert"
	"github.com/wfblockchain/coreblockchain/v2/cmd"
)

func TestNewRootCmd(t *testing.T) {
	sdk.SetAddrCacheEnabled(false)
	sdk.GetConfig().SetBech32PrefixForAccount("wf", "accountAddressPrefixpub")
	sdk.GetConfig().SetBech32PrefixForValidator("wf", "accountAddressPrefixvalpub")
	sdk.GetConfig().SetBech32PrefixForConsensusNode("wf", "accountAddressPrefixcons")
	rootCmd := cmd.NewRootCmd()
	t.Run("Check Root Command Setup", func(t *testing.T) {
		assert.NotNil(t, rootCmd)
		assert.Equal(t, "tokenfactoryd", rootCmd.Use)
		assert.Equal(t, "noblefork app", rootCmd.Short)
	})

	var homeDir string
	t.Run("Test Command Execution", func(t *testing.T) {
		rootCmd.SetArgs([]string{"version", "--home", "/tmp/TestCommandExecution"})
		rootCmd.PersistentFlags().StringVar(&homeDir, "home", "", "specify a custom home directory for configuration and data")
		err := rootCmd.Execute()
		assert.NoError(t, err, "Root command should execute without error")

	})

	t.Run("Check Subcommands", func(t *testing.T) {
		cmdExists := false
		for _, cmd := range rootCmd.Commands() {
			if cmd.Use == "tx" {
				cmdExists = true
				break
			}
		}
		assert.True(t, cmdExists, "Expected 'tx' subcommand to be present")
	})
}

func TestAppExport(t *testing.T) {
	var opts = viper.NewWithOptions(viper.KeyDelimiter("."))

	_, err := cmd.AppExport(
		log.NewNopLogger(),
		dbm.NewMemDB(),
		nil,
		0,
		false,
		nil,
		opts,
		[]string{"auth"})
	assert.Error(t, err, "AppExport should execute with error")

	opts.Set(flags.FlagHome, "/tmp/TestAppExport_1")
	_, err = cmd.AppExport(
		log.NewNopLogger(),
		dbm.NewMemDB(),
		nil,
		-1,
		false,
		nil,
		opts,
		[]string{"auth"})
	assert.NoError(t, err, "AppExport should execute without error")

	opts.Set(flags.FlagHome, "/tmp/TestAppExport_2")
	_, err = cmd.AppExport(
		log.NewNopLogger(),
		dbm.NewMemDB(),
		nil,
		0,
		false,
		nil,
		opts,
		[]string{"auth"})
	assert.NoError(t, err, "AppExport should execute without error")
}
