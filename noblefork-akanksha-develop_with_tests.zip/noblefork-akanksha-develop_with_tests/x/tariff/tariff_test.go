package tariff_test

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"cosmossdk.io/log"
	"cosmossdk.io/math"
	abci "github.com/cometbft/cometbft/abci/types"
	tmproto "github.com/cometbft/cometbft/proto/tendermint/types"
	"github.com/cosmos/cosmos-sdk/client"
	"github.com/cosmos/cosmos-sdk/codec"
	codectypes "github.com/cosmos/cosmos-sdk/codec/types"
	sdk "github.com/cosmos/cosmos-sdk/types"
	sdktypes "github.com/cosmos/cosmos-sdk/types"
	"github.com/cosmos/cosmos-sdk/types/module"
	simulation "github.com/cosmos/cosmos-sdk/types/module"
	"github.com/cosmos/cosmos-sdk/types/module/testutil"
	simtypes "github.com/cosmos/cosmos-sdk/types/simulation"
	banktypes "github.com/cosmos/cosmos-sdk/x/bank/types"
	capabilitytypes "github.com/cosmos/ibc-go/modules/capability/types"
	clienttypes "github.com/cosmos/ibc-go/v8/modules/core/02-client/types"
	"github.com/cosmos/ibc-go/v8/modules/core/exported"
	"github.com/gorilla/mux"
	"github.com/grpc-ecosystem/grpc-gateway/runtime"
	asserttest "github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"github.com/wfblockchain/noblechain/v5/x/tariff"
	"github.com/wfblockchain/noblechain/v5/x/tariff/client/cli"
	"github.com/wfblockchain/noblechain/v5/x/tariff/keeper"
	"github.com/wfblockchain/noblechain/v5/x/tariff/types"
	"gotest.tools/v3/assert"
)

func TestAppModuleBasic_DefaultGenesis(t *testing.T) {
	interfaceRegistry := codectypes.NewInterfaceRegistry()
	cdc := codec.NewProtoCodec(interfaceRegistry)
	appModuleBasic := tariff.AppModuleBasic{}
	genesisBytes := appModuleBasic.DefaultGenesis(cdc)
	require.NotNil(t, genesisBytes)
	var result types.GenesisState
	err := cdc.UnmarshalJSON(genesisBytes, &result)
	require.NoError(t, err)
	expected := types.DefaultGenesis()
	require.Equal(t, expected.Params.DistributionEntities, result.Params.DistributionEntities, "Mismatch in DistributionEntities")
	require.Equal(t, expected.Params.TransferFeeBps.String(), result.Params.TransferFeeBps.String(), "Mismatch in TransferFeeBps")
	require.Equal(t, expected.Params.TransferFeeMax.String(), result.Params.TransferFeeMax.String(), "Mismatch in TransferFeeMax")
	require.Equal(t, expected.Params.TransferFeeDenom, result.Params.TransferFeeDenom, "Mismatch in TransferFeeDenom")
}

func TestAppModule_ConsensusVersion(t *testing.T) {
	appModule := tariff.AppModule{}
	version := appModule.ConsensusVersion()
	assert.Equal(t, uint64(1), version)
}

func TestGetTxCmd(t *testing.T) {
	appModuleBasic := tariff.AppModuleBasic{}
	txCmd := appModuleBasic.GetTxCmd()
	require.NotNil(t, txCmd, "GetTxCmd() should not return nil")
	require.Equal(t, "forwarding", txCmd.Use, "Transaction command should have the correct name")
	subCommands := txCmd.Commands()
	require.NotEmpty(t, subCommands, "Transaction command should have subcommands")
	for _, cmd := range subCommands {
		t.Logf("Found subcommand: %s", cmd.Use)
	}
	expectedSubcommands := []string{"register-account", "clear-account"}

	for _, expected := range expectedSubcommands {
		found := false
		for _, cmd := range subCommands {
			if strings.HasPrefix(cmd.Use, expected) {
				found = true
				break
			}
		}
		require.Truef(t, found, "Expected subcommand %q not found", expected)
	}
}

func TestGetQueryCmd(t *testing.T) {
	queryCmd := cli.GetQueryCmd()
	require.NotNil(t, queryCmd, "GetQueryCmd() should not return nil")
	require.NotEmpty(t, queryCmd.Use, "Query command should have a name")
	require.Equal(t, types.ModuleName, queryCmd.Use, "Query command should match module name")
	subCommands := queryCmd.Commands()
	require.NotEmpty(t, subCommands, "Query command should have subcommands")
	for _, cmd := range subCommands {
		t.Logf("Found subcommand: %s", cmd.Use)
	}
	expectedSubcommands := []string{"params"}

	for _, expected := range expectedSubcommands {
		found := false
		for _, cmd := range subCommands {
			if strings.HasPrefix(cmd.Use, expected) {
				found = true
				break
			}
		}
		require.Truef(t, found, "Expected subcommand %q not found", expected)
	}
}

func TestIsAppModule(t *testing.T) {
	am := tariff.AppModule{}
	require.NotPanics(t, func() {
		am.IsAppModule()
	}, "IsAppModule should not panic")
}

func TestIsOnePerModuleType(t *testing.T) {
	am := tariff.AppModule{}
	require.NotPanics(t, func() {
		am.IsOnePerModuleType()
	}, "IsOnePerModuleType should not panic")
}

func TestAppModuleBasicRegisterLegacyAminoCodec(t *testing.T) {
	cdc := codec.NewLegacyAmino()
	amb := tariff.AppModuleBasic{}
	amb.RegisterLegacyAminoCodec(cdc)
	expectedType := types.GenesisState{}
	_, err := cdc.MarshalJSON(expectedType)

	require.NoError(t, err, "RegisterLegacyAminoCodec should register the expected types without errors")
}

func TestRegisterRESTRoutes(t *testing.T) {
	ctx := client.Context{}
	router := mux.NewRouter()
	am := tariff.AppModuleBasic{}
	am.RegisterRESTRoutes(ctx, router)

	routeFound := false
	router.Walk(func(route *mux.Route, router *mux.Router, ancestors []*mux.Route) error {
		path, _ := route.GetPathTemplate()
		methods, _ := route.GetMethods()

		if path == "/tariff/register-account" && containsMethod(methods, http.MethodPost) {
			routeFound = true
			return nil
		}
		return nil
	})
	require.True(t, routeFound, "/tariff/register-account with POST method should be registered")

}

func containsMethod(methods []string, method string) bool {
	for _, m := range methods {
		if m == method {
			return true
		}
	}
	return false
}

func TestAppModuleBasicName(t *testing.T) {
	amb := tariff.AppModuleBasic{}
	expectedName := types.ModuleName

	actualName := amb.Name()

	require.Equal(t, expectedName, actualName, "AppModuleBasic.Name() should return the correct module name")
}

func TestNewAppModuleBasic(t *testing.T) {
	interfaceRegistry := codectypes.NewInterfaceRegistry()
	protoCodec := codec.NewProtoCodec(interfaceRegistry)
	moduleBasic := tariff.NewAppModuleBasic(protoCodec)
	require.NotNil(t, moduleBasic, "Expected non-nil AppModuleBasic")
}

func TestRegisterInterfaces(t *testing.T) {
	interfaceRegistry := codectypes.NewInterfaceRegistry()
	cdc := codec.NewProtoCodec(interfaceRegistry)
	appModuleBasic := tariff.NewAppModuleBasic(cdc)
	appModuleBasic.RegisterInterfaces(interfaceRegistry)
	require.NotNil(t, interfaceRegistry, "InterfaceRegistry should not be nil")
}

func TestValidateGenesis(t *testing.T) {
	interfaceRegistry := codectypes.NewInterfaceRegistry()
	cdc := codec.NewProtoCodec(interfaceRegistry)
	var config client.TxEncodingConfig
	validGenesisState := types.GenesisState{}
	validGenesisJSON, err := cdc.MarshalJSON(&validGenesisState)
	asserttest.NoError(t, err, "Failed to marshal valid genesis state")
	appModuleBasic := tariff.NewAppModuleBasic(cdc)
	err = appModuleBasic.ValidateGenesis(cdc, config, validGenesisJSON)
	asserttest.NoError(t, err, "Expected no error for valid genesis state")
	invalidGenesisJSON := []byte(`{"invalid_field": "invalid_value"}`)
	err = appModuleBasic.ValidateGenesis(cdc, config, invalidGenesisJSON)
	asserttest.Contains(t, err.Error(), "failed to unmarshal", "Error message should indicate unmarshaling failure")
}

func TestPostRegisterAccountHandler(t *testing.T) {
	req, err := http.NewRequest("POST", "/register", nil)
	asserttest.NoError(t, err, "Failed to create request")
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(tariff.PostRegisterAccountHandler)
	handler.ServeHTTP(rr, req)
	assert.Equal(t, http.StatusOK, rr.Code, "Expected status code 200")
	expectedResponse := "Registration successful"
	assert.Equal(t, expectedResponse, rr.Body.String(), "Expected response body to be 'Registration successful'")

}

func TestRegisterGRPCGatewayRoutes(t *testing.T) {
	interfaceRegistry := codectypes.NewInterfaceRegistry()
	cdc := codec.NewProtoCodec(interfaceRegistry)
	clientCtx := client.Context{}
	mux := runtime.NewServeMux()
	appModuleBasic := tariff.NewAppModuleBasic(cdc)
	appModuleBasic.RegisterGRPCGatewayRoutes(clientCtx, mux)
	asserttest.NotNil(t, mux, "Expected mux to be initialized")
}

func TestGetQueryCmd2(t *testing.T) {
	appModuleBasic := tariff.NewAppModuleBasic(nil)
	cmd := appModuleBasic.GetQueryCmd()
	asserttest.NotNil(t, cmd, "Expected GetQueryCmd to return a non-nil command")
	expectedCmdName := "tariff"
	assert.Equal(t, expectedCmdName, cmd.Use, "Expected the command name to be 'query'")
	err := cmd.Execute() // Run the command
	asserttest.NoError(t, err, "Expected the query command to execute without error")
}

type SimpleAccountKeeper struct{}
type SimpleBankKeeper struct{}

func (s *SimpleAccountKeeper) GetAccount(ctx context.Context, addr sdktypes.AccAddress) sdktypes.AccountI {
	return nil
}

func (s *SimpleBankKeeper) SendCoins(fromAddr string, toAddr string, amount sdktypes.Coin) error {
	return nil
}

func (s *SimpleBankKeeper) BurnCoins(ctx context.Context, addr string, amount sdktypes.Coins) error {
	return nil
}

func (s *SimpleBankKeeper) GetDenomMetaData(ctx context.Context, denom string) (banktypes.Metadata, bool) {
	return banktypes.Metadata{
		Name:    "mockCoin",
		Symbol:  "MC",
		Base:    denom,
		Display: denom,
		DenomUnits: []*banktypes.DenomUnit{
			{
				Denom:    denom,
				Exponent: 0,
			},
			{
				Denom:    "m" + denom,
				Exponent: 3,
			},
		},
	}, true
}

func (s *SimpleBankKeeper) MintCoins(ctx context.Context, moduleName string, amt sdktypes.Coins) error {
	fmt.Printf("Minting coins for module: %s\n", moduleName)
	fmt.Printf("Coins minted: %s\n", amt.String())
	return nil
}

func (s *SimpleBankKeeper) SendCoinsFromModuleToAccount(
	ctx context.Context, senderModule string, recipientAddr sdktypes.AccAddress, amt sdktypes.Coins) error {
	fmt.Printf("Sending coins from module: %s to account: %s\n", senderModule, recipientAddr.String())
	fmt.Printf("Amount sent: %s\n", amt.String())
	return nil
}

func (s *SimpleBankKeeper) SendCoinsFromAccountToModule(
	ctx context.Context, senderAddr sdktypes.AccAddress, recipientModule string, amt sdktypes.Coins) error {
	fmt.Printf("Sending coins from account: %s to module: %s\n", senderAddr.String(), recipientModule)
	fmt.Printf("Amount sent: %s\n", amt.String())
	return nil
}

func (s *SimpleBankKeeper) SpendableCoins(ctx context.Context, addr sdktypes.AccAddress) sdktypes.Coins {
	coins := sdktypes.NewCoins(
		sdktypes.NewCoin("mockCoin", math.NewInt(1000)),
		sdktypes.NewCoin("otherCoin", math.NewInt(500)),
	)

	return coins
}
func (s *SimpleAccountKeeper) GetModuleAccount(ctx context.Context, moduleName string) sdktypes.ModuleAccountI {
	return nil
}
func (s *SimpleBankKeeper) GetAllBalances(ctx context.Context, addr sdktypes.AccAddress) sdktypes.Coins {
	return sdktypes.NewCoins(
		sdktypes.NewCoin("mockCoin", math.NewInt(1000)),
	)
}

func TestNewAppModule(t *testing.T) {
	interfaceRegistry := codectypes.NewInterfaceRegistry()
	cdc := codec.NewProtoCodec(interfaceRegistry)
	accountKeeper := &SimpleAccountKeeper{}
	bankKeeper := &SimpleBankKeeper{}
	keeper := &keeper.Keeper{}
	appModule := tariff.NewAppModule(cdc, *keeper, accountKeeper, bankKeeper)
	asserttest.NotNil(t, appModule, "Expected AppModule to be initialized")
}

type MockRegistry struct {
	invariants []sdktypes.Invariant
}

func (m *MockRegistry) RegisterInvariant(invar sdktypes.Invariant) {
	m.invariants = append(m.invariants, invar)
}

func (m *MockRegistry) RegisterRoute(route, moduleName string, invariant sdktypes.Invariant) {
	m.RegisterInvariant(invariant)
}

func TestRegisterInvariants(t *testing.T) {
	appModule := tariff.AppModule{
		AppModuleBasic: tariff.AppModuleBasic{},
	}
	mockRegistry := &MockRegistry{}

	inv := sdktypes.Invariant(func(ctx sdk.Context) (string, bool) {
		return "dummy-invariant", true
	})
	mockRegistry.RegisterRoute("test_route", "test_module", inv)
	appModule.RegisterInvariants(mockRegistry)
	asserttest.Len(t, mockRegistry.invariants, 1, "Expected 1 invariant to be registered")
}

func TestEndBlock(t *testing.T) {
	appModule := tariff.AppModule{
		AppModuleBasic: tariff.AppModuleBasic{},
	}
	ctx := sdktypes.NewContext(nil, tmproto.Header{}, false, log.NewNopLogger())
	validatorUpdates := appModule.EndBlock(ctx, abci.RequestFinalizeBlock{})
	asserttest.NotNil(t, validatorUpdates, "Expected non-nil validator updates")
	asserttest.Empty(t, validatorUpdates, "Expected an empty slice of validator updates")
}

type MockICS4Wrapper struct{}

func (m *MockICS4Wrapper) GetAppVersion(ctx sdk.Context, portID, channelID string) (string, bool) {
	return "1.0", true
}

func (m *MockICS4Wrapper) SendPacket(
	ctx sdk.Context,
	chanCap *capabilitytypes.Capability,
	sourcePort string,
	sourceChannel string,
	timeoutHeight clienttypes.Height,
	timeoutTimestamp uint64,
	data []byte,
) (uint64, error) {
	return 1, nil
}

func (m *MockICS4Wrapper) WriteAcknowledgement(
	ctx sdk.Context,
	chanCap *capabilitytypes.Capability,
	packet exported.PacketI,
	ack exported.Acknowledgement,
) error {
	return nil
}
func TestGenerateGenesisState(t *testing.T) {
	simState := &module.SimulationState{
		Cdc:      testutil.MakeTestEncodingConfig().Codec,
		GenState: make(map[string]json.RawMessage),
	}
	tariff.AppModule{}.GenerateGenesisState(simState)

	require.Contains(t, simState.GenState, types.ModuleName)
	var genesisState types.GenesisState
	err := simState.Cdc.UnmarshalJSON(simState.GenState[types.ModuleName], &genesisState)
	require.NoError(t, err)
}

func TestProposalContents(t *testing.T) {
	var simState simulation.SimulationState
	proposals := tariff.AppModule{}.ProposalContents(simState)
	require.Nil(t, proposals)
	require.Equal(t, 0, len(proposals))
}

func TestRegisterStoreDecoder(t *testing.T) {
	var registry simtypes.StoreDecoderRegistry
	require.NotPanics(t, func() {
		tariff.AppModule{}.RegisterStoreDecoder(registry)
	})
}
func TestWeightedOperations(t *testing.T) {
	var simState simulation.SimulationState
	operations := tariff.AppModule{}.WeightedOperations(simState)
	require.Nil(t, operations, "Expected WeightedOperations to return nil")
}
