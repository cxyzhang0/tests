package cli_test

import (
	"context"
	"testing"
	"time"

	"github.com/cosmos/cosmos-sdk/client"
	"github.com/cosmos/cosmos-sdk/types"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/golang/mock/gomock"
	"github.com/stretchr/testify/require"
	"github.com/wfblockchain/noblechain/v5/testutil/sample"
	"github.com/wfblockchain/noblechain/v5/x/tariff/client/cli"
	ttypes "github.com/wfblockchain/noblechain/v5/x/tariff/types"
)

type MockQueryClient struct {
	ttypes.QueryClient
}

func (m *MockQueryClient) Params(ctx context.Context, req *ttypes.QueryParamsRequest) (*ttypes.QueryParamsResponse, error) {
	return &ttypes.QueryParamsResponse{
		Params: ttypes.Params{},
	}, nil
}
func (m *MockQueryClient) Deadline() (deadline time.Time, ok bool) {
	return time.Time{}, false
}

type MockClientContext struct {
	clientCtx client.Context
}

func (m *MockClientContext) GetFromAddress() types.AccAddress {
	return m.clientCtx.GetFromAddress()
}

func (m *MockClientContext) Deadline() (deadline time.Time, ok bool) {
	return time.Time{}, false
}
func (m *MockClientContext) Done() <-chan struct{} {
	ch := make(chan struct{})
	close(ch)
	return ch
}

func (m *MockClientContext) Err() error {
	return nil
}

func (m *MockClientContext) Value(key interface{}) interface{} {
	return nil
}

func TestCmdQueryParams(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()
	clientCtx := client.Context{}
	validAddress := sample.AccAddress()
	clientCtx = clientCtx.WithFromAddress(types.AccAddress(validAddress))
	clientCtx = clientCtx.WithOffline(false)
	fromAddr := clientCtx.GetFromAddress().String()
	if fromAddr == "" {
		t.Fatalf("The from address is empty, check if it has been set properly.")
	}
	_, err := sdk.AccAddressFromBech32(fromAddr)
	if err != nil {
		t.Fatalf("Invalid From address in context: %s, error: %v", fromAddr, err)
	}

	cli.CmdQueryParams()

}

func TestGetTxCmd(t *testing.T) {
	cmd := cli.GetTxCmd()
	require.NotNil(t, cmd)
	require.Equal(t, "forwarding", cmd.Use)
	require.NotNil(t, cmd.RunE)
	expectedSubcommands := map[string]bool{
		"register-account": false,
		"clear-account":    false,
	}

	for _, subCmd := range cmd.Commands() {
		if _, exists := expectedSubcommands[subCmd.Use]; exists {
			expectedSubcommands[subCmd.Use] = true
		}
	}
	cmd.SetArgs([]string{})
	err := cmd.Execute()
	require.NoError(t, err)
}

type mockCodec struct{}

func (m mockCodec) StringToBytes(string) ([]byte, error) { return []byte{}, nil }
func (m mockCodec) BytesToString([]byte) (string, error) { return "", nil }

func TestNewTxCmd(t *testing.T) {
	mockValAc := mockCodec{}
	mockAc := mockCodec{}
	cmd := cli.NewTxCmd(mockValAc, mockAc)
	require.NotNil(t, cmd)
	require.Equal(t, "forwarding", cmd.Use)
	require.Equal(t, "Distribution transactions subcommands", cmd.Short)
	require.NotNil(t, cmd.RunE)
	expectedSubcommands := map[string]bool{
		"register-account": false,
		"clear-account":    false,
	}

	for _, subCmd := range cmd.Commands() {
		if _, exists := expectedSubcommands[subCmd.Use]; exists {
			expectedSubcommands[subCmd.Use] = true
		}
	}
	cmd.SetArgs([]string{})
	err := cmd.Execute()
	require.NoError(t, err)
}

func TestGetQueryCmd(t *testing.T) {
	cmd := cli.GetQueryCmd()
	require.NotNil(t, cmd, "GetQueryCmd should return a non-nil command")
	require.Equal(t, "tariff", cmd.Use, "The module name should match the expected value")
	foundCmd := false
	for _, subCmd := range cmd.Commands() {
		if subCmd.Use == "params" {
			foundCmd = true
			break
		}
	}

	require.True(t, foundCmd, "CmdQueryParams should be added as a subcommand of GetQueryCmd")
}
