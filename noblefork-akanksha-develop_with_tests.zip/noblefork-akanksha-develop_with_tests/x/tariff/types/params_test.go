package types_test

import (
	fmt "fmt"
	"testing"

	"cosmossdk.io/math"
	sdkmath "cosmossdk.io/math"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/stretchr/testify/require"
	"github.com/wfblockchain/noblechain/v5/x/tariff/types"
	"gopkg.in/yaml.v2"
)

func TestValidateDistributionEntityParams(t *testing.T) {
	validAddr1 := sdk.AccAddress([]byte("address1")).String()
	validAddr2 := sdk.AccAddress([]byte("address2")).String()

	tests := []struct {
		name    string
		input   interface{}
		wantErr bool
		errMsg  string
	}{
		{
			name: "valid distribution entities",
			input: []types.DistributionEntity{
				{Address: validAddr1, Share: math.LegacyNewDecWithPrec(50, 2)}, // 50%
				{Address: validAddr2, Share: math.LegacyNewDecWithPrec(50, 2)}, // 50%
			},
			wantErr: false,
		},
		{
			name:    "invalid parameter type",
			input:   "invalid type",
			wantErr: true,
			errMsg:  "invalid parameter type: string",
		},
		{
			name: "duplicate address",
			input: []types.DistributionEntity{
				{Address: validAddr1, Share: math.LegacyNewDecWithPrec(40, 2)},
				{Address: validAddr1, Share: math.LegacyNewDecWithPrec(60, 2)},
			},
			wantErr: true,
			errMsg:  "address is already added as a distribution entity",
		},
		{
			name: "sum of shares more than 100%",
			input: []types.DistributionEntity{
				{Address: validAddr1, Share: math.LegacyNewDecWithPrec(70, 2)},
				{Address: validAddr2, Share: math.LegacyNewDecWithPrec(40, 2)},
			},
			wantErr: true,
			errMsg:  "sum of distribution entity shares don't equal 100%",
		},
		{
			name: "sum of shares less than 100%",
			input: []types.DistributionEntity{
				{Address: validAddr1, Share: math.LegacyNewDecWithPrec(30, 2)},
				{Address: validAddr2, Share: math.LegacyNewDecWithPrec(40, 2)},
			},
			wantErr: true,
			errMsg:  "sum of distribution entity shares don't equal 100%",
		},
		{
			name: "zero share",
			input: []types.DistributionEntity{
				{Address: validAddr1, Share: math.LegacyZeroDec()},
				{Address: validAddr2, Share: math.LegacyOneDec()},
			},
			wantErr: true,
			errMsg:  "distribution entity share must be greater than 0",
		},
		{
			name: "negative share",
			input: []types.DistributionEntity{
				{Address: validAddr1, Share: math.LegacyNewDec(-1)},
				{Address: validAddr2, Share: math.LegacyOneDec()},
			},
			wantErr: true,
			errMsg:  "distribution entity share must be greater than 0",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			err := types.ValidateDistributionEntityParams(tt.input)
			if tt.wantErr {
				require.Error(t, err)
				require.Contains(t, err.Error(), tt.errMsg)
			} else {
				require.NoError(t, err)
			}
		})
	}
}

func TestParamsString(t *testing.T) {
	params := types.Params{
		DistributionEntities: []types.DistributionEntity{
			{
				Address: "cosmos1exampleaddress",
				Share:   math.LegacyMustNewDecFromStr("0.5"),
			},
			{
				Address: "cosmos1anotheraddress",
				Share:   math.LegacyMustNewDecFromStr("0.5"),
			},
		},
	}
	expectedOutput, err := yaml.Marshal(params)
	require.NoError(t, err)
	result := params.String()
	require.Equal(t, string(expectedOutput), result, "Params.String() output mismatch")
	require.NotEmpty(t, result, "Params.String() should not return an empty string")
}

func TestDefaultGenesis(t *testing.T) {
	defaultGenesis := types.DefaultGenesis()
	require.NotNil(t, defaultGenesis, "DefaultGenesis should not return nil")

	expectedParams := types.DefaultParams()
	require.Equal(t, expectedParams, defaultGenesis.Params, "DefaultGenesis should return genesis state with default parameters")
}

func TestDefaultParams(t *testing.T) {
	defaultParams := types.DefaultParams()
	require.Equal(t, math.LegacyDec{}, defaultParams.Share, "Share should be zero")
	require.Empty(t, defaultParams.DistributionEntities, "DistributionEntities should be an empty slice")
	require.Equal(t, math.NewInt(0), defaultParams.TransferFeeBps, "TransferFeeBps should be zero")
	require.Equal(t, math.NewInt(0), defaultParams.TransferFeeMax, "TransferFeeMax should be zero")
	require.Equal(t, "", defaultParams.TransferFeeDenom, "TransferFeeDenom should be an empty string")
}

func TestParamSetPairs(t *testing.T) {
	params := types.Params{
		Share:                sdkmath.LegacyDec{},
		DistributionEntities: []types.DistributionEntity{},
		TransferFeeBps:       sdkmath.NewInt(0),
		TransferFeeMax:       sdkmath.NewInt(0),
		TransferFeeDenom:     "",
	}

	paramSetPairs := params.ParamSetPairs()
	require.Len(t, paramSetPairs, 5, "ParamSetPairs should contain 5 elements")
	require.Equal(t, types.KeyShare, paramSetPairs[0].Key, "Key for Share should match")
	require.Equal(t, &params.Share, paramSetPairs[0].Value, "Value for Share should match")

	require.Equal(t, types.KeyDistributionEntities, paramSetPairs[1].Key, "Key for DistributionEntities should match")
	require.Equal(t, &params.DistributionEntities, paramSetPairs[1].Value, "Value for DistributionEntities should match")

	require.Equal(t, types.KeyTransferFeeBPS, paramSetPairs[2].Key, "Key for TransferFeeBps should match")
	require.Equal(t, &params.TransferFeeBps, paramSetPairs[2].Value, "Value for TransferFeeBps should match")

	require.Equal(t, types.KeyTransferFeeMax, paramSetPairs[3].Key, "Key for TransferFeeMax should match")
	require.Equal(t, &params.TransferFeeMax, paramSetPairs[3].Value, "Value for TransferFeeMax should match")

	require.Equal(t, types.KeyTransferFeeDenom, paramSetPairs[4].Key, "Key for TransferFeeDenom should match")
	require.Equal(t, &params.TransferFeeDenom, paramSetPairs[4].Value, "Value for TransferFeeDenom should match")

}
func TestValidateTransferFeeBPS(t *testing.T) {
	validFee := math.NewInt(5000)
	err := types.ValidateTransferFeeBPS(validFee)
	require.NoError(t, err, "ValidateTransferFeeBPS should not return an error for valid fee")
	validFeeZero := math.NewInt(0)
	err = types.ValidateTransferFeeBPS(validFeeZero)
	require.NoError(t, err, "ValidateTransferFeeBPS should not return an error for fee of 0")
	validFeeMax := math.NewInt(10000)
	err = types.ValidateTransferFeeBPS(validFeeMax)
	require.NoError(t, err, "ValidateTransferFeeBPS should not return an error for fee of 10000")
	invalidFeeNegative := math.NewInt(-100)
	err = types.ValidateTransferFeeBPS(invalidFeeNegative)
	require.Error(t, err, "ValidateTransferFeeBPS should return an error for fee less than 0")
	require.Equal(t, fmt.Sprintf("ibc transfer basis points fee is outside of the range of 0 to 10000: %s", invalidFeeNegative.String()), err.Error(), "error message should match")
	invalidFeeGreaterThanMax := math.NewInt(15000)
	err = types.ValidateTransferFeeBPS(invalidFeeGreaterThanMax)
	require.Error(t, err, "ValidateTransferFeeBPS should return an error for fee greater than 10000")
	require.Equal(t, fmt.Sprintf("ibc transfer basis points fee is outside of the range of 0 to 10000: %s", invalidFeeGreaterThanMax.String()), err.Error(), "error message should match")
}

func TestValidateTransferFeeMax(t *testing.T) {
	validFee := math.NewInt(5000)
	err := types.ValidateTransferFeeMax(validFee)
	require.NoError(t, err, "ValidateTransferFeeMax should not return an error for valid fee")
	validFeeZero := math.NewInt(0)
	err = types.ValidateTransferFeeMax(validFeeZero)
	require.NoError(t, err, "ValidateTransferFeeMax should not return an error for fee of 0")
	invalidFeeNegative := math.NewInt(-100)
	err = types.ValidateTransferFeeMax(invalidFeeNegative)
	require.Error(t, err, "ValidateTransferFeeMax should return an error for fee less than 0")
	require.Equal(t, fmt.Sprintf("ibc transfer max fee is less than 0: %s", invalidFeeNegative.String()), err.Error(), "error message should match")
}

func TestValidateTransferFeeDenom(t *testing.T) {
	emptyDenom := ""
	err := types.ValidateTransferFeeDenom(emptyDenom)
	require.NoError(t, err, "ValidateTransferFeeDenom should not return an error for an empty denom")
	validDenom := "validdenom"
	err = types.ValidateTransferFeeDenom(validDenom)
	require.NoError(t, err, "ValidateTransferFeeDenom should not return an error for a valid denom")
	invalidDenom := "invalid!denom"
	err = types.ValidateTransferFeeDenom(invalidDenom)
	require.Error(t, err, "ValidateTransferFeeDenom should return an error for an invalid denom")
}
