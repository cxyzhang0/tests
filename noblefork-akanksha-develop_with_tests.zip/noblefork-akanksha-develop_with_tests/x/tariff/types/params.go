package types

import (
	"fmt"

	"cosmossdk.io/math"
	cosmossdk_io_math "cosmossdk.io/math"
	sdkmath "cosmossdk.io/math"
	sdk "github.com/cosmos/cosmos-sdk/types"
	paramtypes "github.com/cosmos/cosmos-sdk/x/params/types"
	"gopkg.in/yaml.v2"
)

var (
	KeyShare                = []byte("Share")
	KeyDistributionEntities = []byte("DistributionEntities")
	KeyTransferFeeBPS       = []byte("TransferFeeBPS")
	KeyTransferFeeMax       = []byte("TransferFeeMax")
	KeyTransferFeeDenom     = []byte("TransferFeeDenom")
)

var _ paramtypes.ParamSet = (*Params)(nil)

// ParamKeyTable the param key table for launch module
func ParamKeyTable() paramtypes.KeyTable {
	return paramtypes.NewKeyTable().RegisterParamSet(&Params{})
}

// DefaultParams returns a default set of parameters
func DefaultParams() Params {
	return Params{
		Share:                sdkmath.LegacyDec{},         // Ensure it's explicitly set to zero
		DistributionEntities: []DistributionEntity{},      // Empty slice is fine
		TransferFeeBps:       cosmossdk_io_math.NewInt(0), // Ensure it's explicitly set to zero
		TransferFeeMax:       cosmossdk_io_math.NewInt(0), // Ensure it's explicitly set to zero
		TransferFeeDenom:     "",                          // Default empty string
	}
}

// ParamSetPairs get the params.ParamSet
func (p *Params) ParamSetPairs() paramtypes.ParamSetPairs {
	return paramtypes.ParamSetPairs{
		paramtypes.NewParamSetPair(KeyShare, &p.Share, ValidateShare),
		paramtypes.NewParamSetPair(KeyDistributionEntities, &p.DistributionEntities, ValidateDistributionEntityParams),
		paramtypes.NewParamSetPair(KeyTransferFeeBPS, &p.TransferFeeBps, ValidateTransferFeeBPS),
		paramtypes.NewParamSetPair(KeyTransferFeeMax, &p.TransferFeeMax, ValidateTransferFeeMax),
		paramtypes.NewParamSetPair(KeyTransferFeeDenom, &p.TransferFeeDenom, ValidateTransferFeeDenom),
	}
}

func ValidateDistributionEntityParams(i interface{}) error {
	distributionEntities, ok := i.([]DistributionEntity)
	if !ok {
		return fmt.Errorf("invalid parameter type: %T", i)
	}
	// ensure each denom is only registered one time.
	sum := math.LegacyZeroDec()
	for _, d := range distributionEntities {
		adr, _ := sdk.AccAddressFromBech32(d.Address)

		count := 0
		for _, dd := range distributionEntities {
			if dd.Address == adr.String() {
				count++
			}
		}
		if count > 1 {
			return fmt.Errorf("address is already added as a distribution entity: %s", adr)
		}

		if d.Share.LTE(math.LegacyZeroDec()) || d.Share.GT(math.LegacyOneDec()) {
			return fmt.Errorf("distribution entity share must be greater than 0 and less than or equal to 100%%: %s", d.Share.String())
		}

		sum = sum.Add(d.Share)
	}

	if len(distributionEntities) > 0 && !sum.Equal(math.LegacyOneDec()) {
		return fmt.Errorf("sum of distribution entity shares don't equal 100%%: %s", sum.String())
	}

	return nil
}

func ValidateShare(i interface{}) error {
	share, _ := i.(math.LegacyDec)

	if share.LT(math.LegacyZeroDec()) || share.GT(math.LegacyOneDec()) {
		return fmt.Errorf("share is outside of the range of 0 to 100%%: %s", share.String())
	}
	return nil
}

func ValidateTransferFeeBPS(i interface{}) error {
	transferFeeBPS, _ := i.(math.Int)

	if transferFeeBPS.LT(math.ZeroInt()) || transferFeeBPS.GT(math.NewInt(10000)) {
		return fmt.Errorf("ibc transfer basis points fee is outside of the range of 0 to 10000: %s", transferFeeBPS.String())
	}
	return nil
}

func ValidateTransferFeeMax(i interface{}) error {
	transferFeeMax, _ := i.(math.Int)

	if transferFeeMax.LT(math.ZeroInt()) {
		return fmt.Errorf("ibc transfer max fee is less than 0: %s", transferFeeMax.String())
	}
	return nil
}

func ValidateTransferFeeDenom(i interface{}) error {
	transferFeeDenom, _ := i.(string)

	if transferFeeDenom == "" {
		return nil
	}
	return sdk.ValidateDenom(transferFeeDenom)
}

// Validate validates the set of params
func (p Params) Validate() error {
	ValidateShare(p.Share)

	ValidateDistributionEntityParams(p.DistributionEntities)
	ValidateTransferFeeBPS(p.TransferFeeBps)

	ValidateTransferFeeMax(p.TransferFeeMax)

	ValidateTransferFeeDenom(p.TransferFeeDenom)
	return nil
}

// String implements the Stringer interface.
func (p Params) String() string {
	out, _ := yaml.Marshal(p)
	return string(out)
}
