package forwarding

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"

	"cosmossdk.io/core/address"
	abci "github.com/cometbft/cometbft/abci/types"
	"github.com/cosmos/cosmos-sdk/client"
	"github.com/cosmos/cosmos-sdk/codec"
	codectypes "github.com/cosmos/cosmos-sdk/codec/types"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/cosmos/cosmos-sdk/types/module"
	"github.com/gorilla/mux"
	"github.com/grpc-ecosystem/grpc-gateway/runtime"
	"github.com/spf13/cobra"
	"github.com/wfblockchain/noblechain/v5/x/forwarding/client/cli"
	"github.com/wfblockchain/noblechain/v5/x/forwarding/keeper"
	"github.com/wfblockchain/noblechain/v5/x/forwarding/types"
)

// var (
//  _ module.EndBlockAppModule = AppModule{}
//  _ module.AppModuleBasic    = AppModuleBasic{}
// )

type AppModuleBasic struct {
	cdc codec.Codec
	ac  address.Codec
}

type AppModule struct {
	AppModuleBasic

	Keeper *keeper.Keeper
}

// IsAppModule implements the appmodule.AppModule interface.
func (AppModule) IsAppModule() {}

// IsOnePerModuleType implements the depinject.OnePerModuleType interface.
func (AppModule) IsOnePerModuleType() {}

func NewAppModule(keeper *keeper.Keeper) AppModule {
	return AppModule{
		AppModuleBasic: NewAppModuleBasic(),
		Keeper:         keeper,
	}
}

func (am AppModule) InitGenesis(ctx sdk.Context, cdc codec.JSONCodec, bz json.RawMessage) []abci.ValidatorUpdate {
	var genesis types.GenesisState
	cdc.MustUnmarshalJSON(bz, &genesis)

	InitGenesis(ctx, am.Keeper, genesis)

	return []abci.ValidatorUpdate{}
}

func (am AppModule) ExportGenesis(ctx sdk.Context, cdc codec.JSONCodec) json.RawMessage {
	genesis := ExportGenesis(ctx, am.Keeper)
	return cdc.MustMarshalJSON(genesis)
}

func (AppModule) RegisterInvariants(_ sdk.InvariantRegistry) {}

//func (AppModule) Route() sdk.Route { return sdk.Route{} }

func (AppModule) QuerierRoute() string { return types.ModuleName }

//func (AppModule) LegacyQuerierHandler(_ *codec.LegacyAmino) sdk.Querier { return nil }

func (am AppModule) RegisterServices(cfg module.Configurator) {
	types.RegisterMsgServer(cfg.MsgServer(), am.Keeper)
	types.RegisterQueryServer(cfg.QueryServer(), am.Keeper)
}

func (AppModule) ConsensusVersion() uint64 { return 1 }

// func (am AppModule) EndBlock(ctx sdk.Context, _ abci.RequestFinalizeBlock) []abci.ValidatorUpdate {
// 	am.Keeper.ExecuteForwards(ctx)

// 	return []abci.ValidatorUpdate{}
// }

//

func NewAppModuleBasic() AppModuleBasic {
	return AppModuleBasic{}
}

func (AppModuleBasic) Name() string {
	return types.ModuleName
}

func (AppModuleBasic) RegisterLegacyAminoCodec(cdc *codec.LegacyAmino) {
	types.RegisterLegacyAminoCodec(cdc)
}

func (AppModuleBasic) RegisterInterfaces(reg codectypes.InterfaceRegistry) {
	types.RegisterInterfaces(reg)
}

func (AppModuleBasic) DefaultGenesis(cdc codec.JSONCodec) json.RawMessage {
	return cdc.MustMarshalJSON(types.DefaultGenesisState())
}

func (AppModuleBasic) ValidateGenesis(cdc codec.JSONCodec, cfg client.TxEncodingConfig, bz json.RawMessage) error {
	var genesis types.GenesisState
	if err := cdc.UnmarshalJSON(bz, &genesis); err != nil {
		return fmt.Errorf("failed to unmarshal %s genesis state: %w", types.ModuleName, err)
	}

	return genesis.Validate()
}

func (AppModuleBasic) RegisterRESTRoutes(_ client.Context, rtr *mux.Router) {
	rtr.HandleFunc("/forwarding/register-account", postRegisterAccountHandler).Methods(http.MethodPost)
}

func postRegisterAccountHandler(w http.ResponseWriter, r *http.Request) {
	w.Write([]byte("Registration successful"))
}

func (AppModuleBasic) RegisterGRPCGatewayRoutes(clientCtx client.Context, mux *runtime.ServeMux) {
	_ = types.RegisterQueryHandlerClient(context.Background(), mux, types.NewQueryClient(clientCtx))
}

func (AppModuleBasic) GetTxCmd() *cobra.Command { return cli.GetTxCmd() }

// func (ab AppModuleBasic) GetTxCmd() *cobra.Command {
//  return cli.NewTxCmd(ab.cdc.InterfaceRegistry().SigningContext().ValidatorAddressCodec(), ab.cdc.InterfaceRegistry().SigningContext().AddressCodec())
// }

func (AppModuleBasic) GetQueryCmd() *cobra.Command { return cli.GetQueryCmd() }
