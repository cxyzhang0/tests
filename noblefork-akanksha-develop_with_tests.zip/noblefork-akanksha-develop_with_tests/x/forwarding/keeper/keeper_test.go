package keeper_test

import (
	"context"
	"testing"

	tmproto "github.com/cometbft/cometbft/proto/tendermint/types"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"

	"cosmossdk.io/log"
	storetypes "cosmossdk.io/store/types"
	"github.com/cosmos/cosmos-sdk/codec"
	sdk "github.com/cosmos/cosmos-sdk/types"
	clienttypes "github.com/cosmos/ibc-go/v8/modules/core/02-client/types"
	channeltypes "github.com/cosmos/ibc-go/v8/modules/core/04-channel/types"
	"github.com/wfblockchain/noblechain/v5/x/forwarding/keeper"
	"github.com/wfblockchain/noblechain/v5/x/forwarding/types"
)

type MockAccountKeeper struct{ mock.Mock }

func (m *MockAccountKeeper) GetAccount(ctx context.Context, addr sdk.AccAddress) sdk.AccountI {
	return nil
}

func (m *MockAccountKeeper) HasAccount(ctx context.Context, addr sdk.AccAddress) bool {
	return false
}

func (m *MockAccountKeeper) SetAccount(ctx context.Context, acc sdk.AccountI) {
}

type MockBankKeeper struct{ mock.Mock }

func (m *MockBankKeeper) GetAllBalances(ctx context.Context, addr sdk.AccAddress) sdk.Coins {
	return sdk.Coins{}
}

func (m *MockChannelKeeper) GetChannel(ctx sdk.Context, portID, channelID string) (channeltypes.Channel, bool) {
	return channeltypes.Channel{}, false
}

type MockChannelKeeper struct{ mock.Mock }
type MockTransferKeeper struct{ mock.Mock }

func (m *MockTransferKeeper) SendTransfer(
	ctx sdk.Context,
	sourcePort, sourceChannel string,
	token sdk.Coin,
	sender sdk.AccAddress,
	receiver string,
	timeoutHeight clienttypes.Height,
	timeoutTimestamp uint64,
) error {
	return nil
}

func TestNewKeeper(t *testing.T) {
	var cdc codec.Codec
	storeKey := storetypes.NewKVStoreKey("test_store")
	transientKey := storetypes.NewTransientStoreKey("test_transient")
	accountKeeper := new(MockAccountKeeper)
	bankKeeper := new(MockBankKeeper)
	channelKeeper := new(MockChannelKeeper)
	transferKeeper := new(MockTransferKeeper)
	keeper := keeper.NewKeeper(cdc, storeKey, transientKey, accountKeeper, bankKeeper, channelKeeper, transferKeeper)
	require.NotNil(t, keeper)
}

func TestSetTransferKeeper(t *testing.T) {
	var cdc codec.Codec
	storeKey := storetypes.NewKVStoreKey("test_store")
	transientKey := storetypes.NewTransientStoreKey("test_transient")
	accountKeeper := new(MockAccountKeeper)
	bankKeeper := new(MockBankKeeper)
	channelKeeper := new(MockChannelKeeper)
	transferKeeper1 := new(MockTransferKeeper)
	transferKeeper2 := new(MockTransferKeeper)
	keeper := keeper.NewKeeper(cdc, storeKey, transientKey, accountKeeper, bankKeeper, channelKeeper, transferKeeper1)
	keeper.SetTransferKeeper(transferKeeper2)
}

func TestLogger(t *testing.T) {
	ctx := sdk.NewContext(nil, tmproto.Header{}, false, log.NewNopLogger())
	keeper := &keeper.Keeper{}
	logger := keeper.Logger(ctx)
	require.NotNil(t, logger)
	expected := ctx.Logger().With("module", types.ModuleName)
	require.Equal(t, expected, logger)
}

func TestMsgRegisterAccount_ValidateBasic(t *testing.T) {
	tests := []struct {
		name      string
		msg       types.MsgRegisterAccount
		expectErr bool
	}{
		{
			name: "valid message",
			msg: types.MsgRegisterAccount{
				Signer:  sdk.AccAddress([]byte("valid_address")).String(),
				Channel: "channel-0",
			},
			expectErr: false,
		},
		{
			name: "invalid signer",
			msg: types.MsgRegisterAccount{
				Signer:  "invalid_signer_address",
				Channel: "channel-0",
			},
			expectErr: true,
		},
		{
			name: "invalid channel",
			msg: types.MsgRegisterAccount{
				Signer:  sdk.AccAddress([]byte("valid_address")).String(),
				Channel: "invalid_channel_id",
			},
			expectErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			err := tt.msg.ValidateBasic()
			if tt.expectErr {
				require.Error(t, err, "expected error for case: %s", tt.name)
			} else {
				require.NoError(t, err, "unexpected error for case: %s", tt.name)
			}
		})
	}
}

func TestMsgRegisterAccount_GetSigners(t *testing.T) {
	validAddr := sdk.AccAddress([]byte("valid_address")).String()

	tests := []struct {
		name      string
		msg       types.MsgRegisterAccount
		expectErr bool
	}{
		{
			name: "valid signer",
			msg: types.MsgRegisterAccount{
				Signer: validAddr,
			},
			expectErr: false,
		},
		{
			name: "invalid signer - should panic",
			msg: types.MsgRegisterAccount{
				Signer: "invalid_signer_address",
			},
			expectErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if tt.expectErr {
				require.Panics(t, func() {
					tt.msg.GetSigners()
				}, "expected panic for case: %s", tt.name)
			} else {
				signers := tt.msg.GetSigners()
				require.Len(t, signers, 1, "expected one signer")
				require.Equal(t, validAddr, signers[0].String(), "signer mismatch")
			}
		})
	}
}

func TestMsgRegisterAccount_GetSignBytes(t *testing.T) {
	msg := types.MsgRegisterAccount{
		Signer:  "cosmos1xyzxyzxyzxyzxyzxyzxyzxyzxyzxyzxyzxyz",
		Channel: "channel-0",
	}
	signBytes := msg.GetSignBytes()
	require.NotEmpty(t, signBytes, "GetSignBytes should not return an empty byte array")
	expectedJSON, err := types.ModuleCdc.MarshalJSON(&msg)
	require.NoError(t, err, "JSON marshalling should not fail")

	expectedSortedJSON := sdk.MustSortJSON(expectedJSON)
	require.Equal(t, expectedSortedJSON, signBytes, "Sign bytes should match sorted JSON")
}

func TestMsgRegisterAccount_Route(t *testing.T) {
	msg := types.MsgRegisterAccount{}
	require.Equal(t, types.ModuleName, msg.Route(), "Route should return the correct module name")
}
func TestMsgRegisterAccount_Type(t *testing.T) {
	msg := types.MsgRegisterAccount{}
	expectedType := "noble/forwarding/RegisterAccount"
	require.Equal(t, expectedType, msg.Type(), "Type should return the correct message type")
}

func TestMsgClearAccount_Type(t *testing.T) {
	msg := types.MsgClearAccount{}
	expectedType := "noble/forwarding/ClearAccount"

	require.Equal(t, expectedType, msg.Type(), "Type() should return the correct message type")
}

type MockKeeper struct {
	mock.Mock
}

func (m *MockKeeper) GetNumOfAccounts(ctx sdk.Context, channel string) uint64 {
	args := m.Called(ctx, channel)
	return args.Get(0).(uint64)
}

func (m *MockKeeper) GetNumOfForwards(ctx sdk.Context, channel string) uint64 {
	args := m.Called(ctx, channel)
	return args.Get(0).(uint64)
}

func (m *MockKeeper) GetTotalForwarded(ctx sdk.Context, channel string) sdk.Coin {
	args := m.Called(ctx, channel)
	return args.Get(0).(sdk.Coin)
}

type StatsGetter interface {
	GetNumOfAccounts(ctx sdk.Context, channel string) uint64
	GetNumOfForwards(ctx sdk.Context, channel string) uint64
	GetTotalForwarded(ctx sdk.Context, channel string) sdk.Coin
}

type Keeper struct {
	statsGetter StatsGetter
}
