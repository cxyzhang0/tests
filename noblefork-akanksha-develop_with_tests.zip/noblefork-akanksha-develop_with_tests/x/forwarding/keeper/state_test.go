package keeper_test

import (
	"strconv"
	"testing"

	"cosmossdk.io/log"
	"cosmossdk.io/math"
	"cosmossdk.io/store/metrics"
	"cosmossdk.io/store/rootmulti"
	storetypes "cosmossdk.io/store/types"
	tmproto "github.com/cometbft/cometbft/proto/tendermint/types"
	db "github.com/cosmos/cosmos-db"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/stretchr/testify/require"
	"github.com/wfblockchain/noblechain/v5/x/forwarding/keeper"
	"github.com/wfblockchain/noblechain/v5/x/forwarding/types"
)

func TestGetNumOfAccounts(t *testing.T) {
	db := db.NewMemDB()

	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	cms := rootmulti.NewStore(db, logger, storeMetrics)

	storeKey := storetypes.NewKVStoreKey("forwarding")
	cms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	_ = cms.LoadLatestVersion()

	ctx := sdk.NewContext(cms, tmproto.Header{}, false, nil)

	k := keeper.Keeper{StoreKey: storeKey}

	channel := "channel-123"

	t.Run("Returns 0 when key does not exist", func(t *testing.T) {
		count := k.GetNumOfAccounts(ctx, channel)
		require.Equal(t, uint64(0), count)
	})

	t.Run("Returns stored count when key exists", func(t *testing.T) {
		expectedCount := uint64(5)
		bz := []byte(strconv.FormatUint(expectedCount, 10))

		ctx.KVStore(storeKey).Set(types.NumOfAccountsKey(channel), bz)

		count := k.GetNumOfAccounts(ctx, channel)
		require.Equal(t, expectedCount, count)
	})

	t.Run("Handles invalid stored data gracefully", func(t *testing.T) {
		ctx.KVStore(storeKey).Set(types.NumOfAccountsKey(channel), []byte("invalid"))

		count := k.GetNumOfAccounts(ctx, channel)
		require.Equal(t, uint64(0), count)
	})
}

func TestGetAllNumOfAccounts(t *testing.T) {
	memDB := db.NewMemDB()
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()
	cms := rootmulti.NewStore(memDB, logger, storeMetrics)

	storeKey := storetypes.NewKVStoreKey("forwarding")
	cms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, memDB)
	_ = cms.LoadLatestVersion()

	ctx := sdk.NewContext(cms, tmproto.Header{}, false, logger)
	k := keeper.Keeper{StoreKey: storeKey}

	t.Run("Returns empty map when no accounts exist", func(t *testing.T) {
		counts := k.GetAllNumOfAccounts(ctx)
		require.Empty(t, counts)
	})

	t.Run("Returns all stored channel counts", func(t *testing.T) {
		expectedCounts := map[string]uint64{
			"channel-1": 10,
			"channel-2": 5,
			"channel-3": 7,
		}

		store := ctx.KVStore(storeKey)
		for channel, count := range expectedCounts {
			bz := []byte(strconv.FormatUint(count, 10))
			store.Set(append(types.NumOfAccountsPrefix, []byte(channel)...), bz)
		}

		counts := k.GetAllNumOfAccounts(ctx)
		require.Equal(t, expectedCounts, counts)
	})

	t.Run("Handles invalid stored data gracefully", func(t *testing.T) {
		store := ctx.KVStore(storeKey)
		store.Set(append(types.NumOfAccountsPrefix, []byte("channel-invalid")...), []byte("invalid"))

		k.GetAllNumOfAccounts(ctx)

	})
}

func TestIncrementNumOfAccounts(t *testing.T) {
	memDB := db.NewMemDB()
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()
	cms := rootmulti.NewStore(memDB, logger, storeMetrics)
	storeKey := storetypes.NewKVStoreKey("forwarding")
	cms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, memDB)
	_ = cms.LoadLatestVersion()
	ctx := sdk.NewContext(cms, tmproto.Header{}, false, logger)
	k := keeper.Keeper{StoreKey: storeKey}

	t.Run("Increments count when account exists", func(t *testing.T) {
		channel := "channel-1"
		key := types.NumOfAccountsKey(channel)
		ctx.KVStore(storeKey).Set(key, []byte(strconv.Itoa(5)))
		k.IncrementNumOfAccounts(ctx, channel)
		bz := ctx.KVStore(storeKey).Get(key)
		require.NotNil(t, bz)
		newCount, err := strconv.ParseUint(string(bz), 10, 64)
		require.NoError(t, err)
		require.Equal(t, uint64(6), newCount)
	})

	t.Run("Initializes count to 1 when account does not exist", func(t *testing.T) {
		channel := "channel-2"
		key := types.NumOfAccountsKey(channel)
		require.Nil(t, ctx.KVStore(storeKey).Get(key))
		k.IncrementNumOfAccounts(ctx, channel)
		bz := ctx.KVStore(storeKey).Get(key)
		require.NotNil(t, bz)
		newCount, err := strconv.ParseUint(string(bz), 10, 64)
		require.NoError(t, err)
		require.Equal(t, uint64(1), newCount)
	})
}

func TestSetNumOfAccounts(t *testing.T) {
	memDB := db.NewMemDB()
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()
	cms := rootmulti.NewStore(memDB, logger, storeMetrics)
	storeKey := storetypes.NewKVStoreKey("forwarding")
	cms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, memDB)
	_ = cms.LoadLatestVersion()

	ctx := sdk.NewContext(cms, tmproto.Header{}, false, logger)
	k := keeper.Keeper{StoreKey: storeKey}

	t.Run("Sets account count for a new channel", func(t *testing.T) {
		channel := "channel-1"
		count := uint64(10)
		k.SetNumOfAccounts(ctx, channel, count)
		key := types.NumOfAccountsKey(channel)
		bz := ctx.KVStore(storeKey).Get(key)
		require.NotNil(t, bz)
		storedCount, err := strconv.ParseUint(string(bz), 10, 64)
		require.NoError(t, err)
		require.Equal(t, count, storedCount)
	})

	t.Run("Updates account count for an existing channel", func(t *testing.T) {
		channel := "channel-1"
		newCount := uint64(25)

		k.SetNumOfAccounts(ctx, channel, newCount)
		key := types.NumOfAccountsKey(channel)
		bz := ctx.KVStore(storeKey).Get(key)
		require.NotNil(t, bz)
		storedCount, err := strconv.ParseUint(string(bz), 10, 64)
		require.NoError(t, err)
		require.Equal(t, newCount, storedCount)
	})
}

func TestGetNumOfForwards(t *testing.T) {
	memDB := db.NewMemDB()
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()
	cms := rootmulti.NewStore(memDB, logger, storeMetrics)
	storeKey := storetypes.NewKVStoreKey("forwarding")
	cms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, memDB)
	_ = cms.LoadLatestVersion()
	ctx := sdk.NewContext(cms, tmproto.Header{}, false, logger)
	k := keeper.Keeper{StoreKey: storeKey}

	t.Run("Returns 0 when no forwards exist", func(t *testing.T) {
		channel := "channel-1"
		count := k.GetNumOfForwards(ctx, channel)
		require.Equal(t, uint64(0), count)
	})

	t.Run("Retrieves stored forward count", func(t *testing.T) {
		channel := "channel-1"
		expectedCount := uint64(15)
		key := types.NumOfForwardsKey(channel)
		bz := []byte(strconv.FormatUint(expectedCount, 10))
		ctx.KVStore(storeKey).Set(key, bz)
		count := k.GetNumOfForwards(ctx, channel)
		require.Equal(t, expectedCount, count)
	})

	t.Run("Handles corrupted data gracefully", func(t *testing.T) {
		channel := "channel-invalid"
		key := types.NumOfForwardsKey(channel)
		ctx.KVStore(storeKey).Set(key, []byte("invalid"))
		count := k.GetNumOfForwards(ctx, channel)
		require.Equal(t, uint64(0), count)
	})
}

func TestGetAllNumOfForwards(t *testing.T) {
	memDB := db.NewMemDB()
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()
	cms := rootmulti.NewStore(memDB, logger, storeMetrics)
	storeKey := storetypes.NewKVStoreKey("forwarding")
	cms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, memDB)
	_ = cms.LoadLatestVersion()
	ctx := sdk.NewContext(cms, tmproto.Header{}, false, logger)
	k := keeper.Keeper{StoreKey: storeKey}

	t.Run("Returns empty map when no forwards exist", func(t *testing.T) {
		counts := k.GetAllNumOfForwards(ctx)
		require.Empty(t, counts)
	})

	t.Run("Retrieves all stored forward counts", func(t *testing.T) {
		expectedCounts := map[string]uint64{
			"channel-1": 8,
			"channel-2": 3,
			"channel-3": 12,
		}

		store := ctx.KVStore(storeKey)
		for channel, count := range expectedCounts {
			key := append(types.NumOfForwardsPrefix, []byte(channel)...)
			bz := []byte(strconv.FormatUint(count, 10))
			store.Set(key, bz)
		}

		counts := k.GetAllNumOfForwards(ctx)

		require.Equal(t, expectedCounts, counts)
	})

	t.Run("Handles invalid stored data gracefully", func(t *testing.T) {
		store := ctx.KVStore(storeKey)
		key := append(types.NumOfForwardsPrefix, []byte("channel-invalid")...)
		store.Set(key, []byte("invalid"))

		k.GetAllNumOfForwards(ctx)

	})
}

func TestIncrementNumOfForwards(t *testing.T) {
	memDB := db.NewMemDB()
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()
	cms := rootmulti.NewStore(memDB, logger, storeMetrics)
	storeKey := storetypes.NewKVStoreKey("forwarding")
	cms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, memDB)
	_ = cms.LoadLatestVersion()
	ctx := sdk.NewContext(cms, tmproto.Header{}, false, logger)
	k := keeper.Keeper{StoreKey: storeKey}

	t.Run("Increments forward count from zero", func(t *testing.T) {
		channel := "channel-1"
		k.IncrementNumOfForwards(ctx, channel)
		count := k.GetNumOfForwards(ctx, channel)
		require.Equal(t, uint64(1), count)
	})

	t.Run("Increments existing forward count", func(t *testing.T) {
		channel := "channel-2"
		store := ctx.KVStore(storeKey)
		key := types.NumOfForwardsKey(channel)
		store.Set(key, []byte(strconv.Itoa(5)))
		k.IncrementNumOfForwards(ctx, channel)
		count := k.GetNumOfForwards(ctx, channel)
		require.Equal(t, uint64(6), count)
	})
}

func TestSetNumOfForwards(t *testing.T) {
	memDB := db.NewMemDB()
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()
	cms := rootmulti.NewStore(memDB, logger, storeMetrics)
	storeKey := storetypes.NewKVStoreKey("forwarding")
	cms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, memDB)
	_ = cms.LoadLatestVersion()
	ctx := sdk.NewContext(cms, tmproto.Header{}, false, logger)
	k := keeper.Keeper{StoreKey: storeKey}

	t.Run("Sets the number of forwards correctly", func(t *testing.T) {
		channel := "channel-1"
		expectedCount := uint64(10)
		k.SetNumOfForwards(ctx, channel, expectedCount)
		store := ctx.KVStore(storeKey)
		key := types.NumOfForwardsKey(channel)
		bz := store.Get(key)
		count, err := strconv.ParseUint(string(bz), 10, 64)
		require.NoError(t, err)
		require.Equal(t, expectedCount, count)
	})

	t.Run("Overwrites an existing number of forwards", func(t *testing.T) {
		channel := "channel-2"
		k.SetNumOfForwards(ctx, channel, 5)
		k.SetNumOfForwards(ctx, channel, 20)
		store := ctx.KVStore(storeKey)
		key := types.NumOfForwardsKey(channel)
		bz := store.Get(key)
		count, err := strconv.ParseUint(string(bz), 10, 64)
		require.NoError(t, err)
		require.Equal(t, uint64(20), count)
	})
}

func TestGetTotalForwarded(t *testing.T) {
	memDB := db.NewMemDB()
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()
	cms := rootmulti.NewStore(memDB, logger, storeMetrics)
	storeKey := storetypes.NewKVStoreKey("forwarding")
	cms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, memDB)
	_ = cms.LoadLatestVersion()
	ctx := sdk.NewContext(cms, tmproto.Header{}, false, logger)
	k := keeper.Keeper{StoreKey: storeKey}

	t.Run("Returns empty coins when no total forwarded exists", func(t *testing.T) {
		channel := "channel-1"
		total := k.GetTotalForwarded(ctx, channel)
		require.True(t, total.IsZero())
	})

	t.Run("Returns the correct total forwarded coins", func(t *testing.T) {
		channel := "channel-2"
		expectedTotal, _ := sdk.ParseCoinsNormalized("1000stake,500uatom")
		store := ctx.KVStore(storeKey)
		key := types.TotalForwardedKey(channel)
		store.Set(key, []byte(expectedTotal.String()))
		total := k.GetTotalForwarded(ctx, channel)
		require.Equal(t, expectedTotal, total)
	})
}

func TestGetAllTotalForwarded(t *testing.T) {
	memDB := db.NewMemDB()
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()
	cms := rootmulti.NewStore(memDB, logger, storeMetrics)
	storeKey := storetypes.NewKVStoreKey("forwarding")
	cms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, memDB)
	_ = cms.LoadLatestVersion()
	ctx := sdk.NewContext(cms, tmproto.Header{}, false, logger)
	k := keeper.Keeper{StoreKey: storeKey}

	t.Run("Returns empty map when no total forwarded exists", func(t *testing.T) {
		totals := k.GetAllTotalForwarded(ctx)
		require.Empty(t, totals)
	})

	t.Run("Returns all stored total forwarded amounts", func(t *testing.T) {
		expectedTotals := map[string]string{
			"channel-1": "1000stake,500uatom",
			"channel-2": "2000usdc",
			"channel-3": "3000udai,1500uluna",
		}

		store := ctx.KVStore(storeKey)
		for channel, total := range expectedTotals {
			key := append(types.TotalForwardedPrefix, []byte(channel)...)
			store.Set(key, []byte(total))
		}

		totals := k.GetAllTotalForwarded(ctx)
		require.Equal(t, expectedTotals, totals)
	})
}

func TestIncrementTotalForwarded(t *testing.T) {
	memDB := db.NewMemDB()
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()
	cms := rootmulti.NewStore(memDB, logger, storeMetrics)
	storeKey := storetypes.NewKVStoreKey("forwarding")
	cms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, memDB)
	_ = cms.LoadLatestVersion()
	ctx := sdk.NewContext(cms, tmproto.Header{}, false, logger)
	k := keeper.Keeper{StoreKey: storeKey}

	t.Run("Increments total forwarded for an empty channel", func(t *testing.T) {
		channel := "channel-1"
		coin := sdk.NewCoin("stake", math.NewInt(1000))

		k.IncrementTotalForwarded(ctx, channel, coin)

		total := k.GetTotalForwarded(ctx, channel)
		require.Equal(t, sdk.NewCoins(coin), total)
	})

	t.Run("Increments total forwarded for an existing channel", func(t *testing.T) {
		channel := "channel-2"
		initial := sdk.NewCoins(
			sdk.NewCoin("uatom", math.NewInt(500)),
			sdk.NewCoin("usdc", math.NewInt(2000)),
		)
		increment := sdk.NewCoin("uatom", math.NewInt(1000))
		key := types.TotalForwardedKey(channel)
		ctx.KVStore(storeKey).Set(key, []byte(initial.String()))

		k.IncrementTotalForwarded(ctx, channel, increment)

		expectedTotal := initial.Add(increment)
		total := k.GetTotalForwarded(ctx, channel)
		require.Equal(t, expectedTotal, total)
	})
}

func TestSetTotalForwarded(t *testing.T) {
	memDB := db.NewMemDB()
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()
	cms := rootmulti.NewStore(memDB, logger, storeMetrics)
	storeKey := storetypes.NewKVStoreKey("forwarding")
	cms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, memDB)
	_ = cms.LoadLatestVersion()
	ctx := sdk.NewContext(cms, tmproto.Header{}, false, logger)
	k := keeper.Keeper{StoreKey: storeKey}

	t.Run("Sets total forwarded for a new channel", func(t *testing.T) {
		channel := "channel-1"
		total := sdk.NewCoins(
			sdk.NewCoin("stake", math.NewInt(1000)),
			sdk.NewCoin("uatom", math.NewInt(500)),
		)

		k.SetTotalForwarded(ctx, channel, total)

		storedTotal := k.GetTotalForwarded(ctx, channel)
		require.Equal(t, total, storedTotal)
	})

	t.Run("Updates total forwarded for an existing channel", func(t *testing.T) {
		channel := "channel-2"
		initialTotal := sdk.NewCoins(sdk.NewCoin("usdc", math.NewInt(2000)))
		newTotal := sdk.NewCoins(
			sdk.NewCoin("usdc", math.NewInt(3000)),
			sdk.NewCoin("ustake", math.NewInt(1500)),
		)
		key := types.TotalForwardedKey(channel)
		ctx.KVStore(storeKey).Set(key, []byte(initialTotal.String()))

		k.SetTotalForwarded(ctx, channel, newTotal)

		storedTotal := k.GetTotalForwarded(ctx, channel)
		require.Equal(t, newTotal, storedTotal)
	})
}
