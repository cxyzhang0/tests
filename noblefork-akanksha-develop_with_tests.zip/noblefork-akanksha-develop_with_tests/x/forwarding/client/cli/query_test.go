package cli_test

import (
	"bytes"
	"context"
	"errors"
	"strings"
	"testing"

	"cosmossdk.io/math"
	"github.com/cosmos/cosmos-sdk/client"
	"github.com/cosmos/cosmos-sdk/codec/address"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/spf13/cobra"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"
	"github.com/wfblockchain/noblechain/v5/testutil/sample"
	"github.com/wfblockchain/noblechain/v5/x/forwarding/client/cli"
	"github.com/wfblockchain/noblechain/v5/x/forwarding/types"
)

func TestGetQueryCmd(t *testing.T) {
	cmd := cli.GetQueryCmd()
	assert.NotNil(t, cmd)
	assert.Equal(t, "forwarding", cmd.Use)
	subCommands := cmd.Commands()
	assert.Len(t, subCommands, 2)
	queryAddressCmd := subCommands[0]
	assert.Equal(t, "address", queryAddressCmd.Name())
	queryStatsCmd := subCommands[1]
	assert.Equal(t, "stats", queryStatsCmd.Name())
	assert.NotNil(t, cmd.RunE)
}

func TestGetTxCmd(t *testing.T) {
	cmd := cli.GetTxCmd()
	require.NotNil(t, cmd)
	require.Equal(t, types.ModuleName, cmd.Use)
	expectedSubcommands := []string{"register-account", "clear-account"}

	subcommands := make(map[string]bool)
	for _, subCmd := range cmd.Commands() {
		subCmdName := strings.Split(subCmd.Use, " ")[0]
		subcommands[subCmdName] = true
	}

	for _, expected := range expectedSubcommands {
		require.Contains(t, subcommands, expected, "Missing subcommand: %s", expected)
	}
}
func TestNewTxCmd(t *testing.T) {
	cmd := cli.NewTxCmd(address.NewBech32Codec("cosmos"), address.NewBech32Codec("cosmos"))
	require.NotNil(t, cmd)
	require.Equal(t, types.ModuleName, cmd.Use)
	expectedSubcommands := []string{"register-account", "clear-account"}

	subcommands := make(map[string]bool)
	for _, subCmd := range cmd.Commands() {
		subCmdName := strings.Split(subCmd.Use, " ")[0]
		subcommands[subCmdName] = true
	}

	for _, expected := range expectedSubcommands {
		require.Contains(t, subcommands, expected, "Missing subcommand: %s", expected)
	}
	require.NotNil(t, cmd.RunE, "cmd.RunE should not be nil")
}
func mockGetClientTxContext(_ *cobra.Command) (client.Context, error) {
	addrStr := sample.AccAddress()
	addr, err := sdk.AccAddressFromBech32(addrStr)
	if err != nil {
		return client.Context{}, err
	}
	return client.Context{}.WithFromAddress(addr), nil
}

func TestTxRegisterAccount(t *testing.T) {
	cmd := cli.TxRegisterAccount()
	require.NotNil(t, cmd)
	require.Equal(t, "register-account [channel] [recipient]", cmd.Use)
	require.Equal(t, "Register a forwarding account for a channel and recipient", cmd.Short)
	require.NotNil(t, cmd.Args)

	argsCheck := cmd.Args
	err := argsCheck(cmd, []string{"channel-0", "cosmos1recipient"})
	require.NoError(t, err)

	err = argsCheck(cmd, []string{"channel-0"})
	require.Error(t, err)
	require.Contains(t, err.Error(), "accepts 2 arg(s), received 1")

	err = argsCheck(cmd, []string{})
	require.Error(t, err)
	require.Contains(t, err.Error(), "accepts 2 arg(s), received 0")

	t.Run("Fails with Missing Arguments", func(t *testing.T) {
		_, err := executeCommand(cmd)
		require.Error(t, err)
		require.Contains(t, err.Error(), "accepts 2 arg(s), received 0")
	})

	t.Run("Fails with One Argument", func(t *testing.T) {
		_, err := executeCommand(cmd, "channel-0")
		require.Error(t, err)
		require.Contains(t, err.Error(), "accepts 2 arg(s), received 1")
	})

	t.Run("Fails if Client Context Retrieval Fails", func(t *testing.T) {
		mockFailingClientTxContext := func(_ *cobra.Command) (client.Context, error) {
			return client.Context{}, errors.New("mock client context error")
		}

		mockFailingClientTxContext(cmd)

		executeCommand(cmd, "channel-0", "cosmos1recipient")

	})

	t.Run("Succeeds with Valid Arguments", func(t *testing.T) {
		_, err := mockGetClientTxContext(cmd)
		require.NoError(t, err)

		executeCommand(cmd, "channel-0", "cosmos1recipient")

	})
}

func executeCommand(cmd *cobra.Command, args ...string) (string, error) {
	buf := new(bytes.Buffer)
	cmd.SetOut(buf)
	cmd.SetErr(buf)
	cmd.SetArgs(args)

	err := cmd.Execute()
	return buf.String(), err
}

func TestTxClearAccount(t *testing.T) {
	cmd := cli.TxClearAccount()
	require.NotNil(t, cmd)
	require.Equal(t, "clear-account [address]", cmd.Use)
	require.Equal(t, "Manually clear funds inside forwarding account", cmd.Short)
	require.NotNil(t, cmd.Args)

	argsCheck := cmd.Args
	err := argsCheck(cmd, []string{"cosmos1recipient"})
	require.NoError(t, err)

	err = argsCheck(cmd, []string{})
	require.Error(t, err)
	require.Contains(t, err.Error(), "accepts 1 arg(s), received 0")

	t.Run("Fails with Too Many Arguments", func(t *testing.T) {
		err = argsCheck(cmd, []string{"addr1", "addr2"})
		require.Error(t, err)
		require.Contains(t, err.Error(), "accepts 1 arg(s), received 2")
	})

	t.Run("Succeeds with One Argument", func(t *testing.T) {
		err = argsCheck(cmd, []string{"cosmos1recipient"})
		require.NoError(t, err)
	})

	err = argsCheck(cmd, []string{})
	require.Error(t, err)
	require.Contains(t, err.Error(), "accepts 1 arg(s), received 0")

	t.Run("Fails with Missing Arguments", func(t *testing.T) {
		_, err := executeCommand(cmd)
		require.Error(t, err)
		require.Contains(t, err.Error(), "accepts 1 arg(s), received 0")
	})

	t.Run("Fails if Client Context Retrieval Fails", func(t *testing.T) {
		mockFailingClientTxContext := func(_ *cobra.Command) (client.Context, error) {
			return client.Context{}, errors.New("mock client context error")
		}

		mockFailingClientTxContext(cmd)

		_, err := executeCommand(cmd, "cosmos1recipient")
		require.Error(t, err)
	})

	t.Run("Succeeds with Valid Arguments", func(t *testing.T) {
		_, err := mockGetClientTxContext(cmd)
		require.NoError(t, err)

		executeCommand(cmd, "cosmos1recipient")

	})
}

func TestQueryAddress(t *testing.T) {
	cmd := cli.QueryAddress()

	t.Run("Fails with No Arguments", func(t *testing.T) {
		err := cmd.Args(cmd, []string{})
		require.Error(t, err)
		require.Contains(t, err.Error(), "accepts 2 arg(s), received 0")
	})

	t.Run("Fails with One Argument", func(t *testing.T) {
		err := cmd.Args(cmd, []string{"channel-0"})
		require.Error(t, err)
		require.Contains(t, err.Error(), "accepts 2 arg(s), received 1")
	})

	t.Run("Succeeds with Valid Arguments", func(t *testing.T) {
		mockQueryClient := &MockQueryClient{
			AddressResponse: &types.QueryAddressResponse{Address: "cosmos1forwarding"},
		}

		cmd.SetContext(context.Background())

		res, err := mockQueryClient.Address(context.Background(), &types.QueryAddress{
			Channel:   "channel-0",
			Recipient: "cosmos1recipient",
		})
		require.NoError(t, err)
		require.Equal(t, "cosmos1forwarding", res.Address)
	})

	t.Run("Fails if QueryClient Returns an Error", func(t *testing.T) {
		mockQueryClient := &MockQueryClient{
			AddressErr: errors.New("query error"),
		}

		cmd.SetContext(context.Background())

		_, err := mockQueryClient.Address(context.Background(), &types.QueryAddress{
			Channel:   "channel-0",
			Recipient: "cosmos1recipient",
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "query error")
	})
}

func TestQueryStats(t *testing.T) {
	cmd := cli.QueryStats()

	t.Run("Fails with No Arguments", func(t *testing.T) {
		err := cmd.Args(cmd, []string{})
		require.Error(t, err)
		require.Contains(t, err.Error(), "accepts 1 arg(s), received 0")
	})

	t.Run("Fails with Too Many Arguments", func(t *testing.T) {
		err := cmd.Args(cmd, []string{"channel-0", "extra-arg"})
		require.Error(t, err)
		require.Contains(t, err.Error(), "accepts 1 arg(s), received 2")
	})

	t.Run("Succeeds with Valid Argument", func(t *testing.T) {
		mockQueryClient := &MockQueryClient2{
			StatsResponse: &types.QueryStatsByChannelResponse{
				NumOfAccounts:  5,
				NumOfForwards:  10,
				TotalForwarded: sdk.NewCoins(sdk.NewInt64Coin("ustake", 5000)),
			},
		}

		res, err := mockQueryClient.StatsByChannel(context.Background(), &types.QueryStatsByChannel{
			Channel: "channel-0",
		})
		require.NoError(t, err)
		require.Equal(t, uint64(5), res.NumOfAccounts)
		require.Equal(t, uint64(10), res.NumOfForwards)
		require.Equal(t, sdk.NewCoins(sdk.NewInt64Coin("ustake", 5000)), res.TotalForwarded)
	})

	t.Run("Fails if QueryClient Returns an Error", func(t *testing.T) {
		mockQueryClient := &MockQueryClient2{
			StatsErr: errors.New("query error"),
		}

		cmd.SetContext(context.Background())

		_, err := mockQueryClient.StatsByChannel(context.Background(), &types.QueryStatsByChannel{
			Channel: "channel-0",
		})
		require.Error(t, err)
		require.Contains(t, err.Error(), "query error")
	})
}

type MockQueryClient struct {
	AddressResponse *types.QueryAddressResponse
	AddressErr      error
}

func (m *MockQueryClient) Address(ctx context.Context, req *types.QueryAddress) (*types.QueryAddressResponse, error) {
	if m.AddressErr != nil {
		return nil, m.AddressErr
	}
	return m.AddressResponse, nil
}
func (m *MockQueryClient) StatsByChannel(ctx context.Context, req *types.QueryStatsByChannel) (*types.QueryStatsByChannelResponse, error) {
	return nil, errors.New("not implemented")
}

type MockQueryClient2 struct {
	StatsResponse *types.QueryStatsByChannelResponse
	StatsErr      error
}

func (m *MockQueryClient2) StatsByChannel(ctx context.Context, req *types.QueryStatsByChannel) (*types.QueryStatsByChannelResponse, error) {
	if m.StatsErr != nil {
		return nil, m.StatsErr
	}
	return m.StatsResponse, nil
}

func (m *MockQueryClient2) Address(ctx context.Context, req *types.QueryAddress) (*types.QueryAddressResponse, error) {
	return nil, errors.New("not implemented")
}

type MockQueryClient3 struct {
	mock.Mock
}

func (m *MockQueryClient3) Address(ctx context.Context, req *types.QueryAddress) (*types.QueryAddressResponse, error) {
	args := m.Called(ctx, req)
	return args.Get(0).(*types.QueryAddressResponse), args.Error(1)
}

func TestQueryAddressCmd(t *testing.T) {
	clientCtx := client.Context{}
	cmd := cli.QueryAddress()
	mockQueryClient3 := new(MockQueryClient3)
	clientCtx.WithInterfaceRegistry(types.ModuleCdc.InterfaceRegistry())
	expectedResponse := &types.QueryAddressResponse{Address: "cosmos1xyz"}
	mockQueryClient3.On("Address", mock.Anything, &types.QueryAddress{
		Channel:   "channel-0",
		Recipient: "recipient-1",
	}).Return(expectedResponse, nil)
	cmd.SetArgs([]string{"channel-0", "recipient-1"})

	cmd.Execute()

	cmd.SetArgs([]string{"channel-0"})
	err := cmd.Execute()
	require.Error(t, err, "Expected error due to missing arguments")
	mockQueryClient3.On("Address", mock.Anything, &types.QueryAddress{
		Channel:   "channel-0",
		Recipient: "recipient-2",
	}).Return(nil, nil)

	cmd.SetArgs([]string{"channel-0", "recipient-2"})
	err = cmd.Execute()
	require.Error(t, err, "Expected error from failed query execution")
}
func TestQueryStatsCmd(t *testing.T) {
	clientCtx := client.Context{}
	cmd := cli.QueryStats()
	mockQueryClient := new(MockQueryClient3)
	clientCtx.WithInterfaceRegistry(types.ModuleCdc.InterfaceRegistry())
	expectedResponse := &types.QueryStatsByChannelResponse{
		NumOfAccounts:  5,
		NumOfForwards:  10,
		TotalForwarded: sdk.NewCoins(sdk.NewCoin("ustake", math.NewInt(1000))),
	}

	mockQueryClient.On("StatsByChannel", mock.Anything, &types.QueryStatsByChannel{
		Channel: "channel-0",
	}).Return(expectedResponse, nil)
	cmd.SetArgs([]string{"channel-0"})
	cmd.SetArgs([]string{})
	err := cmd.Execute()
	require.Error(t, err, "Expected error due to missing arguments")
	mockQueryClient.On("StatsByChannel", mock.Anything, &types.QueryStatsByChannel{
		Channel: "channel-1",
	}).Return(nil, errors.New("channel not found"))

	cmd.SetArgs([]string{"channel-1"})
	err = cmd.Execute()
	require.Error(t, err, "Expected error from failed query execution")
}
