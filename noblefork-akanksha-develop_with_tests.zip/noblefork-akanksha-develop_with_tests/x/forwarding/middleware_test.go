package forwarding_test

import (
	"context"
	"encoding/json"
	"net/http"
	"strings"
	"testing"

	"cosmossdk.io/log"
	"cosmossdk.io/store"
	"cosmossdk.io/store/metrics"
	sdktypes "cosmossdk.io/store/types"
	tmproto "github.com/cometbft/cometbft/proto/tendermint/types"
	dbm "github.com/cosmos/cosmos-db"
	"github.com/cosmos/cosmos-sdk/client"
	"github.com/cosmos/cosmos-sdk/codec"
	codectypes "github.com/cosmos/cosmos-sdk/codec/types"
	"github.com/cosmos/cosmos-sdk/types"
	sdk "github.com/cosmos/cosmos-sdk/types"
	moduletestutil "github.com/cosmos/cosmos-sdk/types/module/testutil"
	capabilitytypes "github.com/cosmos/ibc-go/modules/capability/types"
	clienttypes "github.com/cosmos/ibc-go/v8/modules/core/02-client/types"
	channeltypes "github.com/cosmos/ibc-go/v8/modules/core/04-channel/types"
	"github.com/cosmos/ibc-go/v8/modules/core/exported"
	"github.com/gorilla/mux"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"
	"github.com/wfblockchain/noblechain/v5/app"
	"github.com/wfblockchain/noblechain/v5/x/forwarding"
	"github.com/wfblockchain/noblechain/v5/x/forwarding/client/cli"
	"github.com/wfblockchain/noblechain/v5/x/forwarding/keeper"
	fkeeper "github.com/wfblockchain/noblechain/v5/x/forwarding/keeper"
	ftypes "github.com/wfblockchain/noblechain/v5/x/forwarding/types"
	"go.uber.org/mock/gomock"
)

type MockApp struct {
	mock.Mock
}

func TestNewAppModule(t *testing.T) {
	mockKeeper := &keeper.Keeper{}
	appModule := forwarding.NewAppModule(mockKeeper)
	assert.NotNil(t, appModule)
	assert.Equal(t, mockKeeper, appModule.Keeper)
	assert.NotNil(t, appModule.AppModuleBasic)
}

func TestAppModule_InitGenesis_RealKeeper(t *testing.T) {
	ctx := sdk.NewContext(nil, tmproto.Header{}, false, nil)
	interfaceRegistry := codectypes.NewInterfaceRegistry()
	mockCDC := codec.NewProtoCodec(interfaceRegistry)
	mockKeeper := &keeper.Keeper{}
	testGenesis := app.GenesisState{}
	bz, err := json.Marshal(testGenesis)
	assert.NoError(t, err)
	appModule := forwarding.AppModule{
		Keeper: mockKeeper,
	}
	validatorUpdates := appModule.InitGenesis(ctx, mockCDC, bz)
	assert.Empty(t, validatorUpdates)
}

func TestAppModule_ConsensusVersion(t *testing.T) {
	appModule := forwarding.AppModule{}
	version := appModule.ConsensusVersion()
	assert.Equal(t, uint64(1), version)
}

func TestQuerierRoute(t *testing.T) {
	appModule := forwarding.AppModule{}
	expectedModuleName := ftypes.ModuleName
	actualModuleName := appModule.QuerierRoute()
	assert.Equal(t, expectedModuleName, actualModuleName, "QuerierRoute should return the module name")
}

func (m *MockApp) OnChanOpenInit(
	ctx sdk.Context,
	order channeltypes.Order,
	connectionHops []string,
	portID string,
	channelID string,
	channelCap *capabilitytypes.Capability,
	counterparty channeltypes.Counterparty,
	version string,
) (string, error) {
	args := m.Called(ctx, order, connectionHops, portID, channelID, channelCap, counterparty, version)
	return args.String(0), args.Error(1)
}

func (m *MockApp) OnChanOpenTry(
	ctx sdk.Context,
	order channeltypes.Order,
	connectionHops []string,
	portID string,
	channelID string,
	channelCap *capabilitytypes.Capability,
	counterparty channeltypes.Counterparty,
	counterpartyVersion string,
) (string, error) {
	args := m.Called(ctx, order, connectionHops, portID, channelID, channelCap, counterparty, counterpartyVersion)
	return args.String(0), args.Error(1)
}

type Middleware struct {
	app *MockApp
}

func TestOnChanOpenInit(t *testing.T) {
	mockApp := new(MockApp)
	mockApp.On("OnChanOpenInit", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).Return("success", nil)
	middleware := Middleware{app: mockApp}
	ctx := types.Context{}
	order := channeltypes.ORDERED
	connectionHops := []string{"connection-1"}
	portID := "port-1"
	channelID := "channel-1"
	channelCap := &capabilitytypes.Capability{}
	counterparty := channeltypes.Counterparty{}
	version := "1.0"
	result, err := middleware.app.OnChanOpenInit(ctx, order, connectionHops, portID, channelID, channelCap, counterparty, version)
	assert.NoError(t, err)
	assert.Equal(t, "success", result)
	mockApp.AssertExpectations(t)
}

func TestOnChanOpenInitError(t *testing.T) {
	mockApp := new(MockApp)
	mockApp.On("OnChanOpenInit", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).Return("", assert.AnError)
	middleware := Middleware{app: mockApp}
	ctx := types.Context{}
	order := channeltypes.ORDERED
	connectionHops := []string{"connection-1"}
	portID := "port-1"
	channelID := "channel-1"
	channelCap := &capabilitytypes.Capability{}
	counterparty := channeltypes.Counterparty{}
	version := "1.0"
	result, err := middleware.app.OnChanOpenInit(ctx, order, connectionHops, portID, channelID, channelCap, counterparty, version)
	assert.Error(t, err)
	assert.Equal(t, "", result)
	mockApp.AssertExpectations(t)
}

func TestOnChanOpenTry(t *testing.T) {
	mockApp := new(MockApp)
	mockApp.On("OnChanOpenTry", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).Return("success", nil)
	middleware := Middleware{app: mockApp}
	ctx := types.Context{}
	order := channeltypes.ORDERED
	connectionHops := []string{"connection-1"}
	portID := "port-1"
	channelID := "channel-1"
	channelCap := &capabilitytypes.Capability{}
	counterparty := channeltypes.Counterparty{}
	counterpartyVersion := "1.0"
	result, err := middleware.app.OnChanOpenTry(ctx, order, connectionHops, portID, channelID, channelCap, counterparty, counterpartyVersion)
	assert.NoError(t, err)
	assert.Equal(t, "success", result)
	mockApp.AssertExpectations(t)
}

func TestOnChanOpenTryError(t *testing.T) {
	mockApp := new(MockApp)
	mockApp.On("OnChanOpenTry", mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything, mock.Anything).Return("", assert.AnError)
	middleware := Middleware{app: mockApp}
	ctx := types.Context{}
	order := channeltypes.ORDERED
	connectionHops := []string{"connection-1"}
	portID := "port-1"
	channelID := "channel-1"
	channelCap := &capabilitytypes.Capability{}
	counterparty := channeltypes.Counterparty{}
	counterpartyVersion := "1.0"
	result, err := middleware.app.OnChanOpenTry(ctx, order, connectionHops, portID, channelID, channelCap, counterparty, counterpartyVersion)
	assert.Error(t, err)
	assert.Equal(t, "", result)
	mockApp.AssertExpectations(t)
}

func TestGetTxCmd(t *testing.T) {
	appModuleBasic := forwarding.AppModuleBasic{}
	txCmd := appModuleBasic.GetTxCmd()
	require.NotNil(t, txCmd, "GetTxCmd() should not return nil")
	require.Equal(t, "forwarding", txCmd.Use, "Transaction command should have the correct name")
	subCommands := txCmd.Commands()
	require.NotEmpty(t, subCommands, "Transaction command should have subcommands")
	for _, cmd := range subCommands {
		t.Logf("Found subcommand: %s", cmd.Use)
	}
	expectedSubcommands := []string{"register-account", "clear-account"}

	for _, expected := range expectedSubcommands {
		found := false
		for _, cmd := range subCommands {
			if strings.HasPrefix(cmd.Use, expected) {
				found = true
				break
			}
		}
		require.Truef(t, found, "Expected subcommand %q not found", expected)
	}
}

func TestGetQueryCmd(t *testing.T) {
	queryCmd := cli.GetQueryCmd()
	require.NotNil(t, queryCmd, "GetQueryCmd() should not return nil")
	require.NotEmpty(t, queryCmd.Use, "Query command should have a name")
	subCommands := queryCmd.Commands()
	require.NotEmpty(t, subCommands, "Query command should have subcommands")
	for _, cmd := range subCommands {
		t.Logf("Found subcommand: %s", cmd.Use)
	}
	expectedSubcommands := []string{"address", "stats"}

	for _, expected := range expectedSubcommands {
		found := false
		for _, cmd := range subCommands {
			if strings.HasPrefix(cmd.Use, expected) {
				found = true
				break
			}
		}
		require.Truef(t, found, "Expected subcommand %q not found", expected)
	}
}

func TestIsAppModule(t *testing.T) {
	am := forwarding.AppModule{}
	require.NotPanics(t, func() {
		am.IsAppModule()
	}, "IsAppModule should not panic")
}

func TestIsOnePerModuleType(t *testing.T) {
	am := forwarding.AppModule{}
	require.NotPanics(t, func() {
		am.IsOnePerModuleType()
	}, "IsOnePerModuleType should not panic")
}

func TestAppModuleBasicName(t *testing.T) {
	amb := forwarding.AppModuleBasic{}
	expectedName := ftypes.ModuleName

	actualName := amb.Name()

	require.Equal(t, expectedName, actualName, "AppModuleBasic.Name() should return the correct module name")
}

func TestAppModuleBasicRegisterLegacyAminoCodec(t *testing.T) {
	cdc := codec.NewLegacyAmino()
	amb := forwarding.AppModuleBasic{}
	amb.RegisterLegacyAminoCodec(cdc)
	expectedType := ftypes.GenesisState{}
	_, err := cdc.MarshalJSON(expectedType)

	require.NoError(t, err, "RegisterLegacyAminoCodec should register the expected types without errors")
}

func TestRegisterRESTRoutes(t *testing.T) {
	ctx := client.Context{}
	router := mux.NewRouter()
	am := forwarding.AppModuleBasic{}
	am.RegisterRESTRoutes(ctx, router)
	routeFound := false
	router.Walk(func(route *mux.Route, router *mux.Router, ancestors []*mux.Route) error {
		path, _ := route.GetPathTemplate()
		methods, _ := route.GetMethods()

		if path == "/forwarding/register-account" && containsMethod(methods, http.MethodPost) {
			routeFound = true
			return nil
		}
		return nil
	})
	require.True(t, routeFound, "/forwarding/register-account with POST method should be registered")

}

func containsMethod(methods []string, method string) bool {
	for _, m := range methods {
		if m == method {
			return true
		}
	}
	return false
}

type MockInvariantRegistry struct {
	Invariants map[string]sdk.Invariant
}

func (m *MockInvariantRegistry) RegisterRoute(moduleName, route string, invariant sdk.Invariant) {
	if m.Invariants == nil {
		m.Invariants = make(map[string]sdk.Invariant)
	}
	m.Invariants[moduleName+"/"+route] = invariant
}

func TestRegisterInvariants(t *testing.T) {
	registry := &MockInvariantRegistry{}

	module := forwarding.AppModule{}
	module.RegisterInvariants(registry)
	require.Empty(t, registry.Invariants, "Expected no invariants to be registered")
}

type MockConfigurator struct {
	mockMsgServer   ftypes.MsgServer
	mockQueryServer ftypes.QueryServer
}

func (m *MockConfigurator) MsgServer() ftypes.MsgServer {
	return m.mockMsgServer
}

func (m *MockConfigurator) QueryServer() ftypes.QueryServer {
	return m.mockQueryServer
}

func TestRegisterInterfaces(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()
	registry := codectypes.NewInterfaceRegistry()
	appModuleBasic := forwarding.AppModuleBasic{}
	appModuleBasic.RegisterInterfaces(registry)
	require.NotNil(t, registry, "InterfaceRegistry should not be nil")
}
func TestDefaultGenesis(t *testing.T) {
	registry := codectypes.NewInterfaceRegistry()
	cdc := codec.NewProtoCodec(registry)
	appModuleBasic := forwarding.AppModuleBasic{}
	rawGenesis := appModuleBasic.DefaultGenesis(cdc)
	require.NotEmpty(t, rawGenesis, "Default genesis should not be empty")
	var genesisState ftypes.GenesisState
	err := cdc.UnmarshalJSON(rawGenesis, &genesisState)
	require.NoError(t, err, "Failed to unmarshal default genesis state")
}

func CreateTestContextAndKeeper(t *testing.T) (sdk.Context, *fkeeper.Keeper) {
	storeKey := sdktypes.NewKVStoreKey(ftypes.StoreKey)
	transientStoreKey := sdktypes.NewTransientStoreKey("transient_" + ftypes.StoreKey)

	db := dbm.NewMemDB()
	ms := store.NewCommitMultiStore(db, log.NewNopLogger(), metrics.Metrics{})

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, nil)

	ms.MountStoreWithDB(storeKey, sdktypes.StoreTypeIAVL, db)
	ms.MountStoreWithDB(transientStoreKey, sdktypes.StoreTypeTransient, db)
	require.NoError(t, ms.LoadLatestVersion())
	appCodec := moduletestutil.MakeTestEncodingConfig().Codec

	require.NoError(t, ms.LoadLatestVersion())

	accountKeeper := MockAccountKeeper{}
	bankKeeper := MockBankKeeper{}
	channelKeeper := MockChannelKeeper{}
	transferKeeper := MockTransferKeeper{}
	k := fkeeper.NewKeeper(
		appCodec,
		storeKey,
		transientStoreKey,
		accountKeeper,
		bankKeeper,
		channelKeeper,
		transferKeeper,
	)

	return ctx, k
}

type MockAccountKeeper struct{}

func (m MockAccountKeeper) GetAccount(ctx context.Context, addr sdk.AccAddress) sdk.AccountI {
	return nil
}

func (m MockAccountKeeper) HasAccount(ctx context.Context, addr sdk.AccAddress) bool {
	return false
}

func (m MockAccountKeeper) SetAccount(ctx context.Context, acc sdk.AccountI) {
}

type MockBankKeeper struct{}

func (m MockBankKeeper) GetAllBalances(ctx context.Context, addr sdk.AccAddress) sdk.Coins {
	return sdk.Coins{}
}

type MockChannelKeeper struct{}

func (m MockChannelKeeper) GetChannel(ctx sdk.Context, portID, channelID string) (channeltypes.Channel, bool) {
	return channeltypes.Channel{}, false
}

type MockTransferKeeper struct{}

func (m MockTransferKeeper) SendTransfer(
	ctx sdk.Context,
	sourcePort, sourceChannel string,
	token sdk.Coin,
	sender sdk.AccAddress,
	receiver string,
	timeoutHeight clienttypes.Height,
	timeoutTimestamp uint64,
) error {
	return nil
}

func TestInitGenesis(t *testing.T) {
	ctx, k := CreateTestContextAndKeeper(t)
	genesis := ftypes.GenesisState{
		NumOfAccounts: map[string]uint64{
			"channel-0": 5,
			"channel-1": 10,
		},
		NumOfForwards: map[string]uint64{
			"channel-0": 20,
			"channel-1": 30,
		},
		TotalForwarded: map[string]string{
			"channel-0": "100ustake",
			"channel-1": "200ustake",
		},
	}

	forwarding.InitGenesis(ctx, k, genesis)
	for channel, expectedCount := range genesis.NumOfAccounts {
		count := k.GetNumOfAccounts(ctx, channel)
		require.Equal(t, expectedCount, count, "NumOfAccounts mismatch for channel: %s", channel)
	}

	for channel, expectedCount := range genesis.NumOfForwards {
		count := k.GetNumOfForwards(ctx, channel)
		require.Equal(t, expectedCount, count, "NumOfForwards mismatch for channel: %s", channel)
	}

	for channel, expectedTotal := range genesis.TotalForwarded {
		expectedCoins, _ := sdk.ParseCoinsNormalized(expectedTotal)
		total := k.GetTotalForwarded(ctx, channel)
		require.Equal(t, expectedCoins, total, "TotalForwarded mismatch for channel: %s", channel)
	}
}

func TestExportGenesis(t *testing.T) {
	ctx, k := CreateTestContextAndKeeper(t)
	genesis := ftypes.GenesisState{
		NumOfAccounts: map[string]uint64{
			"channel-0": 5,
			"channel-1": 10,
		},
		NumOfForwards: map[string]uint64{
			"channel-0": 20,
			"channel-1": 30,
		},
		TotalForwarded: map[string]string{
			"channel-0": "100ustake",
			"channel-1": "200ustake",
		},
	}
	forwarding.InitGenesis(ctx, k, genesis)
	exportedGenesis := forwarding.ExportGenesis(ctx, k)
	require.NotNil(t, exportedGenesis, "Exported genesis state should not be nil")

	require.Equal(t, genesis.NumOfAccounts, exportedGenesis.NumOfAccounts, "NumOfAccounts mismatch")
	require.Equal(t, genesis.NumOfForwards, exportedGenesis.NumOfForwards, "NumOfForwards mismatch")
	require.Equal(t, genesis.TotalForwarded, exportedGenesis.TotalForwarded, "TotalForwarded mismatch")
}

func TestNewMiddleware(t *testing.T) {
	mockApp := new(MockIBCModule)
	mockAuthKeeper := new(MockAccountKeeper)
	mockKeeper := new(keeper.Keeper)
	middleware := forwarding.NewMiddleware(mockApp, mockAuthKeeper, mockKeeper)
	require.NotNil(t, middleware)
}

type MockIBCModule struct{ mock.Mock }

func (m *MockIBCModule) OnRecvPacket(ctx sdk.Context, packet channeltypes.Packet, relayer sdk.AccAddress) exported.Acknowledgement {
	args := m.Called(ctx, packet, relayer)
	return args.Get(0).(exported.Acknowledgement)
}

func (m *MockIBCModule) OnAcknowledgementPacket(ctx sdk.Context, packet channeltypes.Packet, acknowledgement []byte, relayer sdk.AccAddress) error {
	args := m.Called(ctx, packet, acknowledgement, relayer)
	return args.Error(0)
}

func (m *MockIBCModule) OnTimeoutPacket(ctx sdk.Context, packet channeltypes.Packet, relayer sdk.AccAddress) error {
	args := m.Called(ctx, packet, relayer)
	return args.Error(0)
}

func (m *MockIBCModule) OnChanOpenInit(ctx sdk.Context, order channeltypes.Order, connectionHops []string, portID string, channelID string, chanCap *capabilitytypes.Capability, counterparty channeltypes.Counterparty, version string) (string, error) {
	args := m.Called(ctx, order, connectionHops, portID, channelID, chanCap, counterparty, version)
	return "", args.Error(0)
}

func (m *MockIBCModule) OnChanOpenTry(ctx sdk.Context, order channeltypes.Order, connectionHops []string, portID string, channelID string, chanCap *capabilitytypes.Capability, counterparty channeltypes.Counterparty, counterpartyVersion string) (string, error) {
	args := m.Called(ctx, order, connectionHops, portID, channelID, chanCap, counterparty, counterpartyVersion)
	return "", args.Error(0)
}

func (m *MockIBCModule) OnChanOpenAck(ctx sdk.Context, portID string, channelID string, counterpartyChannelID string, counterpartyVersion string) error {
	args := m.Called(ctx, portID, channelID, counterpartyChannelID, counterpartyVersion)
	return args.Error(0)
}

func (m *MockIBCModule) OnChanOpenConfirm(ctx sdk.Context, portID string, channelID string) error {
	args := m.Called(ctx, portID, channelID)
	return args.Error(0)
}

func (m *MockIBCModule) OnChanCloseInit(ctx sdk.Context, portID string, channelID string) error {
	args := m.Called(ctx, portID, channelID)
	return args.Error(0)
}

func (m *MockIBCModule) OnChanCloseConfirm(ctx sdk.Context, portID string, channelID string) error {
	args := m.Called(ctx, portID, channelID)
	return args.Error(0)
}

type MockKeeper struct {
	keeper.Keeper
	mock.Mock
}

func (m *MockKeeper) RegisterAccount(ctx context.Context, msg *ftypes.MsgRegisterAccount) (*ftypes.MsgRegisterAccountResponse, error) {
	args := m.Called(ctx, msg)
	return args.Get(0).(*ftypes.MsgRegisterAccountResponse), args.Error(1)
}

func (m *MockKeeper) SetPendingForward(ctx sdk.Context, account *ftypes.ForwardingAccount) {
	m.Called(ctx, account)
}

func (m *MockApp) OnAcknowledgementPacket(ctx sdk.Context, packet channeltypes.Packet, acknowledgement []byte, relayer sdk.AccAddress) error {
	args := m.Called(ctx, packet, acknowledgement, relayer)
	return args.Error(0)
}

func (m *MockApp) OnChanCloseConfirm(ctx sdk.Context, portID string, channelID string) error {
	args := m.Called(ctx, portID, channelID)
	return args.Error(0)
}

func TestOnChanCloseInit(t *testing.T) {
	mockApp := new(MockIBCModule)
	m := forwarding.Middleware{
		App: mockApp,
	}
	ctx := types.Context{}
	portID := "port-1"
	channelID := "channel-1"
	mockApp.On("OnChanCloseInit", ctx, portID, channelID).Return(nil)
	err := m.OnChanCloseInit(ctx, portID, channelID)
	require.NoError(t, err)
	mockApp.AssertExpectations(t)
}
