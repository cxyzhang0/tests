package types_test

import (
	context "context"
	"testing"

	"cosmossdk.io/log"
	"cosmossdk.io/store"
	"cosmossdk.io/store/metrics"
	sdktypes "cosmossdk.io/store/types"
	storetypes "cosmossdk.io/store/types"
	tmproto "github.com/cometbft/cometbft/proto/tendermint/types"
	dbm "github.com/cosmos/cosmos-db"
	"github.com/cosmos/cosmos-sdk/codec"
	codectypes "github.com/cosmos/cosmos-sdk/codec/types"
	sdk "github.com/cosmos/cosmos-sdk/types"
	moduletestutil "github.com/cosmos/cosmos-sdk/types/module/testutil"
	clienttypes "github.com/cosmos/ibc-go/v8/modules/core/02-client/types"
	channeltypes "github.com/cosmos/ibc-go/v8/modules/core/04-channel/types"
	"github.com/stretchr/testify/require"
	"github.com/wfblockchain/noblechain/v5/testutil/sample"
	"github.com/wfblockchain/noblechain/v5/x/forwarding"
	ftypes "github.com/wfblockchain/noblechain/v5/x/forwarding/keeper"
	"github.com/wfblockchain/noblechain/v5/x/forwarding/types"
)

func createTestContextAndKeeper(t *testing.T) (sdk.Context, *ftypes.Keeper) {
	storeKey := sdktypes.NewKVStoreKey(types.StoreKey)
	transientStoreKey := sdktypes.NewTransientStoreKey("transient_" + types.StoreKey)

	db := dbm.NewMemDB()
	ms := store.NewCommitMultiStore(db, log.NewNopLogger(), metrics.Metrics{})

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, nil)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	ms.MountStoreWithDB(transientStoreKey, storetypes.StoreTypeTransient, db)
	require.NoError(t, ms.LoadLatestVersion())
	appCodec := moduletestutil.MakeTestEncodingConfig().Codec

	require.NoError(t, ms.LoadLatestVersion())

	accountKeeper := MockAccountKeeper{}
	bankKeeper := MockBankKeeper{}
	channelKeeper := MockChannelKeeper{}
	transferKeeper := MockTransferKeeper{}
	k := ftypes.NewKeeper(
		appCodec,
		storeKey,
		transientStoreKey,
		accountKeeper,
		bankKeeper,
		channelKeeper,
		transferKeeper,
	)

	return ctx, k
}

type MockAccountKeeper struct{}

func (m MockAccountKeeper) GetAccount(ctx context.Context, addr sdk.AccAddress) sdk.AccountI {
	return nil
}

func (m MockAccountKeeper) HasAccount(ctx context.Context, addr sdk.AccAddress) bool {
	return false
}

func (m MockAccountKeeper) SetAccount(ctx context.Context, acc sdk.AccountI) {
}

type MockBankKeeper struct{}

func (m MockBankKeeper) GetAllBalances(ctx context.Context, addr sdk.AccAddress) sdk.Coins {
	return sdk.Coins{}
}

type MockChannelKeeper struct{}

func (m MockChannelKeeper) GetChannel(ctx sdk.Context, portID, channelID string) (channeltypes.Channel, bool) {
	return channeltypes.Channel{}, false
}

type MockTransferKeeper struct{}

func (m MockTransferKeeper) SendTransfer(
	ctx sdk.Context,
	sourcePort, sourceChannel string,
	token sdk.Coin,
	sender sdk.AccAddress,
	receiver string,
	timeoutHeight clienttypes.Height,
	timeoutTimestamp uint64,
) error {
	return nil
}

func TestInitGenesis(t *testing.T) {
	ctx, k := createTestContextAndKeeper(t)
	genesis := types.GenesisState{
		NumOfAccounts: map[string]uint64{
			"channel-0": 5,
			"channel-1": 10,
		},
		NumOfForwards: map[string]uint64{
			"channel-0": 20,
			"channel-1": 30,
		},
		TotalForwarded: map[string]string{
			"channel-0": "100ustake",
			"channel-1": "200ustake",
		},
	}

	forwarding.InitGenesis(ctx, k, genesis)
	for channel, expectedCount := range genesis.NumOfAccounts {
		count := k.GetNumOfAccounts(ctx, channel)
		require.Equal(t, expectedCount, count, "NumOfAccounts mismatch for channel: %s", channel)
	}

	for channel, expectedCount := range genesis.NumOfForwards {
		count := k.GetNumOfForwards(ctx, channel)
		require.Equal(t, expectedCount, count, "NumOfForwards mismatch for channel: %s", channel)
	}

	for channel, expectedTotal := range genesis.TotalForwarded {
		expectedCoins, _ := sdk.ParseCoinsNormalized(expectedTotal)
		total := k.GetTotalForwarded(ctx, channel)
		require.Equal(t, expectedCoins, total, "TotalForwarded mismatch for channel: %s", channel)
	}
}
func TestMsgClearAccount_Type(t *testing.T) {
	msg := types.MsgClearAccount{}
	expectedType := "noble/forwarding/ClearAccount"

	require.Equal(t, expectedType, msg.Type(), "Type() should return the correct message type")
}
func TestMsgClearAccount_ValidateBasic(t *testing.T) {
	validSigner := "cosmos1v4gak5flm5nr5xg7p5w9hxkjy7z7xk9smvytkz"
	validAddress := "cosmos1qp9wqpmv8t7gz30jf8f4xufec49yde4hqhns74"
	invalidAddress := "invalid-address"

	tests := []struct {
		name      string
		msg       types.MsgClearAccount
		expectErr bool
	}{
		{
			name:      "valid msg",
			msg:       types.MsgClearAccount{Signer: validSigner, Address: validAddress},
			expectErr: false,
		},
		{
			name:      "invalid signer",
			msg:       types.MsgClearAccount{Signer: invalidAddress, Address: validAddress},
			expectErr: true,
		},
		{
			name:      "invalid address",
			msg:       types.MsgClearAccount{Signer: validSigner, Address: invalidAddress},
			expectErr: true,
		},
		{
			name:      "both invalid",
			msg:       types.MsgClearAccount{Signer: invalidAddress, Address: invalidAddress},
			expectErr: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			tc.msg.ValidateBasic()
		})
	}
}

func TestMsgClearAccount_GetSigners(t *testing.T) {
	validSigner := sample.AccAddress()
	invalidSigner := "invalid-address"

	t.Run("valid signer", func(t *testing.T) {
		msg := types.MsgClearAccount{Signer: validSigner}
		signers := msg.GetSigners()

		require.Len(t, signers, 1, "expected one signer")
		require.Equal(t, validSigner, signers[0].String(), "unexpected signer address")
	})

	t.Run("invalid signer - should panic", func(t *testing.T) {
		defer func() {
			if r := recover(); r == nil {
				t.Errorf("expected panic but got none")
			}
		}()
		msg := types.MsgClearAccount{Signer: invalidSigner}
		msg.GetSigners()
	})
}

func TestMsgClearAccount_GetSignBytes(t *testing.T) {
	msg := types.MsgClearAccount{
		Signer:  sample.AccAddress(),
		Address: sample.AccAddress(),
	}
	expectedJSON := `{"address":"cosmos1d9h8qat5jswvv3jv9p54v6uc8kk5y5dhdlfxwd","signer":"cosmos1v4gak5flm5nr5xg7p5w9hxkjy7z7xk9smvytkz"}`
	signBytes := msg.GetSignBytes()
	var expectedMap, actualMap map[string]interface{}
	codec.NewLegacyAmino().UnmarshalJSON([]byte(expectedJSON), &expectedMap)

	codec.NewLegacyAmino().UnmarshalJSON(signBytes, &actualMap)
	require.Equal(t, expectedMap, actualMap, "sorted JSON does not match expected output")
}

func TestMsgClearAccount_Route(t *testing.T) {
	msg := types.MsgClearAccount{}
	require.Equal(t, "forwarding", msg.Route(), "Route() should return the correct module name")
}

func TestRegisterInterfaces(t *testing.T) {

	registry := codectypes.NewInterfaceRegistry()
	types.RegisterInterfaces(registry)
	fullTypeUrls := []string{
		"/wfblockchain.noblechain.forwarding.MsgRegisterAccount",
		"/wfblockchain.noblechain.forwarding.MsgClearAccount",
	}

	for _, typeUrl := range fullTypeUrls {
		registry.Resolve(typeUrl)
	}
}

func TestGenerateAddress(t *testing.T) {
	channel := "channel-0"
	recipient := "recipient-address"
	addr := types.GenerateAddress(channel, recipient)
	require.NotNil(t, addr)
	require.NotEmpty(t, addr)
	require.Equal(t, 20, len(addr))
	addr2 := types.GenerateAddress(channel, recipient)
	require.Equal(t, addr, addr2)
	diffAddr := types.GenerateAddress("channel-1", recipient)
	require.NotEqual(t, addr, diffAddr)

	diffAddr2 := types.GenerateAddress(channel, "another-recipient")
	require.NotEqual(t, addr, diffAddr2)
}

func TestDefaultGenesisState(t *testing.T) {
	genesisState := types.DefaultGenesisState()
	require.NotNil(t, genesisState)
	expected := &types.GenesisState{}
	require.Equal(t, expected, genesisState)
}

func TestGenesisState_Validate(t *testing.T) {
	tests := []struct {
		name        string
		genesis     types.GenesisState
		expectError bool
	}{
		{
			name: "valid genesis state",
			genesis: types.GenesisState{
				NumOfAccounts:  map[string]uint64{"channel-0": 10},
				NumOfForwards:  map[string]uint64{"channel-1": 5},
				TotalForwarded: map[string]string{"channel-2": "100stake"},
			},
			expectError: false,
		},
		{
			name: "invalid channel ID in NumOfAccounts",
			genesis: types.GenesisState{
				NumOfAccounts: map[string]uint64{"invalid-channel": 10},
			},
			expectError: true,
		},
		{
			name: "invalid channel ID in NumOfForwards",
			genesis: types.GenesisState{
				NumOfForwards: map[string]uint64{"invalid-channel": 5},
			},
			expectError: true,
		},
		{
			name: "invalid channel ID in TotalForwarded",
			genesis: types.GenesisState{
				TotalForwarded: map[string]string{"invalid-channel": "100stake"},
			},
			expectError: true,
		},
		{
			name: "invalid coin format in TotalForwarded",
			genesis: types.GenesisState{
				TotalForwarded: map[string]string{"channel-0": "invalid-coin"},
			},
			expectError: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			err := tc.genesis.Validate()
			if tc.expectError {
				require.Error(t, err)
			} else {
				require.NoError(t, err)
			}
		})
	}
}

func TestMsgRegisterAccount_ValidateBasic(t *testing.T) {
	validAddr := sdk.AccAddress([]byte("validAddress")).String()

	tests := []struct {
		name        string
		msg         types.MsgRegisterAccount
		expectError bool
	}{
		{
			name: "valid message",
			msg: types.MsgRegisterAccount{
				Signer:  validAddr,
				Channel: "channel-0",
			},
			expectError: false,
		},
		{
			name: "invalid signer address",
			msg: types.MsgRegisterAccount{
				Signer:  "invalidAddress",
				Channel: "channel-0",
			},
			expectError: true,
		},
		{
			name: "invalid channel ID",
			msg: types.MsgRegisterAccount{
				Signer:  validAddr,
				Channel: "invalid-channel",
			},
			expectError: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			err := tc.msg.ValidateBasic()
			if tc.expectError {
				require.Error(t, err)
			} else {
				require.NoError(t, err)
			}
		})
	}
}

func TestMsgRegisterAccount_GetSigners(t *testing.T) {
	validAddr := sdk.AccAddress([]byte("validAddress")).String()

	tests := []struct {
		name        string
		msg         types.MsgRegisterAccount
		expectPanic bool
	}{
		{
			name: "valid signer address",
			msg: types.MsgRegisterAccount{
				Signer: validAddr,
			},
			expectPanic: false,
		},
		{
			name: "invalid signer address (should panic)",
			msg: types.MsgRegisterAccount{
				Signer: "invalidAddress",
			},
			expectPanic: true,
		},
	}

	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			if tc.expectPanic {
				require.Panics(t, func() { tc.msg.GetSigners() })
			} else {
				require.NotPanics(t, func() {
					signers := tc.msg.GetSigners()
					require.Len(t, signers, 1)
					require.Equal(t, validAddr, signers[0].String())
				})
			}
		})
	}
}

func TestMsgRegisterAccount_GetSignBytes(t *testing.T) {
	msg := types.MsgRegisterAccount{
		Signer:  "cosmos1v4npr4yqkd9mfnxpm3kh8ex8nxs3flw78uvk30",
		Channel: "channel-0",
	}
	signBytes := msg.GetSignBytes()
	require.NotEmpty(t, signBytes)
	require.NotPanics(t, func() {
		sorted := sdk.MustSortJSON(signBytes)
		require.Equal(t, sorted, signBytes)
	})
}

func TestMsgRegisterAccount_Route(t *testing.T) {
	msg := types.MsgRegisterAccount{}
	require.Equal(t, types.ModuleName, msg.Route())
}

func TestMsgRegisterAccount_Type(t *testing.T) {
	msg := types.MsgRegisterAccount{}
	require.Equal(t, "noble/forwarding/RegisterAccount", msg.Type())
}
