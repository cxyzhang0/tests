package keeper

import (
	"context"

	"cosmossdk.io/store/prefix"
	"github.com/cosmos/cosmos-sdk/types/query"

	"github.com/wfblockchain/noblechain/v5/x/tokenfactory/types"

	sdk "github.com/cosmos/cosmos-sdk/types"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

func (k Keeper) MintingDenom(c context.Context, req *types.QueryGetMintingDenomRequest) (*types.QueryGetMintingDenomResponse, error) {
	if req == nil {
		return nil, status.Error(codes.InvalidArgument, "invalid request")
	}
	ctx := sdk.UnwrapSDKContext(c)

	val, found := k.GetMintingDenom(ctx, req.Denom)
	if !found {
		return nil, status.Error(codes.NotFound, "not found")
	}

	return &types.QueryGetMintingDenomResponse{MintingDenom: val}, nil
}

func (k Keeper) MintingDenomAll(c context.Context, req *types.QueryAllMintingDenomRequest) (*types.QueryAllMintingDenomResponse, error) {
	if req == nil {
		return nil, status.Error(codes.InvalidArgument, "invalid request")
	}

	var mintingDenoms []types.MintingDenom
	ctx := sdk.UnwrapSDKContext(c)

	store := ctx.KVStore(k.storeKey)
	mintingDenomStore := prefix.NewStore(store, types.KeyPrefix(types.MintingDenomKeyPrefix))

	pageRes, err := query.Paginate(mintingDenomStore, req.Pagination, func(key []byte, value []byte) error {
		var mintingDenom types.MintingDenom
		if err := k.cdc.Unmarshal(value, &mintingDenom); err != nil {
			return err
		}

		mintingDenoms = append(mintingDenoms, mintingDenom)
		return nil
	})

	if err != nil {
		return nil, status.Error(codes.Internal, err.Error())
	}

	return &types.QueryAllMintingDenomResponse{MintingDenom: mintingDenoms, Pagination: pageRes}, nil
}
