package cli_test

import (
	"fmt"
	"testing"

	tmcli "github.com/cometbft/cometbft/libs/cli"
	clitestutil "github.com/cosmos/cosmos-sdk/testutil/cli"
	banktypes "github.com/cosmos/cosmos-sdk/x/bank/types"
	"github.com/stretchr/testify/require"
	"google.golang.org/grpc/status"

	"github.com/wfblockchain/noblechain/v5/testutil/network"
	"github.com/wfblockchain/noblechain/v5/testutil/nullify"
	"github.com/wfblockchain/noblechain/v5/x/tokenfactory/client/cli"
	"github.com/wfblockchain/noblechain/v5/x/tokenfactory/types"
)

func networkWithMintingDenomObjects(t *testing.T) (*network.Network, []types.MintingDenom) {
	t.Helper()
	cfg := network.DefaultConfig(nil)
	state := types.GenesisState{}
	require.NoError(t, cfg.Codec.UnmarshalJSON(cfg.GenesisState[types.ModuleName], &state))

	testDenom := "test"

	state.MintingDenomList = []types.MintingDenom{
		{Denom: testDenom},
	}

	bankState := banktypes.DefaultGenesisState()
	bankState.DenomMetadata = []banktypes.Metadata{{
		Base: testDenom,
	}}

	buf, err := cfg.Codec.MarshalJSON(bankState)
	require.NoError(t, err)
	cfg.GenesisState[banktypes.ModuleName] = buf

	buf, err = cfg.Codec.MarshalJSON(&state)
	require.NoError(t, err)
	cfg.GenesisState[types.ModuleName] = buf

	baseDir := t.TempDir()
	fmt.Printf("Creating network with baseDir: %s\n", baseDir)

	returnValue, err := network.New(nil, baseDir, cfg)
	require.NoError(t, err, "failed to create network")

	return returnValue, state.MintingDenomList
}

func TestShowMintingDenom(t *testing.T) {
	net, objs := networkWithMintingDenomObjects(t)

	ctx := net.Validators[0].ClientCtx
	common := []string{
		fmt.Sprintf("--%s=json", tmcli.OutputFlag),
	}
	for _, tc := range []struct {
		desc    string
		idDenom string
		args    []string
		err     error
		obj     types.MintingDenom
	}{
		{
			desc:    "get",
			idDenom: objs[0].Denom,
			args:    common,
			obj:     objs[0],
		},
	} {
		t.Run(tc.desc, func(t *testing.T) {
			args := []string{
				tc.idDenom,
			}
			args = append(args, tc.args...)
			out, err := clitestutil.ExecTestCLICmd(ctx, cli.CmdShowMintingDenom(), args)
			if tc.err != nil {
				stat, ok := status.FromError(tc.err)
				require.True(t, ok)
				require.ErrorIs(t, stat.Err(), tc.err)
			} else {
				require.NoError(t, err)
				var resp types.QueryGetMintingDenomResponse
				require.NoError(t, net.Config.Codec.UnmarshalJSON(out.Bytes(), &resp))
				require.NotNil(t, resp.MintingDenom)
				require.Equal(t,
					nullify.Fill(&tc.obj),
					nullify.Fill(&resp.MintingDenom),
				)
			}
		})
	}
}
