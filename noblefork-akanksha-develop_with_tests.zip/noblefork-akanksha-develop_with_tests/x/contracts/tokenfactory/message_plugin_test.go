package tokenfactory_test

import (
	"encoding/json"
	"testing"

	logs "log"

	"cosmossdk.io/math"
	"cosmossdk.io/store"
	"cosmossdk.io/store/metrics"
	storetypes "cosmossdk.io/store/types"
	wasmvmtypes "github.com/CosmWasm/wasmvm/v2/types"
	tmproto "github.com/cometbft/cometbft/proto/tendermint/types"
	dbm "github.com/cosmos/cosmos-db"
	"github.com/cosmos/cosmos-sdk/codec"
	codectypes "github.com/cosmos/cosmos-sdk/codec/types"
	"github.com/cosmos/cosmos-sdk/runtime"
	sdk "github.com/cosmos/cosmos-sdk/types"
	authtypes "github.com/cosmos/cosmos-sdk/x/auth/types"
	paramtypes "github.com/cosmos/cosmos-sdk/x/params/types"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"
	"github.com/wfblockchain/noblechain/v5/testutil/sample"
	"github.com/wfblockchain/noblechain/v5/x/contracts/tokenfactory/bindings"

	"cosmossdk.io/log"
	feegrant "cosmossdk.io/x/feegrant"
	feegrantkeeper "cosmossdk.io/x/feegrant/keeper"
	fiattokenfactorymodulekeeper "github.com/wfblockchain/noble-fiattokenfactory/x/fiattokenfactory/keeper"
	fiattokenfactorymoduletypes "github.com/wfblockchain/noble-fiattokenfactory/x/fiattokenfactory/types"
	"github.com/wfblockchain/noblechain/v5/x/contracts/tokenfactory"
	tokenfactorymodulekeeper "github.com/wfblockchain/noblechain/v5/x/tokenfactory/keeper"
	tokenfactorymoduletypes "github.com/wfblockchain/noblechain/v5/x/tokenfactory/types"
)

type MockMessenger struct {
	mock.Mock
}

func (m *MockMessenger) DispatchMsg(ctx sdk.Context, contractAddr sdk.AccAddress, contractIBCPortID string, msg wasmvmtypes.CosmosMsg) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	args := m.Called(ctx, contractAddr, contractIBCPortID, msg)
	return args.Get(0).([]sdk.Event), args.Get(1).([][]byte), args.Get(2).([][]*codectypes.Any), args.Error(3)
}

type MsgUpdateMasterMinter struct {
	From    string `protobuf:"bytes,1,opt,name=from,proto3" json:"from,omitempty"`
	Address string `protobuf:"bytes,2,opt,name=address,proto3" json:"address,omitempty"`
}

type TokenFactoryMessages struct {
	UpdateMasterMinter *MsgUpdateMasterMinter `json:"update_master_minter,omitempty"`
}

func (m *MockMessenger) updateMasterMinter(ctx sdk.Context, contractAddr sdk.AccAddress, msg interface{}, tf bool) ([]sdk.Event, [][]byte, [][]*codectypes.Any, error) {
	args := m.Called(ctx, contractAddr, msg, tf)
	return args.Get(0).([]sdk.Event), args.Get(1).([][]byte), args.Get(2).([][]*codectypes.Any), args.Error(3)
}

func TestCustomMessagerDecorator(t *testing.T) {
	tf := &tokenfactorymodulekeeper.Keeper{}
	ftf := &fiattokenfactorymodulekeeper.Keeper{}
	feegrant := &feegrantkeeper.Keeper{}

	mockMsg := &MockMessenger{}

	decoratedFunc := tokenfactory.CustomMessagerDecorator(tf, ftf, feegrant)
	wrappedMessenger := decoratedFunc(mockMsg)

	customMessenger, ok := wrappedMessenger.(*tokenfactory.CustomMessenger)
	require.True(t, ok, "Expected wrapped messenger to be of type *CustomMessenger")

	require.Equal(t, tf, customMessenger.Tf, "TokenFactory keeper not set correctly")
	require.Equal(t, ftf, customMessenger.Ftf, "FiatTokenFactory keeper not set correctly")
	require.Equal(t, feegrant, customMessenger.Feegrant, "Feegrant keeper not set correctly")
	require.Equal(t, mockMsg, customMessenger.Wrapped, "Wrapped messenger not set correctly")
}

func TestUpdateMasterMinter(t *testing.T) {
	mockMessenger := new(MockMessenger)
	ctx := sdk.Context{}
	contractAddr := sdk.AccAddress([]byte("someContractAddr"))
	msg := MsgUpdateMasterMinter{
		From:    "senderAddress",
		Address: "newMasterMinterAddress",
	}
	tf := true

	mockMessenger.On("updateMasterMinter", ctx, contractAddr, msg, tf).Return([]sdk.Event{}, [][]byte{}, [][]*codectypes.Any{}, nil)
	events, bytes, any, err := mockMessenger.updateMasterMinter(ctx, contractAddr, msg, tf)

	assert.NoError(t, err)
	assert.Len(t, events, 0)
	assert.Len(t, bytes, 0)
	assert.Len(t, any, 0)

	mockMessenger.AssertExpectations(t)
}

type FactoryMsg struct {
	TF *TokenFactoryMessages `json:"tf,omitempty"`
}

type UpdateMasterMinterMsg struct {
	MasterMinterAddress string `json:"master_minter_address"`
}

func TestDispatchMsg(t *testing.T) {
	ctx := sdk.Context{}
	contractAddr := sdk.AccAddress("contractAddr")
	contractIBCPortID := "portID"

	mockWrapped := new(MockMessenger)
	messenger := tokenfactory.CustomMessenger{Wrapped: mockWrapped}

	msg := wasmvmtypes.CosmosMsg{}
	mockWrapped.On("DispatchMsg", ctx, contractAddr, contractIBCPortID, msg).Return([]sdk.Event{}, [][]byte{}, [][]*codectypes.Any{}, nil)

	events, data, msgResponses, err := messenger.DispatchMsg(ctx, contractAddr, contractIBCPortID, msg)
	assert.NoError(t, err)
	assert.Empty(t, events)
	assert.Empty(t, data)
	assert.Empty(t, msgResponses)

	invalidMsg := wasmvmtypes.CosmosMsg{Custom: []byte("{invalid_json}")}
	events, data, msgResponses, err = messenger.DispatchMsg(ctx, contractAddr, contractIBCPortID, invalidMsg)
	assert.Error(t, err)
	assert.Contains(t, err.Error(), "failed to decode tokenfactory msg")
	assert.Empty(t, events)
	assert.Empty(t, data)
	assert.Empty(t, msgResponses)

	validMsg := wasmvmtypes.CosmosMsg{
		Custom: []byte(`{
			"TF": {
				"UpdateMasterMinter": {"field": "value"}
			},
			"FTF": {
				"UpdateMasterMinter": {"field": "value"}
			}
		}`),
	}

	mockWrapped.On("DispatchMsg", ctx, contractAddr, contractIBCPortID, validMsg).Return([]sdk.Event{}, [][]byte{}, [][]*codectypes.Any{}, nil)

	events, data, msgResponses, err = messenger.DispatchMsg(ctx, contractAddr, contractIBCPortID, validMsg)
	assert.NoError(t, err)
	assert.Empty(t, events)
	assert.Empty(t, data)
	assert.Empty(t, msgResponses)

}

type MockMsgServerImpl struct {
	mock.Mock
}

type MockMsgServerImplFTF struct {
	mock.Mock
}

func TestDispatchMsg_TFUpdateMasterMinter(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(tokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	ownerAddr := sample.AccAddress()

	owner := tokenfactorymoduletypes.Owner{Address: ownerAddr}

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace

	var tfbankKeeper tokenfactorymoduletypes.BankKeeper

	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper)

	tf.SetOwner(ctx, owner)
	masterminter := sample.AccAddress()
	tf.SetMasterMinter(ctx, tokenfactorymoduletypes.MasterMinter{Address: masterminter})

	logs.Printf("Owner Address: %s", ownerAddr)
	logs.Printf("Minter Address: %s", masterminter)

	newminter := sample.AccAddress()

	contractAddr := sdk.AccAddress([]byte("contract_address"))
	mockMessenger := new(MockMessenger)
	updateMinterMsg := bindings.FactoryMsg{
		TF: &bindings.TokenfactoryMsg{
			UpdateMasterMinter: &bindings.UpdateMasterMinter{
				Signer:  ownerAddr,
				Address: newminter,
			},
		},
	}
	customMessenger := &tokenfactory.CustomMessenger{
		Tf: tf,
	}

	msgBytes, err := json.Marshal(updateMinterMsg)
	require.NoError(t, err)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: msgBytes,
	}
	expectedEvents := []sdk.Event{
		sdk.NewEvent(
			"tokenfactory",
			sdk.NewAttribute("update_master_minter", newminter),
		),
	}

	expectedData := [][]byte(nil)

	expectedMsgResponses := [][]*codectypes.Any(nil)

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)

	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)

}
func TestDispatchMsg_FTFUpdateMasterMinter(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(fiattokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	ownerAddr := sample.AccAddress()

	owner := fiattokenfactorymoduletypes.Owner{Address: ownerAddr}

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace

	var ftfbankKeeper fiattokenfactorymoduletypes.BankKeeper

	contractAddr := sdk.AccAddress([]byte("contract_address"))
	mockMessenger := new(MockMessenger)

	ftf := fiattokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, ftfbankKeeper)
	ftf.SetOwner(ctx, owner)
	minter := sample.AccAddress()
	fiattokenfactorymodulekeeper.Keeper.SetMasterMinter(*ftf, ctx, fiattokenfactorymoduletypes.MasterMinter{Address: minter})

	logs.Printf("Owner Address: %s", ownerAddr)
	logs.Printf("Minter Address: %s", minter)

	newminter := sample.AccAddress()

	updateFiatMinterMsg := bindings.FactoryMsg{
		FTF: &bindings.FiatTokenfactoryMsg{
			UpdateMasterMinter: &bindings.UpdateMasterMinter{
				Signer:  ownerAddr,
				Address: newminter,
			},
		},
	}

	customMessenger := &tokenfactory.CustomMessenger{
		Ftf: ftf,
	}

	ftfMsgBytes, err := json.Marshal(updateFiatMinterMsg)
	require.NoError(t, err)
	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: ftfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)

}

func TestDispatchMsg_FTFConfigureMinterController(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(fiattokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace
	var ftfbankKeeper fiattokenfactorymoduletypes.BankKeeper

	contractAddr := sdk.AccAddress([]byte("contract_address"))
	mockMessenger := new(MockMessenger)
	ftf := fiattokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, ftfbankKeeper)

	minter := sample.AccAddress()
	masterminter := sample.AccAddress()
	mintercontroller := sample.AccAddress()
	ftf.SetMasterMinter(ctx, fiattokenfactorymoduletypes.MasterMinter{Address: minter})
	ftf.SetMasterMinter(ctx, fiattokenfactorymoduletypes.MasterMinter{Address: masterminter})

	ftf.SetMinterController(ctx, fiattokenfactorymoduletypes.MinterController{Minter: mintercontroller, Controller: mintercontroller})

	configureFiatMinterControllerMsg := bindings.FactoryMsg{
		FTF: &bindings.FiatTokenfactoryMsg{
			ConfigureMinterController: &bindings.ConfigureMinterController{
				Signer:     masterminter,
				Controller: mintercontroller,
				Minter:     minter,
			},
		},
	}

	customMessenger := &tokenfactory.CustomMessenger{
		Ftf: ftf,
	}

	ftfMsgBytes, err := json.Marshal(configureFiatMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: ftfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)

}

func TestDispatchMsg_TFConfigureMinterController(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(tokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	ownerAddr := sample.AccAddress()

	owner := tokenfactorymoduletypes.Owner{Address: ownerAddr}

	var ps paramtypes.Subspace
	var tfbankKeeper tokenfactorymoduletypes.BankKeeper

	contractAddr := sdk.AccAddress([]byte("contract_address"))
	mockMessenger := new(MockMessenger)

	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper)
	tf.SetOwner(ctx, owner)
	masterminter := sample.AccAddress()
	mintercontroller := sample.AccAddress()
	minter := sample.AccAddress()
	tf.SetMasterMinter(ctx, tokenfactorymoduletypes.MasterMinter{Address: masterminter})

	tf.SetMinterController(ctx, tokenfactorymoduletypes.MinterController{Minter: mintercontroller, Controller: mintercontroller})

	tf.SetMinters(ctx, tokenfactorymoduletypes.Minters{Address: minter})

	configureMinterControllerMsg := bindings.FactoryMsg{
		TF: &bindings.TokenfactoryMsg{
			ConfigureMinterController: &bindings.ConfigureMinterController{
				Signer:     masterminter,
				Controller: mintercontroller,
				Minter:     minter,
			},
		},
	}

	customMessenger := &tokenfactory.CustomMessenger{
		Tf: tf,
	}

	tfMsgBytes, err := json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)

}

func TestDispatchMsg_TFRemoveMinterController(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(tokenfactorymoduletypes.StoreKey)

	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)
	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())
	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	masterminter := sample.AccAddress()
	mintercontroller := sample.AccAddress()
	minter := sample.AccAddress()

	var ps paramtypes.Subspace
	var tfbankKeeper tokenfactorymoduletypes.BankKeeper
	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper)

	tf.SetMasterMinter(ctx, tokenfactorymoduletypes.MasterMinter{Address: masterminter})
	tf.SetMinterController(ctx, tokenfactorymoduletypes.MinterController{Minter: mintercontroller, Controller: mintercontroller})

	tf.SetMinters(ctx, tokenfactorymoduletypes.Minters{Address: minter})

	ms.Commit()

	removeMinterControllerMsg := bindings.FactoryMsg{
		TF: &bindings.TokenfactoryMsg{
			RemoveMinterController: &bindings.RemoveMinterController{
				Signer:     masterminter,
				Controller: mintercontroller,
			},
		},
	}

	customMessenger := &tokenfactory.CustomMessenger{
		Tf: tf,
	}

	tfMsgBytes, err := json.Marshal(removeMinterControllerMsg)
	require.NoError(t, err)

	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger := new(MockMessenger)
	mockMessenger.On("DispatchMsg", ctx, sdk.AccAddress([]byte("contract_address")), "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, sdk.AccAddress([]byte("contract_address")), "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)

}

func TestDispatchMsg_TFConfigureMinter(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(tokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace
	var tfbankKeeper tokenfactorymoduletypes.BankKeeper = &MockBankKeeper{}

	contractAddr := sdk.AccAddress([]byte("contract_address"))
	mockMessenger := new(MockMessenger)
	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper)
	ownerAddr := sample.AccAddress()

	owner := tokenfactorymoduletypes.Owner{Address: ownerAddr}

	tf.SetOwner(ctx, owner)
	minter := sample.AccAddress()
	mintercontroller := minter

	tf.SetMasterMinter(ctx, tokenfactorymoduletypes.MasterMinter{Address: minter})
	tf.SetMinterController(ctx, tokenfactorymoduletypes.MinterController{Minter: mintercontroller, Controller: mintercontroller})

	tf.SetMintingDenom(ctx, tokenfactorymoduletypes.MintingDenom{Denom: "stake"})

	configureMinterControllerMsg := bindings.FactoryMsg{
		TF: &bindings.TokenfactoryMsg{
			ConfigureMinter: &bindings.ConfigureMinter{
				Signer:    mintercontroller,
				Address:   minter,
				Allowance: sdk.NewCoin("ustake", math.NewInt(100)),
			},
		},
	}

	customMessenger := &tokenfactory.CustomMessenger{
		Tf: tf,
	}

	tfMsgBytes, err := json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)

}

func TestDispatchMsg_TFRemoveMinter(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(tokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace
	var tfbankKeeper tokenfactorymoduletypes.BankKeeper = &MockBankKeeper{}

	contractAddr := sdk.AccAddress([]byte("contract_address"))
	mockMessenger := new(MockMessenger)
	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper)

	ownerAddr := sample.AccAddress()

	owner := tokenfactorymoduletypes.Owner{Address: ownerAddr}

	tf.SetOwner(ctx, owner)
	minter := sample.AccAddress()
	mintercontroller := minter

	tf.SetMasterMinter(ctx, tokenfactorymoduletypes.MasterMinter{Address: minter})
	tf.SetMinterController(ctx, tokenfactorymoduletypes.MinterController{Minter: mintercontroller, Controller: mintercontroller})

	tf.SetMintingDenom(ctx, tokenfactorymoduletypes.MintingDenom{Denom: "stake"})

	configureMinterControllerMsg := bindings.FactoryMsg{
		TF: &bindings.TokenfactoryMsg{
			ConfigureMinter: &bindings.ConfigureMinter{
				Signer:    mintercontroller,
				Address:   minter,
				Allowance: sdk.NewCoin("ustake", math.NewInt(100)),
			},
		},
	}

	customMessenger := &tokenfactory.CustomMessenger{
		Tf: tf,
	}

	tfMsgBytes, err := json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)

	configureMinterControllerMsg = bindings.FactoryMsg{
		TF: &bindings.TokenfactoryMsg{
			RemoveMinter: &bindings.RemoveMinter{
				Signer:  mintercontroller,
				Address: minter,
			},
		},
	}

	customMessenger = &tokenfactory.CustomMessenger{
		Tf: tf,
	}

	tfMsgBytes, err = json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents = []sdk.Event(nil)
	expectedData = [][]byte(nil)
	expectedMsgResponses = [][]*codectypes.Any(nil)

	cosmosMsg = wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err = customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)

}

func TestDispatchMsg_TFUpdateBlacklister(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(tokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace
	var tfbankKeeper tokenfactorymoduletypes.BankKeeper

	contractAddr := sdk.AccAddress([]byte("contract_address"))
	mockMessenger := new(MockMessenger)
	ownerAddr := sample.AccAddress()
	blacklister := sample.AccAddress()
	owner := tokenfactorymoduletypes.Owner{Address: ownerAddr}
	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper)

	tf.SetOwner(ctx, owner)

	configureMinterControllerMsg := bindings.FactoryMsg{
		TF: &bindings.TokenfactoryMsg{
			UpdateBlacklister: &bindings.UpdateBlacklister{
				Signer:  ownerAddr,
				Address: blacklister,
			},
		},
	}

	customMessenger := &tokenfactory.CustomMessenger{
		Tf: tf,
	}

	tfMsgBytes, err := json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)
}

func TestDispatchMsg_TFBlacklist(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(tokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace
	var tfbankKeeper tokenfactorymoduletypes.BankKeeper

	contractAddr := sdk.AccAddress([]byte("contract_address"))
	mockMessenger := new(MockMessenger)

	blacklister := sample.AccAddress()

	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper)
	tf.SetBlacklister(ctx, tokenfactorymoduletypes.Blacklister{Address: blacklister})
	blacklist := sample.AccAddress()

	configureMinterControllerMsg := bindings.FactoryMsg{
		TF: &bindings.TokenfactoryMsg{
			Blacklist: &bindings.Blacklist{
				Signer:  blacklister,
				Address: blacklist,
			},
		},
	}

	customMessenger := &tokenfactory.CustomMessenger{
		Tf: tf,
	}

	tfMsgBytes, err := json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)

}

func TestDispatchMsg_TFUnblacklist(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(tokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace
	var tfbankKeeper tokenfactorymoduletypes.BankKeeper

	contractAddr := sdk.AccAddress([]byte("contract_address"))
	mockMessenger := new(MockMessenger)

	blacklister := sample.AccAddress()

	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper)
	tf.SetBlacklister(ctx, tokenfactorymoduletypes.Blacklister{Address: blacklister})
	blacklist := sample.AccAddress()

	configureMinterControllerMsg := bindings.FactoryMsg{
		TF: &bindings.TokenfactoryMsg{
			Blacklist: &bindings.Blacklist{
				Signer:  blacklister,
				Address: blacklist,
			},
		},
	}

	customMessenger := &tokenfactory.CustomMessenger{
		Tf: tf,
	}

	tfMsgBytes, err := json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)

	configureMinterControllerMsg = bindings.FactoryMsg{
		TF: &bindings.TokenfactoryMsg{
			Unblacklist: &bindings.Unblacklist{
				Signer:  blacklister,
				Address: blacklist,
			},
		},
	}

	customMessenger = &tokenfactory.CustomMessenger{
		Tf: tf,
	}

	tfMsgBytes, err = json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents = []sdk.Event(nil)
	expectedData = [][]byte(nil)
	expectedMsgResponses = [][]*codectypes.Any(nil)

	cosmosMsg = wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err = customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)
}

func TestDispatchMsg_TFUpdatePauser(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(tokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace
	var tfbankKeeper tokenfactorymoduletypes.BankKeeper

	contractAddr := sdk.AccAddress([]byte("contract_address"))
	mockMessenger := new(MockMessenger)

	ownerAddr := sample.AccAddress()
	owner := tokenfactorymoduletypes.Owner{Address: ownerAddr}
	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper)
	pauser := sample.AccAddress()

	tf.SetOwner(ctx, owner)

	configureMinterControllerMsg := bindings.FactoryMsg{
		TF: &bindings.TokenfactoryMsg{
			UpdatePauser: &bindings.UpdatePauser{
				Signer:  ownerAddr,
				Address: pauser,
			},
		},
	}

	customMessenger := &tokenfactory.CustomMessenger{
		Tf: tf,
	}

	tfMsgBytes, err := json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)

}

func TestDispatchMsg_TFPause(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(tokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace
	var tfbankKeeper tokenfactorymoduletypes.BankKeeper

	contractAddr := sdk.AccAddress([]byte("contract_address"))
	mockMessenger := new(MockMessenger)
	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper)

	pauserAddr := sample.AccAddress()
	tf.SetPauser(ctx, tokenfactorymoduletypes.Pauser{Address: pauserAddr})

	configureMinterControllerMsg := bindings.FactoryMsg{
		TF: &bindings.TokenfactoryMsg{
			Pause: &bindings.Pause{
				Signer: pauserAddr,
			},
		},
	}

	customMessenger := &tokenfactory.CustomMessenger{
		Tf: tf,
	}

	tfMsgBytes, err := json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)

}

func TestDispatchMsg_TFUnpause(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(tokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace
	var tfbankKeeper tokenfactorymoduletypes.BankKeeper

	contractAddr := sdk.AccAddress([]byte("contract_address"))
	mockMessenger := new(MockMessenger)
	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper)

	pauserAddr := sample.AccAddress()
	tf.SetPauser(ctx, tokenfactorymoduletypes.Pauser{Address: pauserAddr})

	configureMinterControllerMsg := bindings.FactoryMsg{
		TF: &bindings.TokenfactoryMsg{
			Unpause: &bindings.Unpause{
				Signer: pauserAddr,
			},
		},
	}

	customMessenger := &tokenfactory.CustomMessenger{
		Tf: tf,
	}

	tfMsgBytes, err := json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)
}

func TestDispatchMsg_TFMint(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(tokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace
	var tfbankKeeper tokenfactorymoduletypes.BankKeeper = &MockBankKeeper{}

	contractAddr := sdk.AccAddress([]byte("contract_address"))
	mockMessenger := new(MockMessenger)
	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper)
	ownerAddr := sample.AccAddress()

	owner := tokenfactorymoduletypes.Owner{Address: ownerAddr}

	tf.SetOwner(ctx, owner)
	minter := sample.AccAddress()
	mintercontroller := minter

	tf.SetMasterMinter(ctx, tokenfactorymoduletypes.MasterMinter{Address: minter})
	tf.SetMinterController(ctx, tokenfactorymoduletypes.MinterController{Minter: mintercontroller, Controller: mintercontroller})

	tf.SetMintingDenom(ctx, tokenfactorymoduletypes.MintingDenom{Denom: "stake"}) // This will initialize the minting denom

	configureMinterControllerMsg := bindings.FactoryMsg{
		TF: &bindings.TokenfactoryMsg{
			ConfigureMinter: &bindings.ConfigureMinter{
				Signer:    mintercontroller,
				Address:   minter,
				Allowance: sdk.NewCoin("ustake", math.NewInt(100)),
			},
		},
	}

	customMessenger := &tokenfactory.CustomMessenger{
		Tf: tf,
	}

	tfMsgBytes, err := json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)

	alice := sample.AccAddress()

	configureMinterControllerMsg = bindings.FactoryMsg{
		TF: &bindings.TokenfactoryMsg{
			Mint: &bindings.Mint{
				Signer:  minter,
				Address: alice,
				Amount:  sdk.NewCoin("ustake", math.NewInt(100)),
			},
		},
	}

	customMessenger = &tokenfactory.CustomMessenger{
		Tf: tf,
	}

	tfMsgBytes, err = json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents = []sdk.Event(nil)
	expectedData = [][]byte(nil)
	expectedMsgResponses = [][]*codectypes.Any(nil)

	cosmosMsg = wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err = customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)

}

func TestDispatchMsg_FTFMint(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(fiattokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace
	var ftfbankKeeper fiattokenfactorymoduletypes.BankKeeper = &MockBankKeeper{}

	contractAddr := sdk.AccAddress([]byte("contract_address"))
	mockMessenger := new(MockMessenger)
	ftf := fiattokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, ftfbankKeeper)
	ownerAddr := sample.AccAddress()

	owner := fiattokenfactorymoduletypes.Owner{Address: ownerAddr}

	ftf.SetOwner(ctx, owner)
	minter := sample.AccAddress()
	mintercontroller := minter

	ftf.SetMasterMinter(ctx, fiattokenfactorymoduletypes.MasterMinter{Address: minter})
	ftf.SetMinterController(ctx, fiattokenfactorymoduletypes.MinterController{Minter: mintercontroller, Controller: mintercontroller})

	ftf.SetMintingDenom(ctx, fiattokenfactorymoduletypes.MintingDenom{Denom: "stake"}) // This will initialize the minting denom
	ftf.SetPaused(ctx, fiattokenfactorymoduletypes.Paused{Paused: false})

	configureMinterControllerMsg := bindings.FactoryMsg{
		FTF: &bindings.FiatTokenfactoryMsg{
			ConfigureMinter: &bindings.ConfigureMinter{
				Signer:    mintercontroller,
				Address:   minter,
				Allowance: sdk.NewCoin("ustake", math.NewInt(100)),
			},
		},
	}

	customMessenger := &tokenfactory.CustomMessenger{
		Ftf: ftf,
	}

	tfMsgBytes, err := json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)

	alice := sample.AccAddress()

	configureMinterControllerMsg = bindings.FactoryMsg{
		FTF: &bindings.FiatTokenfactoryMsg{
			Mint: &bindings.Mint{
				Signer:  minter,
				Address: alice,
				Amount:  sdk.NewCoin("ustake", math.NewInt(100)),
			},
		},
	}

	customMessenger = &tokenfactory.CustomMessenger{
		Ftf: ftf,
	}

	tfMsgBytes, err = json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents = []sdk.Event(nil)
	expectedData = [][]byte(nil)
	expectedMsgResponses = [][]*codectypes.Any(nil)

	cosmosMsg = wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err = customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)

}

func TestDispatchMsg_TFBurn(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(tokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace
	var tfbankKeeper tokenfactorymoduletypes.BankKeeper = &MockBankKeeper{}

	contractAddr := sdk.AccAddress([]byte("contract_address"))
	mockMessenger := new(MockMessenger)

	ownerAddr := sample.AccAddress()

	owner := tokenfactorymoduletypes.Owner{Address: ownerAddr}
	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper)

	tf.SetOwner(ctx, owner)
	minter := sample.AccAddress()
	mintercontroller := minter

	tf.SetMasterMinter(ctx, tokenfactorymoduletypes.MasterMinter{Address: minter})
	tf.SetMinterController(ctx, tokenfactorymoduletypes.MinterController{Minter: mintercontroller, Controller: mintercontroller})

	tf.SetMintingDenom(ctx, tokenfactorymoduletypes.MintingDenom{Denom: "stake"}) // This will initialize the minting denom

	configureMinterControllerMsg := bindings.FactoryMsg{
		TF: &bindings.TokenfactoryMsg{
			ConfigureMinter: &bindings.ConfigureMinter{
				Signer:    mintercontroller,
				Address:   minter,
				Allowance: sdk.NewCoin("ustake", math.NewInt(100)),
			},
		},
	}

	customMessenger := &tokenfactory.CustomMessenger{
		Tf: tf,
	}

	tfMsgBytes, err := json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)

	configureMinterControllerMsg = bindings.FactoryMsg{
		TF: &bindings.TokenfactoryMsg{
			Burn: &bindings.Burn{
				Signer: minter,
				Amount: sdk.NewCoin("ustake", math.NewInt(100)),
			},
		},
	}

	customMessenger = &tokenfactory.CustomMessenger{
		Tf: tf,
	}

	tfMsgBytes, err = json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents = []sdk.Event(nil)
	expectedData = [][]byte(nil)
	expectedMsgResponses = [][]*codectypes.Any(nil)

	cosmosMsg = wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err = customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)

}

func TestDispatchMsg_FTFRemoveMinterController(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(fiattokenfactorymoduletypes.StoreKey)

	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)
	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())
	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	masterminter := sample.AccAddress()
	mintercontroller := sample.AccAddress()
	minter := sample.AccAddress()

	var ps paramtypes.Subspace
	var ftfbankKeeper fiattokenfactorymoduletypes.BankKeeper
	ftf := fiattokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, ftfbankKeeper)

	ftf.SetMasterMinter(ctx, fiattokenfactorymoduletypes.MasterMinter{Address: masterminter})
	ftf.SetMinterController(ctx, fiattokenfactorymoduletypes.MinterController{Minter: mintercontroller, Controller: mintercontroller})

	ftf.SetMinters(ctx, fiattokenfactorymoduletypes.Minters{Address: minter})

	ms.Commit()

	removeMinterControllerMsg := bindings.FactoryMsg{
		FTF: &bindings.FiatTokenfactoryMsg{
			RemoveMinterController: &bindings.RemoveMinterController{
				Signer:     masterminter,
				Controller: mintercontroller,
			},
		},
	}

	customMessenger := &tokenfactory.CustomMessenger{
		Ftf: ftf,
	}

	tfMsgBytes, err := json.Marshal(removeMinterControllerMsg)
	require.NoError(t, err)

	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger := new(MockMessenger)
	mockMessenger.On("DispatchMsg", ctx, sdk.AccAddress([]byte("contract_address")), "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, sdk.AccAddress([]byte("contract_address")), "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)
}

func TestDispatchMsg_FTFRemoveMinter(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(fiattokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace
	var ftfbankKeeper fiattokenfactorymoduletypes.BankKeeper = &MockBankKeeper{}

	contractAddr := sdk.AccAddress([]byte("contract_address"))
	mockMessenger := new(MockMessenger)
	ftf := fiattokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, ftfbankKeeper)

	ownerAddr := sample.AccAddress()

	owner := fiattokenfactorymoduletypes.Owner{Address: ownerAddr}

	ftf.SetOwner(ctx, owner)
	minter := sample.AccAddress()
	mintercontroller := minter

	ftf.SetMasterMinter(ctx, fiattokenfactorymoduletypes.MasterMinter{Address: minter})
	ftf.SetMinterController(ctx, fiattokenfactorymoduletypes.MinterController{Minter: mintercontroller, Controller: mintercontroller})

	ftf.SetMintingDenom(ctx, fiattokenfactorymoduletypes.MintingDenom{Denom: "stake"})

	configureMinterControllerMsg := bindings.FactoryMsg{
		FTF: &bindings.FiatTokenfactoryMsg{
			ConfigureMinter: &bindings.ConfigureMinter{
				Signer:    mintercontroller,
				Address:   minter,
				Allowance: sdk.NewCoin("ustake", math.NewInt(100)),
			},
		},
	}

	customMessenger := &tokenfactory.CustomMessenger{
		Ftf: ftf,
	}

	tfMsgBytes, err := json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)

	configureMinterControllerMsg = bindings.FactoryMsg{
		FTF: &bindings.FiatTokenfactoryMsg{
			RemoveMinter: &bindings.RemoveMinter{
				Signer:  mintercontroller,
				Address: minter,
			},
		},
	}

	customMessenger = &tokenfactory.CustomMessenger{
		Ftf: ftf,
	}

	tfMsgBytes, err = json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents = []sdk.Event(nil)
	expectedData = [][]byte(nil)
	expectedMsgResponses = [][]*codectypes.Any(nil)

	cosmosMsg = wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err = customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)

}

func TestDispatchMsg_FTFUpdateBlacklister(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(fiattokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace
	var ftfbankKeeper fiattokenfactorymoduletypes.BankKeeper

	contractAddr := sdk.AccAddress([]byte("contract_address"))
	mockMessenger := new(MockMessenger)
	ownerAddr := sample.AccAddress()
	blacklister := sample.AccAddress()
	owner := fiattokenfactorymoduletypes.Owner{Address: ownerAddr}
	ftf := fiattokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, ftfbankKeeper)

	ftf.SetOwner(ctx, owner)

	configureMinterControllerMsg := bindings.FactoryMsg{
		FTF: &bindings.FiatTokenfactoryMsg{
			UpdateBlacklister: &bindings.UpdateBlacklister{
				Signer:  ownerAddr,
				Address: blacklister,
			},
		},
	}

	customMessenger := &tokenfactory.CustomMessenger{
		Ftf: ftf,
	}

	tfMsgBytes, err := json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)
}

func TestDispatchMsg_FTFBlacklist(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(fiattokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace
	var ftfbankKeeper fiattokenfactorymoduletypes.BankKeeper

	contractAddr := sdk.AccAddress([]byte("contract_address"))
	mockMessenger := new(MockMessenger)

	blacklister := sample.AccAddress()

	ftf := fiattokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, ftfbankKeeper)
	ftf.SetBlacklister(ctx, fiattokenfactorymoduletypes.Blacklister{Address: blacklister})
	blacklist := sample.AccAddress()

	configureMinterControllerMsg := bindings.FactoryMsg{
		FTF: &bindings.FiatTokenfactoryMsg{
			Blacklist: &bindings.Blacklist{
				Signer:  blacklister,
				Address: blacklist,
			},
		},
	}

	customMessenger := &tokenfactory.CustomMessenger{
		Ftf: ftf,
	}

	tfMsgBytes, err := json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)
}

func TestDispatchMsg_FTFUnblacklist(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(fiattokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace
	var ftfbankKeeper fiattokenfactorymoduletypes.BankKeeper

	contractAddr := sdk.AccAddress([]byte("contract_address"))
	mockMessenger := new(MockMessenger)

	blacklister := sample.AccAddress()

	ftf := fiattokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, ftfbankKeeper)
	ftf.SetBlacklister(ctx, fiattokenfactorymoduletypes.Blacklister{Address: blacklister})
	blacklist := sample.AccAddress()

	configureMinterControllerMsg := bindings.FactoryMsg{
		FTF: &bindings.FiatTokenfactoryMsg{
			Blacklist: &bindings.Blacklist{
				Signer:  blacklister,
				Address: blacklist,
			},
		},
	}

	customMessenger := &tokenfactory.CustomMessenger{
		Ftf: ftf,
	}

	tfMsgBytes, err := json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)

	configureMinterControllerMsg = bindings.FactoryMsg{
		FTF: &bindings.FiatTokenfactoryMsg{
			Unblacklist: &bindings.Unblacklist{
				Signer:  blacklister,
				Address: blacklist,
			},
		},
	}

	customMessenger = &tokenfactory.CustomMessenger{
		Ftf: ftf,
	}

	tfMsgBytes, err = json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents = []sdk.Event(nil)
	expectedData = [][]byte(nil)
	expectedMsgResponses = [][]*codectypes.Any(nil)

	cosmosMsg = wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err = customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)
}

func TestDispatchMsg_FTFUpdatePauser(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(fiattokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace
	var ftfbankKeeper fiattokenfactorymoduletypes.BankKeeper

	contractAddr := sdk.AccAddress([]byte("contract_address"))
	mockMessenger := new(MockMessenger)

	ownerAddr := sample.AccAddress()
	owner := fiattokenfactorymoduletypes.Owner{Address: ownerAddr}
	ftf := fiattokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, ftfbankKeeper)
	pauser := sample.AccAddress()

	ftf.SetOwner(ctx, owner)

	configureMinterControllerMsg := bindings.FactoryMsg{
		FTF: &bindings.FiatTokenfactoryMsg{
			UpdatePauser: &bindings.UpdatePauser{
				Signer:  ownerAddr,
				Address: pauser,
			},
		},
	}

	customMessenger := &tokenfactory.CustomMessenger{
		Ftf: ftf,
	}

	tfMsgBytes, err := json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)

}

func TestDispatchMsg_FTFPause(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(fiattokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace
	var ftfbankKeeper fiattokenfactorymoduletypes.BankKeeper

	contractAddr := sdk.AccAddress([]byte("contract_address"))
	mockMessenger := new(MockMessenger)
	ftf := fiattokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, ftfbankKeeper)

	pauserAddr := sample.AccAddress()
	ftf.SetPauser(ctx, fiattokenfactorymoduletypes.Pauser{Address: pauserAddr})

	configureMinterControllerMsg := bindings.FactoryMsg{
		FTF: &bindings.FiatTokenfactoryMsg{
			Pause: &bindings.Pause{
				Signer: pauserAddr,
			},
		},
	}

	customMessenger := &tokenfactory.CustomMessenger{
		Ftf: ftf,
	}

	tfMsgBytes, err := json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)
}

func TestDispatchMsg_FTFUnpause(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(fiattokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace
	var ftfbankKeeper fiattokenfactorymoduletypes.BankKeeper

	contractAddr := sdk.AccAddress([]byte("contract_address"))
	mockMessenger := new(MockMessenger)
	ftf := fiattokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, ftfbankKeeper)

	pauserAddr := sample.AccAddress()
	ftf.SetPauser(ctx, fiattokenfactorymoduletypes.Pauser{Address: pauserAddr})

	configureMinterControllerMsg := bindings.FactoryMsg{
		FTF: &bindings.FiatTokenfactoryMsg{
			Unpause: &bindings.Unpause{
				Signer: pauserAddr,
			},
		},
	}

	customMessenger := &tokenfactory.CustomMessenger{
		Ftf: ftf,
	}

	tfMsgBytes, err := json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)
}

func TestDispatchMsg_FTFBurn(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(fiattokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace
	var ftfbankKeeper fiattokenfactorymoduletypes.BankKeeper = &MockBankKeeper{}

	contractAddr := sdk.AccAddress([]byte("contract_address"))
	mockMessenger := new(MockMessenger)

	ownerAddr := sample.AccAddress()

	owner := fiattokenfactorymoduletypes.Owner{Address: ownerAddr}
	ftf := fiattokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, ftfbankKeeper)

	ftf.SetOwner(ctx, owner)
	minter := sample.AccAddress()
	mintercontroller := minter

	ftf.SetMasterMinter(ctx, fiattokenfactorymoduletypes.MasterMinter{Address: minter})
	ftf.SetMinterController(ctx, fiattokenfactorymoduletypes.MinterController{Minter: mintercontroller, Controller: mintercontroller})

	ftf.SetMintingDenom(ctx, fiattokenfactorymoduletypes.MintingDenom{Denom: "stake"})
	ftf.SetPaused(ctx, fiattokenfactorymoduletypes.Paused{Paused: false})

	configureMinterControllerMsg := bindings.FactoryMsg{
		FTF: &bindings.FiatTokenfactoryMsg{
			ConfigureMinter: &bindings.ConfigureMinter{
				Signer:    mintercontroller,
				Address:   minter,
				Allowance: sdk.NewCoin("ustake", math.NewInt(100)),
			},
		},
	}

	customMessenger := &tokenfactory.CustomMessenger{
		Ftf: ftf,
	}

	tfMsgBytes, err := json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)

	configureMinterControllerMsg = bindings.FactoryMsg{
		FTF: &bindings.FiatTokenfactoryMsg{
			Burn: &bindings.Burn{
				Signer: minter,
				Amount: sdk.NewCoin("ustake", math.NewInt(100)),
			},
		},
	}

	customMessenger = &tokenfactory.CustomMessenger{
		Ftf: ftf,
	}

	tfMsgBytes, err = json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents = []sdk.Event(nil)
	expectedData = [][]byte(nil)
	expectedMsgResponses = [][]*codectypes.Any(nil)

	cosmosMsg = wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err = customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)

}

func TestDispatchMsg_FeegrantGrantFeeBasicAllowance(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(feegrant.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	mockAccount := &authtypes.BaseAccount{}

	accountKeeper := &MockAccountKeeper{}
	mockAddressCodec := new(MockAddressCodec)

	contractAddr := sdk.AccAddress([]byte("contract_address"))
	mockMessenger := new(MockMessenger)

	signer := sample.AccAddress()
	granter := sample.AccAddress()
	grantee := sample.AccAddress()

	accountKeeper.On("AddressCodec").Return(mockAddressCodec)
	mockAddressCodec.On("StringToBytes", signer).Return([]byte(signer), nil)
	mockAddressCodec.On("StringToBytes", granter).Return([]byte(granter), nil)
	mockAddressCodec.On("StringToBytes", grantee).Return([]byte(grantee), nil)
	accountKeeper.On("GetAccount", mock.Anything, mock.Anything).Return(mockAccount)

	logs.Println("Signer: " + signer)
	logs.Println("Granter: " + granter)
	logs.Println("Grantee: " + grantee)

	configureFiatMinterControllerMsg := bindings.FactoryMsg{
		Feegrant: &bindings.FeegrantMsg{
			GrantFeeBasicAllowance: &bindings.GrantFeeBasicAllowance{
				Signer:        signer,
				Granter:       signer,
				Grantee:       grantee,
				Allowance:     sdk.NewCoin("ustake", math.NewInt(100)),
				HoursToExpire: 3,
			},
		},
	}
	feegrant := feegrantkeeper.NewKeeper(cdc, runtime.NewKVStoreService(storeKey), accountKeeper)

	customMessenger := &tokenfactory.CustomMessenger{
		Feegrant: &feegrant,
	}

	ftfMsgBytes, err := json.Marshal(configureFiatMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: ftfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)
}

func TestDispatchMsg_FeegrantRevokeFeeAllowance(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(feegrant.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	registry := codectypes.NewInterfaceRegistry()
	feegrant.RegisterInterfaces(registry)
	cdc := codec.NewProtoCodec(registry)
	mockAccount := &authtypes.BaseAccount{}

	accountKeeper := &MockAccountKeeper{}
	mockAddressCodec := new(MockAddressCodec)

	contractAddr := sdk.AccAddress([]byte("contract_address"))
	mockMessenger := new(MockMessenger)

	signer := sample.AccAddress()
	granter := sample.AccAddress()
	grantee := sample.AccAddress()

	accountKeeper.On("AddressCodec").Return(mockAddressCodec)
	mockAddressCodec.On("StringToBytes", signer).Return([]byte(signer), nil)
	mockAddressCodec.On("StringToBytes", granter).Return([]byte(granter), nil)
	mockAddressCodec.On("StringToBytes", grantee).Return([]byte(grantee), nil)
	accountKeeper.On("GetAccount", mock.Anything, mock.Anything).Return(mockAccount)

	logs.Println("Signer: " + signer)
	logs.Println("Granter: " + granter)
	logs.Println("Grantee: " + grantee)

	configureFiatMinterControllerMsg := bindings.FactoryMsg{
		Feegrant: &bindings.FeegrantMsg{
			GrantFeeBasicAllowance: &bindings.GrantFeeBasicAllowance{
				Signer:        signer,
				Granter:       signer,
				Grantee:       grantee,
				Allowance:     sdk.NewCoin("ustake", math.NewInt(100)),
				HoursToExpire: 3,
			},
		},
	}
	feegrant := feegrantkeeper.NewKeeper(cdc, runtime.NewKVStoreService(storeKey), accountKeeper)

	customMessenger := &tokenfactory.CustomMessenger{
		Feegrant: &feegrant,
	}

	ftfMsgBytes, err := json.Marshal(configureFiatMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: ftfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)

	configureFiatMinterControllerMsg = bindings.FactoryMsg{
		Feegrant: &bindings.FeegrantMsg{
			RevokeFeeAllowance: &bindings.RevokeFeeAllowance{
				Signer:  signer,
				Granter: signer,
				Grantee: grantee,
			},
		},
	}
	feegrant = feegrantkeeper.NewKeeper(cdc, runtime.NewKVStoreService(storeKey), accountKeeper)

	customMessenger = &tokenfactory.CustomMessenger{
		Feegrant: &feegrant,
	}

	ftfMsgBytes, err = json.Marshal(configureFiatMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents = []sdk.Event(nil)
	expectedData = [][]byte(nil)
	expectedMsgResponses = [][]*codectypes.Any(nil)

	cosmosMsg = wasmvmtypes.CosmosMsg{
		Custom: ftfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err = customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)
}
