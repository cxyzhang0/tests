package cmd_test

import (
	"testing"

	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/stretchr/testify/assert"
	"github.com/wfblockchain/noblechain/v5/cmd"
)

func TestNewRootCmd(t *testing.T) {
	sdk.GetConfig().SetBech32PrefixForAccount("wf", "accountAddressPrefixpub")
	sdk.GetConfig().SetBech32PrefixForValidator("wf", "accountAddressPrefixvalpub")
	sdk.GetConfig().SetBech32PrefixForConsensusNode("wf", "accountAddressPrefixcons")
	rootCmd := cmd.NewRootCmd()
	t.Run("Check Root Command Setup", func(t *testing.T) {
		assert.NotNil(t, rootCmd)
		assert.Equal(t, "tokenfactoryd", rootCmd.Use)
		assert.Equal(t, "noblefork app", rootCmd.Short)
	})

	t.Run("Test Command Execution", func(t *testing.T) {
		err := rootCmd.Execute()
		assert.NoError(t, err, "Root command should execute without error")
	})

	t.Run("Check Subcommands", func(t *testing.T) {
		cmdExists := false
		for _, cmd := range rootCmd.Commands() {
			if cmd.Use == "tx" {
				cmdExists = true
				break
			}
		}
		assert.True(t, cmdExists, "Expected 'tx' subcommand to be present")
	})
}
