package cmd_test

import (
	"bytes"
	"os"
	"testing"

	"cosmossdk.io/log"
	dbm "github.com/cosmos/cosmos-db"
	sdk "github.com/cosmos/cosmos-sdk/types"

	cmtcfg "github.com/cometbft/cometbft/config"
	serverconfig "github.com/cosmos/cosmos-sdk/server/config"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"
	"github.com/wfblockchain/noblechain/v5/cmd"
)

type MockAppOptions struct {
	options map[string]interface{}
}

func (m MockAppOptions) Get(key string) interface{} {
	return m.options[key]
}

func TestNewApp(t *testing.T) {
	homeDir := os.Getenv("HOME") + "/.tokenfactory"
	if _, err := os.Stat(homeDir + "/config/genesis.json"); os.IsNotExist(err) {
		t.Fatalf("genesis.json not found in %s", homeDir+"/config")
	}
	logger := log.NewNopLogger()
	db := dbm.NewMemDB()
	var traceStore bytes.Buffer
	appOpts := MockAppOptions{
		options: map[string]interface{}{
			"telemetry.enabled": true,
			"pruning":           "default",
			"home":              homeDir,
		},
	}
	defer func() {
		if r := recover(); r != nil {
			t.Fatalf("newApp panicked: %v", r)
		}
	}()

	app := cmd.NewApp(logger, db, &traceStore, appOpts)
	require.NotNil(t, app, "Expected app to be initialized successfully")
}
func TestSetPrefixes(t *testing.T) {
	accountAddressPrefix := "accountAddressPrefix"
	cmd.SetPrefixes(accountAddressPrefix)
	config := sdk.GetConfig()
	require.Equal(t, accountAddressPrefix, config.GetBech32AccountAddrPrefix(), "Account address prefix mismatch")
	require.Equal(t, accountAddressPrefix+"pub", config.GetBech32AccountPubPrefix(), "Account pubkey prefix mismatch")
	require.Equal(t, accountAddressPrefix+"valoper", config.GetBech32ValidatorAddrPrefix(), "Validator address prefix mismatch")
	require.Equal(t, accountAddressPrefix+"valoperpub", config.GetBech32ValidatorPubPrefix(), "Validator pubkey prefix mismatch")
	require.Equal(t, accountAddressPrefix+"valcons", config.GetBech32ConsensusAddrPrefix(), "Consensus address prefix mismatch")
	require.Equal(t, accountAddressPrefix+"valconspub", config.GetBech32ConsensusPubPrefix(), "Consensus pubkey prefix mismatch")
}

func TestInitCometBFTConfig(t *testing.T) {
	cfg := cmd.InitCometBFTConfig()
	require.NotNil(t, cfg, "Config should not be nil")
	require.Equal(t, cmtcfg.DefaultConfig().P2P.MaxNumInboundPeers, cfg.P2P.MaxNumInboundPeers, "Inbound peers should match default")
	require.Equal(t, cmtcfg.DefaultConfig().P2P.MaxNumOutboundPeers, cfg.P2P.MaxNumOutboundPeers, "Outbound peers should match default")
}

type CustomConfig struct {
	CustomField string `mapstructure:"custom-field"`
}

type CustomAppConfig struct {
	serverconfig.Config `mapstructure:",squash"`
	Custom              CustomConfig `mapstructure:"custom"`
}

func TestInitAppConfig(t *testing.T) {
	configTemplate, customConfig := cmd.InitAppConfig()
	require.NotEmpty(t, configTemplate, "Config template should not be empty")
	require.NotNil(t, customConfig, "Config object should not be nil")
	require.Equal(t, "0stake", customConfig.MinGasPrices, "MinGasPrices should be set to '0stake'")
	require.Equal(t, "anything", customConfig.Custom.CustomField, "CustomField should be 'anything'")
	require.Contains(t, configTemplate, `custom-field = "{{ .Custom.CustomField }}"`, "Config template should contain the custom field placeholder")
}

type MockDB struct {
	mock.Mock
}

func (m *MockDB) Get([]byte) ([]byte, error) {
	args := m.Called()
	return args.Get(0).([]byte), args.Error(1)
}

func (m *MockDB) Set([]byte, []byte) error {
	args := m.Called()
	return args.Error(0)
}
