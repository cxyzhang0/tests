# Developer notes

This repo is intended to be a private fork of https://github.com/noble-assets/noble.git.  
> - Our contributions include:
> - - Upgrade to the latest cosmos sdk and cometbft.
> - - Add [wasm integration](./x/contracts/).
> - - Add [support for multiple minting denoms](./multi-denom.md). 
> - - Many build scripts
> - - - [./play_tf.sh](./play_tf.sh) and [./chains.env](./chains.env) for running local single-validator tokenfactory chain with all soft keys.
> - - - [./play_wallet.sh](./play_wallet.sh) and [./chains_wallet.env](./chains_wallet.env) for running local single-validator tokenfactory chain with hsm keys for all players except for validator account and consensus keys.
> - - - [./play_wallet_tmkms.sh](./play_wallet_tmkms.sh) and [./chains_wallet_tmkms.env](./chains_wallet_tmkms.env) for running local single-validator tokenfactory chain with hsm keys for all players including validator consensus key except for validator account key.
> - - - [./play_wallet_tmkms.sh](./play_wallet_tmkms.sh) and [./chains_wallet_tmkms.env](./chains_wallet_tmkms.env) for running local single-validator tokenfactory chain with hsm keys for all players including validator consensus key except for validator account key.
> - - - [./july](./july) multi-validator build scripts for production release scheduled for July 2024. 
> - - - [./play_1_val_july.sh](./play_1_val_july.sh) and [./chains_1_val_july.env](./chains_1_val_july.env) for testing the july scripts locally. Note: it may be out of date because we now need to create genesis accounts for all governance players. Refer to ./july/build-genesis.sh for update.
> - - Test coverage.

We need to be able to fetch future changes in the original repo via upstream.
> Note: noble-assets/noble has since made significant changes. 
> - Specifically, it has been upgraded to the latest cosmos sdk and cometbft. 
> - Most importantly, x/tokenfactory has been removed. That is probably because its business model is to support multiple stablecoin issuers so that each issuer will independently develop its own token issuring module.
> - - At this point, per its website https://www.noble.xyz/ and its go.mod , it supports ciclefin/noble-fiattokenfactory (USDC), monerium/module-noble (EURe), dollar.noble.xyz (USDN), ondoprotocol/usdy-noble (USDY), and swap.noble.xyz (USYC?). 
> - - Among them, ciclefin/noble-fiattokenfactory mostly resembles our tokenfactory because fiattokenfactory inherited the original x/tokenfactory. 

## Scripts to build, test, and deploy, including both native and cosmwasm contracts.
> - [./scripts.md](./scripts.md) up-to-date cli scripts for interacting with tokenfactory, natively and wasm smart-contract.
> - [./scripts_wallet.md](./scripts_wallet.md) (may be a little out of date wrt multi-denom) cli scripts for interacting with tokenfactory with wfdc2 wallet wallets and tmkms, natively and wasm smart-contract. 
> - [./scripts_aurum.md](./scripts_aurum.md) (may be a little out of date wrt multi-denom) cli scripts for interacting with aurum smart contracts.
> - [./scripts_wallet_aurum.md](./scripts_wallet_aurum.md) (may be a little out of date wrt multi-denom) cli scripts for interacting with aurum smart contracts with wfdc2 wallet wallets and tmkms.


## upstream
```bash
# todo: we should follow ciclefin/noble-fiattokenfactory instead of noble-assets/noble since the latter has removed x/tokenfactory.
git remote add upstream https://github.com/noble-assets/noble.git
git remote set-url --push upstream DISABLE
git remote -v
# should show something like this:
origin  https://github.com/wfblockchain/noblefork.git (fetch)
origin  https://github.com/wfblockchain/noblefork.git (push)
upstream        https://github.com/noble-assets/noble.git (fetch)
upstream        DISABLE (push)

# We can pull changes from the original repo like this:
git fetch upstream
# TBD: git rebase upstream/main
# resolve any conflicts
# Review the upsteam PRs and merge appropriately or manually update the code
```

## submodule
It may be made a submodule of [coreblock-chains](https://github.com/wfblockchain/coreblock-chains.git).  

## tools
> - gex is a neat tool for visualizing validator  
go install github.com/cosmos/gex@latest  
gex -p port