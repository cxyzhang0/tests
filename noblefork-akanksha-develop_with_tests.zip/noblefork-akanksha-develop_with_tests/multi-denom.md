# Developer notes
> Branch sean/multi-denom was originally created from main on 2024-3-26 as a POC to extend the original tokenfactory
> to support multiple minting denoms. It successfully demonstrates the feasibility.  
> 2025-03-05: sean/multi-denom-2 was created by merging sean/multi-denom into sean/working to continue the work to overcome all the limitations.  
> See scripts_multi_denom.md, play_multi_denom.sh and chains_multi_denom.env for details on how to build, run and test.  
> The current limitations are:
> - mintingDenomList is only defined in genesis (it should be a subset of denom_metadata). To be robust, we need to add tx to update both mintintDenomList and denom_metadata.
> - - ?: update denom-metadata: this needs governance proposal and vote.
> - - - tfd q auth module-account gov
> - - - tfd q gov params
> - - - tfd tx gov submit-proposal --title "update denom-metadata" --description "update denom-metadata" --type="tokenfactory/UpdateDenomMetadata" --from mintercontroller --module-account gov --module-name tokenfactory --denom-metadata <denom-metadata>
> - - - tfd tx gov vote <proposal-id> yes
> - - - conclusion: even with the governance proposal and vote process, we still need a tx to update denom-metadata.
> - - - so we work on the tx first. whether we need governance proposal and vote to run the tx is a separate issue.
> - - after denom-metadata is updated with the new denom, update mintingDenomList: this needs a tx to update mintingDenomList.
> - - or we combine SetDenomMetadata and UpdatingMintingDenomList into a single tx.
> - - - this is the approach implemented. we now have a new tx set-denom-metadata which takes medata string as the argument.
> - done except for wasm binding - The current datamodel for mintercontroller is such that one controller can only be paired to one minter at a time because the controller address is the primary key. We may need to make (controller, minter) the primary key.
> - done except for wasm binding - The current datamodel for minters only supports one denom per minter because minter address is the primary key. We may need to make (address, denom) the primary key.
> - fixed - Burn: minter for wfusd can burn wfdc. This should be disallowed.
> - Need to update wasm binding accordingly.

These are the files that were modified:
```shell
       modified:   Developer.md
        modified:   Makefile
        modified:   chains_multi_denom.env
        modified:   play_multi_denom.sh
        modified:   proto/tokenfactory/genesis.proto
        modified:   proto/tokenfactory/query.proto
        modified:   scripts_multi_denom.md
        modified:   x/blockibc/blockibc.go
        modified:   x/contracts/tokenfactory/bindings/query.go
        modified:   x/contracts/tokenfactory/queries.go
        modified:   x/contracts/tokenfactory/query_plugin.go
        modified:   x/tokenfactory/client/cli/query_minting_denom.go
        modified:   x/tokenfactory/client/cli/query_minting_denom_test.go
        modified:   x/tokenfactory/genesis.go
        modified:   x/tokenfactory/keeper/grpc_query_minting_denom.go
        modified:   x/tokenfactory/keeper/grpc_query_minting_denom_test.go
        modified:   x/tokenfactory/keeper/minting_denom.go
        modified:   x/tokenfactory/keeper/minting_denom_test.go
        modified:   x/tokenfactory/keeper/msg_server_burn.go
        modified:   x/tokenfactory/keeper/msg_server_configure_minter.go
        modified:   x/tokenfactory/keeper/msg_server_mint.go
        modified:   x/tokenfactory/module_simulation.go
        modified:   x/tokenfactory/types/genesis.go
        modified:   x/tokenfactory/types/genesis.pb.go
        modified:   x/tokenfactory/types/genesis_test.go
        modified:   x/tokenfactory/types/keys.go
        modified:   x/tokenfactory/types/query.pb.go
        modified:   x/tokenfactory/types/query.pb.gw.go
```
> Making tokenfactory support multiple minting denoms is necessary now because we are doing POC of WFDAMP which mints wrapped coins such as wbtc, beth, etc.  
> xEven though it is feadible to extend the tokenfactory to support multiple minting denominations, it is not necessarily urgent to focus on this at this moment because of other priorities.  
> xOur current tokenfactory chain as is is sufficient to production-support a single currency (USD) wfdc2 and the deposit token because we may have two modules: x/tokenfactory and x/fiat-tokenfactory.    
> xIf the production wfdc2 needs to exend to multi-currencies, we can revisit it. Remember we have been waiting for the WFDC production for many years and it is currently in no sight. 

