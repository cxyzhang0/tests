# Cosmwasm smart contracts

### contracts folder for multiple contracts

### packages folder for common crates used by contracts
