# Core smart contract for DiFi

* See [install.md](install.md) for how to deploy contract onto a running chain.
* See [demo.md](demo.md) for flow of cli queries used during demos and [Query Examples](demo.md#query) and/or [Execute Examples](demo.md#execute).

## Use Case
### Actors
* Minter (nft_minter) - single authority to mint NFTs
* Manufacturer (mf) - multiple. For example, Toyota, Honda, etc.
* Dealer (dealer) - multiple. For example, Concord Toyota, San Francisco Honda, etc.
* Financier (fin) - support multiple. most likely only one for POC, WFC
* Customer (customer) - multiple. For example, Alice, Bob, etc.

### Price Definitions
* SalesAgrmt has a `dealer_price` and a `fin_cost` for each nft token, and `total_dealer_price` and `total_fin_cost` for the whole sales agreement
  * `dealer_price` is the price financier pays manufacturer in lieu of dealer when nft is transferred from mf to fin.
  * `fin_cost` is the price the dealer pays the financier when customer buys the nft.
  * `total_dealer_cost` = sum of all `dealer_cost` on the sales agreement
  * `total_fin_cost` = sum of all `fin_cost` on the sales agreement
> In POC, mf or fin can reject a SalesAgrmt if they don't agree with the prices.

### Transactions (happy path)
* Minter mints NFTs 
    > nft token_id is of this humanly readable format - mf_addr:product:id  
    > owner = mf
* Dealer submits SalesAgrmt 
    > SalesAgrmt is a list nfts from a given mf, to be financed by a given financier.  
    > SalesAgrmt.status = Pending
* Manufacturer approves SalesAgrmt
    > SalesAgrmt.status = MfApproved
* Financier approves SalesAgrmt
    > fin pays escrow total_dealer_cost  
    > SalesAgrmt.status = FinApproved
* Manufacturer transfers all NFTs in SalesAgrmt to Financier
    > nft owner = fin for all nfts in agreement
    > escrow pays mf at total_dealer_price  
    > fin adds dealer as spender/approval so that dealer can transact the nft on behalf of fin  
    > SalesAgrmt.status = NftsTransferred
* Customer buys NFT from Dealer
    > customer pays escrow customer_price  
    > nft owner = customer  
    > escrow pays fin fin_cost  
    > escrow pays dealer (customer_price - fin_cost)  

### NFT Design Option 3: difi with integrated nft minter
* features
  * full cw721-metadata-onchain (cw721-mo) functionality inside difi
  * single contract
  * single integrated NFT store with a single dedicated (human) minter
  * individuals as NFT owners

## Developer Guidelines

### Attempt to ugrade to wasmd 0.40.2 and sdk 0.47.3 from (0.32.0, 0.45.15) 
* this branch is running wasmd 0.40.2 and sdk 0.47.3, and ignite 0.27.1

### How this package was created
Unfortunately, `cargo generate --git https://github.com/CosmWasm/cw-template.git --name PROJECT_NAME -d minimal=true` does not work. So, start the project from scratch.  
```
cd contracts
cargo new --lib ./difi-core-2
```

There are many functioning codes for state modeling, execute and query, and test. Even though there is still room to improve on them, they can serve as examples for developing a new feature. Every new execute or query in the new feature should be covered by unit tests.

```bash
cargo test # should all pass
```

If applicable, add a cli example in [Query Examples](demo.md#query) and/or [Execute Examples](demo.md#execute) sections to demonstrate how the new feature is used. Integration-test it out by building wasm, deploying code to chain and intantiating code as follows.

### Generate Contract Json Schema for frontend
Note: The generated ./schema/difi-core-2.json is to be used by cosmwasm-ts-codegen later.
```bash
cargo run schema 
```