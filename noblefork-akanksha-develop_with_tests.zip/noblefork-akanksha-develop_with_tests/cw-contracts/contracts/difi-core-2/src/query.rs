use cosmwasm_std::{entry_point, to_binary, Binary, Deps, Env, StdResult};

use crate::msg::{QueryMsg};
use crate::state::{Config, CONFIG, SALES_AGRMT};
use crate::df721_mo::{Df721MoContract, Df721QueryMsg, Df721MoQueryMsg, Df721Contract};

const DEFAULT_LIMIT: u32 = 10;
const MAX_LIMIT: u32 = 100;

#[cfg_attr(not(feature = "library"), entry_point)]
pub fn query (
    deps: Deps,
    env: Env,
    msg: QueryMsg,
) -> StdResult<Binary> {
    match msg {
        QueryMsg::Config {} => to_binary(&query::get_config(deps, env)?),
        QueryMsg::SalesAgrmt { id } => to_binary(&query::get_sales_agrmt(deps, env, id)?),
        QueryMsg::AllSalesAgrmts { start_after, limit } => to_binary(&query::get_all_sales_agrmts(deps, env, start_after, limit)?),
        QueryMsg::SalesAgrmtsByDealer {dealer, start_after, limit} => to_binary(&query::get_all_sales_agrmts_by_dealer(deps, env, dealer, start_after, limit)?),
        QueryMsg::SalesAgrmtsByMf {mf, start_after, limit} => to_binary(&query::get_all_sales_agrmts_by_mf(deps, env, mf, start_after, limit)?),
        QueryMsg::SalesAgrmtsByFin {fin, start_after, limit} => to_binary(&query::get_all_sales_agrmts_by_fin(deps, env, fin, start_after, limit)?),
        QueryMsg::AllNftsLocked { start_after, limit} => to_binary(&query::get_all_nfts_locked(deps, env, start_after, limit)?),
        QueryMsg::NftsLockedByAgrmtId { agrmt_id, start_after, limit} => to_binary(&query::get_nfts_locked_by_agrmt_id(deps, env, agrmt_id, start_after, limit)?),
        QueryMsg::CoinBalances { address } => to_binary(&query::get_coin_balances(deps, env, address)?),
        QueryMsg::NftInfoList { owner, start_after, limit } => to_binary(&query::get_nft_info_list(deps, env, owner, start_after, limit)?),
        // 721 queries
        QueryMsg::OwnerOf {token_id, include_expired} => Df721MoContract::default().query(deps, env, Df721MoQueryMsg::OwnerOf {token_id, include_expired}),
        QueryMsg::Approval {token_id, spender, include_expired} => Df721MoContract::default().query(deps, env, Df721MoQueryMsg::Approval {token_id, spender, include_expired}),
        QueryMsg::Approvals {token_id, include_expired} => Df721MoContract::default().query(deps, env, Df721MoQueryMsg::Approvals {token_id, include_expired}),
        // QueryMsg::Operator {owner, operator, include_expired} => Df721MoContract::default().query(deps, env, Df721QueryMsg::<Empty>::Operator {token_id, include_expired}),
        QueryMsg::AllOperators {owner, include_expired, start_after, limit} => Df721Contract::default().query(deps, env, Df721QueryMsg::AllOperators {owner, include_expired, start_after, limit}),
        QueryMsg::NumTokens {} => Df721Contract::default().query(deps, env, Df721QueryMsg::NumTokens {}),
        QueryMsg::ContractInfo {} => Df721Contract::default().query(deps, env, Df721QueryMsg::ContractInfo {}),
        QueryMsg::NftInfo {token_id} => Df721Contract::default().query(deps, env, Df721QueryMsg::NftInfo {token_id}),
        QueryMsg::AllNftInfo {token_id, include_expired} => Df721Contract::default().query(deps, env, Df721QueryMsg::AllNftInfo {token_id, include_expired}),
        QueryMsg::Tokens {owner, start_after, limit} => Df721Contract::default().query(deps, env, Df721QueryMsg::Tokens {owner, start_after, limit}),
        QueryMsg::AllTokens {start_after, limit} => Df721Contract::default().query(deps, env, Df721QueryMsg::AllTokens {start_after, limit}),
        QueryMsg::Minter {} => Df721Contract::default().query(deps, env, Df721QueryMsg::Minter {}),
        QueryMsg::Extension {msg: _} => Ok(Binary::default()) //Df721MoContract::default().query(deps, env, Df721MoQueryMsg::Extension{msg}),
    }
}

mod query {
    use cosmwasm_std::Order;
    use cw721::NftInfoResponse;
    use cw721_metadata_onchain::Extension;
    use cw_storage_plus::{Bound, PrimaryKey};
    use crate::df721_mo::Df721Contract;
    use crate::msg::{CoinBalanceResponse, CoinBalancesResponse, DifiNftInfoResponse, NftInfoListResponse, NftLockedResponse, NftsLockedResponse, SalesAgrmtResponse, SalesAgrmtsResponse};
    use crate::state::NFTS_LOCKED;
    use super::*;

    pub fn get_config(deps: Deps, _env: Env) -> StdResult<Config> {
        let config = CONFIG.load(deps.storage)?;

        Ok(config)
    }

    pub fn get_sales_agrmt(deps: Deps, _env: Env, id: u64) -> StdResult<SalesAgrmtResponse> {
        let agrmt = SALES_AGRMT().load(deps.storage, id)?;
        let resp = SalesAgrmtResponse {
            id,
            agrmt
        };
        Ok(resp)
    }

    pub fn get_all_sales_agrmts(deps: Deps, _env: Env, start_after: Option<u64>, limit: Option<u32>) -> StdResult<SalesAgrmtsResponse> {
        let limit = limit.unwrap_or(DEFAULT_LIMIT).min(MAX_LIMIT) as usize;
        let start = start_after.map(|u| Bound::ExclusiveRaw(u.joined_key()));
        let agrmts: StdResult<Vec<SalesAgrmtResponse>> = SALES_AGRMT()
            .range(deps.storage, start, None, Order::Ascending)
            .take(limit)
            .map(|item| item.map(|(k, agrmt)| SalesAgrmtResponse{ id: k, agrmt }))
            .collect();
        Ok(SalesAgrmtsResponse{ agrmts: agrmts? })
    }

    pub fn get_all_sales_agrmts_by_dealer(deps: Deps, _env: Env, dealer: String, start_after: Option<u64>, limit: Option<u32>) -> StdResult<SalesAgrmtsResponse> {
        let dealer = deps.api.addr_validate(&dealer)?;
        let limit = limit.unwrap_or(DEFAULT_LIMIT).min(MAX_LIMIT) as usize;
        let start = start_after.map(|u| Bound::ExclusiveRaw(u.joined_key()));
        let agrmts: StdResult<Vec<SalesAgrmtResponse>> = SALES_AGRMT()
            .idx
            .idealer
            .prefix(dealer)
            .range(deps.storage, start, None, Order::Ascending)
            .take(limit)
            .map(|item| item.map(|(k, agrmt)| SalesAgrmtResponse{ id: k, agrmt }))
            .collect();
        Ok(SalesAgrmtsResponse{ agrmts: agrmts? })
    }

    pub fn get_all_sales_agrmts_by_mf(deps: Deps, _env: Env, mf: String, start_after: Option<u64>, limit: Option<u32>) -> StdResult<SalesAgrmtsResponse> {
        let mf = deps.api.addr_validate(&mf)?;
        let limit = limit.unwrap_or(DEFAULT_LIMIT).min(MAX_LIMIT) as usize;
        let start = start_after.map(|u| Bound::ExclusiveRaw(u.joined_key()));
        let agrmts: StdResult<Vec<SalesAgrmtResponse>> = SALES_AGRMT()
            .idx
            .imf
            .prefix(mf)
            .range(deps.storage, start, None, Order::Ascending)
            .take(limit)
            .map(|item| item.map(|(k, agrmt)| SalesAgrmtResponse{ id: k, agrmt }))
            .collect();
        Ok(SalesAgrmtsResponse{ agrmts: agrmts? })
    }

    pub fn get_all_sales_agrmts_by_fin(deps: Deps, _env: Env, fin: String, start_after: Option<u64>, limit: Option<u32>) -> StdResult<SalesAgrmtsResponse> {
        let fin = deps.api.addr_validate(&fin)?;
        let limit = limit.unwrap_or(DEFAULT_LIMIT).min(MAX_LIMIT) as usize;
        let start = start_after.map(|u| Bound::ExclusiveRaw(u.joined_key()));
        let agrmts: StdResult<Vec<SalesAgrmtResponse>> = SALES_AGRMT()
            .idx
            .ifin
            .prefix(fin)
            .range(deps.storage, start, None, Order::Ascending)
            .take(limit)
            .map(|item| item.map(|(k, agrmt)| SalesAgrmtResponse{ id: k, agrmt }))
            .collect();
        Ok(SalesAgrmtsResponse{ agrmts: agrmts? })
    }

    pub fn get_all_nfts_locked(deps: Deps, _env: Env, start_after: Option<String>, limit: Option<u32>) -> StdResult<NftsLockedResponse> {
        let limit = limit.unwrap_or(DEFAULT_LIMIT).min(MAX_LIMIT) as usize;
        let start = start_after.map(|t| Bound::ExclusiveRaw(t.into()));
        let resps: StdResult<Vec<NftLockedResponse>> = NFTS_LOCKED()
            .range(deps.storage, start, None, Order::Ascending)
            .take(limit)
            .map(|item| item.map(|(k, agrmt_id)| NftLockedResponse{ token_id: k, agrmt_id }))
            .collect();
        Ok(NftsLockedResponse{ nfts: resps? })
    }

    pub fn get_nfts_locked_by_agrmt_id(deps: Deps, _env: Env, agrmt_id: u64, start_after: Option<String>, limit: Option<u32>) -> StdResult<NftsLockedResponse> {
        let limit = limit.unwrap_or(DEFAULT_LIMIT).min(MAX_LIMIT) as usize;
        let start = start_after.map(|t| Bound::ExclusiveRaw(t.into()));
        let resps: StdResult<Vec<NftLockedResponse>> = NFTS_LOCKED()
            .idx
            .iagrmt_id
            .prefix(agrmt_id)
            .range(deps.storage, start, None, Order::Ascending)
            .take(limit)
            .map(|item| item.map(|(k, agrmt_id)| NftLockedResponse{ token_id: k, agrmt_id }))
            .collect();
        Ok(NftsLockedResponse{ nfts: resps? })
    }

    pub fn get_coin_balances(deps: Deps, _env: Env, address: String) -> StdResult<CoinBalancesResponse> {
        let address = deps.api.addr_validate(&address)?;
        let balances = deps.querier.query_all_balances(&address)?;

        let balances = balances.into_iter().map(|coin| CoinBalanceResponse {
            denom: coin.clone().denom,
            amount: coin.clone().amount.to_string(),
        }).collect();

        Ok(CoinBalancesResponse { balances })
    }

    pub fn get_nft_info_list(deps: Deps, _env: Env, owner: String, start_after: Option<String>, limit: Option<u32>) -> StdResult<NftInfoListResponse<Extension>> {
        let owner = deps.api.addr_validate(&owner)?;
        let limit = limit.unwrap_or(DEFAULT_LIMIT).min(MAX_LIMIT) as usize;
        let start = start_after.map(|s| Bound::ExclusiveRaw(s.into()));
        let cw721 = Df721Contract::default();

        let resp: StdResult<Vec<DifiNftInfoResponse<Extension>>> = cw721
            .tokens
            .idx
            .owner
            .prefix(owner)
            .range(deps.storage, start, None, Order::Ascending)
            .take(limit)
            .map(|item| item.map(|(k, nft)| DifiNftInfoResponse{
                token_id: k,
                info: NftInfoResponse {
                    token_uri: nft.token_uri,
                    extension: nft.extension,
                },
            }))
            .collect();

        Ok(NftInfoListResponse{ info_list: resp? })
    }
}