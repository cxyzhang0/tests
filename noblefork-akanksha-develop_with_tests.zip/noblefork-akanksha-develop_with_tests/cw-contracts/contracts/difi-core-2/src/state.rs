use std::clone::Clone;
use std::fmt;
use cosmwasm_std::{Addr, StdResult, Storage};
use cw_storage_plus::{Index, IndexedMap, IndexList, Item, Map, MultiIndex};
use cosmwasm_schema::{cw_serde};

// Config is defined at contract instantiation
pub const CONFIG: Item<Config> = Item::new("config");

// cannot use const because non-const fun in iwho.
// pub const SALES_AGRMT: IndexedMap<u64, SalesAgrmt, SAIndexes> = IndexedMap::new("sales_agrmt", SAIndexes {
//     iwho: MultiIndex::new(
//         |_pk: &[u8], d: &SalesAgrmt| d.who.clone(),
//         "sales_agrmt",
//         "sales_agrmt_who"
//     ),
// });

pub fn SALES_AGRMT<'a>() -> IndexedMap<'a, u64, SalesAgrmt, SAIndexes<'a>> {
    let indexes = SAIndexes {
        // itriple: MultiIndex::new(
        //     |_pk: &[u8], d: &SalesAgrmt| (d.dealer.clone(), d.mf.clone(), d.fin.clone()),
        //     // |_pk: &[u8], d: &SalesAgrmt| d.who.clone(),
        //     "sales_agrmt",
        //     "sales_agrmt_triple"
        // ),
        idealer: MultiIndex::new(
            |_pk: &[u8], d: &SalesAgrmt| d.dealer.clone(),
            "sales_agrmt",
            "sales_agrmt_dealer"
        ),
        imf: MultiIndex::new(
            |_pk: &[u8], d: &SalesAgrmt| d.mf.clone(),
            "sales_agrmt",
            "sales_agrmt_mf"
        ),
        ifin: MultiIndex::new(
            |_pk: &[u8], d: &SalesAgrmt| d.fin.clone(),
            "sales_agrmt",
            "sales_agrmt_fin"
        ),
    };
    IndexedMap::new("sales_agrmt", indexes)
}

// token_id -> sales_agrmt_id
// a nft is locked when it is in a SalesAgrmt being submitted.
// it is released when the SalesAgrmt is rejected or canceled.
// it is also released when a customer buys it so that its owner is transferred from fin to customer.
pub const _NFTS_LOCKED_OLD: Map<&str, u64> = Map::new("nfts_locked");
pub fn NFTS_LOCKED<'a>() -> IndexedMap<'a, &'a str, u64, NLIndexes<'a>> {
    let indexes = NLIndexes {
        iagrmt_id: MultiIndex::new(
            |_pk: &[u8], d: &u64| d.clone(),
            "nfts_locked",
            "nfts_locked_agrmt_id"
        ),
    };
    IndexedMap::new("nfts_locked", indexes)
}


// SalesAgrmt
#[cw_serde]
pub struct SalesAgrmt {
    // dealer, mf, fin - secondary index
    // pub who: (Addr, Addr, Addr),
    pub dealer: Addr,
    pub mf: Addr,
    pub fin: Addr, // WFC
    pub total_dealer_price: u128,
    pub total_fin_cost: u128,
    pub status: SalesAgrmtStatus,
    pub items: Vec<SalesAgrmtItem>,
}

pub struct SAIndexes<'a> {
 // pub itriple: MultiIndex<'a, (Addr, Addr, Addr), SalesAgrmt, u64>,
 pub idealer: MultiIndex<'a, Addr, SalesAgrmt, u64>,
 pub imf: MultiIndex<'a, Addr, SalesAgrmt, u64>,
 pub ifin: MultiIndex<'a, Addr, SalesAgrmt, u64>,
}

impl<'a> IndexList<SalesAgrmt> for SAIndexes<'a> {
    fn get_indexes(&'_ self) -> Box<dyn Iterator<Item=&'_ dyn Index<SalesAgrmt>> + '_> {
        let v: Vec<&dyn Index<SalesAgrmt>> = vec![/*&self.itriple,*/ &self.idealer, &self.imf, &self.ifin];
        Box::new(v.into_iter())
    }
}

pub struct NLIndexes<'a> {
    pub iagrmt_id: MultiIndex<'a, u64, u64, &'a str>,
}

impl<'a> IndexList<u64> for NLIndexes<'a> {
    fn get_indexes(&'_ self) -> Box<dyn Iterator<Item=&'_ dyn Index<u64>> + '_> {
        let v: Vec<&dyn Index<u64>> = vec![&self.iagrmt_id];
        Box::new(v.into_iter())
    }
}

#[cw_serde]
pub struct SalesAgrmtItem {
    pub nft_token_id: String,
    pub dealer_price: u64,
    pub fin_cost: u64,
}

#[cw_serde]
pub enum SalesAgrmtStatus {
    // upon dealer submission
    Pending,
    // upon mf approval, require prior status = Pending
    MfApproved,
    // upon financier approval, require prior status = MfApproved
    FinApproved,
    // mf transfers all NFTs to fin in a single tx
    NftsTransferred,
    // upon mf rejection, require prior status = Pending
    MfRejected,
    // upon financier rejection, require prior status = Pending or MfApproved
    FinRejected,
    // upon dealer cancellation, require prior status = Pending
    Canceled,
    // upon all nfts have been sold to customers
    // Completed,
}

impl fmt::Display for SalesAgrmtStatus {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        match self {
            SalesAgrmtStatus::Pending => write!(f, "Pending"),
            SalesAgrmtStatus::MfApproved => write!(f, "MfApproved"),
            SalesAgrmtStatus::FinApproved => write!(f, "FinApproved"),
            SalesAgrmtStatus::NftsTransferred => write!(f, "NftsTransferred"),
            SalesAgrmtStatus::MfRejected => write!(f, "MfRejected"),
            SalesAgrmtStatus::FinRejected => write!(f, "FinRejected"),
            SalesAgrmtStatus::Canceled => write!(f, "Canceled"),
            // SalesAgrmtStatus::Completed => write!(f, "Completed"),
        }
    }
}
#[cw_serde]
pub struct Config {
    /*
     owner of this contract = address that creates it
     this owner may be different from cw2 owner set by Cw721 which is the minter.
     */
    pub owner: Addr,

    // nft_minter
    pub nft_minter: Addr,

    // code_id of pre-stored cw721-metadata-onchain
    // pub nft_code_id: u64,

    // currency used for payments uwfusd
    pub denom: String,

    // next id of sales_agrmt
    pub sales_agrmt_id: u64,
}

pub fn increment_sales_agrmt_id(store: &mut dyn Storage) -> StdResult<u64> {
/*
    let mut config = CONFIG.load(store)?;

    config.sales_agrmt_id += 1;
    CONFIG.save(store, &config);
    Ok(config.sales_agrmt_id)
*/
    CONFIG.update(store, |mut c| -> StdResult<_> {
        c.sales_agrmt_id += 1;
        Ok(c)
    })?;

    Ok(CONFIG.load(store)?.sales_agrmt_id)
}

#[cw_serde]
pub struct ManufacturerInfo {
    pub name: String,
    pub category: String,
}

#[cw_serde]
pub struct DealerInfo {
    pub name: String,

}

#[cw_serde]
pub struct FinancierInfo {
    pub name: String,
}
