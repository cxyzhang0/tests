use cosmwasm_std::{ entry_point, DepsMut, Env, MessageInfo, Response, StdResult};
use cw2::{set_contract_version};
use cw721_metadata_onchain::{Extension};
use cw721_base::state::{Approval};
// use cw_utils::parse_reply_instantiate_data;

use crate::msg::{ExecuteMsg, InstantiateMsg};
use crate::state::{Config, CONFIG, SALES_AGRMT, increment_sales_agrmt_id};
use crate::error::ContractError;
use crate::df721_mo::{Df721Contract, Df721MoContract, Df721InstantiateMsg};

// version info for migration info
pub const CONTRACT_NAME: &str = "crates.io:difi-core";
pub const CONTRACT_VERSION: &str = env!("CARGO_PKG_VERSION");

#[cfg_attr(not(feature = "library"), entry_point)]
pub fn instantiate(
    mut deps: DepsMut,
    env: Env,
    info: MessageInfo,
    msg: InstantiateMsg,
) -> StdResult<Response> {
    // initialize the embedded NFT minter
    // fixed name and symbol because they should have no visibility.
    // NOTE: Df721Contract instantiate set nft_minter as the cw2 owner.
    let cw721_inst_msg = Df721InstantiateMsg {
        name: CONTRACT_NAME.to_string(),
        symbol: CONTRACT_NAME.to_string(),
        minter: msg.nft_minter.clone(),
    };
    Df721Contract::default().instantiate(deps.branch(), env, info.to_owned(), cw721_inst_msg)?;

    // set version after D
    set_contract_version(deps.storage, CONTRACT_NAME, CONTRACT_VERSION)?;

    let config = Config {
        owner: info.sender,
        nft_minter: deps.api.addr_validate(&msg.nft_minter)?,
        denom: msg.denom,
        sales_agrmt_id: 0
    };

    CONFIG.save(deps.storage, &config)?;

    Ok(Response::new()
        .add_attribute("action", "instantiate")
        .add_attribute("denom", config.denom)
        .add_attribute("nft_minter", config.nft_minter)
    )
}

#[cfg_attr(not(feature = "library"), entry_point)]
pub fn execute(
    deps: DepsMut,
    env: Env,
    info: MessageInfo,
    msg: ExecuteMsg,
) -> Result<Response, ContractError> {
    // Df721MoContract::default().
    match msg {
        ExecuteMsg::MintNft { mf, product, unique_id, token_uri, extension} => exec::mint_nft(deps, env, info, mf, product, unique_id, token_uri, extension),
        ExecuteMsg::TransferNft { token_id, recipient} => exec::transfer_nft(deps, env, info, token_id, recipient),
        ExecuteMsg::TransferNftByNftTokenId { mf, product, unique_id, recipient} => exec::transfer_nft_by_nft_token_id(deps, env, info, mf, product, unique_id, recipient),
        ExecuteMsg::SubmitSalesAgrmt {dealer, mf, fin, items} => exec::submit_sales_agrmt(deps, env, info, dealer, mf, fin, items),
        ExecuteMsg::MfApproveSalesAgrmt { agrmt_id } => exec::mf_approve_agrmt(deps, env, info, agrmt_id),
        ExecuteMsg::FinApproveSalesAgrmt { agrmt_id } => exec::fin_approve_agrmt(deps, env, info, agrmt_id),
        ExecuteMsg::MfTransferNfts { agrmt_id } => exec::mf_transfer_nfts(deps, env, info, agrmt_id),
        ExecuteMsg::CustomerBuyNft { token_id } => exec::customer_buy_nft(deps, env, info, token_id),
        ExecuteMsg::CancelSalesAgrmt { agrmt_id } => exec::cancel_agrmt(deps, env, info, agrmt_id),
        ExecuteMsg::MfRejectSalesAgrmt { agrmt_id } => exec::mf_reject_agrmt(deps, env, info, agrmt_id),
        ExecuteMsg::FinRejectSalesAgrmt { agrmt_id } => exec::fin_reject_agrmt(deps, env, info, agrmt_id),
        ExecuteMsg::SendCoin { recipient } => exec::send_coin(deps, env, info, recipient),
        
        ExecuteMsg::Cw721(df721_execute_msg) => Df721Contract::default().execute(deps, env, info, df721_execute_msg).map_err(Into::into),
    }
}

mod exec {
    use cosmwasm_std::{BankMsg, coins};
    use cw721_base::state::TokenInfo;
    use crate::df721_mo::{Df721ExecuteMsg, NftTokenId};
    use crate::state::{NFTS_LOCKED, SalesAgrmt, SalesAgrmtItem, SalesAgrmtStatus};
    use super::*;

    pub fn mint_nft(deps: DepsMut, env: Env, info: MessageInfo, mf: String, product: String, unique_id: String, token_uri: Option<String>, extension: Extension) -> Result<Response, ContractError> {
        let token_id = NftTokenId {
            mf: &mf,
            product: &product,
            unique_id: &unique_id,
        }.token_id();

        // valid expression - it must have attribute key "dealer_price"
        // not here any more: dealer_price is moved to SalesAgrmtItem
        // get_dealer_price(&extension)?;

        // This is a test of direct access to tokens state. It works.
        /*
        let nft: TokenInfo<Extension> = TokenInfo {
            owner: deps.api.addr_validate(&mf)?,
            approvals: vec![],
            token_uri: token_uri.clone(),
            extension: extension.clone(),
        };

        Df721MoContract::default().tokens.save(deps.storage, &token_id, &nft)?;
        Df721MoContract::default().increment_tokens(deps.storage)?;
        Ok(Response::new())
        */

        let mint_msg = Df721ExecuteMsg::Mint {
            token_id,
            owner: mf, // mint to the manufacturer as owner
            token_uri,
            extension,
            // the following is for cw-nfts v0.15.0
            // 0: MintMsg {
            //     token_id,
            //     owner: mf, // mint to the manufacturer as owner //info.sender.to_string(),
            //     token_uri,
            //     extension
            // },

        };

        Df721Contract::default().execute(deps, env, info, mint_msg).map_err(Into::into)
    }

    pub fn transfer_nft(deps: DepsMut, env: Env, info: MessageInfo, token_id: String, recipient: String) -> Result<Response, ContractError> {
        let transfer_msg = Df721ExecuteMsg::TransferNft {
            token_id,
            recipient,
        };

        Df721Contract::default().execute(deps, env, info, transfer_msg).map_err(Into::into)
    }

    pub fn transfer_nft_by_nft_token_id(deps: DepsMut, env: Env, info: MessageInfo, mf: String, product: String, unique_id: String, recipient: String) -> Result<Response, ContractError> {
        let token_id = NftTokenId {
            mf: &mf,
            product: &product,
            unique_id: &unique_id,
        }.token_id();
        let transfer_msg = Df721ExecuteMsg::TransferNft {
            token_id,
            recipient,
        };

        Df721Contract::default().execute(deps, env, info, transfer_msg).map_err(Into::into)
    }

    /*
    Dealer submits a sales agreement on chain.
    items must not be empty; nft owner must be mf; nft must be not locked.
    status = Pending
     */
    pub fn submit_sales_agrmt(deps: DepsMut, _env: Env, info: MessageInfo, dealer: String, mf: String, fin: String, items: Vec<SalesAgrmtItem>) -> Result<Response, ContractError> {
        let dealer = deps.api.addr_validate(&dealer)?;
        if dealer != info.sender {
            return Err(ContractError::Unauthorized { sender: info.sender })
        }
        let mf = deps.api.addr_validate(&mf)?;
        let fin = deps.api.addr_validate(&fin)?;
        let mut total_dealer_price: u128 = 0;
        let mut total_fin_cost: u128 = 0;

        let id = increment_sales_agrmt_id(deps.storage)?;

        // items must not be empty
        if items.is_empty() {
            return Err(ContractError::SalesAgrmtEmptyItems {})
        }
        let cw721 = Df721Contract::default();
        for item in &items {
            let token_id: &str = item.nft_token_id.as_str();
            // check owner
            let nft: TokenInfo<Extension> = cw721.tokens.load(deps.storage, token_id)?;
            // let nft: TokenInfo<Extension> = Df721Contract::default().tokens.load(deps.storage, token_id)?;
            if nft.owner != mf {
                return Err(ContractError::WrongOwner { expected: mf, got: nft.owner } )
            }
            // check locked status
            if NFTS_LOCKED().has(deps.storage, token_id) {
                return Err(ContractError::NftLocked { token_id: token_id.to_string()})
            }
            // add to NFTS_LOCKED
            NFTS_LOCKED().save(deps.storage, token_id, &id)?;

            total_dealer_price += item.dealer_price as u128;
            total_fin_cost += item.fin_cost as u128;
        }
        let agrmt = SalesAgrmt {
            // who: (dealer.to_owned(), mf.to_owned(), fin.to_owned()),
            dealer: dealer.to_owned(),
            mf: mf.to_owned(),
            fin: fin.to_owned(),
            total_dealer_price,
            total_fin_cost,
            status: SalesAgrmtStatus::Pending,
            items,
        };

        SALES_AGRMT().save(deps.storage, id, &agrmt)?;

        Ok(Response::new()
            .add_attribute("action", "submit_sales_agrmt")
            .add_attribute("sales_agrmt_id", id.to_string())
            .add_attribute("dealer", dealer.to_string())
            .add_attribute("mf", mf.to_string())
            .add_attribute("fin", fin.to_string())
            .add_attribute("total_dealer_price", total_dealer_price.to_string())
            .add_attribute("total_fin_cost", total_fin_cost.to_string())
        )
    }

    /*
    mf approves sales agreement from dealer.
    We need mf's approval because dealer_price is of interest to mf since that is the price mf will get paid for
        once mf transfers nft to fin.
    status = MfApproved
     */
    pub fn mf_approve_agrmt(deps: DepsMut, _env: Env, info: MessageInfo, agrmt_id: u64) -> Result<Response, ContractError> {
        let agrmt = SALES_AGRMT().may_load(deps.storage, agrmt_id)?;
        if agrmt.is_none() {
            return Err(ContractError::SalesAgrmtNotExist { id: agrmt_id })
        }
        let mut agrmt = agrmt.unwrap();

        // validate mf against sender
        if info.sender != agrmt.mf {
            return Err(ContractError::Unauthorized { sender: info.sender})
        }

        // validate status
        if agrmt.status != SalesAgrmtStatus::Pending {
            return Err(ContractError::InvalidStatus { expected: SalesAgrmtStatus::Pending.to_string(), got: agrmt.status.to_string() })
        }

        agrmt.status = SalesAgrmtStatus::MfApproved;

        SALES_AGRMT().save(deps.storage, agrmt_id, &agrmt)?;

        Ok(Response::new()
            .add_attribute("action", "mf_approve_agrmt")
            .add_attribute("mf", info.sender.to_string())
            .add_attribute("sales_agrmt_id", agrmt_id.to_string())
        )
    }

    /*
    fin approves sales agreement previously approved by mf
    validate payment against sales contract's total_dealer_price.
    payment stays on escrow.
    status = FinApproved
     */
    pub fn fin_approve_agrmt(deps: DepsMut, _env: Env, info: MessageInfo, agrmt_id: u64) -> Result<Response, ContractError> {
        let agrmt = SALES_AGRMT().may_load(deps.storage, agrmt_id)?;
        if agrmt.is_none() {
            return Err(ContractError::SalesAgrmtNotExist { id: agrmt_id })
        }
        let mut agrmt = agrmt.unwrap();

        // validate fin against sender
        if info.sender != agrmt.fin {
            return Err(ContractError::Unauthorized { sender: info.sender})
        }

        // validate status
        if agrmt.status != SalesAgrmtStatus::MfApproved {
            return Err(ContractError::InvalidStatus { expected: SalesAgrmtStatus::MfApproved.to_string(), got: agrmt.status.to_string() })
        }

        // validate payment
        let config = CONFIG.load(deps.storage)?;
        let pmt_amount = cw_utils::may_pay(&info, &config.denom)?.u128();
        if pmt_amount != agrmt.total_dealer_price {
            return Err(ContractError::IncorrectAmount { expected: agrmt.total_dealer_price, got: pmt_amount })
        }

        // let pmt = Coin::new(pmt_amount, config.denom.to_owned());

        agrmt.status = SalesAgrmtStatus::FinApproved;

        SALES_AGRMT().save(deps.storage, agrmt_id, &agrmt)?;

        Ok(Response::new()
            .add_attribute("action", "fin_approve_agrmt")
            .add_attribute("fin", info.sender.to_string())
            .add_attribute("sales_agrmt_id", agrmt_id.to_string())
        )
    }

    /*
    mf transfers all NFTs to fin and set dealer as spender
    no need to validate owner because cw721 requires tx sender is the current NFT owner
    //unlock the token to save space - it is safe because fin-owned NFT cannot be in a future SalesAgrmt
    pay mf from escrow.
    status = NftsTranferred
    */
    pub fn mf_transfer_nfts(deps: DepsMut, env: Env, info: MessageInfo, agrmt_id: u64) -> Result<Response, ContractError> {
        let agrmt = SALES_AGRMT().may_load(deps.storage, agrmt_id)?;
        if agrmt.is_none() {
            return Err(ContractError::SalesAgrmtNotExist { id: agrmt_id })
        }
        let mut agrmt = agrmt.unwrap();

        // validate mf against sender
        if info.sender != agrmt.mf {
            return Err(ContractError::Unauthorized { sender: info.sender})
        }

        // validate status
        if agrmt.status != SalesAgrmtStatus::FinApproved {
            return Err(ContractError::InvalidStatus { expected: SalesAgrmtStatus::FinApproved.to_string(), got: agrmt.status.to_string() })
        }

        let cw721 = Df721Contract::default();
        // transfer and unlock every NFT
        for item in &agrmt.items {
            // transfer: Df721MoContract::default().execute moves deps so no good.
            // let transfer_msg = Df721MoExecuteMsg::TransferNft {
            //     recipient: agrmt.fin.to_string(),
            //     token_id: item.nft_token_id.clone(),
            // };
            // Df721MoContract::default().execute(deps, env.clone(), info.clone(), transfer_msg);

            let mut token = cw721.tokens.load(deps.storage, item.nft_token_id.as_str())?;
            // ensure we have permissions
            cw721.check_can_send(deps.as_ref(), &env, &info, &token)?;
            // set owner and spender as dealer
            token.owner = agrmt.fin.to_owned();
            token.approvals = vec![Approval {
                spender: agrmt.dealer.to_owned(),
                expires: Default::default(),  // never expires.
                },
            ];
            cw721.tokens.save(deps.storage, item.nft_token_id.as_str(), &token)?;
            // unlock: not here. need the lock for customer buying NFT so we know which SalesAgrmt
            //NFTS_LOCKED().remove(deps.storage, item.nft_token_id.as_str())?;
        }

        // pays mf from escrow
        let config = CONFIG.load(deps.storage)?;
        let payment_msg = BankMsg::Send {
            to_address: agrmt.mf.to_string(),
            amount: coins(agrmt.total_dealer_price, config.denom),
        };

        agrmt.status = SalesAgrmtStatus::NftsTransferred;

        SALES_AGRMT().save(deps.storage, agrmt_id, &agrmt)?;

        Ok(Response::new()
            .add_message(payment_msg)
            .add_attribute("action", "mf_transfer_nfts")
            .add_attribute("sales_agrmt_id", agrmt_id.to_string())
        )
    }

    /*
    customer buys an nft at a price of customer_price
    get the corresponding SalesAgrmt
    pays fin fin_cost
    pays dealer customer_price - fin_cost
    owner of nft = customer
    unlock nft
     */
    pub fn customer_buy_nft(deps: DepsMut, _env: Env, info: MessageInfo, token_id: String) -> Result<Response, ContractError> {
        let config = CONFIG.load(deps.storage)?;

        // get SalesAgrmt
        let agrmt_id = NFTS_LOCKED().load(deps.storage, &token_id)?;
        let agrmt = SALES_AGRMT().load(deps.storage, agrmt_id)?;

        // status must be NftsTransferred
        if agrmt.status != SalesAgrmtStatus::NftsTransferred {
            return Err(ContractError::InvalidStatus { expected: SalesAgrmtStatus::NftsTransferred.to_string(), got: agrmt.status.to_string() })
        }

        // validate current nft ownership
        let cw721 = Df721MoContract::default();
        let mut token = cw721.tokens.load(deps.storage, token_id.as_str())?;
        if token.owner != agrmt.fin {
            return Err(ContractError::WrongOwner {expected: agrmt.fin, got: token.owner})
        }

        // validate payment
        let customer_price = cw_utils::may_pay(&info, &config.denom)?.u128();
        let mut fin_cost: u64 = u64::MAX;
        for item in &agrmt.items {
            if item.nft_token_id == token_id {
                fin_cost = item.fin_cost;
            }
        }
        if fin_cost == u64::MAX {
            return Err(ContractError::KeyNotFound { key: token_id })
        }
        if customer_price < (fin_cost as u128) {
            return Err(ContractError::InsufficientAmount {})
        }

        // set owner and empty spender
        token.owner = info.sender.to_owned();
        token.approvals = vec![];
        cw721.tokens.save(deps.storage, token_id.as_str(), &token)?;

        // payments
        let payment_to_fin_msg = BankMsg::Send {
            to_address: agrmt.fin.to_string(),
            amount: coins(fin_cost as u128, config.denom.to_owned()),
        };
        let payment_to_dealer_msg = BankMsg::Send {
            to_address: agrmt.dealer.to_string(),
            amount: coins(customer_price - fin_cost as u128, config.denom),
        };

        // unlock
        NFTS_LOCKED().remove(deps.storage, token_id.as_str())?;

        Ok(Response::new()
            .add_messages(vec![payment_to_fin_msg, payment_to_dealer_msg])
            .add_attribute("action", "customer_buy_nft")
            .add_attribute("customer", info.sender.to_string())
            .add_attribute("customer_price", customer_price.to_string())
        )
    }

    /*
    dealer cancel sales agreement.
    release the locked nfts on this agrmt.
    status = Canceled
     */
    pub fn cancel_agrmt(deps: DepsMut, _env: Env, info: MessageInfo, agrmt_id: u64) -> Result<Response, ContractError> {
        let agrmt = SALES_AGRMT().may_load(deps.storage, agrmt_id)?;
        if agrmt.is_none() {
            return Err(ContractError::SalesAgrmtNotExist { id: agrmt_id })
        }
        let mut agrmt = agrmt.unwrap();

        // validate dealer against sender
        if info.sender != agrmt.dealer {
            return Err(ContractError::Unauthorized { sender: info.sender})
        }

        // validate status
        if agrmt.status != SalesAgrmtStatus::Pending {
            return Err(ContractError::InvalidStatus { expected: SalesAgrmtStatus::Pending.to_string(), got: agrmt.status.to_string() })
        }

        // release locked nfts
        for item in &agrmt.items {
            NFTS_LOCKED().remove(deps.storage, &item.nft_token_id)?;
        }

        agrmt.status = SalesAgrmtStatus::Canceled;

        SALES_AGRMT().save(deps.storage, agrmt_id, &agrmt)?;

        Ok(Response::new()
            .add_attribute("action", "cancel_agrmt")
            .add_attribute("dealer", info.sender.to_string())
            .add_attribute("sales_agrmt_id", agrmt_id.to_string())
        )
    }

    /*
    mf rejects sales agreement.
    release the locked nfts on this agrmt.
    status = MfRejected
     */
    pub fn mf_reject_agrmt(deps: DepsMut, _env: Env, info: MessageInfo, agrmt_id: u64) -> Result<Response, ContractError> {
        let agrmt = SALES_AGRMT().may_load(deps.storage, agrmt_id)?;
        if agrmt.is_none() {
            return Err(ContractError::SalesAgrmtNotExist { id: agrmt_id })
        }
        let mut agrmt = agrmt.unwrap();

        // validate dealer against sender
        if info.sender != agrmt.mf {
            return Err(ContractError::Unauthorized { sender: info.sender})
        }

        // validate status
        if agrmt.status != SalesAgrmtStatus::Pending {
            return Err(ContractError::InvalidStatus { expected: SalesAgrmtStatus::Pending.to_string(), got: agrmt.status.to_string() })
        }

        // release locked nfts
        for item in &agrmt.items {
            NFTS_LOCKED().remove(deps.storage, &item.nft_token_id)?;
        }

        agrmt.status = SalesAgrmtStatus::MfRejected;

        SALES_AGRMT().save(deps.storage, agrmt_id, &agrmt)?;

        Ok(Response::new()
            .add_attribute("action", "mf_reject_agrmt")
            .add_attribute("mf", info.sender.to_string())
            .add_attribute("sales_agrmt_id", agrmt_id.to_string())
        )
    }

    /*
    fin rejects sales agreement.
    release the locked nfts on this agrmt.
    status = FinRejected
     */
    pub fn fin_reject_agrmt(deps: DepsMut, _env: Env, info: MessageInfo, agrmt_id: u64) -> Result<Response, ContractError> {
        let agrmt = SALES_AGRMT().may_load(deps.storage, agrmt_id)?;
        if agrmt.is_none() {
            return Err(ContractError::SalesAgrmtNotExist { id: agrmt_id })
        }
        let mut agrmt = agrmt.unwrap();

        // validate dealer against sender
        if info.sender != agrmt.fin {
            return Err(ContractError::Unauthorized { sender: info.sender})
        }

        // validate status
        if !(agrmt.status != SalesAgrmtStatus::Pending || agrmt.status != SalesAgrmtStatus::MfApproved) {
            return Err(ContractError::InvalidStatus { expected: SalesAgrmtStatus::Pending.to_string(), got: agrmt.status.to_string() })
        }

        // release locked nfts
        for item in &agrmt.items {
            NFTS_LOCKED().remove(deps.storage, &item.nft_token_id)?;
        }

        agrmt.status = SalesAgrmtStatus::FinRejected;

        SALES_AGRMT().save(deps.storage, agrmt_id, &agrmt)?;

        Ok(Response::new()
            .add_attribute("action", "fin_reject_agrmt")
            .add_attribute("fin", info.sender.to_string())
            .add_attribute("sales_agrmt_id", agrmt_id.to_string())
        )
    }

    /*
    This is the smart contract version of send tx.
    coin can be any denom.
     */
    pub fn send_coin(deps: DepsMut, _env: Env, info: MessageInfo, recipient: String) -> Result<Response, ContractError> {
        let recipient = deps.api.addr_validate(&recipient)?;
        let coin = cw_utils::one_coin(&info)?;

        let payment_msg = BankMsg::Send {
            to_address: recipient.to_string(),
            amount: vec![coin.clone()],
        };
        
        Ok(Response::new()
            .add_message(payment_msg)
            .add_attribute("action", "send_coin")
            .add_attribute("sender", info.sender.to_string())
            .add_attribute("recipient", recipient.to_string())
            .add_attribute("coin", coin.to_string())
        )
    }
}
