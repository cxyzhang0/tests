use cosmwasm_std::{attr, Addr, from_binary, StdResult, coins, Coin};
use cosmwasm_std::testing::{mock_dependencies, mock_info, mock_env};
use cw2::ContractVersion;
use cw721::ApprovalsResponse;
use cw721::Approval;
use cw_multi_test::{App, BasicApp, ContractWrapper, Executor};
use cw721_metadata_onchain::{Extension, Metadata, Trait};
use crate::execute::{execute, instantiate, CONTRACT_VERSION, CONTRACT_NAME};
use crate::query::{query};
use crate::error::ContractError;
use crate::msg::{CoinBalanceResponse, CoinBalancesResponse, DifiNftInfoResponse, ExecuteMsg, InstantiateMsg, NftInfoListResponse, NftLockedResponse, NftsLockedResponse, QueryMsg, SalesAgrmtResponse, SalesAgrmtsResponse};
use crate::state::{Config, increment_sales_agrmt_id, SalesAgrmt, SalesAgrmtItem, SalesAgrmtStatus};
use crate::df721_mo::{Df721ExecuteMsg, NftTokenId};
use crate::msg::ExecuteMsg::SubmitSalesAgrmt;

const DENOM: &str = "uwfusd";
const OWNER: &str = "owner";
const NFT_MINTER: &str = "minter";
const DEALER: &str = "dealer";
const MF: &str = "toyota";
const MF2: &str = "honda";
const FIN: &str = "financier";
const PRODUCT: &str = "prius";
const UNIQUE_ID: &str = "VIN1";
const UNIQUE_ID_2: &str = "VIN2";
const CUSTOMER: &str = "customer";

fn _setup(app: &mut BasicApp) -> (Addr, u64) {
    let code = ContractWrapper::new(execute, instantiate, query);
    let code_id = app.store_code(Box::new(code));

    let msg = InstantiateMsg {
        denom:  DENOM.to_string(),
        nft_minter: NFT_MINTER.to_string(),
    };

    let addr = app.instantiate_contract(
        code_id,
        Addr::unchecked(OWNER),
        &msg,
        &[],
        "difi-core Contract",
        None
    ).unwrap();

    (addr, code_id)
}
fn setup_all() -> (BasicApp, Addr, u64) {
    let mut app = App::new(|router, _, storage| {
        router
            .bank
            .init_balance(storage, &Addr::unchecked(FIN), coins(2000000, DENOM))
            .unwrap()
    });


    let code = ContractWrapper::new(execute, instantiate, query);
    let code_id = app.store_code(Box::new(code));

    let msg = InstantiateMsg {
        denom:  DENOM.to_string(),
        nft_minter: NFT_MINTER.to_string(),
    };

    let addr = app.instantiate_contract(
        code_id,
        Addr::unchecked(OWNER),
        &msg,
        &[],
        "difi-core Contract",
        None
    ).unwrap();

    app.send_tokens(Addr::unchecked(FIN.to_owned()), Addr::unchecked(CUSTOMER.to_owned()), &coins(1000000, DENOM)).unwrap();

    (app, addr, code_id)
}

#[test]
// instantiate with mock deps, env and info
fn can_instantiate_with_mock() {
    let msg = InstantiateMsg { denom:  DENOM.to_string(), nft_minter: NFT_MINTER.to_string() };

    let mut deps = mock_dependencies();
    let env = mock_env();
    let info = mock_info(OWNER, &[]);


    let resp = instantiate(deps.as_mut(), env.clone(), info, msg).unwrap();
    assert_eq!(
        resp.attributes,
        vec![attr("action", "instantiate"), attr("denom", DENOM.to_string()), attr("nft_minter", NFT_MINTER.to_string())]
    );

    let ver = cw2::get_contract_version(&deps.storage).unwrap();
    assert_eq!(
        ver,
        ContractVersion {
            contract: CONTRACT_NAME.to_string(),
            version: CONTRACT_VERSION.to_string(),
        }
    );

    // this test does not work.
    /*
    let owner = cw_ownable::get_ownership(&deps.storage);
    assert_eq!(
        owner.owner,
        Some(Addr::unchecked(NFT_MINTER))
    )
    */

    // query config
    let config: Config = from_binary(&query(deps.as_ref(), env.to_owned(), QueryMsg::Config {}).unwrap()).unwrap();

    assert_eq!(
        config,
        Config {
            owner: Addr::unchecked(OWNER.to_string()),
            denom: DENOM.to_string(),
            nft_minter: Addr::unchecked(NFT_MINTER.to_string()),
            sales_agrmt_id: 0,
        }
    );

    let id = increment_sales_agrmt_id(deps.as_mut().storage).unwrap();
    assert_eq!(
        1,
        id
    );

    // query config
    let config: Config = from_binary(&query(deps.as_ref(), env, QueryMsg::Config {}).unwrap()).unwrap();

    assert_eq!(
        config,
        Config {
            owner: Addr::unchecked(OWNER.to_string()),
            denom: DENOM.to_string(),
            nft_minter: Addr::unchecked(NFT_MINTER.to_string()),
            sales_agrmt_id: 1,
        }
    );

}

#[test]
// instantiate with app
fn can_instantiate_with_setup() {
    let (app, contract_addr, _code_id) = setup_all();

    // Q: how to test version? how to test events from instantiation?

    // query config
    let config: Config = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::Config {})
        .unwrap();

    assert_eq!(
        config,
        Config {
            owner: Addr::unchecked(OWNER.to_string()),
            denom: DENOM.to_string(),
            nft_minter: Addr::unchecked(NFT_MINTER.to_string()),
            sales_agrmt_id: 0,
        }
    );
    // query contract info
    let contract_info_resp: cw721::ContractInfoResponse = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::ContractInfo {})
        .unwrap();

    assert_eq!(
        contract_info_resp,
        cw721::ContractInfoResponse {
            name: CONTRACT_NAME.to_string(),
            symbol: CONTRACT_NAME.to_string(),
        }
    );
    // query minter
    let minter_resp: cw721_base::MinterResponse = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::Minter {})
        .unwrap();

    assert_eq!(
        minter_resp,
        cw721_base::MinterResponse {
            minter: Some(NFT_MINTER.to_string()),
        }
    );
    // num tokens
    let num_token_resp: cw721::NumTokensResponse = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::NumTokens {})
        .unwrap();

    assert_eq!(
        num_token_resp,
        cw721::NumTokensResponse {
            count: 0,
        }
    );

    // coin balances
    let balances_resp: CoinBalancesResponse = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::CoinBalances { address: CUSTOMER.to_string() })
        .unwrap();
    assert_eq!(
        balances_resp,
        CoinBalancesResponse {
            balances: vec![
                CoinBalanceResponse {
                    denom: DENOM.to_string(),
                    amount: "1000000".to_string(),
                }
            ],
        }
    )

}

#[test]
fn can_mint_nft_one() {
    let (mut app, contract_addr, _code_id) = setup_all();

    // Q: how to test version? how to test events from instantiation?
    let token_id = NftTokenId::new(MF, PRODUCT, UNIQUE_ID).token_id();


    let extension = Some(Metadata {
        name: Some(PRODUCT.to_string()),
        attributes: Some(vec![
            Trait {
                display_type: None,
                trait_type: "year".to_string(),
                value: "2024".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "msp".to_string(),
                value: "40000".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "color".to_string(),
                value: "black".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "doors".to_string(),
                value: "4".to_string(),
            },
        ]),
        ..Metadata::default()
    });
    let mint_msg = ExecuteMsg::MintNft {
        mf: MF.to_string(),
        product: PRODUCT.to_string(),
        unique_id: UNIQUE_ID.to_string(),
        token_uri: None,
        extension,
    };
    let _resp = app.execute_contract(
        Addr::unchecked(NFT_MINTER),
        contract_addr.to_owned(),
        &mint_msg,
        &[],
    ).unwrap();

    // query config
    let config: Config = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::Config {})
        .unwrap();

    assert_eq!(
        config,
        Config {
            owner: Addr::unchecked(OWNER.to_string()),
            denom: DENOM.to_string(),
            nft_minter: Addr::unchecked(NFT_MINTER.to_string()),
            sales_agrmt_id: 0,
        }
    );
    // query contract info
    let contract_info_resp: cw721::ContractInfoResponse = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::ContractInfo {})
        .unwrap();

    assert_eq!(
        contract_info_resp,
        cw721::ContractInfoResponse {
            name: CONTRACT_NAME.to_string(),
            symbol: CONTRACT_NAME.to_string(),
        }
    );
    // query minter
    let minter_resp: cw721_base::MinterResponse = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::Minter {})
        .unwrap();

    assert_eq!(
        minter_resp,
        cw721_base::MinterResponse {
            minter: Some(NFT_MINTER.to_string()),
        }
    );
    // num tokens
    let num_token_resp: cw721::NumTokensResponse = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::NumTokens {})
        .unwrap();

    assert_eq!(
        num_token_resp,
        cw721::NumTokensResponse {
            count: 1,
        }
    );
    // owner
    let owner_of_resp: cw721::OwnerOfResponse = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::OwnerOf { token_id: token_id.to_owned(), include_expired: None })
        .unwrap();

    assert_eq!(
        owner_of_resp,
        cw721::OwnerOfResponse {
            owner: MF.to_string(),
            approvals: vec![],
        }
    );
    // nft info
    let token_id = NftTokenId {
        mf: MF,
        product: PRODUCT,
        unique_id: UNIQUE_ID,
    }.token_id();
    let nft_info_resp: cw721::NftInfoResponse<Extension> = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::NftInfo { token_id })
        .unwrap();

    assert_eq!(
        nft_info_resp,
        cw721::NftInfoResponse::<Extension> {
            token_uri: None,
            extension: Some(Metadata {
            name: Some(PRODUCT.to_string()),
            attributes: Some(vec![
                Trait {
                    display_type: None,
                    trait_type: "year".to_string(),
                    value: "2024".to_string(),
                },
                Trait {
                    display_type: None,
                    trait_type: "msp".to_string(),
                    value: "40000".to_string(),
                },
                Trait {
                    display_type: None,
                    trait_type: "color".to_string(),
                    value: "black".to_string(),
                },
                Trait {
                    display_type: None,
                    trait_type: "doors".to_string(),
                    value: "4".to_string(),
                },
            ]),
            ..Metadata::default()
        }),
        }
    )
}

#[test]
fn can_mint_nft_two() {
    let (mut app, contract_addr, _code_id) = setup_all();

    // Q: how to test version? how to test events from instantiation?
    let token_id = NftTokenId::new(MF, PRODUCT, UNIQUE_ID).token_id();

    // mint first
    let extension = Some(Metadata {
        name: Some(PRODUCT.to_string()),
        attributes: Some(vec![
            Trait {
                display_type: None,
                trait_type: "year".to_string(),
                value: "2024".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "msp".to_string(),
                value: "40000".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "color".to_string(),
                value: "black".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "doors".to_string(),
                value: "4".to_string(),
            },
        ]),
        ..Metadata::default()
    });
    let mint_msg = ExecuteMsg::MintNft {
        mf: MF.to_string(),
        product: PRODUCT.to_string(),
        unique_id: UNIQUE_ID.to_string(),
        token_uri: None,
        extension: extension,
    };
    let _resp = app.execute_contract(
        Addr::unchecked(NFT_MINTER),
        contract_addr.to_owned(),
        &mint_msg,
        &[],
    ).unwrap();

    // num tokens = 1
    let num_token_resp: cw721::NumTokensResponse = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::NumTokens {})
        .unwrap();

    assert_eq!(
        num_token_resp,
        cw721::NumTokensResponse {
            count: 1,
        }
    );
    let owner_of_resp: cw721::OwnerOfResponse = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::OwnerOf { token_id: token_id.to_owned(), include_expired: None })
        .unwrap();

    assert_eq!(
        owner_of_resp,
        cw721::OwnerOfResponse {
            owner: MF.to_string(),
            approvals: vec![],
        }
    );

    let nft_info_resp: cw721::NftInfoResponse<Extension> = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::NftInfo { token_id })
        .unwrap();

    assert_eq!(
        nft_info_resp,
        cw721::NftInfoResponse::<Extension> {
            token_uri: None,
            extension: Some(Metadata {
                name: Some(PRODUCT.to_string()),
                attributes: Some(vec![
                    Trait {
                        display_type: None,
                        trait_type: "year".to_string(),
                        value: "2024".to_string(),
                    },
                    Trait {
                        display_type: None,
                        trait_type: "msp".to_string(),
                        value: "40000".to_string(),
                    },
                    Trait {
                        display_type: None,
                        trait_type: "color".to_string(),
                        value: "black".to_string(),
                    },
                    Trait {
                        display_type: None,
                        trait_type: "doors".to_string(),
                        value: "4".to_string(),
                    },
                ]),
                ..Metadata::default()
            }),
        }
    );
    // mint second
    let extension = Some(Metadata {
        name: Some(PRODUCT.to_string()),
        attributes: Some(vec![
            Trait {
                display_type: None,
                trait_type: "year".to_string(),
                value: "2024".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "msp".to_string(),
                value: "40000".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "color".to_string(),
                value: "black".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "doors".to_string(),
                value: "4".to_string(),
            },
        ]),
        ..Metadata::default()
    });
    let mint_msg = ExecuteMsg::MintNft {
        mf: MF.to_string(),
        product: PRODUCT.to_string(),
        unique_id: UNIQUE_ID_2.to_string(),
        token_uri: None,
        extension: extension,
    };
    let _resp = app.execute_contract(
        Addr::unchecked(NFT_MINTER),
        contract_addr.to_owned(),
        &mint_msg,
        &[],
    ).unwrap();

    // num tokens = 2
    let num_token_resp: cw721::NumTokensResponse = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::NumTokens {})
        .unwrap();

    assert_eq!(
        num_token_resp,
        cw721::NumTokensResponse {
            count: 2,
        }
    );
    // nft info
    let token_id = NftTokenId::new(MF, PRODUCT, UNIQUE_ID_2).token_id();

    let nft_info_resp: cw721::NftInfoResponse<Extension> = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::NftInfo { token_id })
        .unwrap();

    assert_eq!(
        nft_info_resp,
        cw721::NftInfoResponse::<Extension> {
            token_uri: None,
            extension: Some(Metadata {
                name: Some(PRODUCT.to_string()),
                attributes: Some(vec![
                    Trait {
                        display_type: None,
                        trait_type: "year".to_string(),
                        value: "2024".to_string(),
                    },
                    Trait {
                        display_type: None,
                        trait_type: "msp".to_string(),
                        value: "40000".to_string(),
                    },
                    Trait {
                        display_type: None,
                        trait_type: "color".to_string(),
                        value: "black".to_string(),
                    },
                    Trait {
                        display_type: None,
                        trait_type: "doors".to_string(),
                        value: "4".to_string(),
                    },
                ]),
                ..Metadata::default()
            }),
        }
    );

    // nft info list
    let list: NftInfoListResponse<Extension> = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::NftInfoList { owner: MF.to_string(), start_after: None, limit: None })
        .unwrap();
    assert_eq!(
        list,
        NftInfoListResponse::<Extension> {
            info_list: vec![
                DifiNftInfoResponse::<Extension> {
                    token_id: NftTokenId::new(MF, PRODUCT, UNIQUE_ID).token_id(),
                    info: cw721::NftInfoResponse::<Extension> {
                        token_uri: None,
                        extension: Some(Metadata {
                            name: Some(PRODUCT.to_string()),
                            attributes: Some(vec![
                                Trait {
                                    display_type: None,
                                    trait_type: "year".to_string(),
                                    value: "2024".to_string(),
                                },
                                Trait {
                                    display_type: None,
                                    trait_type: "msp".to_string(),
                                    value: "40000".to_string(),
                                },
                                Trait {
                                    display_type: None,
                                    trait_type: "color".to_string(),
                                    value: "black".to_string(),
                                },
                                Trait {
                                    display_type: None,
                                    trait_type: "doors".to_string(),
                                    value: "4".to_string(),
                                },
                            ]),
                            ..Metadata::default()
                        }),
                    }
                },
                DifiNftInfoResponse::<Extension> {
                    token_id: NftTokenId::new(MF, PRODUCT, UNIQUE_ID_2).token_id(),
                    info: cw721::NftInfoResponse::<Extension> {
                        token_uri: None,
                        extension: Some(Metadata {
                            name: Some(PRODUCT.to_string()),
                            attributes: Some(vec![
                                Trait {
                                    display_type: None,
                                    trait_type: "year".to_string(),
                                    value: "2024".to_string(),
                                },
                                Trait {
                                    display_type: None,
                                    trait_type: "msp".to_string(),
                                    value: "40000".to_string(),
                                },
                                Trait {
                                    display_type: None,
                                    trait_type: "color".to_string(),
                                    value: "black".to_string(),
                                },
                                Trait {
                                    display_type: None,
                                    trait_type: "doors".to_string(),
                                    value: "4".to_string(),
                                },
                            ]),
                            ..Metadata::default()
                        }),
                    }
                },
            ]

        }
    )
}

#[test]
fn fail_mint_nft_claimed() {
    let (mut app, contract_addr, _code_id) = setup_all();

    // Q: how to test version? how to test events from instantiation?

    // mint first
    let extension = Some(Metadata {
        name: Some(PRODUCT.to_string()),
        attributes: Some(vec![
            Trait {
                display_type: None,
                trait_type: "year".to_string(),
                value: "2024".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "msp".to_string(),
                value: "40000".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "color".to_string(),
                value: "black".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "doors".to_string(),
                value: "4".to_string(),
            },
        ]),
        ..Metadata::default()
    });
    let mint_msg = ExecuteMsg::MintNft {
        mf: MF.to_string(),
        product: PRODUCT.to_string(),
        unique_id: UNIQUE_ID.to_string(),
        token_uri: None,
        extension: extension,
    };
    let _resp = app.execute_contract(
        Addr::unchecked(NFT_MINTER),
        contract_addr.to_owned(),
        &mint_msg,
        &[],
    ).unwrap();

    // num tokens = 1
    let num_token_resp: cw721::NumTokensResponse = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::NumTokens {})
        .unwrap();

    assert_eq!(
        num_token_resp,
        cw721::NumTokensResponse {
            count: 1,
        }
    );
    // nft info
    let token_id = NftTokenId::new(MF, PRODUCT, UNIQUE_ID).token_id();

    let nft_info_resp: cw721::NftInfoResponse<Extension> = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::NftInfo { token_id })
        .unwrap();

    assert_eq!(
        nft_info_resp,
        cw721::NftInfoResponse::<Extension> {
            token_uri: None,
            extension: Some(Metadata {
                name: Some(PRODUCT.to_string()),
                attributes: Some(vec![
                    Trait {
                        display_type: None,
                        trait_type: "year".to_string(),
                        value: "2024".to_string(),
                    },
                    Trait {
                        display_type: None,
                        trait_type: "msp".to_string(),
                        value: "40000".to_string(),
                    },
                    Trait {
                        display_type: None,
                        trait_type: "color".to_string(),
                        value: "black".to_string(),
                    },
                    Trait {
                        display_type: None,
                        trait_type: "doors".to_string(),
                        value: "4".to_string(),
                    },
                ]),
                ..Metadata::default()
            }),
        }
    );
    // mint dup
    let extension = Some(Metadata {
        name: Some(PRODUCT.to_string()),
        attributes: Some(vec![
            Trait {
                display_type: None,
                trait_type: "year".to_string(),
                value: "2024".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "msp".to_string(),
                value: "40000".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "color".to_string(),
                value: "black".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "doors".to_string(),
                value: "4".to_string(),
            },
        ]),
        ..Metadata::default()
    });
    let mint_msg = ExecuteMsg::MintNft {
        mf: MF.to_string(),
        product: PRODUCT.to_string(),
        unique_id: UNIQUE_ID.to_string(),
        token_uri: None,
        extension: extension,
    };
    let err = app.execute_contract(
        Addr::unchecked(NFT_MINTER),
        contract_addr.to_owned(),
        &mint_msg,
        &[],
    ).unwrap_err();

    assert_eq!(
        ContractError::Cw721ContractError(cw721_base::ContractError::Claimed {}),
        err.downcast().unwrap()
    );

    // num tokens = 1 still
    let num_token_resp: cw721::NumTokensResponse = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::NumTokens {})
        .unwrap();

    assert_eq!(
        num_token_resp,
        cw721::NumTokensResponse {
            count: 1,
        }
    )
}

#[test]
fn can_transfer_nft() {
    let (mut app, contract_addr, _code_id) = setup_all();

    // Q: how to test version? how to test events from instantiation?
    let token_id = NftTokenId::new(MF, PRODUCT, UNIQUE_ID).token_id();

    let extension = Some(Metadata {
        name: Some(PRODUCT.to_string()),
        attributes: Some(vec![
            Trait {
                display_type: None,
                trait_type: "year".to_string(),
                value: "2024".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "msp".to_string(),
                value: "40000".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "color".to_string(),
                value: "black".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "doors".to_string(),
                value: "4".to_string(),
            },
        ]),
        ..Metadata::default()
    });
    let mint_msg = ExecuteMsg::MintNft {
        mf: MF.to_string(),
        product: PRODUCT.to_string(),
        unique_id: UNIQUE_ID.to_string(),
        token_uri: None,
        extension,
    };
    let _resp = app.execute_contract(
        Addr::unchecked(NFT_MINTER),
        contract_addr.to_owned(),
        &mint_msg,
        &[],
    ).unwrap();

    // num tokens
    let num_token_resp: cw721::NumTokensResponse = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::NumTokens {})
        .unwrap();

    assert_eq!(
        num_token_resp,
        cw721::NumTokensResponse {
            count: 1,
        }
    );
    // current owner = MF
    let owner_of_resp: cw721::OwnerOfResponse = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::OwnerOf { token_id: token_id.to_owned(), include_expired: None })
        .unwrap();

    assert_eq!(
        owner_of_resp,
        cw721::OwnerOfResponse {
            owner: MF.to_string(),
            approvals: vec![],
        }
    );
    // nft info
    let nft_info_resp: cw721::NftInfoResponse<Extension> = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::NftInfo { token_id: token_id.to_owned() })
        .unwrap();

    assert_eq!(
        nft_info_resp,
        cw721::NftInfoResponse::<Extension> {
            token_uri: None,
            extension: Some(Metadata {
                name: Some(PRODUCT.to_string()),
                attributes: Some(vec![
                    Trait {
                        display_type: None,
                        trait_type: "year".to_string(),
                        value: "2024".to_string(),
                    },
                    Trait {
                        display_type: None,
                        trait_type: "msp".to_string(),
                        value: "40000".to_string(),
                    },
                    Trait {
                        display_type: None,
                        trait_type: "color".to_string(),
                        value: "black".to_string(),
                    },
                    Trait {
                        display_type: None,
                        trait_type: "doors".to_string(),
                        value: "4".to_string(),
                    },
                ]),
                ..Metadata::default()
            }),
        }
    );
    // transfer to FIN
    let transfer_msg = ExecuteMsg::TransferNft {
        token_id: token_id.to_owned(),
        recipient: FIN.to_string(),
    };
    let _resp = app.execute_contract(
        Addr::unchecked(MF),
        contract_addr.to_owned(),
        &transfer_msg,
        &[],
    ).unwrap();
    // new owner = FIN
    let owner_of_resp: cw721::OwnerOfResponse = app.wrap()
        .query_wasm_smart(contract_addr, &QueryMsg::OwnerOf { token_id, include_expired: None })
        .unwrap();

    assert_eq!(
        owner_of_resp,
        cw721::OwnerOfResponse {
            owner: FIN.to_string(),
            approvals: vec![],
        }
    );
}

#[test]
fn fail_transfer_nft_unauthorized() {
    let (mut app, contract_addr, _code_id) = setup_all();

    // Q: how to test version? how to test events from instantiation?
    let token_id = NftTokenId::new(MF, PRODUCT, UNIQUE_ID).token_id();

    let extension = Some(Metadata {
        name: Some(PRODUCT.to_string()),
        attributes: Some(vec![
            Trait {
                display_type: None,
                trait_type: "year".to_string(),
                value: "2024".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "msp".to_string(),
                value: "40000".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "color".to_string(),
                value: "black".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "doors".to_string(),
                value: "4".to_string(),
            },
        ]),
        ..Metadata::default()
    });
    let mint_msg = ExecuteMsg::MintNft {
        mf: MF.to_string(),
        product: PRODUCT.to_string(),
        unique_id: UNIQUE_ID.to_string(),
        token_uri: None,
        extension,
    };
    let _resp = app.execute_contract(
        Addr::unchecked(NFT_MINTER),
        contract_addr.to_owned(),
        &mint_msg,
        &[],
    ).unwrap();

    // num tokens
    let num_token_resp: cw721::NumTokensResponse = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::NumTokens {})
        .unwrap();

    assert_eq!(
        num_token_resp,
        cw721::NumTokensResponse {
            count: 1,
        }
    );
    // current owner = MF
    let owner_of_resp: cw721::OwnerOfResponse = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::OwnerOf { token_id: token_id.to_owned(), include_expired: None })
        .unwrap();

    assert_eq!(
        owner_of_resp,
        cw721::OwnerOfResponse {
            owner: MF.to_string(),
            approvals: vec![],
        }
    );
    // nft info
    let nft_info_resp: cw721::NftInfoResponse<Extension> = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::NftInfo { token_id: token_id.to_owned() })
        .unwrap();

    assert_eq!(
        nft_info_resp,
        cw721::NftInfoResponse::<Extension> {
            token_uri: None,
            extension: Some(Metadata {
                name: Some(PRODUCT.to_string()),
                attributes: Some(vec![
                    Trait {
                        display_type: None,
                        trait_type: "year".to_string(),
                        value: "2024".to_string(),
                    },
                    Trait {
                        display_type: None,
                        trait_type: "msp".to_string(),
                        value: "40000".to_string(),
                    },
                    Trait {
                        display_type: None,
                        trait_type: "color".to_string(),
                        value: "black".to_string(),
                    },
                    Trait {
                        display_type: None,
                        trait_type: "doors".to_string(),
                        value: "4".to_string(),
                    },
                ]),
                ..Metadata::default()
            }),
        }
    );
    // transfer to FIN by MF2: fails because owner is MF
    let transfer_msg = ExecuteMsg::TransferNft {
        token_id: token_id.to_owned(),
        recipient: FIN.to_string(),
    };
    let err = app.execute_contract(
        Addr::unchecked(MF2),
        contract_addr.to_owned(),
        &transfer_msg,
        &[],
    ).unwrap_err();
    assert_eq!(
        ContractError::Cw721ContractError(cw721_base::ContractError::Ownership(cw721_base::OwnershipError::NotOwner)),
        err.downcast().unwrap()
    );

    // owner = MF
    let owner_of_resp: cw721::OwnerOfResponse = app.wrap()
        .query_wasm_smart(contract_addr, &QueryMsg::OwnerOf { token_id, include_expired: None })
        .unwrap();

    assert_eq!(
        owner_of_resp,
        cw721::OwnerOfResponse {
            owner: MF.to_string(),
            approvals: vec![],
        }
    );
}

#[test]
// execute: SubmitSalesAgrmt
// query: SalesAgrmt, AllSalesAgrmts, SalesAgrmtsByDealer, SalesAgrmtsByMf, SalesAgrmtsByFin
fn can_submit_sales_agrmt() {
    let (mut app, contract_addr, _code_id) = setup_all();

    // Q: how to test version? how to test events from instantiation?
    let token_id = NftTokenId::new(MF, PRODUCT, UNIQUE_ID).token_id();

    let extension = Some(Metadata {
        name: Some(PRODUCT.to_string()),
        attributes: Some(vec![
            Trait {
                display_type: None,
                trait_type: "year".to_string(),
                value: "2024".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "msp".to_string(),
                value: "40000".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "color".to_string(),
                value: "black".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "doors".to_string(),
                value: "4".to_string(),
            },
        ]),
        ..Metadata::default()
    });
    let mint_msg = ExecuteMsg::MintNft {
        mf: MF.to_string(),
        product: PRODUCT.to_string(),
        unique_id: UNIQUE_ID.to_string(),
        token_uri: None,
        extension,
    };
    let _resp = app.execute_contract(
        Addr::unchecked(NFT_MINTER),
        contract_addr.to_owned(),
        &mint_msg,
        &[],
    ).unwrap();

    // num tokens
    let num_token_resp: cw721::NumTokensResponse = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::NumTokens {})
        .unwrap();

    assert_eq!(
        num_token_resp,
        cw721::NumTokensResponse {
            count: 1,
        }
    );
    // current owner = MF
    let owner_of_resp: cw721::OwnerOfResponse = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::OwnerOf { token_id: token_id.to_owned(), include_expired: None })
        .unwrap();

    assert_eq!(
        owner_of_resp,
        cw721::OwnerOfResponse {
            owner: MF.to_string(),
            approvals: vec![],
        }
    );
    // nft info
    let token_id = NftTokenId {
        mf: MF,
        product: PRODUCT,
        unique_id: UNIQUE_ID,
    }.token_id();
    let nft_info_resp: cw721::NftInfoResponse<Extension> = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::NftInfo { token_id: token_id.to_owned() })
        .unwrap();

    assert_eq!(
        nft_info_resp,
        cw721::NftInfoResponse::<Extension> {
            token_uri: None,
            extension: Some(Metadata {
                name: Some(PRODUCT.to_string()),
                attributes: Some(vec![
                    Trait {
                        display_type: None,
                        trait_type: "year".to_string(),
                        value: "2024".to_string(),
                    },
                    Trait {
                        display_type: None,
                        trait_type: "msp".to_string(),
                        value: "40000".to_string(),
                    },
                    Trait {
                        display_type: None,
                        trait_type: "color".to_string(),
                        value: "black".to_string(),
                    },
                    Trait {
                        display_type: None,
                        trait_type: "doors".to_string(),
                        value: "4".to_string(),
                    },
                ]),
                ..Metadata::default()
            }),
        }
    );

    // sales agrmt
    let items = vec![
        SalesAgrmtItem {
            nft_token_id: token_id.to_owned(),
            dealer_price: 40000,
            fin_cost: 41000,
        },
    ];
    let submit_msg = SubmitSalesAgrmt {
        dealer: DEALER.to_owned(),
        mf: MF.to_owned(),
        fin: FIN.to_owned(),
        items,
    };
    let _resp = app.execute_contract(
        Addr::unchecked(DEALER.to_owned()),
        contract_addr.to_owned(),
        &submit_msg,
        &[],
    ).unwrap();

    // get the agrmt
    let sales_agrmt_resp: SalesAgrmtResponse = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::SalesAgrmt { id: 1 }
    ).unwrap();
    let items = vec![
        SalesAgrmtItem {
            nft_token_id: token_id.to_owned(),
            dealer_price: 40000,
            fin_cost: 41000,
        },
    ];
    let agrmt = SalesAgrmt {
        dealer: Addr::unchecked(DEALER.to_owned()),
        mf: Addr::unchecked(MF.to_owned()),
        fin: Addr::unchecked(FIN.to_owned()),
        total_dealer_price: 40000,
        total_fin_cost: 41000,
        status: SalesAgrmtStatus::Pending,
        items,
    };
    assert_eq!(
        SalesAgrmtResponse {
            id: 1,
            agrmt,
        },
        sales_agrmt_resp
    );
    // get all agrmts
    let sales_agrmts_resp: SalesAgrmtsResponse = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::AllSalesAgrmts { start_after: None, limit: None }
    ).unwrap();
    let items = vec![
        SalesAgrmtItem {
            nft_token_id: token_id.to_owned(),
            dealer_price: 40000,
            fin_cost: 41000,
        },
    ];
    let agrmt = SalesAgrmt {
        // who: (Addr::unchecked(dealer.to_owned()), Addr::unchecked(MF.to_owned()), Addr::unchecked(FIN.to_owned())),
        dealer: Addr::unchecked(DEALER.to_owned()),
        mf: Addr::unchecked(MF.to_owned()),
        fin: Addr::unchecked(FIN.to_owned()),
        total_dealer_price: 40000,
        total_fin_cost: 41000,
        status: SalesAgrmtStatus::Pending,
        items,
    };
    assert_eq!(
        SalesAgrmtsResponse {
            agrmts: vec![SalesAgrmtResponse {
                id: 1,
                agrmt
            }]
        },
        sales_agrmts_resp
    );

    // get agrmts by dealer
    let sales_agrmts_resp: SalesAgrmtsResponse = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::SalesAgrmtsByDealer { dealer: DEALER.to_owned(), start_after: None, limit: None }
    ).unwrap();
    let items = vec![
        SalesAgrmtItem {
            nft_token_id: token_id.to_owned(),
            dealer_price: 40000,
            fin_cost: 41000,
        },
    ];
    let agrmt = SalesAgrmt {
        dealer: Addr::unchecked(DEALER.to_owned()),
        mf: Addr::unchecked(MF.to_owned()),
        fin: Addr::unchecked(FIN.to_owned()),
        total_dealer_price: 40000,
        total_fin_cost: 41000,
        status: SalesAgrmtStatus::Pending,
        items,
    };
    assert_eq!(
        SalesAgrmtsResponse {
            agrmts: vec![SalesAgrmtResponse {
                id: 1,
                agrmt
            }]
        },
        sales_agrmts_resp
    );

    // get agrmts by MF
    let sales_agrmts_resp: SalesAgrmtsResponse = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::SalesAgrmtsByMf { mf: MF.to_owned(), start_after: None, limit: None }
    ).unwrap();
    let items = vec![
        SalesAgrmtItem {
            nft_token_id: token_id.to_owned(),
            dealer_price: 40000,
            fin_cost: 41000,
        },
    ];
    let agrmt = SalesAgrmt {
        dealer: Addr::unchecked(DEALER.to_owned()),
        mf: Addr::unchecked(MF.to_owned()),
        fin: Addr::unchecked(FIN.to_owned()),
        total_dealer_price: 40000,
        total_fin_cost: 41000,
        status: SalesAgrmtStatus::Pending,
        items,
    };
    assert_eq!(
        SalesAgrmtsResponse {
            agrmts: vec![SalesAgrmtResponse {
                id: 1,
                agrmt
            }]
        },
        sales_agrmts_resp
    );

    // get agrmts by fin
    let sales_agrmts_resp: SalesAgrmtsResponse = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::SalesAgrmtsByFin { fin: FIN.to_owned(), start_after: None, limit: None }
    ).unwrap();
    let items = vec![
        SalesAgrmtItem {
            nft_token_id: token_id.to_owned(),
            dealer_price: 40000,
            fin_cost: 41000,
        },
    ];
    let agrmt = SalesAgrmt {
        dealer: Addr::unchecked(DEALER.to_owned()),
        mf: Addr::unchecked(MF.to_owned()),
        fin: Addr::unchecked(FIN.to_owned()),
        total_dealer_price: 40000,
        total_fin_cost: 41000,
        status: SalesAgrmtStatus::Pending,
        items,
    };
    assert_eq!(
        SalesAgrmtsResponse {
            agrmts: vec![SalesAgrmtResponse {
                id: 1,
                agrmt
            }]
        },
        sales_agrmts_resp
    );

    // test invalid id: TODO: msg with difi_core_2 is brittle
    let err: StdResult<SalesAgrmtResponse> = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::SalesAgrmt { id: 2 }
    );
    let err = err.unwrap_err();
    assert_eq!(
        cosmwasm_std::StdError::GenericErr {msg: "Querier contract error: difi_core_2::state::SalesAgrmt not found".to_string()},
        err
    );
}

#[test]
// execute: SubmitSalesAgrmt
// SalesAgrmtEmptyItems, WrongOwner, NftLocked
fn fail_submit_sales_agrmt_nft_locked() {
    let (mut app, contract_addr, _code_id) = setup_all();

    // Q: how to test version? how to test events from instantiation?
    let token_id = NftTokenId::new(MF, PRODUCT, UNIQUE_ID).token_id();

    let extension = Some(Metadata {
        name: Some(PRODUCT.to_string()),
        attributes: Some(vec![
            Trait {
                display_type: None,
                trait_type: "year".to_string(),
                value: "2024".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "msp".to_string(),
                value: "40000".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "color".to_string(),
                value: "black".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "doors".to_string(),
                value: "4".to_string(),
            },
        ]),
        ..Metadata::default()
    });
    let mint_msg = ExecuteMsg::MintNft {
        mf: MF.to_string(),
        product: PRODUCT.to_string(),
        unique_id: UNIQUE_ID.to_string(),
        token_uri: None,
        extension,
    };
    let _resp = app.execute_contract(
        Addr::unchecked(NFT_MINTER),
        contract_addr.to_owned(),
        &mint_msg,
        &[],
    ).unwrap();

    // num tokens
    let num_token_resp: cw721::NumTokensResponse = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::NumTokens {})
        .unwrap();

    assert_eq!(
        num_token_resp,
        cw721::NumTokensResponse {
            count: 1,
        }
    );
    // current owner = MF
    let owner_of_resp: cw721::OwnerOfResponse = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::OwnerOf { token_id: token_id.to_owned(), include_expired: None })
        .unwrap();

    assert_eq!(
        owner_of_resp,
        cw721::OwnerOfResponse {
            owner: MF.to_string(),
            approvals: vec![],
        }
    );
    // nft info
    let token_id = NftTokenId {
        mf: MF,
        product: PRODUCT,
        unique_id: UNIQUE_ID,
    }.token_id();
    let nft_info_resp: cw721::NftInfoResponse<Extension> = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::NftInfo { token_id: token_id.to_owned() })
        .unwrap();

    assert_eq!(
        nft_info_resp,
        cw721::NftInfoResponse::<Extension> {
            token_uri: None,
            extension: Some(Metadata {
                name: Some(PRODUCT.to_string()),
                attributes: Some(vec![
                    Trait {
                        display_type: None,
                        trait_type: "year".to_string(),
                        value: "2024".to_string(),
                    },
                    Trait {
                        display_type: None,
                        trait_type: "msp".to_string(),
                        value: "40000".to_string(),
                    },
                    Trait {
                        display_type: None,
                        trait_type: "color".to_string(),
                        value: "black".to_string(),
                    },
                    Trait {
                        display_type: None,
                        trait_type: "doors".to_string(),
                        value: "4".to_string(),
                    },
                ]),
                ..Metadata::default()
            }),
        }
    );

    // sales agrmt: empty items
    let items = vec![];
    let submit_msg = SubmitSalesAgrmt {
        dealer: DEALER.to_owned(),
        mf: MF.to_owned(),
        fin: FIN.to_owned(),
        items,
    };
    let err = app.execute_contract(
        Addr::unchecked(DEALER.to_owned()),
        contract_addr.to_owned(),
        &submit_msg,
        &[],
    ).unwrap_err();
    assert_eq!(
        ContractError::SalesAgrmtEmptyItems {},
        err.downcast().unwrap()
    );

    // sales agrmt: use MF2 so expect WrongOwner
    let items = vec![
        SalesAgrmtItem {
            nft_token_id: token_id.to_owned(),
            dealer_price: 40000,
            fin_cost: 41000,
        },
    ];
    let submit_msg = SubmitSalesAgrmt {
        dealer: DEALER.to_owned(),
        mf: MF2.to_owned(),
        fin: FIN.to_owned(),
        items,
    };
    let err = app.execute_contract(
        Addr::unchecked(DEALER.to_owned()),
        contract_addr.to_owned(),
        &submit_msg,
        &[],
    ).unwrap_err();
    assert_eq!(
        ContractError::WrongOwner { expected: Addr::unchecked(MF2), got: Addr::unchecked(MF) },
        err.downcast().unwrap()
    );

    // sales agrmt: this one should pass
    let items = vec![
        SalesAgrmtItem {
            nft_token_id: token_id.to_owned(),
            dealer_price: 40000,
            fin_cost: 41000,
        },
    ];
    let submit_msg = SubmitSalesAgrmt {
        dealer: DEALER.to_owned(),
        mf: MF.to_owned(),
        fin: FIN.to_owned(),
        items,
    };
    let _resp = app.execute_contract(
        Addr::unchecked(DEALER.to_owned()),
        contract_addr.to_owned(),
        &submit_msg,
        &[],
    ).unwrap();

    // get the agrmt
    let sales_agrmt_resp: SalesAgrmtResponse = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::SalesAgrmt { id: 1 }
    ).unwrap();
    let items = vec![
        SalesAgrmtItem {
            nft_token_id: token_id.to_owned(),
            dealer_price: 40000,
            fin_cost: 41000,
        },
    ];
    let agrmt = SalesAgrmt {
        dealer: Addr::unchecked(DEALER.to_owned()),
        mf: Addr::unchecked(MF.to_owned()),
        fin: Addr::unchecked(FIN.to_owned()),
        total_dealer_price: 40000,
        total_fin_cost: 41000,
        status: SalesAgrmtStatus::Pending,
        items,
    };
    assert_eq!(
        SalesAgrmtResponse {
            id: 1,
            agrmt,
        },
        sales_agrmt_resp
    );
    // get all agrmts
    let sales_agrmts_resp: SalesAgrmtsResponse = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::AllSalesAgrmts { start_after: None, limit: None }
    ).unwrap();
    let items = vec![
        SalesAgrmtItem {
            nft_token_id: token_id.to_owned(),
            dealer_price: 40000,
            fin_cost: 41000,
        },
    ];
    let agrmt = SalesAgrmt {
        // who: (Addr::unchecked(dealer.to_owned()), Addr::unchecked(MF.to_owned()), Addr::unchecked(FIN.to_owned())),
        dealer: Addr::unchecked(DEALER.to_owned()),
        mf: Addr::unchecked(MF.to_owned()),
        fin: Addr::unchecked(FIN.to_owned()),
        total_dealer_price: 40000,
        total_fin_cost: 41000,
        status: SalesAgrmtStatus::Pending,
        items,
    };
    assert_eq!(
        SalesAgrmtsResponse {
            agrmts: vec![SalesAgrmtResponse {
                id: 1,
                agrmt
            }]
        },
        sales_agrmts_resp
    );

    // get agrmts by dealer
    let sales_agrmts_resp: SalesAgrmtsResponse = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::SalesAgrmtsByDealer { dealer: DEALER.to_owned(), start_after: None, limit: None }
    ).unwrap();
    let items = vec![
        SalesAgrmtItem {
            nft_token_id: token_id.to_owned(),
            dealer_price: 40000,
            fin_cost: 41000,
        },
    ];
    let agrmt = SalesAgrmt {
        dealer: Addr::unchecked(DEALER.to_owned()),
        mf: Addr::unchecked(MF.to_owned()),
        fin: Addr::unchecked(FIN.to_owned()),
        total_dealer_price: 40000,
        total_fin_cost: 41000,
        status: SalesAgrmtStatus::Pending,
        items,
    };
    assert_eq!(
        SalesAgrmtsResponse {
            agrmts: vec![SalesAgrmtResponse {
                id: 1,
                agrmt
            }]
        },
        sales_agrmts_resp
    );

    // get agrmts by MF
    let sales_agrmts_resp: SalesAgrmtsResponse = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::SalesAgrmtsByMf { mf: MF.to_owned(), start_after: None, limit: None }
    ).unwrap();
    let items = vec![
        SalesAgrmtItem {
            nft_token_id: token_id.to_owned(),
            dealer_price: 40000,
            fin_cost: 41000,
        },
    ];
    let agrmt = SalesAgrmt {
        dealer: Addr::unchecked(DEALER.to_owned()),
        mf: Addr::unchecked(MF.to_owned()),
        fin: Addr::unchecked(FIN.to_owned()),
        total_dealer_price: 40000,
        total_fin_cost: 41000,
        status: SalesAgrmtStatus::Pending,
        items,
    };
    assert_eq!(
        SalesAgrmtsResponse {
            agrmts: vec![SalesAgrmtResponse {
                id: 1,
                agrmt
            }]
        },
        sales_agrmts_resp
    );

    // get agrmts by fin
    let sales_agrmts_resp: SalesAgrmtsResponse = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::SalesAgrmtsByFin { fin: FIN.to_owned(), start_after: None, limit: None }
    ).unwrap();
    let items = vec![
        SalesAgrmtItem {
            nft_token_id: token_id.to_owned(),
            dealer_price: 40000,
            fin_cost: 41000,
        },
    ];
    let agrmt = SalesAgrmt {
        dealer: Addr::unchecked(DEALER.to_owned()),
        mf: Addr::unchecked(MF.to_owned()),
        fin: Addr::unchecked(FIN.to_owned()),
        total_dealer_price: 40000,
        total_fin_cost: 41000,
        status: SalesAgrmtStatus::Pending,
        items,
    };
    assert_eq!(
        SalesAgrmtsResponse {
            agrmts: vec![SalesAgrmtResponse {
                id: 1,
                agrmt
            }]
        },
        sales_agrmts_resp
    );

    // test invalid id: TODO: msg with difi_core_2 is brittle
    let err: StdResult<SalesAgrmtResponse> = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::SalesAgrmt { id: 2 }
    );
    let err = err.unwrap_err();
    assert_eq!(
        cosmwasm_std::StdError::GenericErr {msg: "Querier contract error: difi_core_2::state::SalesAgrmt not found".to_string()},
        err
    );

    // sales agrmt: NftLocked
    let items = vec![
        SalesAgrmtItem {
            nft_token_id: token_id.to_owned(),
            dealer_price: 40000,
            fin_cost: 41000,
        },
    ];
    let submit_msg = SubmitSalesAgrmt {
        dealer: DEALER.to_owned(),
        mf: MF.to_owned(),
        fin: FIN.to_owned(),
        items,
    };
    let err = app.execute_contract(
        Addr::unchecked(DEALER.to_owned()),
        contract_addr.to_owned(),
        &submit_msg,
        &[],
    ).unwrap_err();
    assert_eq!(
        ContractError::NftLocked { token_id },
        err.downcast().unwrap()
    );

}

#[test]
// execute: SubmitSalesAgrmt, MfApproveSalesAgrmt, FinApproveSalesAgrmt
// query: SalesAgrmt
fn can_approve_sales_agrmt() {
    let (mut app, contract_addr, _code_id) = setup_all();

    // Q: how to test version? how to test events from instantiation?
    let token_id = NftTokenId::new(MF, PRODUCT, UNIQUE_ID).token_id();

    let extension = Some(Metadata {
        name: Some(PRODUCT.to_string()),
        attributes: Some(vec![
            Trait {
                display_type: None,
                trait_type: "year".to_string(),
                value: "2024".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "msp".to_string(),
                value: "40000".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "color".to_string(),
                value: "black".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "doors".to_string(),
                value: "4".to_string(),
            },
        ]),
        ..Metadata::default()
    });
    let mint_msg = ExecuteMsg::MintNft {
        mf: MF.to_string(),
        product: PRODUCT.to_string(),
        unique_id: UNIQUE_ID.to_string(),
        token_uri: None,
        extension,
    };
    let _resp = app.execute_contract(
        Addr::unchecked(NFT_MINTER),
        contract_addr.to_owned(),
        &mint_msg,
        &[],
    ).unwrap();

    // sales agrmt
    let items = vec![
        SalesAgrmtItem {
            nft_token_id: token_id.to_owned(),
            dealer_price: 40000,
            fin_cost: 41000,
        },
    ];
    let submit_msg = SubmitSalesAgrmt {
        dealer: DEALER.to_owned(),
        mf: MF.to_owned(),
        fin: FIN.to_owned(),
        items,
    };
    let _resp = app.execute_contract(
        Addr::unchecked(DEALER.to_owned()),
        contract_addr.to_owned(),
        &submit_msg,
        &[],
    ).unwrap();

    // get the agrmt
    let sales_agrmt_resp: SalesAgrmtResponse = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::SalesAgrmt { id: 1 }
    ).unwrap();
    let items = vec![
        SalesAgrmtItem {
            nft_token_id: token_id.to_owned(),
            dealer_price: 40000,
            fin_cost: 41000,
        },
    ];
    let agrmt = SalesAgrmt {
        dealer: Addr::unchecked(DEALER.to_owned()),
        mf: Addr::unchecked(MF.to_owned()),
        fin: Addr::unchecked(FIN.to_owned()),
        total_dealer_price: 40000,
        total_fin_cost: 41000,
        status: SalesAgrmtStatus::Pending,
        items,
    };
    assert_eq!(
        SalesAgrmtResponse {
            id: 1,
            agrmt,
        },
        sales_agrmt_resp
    );

    // approve agrmt by dealer:unauthorized
    let err = app.execute_contract(
        Addr::unchecked(DEALER.to_owned()),
        contract_addr.to_owned(),
        &ExecuteMsg::MfApproveSalesAgrmt { agrmt_id: 1 },
        &[],
    ).unwrap_err();
    assert_eq!(
        ContractError::Unauthorized { sender: Addr::unchecked(DEALER.to_owned())},
        err.downcast().unwrap()
    );

    // MF approve agrmt
    let _resp = app.execute_contract(
        Addr::unchecked(MF.to_owned()),
        contract_addr.to_owned(),
        &ExecuteMsg::MfApproveSalesAgrmt { agrmt_id: 1 },
        &[],
    ).unwrap();

    // get the agrmt
    let sales_agrmt_resp: SalesAgrmtResponse = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::SalesAgrmt { id: 1 }
    ).unwrap();

    assert_eq!(
        sales_agrmt_resp.agrmt.status,
        SalesAgrmtStatus::MfApproved
    );

    // MF approve agrmt again - invalid status
    let err = app.execute_contract(
        Addr::unchecked(MF.to_owned()),
        contract_addr.to_owned(),
        &ExecuteMsg::MfApproveSalesAgrmt { agrmt_id: 1 },
        &[],
    ).unwrap_err();
    assert_eq!(
        ContractError::InvalidStatus { expected: SalesAgrmtStatus::Pending.to_string(), got: SalesAgrmtStatus::MfApproved.to_string()},
        err.downcast().unwrap()
    );

    // fin approves agrmt
    let payment = coins(40000, DENOM);
    let _resp = app.execute_contract(
        Addr::unchecked(FIN.to_owned()),
        contract_addr.to_owned(),
        &ExecuteMsg::FinApproveSalesAgrmt { agrmt_id: 1 },
        &payment,
    ).unwrap();

    // get the agrmt
    let sales_agrmt_resp: SalesAgrmtResponse = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::SalesAgrmt { id: 1 }
    ).unwrap();

    assert_eq!(
        sales_agrmt_resp.agrmt.status,
        SalesAgrmtStatus::FinApproved
    );
    // financier balance reduced
    let balance = coins(1000000 - Into::<u128>::into(payment[0].amount), DENOM); //Coin::new(1000, DENOM);
    assert_eq!(
        app.wrap()
            .query_balance(Addr::unchecked(FIN.to_string()), DENOM)
            .unwrap()
            .amount
            .u128(),
        Into::into(balance[0].amount)
    );
    // escrow gets paid
    assert_eq!(
        app.wrap()
            .query_balance(contract_addr.to_owned(), DENOM)
            .unwrap()
            .amount
            .u128(),
        Into::into(payment[0].amount)
    );
}

#[test]
// execute: SubmitSalesAgrmt, MfApproveSalesAgrmt, FinApproveSalesAgrmt, MfTransferNfts
// query: SalesAgrmt, AllNftsLocked, Approval
fn can_mf_transfer_nfts() {
    let (mut app, contract_addr, _code_id) = setup_all();

    // Q: how to test version? how to test events from instantiation?
    let token_id = NftTokenId::new(MF, PRODUCT, UNIQUE_ID).token_id();

    let extension = Some(Metadata {
        name: Some(PRODUCT.to_string()),
        attributes: Some(vec![
            Trait {
                display_type: None,
                trait_type: "year".to_string(),
                value: "2024".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "msp".to_string(),
                value: "40000".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "color".to_string(),
                value: "black".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "doors".to_string(),
                value: "4".to_string(),
            },
        ]),
        ..Metadata::default()
    });
    let mint_msg = ExecuteMsg::MintNft {
        mf: MF.to_string(),
        product: PRODUCT.to_string(),
        unique_id: UNIQUE_ID.to_string(),
        token_uri: None,
        extension,
    };
    let _resp = app.execute_contract(
        Addr::unchecked(NFT_MINTER),
        contract_addr.to_owned(),
        &mint_msg,
        &[],
    ).unwrap();

    // sales agrmt
    let items = vec![
        SalesAgrmtItem {
            nft_token_id: token_id.to_owned(),
            dealer_price: 40000,
            fin_cost: 41000,
        },
    ];
    let submit_msg = SubmitSalesAgrmt {
        dealer: DEALER.to_owned(),
        mf: MF.to_owned(),
        fin: FIN.to_owned(),
        items,
    };
    let _resp = app.execute_contract(
        Addr::unchecked(DEALER.to_owned()),
        contract_addr.to_owned(),
        &submit_msg,
        &[],
    ).unwrap();

    // get the agrmt
    let sales_agrmt_resp: SalesAgrmtResponse = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::SalesAgrmt { id: 1 }
    ).unwrap();
    let items = vec![
        SalesAgrmtItem {
            nft_token_id: token_id.to_owned(),
            dealer_price: 40000,
            fin_cost: 41000,
        },
    ];
    let agrmt = SalesAgrmt {
        dealer: Addr::unchecked(DEALER.to_owned()),
        mf: Addr::unchecked(MF.to_owned()),
        fin: Addr::unchecked(FIN.to_owned()),
        total_dealer_price: 40000,
        total_fin_cost: 41000,
        status: SalesAgrmtStatus::Pending,
        items,
    };
    assert_eq!(
        SalesAgrmtResponse {
            id: 1,
            agrmt,
        },
        sales_agrmt_resp
    );

    // MF approve agrmt
    let _resp = app.execute_contract(
        Addr::unchecked(MF.to_owned()),
        contract_addr.to_owned(),
        &ExecuteMsg::MfApproveSalesAgrmt { agrmt_id: 1 },
        &[],
    ).unwrap();

    // get the agrmt
    let sales_agrmt_resp: SalesAgrmtResponse = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::SalesAgrmt { id: 1 }
    ).unwrap();

    assert_eq!(
        sales_agrmt_resp.agrmt.status,
        SalesAgrmtStatus::MfApproved
    );

    // fin approves agrmt
    let payment = coins(40000, DENOM);
    let _resp = app.execute_contract(
        Addr::unchecked(FIN.to_owned()),
        contract_addr.to_owned(),
        &ExecuteMsg::FinApproveSalesAgrmt { agrmt_id: 1 },
        &payment,
    ).unwrap();

    // get the agrmt
    let sales_agrmt_resp: SalesAgrmtResponse = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::SalesAgrmt { id: 1 }
    ).unwrap();

    assert_eq!(
        sales_agrmt_resp.agrmt.status,
        SalesAgrmtStatus::FinApproved
    );
    // financier balance reduced
    let balance = coins(1000000 - Into::<u128>::into(payment[0].amount), DENOM); //Coin::new(1000, DENOM);
    assert_eq!(
        app.wrap()
            .query_balance(Addr::unchecked(FIN.to_string()), DENOM)
            .unwrap()
            .amount
            .u128(),
        Into::into(balance[0].amount)
    );
    // escrow gets paid
    assert_eq!(
        app.wrap()
            .query_balance(contract_addr.to_owned(), DENOM)
            .unwrap()
            .amount
            .u128(),
        Into::into(payment[0].amount)
    );

    // mf transfer nfts
    let _resp = app.execute_contract(
        Addr::unchecked(MF.to_owned()),
        contract_addr.to_owned(),
        &ExecuteMsg::MfTransferNfts { agrmt_id: 1 },
        &[],
    ).unwrap();
    // mf gets paid
    assert_eq!(
        app.wrap()
            .query_balance(MF.to_owned(), DENOM)
            .unwrap()
            .amount
            .u128(),
        Into::into(payment[0].amount)
    );
    // escrow gets reduced to 0
    assert_eq!(
        app.wrap()
            .query_balance(contract_addr.to_owned(), DENOM)
            .unwrap()
            .amount
            .u128(),
        0u128
    );

    // owner and spender
    let owner_of_resp: cw721::OwnerOfResponse = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::OwnerOf { token_id: token_id.to_owned(), include_expired: None })
        .unwrap();

    assert_eq!(
        owner_of_resp,
        cw721::OwnerOfResponse {
            owner: FIN.to_string(),
            approvals: vec![Approval {
                spender: DEALER.to_string(),
                expires: Default::default(),
            }],
        }
    );
    // again: spender should be dealer
    let approvals = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::Approvals {
            token_id: token_id.to_owned(),
            include_expired: None,
        }
    ).unwrap();
    assert_eq!(
        ApprovalsResponse {
            approvals: vec![Approval {
                spender: DEALER.to_string(),
                expires: Default::default(),
            }],
        },
        approvals
    );

    // get the agrmt
    let sales_agrmt_resp: SalesAgrmtResponse = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::SalesAgrmt { id: 1 }
    ).unwrap();

    assert_eq!(
        sales_agrmt_resp.agrmt.status,
        SalesAgrmtStatus::NftsTransferred
    );
}

#[test]
// execute: SubmitSalesAgrmt, MfApproveSalesAgrmt, FinApproveSalesAgrmt, MfTransferNfts, CustomerBuyNft
// query: SalesAgrmt, AllNftsLocked, Approval
fn can_customer_buy_nft() {
    let (mut app, contract_addr, _code_id) = setup_all();

    // Q: how to test version? how to test events from instantiation?
    let token_id = NftTokenId::new(MF, PRODUCT, UNIQUE_ID).token_id();

    let extension = Some(Metadata {
        name: Some(PRODUCT.to_string()),
        attributes: Some(vec![
            Trait {
                display_type: None,
                trait_type: "year".to_string(),
                value: "2024".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "msp".to_string(),
                value: "40000".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "color".to_string(),
                value: "black".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "doors".to_string(),
                value: "4".to_string(),
            },
        ]),
        ..Metadata::default()
    });
    let mint_msg = ExecuteMsg::MintNft {
        mf: MF.to_string(),
        product: PRODUCT.to_string(),
        unique_id: UNIQUE_ID.to_string(),
        token_uri: None,
        extension,
    };
    let _resp = app.execute_contract(
        Addr::unchecked(NFT_MINTER),
        contract_addr.to_owned(),
        &mint_msg,
        &[],
    ).unwrap();

    // sales agrmt
    let items = vec![
        SalesAgrmtItem {
            nft_token_id: token_id.to_owned(),
            dealer_price: 40000,
            fin_cost: 41000,
        },
    ];
    let submit_msg = SubmitSalesAgrmt {
        dealer: DEALER.to_owned(),
        mf: MF.to_owned(),
        fin: FIN.to_owned(),
        items,
    };
    let _resp = app.execute_contract(
        Addr::unchecked(DEALER.to_owned()),
        contract_addr.to_owned(),
        &submit_msg,
        &[],
    ).unwrap();

    // get the agrmt
    let sales_agrmt_resp: SalesAgrmtResponse = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::SalesAgrmt { id: 1 }
    ).unwrap();
    let items = vec![
        SalesAgrmtItem {
            nft_token_id: token_id.to_owned(),
            dealer_price: 40000,
            fin_cost: 41000,
        },
    ];
    let agrmt = SalesAgrmt {
        dealer: Addr::unchecked(DEALER.to_owned()),
        mf: Addr::unchecked(MF.to_owned()),
        fin: Addr::unchecked(FIN.to_owned()),
        total_dealer_price: 40000,
        total_fin_cost: 41000,
        status: SalesAgrmtStatus::Pending,
        items,
    };
    assert_eq!(
        SalesAgrmtResponse {
            id: 1,
            agrmt,
        },
        sales_agrmt_resp
    );

    // MF approve agrmt
    let _resp = app.execute_contract(
        Addr::unchecked(MF.to_owned()),
        contract_addr.to_owned(),
        &ExecuteMsg::MfApproveSalesAgrmt { agrmt_id: 1 },
        &[],
    ).unwrap();

    // get the agrmt
    let sales_agrmt_resp: SalesAgrmtResponse = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::SalesAgrmt { id: 1 }
    ).unwrap();

    assert_eq!(
        sales_agrmt_resp.agrmt.status,
        SalesAgrmtStatus::MfApproved
    );

    // fin approves agrmt
    let payment = coins(40000, DENOM);
    let _resp = app.execute_contract(
        Addr::unchecked(FIN.to_owned()),
        contract_addr.to_owned(),
        &ExecuteMsg::FinApproveSalesAgrmt { agrmt_id: 1 },
        &payment,
    ).unwrap();

    // get the agrmt
    let sales_agrmt_resp: SalesAgrmtResponse = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::SalesAgrmt { id: 1 }
    ).unwrap();

    assert_eq!(
        sales_agrmt_resp.agrmt.status,
        SalesAgrmtStatus::FinApproved
    );
    // financier balance reduced
    let balance = coins(1000000 - Into::<u128>::into(payment[0].amount), DENOM); //Coin::new(1000, DENOM);
    assert_eq!(
        app.wrap()
            .query_balance(Addr::unchecked(FIN.to_string()), DENOM)
            .unwrap()
            .amount
            .u128(),
        Into::into(balance[0].amount)
    );
    // escrow gets paid
    assert_eq!(
        app.wrap()
            .query_balance(contract_addr.to_owned(), DENOM)
            .unwrap()
            .amount
            .u128(),
        Into::into(payment[0].amount)
    );

    // mf transfer nfts
    let _resp = app.execute_contract(
        Addr::unchecked(MF.to_owned()),
        contract_addr.to_owned(),
        &ExecuteMsg::MfTransferNfts { agrmt_id: 1 },
        &[],
    ).unwrap();
    // mf gets paid
    assert_eq!(
        app.wrap()
            .query_balance(MF.to_owned(), DENOM)
            .unwrap()
            .amount
            .u128(),
        Into::into(payment[0].amount)
    );
    // escrow gets reduced to 0
    assert_eq!(
        app.wrap()
            .query_balance(contract_addr.to_owned(), DENOM)
            .unwrap()
            .amount
            .u128(),
        0u128
    );

    // owner and spender
    let owner_of_resp: cw721::OwnerOfResponse = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::OwnerOf { token_id: token_id.to_owned(), include_expired: None })
        .unwrap();

    assert_eq!(
        owner_of_resp,
        cw721::OwnerOfResponse {
            owner: FIN.to_string(),
            approvals: vec![Approval {
                spender: DEALER.to_string(),
                expires: Default::default(),
            }],
        }
    );
    // again: spender should be dealer
    let approvals = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::Approvals {
            token_id: token_id.to_owned(),
            include_expired: None,
        }
    ).unwrap();
    assert_eq!(
        ApprovalsResponse {
            approvals: vec![Approval {
                spender: DEALER.to_string(),
                expires: Default::default(),
            }],
        },
        approvals
    );

    // get the agrmt
    let sales_agrmt_resp: SalesAgrmtResponse = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::SalesAgrmt { id: 1 }
    ).unwrap();

    assert_eq!(
        sales_agrmt_resp.agrmt.status,
        SalesAgrmtStatus::NftsTransferred
    );

    // get nfts locked, expected 1
    let nfts_locked = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::AllNftsLocked { start_after: None, limit: None}
    ).unwrap();
    assert_eq!(
        NftsLockedResponse {
            nfts: vec![NftLockedResponse {
                token_id: token_id.to_owned(),
                agrmt_id: 1,
            }]
        },
        nfts_locked
    );

    // customer buys nft
    let customer_price = 45000;
    let _resp = app.execute_contract(
        Addr::unchecked(CUSTOMER.to_owned()),
        contract_addr.to_owned(),
        &ExecuteMsg::CustomerBuyNft { token_id: token_id.to_owned() },
        &coins(customer_price, DENOM),
    ).unwrap();
    // check fin balance: fin pays 40000 to mf as dealer_price and gets 41000 as fin_cost
    let expected_balane = coins(1000000 - 40000 + 41000, DENOM);
    assert_eq!(
        app.wrap()
            .query_balance(Addr::unchecked(FIN.to_string()), DENOM)
            .unwrap()
            .amount
            .u128(),
        Into::into(expected_balane[0].amount)
    );
    // check dealer balance: dealer gets 45000 from customer and pays 41000 as fin_cost
    let expected_balane = coins(45000 - 41000, DENOM);
    assert_eq!(
        app.wrap()
            .query_balance(Addr::unchecked(DEALER.to_string()), DENOM)
            .unwrap()
            .amount
            .u128(),
        Into::into(expected_balane[0].amount)
    );
    // owner and spender
    let owner_of_resp: cw721::OwnerOfResponse = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::OwnerOf { token_id: token_id.to_owned(), include_expired: None })
        .unwrap();

    assert_eq!(
        owner_of_resp,
        cw721::OwnerOfResponse {
            owner: CUSTOMER.to_string(),
            approvals: vec![],
        }
    );

    // get nfts locked, expected empty
    let nfts_locked = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::AllNftsLocked { start_after: None, limit: None}
    ).unwrap();
    assert_eq!(
        NftsLockedResponse {
            nfts: vec![]
        },
        nfts_locked
    );

}

#[test]
// execute: SubmitSalesAgrmt, CancelSalesAgrmt
// query: AllNftsLocked, SalesAgrmt
fn can_calcel_sales_agrmt() {
    let (mut app, contract_addr, _code_id) = setup_all();

    // Q: how to test version? how to test events from instantiation?
    let token_id = NftTokenId::new(MF, PRODUCT, UNIQUE_ID).token_id();

    let extension = Some(Metadata {
        name: Some(PRODUCT.to_string()),
        attributes: Some(vec![
            Trait {
                display_type: None,
                trait_type: "year".to_string(),
                value: "2024".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "msp".to_string(),
                value: "40000".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "color".to_string(),
                value: "black".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "doors".to_string(),
                value: "4".to_string(),
            },
        ]),
        ..Metadata::default()
    });
    let mint_msg = ExecuteMsg::MintNft {
        mf: MF.to_string(),
        product: PRODUCT.to_string(),
        unique_id: UNIQUE_ID.to_string(),
        token_uri: None,
        extension,
    };
    let _resp = app.execute_contract(
        Addr::unchecked(NFT_MINTER),
        contract_addr.to_owned(),
        &mint_msg,
        &[],
    ).unwrap();

    // sales agrmt
    let items = vec![
        SalesAgrmtItem {
            nft_token_id: token_id.to_owned(),
            dealer_price: 40000,
            fin_cost: 41000,
        },
    ];
    let submit_msg = SubmitSalesAgrmt {
        dealer: DEALER.to_owned(),
        mf: MF.to_owned(),
        fin: FIN.to_owned(),
        items,
    };
    let _resp = app.execute_contract(
        Addr::unchecked(DEALER.to_owned()),
        contract_addr.to_owned(),
        &submit_msg,
        &[],
    ).unwrap();

    // get nfts locked, expected: 1 record
    let nfts_locked = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::AllNftsLocked { start_after: None, limit: None}
    ).unwrap();
    assert_eq!(
        NftsLockedResponse {
            nfts: vec![NftLockedResponse {
                token_id: token_id.to_owned(),
                agrmt_id: 1
            }]
        },
        nfts_locked
    );
    // get the agrmt
    let sales_agrmt_resp: SalesAgrmtResponse = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::SalesAgrmt { id: 1 }
    ).unwrap();

    assert_eq!(
        sales_agrmt_resp.agrmt.status,
        SalesAgrmtStatus::Pending
    );

    // cancel the agrmt
    let _resp = app.execute_contract(
        Addr::unchecked(DEALER.to_owned()),
        contract_addr.to_owned(),
        &ExecuteMsg::CancelSalesAgrmt { agrmt_id: 1},
        &[],
    ).unwrap();

    // get nfts locked, expected empty
    let nfts_locked = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::AllNftsLocked { start_after: None, limit: None}
    ).unwrap();
    assert_eq!(
        NftsLockedResponse {
            nfts: vec![]
        },
        nfts_locked
    );

    // get the agrmt
    let sales_agrmt_resp: SalesAgrmtResponse = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::SalesAgrmt { id: 1 }
    ).unwrap();

    assert_eq!(
        sales_agrmt_resp.agrmt.status,
        SalesAgrmtStatus::Canceled
    );
}

#[test]
// execute: SubmitSalesAgrmt, MfRejectSalesAgrmt
// query: AllNftsLocked, SalesAgrmt
fn can_mf_reject_sales_agrmt() {
    let (mut app, contract_addr, _code_id) = setup_all();

    // Q: how to test version? how to test events from instantiation?
    let token_id = NftTokenId::new(MF, PRODUCT, UNIQUE_ID).token_id();

    let extension = Some(Metadata {
        name: Some(PRODUCT.to_string()),
        attributes: Some(vec![
            Trait {
                display_type: None,
                trait_type: "year".to_string(),
                value: "2024".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "msp".to_string(),
                value: "40000".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "color".to_string(),
                value: "black".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "doors".to_string(),
                value: "4".to_string(),
            },
        ]),
        ..Metadata::default()
    });
    let mint_msg = ExecuteMsg::MintNft {
        mf: MF.to_string(),
        product: PRODUCT.to_string(),
        unique_id: UNIQUE_ID.to_string(),
        token_uri: None,
        extension,
    };
    let _resp = app.execute_contract(
        Addr::unchecked(NFT_MINTER),
        contract_addr.to_owned(),
        &mint_msg,
        &[],
    ).unwrap();

    // sales agrmt
    let items = vec![
        SalesAgrmtItem {
            nft_token_id: token_id.to_owned(),
            dealer_price: 40000,
            fin_cost: 41000,
        },
    ];
    let submit_msg = SubmitSalesAgrmt {
        dealer: DEALER.to_owned(),
        mf: MF.to_owned(),
        fin: FIN.to_owned(),
        items,
    };
    let _resp = app.execute_contract(
        Addr::unchecked(DEALER.to_owned()),
        contract_addr.to_owned(),
        &submit_msg,
        &[],
    ).unwrap();

    // get nfts locked, expected: 1 record
    let nfts_locked = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::AllNftsLocked { start_after: None, limit: None}
    ).unwrap();
    assert_eq!(
        NftsLockedResponse {
            nfts: vec![NftLockedResponse {
                token_id: token_id.to_owned(),
                agrmt_id: 1
            }]
        },
        nfts_locked
    );
    // get the agrmt
    let sales_agrmt_resp: SalesAgrmtResponse = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::SalesAgrmt { id: 1 }
    ).unwrap();

    assert_eq!(
        sales_agrmt_resp.agrmt.status,
        SalesAgrmtStatus::Pending
    );

    // mf reject the agrmt
    let _resp = app.execute_contract(
        Addr::unchecked(MF.to_owned()),
        contract_addr.to_owned(),
        &ExecuteMsg::MfRejectSalesAgrmt { agrmt_id: 1},
        &[],
    ).unwrap();

    // get nfts locked, expected empty
    let nfts_locked = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::AllNftsLocked { start_after: None, limit: None}
    ).unwrap();
    assert_eq!(
        NftsLockedResponse {
            nfts: vec![]
        },
        nfts_locked
    );

    // get the agrmt
    let sales_agrmt_resp: SalesAgrmtResponse = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::SalesAgrmt { id: 1 }
    ).unwrap();

    assert_eq!(
        sales_agrmt_resp.agrmt.status,
        SalesAgrmtStatus::MfRejected
    );
}

#[test]
// execute: SubmitSalesAgrmt, FinRejectSalesAgrmt
// query: AllNftsLocked, SalesAgrmt, NftsLockedByAgrmtId
fn can_fin_reject_sales_agrmt() {
    let (mut app, contract_addr, _code_id) = setup_all();

    // Q: how to test version? how to test events from instantiation?
    let token_id = NftTokenId::new(MF, PRODUCT, UNIQUE_ID).token_id();

    let extension = Some(Metadata {
        name: Some(PRODUCT.to_string()),
        attributes: Some(vec![
            Trait {
                display_type: None,
                trait_type: "year".to_string(),
                value: "2024".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "msp".to_string(),
                value: "40000".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "color".to_string(),
                value: "black".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "doors".to_string(),
                value: "4".to_string(),
            },
        ]),
        ..Metadata::default()
    });
    let mint_msg = ExecuteMsg::MintNft {
        mf: MF.to_string(),
        product: PRODUCT.to_string(),
        unique_id: UNIQUE_ID.to_string(),
        token_uri: None,
        extension,
    };
    let _resp = app.execute_contract(
        Addr::unchecked(NFT_MINTER),
        contract_addr.to_owned(),
        &mint_msg,
        &[],
    ).unwrap();

    // sales agrmt
    let items = vec![
        SalesAgrmtItem {
            nft_token_id: token_id.to_owned(),
            dealer_price: 40000,
            fin_cost: 41000,
        },
    ];
    let submit_msg = SubmitSalesAgrmt {
        dealer: DEALER.to_owned(),
        mf: MF.to_owned(),
        fin: FIN.to_owned(),
        items,
    };
    let _resp = app.execute_contract(
        Addr::unchecked(DEALER.to_owned()),
        contract_addr.to_owned(),
        &submit_msg,
        &[],
    ).unwrap();

    // get nfts locked, expected: 1 record
    let nfts_locked = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::NftsLockedByAgrmtId { agrmt_id: 1, start_after: None, limit: None}
    ).unwrap();
    assert_eq!(
        NftsLockedResponse {
            nfts: vec![NftLockedResponse {
                token_id: token_id.to_owned(),
                agrmt_id: 1
            }]
        },
        nfts_locked
    );
    // get the agrmt
    let sales_agrmt_resp: SalesAgrmtResponse = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::SalesAgrmt { id: 1 }
    ).unwrap();

    assert_eq!(
        sales_agrmt_resp.agrmt.status,
        SalesAgrmtStatus::Pending
    );

    // mf reject the agrmt
    let _resp = app.execute_contract(
        Addr::unchecked(FIN.to_owned()),
        contract_addr.to_owned(),
        &ExecuteMsg::FinRejectSalesAgrmt { agrmt_id: 1},
        &[],
    ).unwrap();

    // get nfts locked, expected empty
    let nfts_locked = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::AllNftsLocked { start_after: None, limit: None}
    ).unwrap();
    assert_eq!(
        NftsLockedResponse {
            nfts: vec![]
        },
        nfts_locked
    );

    // get the agrmt
    let sales_agrmt_resp: SalesAgrmtResponse = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::SalesAgrmt { id: 1 }
    ).unwrap();

    assert_eq!(
        sales_agrmt_resp.agrmt.status,
        SalesAgrmtStatus::FinRejected
    );
}

#[test]
fn can_send_coin() {
    let (mut app, contract_addr, _code_id) = setup_all();

    // check balances before send_coin
    let customer_bal = app.wrap().query_balance(CUSTOMER.to_owned(), DENOM).unwrap();
    let dealer_bal = app.wrap().query_balance(DEALER.to_owned(), DENOM).unwrap();
    let customer_amount = u128::from(customer_bal.amount);

    assert_eq!(dealer_bal, coins(0, DENOM)[0]);

    // send_coin
    let send_amount = 10000;
    assert!(customer_amount >= send_amount);

    let _ = app.execute_contract(
        Addr::unchecked(CUSTOMER.to_owned()),
        contract_addr.to_owned(),
        &ExecuteMsg::SendCoin { recipient: DEALER.to_owned(),},
        &coins(send_amount, DENOM),
    ).unwrap();

    let customer_bal = app.wrap().query_balance(CUSTOMER.to_owned(), DENOM).unwrap();
    let dealer_bal = app.wrap().query_balance(DEALER.to_owned(), DENOM).unwrap();

    assert_eq!(customer_bal, coins(customer_amount - send_amount, DENOM)[0]);
    assert_eq!(dealer_bal, coins(send_amount, DENOM)[0]);

}

#[test]
// use cw721 message
fn can_mint_cw721() {
    let (mut app, contract_addr, _code_id) = setup_all();

    // Q: how to test version? how to test events from instantiation?
    let token_id = NftTokenId::new(MF, PRODUCT, UNIQUE_ID).token_id();

    let extension = Some(Metadata {
        name: Some(PRODUCT.to_string()),
        attributes: Some(vec![
            Trait {
                display_type: None,
                trait_type: "year".to_string(),
                value: "2024".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "msp".to_string(),
                value: "40000".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "color".to_string(),
                value: "black".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "doors".to_string(),
                value: "4".to_string(),
            },
        ]),
        ..Metadata::default()
    });
    let mint_msg = ExecuteMsg::Cw721(
        Df721ExecuteMsg::Mint {
            token_id: token_id.to_string(),
            owner: MF.to_string(),
            token_uri: None,
            extension,
        }
    );
    let _resp = app.execute_contract(
        Addr::unchecked(NFT_MINTER),
        contract_addr.to_owned(),
        &mint_msg,
        &[],
    ).unwrap();

    // query config
    let config: Config = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::Config {})
        .unwrap();

    assert_eq!(
        config,
        Config {
            owner: Addr::unchecked(OWNER.to_string()),
            denom: DENOM.to_string(),
            nft_minter: Addr::unchecked(NFT_MINTER.to_string()),
            sales_agrmt_id: 0,
        }
    );
    // query contract info
    let contract_info_resp: cw721::ContractInfoResponse = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::ContractInfo {})
        .unwrap();

    assert_eq!(
        contract_info_resp,
        cw721::ContractInfoResponse {
            name: CONTRACT_NAME.to_string(),
            symbol: CONTRACT_NAME.to_string(),
        }
    );
    // query minter
    let minter_resp: cw721_base::MinterResponse = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::Minter {})
        .unwrap();

    assert_eq!(
        minter_resp,
        cw721_base::MinterResponse {
            minter: Some(NFT_MINTER.to_string()),
        }
    );
    // num tokens
    let num_token_resp: cw721::NumTokensResponse = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::NumTokens {})
        .unwrap();

    assert_eq!(
        num_token_resp,
        cw721::NumTokensResponse {
            count: 1,
        }
    );
    // nft info
    let nft_info_resp: cw721::NftInfoResponse<Extension> = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::NftInfo { token_id: token_id.to_string() })
        .unwrap();

    assert_eq!(
        nft_info_resp,
        cw721::NftInfoResponse::<Extension> {
            token_uri: None,
            extension: Some(Metadata {
                name: Some(PRODUCT.to_string()),
                attributes: Some(vec![
                    Trait {
                        display_type: None,
                        trait_type: "year".to_string(),
                        value: "2024".to_string(),
                    },
                    Trait {
                        display_type: None,
                        trait_type: "msp".to_string(),
                        value: "40000".to_string(),
                    },
                    Trait {
                        display_type: None,
                        trait_type: "color".to_string(),
                        value: "black".to_string(),
                    },
                    Trait {
                        display_type: None,
                        trait_type: "doors".to_string(),
                        value: "4".to_string(),
                    },
                ]),
                ..Metadata::default()
            }),
        }
    )
}

#[test]
// use cw721 message
fn can_transfer_nft_cw721() {
    let (mut app, contract_addr, _code_id) = setup_all();

    // Q: how to test version? how to test events from instantiation?
    let token_id = NftTokenId::new(MF, PRODUCT, UNIQUE_ID).token_id();

    let extension = Some(Metadata {
        name: Some(PRODUCT.to_string()),
        attributes: Some(vec![
            Trait {
                display_type: None,
                trait_type: "year".to_string(),
                value: "2024".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "msp".to_string(),
                value: "40000".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "color".to_string(),
                value: "black".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "doors".to_string(),
                value: "4".to_string(),
            },
        ]),
        ..Metadata::default()
    });
    let mint_msg = ExecuteMsg::Cw721(
        Df721ExecuteMsg::Mint {
            token_id: token_id.to_string(),
            owner: MF.to_string(),
            token_uri: None,
            extension,
        }
    );
    let _resp = app.execute_contract(
        Addr::unchecked(NFT_MINTER),
        contract_addr.to_owned(),
        &mint_msg,
        &[],
    ).unwrap();

    // current owner
    let owner_of_resp: cw721::OwnerOfResponse = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::OwnerOf { token_id: token_id.to_owned(), include_expired: None })
        .unwrap();

    assert_eq!(
        owner_of_resp,
        cw721::OwnerOfResponse {
            owner: MF.to_string(),
            approvals: vec![],
        }
    );

    // transfer to FIN
    let transfer_msg = ExecuteMsg::Cw721(
        Df721ExecuteMsg::TransferNft { recipient: FIN.to_string(), token_id: token_id.to_owned() }
    );
    let _resp = app.execute_contract(
        Addr::unchecked(MF),
        contract_addr.to_owned(),
        &transfer_msg,
        &[],
    ).unwrap();

    // new owner
    let owner_of_resp: cw721::OwnerOfResponse = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::OwnerOf { token_id, include_expired: None })
        .unwrap();

    assert_eq!(
        owner_of_resp,
        cw721::OwnerOfResponse {
            owner: FIN.to_string(),
            approvals: vec![],
        }
    );
}

#[test]
// use cw721 message
fn can_burn_nft_cw721() {
    let (mut app, contract_addr, _code_id) = setup_all();

    // Q: how to test version? how to test events from instantiation?
    let token_id = NftTokenId::new(MF, PRODUCT, UNIQUE_ID).token_id();

    let extension = Some(Metadata {
        name: Some(PRODUCT.to_string()),
        attributes: Some(vec![
            Trait {
                display_type: None,
                trait_type: "year".to_string(),
                value: "2024".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "msp".to_string(),
                value: "40000".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "color".to_string(),
                value: "black".to_string(),
            },
            Trait {
                display_type: None,
                trait_type: "doors".to_string(),
                value: "4".to_string(),
            },
        ]),
        ..Metadata::default()
    });
    let mint_msg = ExecuteMsg::Cw721(
        Df721ExecuteMsg::Mint {
            token_id: token_id.to_string(),
            owner: MF.to_string(),
            token_uri: None,
            extension,
        }
    );
    let _resp = app.execute_contract(
        Addr::unchecked(NFT_MINTER),
        contract_addr.to_owned(),
        &mint_msg,
        &[],
    ).unwrap();

    // current owner
    let owner_of_resp: cw721::OwnerOfResponse = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::OwnerOf { token_id: token_id.to_owned(), include_expired: None })
        .unwrap();

    assert_eq!(
        owner_of_resp,
        cw721::OwnerOfResponse {
            owner: MF.to_string(),
            approvals: vec![],
        }
    );

    // burn
    let burn_msg = ExecuteMsg::Cw721(
        Df721ExecuteMsg::Burn { token_id: token_id.to_owned() }
    );
    let _resp = app.execute_contract(
        Addr::unchecked(MF),
        contract_addr.to_owned(),
        &burn_msg,
        &[],
    ).unwrap();

    // check token has been removed
    let err: StdResult<cw721::NftInfoResponse<Extension>> = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::NftInfo { token_id });

    let err = err.unwrap_err();

    assert_eq!(
        cosmwasm_std::StdError::GenericErr {msg: "Querier contract error: cw721_base::state::TokenInfo<core::option::Option<cw721_metadata_onchain::Metadata>> not found".to_string()},
        err
    );

}