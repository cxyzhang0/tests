use cosmwasm_std::{Empty, StdError, StdResult};
use cw721_metadata_onchain::{Extension};
// use cw721_metadata_onchain::{Extension, Metadata, Trait};
use crate::error::ContractError;
use regex::Regex;

pub type Df721Contract<'a> = cw721_base::Cw721Contract<'a, Extension, Empty, Empty, Empty>;
pub type Df721MoContract<'a> = cw721_metadata_onchain::Cw721MetadataContract<'a>;

pub type Df721InstantiateMsg = cw721_base::InstantiateMsg;

pub type Df721MoExecuteMsg = cw721_metadata_onchain::ExecuteMsg;
pub type Df721MoQueryMsg = cw721_metadata_onchain::QueryMsg;
pub type Df721QueryMsg<Q> = cw721_base::QueryMsg<Q>;
pub type Df721ExecuteMsg = cw721_base::ExecuteMsg<Extension, Empty>;

#[derive(Copy, Debug, Clone, PartialEq, Eq)]
// Canonical DiFi NFT token id definition with its implemention
pub struct NftTokenId <'a> {
    // manufacture's address string
    pub mf: &'a str,
    // manufacture's product
    pub product:  &'a str,
    // unique identifier for (mf, product)
    pub unique_id:  &'a str,
}

// Get the u128 value for a given key in a given extension, e.g., key = "msp"
pub fn get_attr_u128(extension: &Extension, key: &str) -> Result<u128, ContractError> {
    if extension.is_none() {
        return Err(ContractError::InvalidExtension)
    }
    let extension = extension.as_ref().unwrap();
    if extension.attributes.is_none() {
        return Err(ContractError::InvalidExtension)
    };
    let attrs = extension.attributes.as_ref().unwrap();

    for attr in attrs {
        if attr.trait_type == key.to_string() {
            let v = attr.value.parse::<u128>();
            if v.is_err() {
                return Err(ContractError::InvalidExtension)
            }

            return Ok(v.unwrap())
        }
    }
    Err(ContractError::KeyNotFound { key: key.to_string() })
}

impl <'a> NftTokenId <'a> {
    pub fn new(mf: &'a str, product: &'a str, unique_id: &'a str) -> Self {
        Self {
            mf,
            product,
            unique_id,
        }
    }

    pub fn token_id(&self) -> String {
        format!("{}:{}:{}", self.mf, self.product, self.unique_id)
    }

    pub fn to_string(&self) -> String {
        self.token_id()
    }

    pub fn from_string(token_id: &'a str) -> StdResult<Self> {
        let re = Regex::new(r".*:.+:.+").unwrap();
        if !re.is_match(token_id) {
            Err(StdError::GenericErr { msg: format!("token_id {} has incorrect format, expected {}", token_id, re.to_string()) })
        } else {
            re.split(token_id);
            let parts: Vec<&str> = token_id.split(':').collect();
            if parts.len() != 3 {
                Err(StdError::GenericErr { msg: format!("token_id {} must have 2 {}s", token_id, ":") })
            } else {
                Ok(Self {
                    mf: parts[0],
                    product: parts[1],
                    unique_id: parts[2],
                })
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn can_to_string () {
        let nft_token_id = NftTokenId {
            mf: "Toyoto",
            product: "Prius",
            unique_id: "VIN1",
        };
        let token_id = nft_token_id.token_id();
        assert_eq!(
            token_id,
            "Toyoto:Prius:VIN1"
        )
    }

    #[test]
    fn can_from_string () {
        let nft_token_id = NftTokenId {
            mf: "Toyoto",
            product: "Prius",
            unique_id: "VIN1",
        };
        let token_id = nft_token_id.token_id();
        assert_eq!(
            token_id,
            "Toyoto:Prius:VIN1"
        );

        assert_eq!(
            nft_token_id,
            NftTokenId::from_string(&token_id).unwrap()
        )
    }

    #[test]
    fn fail_from_string_incorect_format () {
        let token_id = "Toyoto:Prius";

        let err = NftTokenId::from_string(&token_id).unwrap_err();

        let re = Regex::new(r".*:.+:.+").unwrap();
        assert_eq!(
            err,
            StdError::GenericErr { msg: format!("token_id {} has incorrect format, expected {}", token_id, re.to_string()) }
        )
    }

    #[test]
    fn fail_from_string_too_many_delimiters () {
        let token_id = "Toyoto:Prius:VIN1:extra";

        let err = NftTokenId::from_string(&token_id).unwrap_err();

        assert_eq!(
            err,
            StdError::GenericErr { msg: format!("token_id {} must have 2 {}s", token_id, ":") }
        )
    }

    #[test]
    fn can_get_msp() {
        let extension = Some(cw721_metadata_onchain::Metadata {
            name: Some("product".to_string()),
            attributes: Some(vec![
                cw721_metadata_onchain::Trait {
                    display_type: None,
                    trait_type: "year".to_string(),
                    value: "2024".to_string(),
                },
                cw721_metadata_onchain::Trait {
                    display_type: None,
                    trait_type: "msp".to_string(),
                    value: "40000".to_string(),
                },
                cw721_metadata_onchain::Trait {
                    display_type: None,
                    trait_type: "color".to_string(),
                    value: "black".to_string(),
                },
                cw721_metadata_onchain::Trait {
                    display_type: None,
                    trait_type: "doors".to_string(),
                    value: "4".to_string(),
                },
            ]),
            ..cw721_metadata_onchain::Metadata::default()
        });
        let dealer_price = get_attr_u128(&extension, "msp").unwrap();
        assert_eq! {
            40000,
            dealer_price
        }
    }

    #[test]
    fn fail_get_dealer_price() {
        // typo
        let extension = Some(cw721_metadata_onchain::Metadata {
            name: Some("product".to_string()),
            attributes: Some(vec![
                cw721_metadata_onchain::Trait {
                    display_type: None,
                    trait_type: "year".to_string(),
                    value: "2024".to_string(),
                },
                cw721_metadata_onchain::Trait {
                    display_type: None,
                    trait_type: "xxxxxmsp".to_string(),
                    value: "40000".to_string(),
                },
                cw721_metadata_onchain::Trait {
                    display_type: None,
                    trait_type: "color".to_string(),
                    value: "black".to_string(),
                },
                cw721_metadata_onchain::Trait {
                    display_type: None,
                    trait_type: "doors".to_string(),
                    value: "4".to_string(),
                },
            ]),
            ..cw721_metadata_onchain::Metadata::default()
        });
        let dealer_price = get_attr_u128(&extension, "msp").unwrap_err();
        assert_eq! {
            ContractError::KeyNotFound { key: "msp".to_string() },
            // ContractError::InvalidExtension,
            dealer_price
        }

        // no attributes
        let extension = Some(cw721_metadata_onchain::Metadata {
            name: Some("product".to_string()),
            attributes: None,
            ..cw721_metadata_onchain::Metadata::default()
        });
        let dealer_price = get_attr_u128(&extension, "msp").unwrap_err();
        assert_eq! {
            ContractError::InvalidExtension,
            dealer_price
        }

        // no metadata
        let extension = None;
        let dealer_price = get_attr_u128(&extension, "msp").unwrap_err();
        assert_eq! {
            ContractError::InvalidExtension,
            dealer_price
        }
    }
}