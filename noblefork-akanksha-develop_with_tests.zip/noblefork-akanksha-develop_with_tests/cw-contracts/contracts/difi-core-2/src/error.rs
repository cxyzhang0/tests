use cosmwasm_std::{Addr, StdError};
use cw_utils::PaymentError;
use thiserror::Error;

#[derive(Error, Debug, PartialEq)]
pub enum ContractError {
    #[error("{0}")]
    StdError(#[from] StdError),
    #[error("Payment error: {0}")]
    PaymentError(#[from] PaymentError),
    #[error(transparent)]
    Cw721ContractError(#[from]  cw721_base::ContractError),

    #[error("{sender} is not authorized to perform the function")]
    Unauthorized { sender: Addr },
    #[error("NFT token does not have valid extension")]
    InvalidExtension,
    #[error("Expected: {expected}, Got: {got}")]
    InvalidDenom { expected: String, got: String },
    #[error("Expected: {expected}, Got: {got}")]
    InvalidStatus { expected: String, got: String },
    #[error("({minter} {product}) {token_id} exists")]
    TokenExists { minter: Addr, product: String, token_id: String },
    #[error("Sales Agreement with id {id} does not exist")]
    SalesAgrmtNotExist { id: u64 },
    #[error("Sales Agreement with no items cannot be submitted")]
    SalesAgrmtEmptyItems {},
    #[error("Payment amount is incorrect. Expected: {expected}, Got: {got}")]
    IncorrectAmount { expected: u128, got: u128 },
    #[error("Insuffficient payment amount")]
    InsufficientAmount {},
    #[error("Key {key} is not found")]
    KeyNotFound { key: String },
    #[error("Expected: {expected}, Got: {got}")]
    WrongOwner { expected: Addr, got: Addr },
    #[error("{token_id} is locked")]
    NftLocked { token_id: String },

}