use cosmwasm_schema::{cw_serde, QueryResponses};
use cw721_metadata_onchain::{Extension};
// pub use cw721_base::{InstantiateMsg as Cw721InstantiateMsg};
use crate::state::{Config, SalesAgrmt, SalesAgrmtItem};
use crate::df721_mo::*;


#[cw_serde]
pub struct InstantiateMsg {
    pub denom: String,
    pub nft_minter: String,
}

#[cw_serde]
pub enum ExecuteMsg {
    MintNft {
        // this is the manufacturer's address, not its name. it will be the owner of this newly minted NFT
        mf: String,
        product: String,
        unique_id: String,
        token_uri: Option<String>,
        extension: Extension,
    },
    TransferNft {
        token_id: String,
        recipient: String,
    },
    TransferNftByNftTokenId {
        mf: String, // this is the manufacturer's address, not its name.
        product: String,
        unique_id: String,
        recipient: String,
    },
    SubmitSalesAgrmt {
        dealer: String,
        mf: String,
        fin: String,
        items: Vec<SalesAgrmtItem>,
    },
    MfApproveSalesAgrmt {
        agrmt_id: u64,
    },
    MfTransferNfts {
        agrmt_id: u64,
    },
    CustomerBuyNft {
        token_id: String,
    },
    FinApproveSalesAgrmt {
        agrmt_id: u64,
    },
    CancelSalesAgrmt {
        agrmt_id: u64,
    },
    MfRejectSalesAgrmt {
        agrmt_id: u64,
    },
    FinRejectSalesAgrmt {
        agrmt_id: u64,
    },
    SendCoin { recipient: String },
    // this api for dev unit tests only
    Cw721(Df721ExecuteMsg),

}

#[cw_serde]
#[derive(QueryResponses)]
pub enum QueryMsg {
// pub enum QueryMsg<Q: JsonSchema> {
    #[returns(Config)]
    Config {},

    /// Return a SalesAgrmt for the given id
    #[returns(SalesAgrmtResponse)]
    SalesAgrmt {
        id: u64,
    },

    /// With Enumerable extension
    /// Return all SalesAgrmts in contract
    #[returns(SalesAgrmtsResponse)]
    AllSalesAgrmts {
        start_after: Option<u64>,
        limit: Option<u32>,
    },

    /// With Enumerable extension
    /// Return all SalesAgrmts in contract for the given dealer
    /// This uses idealer index
    #[returns(SalesAgrmtsResponse)]
    SalesAgrmtsByDealer {
        dealer: String,
        start_after: Option<u64>,
        limit: Option<u32>,
    },

    /// With Enumerable extension
    /// Return all SalesAgrmts in contract for the given mf
    /// This uses imf index
    #[returns(SalesAgrmtsResponse)]
    SalesAgrmtsByMf {
        mf: String,
        start_after: Option<u64>,
        limit: Option<u32>,
    },

    /// With Enumerable extension
    /// Return all SalesAgrmts in contract for the given fin
    /// This uses ifin index
    #[returns(SalesAgrmtsResponse)]
    SalesAgrmtsByFin {
        fin: String,
        start_after: Option<u64>,
        limit: Option<u32>,
    },

    /// With Enumerable extension
    /// Return all NFTs locked
    #[returns(NftsLockedResponse)]
    AllNftsLocked {
        start_after: Option<String>,
        limit: Option<u32>,
    },

    /// With Enumerable extension
    /// Return NFTs locked by a given agrmt_id
    /// This uses iagrmt_id index
    #[returns(NftsLockedResponse)]
    NftsLockedByAgrmtId {
        agrmt_id: u64,
        start_after: Option<String>,
        limit: Option<u32>,
    },

    /// Return balances of a given address
    /// NOTE: no pagination since we don't expect many denominations per address.
    #[returns(CoinBalancesResponse)]
    CoinBalances {
        address: String,
    },

    /// Return NftInfo of all tokens by a given owner
    #[returns(NftInfoListResponse<Extension>)]
    NftInfoList {
        owner: String,
        start_after: Option<String>,
        limit: Option<u32>,
    },

    /// Return the owner of the given token, error if token does not exist
    #[returns(cw721::OwnerOfResponse)]
    OwnerOf {
        token_id: String,
        /// unset or false will filter out expired approvals, you must set to true to see them
        include_expired: Option<bool>,
    },
    /// Return operator that can access all of the owner's tokens.
    #[returns(cw721::ApprovalResponse)]
    Approval {
        token_id: String,
        spender: String,
        include_expired: Option<bool>,
    },
    /// Return approvals that a token has
    #[returns(cw721::ApprovalsResponse)]
    Approvals {
        token_id: String,
        include_expired: Option<bool>,
    },
    // this is 0.17.0
    // /// Return approval of a given operator for all tokens of an owner, error if not set
    // #[returns(cw721::OperatorResponse)]
    // Operator {
    //     owner: String,
    //     operator: String,
    //     include_expired: Option<bool>,
    // },
    /// List all operators that can access all of the owner's tokens
    #[returns(cw721::OperatorsResponse)]
    AllOperators {
        owner: String,
        /// unset or false will filter out expired items, you must set to true to see them
        include_expired: Option<bool>,
        start_after: Option<String>,
        limit: Option<u32>,
    },
    /// Total number of tokens issued
    #[returns(cw721::NumTokensResponse)]
    NumTokens {},

    /// With MetaData Extension.
    /// Returns top-level metadata about the contract
    #[returns(cw721::ContractInfoResponse)]
    ContractInfo {},
    /// With MetaData Extension.
    /// Returns metadata about one particular token, based on *ERC721 Metadata JSON Schema*
    /// but directly from the contract
    #[returns(cw721::NftInfoResponse<Extension>)]
    NftInfo { token_id: String },
    /// With MetaData Extension.
    /// Returns the result of both `NftInfo` and `OwnerOf` as one query as an optimization
    /// for clients
    #[returns(cw721::AllNftInfoResponse<Extension>)]
    AllNftInfo {
        token_id: String,
        /// unset or false will filter out expired approvals, you must set to true to see them
        include_expired: Option<bool>,
    },

    /// With Enumerable extension.
    /// Returns all tokens owned by the given address, [] if unset.
    #[returns(cw721::TokensResponse)]
    Tokens {
        owner: String,
        start_after: Option<String>,
        limit: Option<u32>,
    },
    /// With Enumerable extension.
    /// Requires pagination. Lists all token_ids controlled by the contract.
    #[returns(cw721::TokensResponse)]
    AllTokens {
        start_after: Option<String>,
        limit: Option<u32>,
    },

    /// Return the minter
    #[returns(cw721_base::MinterResponse)]
    Minter {},

    /// Extension query
    #[returns(())]
    Extension { msg: Extension },

}

#[cw_serde]
pub struct SalesAgrmtResponse {
    pub id: u64,
    pub agrmt: SalesAgrmt,
}
#[cw_serde]
pub struct SalesAgrmtsResponse {
    pub agrmts: Vec<SalesAgrmtResponse>,
}

#[cw_serde]
pub struct NftsLockedResponse {
    pub nfts: Vec<NftLockedResponse>
}
#[cw_serde]
pub struct NftLockedResponse {
    pub token_id: String,
    pub agrmt_id: u64,
}

#[cw_serde]
pub struct CoinBalancesResponse {
    pub balances: Vec<CoinBalanceResponse>
}
#[cw_serde]
pub struct CoinBalanceResponse {
    pub denom: String,
    pub amount: String,
}

#[cw_serde]
pub struct DifiNftInfoResponse<Extension> {
    pub token_id: String,
    pub info: cw721::NftInfoResponse<Extension>,
}

#[cw_serde]
pub struct NftInfoListResponse<Extension> {
    pub info_list: Vec<DifiNftInfoResponse<Extension>>,
}