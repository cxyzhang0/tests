# Demo Flow via CLI
> Pre-requisite: [Build wasm](install.md)

* Demo 1: uwfusd
* Demo 2: Use ibc token ibc/E2BD6751F0AA4E2039E5AF627D72CF856859F31A5FD10C5692347964ADD4F4A6 (See the note in install.md for this and the comments down below)

## Smart Contract - Queries and Transactions

### Query

#### ContractInfo {}
```bash
JSON=$(jq -n '{ contract_info: {} }') && \
difid query wasm contract-state smart $CONTRACT_ADDRESS_DIFI "$JSON" $NODE_DIFI --output json | jq
```

#### Config {}
```bash
JSON=$(jq -n '{ config: {} }') && \
difid query wasm contract-state smart $CONTRACT_ADDRESS_DIFI "$JSON" $NODE_DIFI --output json | jq
```

#### Minter {}
```bash
JSON=$(jq -n '{ minter: {} }') && \
difid query wasm contract-state smart $CONTRACT_ADDRESS_DIFI "$JSON" $NODE_DIFI --output json | jq
```

#### NumTokens {}
```bash
JSON=$(jq -n '{ num_tokens: {} }') && \
difid query wasm contract-state smart $CONTRACT_ADDRESS_DIFI "$JSON" $NODE_DIFI --output json | jq 
```

#### NftInfo { token_id } 
```bash
JSON=$(jq -n --arg token_id "$TOYOTA:prius:VIN1" '{ nft_info: { token_id: $token_id } }') && \
RES=$(difid query wasm contract-state smart $CONTRACT_ADDRESS_DIFI "$JSON" $NODE_DIFI --output json) && \
echo $RES | jq
```

#### AllTokens {}
```bash
JSON=$(jq -n '{ all_tokens: {} }') && \
difid query wasm contract-state smart $CONTRACT_ADDRESS_DIFI "$JSON" $NODE_DIFI --output json | jq 
```

#### Tokens { owner }
```bash
JSON=$(jq -n --arg owner $TOYOTA '{ tokens: { owner: $owner } }') && \
RES=$(difid query wasm contract-state smart $CONTRACT_ADDRESS_DIFI "$JSON" $NODE_DIFI --output json) && \
echo $RES | jq
```

#### SalesAgrmt { id }
```bash
JSON=$(jq -n --arg id 1 '{ "sales_agrmt": { id: $id | tonumber } }') && \
RES=$(difid query wasm contract-state smart $CONTRACT_ADDRESS_DIFI "$JSON" $NODE_DIFI --output json) && \
echo $RES | jq
```

#### AllSalesAgrmts { start_after, limit }
```bash
JSON=$(jq -n '{ all_sales_agrmts: {} }') && \
RES=$(difid query wasm contract-state smart $CONTRACT_ADDRESS_DIFI "$JSON" $NODE_DIFI --output json) && \
echo $RES | jq
```

#### SalesAgrmtsByDealer { dealer, start_after, limit }
```bash
JSON=$(jq -n --arg dealer $DEALER1 '{ "sales_agrmts_by_dealer": { dealer: $dealer } }') && \
RES=$(difid query wasm contract-state smart $CONTRACT_ADDRESS_DIFI "$JSON" $NODE_DIFI --output json) && \
echo $RES | jq
```

#### SalesAgrmtsByMf { mf, start_after, limit }
```bash
JSON=$(jq -n --arg mf $TOYOTA '{ "sales_agrmts_by_mf": { mf: $mf} }') && \
RES=$(difid query wasm contract-state smart $CONTRACT_ADDRESS_DIFI "$JSON" $NODE_DIFI --output json) && \
echo $RES | jq
```

#### SalesAgrmtsByFin { fin, start_after, limit }
```bash
JSON=$(jq -n --arg fin $WFC '{ "sales_agrmts_by_fin": { fin: $fin} }') && \
RES=$(difid query wasm contract-state smart $CONTRACT_ADDRESS_DIFI "$JSON" $NODE_DIFI --output json) && \
echo $RES | jq
```

#### CoinBalances { address }
```bash
JSON=$(jq -n --arg address $WFC '{ "coin_balances": { address: $address } }') && \
RES=$(difid query wasm contract-state smart $CONTRACT_ADDRESS_DIFI "$JSON" $NODE_DIFI --output json) && \
echo $RES | jq
```

#### NftInfoList { owner, start_after, limit }
```bash
JSON=$(jq -n --arg owner $TOYOTA '{ "nft_info_list": { owner: $owner} }') && \
RES=$(difid query wasm contract-state smart $CONTRACT_ADDRESS_DIFI "$JSON" $NODE_DIFI --output json) && \
echo $RES | jq
```

### Execute

#### mint_nft: VIN1
Make sure VIN is unique
```bash
JSON=$(jq -n --arg mf $TOYOTA --arg product "prius" --arg unique_id "VIN1" \
--arg k1 "year" --arg v1 "2024" --arg k2 "msp" --arg v2 "40000" --arg k3 "color" --arg v3 "black" --arg k4 "doors" --arg v4 "4" \
'{ "mint_nft": { "mf": $mf, "product": $product, "unique_id": $unique_id, "extension": { "name": $unique_id, "attributes": [ { "trait_type": $k1, "value": $v1 }, { "trait_type": $k2, "value": $v2 }, { "trait_type": $k3, "value": $v3 }, { "trait_type": $k4, "value": $v4 } ] } } }') && \
RES=$(difid tx wasm execute $CONTRACT_ADDRESS_DIFI "$JSON" --from nft_minter $HOME_DIFI $TXFLAG_DIFI -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
difid q tx $TX_HASH $NODE_DIFI --output json | jq && \
echo "$EXPLORER_DIFI/tx/$TX_HASH" && \
open "$EXPLORER_DIFI/tx/$TX_HASH"
```

#### mint_nft: VIN2
Make sure VIN is unique
```bash
JSON=$(jq -n --arg mf $TOYOTA --arg product "prius" --arg unique_id "VIN2" \
--arg k1 "year" --arg v1 "2024" --arg k2 "msp" --arg v2 "40000" --arg k3 "color" --arg v3 "black" --arg k4 "doors" --arg v4 "4" \
'{ "mint_nft": { "mf": $mf, "product": $product, "unique_id": $unique_id, "extension": { "name": $unique_id, "attributes": [ { "trait_type": $k1, "value": $v1 }, { "trait_type": $k2, "value": $v2 }, { "trait_type": $k3, "value": $v3 }, { "trait_type": $k4, "value": $v4 } ] } } }') && \
RES=$(difid tx wasm execute $CONTRACT_ADDRESS_DIFI "$JSON" --from nft_minter $HOME_DIFI $TXFLAG_DIFI -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
difid q tx $TX_HASH $NODE_DIFI --output json | jq && \
echo "$EXPLORER_DIFI/tx/$TX_HASH" && \
open "$EXPLORER_DIFI/tx/$TX_HASH" 
```

#### submit_sales_agrmt { dealer, mf, fin, items }
```bash
JSON=$(jq -n --arg dealer $DEALER1 --arg mf $TOYOTA --arg fin $WFC --arg token_id_1 "$TOYOTA:prius:VIN1" --arg token_id_2 "$TOYOTA:prius:VIN2"  \
'{ submit_sales_agrmt: { dealer: $dealer, mf: $mf, fin: $fin, items: [ { nft_token_id: $token_id_1, dealer_price: 35000|tonumber, fin_cost: 37000|tonumber}, { nft_token_id: $token_id_2, dealer_price: 34000|tonumber, fin_cost: 36000|tonumber } ] } }') && \
RES=$(difid tx wasm execute $CONTRACT_ADDRESS_DIFI "$JSON" --from dealer1 $HOME_DIFI $TXFLAG_DIFI -y --output json --log_level trace --trace) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
difid q tx $TX_HASH $NODE_DIFI --output json | jq && \
echo "$EXPLORER_DIFI/tx/$TX_HASH" && \
open "$EXPLORER_DIFI/tx/$TX_HASH" 
```

#### mf_approve_sales_agrmt { agrmt_id }
```bash
JSON=$(jq -n --arg agrmt_id 1 \
'{ "mf_approve_sales_agrmt": { agrmt_id: $agrmt_id|tonumber } }') && \
RES=$(difid tx wasm execute $CONTRACT_ADDRESS_DIFI "$JSON" --from toyota $HOME_DIFI $TXFLAG_DIFI -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
difid q tx $TX_HASH $NODE_DIFI --output json | jq && \
echo "$EXPLORER_DIFI/tx/$TX_HASH" && \
open "$EXPLORER_DIFI/tx/$TX_HASH" 
```

#### fin_approve_sales_agrmt { agrmt_id }
> FOR IBC DEMO: `--amount "69000ibc/E2BD6751F0AA4E2039E5AF627D72CF856859F31A5FD10C5692347964ADD4F4A6" `
```bash
JSON=$(jq -n --arg agrmt_id 1 \
'{ "fin_approve_sales_agrmt": { agrmt_id: $agrmt_id|tonumber } }') && \
RES=$(difid tx wasm execute $CONTRACT_ADDRESS_DIFI "$JSON" --from wfc --amount 69000uwfusd $HOME_DIFI $TXFLAG_DIFI -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
difid q tx $TX_HASH $NODE_DIFI --output json | jq && \
echo "$EXPLORER_DIFI/tx/$TX_HASH" && \
open "$EXPLORER_DIFI/tx/$TX_HASH" 
```

#### mf (toyota) transers all NFTs to fin
```bash
JSON=$(jq -n --arg agrmt_id 1 \
'{ "mf_transfer_nfts": { agrmt_id: $agrmt_id|tonumber } }') && \
RES=$(difid tx wasm execute $CONTRACT_ADDRESS_DIFI "$JSON" --from toyota $HOME_DIFI $TXFLAG_DIFI -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
difid q tx $TX_HASH $NODE_DIFI --output json | jq && \
echo "$EXPLORER_DIFI/tx/$TX_HASH" && \
open "$EXPLORER_DIFI/tx/$TX_HASH" 
```

#### alice buys $TOYOTA:prius:VIN1 for 40000; fin_cost = 37000
> FOR IBC DEMO: `--amount "40000ibc/E2BD6751F0AA4E2039E5AF627D72CF856859F31A5FD10C5692347964ADD4F4A6" `
```bash
JSON=$(jq -n --arg token_id "$TOYOTA:prius:VIN1" \
'{ "customer_buy_nft": { token_id: $token_id } }') && \
RES=$(difid tx wasm execute $CONTRACT_ADDRESS_DIFI "$JSON" --from alice --amount 40000uwfusd $HOME_DIFI $TXFLAG_DIFI -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
difid q tx $TX_HASH $NODE_DIFI --output json | jq && \
echo "$EXPLORER_DIFI/tx/$TX_HASH" && \
open "$EXPLORER_DIFI/tx/$TX_HASH" 
```

#### bob buys $TOYOTA:prius:VIN2 for 39000; fin_cost = 36000
> FOR IBC DEMO: `--amount "39000ibc/E2BD6751F0AA4E2039E5AF627D72CF856859F31A5FD10C5692347964ADD4F4A6"`
```bash
JSON=$(jq -n --arg token_id "$TOYOTA:prius:VIN2" \
'{ "customer_buy_nft": { token_id: $token_id } }') && \
RES=$(difid tx wasm execute $CONTRACT_ADDRESS_DIFI "$JSON" --from bob --amount 39000uwfusd $HOME_DIFI $TXFLAG_DIFI -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
difid q tx $TX_HASH $NODE_DIFI --output json | jq && \
echo "$EXPLORER_DIFI/tx/$TX_HASH" && \
open "$EXPLORER_DIFI/tx/$TX_HASH"
```

#### test SendCoin
```bash
JSON=$(jq -n --arg recipient "$WFC" \
'{ "send_coin": { recipient: $recipient } }') && \
RES=$(difid tx wasm execute $CONTRACT_ADDRESS_DIFI "$JSON" --from dealer1 --amount 100stake $HOME_DIFI $TXFLAG_DIFI -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
difid q tx $TX_HASH $NODE_DIFI --output json | jq && \
echo "$EXPLORER_DIFI/tx/$TX_HASH" && \
open "$EXPLORER_DIFI/tx/$TX_HASH"  
```

## Misc
``` bash
## env vars
source ../../chains.env && \
export PATH=$PATH:$HOME/go/bin


# set up these variables for convenience
export TOYOTA=$(difid keys show -a toyota $HOME_DIFI) && \
export HONDA=$(difid keys show -a honda $HOME_DIFI) && \
export DEALER1=$(difid keys show -a dealer1 $HOME_DIFI) && \
export DEALER2=$(difid keys show -a dealer2 $HOME_DIFI) && \
export WFC=$(difid keys show -a wfc $HOME_DIFI) && \
export FIN2=$(difid keys show -a fin2 $HOME_DIFI) && \
export ALICE=$(difid keys show -a alice $HOME_DIFI) && \
export BOB=$(difid keys show -a bob $HOME_DIFI)
export NFT_MINTER=$(difid keys show -a nft_minter $HOME_DIFI)

# balance check
difid q bank balances $(difid keys show wfc -a $HOME_DIFI) $NODE_DIFI
difid q bank balances $WFC $NODE_DIFI --output json | jq
difid q bank balances $FIN2 $NODE_DIFI --output json | jq
difid q bank balances $ALICE $NODE_DIFI --output json | jq
difid q bank balances $BOB $NODE_DIFI --output json | jq
difid q bank balances $TOYOTA $NODE_DIFI --output json | jq
difid q bank balances $HONDA $NODE_DIFI --output json | jq
difid q bank balances $DEALER1 $NODE_DIFI --output json | jq
difid q bank balances $DEALER2 $NODE_DIFI --output json | jq
difid q bank balances $NFT_MINTER $NODE_DIFI --output json | jq
difid q bank balances $CONTRACT_ADDRESS_DIFI $NODE_DIFI --output json | jq
difid q bank balances $ESCROW $NODE_DIFI --output json | jq


# any instantiations of code?
difid query wasm list-contract-by-code $CODE_ID_DIFI $NODE_DIFI --output json | jq
difid query wasm code $CODE_ID_DIFI $NODE_DIFI ../../target/wasm32-unknown-unknown/release/download_difi_core_2.wasm

# contract address
or this one is not reliable
CONTRACT_ADDRESS_DIFI=$(echo $RES | jq -r '.logs[0].events[-1].attributes[-1].value')

# contract info
difid q wasm contract-state raw $CONTRACT_ADDRESS_DIFI 636F6E74726163745F696E666F $NODE_DIFI
difid q wasm contract $CONTRACT_ADDRESS_DIFI $NODE_DIFI --output json | jq
```

## Helper
``` bash
difid tx bank send $TOYOTA $ALICE 35000uwfusd $NODE_DIFI $HOME_DIFI
difid tx bank send $TOYOTA $BOB 34000uwfusd $NODE_DIFI $HOME_DIFI
difid tx bank send $DEALER1 $ALICE 3000uwfusd $NODE_DIFI $HOME_DIFI
difid tx bank send $DEALER1 $BOB 3000uwfusd $NODE_DIFI $HOME_DIFI
difid tx bank send $WFC $ALICE 2000uwfusd $NODE_DIFI $HOME_DIFI
difid tx bank send $WFC $BOB 2000uwfusd $NODE_DIFI $HOME_DIFI


difid q tx CDA55CF8D35986B541164BC0BC44998CC1DE41EBFFA8B9A8079672F3EB45C180 $NODE_DIFI --output json | jq 
```
