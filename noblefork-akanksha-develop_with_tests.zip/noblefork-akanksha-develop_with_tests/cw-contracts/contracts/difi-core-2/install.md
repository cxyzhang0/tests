# Distribution Finance Smart Contract

## Build wasm
> Preq-req: Install [Rust and Cargo (1.66.1)](https://doc.rust-lang.org/cargo/getting-started/installation.html)

```bash
cd difi-core-2

# build wasm
RUSTFLAGS='-C link-arg=-s' cargo wasm

# validate wasm
cosmwasm-check ../../target/wasm32-unknown-unknown/release/difi_core_2.wasm
```

## Install on difi chain
> Pre-req: [Start the Difi Chain](../../../chains/difi/readme.md) and run the [Explorer](https://github.com/wfblockchain/explorer/blob/master/installation.md).

> You can see the script [contract.sh](../../../docker-setup/contract.sh) to automate this.

```bash
source ../../chains.env && \
export PATH=$PATH:$HOME/go/bin

export NFT_MINTER=$(difid keys show -a nft_minter $HOME_DIFI)

# upload code and get CODE_ID_DIFI: need two steps
STORE_DIFI=$(difid tx wasm store ../../target/wasm32-unknown-unknown/release/difi_core_2.wasm --from validator1 $TXFLAG_DIFI $HOME_DIFI -y -b sync --output json) && \
TX_HASH_DIFI=$(echo $STORE_DIFI | jq -r '.txhash') && \
echo "$EXPLORER_DIFI/tx/$TX_HASH_DIFI" && \
open "$EXPLORER_DIFI/tx/$TX_HASH_DIFI"

TX=$(difid q tx $TX_HASH_DIFI $NODE_DIFI --output json) && \
CODE_ID_DIFI=$(echo $TX | jq -r '.logs[0].events[-1].attributes[1].value') && \
echo $CODE_ID_DIFI 

# instantiate and get CONTRACT_ADDRESS_DIFI: two steps
INIT_DIFI=$(jq -n --arg nft_minter $NFT_MINTER --arg denom "uwfusd" '{ "nft_minter": $nft_minter, "denom": $denom }') && \
## For Demo2 (IBC):
# INIT_DIFI=$(jq -n --arg nft_minter $NFT_MINTER --arg denom "ibc/E2BD6751F0AA4E2039E5AF627D72CF856859F31A5FD10C5692347964ADD4F4A6" '{ "nft_minter": $nft_minter, "denom": $denom }') && \
RES=$(difid tx wasm instantiate $CODE_ID_DIFI "$INIT_DIFI" --from nft_minter --label "difi" --no-admin $HOME_DIFI $TXFLAG_DIFI -y --output json)

CONTRACT_ADDRESS_DIFI=$(difid query wasm list-contract-by-code $CODE_ID_DIFI $NODE_DIFI --output json | jq -r '.contracts[-1]') && \
echo $CONTRACT_ADDRESS_DIFI
export ESCROW=$CONTRACT_ADDRESS_DIFI

TX_HASH=$(echo $RES | jq -r '.txhash') && \
difid q tx $TX_HASH $NODE_DIFI --output json | jq && \
echo "$EXPLORER_DIFI/tx/$TX_HASH" && \
open "$EXPLORER_DIFI/tx/$TX_HASH"


# escrow balance
difid q bank balances $ESCROW $NODE_DIFI --output json | jq
difid q bank balances $CONTRACT_ADDRESS_DIFI $NODE_DIFI --output json | jq
```

### Deploying to deployed TestNet
See: https://github.com/wfblockchain/testnet-deployments/blob/main/chains/difi/wasm-setup.sh