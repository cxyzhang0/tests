# Cosmwasm contracts for DiFi

## Distribution Finance (DiFi) – High level flows

### Actors and Transactions
#### Trusted Minter (Difi Owner or adim or Minter)
1. mints NFTs of different types (Prius, Avalon, etc)
   (inventory on chain)
#### Manufacturer (Toyoto Motor Corporation)
4. transfers NFT to financier
   uwfusd is sent to manufacturer from escrow
#### Dealer (Concord Toyoto)
2. submit purchase_contract – a list of NFTs from a given minter to a given financier
5. pays uwfusd to financier based on purchase_contract, transfer NFT to customer
#### Financier (WFC)
3. approves a purchase_contract  
   pays uwfusd to escrow
4. approves dealer as delegator of NFT transaction
#### Customer (Alice)
5. buys NFT from dealer  
   pays uwfusd to dealer


## difi nft design choices -
1. current difi contract as minter and owner of all tokens, single or multiple stores
2. mf as mi. nter, multiple stores, less organized
3. haman admin as minter, single store, integrate cw721 libraries into difi instead of instantiating them as separate contracts

1 seems awkward: mf messages difi to mint_nft, then difi messages cw721 to mint, now sender on cw721 becomes difi so difi has to be the minter. similarly for nft owner, difi has to be the nft owner in order for it to message cw721 for transfers; and transfer to difi itself otherwise the new owner cannot transact on the token via difi anymore. So nft becomes redundant and difi states can handle the ownership txs. and we need to states anyway to track ownership since cw721 records a single owner for all tokens.

In 2, each mf manages its own nft contracts/stores outside difi contract. maybe UI can facilitate that. we first store cw721 wasm file on chain. then each mf can instantiate contracts as needed. with the contract address, mf can mint its nfts.
dealer gets the contract addresses from mf and can start browsing, outside difi contract. dealer submits a purchase_contract on difi contract. financier approves it on difi and pays the escrow. but mf has to do the nft transfer off difi, then how can difi know to pay mf from escrow.
so this design may not work.

In 3, if we can do it, there is a single difi contract with its own integrated cw721 nft store. since there is cross-contract messaging, info.sender will be the tx signer, mf, financier, dealer or customer.
if we use cw721 code, minter has to be the owner of the difi contract, which we set at contract instantiation. it will have a keypair so an authoritative entity. mf coordinates with minter offline to send their products for tokenization. minter mints the products to the mf as owner.
the rest follows the flows we discussed, such as purchase_order submission and approval, escrow payment by financier, nft transfer from mf to financier and payment from escrow to mf, financier delegate dealer as transfer agent, dealer and custom exchange of nft and uwfusd and dealer payment to financier.
it is uncertain at this point what the experience in the integration with cw721 will be.
