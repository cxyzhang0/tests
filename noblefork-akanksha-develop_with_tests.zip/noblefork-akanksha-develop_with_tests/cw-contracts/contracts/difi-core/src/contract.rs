#![cfg_attr(debug_assertions, allow(unused_imports))] // ! implies this conditional attr applies to the whole crate

use cosmwasm_std::{entry_point, to_binary, BankMsg, Binary, Coin, Deps, DepsMut, Empty, Env, MessageInfo, Reply, Response, StdResult, WasmMsg, SubMsg, Addr};
use cw2::{set_contract_version};
use cw721_base::{
    msg::ExecuteMsg as Cw721BaseExecuteMsg,
    // msg::QueryMsg as Cw721QueryMsg,
    MinterResponse, // instead of cw721_metadata_onchain::MinterResponse because the latter is of version 0.15.0 of cw721_base.
    /*MintMsg, */
};
use cw721::{OwnerOfResponse};
use cw721_metadata_onchain::{Extension, ExecuteMsg as Cw721ExecuteMsg, InstantiateMsg as Cw721InstantiateMsg, QueryMsg as Cw721QueryMsg, MintMsg};
use cw721::{ContractInfoResponse};

use cw_utils::parse_reply_instantiate_data;

use crate::msg::{ExecuteMsg, InstantiateMsg, QueryMsg};
use crate::state::{Config, CONFIG, NFT_FACTORY};
use crate::error::ContractError;

// version info for migration info
pub const CONTRACT_NAME: &str = "crates.io:difi-core";
pub const CONTRACT_VERSION: &str = env!("CARGO_PKG_VERSION");
const INSTANTIATE_CW721_REPLY_ID: u64 = 1;


#[cfg_attr(not(feature = "library"), entry_point)]
pub fn instantiate(
    deps: DepsMut,
    _env: Env,
    info: MessageInfo,
    msg: InstantiateMsg,
) -> StdResult<Response> {
    set_contract_version(deps.storage, CONTRACT_NAME, CONTRACT_VERSION)?;

    let config = Config {
        owner: info.sender,
        nft_code_id: msg.nft_code_id,
        denom: msg.denom,
    };

    CONFIG.save(deps.storage, &config)?;

    Ok(Response::new()
        .add_attribute("action", "instantiate")
        .add_attribute("nft_code_id", config.nft_code_id.to_string())
        .add_attribute("denom", config.denom)
    )
}

#[cfg_attr(not(feature = "library"), entry_point)]
pub fn execute(
    deps: DepsMut,
    env: Env,
    info: MessageInfo,
    msg: ExecuteMsg,
) -> Result<Response, ContractError> {
    use ExecuteMsg::*;
    match msg {
        CreateNftFactory { product } => exec::create_nft_factory(deps, env, info, &product),
        MintNft { product, token_id, extension} => exec::mint_nft(deps, env, info, &product, &token_id, extension),
    }
}

/*

Handle callbacks
1. callback triggered by sub-message Cw721InstantiateMsg.
    Save the newly instantiated contract address in NFT_FACTORY.
 */
#[cfg_attr(not(feature = "library"), entry_point)]
pub fn reply(deps: DepsMut, _env: Env, msg: Reply) -> Result<Response, ContractError> {
    /*
     Since we only have one sub-message so far, we can do this if check.
     Once we have more than one sub-message, we may use match.
     */
    if msg.id != INSTANTIATE_CW721_REPLY_ID {
        return Err(ContractError::InvalidReplyId { id: msg.id })
    }

    let reply = parse_reply_instantiate_data(msg).unwrap();

    /*
    Now we have reply.contract_address, can we query the contract to get its owner/minter and name/product?
    We need (minter, product) -> contract_address for NFT_FACTORY.
    NOTE: No check for dup because create_nft_factory also did.
     */
    let minter: MinterResponse = deps.querier.query_wasm_smart(reply.contract_address.to_owned(), &Cw721QueryMsg::Minter{}).unwrap();
    let minter = minter.minter;
    let contract_info: ContractInfoResponse = deps.querier.query_wasm_smart(reply.contract_address.to_owned(), &Cw721QueryMsg::ContractInfo{}).unwrap();

    /*
    TODO: Cannot use minter as part of key since minter is always difi contract.
    Consider repurpose symbol as mf's address and use it instead.
     */
    NFT_FACTORY.save(deps.storage, (&Addr::unchecked(minter), &contract_info.name), &Addr::unchecked(reply.contract_address))?;

    Ok(Response::new())
}

#[cfg_attr(not(feature = "library"), entry_point)]
pub fn query(
    deps: Deps,
    env: Env,
    msg: QueryMsg,
) -> StdResult<Binary> {
    match msg {
        QueryMsg::Config {} => to_binary(&query::get_config(deps, env)?),
        QueryMsg::NftContractAddress { minter, product } => to_binary(&query::get_nft_contract_address(deps, env, minter, product)?),

    }
}

mod exec {
    use cosmwasm_std::ReplyOn;
    use cw721::NftInfoResponse;
    use super::*;
    /*
    Instantiates a cw721-metadata-onchain contract whose code_id is in config as nft_code_id.
    That is done by a SubMsg instead of Message because we need a callback.
    In the reply callback handler, save the new contract address in NFT_FACTORY.
    TODO: restrict who can have a factory. need to identify who is a manufacturer.
     */
    pub fn create_nft_factory(deps: DepsMut, env: Env, info: MessageInfo, product: &str) -> Result<Response, ContractError> {
        // check if factory already exists
        if NFT_FACTORY.has(deps.storage, (&info.sender, product)) {
            return Err(ContractError::NFTFactoryExists { mf: info.sender, product: product.to_string()})
        }

        let config = CONFIG.load(deps.storage)?;

        let sub_msg: Vec<SubMsg> = vec![
            SubMsg {
                msg: WasmMsg::Instantiate {
                    code_id: config.nft_code_id,
                    msg: to_binary(&Cw721InstantiateMsg {
                        name: product.to_string(),
                        symbol: product.to_string(), // what should symbol be?
                        // dif contract as minter
                        // minter: info.sender.to_owned().to_string(),
                        minter: env.contract.address.to_string(),  //info.sender.to_owned().to_string(),
                    })?,
                    funds: vec![],
                    admin: None,
                    label: "Instantiate cw721-metadata-onchain".to_string(),
                }.into(),
                id: INSTANTIATE_CW721_REPLY_ID,
                gas_limit: None,
                reply_on: ReplyOn::Success,
            },
        ];

        Ok(Response::new()
            .add_submessages(sub_msg)
            .add_attribute("action", "create_nft_factory")
            .add_attribute("manufacturer", info.sender.to_string())
            .add_attribute("product", product))
    }

    /*
    Send a Mint sub-message to the corresponding NFT factory.
    info.sender is the intended minter.
     */
    pub fn mint_nft(deps: DepsMut, _env: Env, info: MessageInfo, product: &str, token_id: &str, extension: Extension) -> Result<Response, ContractError> {
        let contract_addr = NFT_FACTORY.may_load(deps.storage, (&info.sender, product))?;
        if contract_addr.is_none() {
            return Err(ContractError::NFTFactoryNotFound { mf: info.sender, product: product.to_string()})
        }

        let contract_addr = contract_addr.unwrap();

        // check token_id for dup
        if let Ok(OwnerOfResponse {owner: _owner, approvals: _approvals }) = deps.querier.query_wasm_smart(contract_addr.to_owned(), &Cw721QueryMsg::OwnerOf{token_id: token_id.to_string(), include_expired: Some(true) }) {
            return Err(ContractError::TokenExists { minter: info.sender, product: product.to_string(), token_id: token_id.to_string() })
        }

        let msg = WasmMsg::Execute {
            contract_addr: contract_addr.to_string(),
            msg: to_binary(&Cw721ExecuteMsg::Mint(MintMsg {
                token_id: token_id.to_string(),
                owner: info.sender.to_string(),
                token_uri: None,
                extension,
            }))?,
            funds: vec![],
        };

        // Or use the following submessage
        /*
        let sub_msg: Vec<SubMsg> = vec![
            SubMsg {
                msg: WasmMsg::Execute {
                    contract_addr: contract_addr.to_string(),
                    msg: to_binary(&Cw721ExecuteMsg::Mint(MintMsg {
                        token_id: token_id.to_string(),
                        owner: info.sender.to_string(),
                        token_uri: None,
                        extension,
                    }))?,
                    funds: vec![],
                }.into(),
                id: 0u64, // for fire and forget, id is redundant
                gas_limit: None,
                reply_on: ReplyOn::Never, // fire and forget.
            },
        ];
         */

        Ok(Response::new()
            .add_message(msg)
            // .add_submessages(sub_msg)
            .add_attribute("action", "mint_nft")
            .add_attribute("product", product.to_string())
            .add_attribute("token_id", token_id.to_string())
        )
    }
}

mod query {
    use crate::msg::{OptionQueryNFTContractAddress, QueryNFTContractAddress};
    use super::*;

    pub fn get_config(deps: Deps, _env: Env) -> StdResult<Config> {
        let config = CONFIG.load(deps.storage)?;

        Ok(config)
    }

    pub fn get_nft_contract_address(deps: Deps, _env: Env, minter: String, product: String) -> StdResult<OptionQueryNFTContractAddress> {
        let minter_addr = deps.api.addr_validate(&minter)?;
        let contract_addr = NFT_FACTORY.may_load(deps.storage, (&minter_addr, &product))?;
        if contract_addr.is_none() {
            return Ok(OptionQueryNFTContractAddress { resp: None })
        }

        Ok(OptionQueryNFTContractAddress {
            resp: Some(QueryNFTContractAddress {
                minter,
                product,
                contract_addr: contract_addr.unwrap().to_string(),
            })
        })
    }

}