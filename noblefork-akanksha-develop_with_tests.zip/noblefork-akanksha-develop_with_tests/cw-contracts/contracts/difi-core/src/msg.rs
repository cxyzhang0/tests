use cosmwasm_schema::{cw_serde, QueryResponses};
use crate::state::{Config};
use cw721_metadata_onchain::{Extension};

#[cw_serde]
pub struct InstantiateMsg {
    pub nft_code_id: u64,
    pub denom: String,
}

#[cw_serde]
pub enum ExecuteMsg {
    CreateNftFactory {
        product: String,
    },
    MintNft {
        product: String,
        token_id: String,
        extension: Extension,
    }

}

#[cw_serde]
#[derive(QueryResponses)]
pub enum QueryMsg {
    #[returns(Config)]
    Config {},
    #[returns(OptionQueryNFTContractAddress)]
    NftContractAddress { minter: String, product: String },
}

#[cw_serde]
pub struct OptionQueryNFTContractAddress {
    pub resp: Option<QueryNFTContractAddress>,
}

#[cw_serde]
pub struct QueryNFTContractAddress {
    pub minter: String,
    pub product: String,
    pub contract_addr: String,
}