use cosmwasm_std::{Addr, StdError};
use cw_utils::PaymentError;
use thiserror::Error;

#[derive(Error, Debug, PartialEq)]
pub enum ContractError {
    #[error("{0}")]
    StdError(#[from] StdError),
    #[error("{sender} is not authorized to perform the function")]
    Unauthorized { sender: Addr },
    #[error("Payment error: {0}")]
    PaymentError(#[from] PaymentError),
    #[error("Key ({mf}, {product}) not found")]
    NFTFactoryNotFound { mf: Addr, product: String },
    #[error("Key ({mf}, {product}) exists")]
    NFTFactoryExists { mf: Addr, product: String },
    #[error("Expected: {expected}, Got: {got}")]
    InvalidDenom { expected: String, got: String },
    #[error("Expected: {expected}, Got: {got}")]
    InvalidStatus { expected: String, got: String },
    #[error("({minter} {product}) {token_id} exists")]
    TokenExists { minter: Addr, product: String, token_id: String },
    #[error("InvalidReplyId {id}")]
    InvalidReplyId { id: u64 },
}