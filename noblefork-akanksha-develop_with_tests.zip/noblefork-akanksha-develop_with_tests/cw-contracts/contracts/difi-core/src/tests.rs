#![cfg_attr(debug_assertions, allow(unused_imports))] // ! implies this conditional attr applies to the whole crate

use cosmwasm_std::{attr, coins, Addr, from_binary};
use cosmwasm_std::testing::{mock_dependencies, mock_info, mock_env};
use cw2::ContractVersion;
// use cw721_metadata_onchain::{InstantiateMsg as cw721_InstantiateMsg};
/*
there is no cw721_metadata_onchain::{execute, instantiate, query};
 */
use cw721_base::entry::{execute as cw721_execute, instantiate as cw721_instantiate, query as cw721_query};
// use cw721_base::QueryMsg::Extension;
use cw_multi_test::{App, BasicApp, ContractWrapper, Executor};
use cw721_metadata_onchain::{Extension, Metadata, Trait};
use cw_ownable::{OwnershipError};
use crate::contract::{execute, instantiate, query, reply, CONTRACT_VERSION, CONTRACT_NAME};
use crate::error::ContractError;
use crate::msg::{ExecuteMsg, InstantiateMsg, OptionQueryNFTContractAddress, QueryMsg};
use crate::state::{Config};

const DENOM: &str = "uwfusd";
const OWNER: &str = "owner";

fn setup(app: &mut BasicApp) -> (Addr, u64, u64) {
    let code = ContractWrapper::new(execute, instantiate, query).with_reply(reply);
    let code_id = app.store_code(Box::new(code));
    let nft_code_id = store_cw721(app);

    let msg = InstantiateMsg { nft_code_id, denom:  DENOM.to_string() };

    let addr = app.instantiate_contract(
        code_id,
        Addr::unchecked(OWNER),
        &msg,
        &[],
        "difi-core Contract",
        None
    ).unwrap();

    (addr, code_id, nft_code_id)
}

fn store_cw721(app: &mut BasicApp) -> u64 {
    let code = ContractWrapper::new(cw721_execute, cw721_instantiate, cw721_query);
    let code_id = app.store_code(Box::new(code));

    code_id
}

#[test]
// instantiate with mock deps, env and info
fn can_instantiate_with_mock() {
    let code_id = 1;
    let msg = InstantiateMsg { nft_code_id: 1, denom:  DENOM.to_string() };

    let mut deps = mock_dependencies();
    let env = mock_env();
    let info = mock_info(OWNER, &[]);


    let resp = instantiate(deps.as_mut(), env.clone(), info, msg).unwrap();
    assert_eq!(
        resp.attributes,
        vec![attr("action", "instantiate"), attr("nft_code_id", code_id.to_string()), attr("denom", DENOM.to_string())]
    );

    let ver = cw2::get_contract_version(&deps.storage).unwrap();
    assert_eq!(
        ver,
        ContractVersion {
            contract: CONTRACT_NAME.to_string(),
            version: CONTRACT_VERSION.to_string(),
        }
    );

    // query config
    let config: Config = from_binary(&query(deps.as_ref(), env, QueryMsg::Config {}).unwrap()).unwrap();

    assert_eq!(
        config,
        Config {
            owner: Addr::unchecked(OWNER.to_string()),
            nft_code_id: code_id,
            denom: DENOM.to_string(),
        }
    )
}

#[test]
// instantiate with app
fn can_instantiate_with_setup() {
    let mut app = App::default();
    let (contract_addr, _code_id, nft_code_id) = setup(&mut app);

    // Q: how to test version? how to test events from instantiation?

    // query config
    let config: Config = app.wrap()
        .query_wasm_smart(contract_addr.to_owned(), &QueryMsg::Config {})
        .unwrap();

    assert_eq!(
        config,
        Config {
            owner: Addr::unchecked(OWNER.to_string()),
            nft_code_id: nft_code_id,
            denom: DENOM.to_string(),
        }
    )
}

#[test]
// create one nft factory
fn can_create_nft_factory_one() {
    let mut app = App::default();
    let (contract_addr, _, _) = setup(&mut app);

    let mf = "toyota";
    let product = "prius";
    let resp = app.execute_contract(
        Addr::unchecked(mf.to_string()),
        contract_addr.to_owned(),
        &ExecuteMsg::CreateNftFactory {
                product: product.to_string(),
            },
&[],
    ).unwrap();

    // check events
    let wasm = resp.events.iter().find(|evt| evt.ty == "wasm").unwrap();
    assert_eq!(
        wasm.attributes
            .iter()
            .find(|attr| attr.key == "action")
            .unwrap()
            .value,
        "create_nft_factory"
    );
    assert_eq!(
        wasm.attributes
            .iter()
            .find(|attr| attr.key == "manufacturer")
            .unwrap()
            .value,
        mf.to_string()
    );
    assert_eq!(
        wasm.attributes
            .iter()
            .find(|attr| attr.key == "product")
            .unwrap()
            .value,
        product.to_string()
    );
    // query nft contract addr
    let resp: OptionQueryNFTContractAddress = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::NftContractAddress {
            minter: contract_addr.to_string(),
            // minter: mf.to_string(),
            product: product.to_string(),
        }
    ).unwrap();
    let resp = resp.resp.unwrap();
    assert_eq!(
        resp.minter,
        contract_addr.to_string()
        // mf.to_string()
    );
    assert_eq!(
        resp.product,
        product.to_string()
    );
    assert_eq!(
        resp.contract_addr,
        "contract1".to_string() // Q: why not real addr? A: may be mock.
    );

}

// #[test]
// create two nft factories
fn can_create_nft_factory_two() {
    let mut app = App::default();
    let (contract_addr, _, _) = setup(&mut app);

    let mf = "toyota";
    let product = "prius";
    let product2 = "avalon";
    // first factory (mf, product)
    let _ = app.execute_contract(
        Addr::unchecked(mf.to_string()),
        contract_addr.to_owned(),
        &ExecuteMsg::CreateNftFactory {
            product: product.to_string(),
        },
        &[],
    ).unwrap();
    // seconf factory (mf, product2)
    let _ = app.execute_contract(
        Addr::unchecked(mf.to_string()),
        contract_addr.to_owned(),
        &ExecuteMsg::CreateNftFactory {
            product: product2.to_string(),
        },
        &[],
    ).unwrap();

    // query first nft contract addr
    let resp: OptionQueryNFTContractAddress = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::NftContractAddress {
            minter: mf.to_string(),
            product: product.to_string(),
        }
    ).unwrap();
    let resp = resp.resp.unwrap();
    assert_eq!(
        resp.minter,
        mf.to_string()
    );
    assert_eq!(
        resp.product,
        product.to_string()
    );
    assert_eq!(
        resp.contract_addr,
        "contract1".to_string() // Q: why not real addr? A: may be mock.
    );
    // query second nft contract addr
    let resp: OptionQueryNFTContractAddress = app.wrap().query_wasm_smart(
        contract_addr,
        &QueryMsg::NftContractAddress {
            minter: mf.to_string(),
            product: product2.to_string(),
        }
    ).unwrap();
    let resp = resp.resp.unwrap();
    assert_eq!(
        resp.minter,
        mf.to_string()
    );
    assert_eq!(
        resp.product,
        product2.to_string()
    );
    assert_eq!(
        resp.contract_addr,
        "contract2".to_string() // Q: why not real addr? A: may be mock.
    );
}

// #[test]
// fail to create duplicate nft factory
fn fail_create_nft_factory_dup() {
    let mut app = App::default();
    let (contract_addr, _, _) = setup(&mut app);

    let mf = "toyota";
    let product = "prius";
    let _ = app.execute_contract(
        Addr::unchecked(mf.to_string()),
        contract_addr.to_owned(),
        &ExecuteMsg::CreateNftFactory {
            product: product.to_string(),
        },
        &[],
    ).unwrap();

    // query nft contract addr
    let resp: OptionQueryNFTContractAddress = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::NftContractAddress {
            minter: contract_addr.to_string(),
            // minter: mf.to_string(),
            product: product.to_string(),
        }
    ).unwrap();
    let resp = resp.resp.unwrap();
    assert_eq!(
        resp.minter,
        contract_addr.to_string()
        // mf.to_string()
    );
    assert_eq!(
        resp.product,
        product.to_string()
    );
    assert_eq!(
        resp.contract_addr,
        "contract1".to_string() // Q: why not real addr? A: may be mock.
    );

    // dup
    let err = app.execute_contract(
        Addr::unchecked(mf.to_string()),
        contract_addr.to_owned(),
        &ExecuteMsg::CreateNftFactory {
            product: product.to_string(),
        },
        &[],
    ).unwrap_err();
    assert_eq!(
        ContractError::NFTFactoryExists { mf: Addr::unchecked(mf), product: product.to_string()},
        err.downcast().unwrap()
    )
}

#[test]
// mint a nft with contract as minte
fn can_mint_nft() {
    let mut app = App::default();
    let (contract_addr, _, _) = setup(&mut app);

    let mf = "toyota";
    let product = "prius";
    let token_id = "VIN1";
    let resp = app.execute_contract(
        Addr::unchecked(mf.to_string()),
        contract_addr.to_owned(),
        &ExecuteMsg::CreateNftFactory {
            product: product.to_string(),
        },
        &[],
    ).unwrap();

    // query nft contract addr
    let resp: OptionQueryNFTContractAddress = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::NftContractAddress {
            minter: contract_addr.to_string(), //mf.to_string(),
            product: product.to_string(),
        }
    ).unwrap();
    let resp = resp.resp.unwrap();
    assert_eq!(
        resp.minter,
        contract_addr.to_string()
        // mf.to_string()
    );
    assert_eq!(
        resp.product,
        product.to_string()
    );
    assert_eq!(
        resp.contract_addr,
        "contract1".to_string() // Q: why not real addr? A: may be mock.
    );

    // mint nft
    let mint_nft_msg = ExecuteMsg::MintNft {
        product: product.to_string(),
        token_id: token_id.to_string(),
        extension: Some(Metadata {
            name: Some(token_id.to_string()),
            attributes: Some(vec![
                Trait {
                    display_type: None,
                    trait_type: "year".to_string(),
                    value: "2024".to_string(),
                },
                Trait {
                    display_type: None,
                    trait_type: "msp".to_string(),
                    value: "40000".to_string(),
                },
                Trait {
                    display_type: None,
                    trait_type: "color".to_string(),
                    value: "black".to_string(),
                },
                Trait {
                    display_type: None,
                    trait_type: "doors".to_string(),
                    value: "4".to_string(),
                },
            ]),
            ..Metadata::default()
        }),
    };

    let _ = ExecuteMsg::MintNft {
        product: product.to_string(),
        token_id: token_id.to_string(),
        extension: None,
    };

    let resp = app.execute_contract(
        Addr::unchecked(contract_addr.to_string()),
        contract_addr.to_owned(),
        &mint_nft_msg,
        &[],
    ).unwrap();
    println!("{:?}", resp)
}

/*
#[test]
// mint a nft
fn fail_mint_nft() {
    let mut app = App::default();
    let (contract_addr, _, _) = setup(&mut app);

    let mf = "toyota";
    let product = "prius";
    let token_id = "VIN1";
    let resp = app.execute_contract(
        Addr::unchecked(mf.to_string()),
        contract_addr.to_owned(),
        &ExecuteMsg::CreateNftFactory {
            product: product.to_string(),
        },
        &[],
    ).unwrap();

    // query nft contract addr
    let resp: OptionQueryNFTContractAddress = app.wrap().query_wasm_smart(
        contract_addr.to_owned(),
        &QueryMsg::NftContractAddress {
            minter: mf.to_string(),
            product: product.to_string(),
        }
    ).unwrap();
    let resp = resp.resp.unwrap();
    assert_eq!(
        resp.minter,
        mf.to_string()
    );
    assert_eq!(
        resp.product,
        product.to_string()
    );
    assert_eq!(
        resp.contract_addr,
        "contract1".to_string() // Q: why not real addr? A: may be mock.
    );

    // mint nft
    let mint_nft_msg = ExecuteMsg::MintNft {
        product: product.to_string(),
        token_id: token_id.to_string(),
        extension: Some(Metadata {
            name: Some(token_id.to_string()),
            attributes: Some(vec![
                Trait {
                    display_type: None,
                    trait_type: "year".to_string(),
                    value: "2024".to_string(),
                },
                Trait {
                    display_type: None,
                    trait_type: "msp".to_string(),
                    value: "40000".to_string(),
                },
                Trait {
                    display_type: None,
                    trait_type: "color".to_string(),
                    value: "black".to_string(),
                },
                Trait {
                    display_type: None,
                    trait_type: "doors".to_string(),
                    value: "4".to_string(),
                },
            ]),
            ..Metadata::default()
        }),
    };

    let _ = ExecuteMsg::MintNft {
        product: product.to_string(),
        token_id: token_id.to_string(),
        extension: None,
    };

    let resp = app.execute_contract(
        Addr::unchecked(mf.to_string()),
        contract_addr.to_owned(),
        &mint_nft_msg,
        &[],
    ).unwrap_err();
    // assert_eq!(
    //     OwnershipError::NotOwner,
    //     resp.downcast().unwrap()
    // );
}
*/