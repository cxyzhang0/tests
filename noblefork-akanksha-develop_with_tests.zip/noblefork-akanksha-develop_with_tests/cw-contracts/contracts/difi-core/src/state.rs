#![cfg_attr(debug_assertions, allow(unused_imports))] // ! implies this conditional attr applies to the whole crate

use std::fmt;
use cosmwasm_std::{Addr, Coin};
use cw_storage_plus::{Item, Map};
use cosmwasm_schema::{cw_serde};

// Config is defined at contract instantiation
pub const CONFIG: Item<Config> = Item::new("config");

// (mf, product) -> factory addr: (toyoto, prius) -> its nft factory addr
pub const NFT_FACTORY: Map<(&Addr, &str), Addr> = Map::new("nft_factory");

// mf -> its info
pub const MANUFACTURER: Map<&Addr, ManufacturerInfo> = Map::new("manufacturer");

// dealer -> its info
pub const DEALER: Map<&Addr, DealerInfo> = Map::new("dealer");

// financier -> its info
pub const FINANCIER: Map<&Addr, FinancierInfo> = Map::new("financier");

#[cw_serde]
pub struct Config {
    // owner of this contract = address that creates it
    pub owner: Addr,
    // code_id of pre-stored cw721-metadata-onchain
    pub nft_code_id: u64,
    // currency used for payments uwfusd
    pub denom: String,
}

#[cw_serde]
pub struct ManufacturerInfo {
    pub name: String,
}

#[cw_serde]
pub struct DealerInfo {
    pub name: String,

}

#[cw_serde]
pub struct FinancierInfo {
    pub name: String,
}

