# Core smart contract for DiFi
NFT Option 1: difi as minter and owner
> features
> * factory for cw721-metadata-onchain (cw721-mo) contracts
> * difi as both minter of all contracts and owner of all NFTs from all contracts
> * need bookkeeping of actual ownership of NFTs

## How this package was created
Unfortunately, `cargo generate --git https://github.com/CosmWasm/cw-template.git --name PROJECT_NAME -d minimal=true`` does not work. So, start the project from scratch.  

```bash
cd contracts
cargo new --lib ./difi-core
```

See [install.md](../difi-core-2/install.md) for general instructions on how to build/deploy smart contract.

Legacy instructions down below:
## Install on dosb
```
## start dosb - use branch sean/wasm from repo https://github.com/wfblockchain/dosb-poc/tree/sean/wasm

## env vars
source ../../chains.env
export PATH=$PATH:$HOME/go/bin

## upload code and get CODE_ID_DIFI_CORE
STORE_DIFI_CORE=$(dosbd tx wasm store ../../target/wasm32-unknown-unknown/release/difi_core.wasm --from validator1 $TXFLAG_DOSB $HOME_DOSB -y -b block --output json) && \
CODE_ID_DIFI_CORE=$(echo $STORE_DIFI_CORE | jq -r '.logs[0].events[-1].attributes[1].value')

echo $CODE_ID_DIFI_CORE 

# any instantiations of code?
dosbd query wasm list-contract-by-code $CODE_ID_DIFI_CORE $NODE_DOSB --output json | jq
dosbd query wasm code $CODE_ID_DIFI_CORE $NODE_DOSB ../../target/wasm32-unknown-unknown/release/download_difi_core.wasm

## Instantiation
# set up these variables for convenience
export GP=$(dosbd keys show -a gp $HOME_DOSB) && \
export INVESTOR1=$(dosbd keys show -a investor1 $HOME_DOSB) && \
export INVESTOR2=$(dosbd keys show -a investor2 $HOME_DOSB) && \
export INVESTOR3=$(dosbd keys show -a investor3 $HOME_DOSB) && \
export TREASURER=$(dosbd keys show -a treasurer $HOME_DOSB) && \
export VALIDATOR1=$(dosbd keys show -a validator1 $HOME_DOSB)

dosbd q bank balances $(dosbd keys show gp -a $HOME_DOSB) $NODE_DOSB
dosbd q bank balances $GP $NODE_DOSB
dosbd q bank balances $INVESTOR1 $NODE_DOSB --output json | jq
dosbd q bank balances $TREASURER $NODE_DOSB
dosbd q bank balances $VALIDATOR1 $NODE_DOSB

# instantiate and get CONTRACT_ADDRESS_DIFI_CORE
# NOTE: get nft_code_id from cw-nfts (e.g., CODE_ID_721 = 6)
# NOTE: use gp as sender so gp is the owner in config
INIT_DIFI_CORE=$(jq -n --arg nft_code_id 6 --arg denom "uwfusd" '{ "nft_code_id": $nft_code_id | tonumber, "denom": $denom }') && \
RES=$(dosbd tx wasm instantiate $CODE_ID_DIFI_CORE "$INIT_DIFI_CORE" --from gp --label "difi-core" --no-admin $HOME_DOSB $TXFLAG_DOSB -y --output json) && \
CONTRACT_ADDRESS_DIFI_CORE=$(echo $RES | jq -r '.logs[0].events[-1].attributes[-1].value')
# or this is more reliable
CONTRACT_ADDRESS_DIFI_CORE=$(dosbd query wasm list-contract-by-code $CODE_ID_DIFI_CORE $NODE_DOSB --output json | jq -r '.contracts[-1]')

echo $CONTRACT_ADDRESS_DIFI_CORE

# contract info
dosbd q wasm contract-state raw $CONTRACT_ADDRESS_DIFI_CORE 636F6E74726163745F696E666F $NODE_DOSB
dosbd q wasm contract $CONTRACT_ADDRESS_DIFI_CORE $NODE_DOSB --output json | jq
dosbd q bank balances $CONTRACT_ADDRESS_DIFI_CORE $NODE_DOSB


## Query
# config
JSON=$(jq -n '{ "config": {} }') && \
dosbd query wasm contract-state smart $CONTRACT_ADDRESS_DIFI_CORE "$JSON" $NODE_DOSB --output json | jq

# nft_contract_address
JSON=$(jq -n --arg minter $INVESTOR1 --arg product "prius" '{ "nft_contract_address": {minter: $minter, product: $product} }') && \
RES=$(dosbd query wasm contract-state smart $CONTRACT_ADDRESS_DIFI_CORE "$JSON" $NODE_DOSB --output json) && \
NFT_CONTRACT_ADDRESS=$(echo $RES | jq -r '.data.resp.contract_addr')

echo $NFT_CONTRACT_ADDRESS

# DIRECT minter
JSON=$(jq -n '{ "minter": {} }') && \
dosbd query wasm contract-state smart $NFT_CONTRACT_ADDRESS "$JSON" $NODE_DOSB --output json | jq

# DIRECT nft_info
JSON=$(jq -n --arg token_id "VIN11" '{ "nft_info": { "token_id": $token_id } }') && \
dosbd query wasm contract-state smart $NFT_CONTRACT_ADDRESS "$JSON" $NODE_DOSB --output json | jq


## Execute
# create_nft_factory
# NOTE: use investor1 as mf/minter
JSON=$(jq -n --arg product "prius" '{ "create_nft_factory": { "product": $product } }') && \
dosbd tx wasm execute $CONTRACT_ADDRESS_DIFI_CORE "$JSON" --from investor1 $HOME_DOSB $TXFLAG_DOSB

# mint_nft
# NOTE: investor1 is minter
JSON=$(jq -n --arg product "prius" --arg token_id "VIN1" \
--arg k1 "year" --arg v1 "2024" --arg k2 "msp" --arg v2 "40000" --arg k3 "color" --arg v3 "black" --arg k4 "doors" --arg v4 "4" \
'{ "mint_nft": { "product": $product, "token_id": $token_id, "extension": { "name": $token_id, "attributes": [ { "trait_type": $k1, "value": $v1 }, { "trait_type": $k2, "value": $v2 }, { "trait_type": $k3, "value": $v3 }, { "trait_type": $k4, "value": $v4 } ] } } }') && \
res=$(dosbd tx wasm execute $CONTRACT_ADDRESS_DIFI_CORE "$JSON" --from investor1 $HOME_DOSB $TXFLAG_DOSB -y --output json)

# DIRECT mint: extension
JSON=$(jq -n --arg token_id "VIN11" --arg owner $INVESTOR1 \
--arg k1 "year" --arg v1 "2024" --arg k2 "msp" --arg v2 "40000" --arg k3 "color" --arg v3 "black" --arg k4 "doors" --arg v4 "4" \
'{ "mint": { "token_id": $token_id, "owner": $owner, "extension": { "name": $token_id, "attributes": [ { "trait_type": $k1, "value": $v1 }, { "trait_type": $k2, "value": $v2 }, { "trait_type": $k3, "value": $v3 }, { "trait_type": $k4, "value": $v4 } ] } } }') && \
res=$(dosbd tx wasm execute $NFT_CONTRACT_ADDRESS "$JSON" --from investor1 $HOME_DOSB $TXFLAG_DOSB -y --output json)



```
