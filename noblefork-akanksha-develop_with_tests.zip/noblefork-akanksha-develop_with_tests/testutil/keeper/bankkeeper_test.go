package keeper_test

import (
	"testing"

	math "cosmossdk.io/math"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/stretchr/testify/require"
	fiattokenfactorytypes "github.com/wfblockchain/noble-fiattokenfactory/x/fiattokenfactory/types"
	keepertest "github.com/wfblockchain/noblechain/v5/testutil/keeper"
	types "github.com/wfblockchain/noblechain/v5/x/tokenfactory/types"
)

func TestMockBankKeeper_SpendableCoins(t *testing.T) {

	mockBankKeeper := keepertest.MockBankKeeper{}
	ctx := sdk.Context{}
	addr := sdk.AccAddress([]byte("test-address"))
	spendableCoins := mockBankKeeper.SpendableCoins(ctx, addr)

	require.Nil(t, spendableCoins, "Expected SpendableCoins to return nil")
}

func TestMockBankKeeper_GetDenomMetadata(t *testing.T) {
	mockBankKeeper := keepertest.MockBankKeeper{}
	ctx := sdk.Context{}
	denom := "token"

	metadata, found := mockBankKeeper.GetDenomMetaData(ctx, denom)
	require.NotNil(t, metadata, "Expected metadata to be returned")
	require.True(t, found, "Expected denom to be found")
}

func TestMockBankKeeper_SendCoinsFromAccountToModule(t *testing.T) {
	mockBankKeeper := keepertest.MockBankKeeper{}
	ctx := sdk.Context{}
	senderAddr := sdk.AccAddress([]byte("test-sender-address"))
	recipientModule := "testmodule"
	amt := sdk.NewCoins(sdk.NewCoin("token", math.NewInt(100)))

	err := mockBankKeeper.SendCoinsFromAccountToModule(ctx, senderAddr, recipientModule, amt)
	require.NoError(t, err, "Expected no error from SendCoinsFromAccountToModule")
}

func TestMockBankKeeper_MintCoins(t *testing.T) {
	mockBankKeeper := keepertest.MockBankKeeper{}
	ctx := sdk.Context{}
	moduleName := "testmodule"
	amt := sdk.NewCoins(sdk.NewCoin("token", math.NewInt(100)))

	err := mockBankKeeper.MintCoins(ctx, moduleName, amt)
	require.NoError(t, err, "Expected no error from MintCoins")
}

func TestMockBankKeeper_BurnCoins(t *testing.T) {
	mockBankKeeper := keepertest.MockBankKeeper{}
	ctx := sdk.Context{}
	moduleName := "testmodule"
	amt := sdk.NewCoins(sdk.NewCoin("token", math.NewInt(100)))
	err := mockBankKeeper.BurnCoins(ctx, moduleName, amt)
	require.NoError(t, err, "Expected no error from BurnCoins")
}

func TestMockBankKeeper_SendCoinsFromModuleToAccount(t *testing.T) {
	mockBankKeeper := keepertest.MockBankKeeper{}
	ctx := sdk.Context{}
	senderModule := "testmodule"
	recipientAddr := sdk.AccAddress([]byte("test-address"))
	amt := sdk.NewCoins(sdk.NewCoin("token", math.NewInt(100)))
	err := mockBankKeeper.SendCoinsFromModuleToAccount(ctx, senderModule, recipientAddr, amt)
	require.NoError(t, err, "Expected no error from SendCoinsFromModuleToAccount")
}

func TestFiatTokenfactoryKeeper(t *testing.T) {
	k, ctx := keepertest.FiatTokenfactoryKeeper(t)
	require.NotNil(t, k, "Expected keeper to be initialized")
	require.NotNil(t, ctx, "Expected context to be initialized")

	params := k.GetParams(ctx)
	require.NotNil(t, params, "Expected params to be returned")

	newParams := fiattokenfactorytypes.Params{ /* fill with test data */ }
	k.SetParams(ctx, newParams)

	assertParams := k.GetParams(ctx)
	require.Equal(t, newParams, assertParams, "Expected params to be set correctly")
}

func TestTokenfactoryKeeper(t *testing.T) {
	k, ctx := keepertest.TokenfactoryKeeper(t)

	require.NotNil(t, k, "Expected keeper to be initialized")
	require.NotNil(t, ctx, "Expected context to be initialized")

	params := k.GetParams(ctx)
	require.NotNil(t, params, "Expected params to be returned")

	newParams := types.Params{}
	k.SetParams(ctx, newParams)
	assertParams := k.GetParams(ctx)
	require.Equal(t, newParams, assertParams, "Expected params to be set correctly")
}
