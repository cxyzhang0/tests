# Description: Dockerfile for testing tmkms p11hsm in linux.
#   Test result: musl is not working because it cannot dynamically load libpkcs11.so
#   Test result: gnu is working because it can dynamically load libpkcs11.so
# 2024-6-17: use ubi8 to test tmkms p11hsm diag slotinfo and login successfully.
FROM --platform=linux/amd64 registry.access.redhat.com/ubi8/ubi:8.9-1160.1715068735
#FROM --platform=linux/amd64 registry.access.redhat.com/ubi7/ubi:7.9-1328
#FROM --platform=linux/amd64 ubuntu:20.04

RUN yum -y install wget bzip2 gcc gcc-c++ glibc-headers
#RUN yum update glibc
#RUN yum install glibc

ENV FXPKCS11_CFG=/opt/futurex/fxpkcs11-redhat8-4.59-8551/fxpkcs11.cfg
#ENV FXPKCS11_CFG=/opt/futurex/fxpkcs11-linux-4.58-422d/fxpkcs11.cfg
ENV SOFTHSM2_CONF=/etc/softhsm2.conf

# docker login registry.redhat.io
# docker build -f p11hsm-rhubi.Dockerfile -t tmkms:p11hsm-rhubi .
# docker create --name tmkms-p11hsm-rhubi -i -v $(pwd):/tmkms -v $HOME/futurex:/opt/futurex -v /etc/softhsm2.conf:/etc/softhsm2.conf -v /var/lib/softhsm:/var/lib/softhsm -w /tmkms tmkms:p11hsm-rhubi
# docker start tmkms-p11hsm-rhubi
#
# docker exec -it tmkms-p11hsm-rhubi uname -s
# docker exec -it tmkms-p11hsm-rhubi ls -lsa ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release
# docker exec -it tmkms-p11hsm-rhubi ls -lsa /opt/futurex/fxpkcs11-linux-4.58-422d
# docker exec -it tmkms-p11hsm-rhubi ls -lsa /lib64
# docker exec -it tmkms-p11hsm-rhubi ls -lsa /lib/x86_64-linux-gnu

# with ubi8 which has glibc 2.28, we have not problem any more w.r.t. glibc version.
# docker exec -it tmkms-p11hsm-rhubi ldd --version
# 2.17 but need 2.25+; this site has a tedious way to upgrade glibc - not done here yet: https://github.com/directus/directus/issues/6071
# docker exec -it tmkms-p11hsm-rhubi /lib/x86_64-linux-gnu/libc.so.6
# glibc download link: https://ftp.gnu.org/gnu/glibc, or https://ftp.gnu.org/gnu/libc/
# manual install glibc: https://stackoverflow.com/questions/32316707/rhel-6-how-to-install-glibc-2-14-or-glibc-2-15
# docker exec -it tmkms-p11hsm-rhubi yum update glibc
# docker exec -it tmkms-p11hsm-rhubi rpm -q glibc-common
# docker exec -it tmkms-p11hsm-rhubi subscription-manager repos
# docker exec -it tmkms-p11hsm-rhubi yum-config-manager
# docker exec -it tmkms-p11hsm-rhubi strings /lib64/libc.so.6 | grep GLIBC
# docker exec -it tmkms-p11hsm-rhubi gcc -v

# docker exec -it tmkms-p11hsm-rhubi /opt/futurex/fxpkcs11-linux-4.58-422d/configTest
# docker exec -it tmkms-p11hsm-rhubi ls -lsa /usr/local/lib/softhsm
# docker exec -it tmkms-p11hsm-rhubi ls -lsa /var/lib/softhsm
# docker exec -it tmkms-p11hsm-rhubi ls -lsa /etc
# docker exec -it tmkms-p11hsm-rhubi openssl engine -vvvv

# docker exec -it tmkms-p11hsm-rhubi ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm diag --help
# docker exec -it tmkms-p11hsm-rhubi ./target-p11-val-cli-musl/x86_64-unknown-linux-musl/release/tmkms p11hsm diag --help
# musl not working: docker exec -it tmkms-p11hsm ./target-p11-val-cli-musl/x86_64-unknown-linux-musl/release/tmkms p11hsm diag p11context -c ./tmkms.docker.toml
# docker exec -it tmkms-p11hsm-rhubi ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm diag p11context -c ./tmkms.docker.toml
# docker exec -it tmkms-p11hsm-rhubi ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm diag slotcount -i futurex -c ./tmkms.docker.toml
# docker exec -it tmkms-p11hsm-rhubi ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm diag slotinfo -i futurex -c ./tmkms.docker.toml
# docker exec -it tmkms-p11hsm-rhubi ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm diag login -i futurex -c ./tmkms.docker.toml

# docker exec -it tmkms-p11hsm-rhubi ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm keys generate -i futurex -t "Slot Token 0" -l "virtucrypt/tokenfactory/validator-1/1" -c ./tmkms.docker.toml
# docker exec -it tmkms-p11hsm-rhubi ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm keys sign-verify -i futurex -t "Slot Token 0" -l "virtucrypt/tokenfactory/validator-1/1" -m "hello world" -c ./tmkms.docker.toml

# test sed in Linux
# docker exec -it tmkms-p11hsm-rhubi sed -i -e 's#id = ".*"#id = "changed"#g' /tmkms/temp/temp.toml