# Description: Dockerfile for testing tmkms p11hsm in linux.
#   Test result: musl is not working because it cannot dynamically load libpkcs11.so
#   Test result: gnu is working because it can dynamically load libpkcs11.so
#FROM --platform=linux/amd64 ubuntu:20.04
FROM --platform=linux/amd64 registry.redhat.io/rhel7:7.9-1314

RUN yum install glibc

ENV FXPKCS11_CFG=/opt/futurex/fxpkcs11-linux-4.58-422d/fxpkcs11.cfg
ENV SOFTHSM2_CONF=/etc/softhsm2.conf

# docker login registry.redhat.io
# docker build -f p11hsm-rh.Dockerfile -t tmkms:p11hsm-rh .
# docker create --name tmkms-p11hsm-rh -i -v $(pwd):/tmkms -v $HOME/futurex:/opt/futurex -v /etc/softhsm2.conf:/etc/softhsm2.conf -v /var/lib/softhsm:/var/lib/softhsm -w /tmkms tmkms:p11hsm-rh
# docker start tmkms-p11hsm-rh
#
# docker exec -it tmkms-p11hsm-rh ls -lsa ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release
# docker exec -it tmkms-p11hsm-rh ls -lsa /opt/futurex/fxpkcs11-linux-4.58-422d
# docker exec -it tmkms-p11hsm-rh ls -lsa /lib64
# docker exec -it tmkms-p11hsm-rh ls -lsa /lib/x86_64-linux-gnu
# docker exec -it tmkms-p11hsm-rh ldd --version
# docker exec -it tmkms-p11hsm-rh /lib/x86_64-linux-gnu/libc.so.6
# glibc download link: https://ftp.gnu.org/gnu/glibc, or https://ftp.gnu.org/gnu/libc/
# manual install glibc: https://stackoverflow.com/questions/32316707/rhel-6-how-to-install-glibc-2-14-or-glibc-2-15
# docker exec -it tmkms-p11hsm-rh yum update glibc
# docker exec -it tmkms-p11hsm-rh rpm -q glibc-common
# docker exec -it tmkms-p11hsm-rh subscription-manager repos
# docker exec -it tmkms-p11hsm-rh yum-config-manager

# docker exec -it tmkms-p11hsm-rh /opt/futurex/fxpkcs11-linux-4.58-422d/configTest
# docker exec -it tmkms-p11hsm-rh ls -lsa /usr/local/lib/softhsm
# docker exec -it tmkms-p11hsm-rh ls -lsa /var/lib/softhsm
# docker exec -it tmkms-p11hsm-rh ls -lsa /etc
# docker exec -it tmkms-p11hsm-rh openssl engine -vvvv

# docker exec -it tmkms-p11hsm-rh ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm diag --help
# docker exec -it tmkms-p11hsm-rh ./target-p11-val-cli-musl/x86_64-unknown-linux-musl/release/tmkms p11hsm diag --help
# musl not working: docker exec -it tmkms-p11hsm ./target-p11-val-cli-musl/x86_64-unknown-linux-musl/release/tmkms p11hsm diag p11context -c ./tmkms.docker.toml
# docker exec -it tmkms-p11hsm-rh ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm diag p11context -c ./tmkms.docker.toml
# the following gets SSL connection error: p12 is wrong tag of asn.1 encoding. that is with FX hsm.
# docker exec -it tmkms-p11hsm-rh ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm diag slotcount -c ./tmkms.docker.toml
