use abscissa_core::path::AbsPathBuf;
use abscissa_core::testing::CmdRunner;
use abscissa_core::Config;
use cryptoki::context::{CInitializeArgs, Pkcs11};
use cryptoki::session::UserType;
use cryptoki::slot::Slot;
use cryptoki::types::AuthPin;
use lazy_static::lazy_static;
use once_cell::sync::{Lazy, OnceCell};
use pkcs11_sdk::{CryptographAlgorithm, Error, KeyLabel, SDKContext, SDK};
use rand::Rng;
use std::net::TcpStream;
use std::os::unix::net::UnixStream;
use std::sync::{Mutex, Once};
use std::{env, io};
use tendermint_p2p::secret_connection;
use tendermint_p2p::secret_connection::SecretConnection;
use tmkms::config::provider::KeyType;
use tmkms::config::KmsConfig;
use tmkms::connection::unix::UnixConnection;

#[allow(dead_code)]
pub static ENV_SOFTHSM2_CONF: &str = "SOFTHSM2_CONF";
#[allow(dead_code)]
pub static SOFTHSM2_CONF: &str = "tests/support/softhsm2.conf";
// pub static ENV_MODULE: &str = "PKCS11_SOFTHSM2_MODULE";
#[cfg(target_os = "macos")]
pub static MODULE: &str = "tests/support/libsofthsm2-mac.so";
#[cfg(target_os = "linux")]
pub static MODULE: &str = "./tests/support/libsofthsm2-linux.so";
pub static USER_PIN: &str = "5678";
#[allow(dead_code)]
pub static SO_PIN: &str = "1234";
pub static TOKEN_LABEL: &str = "Slot Token 0";
#[allow(dead_code)]
pub static mut KEY_GENED: Mutex<bool> = Mutex::new(false);

#[allow(dead_code)]
pub static CHAIN_ID: &str = "test_chain_id";
// make sure TCP_SOCKET_ADDR is consistent with that in TMKMS_CONFIG_FILE_TCP file
#[allow(dead_code)]
pub static TMKMS_CONFIG_FILE_TCP: &str = "tests/support/tmkms-tcp.toml";
#[allow(dead_code)]
pub static TCP_SOCKET_HOST: &str = "localhost";
// pub static TCP_SOCKET_ADDR: &str = "localhost:26658";
// make sure UNIX_SOCKET_ADDR is consistent with that in TMKMS_CONFIG_FILE_UNIX file
#[allow(dead_code)]
pub static TMKMS_CONFIG_FILE_UNIX: &str = "tests/support/tmkms-unix.toml";
#[allow(dead_code)]
pub static UNIX_SOCKET_ADDR_PREFIX: &str = "/tmp/tmkms";
/// Path to the KMS executable or cargo run
#[allow(dead_code)]
pub static KMS_EXE_PATH: &str = "target/debug/tmkms";
// pub static KMS_EXE_PATH: &str = "cargo";

/// Path to the example validator signing key
#[allow(dead_code)]
pub static SECRET_CONNECTION_KEY_PATH: &str = "tests/support/secret_connection.key";

lazy_static! {
    pub static ref ED_KEY_LABEL: String = format!("{}/{}", TOKEN_LABEL, "test/ed25519/1");
    pub static ref ED_KL: KeyLabel =
        KeyLabel::from_short(&ED_KEY_LABEL, CryptographAlgorithm::Ed25519).expect("ED_KEY_LABEL");
    pub static ref K256_KEY_LABEL: String = format!("{}/{}", TOKEN_LABEL, "test/secp256k1/1");
    pub static ref K256_KL: KeyLabel =
        KeyLabel::from_short(&K256_KEY_LABEL, CryptographAlgorithm::Secp256k1)
            .expect("ED_KEY_LABEL");
}

#[allow(dead_code)]
pub static RUNNER: Lazy<CmdRunner> = Lazy::new(|| CmdRunner::default());

#[allow(dead_code)]
pub enum SocketType {
    /// TCP socket type
    TCP,

    /// UNIX socket type
    UNIX,
}
#[allow(dead_code)]
pub enum KmsSocket {
    /// TCP socket type
    TCP(TcpStream),

    /// UNIX socket type
    UNIX(UnixStream),
}

pub enum KmsConnection {
    #[allow(dead_code)]
    /// Secret connection type
    Tcp(SecretConnection<TcpStream>),

    #[allow(dead_code)]
    /// UNIX connection type
    Unix(UnixConnection<UnixStream>),
}

impl io::Write for KmsConnection {
    fn write(&mut self, data: &[u8]) -> Result<usize, io::Error> {
        match *self {
            KmsConnection::Tcp(ref mut conn) => conn.write(data),
            KmsConnection::Unix(ref mut conn) => conn.write(data),
        }
    }

    fn flush(&mut self) -> Result<(), io::Error> {
        match *self {
            KmsConnection::Tcp(ref mut conn) => conn.flush(),
            KmsConnection::Unix(ref mut conn) => conn.flush(),
        }
    }
}

impl io::Read for KmsConnection {
    fn read(&mut self, data: &mut [u8]) -> Result<usize, io::Error> {
        match *self {
            KmsConnection::Tcp(ref mut conn) => conn.read(data),
            KmsConnection::Unix(ref mut conn) => conn.read(data),
        }
    }
}

#[allow(dead_code)]
struct Init {
    ctx: SDKContext,
    _sdk: Mutex<SDK>,
}
#[allow(dead_code)]
static INIT_CALL: Once = Once::new();

#[allow(dead_code)]
static INIT_CELL: OnceCell<Init> = OnceCell::new();

#[allow(dead_code)]
fn init_test_sdk() -> pkcs11_sdk::Result<&'static SDKContext> {
    init_config();

    let init = INIT_CELL.get_or_try_init(|| {
        print!("init_test_sdk - inside calling init_pins\n");
        let (p11, slot) = init_pins()?;

        let ctx = SDKContext::new_with_slot(p11, slot);

        // let sdk = SDK::from_context_with_login(&ctx, pin)?;
        let mut sdk = SDK::from_context(&ctx)?;
        sdk.login(USER_PIN)?;

        Ok(Init {
            ctx,
            _sdk: Mutex::new(sdk),
        })
    });

    init.map(|i| &i.ctx)
}

#[allow(dead_code)]
pub fn get_test_ctx() -> pkcs11_sdk::Result<&'static SDKContext> {
    let ctx = init_test_sdk()?;

    Ok(ctx)
}
#[allow(dead_code)]
pub fn get_test_sdk() -> pkcs11_sdk::Result<SDK> {
    let ctx = get_test_ctx()?;
    let mut sdk = SDK::from_context(&ctx)?;

    if !sdk.is_authorized() {
        sdk.login(USER_PIN)?;
    }

    Ok(sdk)
}
#[allow(dead_code)]
pub fn get_test_pkcs11() -> pkcs11_sdk::Result<Pkcs11> {
    // Pkcs11::new(
    //     env::var(ENV_MODULE)
    //         .unwrap_or_else(|_| MODULE.to_string()),
    // )
    //     .map_err(|e| Error::from(e))
    Pkcs11::new(MODULE.to_string()).map_err(|e| Error::from(e))
}

#[allow(dead_code)]
pub fn init_config() {
    INIT_CALL.call_once(|| {
        env::set_var(ENV_SOFTHSM2_CONF, SOFTHSM2_CONF);
    });
}

#[allow(dead_code)]
pub fn init_pins() -> pkcs11_sdk::Result<(Pkcs11, Slot)> {
    init_config();

    let pkcs11 = get_test_pkcs11()?;

    // initialize the library
    pkcs11.initialize(CInitializeArgs::OsThreads)?;

    // find a slot, get the first one
    let slot = pkcs11.get_slots_with_token()?.remove(0);

    let so_pin = AuthPin::new(SO_PIN.into());
    pkcs11.init_token(slot, &so_pin, TOKEN_LABEL)?;

    {
        // open a session
        let session = pkcs11.open_rw_session(slot)?;
        // log in the session
        session.login(UserType::So, Some(&so_pin))?;
        session.init_pin(&AuthPin::new(USER_PIN.into()))?;
    };

    Ok((pkcs11, slot))
}

#[allow(dead_code)]
pub fn keygen() -> pkcs11_sdk::Result<()> {
    unsafe {
        if *KEY_GENED.lock()? {
            return Ok(());
        }
    }

    let sdk = get_test_sdk()?;

    // test keygen for ed25519
    let mut key_label = KeyLabel::from_short(&ED_KEY_LABEL, CryptographAlgorithm::Ed25519)?;

    let persistent = true;

    let (_, _, _) = sdk.keygen(&mut key_label, persistent)?;

    // test keygen for k256
    let mut key_label = KeyLabel::from_short(&K256_KEY_LABEL, CryptographAlgorithm::Secp256k1)?;

    let persistent = true;

    let (_, _, _) = sdk.keygen(&mut key_label, persistent)?;

    // test keygen for k256 2
    // with same lable, sdk will generate version 2
    // let mut key_label = KeyLabel::from_short(&K256_KEY_LABEL, CryptographAlgorithm::Secp256k1)?;
    //
    // let persistent = true;
    //
    // let (_, _, _) = sdk.keygen(&mut key_label, persistent)?;

    sdk.close()?;

    unsafe {
        KEY_GENED = Mutex::from(true);
    }

    Ok(())
}

// generate a random tcp port
#[allow(dead_code)]
pub fn random_tcp_port() -> u16 {
    let port: u16 = rand::thread_rng().gen_range(60000..=65535);
    port
}

// generate a random letter and number for unix socket
#[allow(dead_code)]
pub fn random_unix_parts() -> (char, u32) {
    // Create a random socket path
    let mut rng = rand::thread_rng();
    let letter: char = rng.gen_range(b'a'..=b'z') as char;
    let number: u32 = rng.gen_range(0..=999999);

    (letter, number)
}

#[allow(dead_code)]
pub fn tmkms_config_file(socket_type: SocketType) -> &'static str {
    match socket_type {
        SocketType::TCP => TMKMS_CONFIG_FILE_TCP,
        SocketType::UNIX => TMKMS_CONFIG_FILE_UNIX,
    }
}

/// returns the addr and full addr for the socket type
/// tcp example: addr = "localhost:port", full_addr = "tcp://peer_id@addr"
/// unix example: addr = "/tmp/tmkms-y123456.sock", full_addr = "unix://addr"
#[allow(dead_code)]
pub fn tmkms_socket_addr(socket_type: SocketType) -> (String, String) {
    match socket_type {
        SocketType::TCP => {
            let pub_key = test_ed25519_secret_connection_keypair().verifying_key();
            let peer_id = secret_connection::PublicKey::from(pub_key).peer_id();
            let port = random_tcp_port();
            let addr = format!("{TCP_SOCKET_HOST}:{port}");
            let full_addr = format!("tcp://{peer_id}@{addr}");
            (addr, full_addr)
        }
        SocketType::UNIX => {
            let (letter, number) = random_unix_parts();

            let addr = format!("{UNIX_SOCKET_ADDR_PREFIX}-{letter}{number:06}.sock");
            let full_addr = format!("unix://{addr}");
            (addr, full_addr)
        }
    }
}

#[allow(dead_code)]
pub fn tmkms_config_toml_string(full_addr: &str, key_type: &KeyType) -> String {
    let toml_str = format!(
        r#"
            [[validator]]
            id = "val-1"
            addr = "{full_addr}"
            chain_id = "{CHAIN_ID}"
            max_height = "500000"
            reconnect = false            
            key_format = {{ type = "bech32", account_key_prefix = "wf", consensus_key_prefix = "wf" }}     
            sign_extensions = true
            secret_key = "tests/support/secret_connection.key"
            protocol_version = "v0.34"
        
            [[providers.p11hsm]]
            id = "softhsm"
            module = "{MODULE}"
            env_cfg = "SOFTHSM2_CONF"
            cfg = "tests/support/softhsm2.conf"
            hsms = [
                {{ token_label = "{TOKEN_LABEL}", user_pin = "{USER_PIN}", signing_keys = [ {{ val_ids = ["val-1"], key_type = "{}", key_label = "{}" }},]}},
                ]
        "#,
        key_type,
        test_key_label(key_type)
    );
    toml_str
}

#[allow(dead_code)]
pub fn load_tmkms_config(socket_type: SocketType) -> Result<KmsConfig, tmkms::error::Error> {
    let p = AbsPathBuf::canonicalize(tmkms_config_file(socket_type))?;
    let config = KmsConfig::load_toml_file(p).map_err(|e| {
        tmkms::error::ErrorKind::ConfigError.context(format!("failed to load tmkms config: {}", e))
    })?;
    // assert_eq!(config.providers.p11hsm.len(), 1);;
    Ok(config)
}

/// get the secret connection keypair used by the tests; it is ed25519.
#[allow(dead_code)]
pub fn test_ed25519_secret_connection_keypair() -> tmkms::keyring::ed25519::SigningKey {
    tmkms::key_utils::load_base64_ed25519_key(SECRET_CONNECTION_KEY_PATH).unwrap()
}

/// get the key label str
#[allow(dead_code)]
pub fn test_key_label(key_type: &KeyType) -> &str {
    match key_type {
        KeyType::Account => &K256_KEY_LABEL,
        KeyType::Consensus => &ED_KEY_LABEL,
    }
}

#[allow(dead_code)]
/// get the key label
pub fn test_kl(key_type: &KeyType) -> &KeyLabel {
    match key_type {
        KeyType::Account => &K256_KL,
        KeyType::Consensus => &ED_KL,
    }
}
