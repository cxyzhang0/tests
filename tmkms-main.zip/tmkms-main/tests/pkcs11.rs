use cosmrs::crypto::PublicKey as CosmrsPublicKey;
use cosmrs::proto::cosmos::crypto::ed25519::PubKey as CosmosEdPubKey;
use prost::Message;
use subtle_encoding::{base64, hex};

// Turn on either SOFTHSM2 or FutureX by commenting out the other below.
// SOFTHSM2

// The env for module if any
pub static ENV_MODULE: &str = "PKCS11_SOFTHSM2_MODULE";
// The default module path
pub static MODULE: &str = "/usr/local/lib/softhsm/libsofthsm2.so";
// The default user pin
pub static USER_PIN: &str = "5678";
// The default SO pin
pub static _SO_PIN: &str = "1234";
// The default token label
pub static TOKEN_LABEL: &str = "Slot Token 0";
// config
pub const ENV_CONF: &str = "SOFTHSM2_CONF";
pub const CONF: &str = "/etc/softhsm2.conf";

// FutureX
/*
pub static ENV_MODULE: &str = "FXPKCS11_MODULE";
// The default module path
pub static MODULE: &str = "/Users/johnz/futurex/fxpkcs11-mac-arm-4.58-422d/libfxpkcs11.dylib";
// The default user pin
pub static USER_PIN: &str = "safest";
// The default SO pin
pub static _SO_PIN: &str = "1234";
// The default token label
pub static TOKEN_LABEL: &str = "us01crypto01test.virtucrypt.com:";
// config
pub const ENV_CFG: &str = "FXPKCS11_CFG";
pub const CFG: &str = "/Users/johnz/futurex/fxpkcs11-mac-arm-4.58-422d/fxpkcs11.cfg";

*/

// public key for wfchain-1 and testchain-1 validator
const SOFT_PUB_KEY_B64: &str = "DRvpQ98n4/WeY/1x7Tw9l/yG0guNtkQmPH+51eYZwLo=";
const SOFT_PUB_KEY_JSON: &str = "{\"@type\":\"/cosmos.crypto.ed25519.PubKey\",\"key\":\"DRvpQ98n4/WeY/1x7Tw9l/yG0guNtkQmPH+51eYZwLo=\"}";
// const SOFT_PUB_KEY_JSON: &str = r#"{"@type":"/cosmos.crypto.ed25519.PubKey","key":"DRvpQ98n4/WeY/1x7Tw9l/yG0guNtkQmPH+51eYZwLo="}"#;
// public key for SoftHSM "Slot Token 0/WIM-test/id-ed25519-hsm-1/2"
const SOFTHSM_PUB_KEY_HEX_1: &str =
    "1743d16e9c3cd035c95dee235b66301072354cd89ac504136f7fa2c373cb2fc3";
const SOFTHSM_PUB_KEY_JSON_1: &str = "{\"@type\":\"/cosmos.crypto.ed25519.PubKey\",\"key\":\"F0PRbpw80DXJXe4jW2YwEHI1TNiaxQQTb3+iw3PLL8M=\"}";
// public key for SoftHSM "Slot Token 0/WIM-test/id-ed25519-hsm-1/3"
const SOFTHSM_PUB_KEY_HEX_2: &str =
    "78101dd3673ced48a56bf0d2239bc874895d503868c2e11a09e37aa5fbc75645";
const SOFTHSM_PUB_KEY_JSON_2: &str = "{\"@type\":\"/cosmos.crypto.ed25519.PubKey\",\"key\":\"eBAd02c87Uila/DSI5vIdIldUDhowuEaCeN6pfvHVkU=\"}";
// public key for SoftHSM "Slot Token 0/WIM-test/id-ed25519-hsm-1/4"
const SOFTHSM_PUB_KEY_HEX_3: &str =
    "b258fff60294f719ec134a44ea670d920c91b47b927f808189f342a3f6105ecf";
const SOFTHSM_PUB_KEY_JSON_3: &str = "{\"@type\":\"/cosmos.crypto.ed25519.PubKey\",\"key\":\"slj/9gKU9xnsE0pE6mcNkgyRtHuSf4CBifNCo/YQXs8=\"}";
// public key for SoftHSM "Slot Token 0/WIM-test/id-ed25519-hsm-1/5"
const SOFTHSM_PUB_KEY_HEX_4: &str =
    "a5d3280881e1ca0f09203dacc16fbebe1d8948cfed0edf88f3454bc5d4ea87cc";
const SOFTHSM_PUB_KEY_JSON_4: &str = "{\"@type\":\"/cosmos.crypto.ed25519.PubKey\",\"key\":\"pdMoCIHhyg8JID2swW++vh2JSM/tDt+I80VLxdTqh8w=\"}";

// public key for FX HSM "Slot Token 0/WIM-test/id-ed25519-hsm-1/2"
const FXHSM_PUB_KEY_HEX_1: &str =
    "1f9eda4eebccb5d3ac6296799b356de94b753fe435d582afa229080ce9eb2c76";
const FXHSM_PUB_KEY_JSON_1: &str = "{\"@type\":\"/cosmos.crypto.ed25519.PubKey\",\"key\":\"H57aTuvMtdOsYpZ5mzVt6Ut1P+Q11YKvoikIDOnrLHY=\"}";
// public key for FX HSM "Slot Token 0/WIM-test/id-ed25519-hsm-1/3"
const FXHSM_PUB_KEY_HEX_2: &str =
    "4400fee5224dd219d963196b2c2d6b5a3008f15c88fc1bdd258c4450f4a5ad35";
const FXHSM_PUB_KEY_JSON_2: &str = "{\"@type\":\"/cosmos.crypto.ed25519.PubKey\",\"key\":\"RAD+5SJN0hnZYxlrLC1rWjAI8VyI/BvdJYxEUPSlrTU=\"}";

/// Convert an ed25519 public key from base64 to json
#[ignore]
#[test]
fn it_pk_b64_to_json() {
    let bytes = base64::decode(SOFT_PUB_KEY_B64).unwrap();
    let pub_key = CosmosEdPubKey { key: bytes };

    println!("decoded: {:?} of len: {}", pub_key.key, pub_key.key.len());

    let cosmos_public_key = CosmrsPublicKey::try_from(pub_key.clone()).unwrap();

    // let cosmos_public_key = CosmosPublicKey(tm_public_key);
    println!("json: {:?}", cosmos_public_key.to_json());
    assert_eq!(cosmos_public_key.to_json(), SOFT_PUB_KEY_JSON);
}

#[ignore]
#[test]
fn it_pk_hex_to_json() {
    // SoftHSM "Slot Token 0/WIM-test/id-ed25519-hsm-1/2"
    let bytes = hex::decode(SOFTHSM_PUB_KEY_HEX_1).unwrap();
    let pub_key = CosmosEdPubKey { key: bytes };

    println!(
        "SoftHSM public key 1 decoded: {:?} of len: {}",
        pub_key.key,
        pub_key.key.len()
    );

    let cosmos_public_key = CosmrsPublicKey::try_from(pub_key.clone()).unwrap();

    println!("json: {:?}", cosmos_public_key.to_json());
    assert_eq!(cosmos_public_key.to_json(), SOFTHSM_PUB_KEY_JSON_1);

    // SoftHSM "Slot Token 0/WIM-test/id-ed25519-hsm-1/3"
    let bytes = hex::decode(SOFTHSM_PUB_KEY_HEX_2).unwrap();
    let pub_key = CosmosEdPubKey { key: bytes };

    println!(
        "SoftHSM public key 2 decoded: {:?} of len: {}",
        pub_key.key,
        pub_key.key.len()
    );

    let cosmos_public_key = CosmrsPublicKey::try_from(pub_key.clone()).unwrap();

    println!("json: {:?}", cosmos_public_key.to_json());
    assert_eq!(cosmos_public_key.to_json(), SOFTHSM_PUB_KEY_JSON_2);

    // SoftHSM "Slot Token 0/WIM-test/id-ed25519-hsm-1/4"
    let bytes = hex::decode(SOFTHSM_PUB_KEY_HEX_3).unwrap();
    let pub_key = CosmosEdPubKey { key: bytes };

    println!(
        "SoftHSM public key 3 decoded: {:?} of len: {}",
        pub_key.key,
        pub_key.key.len()
    );

    let cosmos_public_key = CosmrsPublicKey::try_from(pub_key.clone()).unwrap();

    println!("json: {:?}", cosmos_public_key.to_json());
    assert_eq!(cosmos_public_key.to_json(), SOFTHSM_PUB_KEY_JSON_3);

    // SoftHSM "Slot Token 0/WIM-test/id-ed25519-hsm-1/5"
    let bytes = hex::decode(SOFTHSM_PUB_KEY_HEX_4).unwrap();
    let pub_key = CosmosEdPubKey { key: bytes };

    println!(
        "SoftHSM public key 4 decoded: {:?} of len: {}",
        pub_key.key,
        pub_key.key.len()
    );

    let cosmos_public_key = CosmrsPublicKey::try_from(pub_key.clone()).unwrap();

    println!("json: {:?}", cosmos_public_key.to_json());
    assert_eq!(cosmos_public_key.to_json(), SOFTHSM_PUB_KEY_JSON_4);

    // FX HSM "Slot Token 0/WIM-test/id-ed25519-hsm-1/2"
    let bytes = hex::decode(FXHSM_PUB_KEY_HEX_1).unwrap();
    let pub_key = CosmosEdPubKey { key: bytes };

    println!(
        "FX HSM public key 1 decoded: {:?} of len: {}",
        pub_key.key,
        pub_key.key.len()
    );

    let cosmos_public_key = CosmrsPublicKey::try_from(pub_key.clone()).unwrap();

    println!("json: {:?}", cosmos_public_key.to_json());
    assert_eq!(cosmos_public_key.to_json(), FXHSM_PUB_KEY_JSON_1);

    // FX HSM "Slot Token 0/WIM-test/id-ed25519-hsm-1/3"
    let bytes = hex::decode(FXHSM_PUB_KEY_HEX_2).unwrap();
    let pub_key = CosmosEdPubKey { key: bytes };

    println!(
        "FX HSM public key 2 decoded: {:?} of len: {}",
        pub_key.key,
        pub_key.key.len()
    );

    let cosmos_public_key = CosmrsPublicKey::try_from(pub_key.clone()).unwrap();

    println!("json: {:?}", cosmos_public_key.to_json());
    assert_eq!(cosmos_public_key.to_json(), FXHSM_PUB_KEY_JSON_2);
}

#[ignore]
#[test]
fn it_p11signer() {
    // let signer = P11Signer::new(
    //     "Slot Token 0/WIM-test/id-ed25519-hsm-1/2",
    //     "5678",
    //     "http://localhost:8080/v1/msg-relay",
    // );
    //
    // let msg = "hello world";
    // let sig = signer.sign(msg.as_bytes()).unwrap();
    // println!("signature: {:?}", sig);
    //
    // let verified = signer.verify(msg.as_bytes(), &sig).unwrap();
    // assert_eq!(verified, true);
}
