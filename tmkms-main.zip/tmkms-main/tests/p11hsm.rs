//! These test individual p11hsm-related functions used in various modules
//! such as src/p11hsm.rs and src/keyring/providers/p11hsm.rs.
//! they are more like unit tests but they are using softhsm.
//! they interfere with those integration-hsm tests because they don't use INIT_CELL.

use crate::common::{load_tmkms_config, test_kl, SocketType, TOKEN_LABEL};
use abscissa_core::Config;
use k256::ecdsa;
use serial_test::serial;
use signature::Signer;
use std::sync::{Arc, Mutex};
use tmkms::config::provider::KeyType;
use tmkms::config::KmsConfig;
use tmkms::keyring::providers;
use tmkms::keyring::providers::p11hsm::P11Signer;
use tmkms::p11hsm::{get_sdk, make_pkcs11_sdk, make_sdk_context_without_slot};
use tmkms::validator::{Registry, Validator};

mod common;

/// initialize p11hsm provider with a dynamically-generated temp config toml file
fn generate_kms_config_via_temp_config(
    key_type: &KeyType,
    socket_type: SocketType,
) -> pkcs11_sdk::Result<KmsConfig> {
    let (_addr, full_addr) = common::tmkms_socket_addr(socket_type);
    let toml_string = common::tmkms_config_toml_string(&full_addr, key_type);
    KmsConfig::load_toml(toml_string)
        .map_err(|e| pkcs11_sdk::error::Error::GenericError(format!("{:?}", e)))
}

/// initialize p11hsm provider with a dynamically-generated temp config toml file
fn generate_initialized_p11hsm_provider_via_temp_config(
    key_type: &KeyType,
    socket_type: SocketType,
) -> pkcs11_sdk::Result<(Registry, KmsConfig)> {
    // let (addr, full_addr) = common::tmkms_socket_addr(socket_type);
    // let toml_string = common::tmkms_config_toml_string(&full_addr, key_type);
    // let kms_config = KmsConfig::load_toml(toml_string).unwrap();
    let kms_config = generate_kms_config_via_temp_config(key_type, socket_type).unwrap();

    let mut registry = Registry::default();
    let val = Validator::from_config(&kms_config.validator[0]).unwrap();
    registry.register_validator(val).unwrap();

    providers::p11hsm::init(&mut registry, &kms_config.providers.p11hsm)
        .map_err(|e| pkcs11_sdk::error::Error::GenericError(format!("{:?}", e)))?;
    Ok((registry, kms_config))
}

/// initialize p11hsm provider with a physical config toml string
fn _get_initialized_p11hsm_provider() -> pkcs11_sdk::Result<(Registry, KmsConfig)> {
    let kms_config = load_tmkms_config(SocketType::TCP).unwrap();
    let mut registry = Registry::default();
    let val = Validator::from_config(&kms_config.validator[0]).unwrap();
    registry.register_validator(val).unwrap();

    providers::p11hsm::init(&mut registry, &kms_config.providers.p11hsm)
        .map_err(|e| pkcs11_sdk::error::Error::GenericError(format!("{:?}", e)))?;
    Ok((registry, kms_config))
}
#[test]
#[serial]
fn it_make_sdk_context_without_slot_account_tcp() {
    let kms_config =
        generate_kms_config_via_temp_config(&KeyType::Account, SocketType::TCP).unwrap();
    // let kms_config = load_tmkms_config(SocketType::TCP).unwrap();

    let config = kms_config.providers.p11hsm[0].clone();
    let r = make_sdk_context_without_slot(&config);

    assert!(r.is_ok());
}

#[test]
#[serial]
fn it_make_sdk_context_without_slot_consensus_tcp() {
    let kms_config =
        generate_kms_config_via_temp_config(&KeyType::Consensus, SocketType::TCP).unwrap();

    let config = kms_config.providers.p11hsm[0].clone();
    let r = make_sdk_context_without_slot(&config);

    assert!(r.is_ok());
}

#[test]
#[serial]
fn it_make_sdk_context_without_slot_account_unix() {
    let kms_config =
        generate_kms_config_via_temp_config(&KeyType::Account, SocketType::UNIX).unwrap();

    let config = kms_config.providers.p11hsm[0].clone();
    let r = make_sdk_context_without_slot(&config);

    assert!(r.is_ok());
}

#[test]
#[serial]
fn it_make_sdk_context_without_slot_consensus_unix() {
    let kms_config =
        generate_kms_config_via_temp_config(&KeyType::Consensus, SocketType::UNIX).unwrap();

    let config = kms_config.providers.p11hsm[0].clone();
    let r = make_sdk_context_without_slot(&config);

    assert!(r.is_ok());
}

#[test]
#[serial]
fn it_make_pkcs11_sdk_account_tcp() {
    let kms_config =
        generate_kms_config_via_temp_config(&KeyType::Account, SocketType::TCP).unwrap();
    let config = kms_config.providers.p11hsm[0].clone();
    let mut ctx = make_sdk_context_without_slot(&config).unwrap();
    let config = config.hsms[0].clone();
    let r = make_pkcs11_sdk(&mut ctx, &config);

    assert!(r.is_ok());
}

#[test]
#[serial]
fn it_make_pkcs11_sdk_consensus_tcp() {
    let kms_config =
        generate_kms_config_via_temp_config(&KeyType::Consensus, SocketType::TCP).unwrap();
    let config = kms_config.providers.p11hsm[0].clone();
    let mut ctx = make_sdk_context_without_slot(&config).unwrap();
    let config = config.hsms[0].clone();
    let r = make_pkcs11_sdk(&mut ctx, &config);

    assert!(r.is_ok());
}

#[test]
#[serial]
fn it_make_pkcs11_sdk_account_unix() {
    let kms_config =
        generate_kms_config_via_temp_config(&KeyType::Account, SocketType::UNIX).unwrap();
    let config = kms_config.providers.p11hsm[0].clone();
    let mut ctx = make_sdk_context_without_slot(&config).unwrap();
    let config = config.hsms[0].clone();
    let r = make_pkcs11_sdk(&mut ctx, &config);

    assert!(r.is_ok());
}

#[test]
#[serial]
fn it_make_pkcs11_sdk_consensus_unix() {
    let kms_config =
        generate_kms_config_via_temp_config(&KeyType::Consensus, SocketType::UNIX).unwrap();
    let config = kms_config.providers.p11hsm[0].clone();
    let mut ctx = make_sdk_context_without_slot(&config).unwrap();
    let config = config.hsms[0].clone();
    let r = make_pkcs11_sdk(&mut ctx, &config);

    assert!(r.is_ok());
}
#[test]
#[serial]
fn it_get_sdk_account_tcp() {
    let kms_config =
        generate_kms_config_via_temp_config(&KeyType::Account, SocketType::TCP).unwrap();
    let config = kms_config.providers.p11hsm[0].clone();
    let mut ctx = make_sdk_context_without_slot(&config).unwrap();

    get_sdk(&config, &mut ctx, None);

    get_sdk(&config, &mut ctx, Some(TOKEN_LABEL));
}

#[test]
#[serial]
fn it_get_sdk_consensus_tcp() {
    let kms_config =
        generate_kms_config_via_temp_config(&KeyType::Consensus, SocketType::TCP).unwrap();
    let config = kms_config.providers.p11hsm[0].clone();
    let mut ctx = make_sdk_context_without_slot(&config).unwrap();

    get_sdk(&config, &mut ctx, None);

    get_sdk(&config, &mut ctx, Some(TOKEN_LABEL));
}

#[test]
#[serial]
fn it_get_sdk_account_unix() {
    let kms_config =
        generate_kms_config_via_temp_config(&KeyType::Account, SocketType::UNIX).unwrap();
    let config = kms_config.providers.p11hsm[0].clone();
    let mut ctx = make_sdk_context_without_slot(&config).unwrap();

    get_sdk(&config, &mut ctx, None);

    get_sdk(&config, &mut ctx, Some(TOKEN_LABEL));
}

#[test]
#[serial]
fn it_get_sdk_consensus_unix() {
    let kms_config =
        generate_kms_config_via_temp_config(&KeyType::Consensus, SocketType::UNIX).unwrap();
    let config = kms_config.providers.p11hsm[0].clone();
    let mut ctx = make_sdk_context_without_slot(&config).unwrap();

    get_sdk(&config, &mut ctx, None);

    get_sdk(&config, &mut ctx, Some(TOKEN_LABEL));
}

#[test]
#[serial]
fn it_provider_init_account_tcp() {
    // account, tcp
    let result =
        generate_initialized_p11hsm_provider_via_temp_config(&KeyType::Account, SocketType::TCP);
    assert!(result.is_ok());
}
#[test]
#[serial]
fn it_provider_init_consensus_tcp() {
    // consensus, tcp
    let result =
        generate_initialized_p11hsm_provider_via_temp_config(&KeyType::Consensus, SocketType::TCP);
    assert!(result.is_ok());
}
#[test]
#[serial]
fn it_provider_init_account_unix() {
    // account, unix
    let result =
        generate_initialized_p11hsm_provider_via_temp_config(&KeyType::Account, SocketType::UNIX);
    assert!(result.is_ok());
}

#[test]
#[serial]
fn it_provider_init_consensus_unix() {
    // consensus, unix
    let result =
        generate_initialized_p11hsm_provider_via_temp_config(&KeyType::Consensus, SocketType::UNIX);
    assert!(result.is_ok());
}

#[test]
#[serial]
fn it_p11signer_sign_ed25519() {
    let kms_config =
        generate_kms_config_via_temp_config(&KeyType::Consensus, SocketType::TCP).unwrap();
    let config = kms_config.providers.p11hsm[0].clone();
    let mut ctx = make_sdk_context_without_slot(&config).unwrap();

    let sdk = get_sdk(&config, &mut ctx, None);

    let p11signer = P11Signer::new(
        Arc::new(Mutex::new(sdk)),
        test_kl(&KeyType::Consensus).clone(),
    )
    .unwrap();

    let _sig: ed25519::Signature = p11signer.0.try_sign(b"hello world").unwrap();
}

#[test]
#[serial]
fn it_p11signer_sign_ecdsa() {
    let kms_config =
        generate_kms_config_via_temp_config(&KeyType::Account, SocketType::TCP).unwrap();
    let config = kms_config.providers.p11hsm[0].clone();
    let mut ctx = make_sdk_context_without_slot(&config).unwrap();

    let sdk = get_sdk(&config, &mut ctx, None);

    let p11signer = P11Signer::new(
        Arc::new(Mutex::new(sdk)),
        test_kl(&KeyType::Account).clone(),
    )
    .unwrap();

    let _sig: ecdsa::Signature = p11signer.0.try_sign(b"hello world").unwrap();
}
