//! Information about particular validators in a Tendermint network

use std::path::PathBuf;
use std::sync::Mutex;

pub use tendermint::chain::Id as ChainId;
use tendermint_config::net;

use crate::{
    config::{KmsConfig, ValidatorConfig},
    error::Error,
    keyring::{self, KeyRing},
    prelude::*,
};

pub use self::{
    guard::Guard,
    registry::{GlobalRegistry, Registry, REGISTRY},
    state::State,
};

mod guard;
mod registry;
pub mod state;

/// For convenience, validator Id has the same type as chain Id
pub type Id = ChainId;

/// Validator information
pub struct Validator {
    /// ID of a particular validator in tmkms
    pub id: Id,

    /// Validator address
    pub addr: net::Address,

    /// Chain ID of the Tendermint network this validator is part of
    pub chain_id: ChainId,

    /// Should extensions for this chain be signed?
    pub sign_extensions: bool,

    /// Signing keyring for this validator
    pub keyring: KeyRing,

    /// State from the last block signed by this validator
    pub state: Mutex<State>,
}

impl Validator {
    /// Attempt to create a `Validator` from the given configuration
    pub fn from_config(config: &ValidatorConfig) -> Result<Validator, Error> {
        let state_file = match &config.state_file {
            Some(path) => path.to_owned(),
            None => PathBuf::from(&format!("{}_priv_validator_state.json", config.id)),
        };

        let mut state = State::load_state(state_file)?;

        if let Some(ref hook) = config.state_hook {
            match state::hook::run(hook) {
                Ok(hook_output) => state.update_from_hook_output(hook_output)?,
                Err(e) => {
                    if hook.fail_closed {
                        return Err(e);
                    } else {
                        // fail open: note the error to the log and proceed anyway
                        error!(
                            "error invoking state hook for validator {}: {}",
                            config.id, e
                        );
                    }
                }
            }
        }

        Ok(Self {
            id: config.id.clone(),
            addr: config.addr.clone(),
            chain_id: config.chain_id.clone(),
            sign_extensions: config.sign_extensions,
            keyring: KeyRing::new(config.key_format.clone()),
            state: Mutex::new(state),
        })
    }
}

/// Initialize the validator registry from the configuration file
pub fn load_config(config: &KmsConfig) -> Result<(), Error> {
    for config in &config.validator {
        REGISTRY.register(Validator::from_config(config)?)?;
    }

    let mut registry = REGISTRY.0.write().unwrap();
    keyring::load_config(&mut registry, &config.providers)
}
