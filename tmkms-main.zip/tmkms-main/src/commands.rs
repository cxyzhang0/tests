//! Subcommands of the `tmkms` command-line application

use std::{env, path::PathBuf};

use abscissa_core::{Command, Configurable, Runnable};
use clap::Parser;

#[cfg(feature = "p11hsm")]
use crate::commands::p11hsm::P11hsmCommand;
use crate::config::{KmsConfig, CONFIG_ENV_VAR, CONFIG_FILE_NAME};

#[cfg(feature = "ledger")]
pub use self::ledger::LedgerCommand;
#[cfg(feature = "softsign")]
pub use self::softsign::SoftsignCommand;
#[cfg(feature = "yubihsm")]
pub use self::yubihsm::YubihsmCommand;
pub use self::{init::InitCommand, start::StartCommand, version::VersionCommand};

pub mod init;
#[cfg(feature = "ledger")]
pub mod ledger;
mod p11hsm;
#[cfg(feature = "softsign")]
pub mod softsign;
pub mod start;
pub mod version;
#[cfg(feature = "yubihsm")]
pub mod yubihsm;

/// Subcommands of the KMS command-line application
#[derive(Command, Debug, Parser, Runnable)]
pub enum KmsCommand {
    /// initialize KMS configuration
    Init(InitCommand),

    /// subcommands for Ledger
    #[cfg(feature = "ledger")]
    #[clap(subcommand)]
    Ledger(LedgerCommand),

    /// subcommands for software signer
    #[cfg(feature = "softsign")]
    #[clap(subcommand)]
    Softsign(SoftsignCommand),

    /// start the KMS application"
    Start(StartCommand),

    /// display the version
    Version(VersionCommand),

    /// subcommands for YubiHSM2
    #[cfg(feature = "yubihsm")]
    #[clap(subcommand)]
    Yubihsm(YubihsmCommand),

    /// subcommands for PKCS11 HSMs
    #[cfg(feature = "p11hsm")]
    #[clap(subcommand)]
    P11hsm(P11hsmCommand),
}

impl KmsCommand {
    /// Are we configured for verbose logging?
    pub fn verbose(&self) -> bool {
        match self {
            KmsCommand::Start(run) => run.verbose,
            #[cfg(feature = "yubihsm")]
            KmsCommand::Yubihsm(yubihsm) => yubihsm.verbose(),
            _ => false,
        }
    }
    /// Are we configured for json logging format?
    pub fn json(&self) -> bool {
        match self {
            KmsCommand::Start(run) => run.json,
            _ => false,
        }
    }
}

impl Configurable<KmsConfig> for KmsCommand {
    /// Get the path to the configuration file, either from selected subcommand
    /// or the default
    fn config_path(&self) -> Option<PathBuf> {
        let config = match self {
            KmsCommand::Start(start) => start.config.as_ref(),
            #[cfg(feature = "yubihsm")]
            KmsCommand::Yubihsm(yubihsm) => yubihsm.config_path(),
            #[cfg(feature = "ledger")]
            KmsCommand::Ledger(ledger) => ledger.config_path(),
            #[cfg(feature = "p11hsm")]
            KmsCommand::P11hsm(p11hsm) => p11hsm.config_path(),
            _ => return None,
        };

        let path = config
            .cloned()
            .or_else(|| env::var(CONFIG_ENV_VAR).ok().map(PathBuf::from))
            .unwrap_or_else(|| PathBuf::from(CONFIG_FILE_NAME));

        Some(path)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use serial_test::serial;
    use std::env;

    #[test]
    fn config_path_start_command() {
        let start_command = KmsCommand::Start(StartCommand {
            config: Some(PathBuf::from("custom_config.toml")),
            verbose: false,
            json: false,
        });
        assert_eq!(
            start_command.config_path(),
            Some(PathBuf::from("custom_config.toml"))
        );
    }

    #[test]
    #[serial]
    // use serial so the env var is not conflicting with that set in config_path_default
    fn config_path_env_var() {
        env::set_var(CONFIG_ENV_VAR, "env_config.toml");
        let start_command = KmsCommand::Start(StartCommand {
            config: None,
            verbose: false,
            json: false,
        });
        assert_eq!(
            start_command.config_path(),
            Some(PathBuf::from("env_config.toml"))
        );
        env::remove_var(CONFIG_ENV_VAR);
    }

    #[test]
    #[serial]
    // use serial so the env var is not conflicting with that set in config_path_env_var
    fn config_path_default() {
        env::set_var(CONFIG_ENV_VAR, CONFIG_FILE_NAME);
        let start_command = KmsCommand::Start(StartCommand {
            config: None,
            verbose: false,
            json: false,
        });
        assert_eq!(
            start_command.config_path(),
            Some(PathBuf::from(CONFIG_FILE_NAME))
        );
    }

    #[test]
    fn verbose_start_command() {
        let start_command = KmsCommand::Start(StartCommand {
            config: None,
            verbose: true,
            json: false,
        });
        assert!(start_command.verbose());
    }

    #[cfg(feature = "yubihsm")]
    #[test]
    fn verbose_yubihsm_command() {
        let yubihsm_command = KmsCommand::Yubihsm(YubihsmCommand::Detect(yubihsm::DetectCommand {
            config: None,
            verbose: true,
        }));
        assert!(yubihsm_command.verbose());
    }

    #[cfg(feature = "ledger")]
    #[test]
    fn config_path_ledger_command() {
        let ledger_command = KmsCommand::Ledger(LedgerCommand::Init(ledger::InitCommand {
            config: None,
            height: None,
            round: None,
        }));
        assert_eq!(
            ledger_command.config_path(),
            Some(PathBuf::from("ledger_config.toml"))
        );
    }
}
