//! Cryptographic service providers: signing backends

use std::fmt;

use serde::Deserialize;

#[cfg(feature = "fortanixdsm")]
use self::fortanixdsm::FortanixDsmConfig;
#[cfg(feature = "ledger")]
use self::ledgertm::LedgerTendermintConfig;
#[cfg(feature = "p11hsm")]
use self::p11hsm::P11hsmConfig;
#[cfg(feature = "softsign")]
use self::softsign::SoftsignConfig;
#[cfg(feature = "yubihsm")]
use self::yubihsm::YubihsmConfig;

#[cfg(feature = "fortanixdsm")]
pub mod fortanixdsm;
#[cfg(feature = "ledger")]
pub mod ledgertm;
#[cfg(feature = "p11hsm")]
pub mod p11hsm;
#[cfg(feature = "softsign")]
pub mod softsign;
#[cfg(feature = "yubihsm")]
pub mod yubihsm;

/// Provider configuration
#[derive(Default, Deserialize, Debug)]
#[serde(deny_unknown_fields)]
pub struct ProviderConfig {
    /// Software-backed signer
    #[cfg(feature = "softsign")]
    #[serde(default)]
    pub softsign: Vec<SoftsignConfig>,

    /// Map of yubihsm-connector labels to their configurations
    #[cfg(feature = "yubihsm")]
    #[serde(default)]
    pub yubihsm: Vec<YubihsmConfig>,

    /// Map of ledger-tm labels to their configurations
    #[cfg(feature = "ledger")]
    #[serde(default)]
    pub ledgertm: Vec<LedgerTendermintConfig>,

    /// Fortanix DSM provider configurations
    #[cfg(feature = "fortanixdsm")]
    #[serde(default)]
    pub fortanixdsm: Vec<FortanixDsmConfig>,

    /// P11Hsm provider configs
    #[cfg(feature = "p11hsm")]
    #[serde(default)]
    pub p11hsm: Vec<P11hsmConfig>,
}

/// Types of cryptographic keys
// TODO(tarcieri): move this into a provider-agnostic module
#[derive(Clone, Debug, Deserialize)]
pub enum KeyType {
    /// Account keys
    #[serde(rename = "account")]
    Account,

    /// Consensus keys
    #[serde(rename = "consensus")]
    Consensus,
}

impl Default for KeyType {
    /// Backwards compat for existing configuration files
    fn default() -> Self {
        KeyType::Consensus
    }
}

impl fmt::Display for KeyType {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            KeyType::Account => f.write_str("account"),
            KeyType::Consensus => f.write_str("consensus"),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json;

    fn _create_test_provider_config() -> ProviderConfig {
        ProviderConfig {
            #[cfg(feature = "softsign")]
            softsign: vec![],
            #[cfg(feature = "yubihsm")]
            yubihsm: vec![],
            #[cfg(feature = "ledger")]
            ledgertm: vec![],
            #[cfg(feature = "fortanixdsm")]
            fortanixdsm: vec![],
            #[cfg(feature = "p11hsm")]
            p11hsm: vec![],
        }
    }

    #[test]
    fn default_provider_config_is_empty() {
        let config = ProviderConfig::default();
        #[cfg(feature = "softsign")]
        assert!(config.softsign.is_empty());
        #[cfg(feature = "yubihsm")]
        assert!(config.yubihsm.is_empty());
        #[cfg(feature = "ledger")]
        assert!(config.ledgertm.is_empty());
        #[cfg(feature = "fortanixdsm")]
        assert!(config.fortanixdsm.is_empty());
        #[cfg(feature = "p11hsm")]
        assert!(config.p11hsm.is_empty());
    }

    #[test]
    fn deserialize_provider_config_successfully() {
        let json = r#"
        {
            "p11hsm": []
        }
        "#;
        /*
        let json = r#"
        {
            "softsign": [],
            "yubihsm": [],
            "ledgertm": [],
            "fortanixdsm": [],
            "p11hsm": []
        }
        "#;
        */
        let config: ProviderConfig = serde_json::from_str(json).unwrap();
        #[cfg(feature = "softsign")]
        assert!(config.softsign.is_empty());
        #[cfg(feature = "yubihsm")]
        assert!(config.yubihsm.is_empty());
        #[cfg(feature = "ledger")]
        assert!(config.ledgertm.is_empty());
        #[cfg(feature = "fortanixdsm")]
        assert!(config.fortanixdsm.is_empty());
        #[cfg(feature = "p11hsm")]
        assert!(config.p11hsm.is_empty());
    }

    #[test]
    fn key_type_default_is_consensus() {
        let key_type = KeyType::default();
        assert!(matches!(key_type, KeyType::Consensus))
        // assert!(matches!(e, Error::GenericError(msg) if msg == String::from("Invalid label")));
    }

    #[test]
    fn key_type_display_formats_correctly() {
        assert_eq!(KeyType::Account.to_string(), "account");
        assert_eq!(KeyType::Consensus.to_string(), "consensus");
    }
    /*
        #[test]
        fn deserialize_key_type_successfully() {
            let json = r#""account""#;
            let key_type: KeyType = serde_json::from_str(json).unwrap();
            assert_eq!(key_type, KeyType::Account);

            let json = r#""consensus""#;
            let key_type: KeyType = serde_json::from_str(json).unwrap();
            assert_eq!(key_type, KeyType::Consensus);
        }
    */
    #[test]
    #[should_panic(expected = "unknown variant")]
    fn deserialize_invalid_key_type_fails() {
        let json = r#""invalid""#;
        let _: KeyType = serde_json::from_str(json).unwrap();
    }
}
