//! Configuration for PKCS11 HSM backend

use serde::Deserialize;

use crate::validator;

use super::KeyType;

/// PKCS11 HSM configuration
#[derive(Clone, Deserialize, Debug)]
#[serde(deny_unknown_fields)]
pub struct P11hsmConfig {
    /// unidue identifier for the p11hsm provider
    pub id: String,

    /// evn var name for pkcs11 library file path
    /// so that the module file path can be retrieved from env var
    /// e.g., for FX, it is "FXPKCS11_MODULE"
    pub env_module: Option<String>,

    /// pkcs11 library binary file path
    pub module: Option<String>,

    /// pkcs11 config env var name
    /// e.g., for FX, it is "FXPKCS11_CFG"
    pub env_cfg: String,

    /// pkcs11 config file path
    pub cfg: String,

    /// pkcs11 token label to identify the slot
    /// e.g., for FX, it may be "us01crypto01test.virtucrypt.com:"
    /// e.g., for SoftHSM, it may be "Slot Token 0"
    // pub token_label: String,

    /// pkcs11 user pin
    // pub user_pin: String,

    /// list of signing keys
    #[serde(default)]
    pub hsms: Vec<HsmConfig>,
}

/// hsms
#[derive(Clone, Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct HsmConfig {
    /// pkcs11 token label to identify the slot
    /// e.g., for FX, it may be "us01crypto01test.virtucrypt.com:"
    /// e.g., for SoftHSM, it may be "Slot Token 0"
    pub token_label: String,

    /// pkcs11 user pin
    pub user_pin: String,

    /// list of signing keys
    #[serde(default)]
    pub signing_keys: Vec<SigningKeyConfig>,
}

/// PKCS11 HSM signing key sub configuration
#[derive(Clone, Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct SigningKeyConfig {
    /// Validators this signing key is authorized to be used for
    pub val_ids: Vec<validator::Id>,

    /// Type of key (account vs consensus, default consensus)
    #[serde(default)]
    pub key_type: KeyType,

    /// key label in the form of "prefix/keyring/key/ver"
    /// e.g., "Slot Token 0/WIM-test/id-ed25519-hsm-1/2"
    pub key_label: String,
}
