//! Validator configuration
use std::path::PathBuf;

use serde::{Deserialize, Serialize};
use tendermint::chain;
use tendermint_config::net;
use tendermint_p2p::secret_connection;

use crate::{keyring, validator};

pub use self::hook::HookConfig;

mod hook;

/// Validator configuration
// #[derive(Debug, Deserialize)]
#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ValidatorConfig {
    /// ID of a particular validator in tmkms
    pub id: validator::Id,

    /// Address of the validator (`tcp://` or `unix://`)
    pub addr: net::Address,

    /// Chain ID of the Tendermint network this validator is part of
    pub chain_id: chain::Id,

    /// Automatically reconnect on error? (default: true)
    #[serde(default = "reconnect_default")]
    pub reconnect: bool,

    /// Optional timeout value in seconds
    pub timeout: Option<u16>,

    /// Path to our Ed25519 identity key (if applicable)
    pub secret_key: Option<PathBuf>,

    /// Key serialization format configuration for this chain
    pub key_format: keyring::Format,

    /// Should vote extensions on this chain be signed? (default: false)
    ///
    /// CometBFT v0.38 and newer supports an `ExtendedCommitSig` which requires computing an
    /// additional signature over an extension using the consensus key beyond simply signing a vote.
    ///
    /// Note: in the future this can be autodetected via the `signExtension` field on `SignVote`.
    /// See cometbft/cometbft#2439.
    #[serde(default)]
    pub sign_extensions: bool,

    /// Path to chain-specific `priv_validator_state.json` file
    pub state_file: Option<PathBuf>,

    /// Height at which to stop signing
    pub max_height: Option<tendermint::block::Height>,

    /// Version of Secret Connection protocol to use when connecting
    pub protocol_version: ProtocolVersion,

    /// User-specified command to run to obtain the current block height for
    /// this chain. This will be executed at launch time to populate the
    /// initial block height if configured
    pub state_hook: Option<HookConfig>,
}

/// Protocol version (based on the Tendermint version)
#[derive(Copy, Clone, Debug, Eq, PartialEq, PartialOrd, Ord, Serialize, Deserialize)]
#[allow(non_camel_case_types)]
pub enum ProtocolVersion {
    /// Tendermint v0.34 and newer.
    #[serde(rename = "v0.34")]
    V0_34,

    /// Tendermint v0.33
    #[serde(rename = "v0.33")]
    V0_33,
}

impl From<ProtocolVersion> for secret_connection::Version {
    fn from(version: ProtocolVersion) -> secret_connection::Version {
        match version {
            ProtocolVersion::V0_34 => secret_connection::Version::V0_34,
            ProtocolVersion::V0_33 => secret_connection::Version::V0_33,
        }
    }
}

/// Default value for the `ValidatorConfig` reconnect field
fn reconnect_default() -> bool {
    true
}
