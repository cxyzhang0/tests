//! Validator configuration
use std::path::PathBuf;

use serde::{Deserialize, Serialize};
use tendermint::chain;
use tendermint_config::net;
use tendermint_p2p::secret_connection;

use crate::{keyring, validator};

pub use self::hook::HookConfig;

mod hook;

/// Validator configuration
// #[derive(Debug, Deserialize)]
#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ValidatorConfig {
    /// ID of a particular validator in tmkms
    pub id: validator::Id,

    /// Address of the validator (`tcp://` or `unix://`)
    pub addr: net::Address,

    /// Chain ID of the Tendermint network this validator is part of
    pub chain_id: chain::Id,

    /// Automatically reconnect on error? (default: true)
    #[serde(default = "reconnect_default")]
    pub reconnect: bool,

    /// Optional timeout value in seconds
    pub timeout: Option<u16>,

    /// Path to our Ed25519 identity key (if applicable)
    pub secret_key: Option<PathBuf>,

    /// Key serialization format configuration for this chain
    pub key_format: keyring::Format,

    /// Should vote extensions on this chain be signed? (default: false)
    ///
    /// CometBFT v0.38 and newer supports an `ExtendedCommitSig` which requires computing an
    /// additional signature over an extension using the consensus key beyond simply signing a vote.
    ///
    /// Note: in the future this can be autodetected via the `signExtension` field on `SignVote`.
    /// See cometbft/cometbft#2439.
    #[serde(default)]
    pub sign_extensions: bool,

    /// Path to chain-specific `priv_validator_state.json` file
    pub state_file: Option<PathBuf>,

    /// Height at which to stop signing
    pub max_height: Option<tendermint::block::Height>,

    /// Version of Secret Connection protocol to use when connecting
    pub protocol_version: ProtocolVersion,

    /// User-specified command to run to obtain the current block height for
    /// this chain. This will be executed at launch time to populate the
    /// initial block height if configured
    pub state_hook: Option<HookConfig>,
}

/// Protocol version (based on the Tendermint version)
#[derive(Copy, Clone, Debug, Eq, PartialEq, PartialOrd, Ord, Serialize, Deserialize)]
#[allow(non_camel_case_types)]
pub enum ProtocolVersion {
    /// Tendermint v0.34 and newer.
    #[serde(rename = "v0.34")]
    V0_34,

    /// Tendermint v0.33
    #[serde(rename = "v0.33")]
    V0_33,
}

impl From<ProtocolVersion> for secret_connection::Version {
    fn from(version: ProtocolVersion) -> secret_connection::Version {
        match version {
            ProtocolVersion::V0_34 => secret_connection::Version::V0_34,
            ProtocolVersion::V0_33 => secret_connection::Version::V0_33,
        }
    }
}

/// Default value for the `ValidatorConfig` reconnect field
fn reconnect_default() -> bool {
    true
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::PathBuf;
    use tendermint::chain;
    use tendermint_config::net;

    fn create_test_validator_config() -> ValidatorConfig {
        ValidatorConfig {
            id: validator::Id::try_from("test_validator").unwrap(),
            addr: net::Address::Tcp {
                peer_id: None,
                host: "127.0.0.1".to_string(),
                port: 26656,
            },
            chain_id: chain::Id::try_from("test_chain").unwrap(),
            reconnect: true,
            timeout: Some(30),
            secret_key: Some(PathBuf::from("/path/to/secret_key")),
            key_format: keyring::Format::Bech32 {
                account_key_prefix: "wf".to_string(),
                consensus_key_prefix: "wf".to_string(),
            },
            sign_extensions: false,
            state_file: Some(PathBuf::from("/path/to/state_file")),
            max_height: Some(tendermint::block::Height::try_from(100u64).unwrap()),
            protocol_version: ProtocolVersion::V0_34,
            state_hook: None,
        }
    }

    #[test]
    fn default_reconnect_is_true() {
        assert!(reconnect_default());
    }

    #[test]
    fn validator_config_default_reconnect_is_true() {
        let config = ValidatorConfig {
            reconnect: reconnect_default(),
            ..create_test_validator_config()
        };
        assert!(config.reconnect);
    }

    #[test]
    fn validator_config_serializes_and_deserializes_correctly() {
        let config = create_test_validator_config();
        let serialized = serde_json::to_string(&config).unwrap();
        let deserialized: ValidatorConfig = serde_json::from_str(&serialized).unwrap();
        assert_eq!(config.addr, deserialized.addr);
    }

    #[test]
    fn protocol_version_from_v0_34() {
        let version: secret_connection::Version = ProtocolVersion::V0_34.into();
        assert_eq!(version, secret_connection::Version::V0_34);
    }

    #[test]
    fn protocol_version_from_v0_33() {
        let version: secret_connection::Version = ProtocolVersion::V0_33.into();
        assert_eq!(version, secret_connection::Version::V0_33);
    }

    #[test]
    fn validator_config_with_optional_fields_none() {
        let config = ValidatorConfig {
            timeout: None,
            secret_key: None,
            state_file: None,
            max_height: None,
            state_hook: None,
            ..create_test_validator_config()
        };
        assert!(config.timeout.is_none());
        assert!(config.secret_key.is_none());
        assert!(config.state_file.is_none());
        assert!(config.max_height.is_none());
        assert!(config.state_hook.is_none());
    }
}
