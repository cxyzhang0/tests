//! p11hsm utility

use std::env;
use std::sync::Once;

use abscissa_core::{format_err, status_err};
use pkcs11::{SDKContext, SDK};

use crate::config::provider::p11hsm::{HsmConfig, P11hsmConfig};
use crate::error::Error;
use crate::error::ErrorKind::P11hsmError;
use crate::prelude::info;

/// One-time function call
pub(crate) static INIT: Once = Once::new();

/// Perform one-time environment variable setup
// TODO: why we are able to set env vars for both fx and softhsm? Is it because they are different?
pub(crate) fn set_env_vars(config: &P11hsmConfig) {
    INIT.call_once(|| {
        env::set_var(&config.env_cfg, &config.cfg);
    });
    info!("env var set - {}={}", &config.env_cfg, &config.cfg);
}

/// Display environment variables
pub(crate) fn display_env_vars(config: &P11hsmConfig) {
    info!("env_cfg: {}; cfg: {}", config.env_cfg, config.cfg);
    info!(
        "evn_module: {:?}; module: {:?}",
        config.env_module, config.module
    );
}

/// Create a new SDLContext without slot
pub(crate) fn make_sdk_context_without_slot(config: &P11hsmConfig) -> Result<SDKContext, Error> {
    set_env_vars(config);

    let p11 = SDKContext::create_pkcs11(config.env_module.as_deref(), config.module.as_deref())
        .map_err(|e| format_err!(P11hsmError, "pkcs11 creation error: {}", e))?;

    info!(
        "new pkcs11 created - env_module: {:?}; module = {:?}",
        &config.env_module, &config.module,
    );
    info!("pkcs11 library: {:?})", p11.get_library_info().unwrap(),);

    Ok(SDKContext::new(p11))
}

/// Create a new pkcs11 sdk with login
/// ctx: &mut SDKContext without slot
pub(crate) fn make_pkcs11_sdk(ctx: &mut SDKContext, hsm: &HsmConfig) -> Result<SDK, Error> {
    info!("set context slot: {}", hsm.token_label);
    ctx.set_slot_by_label(&hsm.token_label)
        .map_err(|e| format_err!(P11hsmError, "sdk context set_slot_by_label error: {}", e))?;

    info!("create sdk from context without login");
    let mut sdk = SDK::from_context(&ctx).unwrap_or_else(|e| {
        status_err!("couldn't make sdk from context (prior to login): {}", e);
        std::process::exit(1);
    });

    info!("logging in: {}", hsm.token_label);
    sdk.login(&hsm.user_pin).map_err(|e| format_err!(P11hsmError, "sdk login error: {}", e))?;
    
    info!("sdk session: {}", sdk.session(),);

    Ok(sdk)
}

/// Wrapper make_pkcs11_sdk for convenient handling of optional token_label.
pub(crate) fn get_sdk(config: &P11hsmConfig, ctx: &mut SDKContext, token_label: &Option<String>) -> SDK {
    /*
    if config.hsms.is_empty() {
        status_err!("no hsms found for provider: {}", &config.id);
        std::process::exit(1);
    }

    let hsm_id = if token_label.is_none() || config.hsms.len() == 1 {
        0
    } else {
        config
            .hsms
            .iter()
            .position(|hsm| hsm.token_label == token_label.as_deref().unwrap())
            .unwrap_or_else(|| {
                status_err!(
                    "couldn't find hsm with token_label: {} for provider {}",
                    token_label.as_deref().unwrap(),
                    &config.id
                );
                std::process::exit(1);
            })
    };
    */
    let hsm_id = get_hsm_id(config, token_label);
    
    info!("token_label: {}", config.hsms[hsm_id].token_label);

    make_pkcs11_sdk(ctx, &config.hsms[hsm_id]).unwrap_or_else(|e| {
        status_err!("couldn't make pkcs11 sdk: {}", e);
        std::process::exit(1);
    })
}

/// get index of hsm matching token_label.
pub(crate) fn get_hsm_id(config: &P11hsmConfig, token_label: &Option<String>) -> usize {
    if config.hsms.is_empty() {
        status_err!("no hsm found for provider: {}", &config.id);
        std::process::exit(1);
    }

    let hsm_id = if token_label.is_none() /*|| config.hsms.len() == 1*/ {
        0
    } else {
        config
            .hsms
            .iter()
            .position(|hsm| hsm.token_label == token_label.as_deref().unwrap())
            .unwrap_or_else(|| {
                status_err!(
                    "couldn't find hsm with token_label: {} for provider {}",
                    token_label.as_deref().unwrap(),
                    &config.id
                );
                std::process::exit(1);
            })
    };

    hsm_id
}

/*
pub(crate) fn make_pkcs11_sdk(config: &P11hsmConfig) -> Result<Arc<SDK>, Error> {
    set_env_vars(config);

    let sdk = SDK::new(
        config.env_module.as_deref(),
        config.module.as_deref(),
        &config.token_label,
        &config.user_pin,
    )
        .map_err(|e| format_err!(P11hsmError, "SDK creation error: {}", e))?;
    info!(
        "p11hsm - new sdk created env_module: {:?}; module = {:?}; token_label: {}",
        &config.env_module, &config.module, &config.token_label
    );
    Ok(Arc::new(sdk))
}
*/
