//! PKCS11 HSM-backed signer objects
use std::sync::{Arc, Mutex};

use abscissa_core::prelude::*;
use k256::{ecdsa::Signature as EcdsaSignature, Secp256k1};
use pkcs11::{CryptographAlgorithm, KeyLabel, SDK};
use signature::{Error as SignError, Signer};
use tendermint::{PublicKey, TendermintKey};

use crate::p11hsm::make_sdk_context_without_slot;
use crate::{
    config::provider::{
        p11hsm::{P11hsmConfig, SigningKeyConfig},
        KeyType,
    },
    error::{Error, ErrorKind::P11hsmError},
    keyring::{self, ed25519, SigningProvider},
    validator::Registry,
};

/// Populate keyring for each validator in registry.
/// Specifically, create PKCS11 HSM-backed signer objects from the given configuration.
pub fn init(registry: &mut Registry, configs: &[P11hsmConfig]) -> Result<(), Error> {
    if configs.is_empty() {
        return Ok(());
    }

    for config in configs {
        let mut ctx = make_sdk_context_without_slot(config)?;

        for hsm in &config.hsms {
            ctx.set_slot_by_label(&hsm.token_label)
                .map_err(|e| format_err!(P11hsmError, "Failed to set slot by label: {}", e))?;
            
            let mut sdk = SDK::from_context(&ctx)
                .map_err(|e| format_err!(P11hsmError, "Failed to create PKCS11 SDK: {}", e))?;

            sdk.login(&hsm.user_pin).map_err(|e| format_err!(P11hsmError, "Failed to login: {}", e))?;
            
            let sdk = Arc::new(Mutex::new(sdk));
            
            for key_config in &hsm.signing_keys {
                add_key(registry, key_config, sdk.clone())?;
            }
        }
    }

    Ok(())
}

fn add_key(
    registry: &mut Registry,
    config: &SigningKeyConfig,
    sdk: Arc<Mutex<SDK>>,
) -> Result<(), Error> {
    let algo = match config.key_type {
        KeyType::Account => CryptographAlgorithm::Secp256k1,
        KeyType::Consensus => CryptographAlgorithm::Ed25519,
    };
    let key_label = KeyLabel::from_short(&config.key_label, algo)
        .map_err(|e| format_err!(P11hsmError, "Invalid key label: {}", e))?;
    let (signer, tmkey) = P11Signer::new(sdk, key_label)
        .map_err(|e| format_err!(P11hsmError, "Failed to create signer: {}", e))?;

    match config.key_type {
        KeyType::Account => {
            let signer =
                keyring::ecdsa::Signer::new(SigningProvider::P11hsm, tmkey, Box::new(signer));
            for val_id in &config.val_ids {
                registry.add_account_key(val_id, signer.clone())?;
            }
        }
        KeyType::Consensus => {
            let signer = ed25519::Signer::new(SigningProvider::P11hsm, tmkey, Box::new(signer));
            for val_id in &config.val_ids {
                registry.add_consensus_key(val_id, signer.clone())?;
            }
        }
    }

    Ok(())
}

/// PKCS11 HSM-backed signer objects
#[derive(Debug)]
pub struct P11Signer {
    sdk: Arc<Mutex<SDK>>,
    key_label: KeyLabel,
}

impl P11Signer {
    /// Create a new PKCS11 HSM-backed signer object.
    /// The returned TendermintKey indicates the type of key (account or consensus) and the public key.
    /// The key type is determined by the key_label.algorithm which is set to Secp256k1 for account keys and Ed25519 for consensus keys.
    /// Caller ensures algorithm is either Secp256k1 or Ed25519.
    pub fn new(sdk: Arc<Mutex<SDK>>, key_label: KeyLabel) -> Result<(Self, TendermintKey), Error> {
        let tm_key = if key_label.algorithm == CryptographAlgorithm::Secp256k1 {
            let sdk = sdk.lock().unwrap();
            let vk = sdk
                .get_k256_public_key(&key_label)
                .map_err(|e| format_err!(P11hsmError, "Failed to get public key: {}", e))?;
            TendermintKey::AccountKey(PublicKey::from(vk))
        } else {
            let sdk = sdk.lock().unwrap();
            // CryptographAlgorithm::Ed25519
            let vk = sdk
                .get_ed_public_key(&key_label)
                .map_err(|e| format_err!(P11hsmError, "Failed to get public key: {}", e))?;
            let pk = PublicKey::from_raw_ed25519(&vk.to_bytes()).ok_or(
                format_err!(P11hsmError, "Failed to get public key")
            )?;
            // let pk = PublicKey::from_raw_ed25519(&vk.to_bytes()).map_or(
            //     Err(format_err!(P11hsmError, "Failed to get public key")),
            //     Ok,
            // )?;
            TendermintKey::ConsensusKey(pk)
        };

        Ok((Self { sdk, key_label }, tm_key))
    }
}

impl Signer<EcdsaSignature> for P11Signer {
    fn try_sign(&self, msg: &[u8]) -> Result<EcdsaSignature, SignError> {
        self.sdk
            .lock()
            .unwrap()
            .sign_ecdsa::<Secp256k1>(&self.key_label, msg)
            .map_err(|_| SignError::new())
    }
}

impl Signer<ed25519::Signature> for P11Signer {
    // TODO: Is it necessary to handle disconnection errors? Retry sign or restart a new session?
    //  Is CKR_DEVICE_ERROR the only error to track? How about CKR_GENERAL_ERROR?
    //  NOTE: Preliminary test simulating temp connection loss and resumption shows tmkms can auto-recovery.
    /*
        fn try_sign(&self, msg: &[u8]) -> Result<ed25519::Signature, SignError> {
            loop {
                match self.sdk.sign_eddsa(&self.key_label, msg) {
                    Ok(sig) => return Ok(sig),
                    Err(e) => {
                        // if lost connection to HSM, we cannot get session info
                        let session_info = self.sdk.session.get_session_info();
                        warn!("p11hsm - Failed to sign: {}", e);
                        if e.to_string().contains("CKR_DEVICE_ERROR") {
                            // pause for a while and retry
                            let sleep = time::Duration::from_secs(1);
                            thread::sleep(sleep);
                            continue;
                        } else {
                            return Err(SignError::new());
                        }
                    }
                }
            }
            self.sdk
                .sign_eddsa(&self.key_label, msg)
                .map_err(|_| SignError::new())
        }
    */

    fn try_sign(&self, msg: &[u8]) -> Result<ed25519::Signature, SignError> {
        self.sdk
            .lock()
            .unwrap()
            .sign_eddsa(&self.key_label, msg)
            .map_err(|_| SignError::new())
    }
}
