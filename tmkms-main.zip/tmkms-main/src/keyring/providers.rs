//! Signature providers (i.e. backends/plugins)

use std::fmt::{self, Display};

#[cfg(feature = "ledger")]
pub mod ledgertm;

#[cfg(feature = "softsign")]
pub mod softsign;

#[cfg(feature = "yubihsm")]
pub mod yubihsm;

#[cfg(feature = "fortanixdsm")]
pub mod fortanixdsm;

#[cfg(feature = "p11hsm")]
pub mod p11hsm;

/// Enumeration of signing key providers
#[derive(Copy, Clone, Debug, Eq, Hash, PartialEq)]
pub enum SigningProvider {
    /// YubiHSM provider
    #[cfg(feature = "yubihsm")]
    Yubihsm,

    /// Ledger + Tendermint application
    #[cfg(feature = "ledger")]
    LedgerTm,

    /// Software signer (not intended for production use)
    #[cfg(feature = "softsign")]
    SoftSign,

    /// Fortanix DSM signer
    #[cfg(feature = "fortanixdsm")]
    FortanixDsm,

    /// PKCS11 HSM signer
    #[cfg(feature = "p11hsm")]
    P11hsm,
}

impl Display for SigningProvider {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            #[cfg(feature = "yubihsm")]
            SigningProvider::Yubihsm => write!(f, "yubihsm"),

            #[cfg(feature = "ledger")]
            SigningProvider::LedgerTm => write!(f, "ledgertm"),

            #[cfg(feature = "softsign")]
            SigningProvider::SoftSign => write!(f, "softsign"),

            #[cfg(feature = "fortanixdsm")]
            SigningProvider::FortanixDsm => write!(f, "fortanixdsm"),

            #[cfg(feature = "p11hsm")]
            SigningProvider::P11hsm => write!(f, "p11hsm"),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn display_yubihsm() {
        #[cfg(feature = "yubihsm")]
        {
            let provider = SigningProvider::Yubihsm;
            assert_eq!(provider.to_string(), "yubihsm");
        }
    }

    #[test]
    fn display_ledgertm() {
        #[cfg(feature = "ledger")]
        {
            let provider = SigningProvider::LedgerTm;
            assert_eq!(provider.to_string(), "ledgertm");
        }
    }

    #[test]
    fn display_softsign() {
        #[cfg(feature = "softsign")]
        {
            let provider = SigningProvider::SoftSign;
            assert_eq!(provider.to_string(), "softsign");
        }
    }

    #[test]
    fn display_fortanixdsm() {
        #[cfg(feature = "fortanixdsm")]
        {
            let provider = SigningProvider::FortanixDsm;
            assert_eq!(provider.to_string(), "fortanixdsm");
        }
    }

    #[test]
    fn display_p11hsm() {
        #[cfg(feature = "p11hsm")]
        {
            let provider = SigningProvider::P11hsm;
            assert_eq!(provider.to_string(), "p11hsm");
        }
    }
}
