use signature::Signer;

use crate::error::{Error, ErrorKind};

use super::{Signature, VerifyingKey};

/// Signing key serialized as bytes.
type SigningKeyBytes = [u8; SigningKey::BYTE_SIZE];

/// Ed25519 signing key.
#[derive(Clone, Debug)]
pub struct SigningKey(ed25519_consensus::SigningKey);

impl SigningKey {
    /// Size of an encoded Ed25519 signing key in bytes.
    pub const BYTE_SIZE: usize = 32;

    /// Borrow the serialized signing key as bytes.
    pub fn as_bytes(&self) -> &SigningKeyBytes {
        self.0.as_bytes()
    }

    /// Get the verifying key for this signing key.
    pub fn verifying_key(&self) -> VerifyingKey {
        VerifyingKey(self.0.verification_key())
    }
}

impl From<SigningKeyBytes> for SigningKey {
    fn from(bytes: SigningKeyBytes) -> Self {
        Self(bytes.into())
    }
}

impl From<SigningKey> for ed25519_consensus::SigningKey {
    fn from(signing_key: SigningKey) -> ed25519_consensus::SigningKey {
        signing_key.0
    }
}

impl From<&SigningKey> for tendermint_p2p::secret_connection::PublicKey {
    fn from(signing_key: &SigningKey) -> tendermint_p2p::secret_connection::PublicKey {
        Self::from(&signing_key.0)
    }
}

impl From<ed25519_consensus::SigningKey> for SigningKey {
    fn from(signing_key: ed25519_consensus::SigningKey) -> SigningKey {
        SigningKey(signing_key)
    }
}

impl From<tendermint::private_key::Ed25519> for SigningKey {
    fn from(signing_key: tendermint::private_key::Ed25519) -> SigningKey {
        signing_key
            .as_bytes()
            .try_into()
            .expect("invalid Ed25519 signing key")
    }
}

impl Signer<Signature> for SigningKey {
    fn try_sign(&self, msg: &[u8]) -> signature::Result<Signature> {
        Ok(self.0.sign(msg).to_bytes().into())
    }
}

impl TryFrom<&[u8]> for SigningKey {
    type Error = Error;

    fn try_from(slice: &[u8]) -> Result<Self, Error> {
        slice
            .try_into()
            .map(Self)
            .map_err(|_| ErrorKind::InvalidKey.into())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    use signature::Verifier;

    use crate::testing::ed25519 as TestingEd25519;

    #[test]
    fn signing_key_as_bytes() {
        let key = TestingEd25519::gen_key();
        let bytes = key.as_bytes();
        assert_eq!(bytes.len(), SigningKey::BYTE_SIZE);
    }

    #[test]
    fn signing_key_to_verifying_key() {
        let key = TestingEd25519::gen_key();
        let verifying_key = key.verifying_key();
        assert_eq!(verifying_key.0.to_bytes().len(), VerifyingKey::BYTE_SIZE);
    }

    #[test]
    fn signing_key_from_bytes() {
        let bytes: SigningKeyBytes = TestingEd25519::gen_random_bytes();
        let signing_key = SigningKey::from(bytes);
        assert_eq!(signing_key.as_bytes(), &bytes);
    }

    #[test]
    fn signing_key_to_tendermint_public_key() {
        let key = TestingEd25519::gen_key();
        let public_key = tendermint_p2p::secret_connection::PublicKey::from(&key);
        match public_key {
            tendermint_p2p::secret_connection::PublicKey::Ed25519(k) => {
                assert_eq!(VerifyingKey(k).0, key.verifying_key().0);
            }
        }
    }

    #[test]
    fn signing_key_from_tendermint_signing_key() {
        let tendermint_key = TestingEd25519::gen_tendermint_private_key();
        let _signing_key = SigningKey::from(tendermint_key);
    }
    #[test]
    fn signing_key_try_sign() {
        let signing_key = TestingEd25519::gen_key();
        let message = b"test message";
        let signature = signing_key.try_sign(message).unwrap();

        let vk = signing_key.verifying_key();

        assert!(vk.verify(message, &signature).is_ok());
    }

    #[test]
    fn signing_key_try_from_invalid_slice() {
        let bytes = [0u8; 31]; // Invalid length
        let result = SigningKey::try_from(bytes.as_slice());
        assert!(result.is_err());
    }
}
