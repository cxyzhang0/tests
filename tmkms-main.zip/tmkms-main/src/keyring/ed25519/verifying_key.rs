use signature::Verifier;

use crate::error::{Error, ErrorKind};

use super::Signature;
use super::SigningKey;

/// Ed25519 verification key.
#[derive(Clone, Debug)]
pub struct VerifyingKey(pub(super) ed25519_consensus::VerificationKey);

impl VerifyingKey {
    /// Size of an encoded Ed25519 verifying key in bytes.
    pub const BYTE_SIZE: usize = 32;

    /// Borrow the serialized verification key as bytes.
    pub fn as_bytes(&self) -> &[u8; Self::BYTE_SIZE] {
        self.0.as_bytes()
    }
}

impl From<&SigningKey> for VerifyingKey {
    fn from(signing_key: &SigningKey) -> VerifyingKey {
        signing_key.verifying_key()
    }
}

impl From<VerifyingKey> for tendermint::PublicKey {
    fn from(verifying_key: VerifyingKey) -> tendermint::PublicKey {
        tendermint::PublicKey::from_raw_ed25519(verifying_key.as_bytes())
            .expect("invalid Ed25519 key")
    }
}

impl From<VerifyingKey> for tendermint_p2p::secret_connection::PublicKey {
    #[inline]
    fn from(verifying_key: VerifyingKey) -> tendermint_p2p::secret_connection::PublicKey {
        Self::from(&verifying_key)
    }
}

impl From<&VerifyingKey> for tendermint_p2p::secret_connection::PublicKey {
    fn from(verifying_key: &VerifyingKey) -> tendermint_p2p::secret_connection::PublicKey {
        verifying_key.0.into()
    }
}

impl Verifier<Signature> for VerifyingKey {
    fn verify(&self, msg: &[u8], sig: &Signature) -> signature::Result<()> {
        let sig = ed25519_consensus::Signature::from(sig.to_bytes());
        self.0
            .verify(&sig, msg)
            .map_err(|_| signature::Error::new())
    }
}

impl TryFrom<&[u8]> for VerifyingKey {
    type Error = Error;

    fn try_from(slice: &[u8]) -> Result<Self, Error> {
        slice
            .try_into()
            .map(Self)
            .map_err(|_| ErrorKind::InvalidKey.into())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::testing;
    use signature::Signer;

    #[test]
    fn verifying_key_as_bytes() {
        let verifying_key = testing::ed25519::gen_key().verifying_key();
        assert_eq!(verifying_key.as_bytes().len(), VerifyingKey::BYTE_SIZE);
    }

    #[test]
    fn verifying_key_from_signing_key() {
        let signing_key = testing::ed25519::gen_key();
        let verifying_key = VerifyingKey::from(&signing_key);
        assert_eq!(verifying_key.as_bytes().len(), VerifyingKey::BYTE_SIZE);
    }

    #[test]
    fn verifying_key_to_tendermint_public_key() {
        let verifying_key = testing::ed25519::gen_key().verifying_key();
        let tendermint_key: tendermint::PublicKey = verifying_key.into();
        match tendermint_key {
            tendermint::PublicKey::Ed25519(k) => {
                assert_eq!(k.as_bytes().len(), VerifyingKey::BYTE_SIZE);
            }
            _ => panic!("unexpected public key type"),
        }
    }

    #[test]
    fn verifying_key_verify_valid_signature() {
        let signing_key = testing::ed25519::gen_key();
        let verifying_key = VerifyingKey::from(&signing_key);
        let message = b"test message";
        let signature = signing_key.try_sign(message).unwrap();
        assert!(verifying_key.verify(message, &signature).is_ok());
    }

    #[test]
    fn verifying_key_verify_invalid_signature() {
        let signing_key = testing::ed25519::gen_key();
        let verifying_key = VerifyingKey::from(&signing_key);
        let message = b"test message";
        let invalid_signature = Signature::from_bytes(&[0u8; 64]);
        assert!(verifying_key.verify(message, &invalid_signature).is_err());
    }

    #[test]
    fn verifying_key_try_from_valid_slice() {
        let verifying_key = testing::ed25519::gen_key().verifying_key();
        let bytes = verifying_key.as_bytes();
        let verifying_key1 = VerifyingKey::try_from(bytes.as_slice()).unwrap();
        assert_eq!(verifying_key.as_bytes(), verifying_key1.as_bytes());
    }

    #[test]
    fn verifying_key_try_from_invalid_slice() {
        let bytes = [0u8; 31]; // Invalid length
        let result = VerifyingKey::try_from(bytes.as_slice());
        assert!(result.is_err());
    }
}
