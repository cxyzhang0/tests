//! Signing signature

pub use k256::ecdsa;

pub use super::ed25519;

/// Cryptographic signature used for block signing
pub enum Signature {
    /// ECDSA signature (e.g secp256k1)
    Ecdsa(ecdsa::Signature),

    ///  ED25519 signature
    Ed25519(ed25519::Signature),
}

impl Signature {
    /// Serialize this signature as a byte vector.
    pub fn to_vec(&self) -> Vec<u8> {
        match self {
            Self::Ecdsa(sig) => sig.to_vec(),
            Self::Ed25519(sig) => sig.to_vec(),
        }
    }
}

impl From<ecdsa::Signature> for Signature {
    fn from(sig: ecdsa::Signature) -> Signature {
        Self::Ecdsa(sig)
    }
}

impl From<ed25519::Signature> for Signature {
    fn from(sig: ed25519::Signature) -> Signature {
        Self::Ed25519(sig)
    }
}

impl From<Signature> for tendermint::Signature {
    fn from(sig: Signature) -> tendermint::Signature {
        sig.to_vec().try_into().expect("signature should be valid")
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::testing;
    use ::ed25519::Signature as Ed25519Signature;
    use k256::ecdsa::Signature as EcdsaSignature;

    fn ecdsa_signature() -> EcdsaSignature {
        let signer = testing::ecdsa::gen_signer();
        let message = b"hello, world!";
        signer.sign(message).unwrap()
    }
    fn ed25519_signature() -> Ed25519Signature {
        Ed25519Signature::from_slice(&[0u8; 64]).unwrap()
    }

    #[test]
    fn ecdsa_signature_to_vec() {
        let signature = ecdsa_signature();
        let vec = signature.to_vec();
        assert_eq!(vec.len(), 64);
    }

    #[test]
    fn ed25519_signature_to_vec() {
        let ed25519_sig = ed25519_signature();
        let signature = Signature::Ed25519(ed25519_sig);
        let vec = signature.to_vec();
        assert_eq!(vec.len(), 64);
    }

    #[test]
    fn from_ecdsa_signature() {
        let ecdsa_sig = ecdsa_signature();
        let signature: Signature = ecdsa_sig.into();
        if let Signature::Ecdsa(_) = signature {
            assert!(true);
        } else {
            assert!(false, "Expected Ecdsa variant");
        }
    }

    #[test]
    fn from_ed25519_signature() {
        let ed25519_sig = ed25519_signature();
        let signature: Signature = ed25519_sig.into();
        if let Signature::Ed25519(_) = signature {
            assert!(true);
        } else {
            assert!(false, "Expected Ed25519 variant");
        }
    }

    #[test]
    fn from_signature_to_tendermint_signature() {
        let ed25519_sig = ed25519_signature();
        let signature = Signature::Ed25519(ed25519_sig);
        let tm_signature: tendermint::Signature = signature.into();
        assert_eq!(tm_signature.as_bytes().len(), 64);
    }
}
