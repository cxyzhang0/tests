//! Chain-specific key configuration

use cosmrs::crypto::PublicKey;
use serde::{Deserialize, Serialize};
use subtle_encoding::bech32;
use tendermint::TendermintKey;

/// Options for how keys for this chain are represented
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(tag = "type")]
pub enum Format {
    /// Use the Bech32 serialization format with the given key prefixes
    #[serde(rename = "bech32")]
    Bech32 {
        /// Prefix to use for Account keys
        account_key_prefix: String,

        /// Prefix to use for Consensus keys
        consensus_key_prefix: String,
    },

    /// JSON-encoded Cosmos protobuf representation of keys
    #[serde(rename = "cosmos-json")]
    CosmosJson,

    /// Hex is a baseline representation
    #[serde(rename = "hex")]
    Hex,
}

impl Format {
    /// Serialize a `TendermintKey` according to chain-specific rules
    pub fn serialize(&self, public_key: TendermintKey) -> String {
        match self {
            Format::Bech32 {
                account_key_prefix,
                consensus_key_prefix,
            } => match public_key {
                TendermintKey::AccountKey(pk) => {
                    bech32::encode(account_key_prefix, tendermint::account::Id::from(pk))
                }
                TendermintKey::ConsensusKey(pk) => pk.to_bech32(consensus_key_prefix),
            },
            Format::CosmosJson => PublicKey::from(*public_key.public_key()).to_json(),
            Format::Hex => match public_key {
                TendermintKey::AccountKey(pk) => pk.to_hex(),
                TendermintKey::ConsensusKey(pk) => pk.to_hex(),
            },
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::testing;

    #[test]
    fn serialize_bech32_account_key() {
        let public_key = testing::ecdsa::gen_k256_tendermint_public_key();

        let format = Format::Bech32 {
            account_key_prefix: "acc".to_string(),
            consensus_key_prefix: "cons".to_string(),
        };
        let result = format.serialize(public_key);
        assert!(result.starts_with("acc"));
    }

    #[test]
    fn serialize_bech32_consensus_key() {
        let public_key = testing::ed25519::gen_ed25519_tendermint_public_key();

        let format = Format::Bech32 {
            account_key_prefix: "acc".to_string(),
            consensus_key_prefix: "cons".to_string(),
        };
        let result = format.serialize(public_key);
        assert!(result.starts_with("cons"));
    }

    #[test]
    fn serialize_k256_cosmos_json() {
        let format = Format::CosmosJson;
        let public_key = testing::ecdsa::gen_k256_tendermint_public_key();
        let result = format.serialize(public_key);
        println!("{}", result);
        assert!(result.contains("\"@type\":\"/cosmos.crypto.secp256k1.PubKey\""));
    }

    #[test]
    fn serialize_ed25519_cosmos_json() {
        let format = Format::CosmosJson;
        let public_key = testing::ed25519::gen_ed25519_tendermint_public_key();
        let result = format.serialize(public_key);
        println!("{}", result);
        assert!(result.contains("\"@type\":\"/cosmos.crypto.ed25519.PubKey\""));
    }
    #[test]
    fn serialize_hex_account_key() {
        let format = Format::Hex;
        let public_key = testing::ecdsa::gen_k256_tendermint_public_key();
        let result = format.serialize(public_key);
        println!("{result}");
        assert_eq!(result.len(), 66);
    }

    #[test]
    fn serialize_hex_consensus_key() {
        let format = Format::Hex;
        let public_key = testing::ed25519::gen_ed25519_tendermint_public_key();
        let result = format.serialize(public_key);
        println!("{result}");
        assert_eq!(result.len(), 64);
    }
}
