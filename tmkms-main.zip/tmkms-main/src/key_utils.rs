//! Utilities

use std::{
    fs::{self, OpenOptions},
    io::Write,
    os::unix::fs::OpenOptionsExt,
    path::Path,
};

use k256::ecdsa;
use rand_core::{OsRng, RngCore};
use subtle_encoding::base64;
use zeroize::Zeroizing;

use crate::{
    error::{Error, ErrorKind::*},
    keyring::ed25519,
    prelude::*,
};

/// File permissions for secret data
pub const SECRET_FILE_PERMS: u32 = 0o600;

/// Load Base64-encoded secret data (i.e. key) from the given path
pub fn load_base64_secret(path: impl AsRef<Path>) -> Result<Zeroizing<Vec<u8>>, Error> {
    // TODO(tarcieri): check file permissions are correct
    let base64_data = Zeroizing::new(fs::read_to_string(path.as_ref()).map_err(|e| {
        format_err!(
            IoError,
            "couldn't read key from {}: {}",
            path.as_ref().display(),
            e
        )
    })?);

    // TODO(tarcieri): constant-time string trimming
    let data = Zeroizing::new(base64::decode(base64_data.trim_end()).map_err(|e| {
        format_err!(
            IoError,
            "can't decode key from `{}`: {}",
            path.as_ref().display(),
            e
        )
    })?);

    Ok(data)
}

/// Load a Base64-encoded Ed25519 secret key
pub fn load_base64_ed25519_key(path: impl AsRef<Path>) -> Result<ed25519::SigningKey, Error> {
    let key_bytes = load_base64_secret(path)?;

    Ok(ed25519::SigningKey::try_from(key_bytes.as_ref())
        .map_err(|e| format_err!(InvalidKey, "invalid Ed25519 key: {}", e))?)
}

/// Load a Base64-encoded Secp256k1 secret key
pub fn load_base64_secp256k1_key(
    path: impl AsRef<Path>,
) -> Result<(ecdsa::SigningKey, ecdsa::VerifyingKey), Error> {
    let key_bytes = load_base64_secret(path)?;

    let signing = ecdsa::SigningKey::try_from(key_bytes.as_slice())
        .map_err(|e| format_err!(InvalidKey, "invalid ECDSA key: {}", e))?;

    let veryfing = ecdsa::VerifyingKey::from(&signing);

    Ok((signing, veryfing))
}

/// Store Base64-encoded secret data at the given path
pub fn write_base64_secret(path: impl AsRef<Path>, data: &[u8]) -> Result<(), Error> {
    let base64_data = Zeroizing::new(base64::encode(data));

    OpenOptions::new()
        .create(true)
        .write(true)
        .truncate(true)
        .mode(SECRET_FILE_PERMS)
        .open(path.as_ref())
        .and_then(|mut file| file.write_all(&base64_data))
        .map_err(|e| {
            format_err!(
                IoError,
                "couldn't write `{}`: {}",
                path.as_ref().display(),
                e
            )
            .into()
        })
}

/// Generate a Secret Connection key at the given path
pub fn generate_key(path: impl AsRef<Path>) -> Result<(), Error> {
    let mut secret_key = Zeroizing::new([0u8; ed25519::SigningKey::BYTE_SIZE]);
    OsRng.fill_bytes(&mut *secret_key);
    write_base64_secret(path, &*secret_key)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;

    use tempfile::tempdir;

    #[test]
    fn load_base64_secret_with_valid_data() {
        let dir = tempdir().unwrap();
        let file_path = dir.path().join("secret.txt");
        fs::write(&file_path, "aGVsbG8gd29ybGQ=").unwrap(); // "hello world" in base64
        let result = load_base64_secret(&file_path);
        assert!(result.is_ok());
        assert_eq!(result.unwrap().as_slice(), b"hello world");
    }

    #[test]
    fn load_base64_secret_with_invalid_data() {
        let dir = tempdir().unwrap();
        let file_path = dir.path().join("secret.txt");
        fs::write(&file_path, "invalid_base64").unwrap();
        let result = load_base64_secret(&file_path);
        assert!(result.is_err());
    }
    /*
        #[test]
        fn load_base64_ed25519_key_with_valid_key() {
            let dir = tempdir().unwrap();
            let file_path = dir.path().join("ed25519_key.txt");
            let key = ed25519::SigningKey::generate(&mut OsRng);
            let key_bytes = base64::encode(key.to_bytes());
            fs::write(&file_path, key_bytes).unwrap();
            let result = load_base64_ed25519_key(&file_path);
            assert!(result.is_ok());
        }
    */
    #[test]
    fn load_base64_ed25519_key_with_invalid_key() {
        let dir = tempdir().unwrap();
        let file_path = dir.path().join("ed25519_key.txt");
        fs::write(&file_path, "invalid_key").unwrap();
        let result = load_base64_ed25519_key(&file_path);
        assert!(result.is_err());
    }

    #[test]
    fn load_base64_secp256k1_key_with_valid_key() {
        let dir = tempdir().unwrap();
        let file_path = dir.path().join("secp256k1_key.txt");
        let key = ecdsa::SigningKey::random(&mut OsRng);
        let key_bytes = base64::encode(key.to_bytes());
        fs::write(&file_path, key_bytes).unwrap();
        let result = load_base64_secp256k1_key(&file_path);
        assert!(result.is_ok());
    }

    #[test]
    fn load_base64_secp256k1_key_with_invalid_key() {
        let dir = tempdir().unwrap();
        let file_path = dir.path().join("secp256k1_key.txt");
        fs::write(&file_path, "invalid_key").unwrap();
        let result = load_base64_secp256k1_key(&file_path);
        assert!(result.is_err());
    }
    /*
        #[test]
        fn write_base64_secret_with_valid_data() {
            let dir = tempdir().unwrap();
            let file_path = dir.path().join("secret.txt");
            let data = b"hello world";
            let result = write_base64_secret(&file_path, data);
            assert!(result.is_ok());
            let written_data = fs::read_to_string(&file_path).unwrap();
            assert_eq!(written_data, base64::encode(data));
        }
    */
    #[test]
    fn generate_key_creates_valid_key() {
        let dir = tempdir().unwrap();
        let file_path = dir.path().join("generated_key.txt");
        let result = generate_key(&file_path);
        assert!(result.is_ok());
        let key_data = fs::read_to_string(&file_path).unwrap();
        let decoded_key = base64::decode(key_data).unwrap();
        assert_eq!(decoded_key.len(), ed25519::SigningKey::BYTE_SIZE);
    }
}
