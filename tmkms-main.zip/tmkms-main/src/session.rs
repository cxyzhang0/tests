//! A session with a validator node

use std::{os::unix::net::UnixStream, time::Instant};

use tendermint::{consensus, TendermintKey};
use tendermint_config::net;
use tendermint_proto as proto;

use crate::{
    config::ValidatorConfig,
    connection::{tcp, unix::UnixConnection, Connection},
    error::{Error, ErrorKind::*},
    prelude::*,
    privval::SignableMsg,
    rpc::{Request, Response},
    // chain::{self, state::StateErrorKind, Chain},
    validator::{state::StateErrorKind, Validator, REGISTRY},
};

/// Encrypted session with a validator node
pub struct Session {
    /// Validator configuration options
    config: ValidatorConfig,

    /// TCP connection to a validator node
    connection: Box<dyn Connection>,
}

impl Session {
    /// Open a session using the given validator configuration
    pub fn open(config: ValidatorConfig) -> Result<Self, Error> {
        let connection: Box<dyn Connection> = match &config.addr {
            net::Address::Tcp {
                peer_id,
                host,
                port,
            } => {
                debug!(
                    "[{}:{}@{}] connecting to validator...",
                    &config.id, &config.chain_id, &config.addr
                );

                let conn = tcp::open_secret_connection(
                    host,
                    *port,
                    &config.secret_key,
                    peer_id,
                    config.timeout,
                    config.protocol_version.into(),
                )?;

                info!(
                    "[{}:{}@{}] connected to validator successfully",
                    &config.id, &config.chain_id, &config.addr
                );

                if peer_id.is_none() {
                    // TODO(tarcieri): make peer verification mandatory
                    warn!(
                        "[{}:{}@{}]: unverified validator peer ID! ({})",
                        &config.id,
                        &config.chain_id,
                        &config.addr,
                        conn.remote_pubkey().peer_id()
                    );
                }

                Box::new(conn)
            }
            net::Address::Unix { path } => {
                if let Some(timeout) = config.timeout {
                    warn!("timeouts not supported with Unix sockets: {}", timeout);
                }

                debug!(
                    "{}: Connecting to socket at {}...",
                    &config.id, &config.addr
                );

                let socket = UnixStream::connect(path)?;
                let conn = UnixConnection::new(socket);

                info!(
                    "[{}:{}@{}] connected to validator successfully",
                    &config.id, &config.chain_id, &config.addr
                );

                Box::new(conn)
            }
        };

        Ok(Self { config, connection })
    }

    /// Main request loop
    pub fn request_loop(&mut self) -> Result<(), Error> {
        while self.handle_request()? {}
        Ok(())
    }

    /// Handle an incoming request from the validator
    fn handle_request(&mut self) -> Result<bool, Error> {
        let request = Request::read(&mut self.connection, &self.config.chain_id)?;
        debug!(
            "[{}:{}@{}] received request: {:?}",
            &self.config.id, &self.config.chain_id, &self.config.addr, &request
        );

        let response = match request {
            Request::SignProposal(_) | Request::SignVote(_) => {
                self.sign(request.into_signable_msg()?)?
            }
            // non-signable requests:
            Request::PingRequest => Response::Ping(proto::privval::PingResponse {}),
            Request::ShowPublicKey => self.get_public_key()?,
        };

        debug!(
            "[{}:{}@{}] sending response: {:?}",
            &self.config.id, &self.config.chain_id, &self.config.addr, &response
        );

        let response_bytes = response.encode()?;
        self.connection.write_all(&response_bytes)?;

        Ok(true)
    }

    /// Perform a digital signature operation
    fn sign(&mut self, mut signable_msg: SignableMsg) -> Result<Response, Error> {
        self.check_max_height(&signable_msg)?;

        let registry = REGISTRY.get();

        let val = registry.get_validator(&self.config.id).unwrap_or_else(|| {
            panic!("validator '{}' missing from registry!", &self.config.id);
        });

        if let Some(remote_err) = self.update_consensus_state(val, &signable_msg)? {
            // In the event of double signing we send a response to notify the validator
            return Ok(Response::error(signable_msg, remote_err));
        }

        // TODO(tarcieri): support for non-default public keys
        let public_key = None;
        let chain_id = self.config.chain_id.clone();
        let canonical_msg = signable_msg.canonical_bytes(chain_id.clone())?;

        let started_at = Instant::now();
        let consensus_sig = val.keyring.sign(public_key, &canonical_msg)?;
        signable_msg.add_consensus_signature(consensus_sig);
        self.log_signing_request(&signable_msg, started_at).unwrap();

        // Add extension signature if the message is a precommit for a non-empty block ID.
        if val.sign_extensions {
            if let Some(extension_msg) = signable_msg.extension_bytes(chain_id)? {
                let started_at = Instant::now();
                let extension_sig = val.keyring.sign(public_key, &extension_msg)?;
                signable_msg.add_extension_signature(extension_sig)?;

                info!(
                    "[{}:{}@{}] signed vote extension ({} ms)",
                    &self.config.id,
                    &self.config.chain_id,
                    &self.config.addr,
                    started_at.elapsed().as_millis(),
                );
            }
        }

        Ok(signable_msg.into())
    }

    /// If a max block height is configured, ensure the block we're signing
    /// doesn't exceed it
    fn check_max_height(&mut self, signable_msg: &SignableMsg) -> Result<(), Error> {
        if let Some(max_height) = self.config.max_height {
            let height = signable_msg.height();

            if height > max_height {
                fail!(
                    ExceedMaxHeight,
                    "attempted to sign at height {} which is greater than {}",
                    height,
                    max_height,
                );
            }
        }

        Ok(())
    }

    /// Update our local knowledge of the chain's consensus state, detecting
    /// attempted double signing and sending a response in the event it happens
    fn update_consensus_state(
        &mut self,
        val: &Validator,
        signable_msg: &SignableMsg,
    ) -> Result<Option<proto::privval::RemoteSignerError>, Error> {
        let msg_type = signable_msg.msg_type();
        let request_state = signable_msg.consensus_state();
        let mut chain_state = val.state.lock().unwrap();

        match chain_state.update_consensus_state(request_state.clone()) {
            Ok(()) => Ok(None),
            Err(e) if e.kind() == StateErrorKind::DoubleSign => {
                // Report double signing error back to the validator
                let original_block_id = chain_state.consensus_state().block_id_prefix();

                error!(
                    "[{}:{}@{}] attempted double sign {:?} at h/r/s: {} ({} != {})",
                    &self.config.id,
                    &self.config.chain_id,
                    &self.config.addr,
                    msg_type,
                    request_state,
                    original_block_id,
                    request_state.block_id_prefix()
                );

                let remote_err = double_sign(request_state);
                Ok(Some(remote_err))
            }
            Err(e) => Err(e.into()),
        }
    }

    /// Get the public key for (the only) public key in the keyring
    fn get_public_key(&mut self) -> Result<Response, Error> {
        let registry = REGISTRY.get();

        let val = registry.get_validator(&self.config.id).unwrap_or_else(|| {
            panic!("validator '{}' missing from registry!", &self.config.id);
        });

        let pub_key = match val.keyring.default_pubkey()? {
            TendermintKey::AccountKey(pk) => pk,
            TendermintKey::ConsensusKey(pk) => pk,
        };

        Ok(Response::PublicKey(proto::privval::PubKeyResponse {
            pub_key: Some(pub_key.into()),
            error: None,
        }))
    }

    /// Write an INFO logline about a signing request
    fn log_signing_request(
        &self,
        signable_msg: &SignableMsg,
        started_at: Instant,
    ) -> Result<(), Error> {
        let msg_type = signable_msg.msg_type();
        let request_state = signable_msg.consensus_state();

        info!(
            "[{}:{}@{}] signed {:?}:{} at h/r/s {} ({} ms)",
            &self.config.id,
            &self.config.chain_id,
            &self.config.addr,
            msg_type,
            request_state.block_id_prefix(),
            request_state,
            started_at.elapsed().as_millis(),
        );

        Ok(())
    }
}

/// Double signing handler.
fn double_sign(consensus_state: consensus::State) -> proto::privval::RemoteSignerError {
    /// Double signing error code.
    const DOUBLE_SIGN_ERROR: i32 = 2;

    proto::privval::RemoteSignerError {
        code: DOUBLE_SIGN_ERROR,
        description: format!(
            "double signing requested at height: {}",
            consensus_state.height
        ),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::ProtocolVersion;
    use crate::{keyring, validator};
    use std::path::PathBuf;
    use tendermint::chain;
    use tendermint_config::net;
    // use crate::validator::ValidatorRegistry;

    fn create_test_validator_config() -> ValidatorConfig {
        ValidatorConfig {
            id: validator::Id::try_from("test_validator").unwrap(),
            addr: net::Address::Tcp {
                peer_id: None,
                host: "127.0.0.1".to_string(),
                port: 26656,
            },
            chain_id: chain::Id::try_from("test_chain").unwrap(),
            reconnect: true,
            timeout: Some(30),
            secret_key: Some(PathBuf::from("/path/to/secret_key")),
            key_format: keyring::Format::Bech32 {
                account_key_prefix: "ws".to_string(),
                consensus_key_prefix: "wf".to_string(),
            },
            sign_extensions: false,
            state_file: Some(PathBuf::from("/path/to/state_file")),
            max_height: Some(tendermint::block::Height::try_from(100u64).unwrap()),
            protocol_version: ProtocolVersion::V0_34,
            state_hook: None,
        }
    }
    /*
        #[test]
        fn open_session_with_tcp_connection() {
            let config = create_test_validator_config();
            let session = Session::open(config);
            assert!(session.is_ok());
        }

        #[test]
        fn open_session_with_unix_connection() {
            let mut config = create_test_validator_config();
            config.addr = net::Address::Unix { path: "/tmp/socket".into() };
            let session = Session::open(config);
            assert!(session.is_ok());
        }
    */
    #[test]
    fn open_session_fails_with_invalid_tcp_address() {
        let mut config = create_test_validator_config();
        config.addr = net::Address::Tcp {
            peer_id: None,
            host: "invalid_host".to_string(),
            port: 26656,
        };
        let session = Session::open(config);
        assert!(session.is_err());
    }
    /*
       #[test]
       fn handle_request_sign_proposal() {
           let mut session = Session::open(create_test_validator_config()).unwrap();
           let request = Request::SignProposal(proto::privval::SignProposalRequest::default());
           let result = session.handle_request();
           assert!(result.is_ok());
       }

       #[test]
       fn handle_request_sign_vote() {
           let mut session = Session::open(create_test_validator_config()).unwrap();
           let request = Request::SignVote(proto::privval::SignVoteRequest::default());
           let result = session.handle_request();
           assert!(result.is_ok());
       }

       #[test]
       fn handle_request_ping() {
           let mut session = Session::open(create_test_validator_config()).unwrap();
           let request = Request::PingRequest;
           let result = session.handle_request();
           assert!(result.is_ok());
       }

       #[test]
       fn handle_request_show_public_key() {
           let mut session = Session::open(create_test_validator_config()).unwrap();
           let request = Request::ShowPublicKey;
           let result = session.handle_request();
           assert!(result.is_ok());
       }

       #[test]
       fn check_max_height_exceeds() {
           let mut session = Session::open(create_test_validator_config()).unwrap();
           let mut signable_msg = SignableMsg::default();
           signable_msg.set_height(101);
           let result = session.check_max_height(&signable_msg);
           assert!(result.is_err());
       }

       #[test]
       fn check_max_height_within_limit() {
           let mut session = Session::open(create_test_validator_config()).unwrap();
           let mut signable_msg = SignableMsg::default();
           signable_msg.set_height(99);
           let result = session.check_max_height(&signable_msg);
           assert!(result.is_ok());
       }

       #[test]
       fn update_consensus_state_double_sign() {
           let mut session = Session::open(create_test_validator_config()).unwrap();
           let mut signable_msg = SignableMsg::default();
           let registry = ValidatorRegistry::default();
           let val = registry.get_validator(&session.config.id).unwrap();
           let result = session.update_consensus_state(val, &signable_msg);
           assert!(result.is_ok());
           assert!(result.unwrap().is_some());
       }

       #[test]
       fn get_public_key_success() {
           let mut session = Session::open(create_test_validator_config()).unwrap();
           let result = session.get_public_key();
           assert!(result.is_ok());
       }

    */
}
