//! Error types

use std::{
    any::Any,
    fmt::{self, Display},
    io,
    ops::Deref,
};

use abscissa_core::error::{BoxError, Context};
use thiserror::Error;

use crate::{prelude::*, validator};

/// Kinds of errors
#[derive(Copy, Clone, Eq, PartialEq, Debug, Error)]
pub enum ErrorKind {
    /// Access denied
    #[error("access denied")]
    AccessError,

    /// Invalid Chain ID
    #[error("chain ID error")]
    ChainIdError,

    /// Error in configuration file
    #[error("config error")]
    ConfigError,

    /// Cryptographic operation failed
    #[error("cryptographic error")]
    CryptoError,

    /// Double sign attempted
    #[error("attempted double sign")]
    DoubleSign,

    /// Request a signature above max height
    #[error("requested signature above stop height")]
    ExceedMaxHeight,

    /// Fortanix DSM related error
    #[cfg(feature = "fortanixdsm")]
    #[error("Fortanix DSM error")]
    FortanixDsmError,

    /// Error running a subcommand to update chain state
    #[error("subcommand hook failed")]
    HookError,

    /// Malformed or otherwise invalid cryptographic key
    #[error("invalid key")]
    InvalidKey,

    /// Validation of consensus message failed
    #[error("invalid consensus message")]
    InvalidMessageError,

    /// Input/output error
    #[error("I/O error")]
    IoError,

    /// PKCS11 HSM provider error
    #[cfg(feature = "p11hsm")]
    #[error("PKCS11 HSM error")]
    P11hsmError,

    /// KMS internal panic
    #[error("internal crash")]
    PanicError,

    /// Parse error
    #[error("parse error")]
    ParseError,

    /// KMS state has been poisoned
    #[error("internal state poisoned")]
    PoisonError,

    /// Network protocol-related errors
    #[error("protocol error")]
    ProtocolError,

    /// Serialization error
    #[error("serialization error")]
    SerializationError,

    /// Signing operation failed
    #[error("signing operation failed")]
    SigningError,

    /// Errors originating in the Tendermint crate
    #[error("Tendermint error")]
    TendermintError,

    /// Verification operation failed
    #[error("verification failed")]
    VerificationError,

    /// YubiHSM-related errors
    #[cfg(feature = "yubihsm")]
    #[error("YubiHSM error")]
    YubihsmError,
}

impl ErrorKind {
    /// Create an error context from this error
    pub fn context(self, source: impl Into<BoxError>) -> Context<ErrorKind> {
        Context::new(self, Some(source.into()))
    }
}

/// Error type
#[derive(Debug)]
pub struct Error(Box<Context<ErrorKind>>);

impl Error {
    /// Create an error from a panic
    pub fn from_panic(panic_msg: Box<dyn Any>) -> Self {
        let err_msg = if let Some(msg) = panic_msg.downcast_ref::<String>() {
            msg.as_ref()
        } else if let Some(msg) = panic_msg.downcast_ref::<&str>() {
            msg
        } else {
            "unknown cause"
        };

        let kind = if err_msg.contains("PoisonError") {
            ErrorKind::PoisonError
        } else {
            ErrorKind::PanicError
        };

        format_err!(kind, err_msg).into()
    }
}

impl Deref for Error {
    type Target = Context<ErrorKind>;

    fn deref(&self) -> &Context<ErrorKind> {
        &self.0
    }
}

impl Display for Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

impl From<ErrorKind> for Error {
    fn from(kind: ErrorKind) -> Self {
        Context::new(kind, None).into()
    }
}

impl From<Context<ErrorKind>> for Error {
    fn from(context: Context<ErrorKind>) -> Self {
        Error(Box::new(context))
    }
}

impl From<io::Error> for Error {
    fn from(other: io::Error) -> Self {
        ErrorKind::IoError.context(other).into()
    }
}

impl std::error::Error for Error {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        self.0.source()
    }
}

impl From<prost::DecodeError> for Error {
    fn from(other: prost::DecodeError) -> Self {
        ErrorKind::ProtocolError.context(other).into()
    }
}

impl From<prost::EncodeError> for Error {
    fn from(other: prost::EncodeError) -> Self {
        ErrorKind::ProtocolError.context(other).into()
    }
}

impl From<serde_json::error::Error> for Error {
    fn from(other: serde_json::error::Error) -> Self {
        ErrorKind::SerializationError.context(other).into()
    }
}

impl From<signature::Error> for Error {
    fn from(other: signature::Error) -> Self {
        ErrorKind::CryptoError.context(other).into()
    }
}

impl From<tendermint::Error> for Error {
    fn from(other: tendermint::error::Error) -> Self {
        ErrorKind::TendermintError.context(other).into()
    }
}

impl From<validator::state::StateError> for Error {
    fn from(other: validator::state::StateError) -> Self {
        ErrorKind::DoubleSign.context(other).into()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use prost::Message;
    use serde_json::error::Error as JsonError;
    use serde_json::json;
    use std::error::Error as StdError;
    use std::io;
    #[derive(prost::Message)]
    struct MyMessage {
        #[prost(string, tag = "1")]
        pub name: String,
    }
    #[derive(serde::Deserialize)]
    #[allow(dead_code)]
    struct MyStruct {
        name: String,
        age: u32,
    }

    fn create_error(kind: ErrorKind) -> Error {
        Context::new(kind, None).into()
    }

    #[test]
    fn error_kind() {
        assert_eq!(
            create_error(ErrorKind::AccessError).kind(),
            &ErrorKind::AccessError
        );
        assert_eq!(
            create_error(ErrorKind::ChainIdError).kind(),
            &ErrorKind::ChainIdError
        );
        assert_eq!(
            create_error(ErrorKind::ConfigError).kind(),
            &ErrorKind::ConfigError
        );
    }

    #[test]
    fn error_kind_access_error() {
        let error = create_error(ErrorKind::AccessError);
        assert_eq!(error.kind(), &ErrorKind::AccessError);
        assert_eq!(format!("{}", error.kind()), "access denied");
    }

    #[test]
    fn error_source() {
        let io_error = io::Error::new(io::ErrorKind::Other, "I/O error");
        let error: Error = io_error.into();
        assert_eq!(error.source().unwrap().to_string(), "I/O error");
    }

    #[test]
    fn error_kind_display() {
        assert_eq!(
            format!("{}", create_error(ErrorKind::AccessError).kind()),
            "access denied"
        );
        assert_eq!(
            format!("{}", create_error(ErrorKind::ChainIdError)),
            "chain ID error"
        );
        assert_eq!(
            format!("{}", create_error(ErrorKind::ConfigError)),
            "config error"
        );
    }

    #[test]
    fn error_from_panic() {
        let panic_msg = Box::new("PoisonError".to_string());
        let error = Error::from_panic(panic_msg);
        assert_eq!(error.kind(), &ErrorKind::PoisonError);

        let panic_msg = Box::new("Some other error");
        let error = Error::from_panic(panic_msg);
        assert_eq!(error.kind(), &ErrorKind::PanicError);

        let panic_msg = Box::new(MyMessage {
            name: "my message".to_string(),
        });
        let error = Error::from_panic(panic_msg);
        assert_eq!(error.kind(), &ErrorKind::PanicError);
    }

    #[test]
    fn error_from_io_error() {
        let io_error = io::Error::new(io::ErrorKind::Other, "I/O error");
        let error: Error = io_error.into();
        assert_eq!(error.kind(), &ErrorKind::IoError);
    }

    #[test]
    fn error_from_prost_decode_error() {
        let decode_error = prost::DecodeError::new("Decode error");
        let error: Error = decode_error.into();
        assert_eq!(error.kind(), &ErrorKind::ProtocolError);
    }

    #[test]
    fn error_from_prost_encode_error() {
        let msg = MyMessage {
            name: "example".to_string(),
        };

        let mut buf = vec![0u8; 1];
        match msg.encode(&mut buf) {
            Ok(()) => println!("encoding successful"),
            Err(e) => {
                // does not reach here
                let error: Error = e.into();
                assert_eq!(error.kind(), &ErrorKind::ProtocolError);
            }
        }
    }

    #[test]
    fn error_from_serde_json_error() {
        // serialization error
        let invalid_json = "{ invalid json }";
        let result: Result<serde_json::Value, JsonError> = serde_json::from_str(invalid_json);
        match result {
            Ok(_) => println!("JSON parsed successfully"),
            Err(e) => {
                let error: Error = e.into();
                assert_eq!(error.kind(), &ErrorKind::SerializationError);
            }
        };
        // deserialization error
        let data = json!({
            "name": "example",
            "age": "invalid age" // This should be a number, not a string
        });
        let result: Result<MyStruct, JsonError> = serde_json::from_value(data);
        match result {
            Ok(_) => println!("Data deserialized successfully"),
            Err(e) => {
                let error: Error = e.into();
                assert_eq!(error.kind(), &ErrorKind::SerializationError);
            }
        }
    }

    #[test]
    fn error_from_signature_error() {
        let signature_error = signature::Error::new();
        let error: Error = signature_error.into();
        assert_eq!(error.kind(), &ErrorKind::CryptoError);
    }
    /*
        #[test]
        fn error_from_tendermint_error() {
            let tendermint_error = tendermint::error::Error::new("Tendermint error");
            let error: Error = tendermint_error.into();
            assert_eq!(error.kind(), ErrorKind::TendermintError);
        }
    */
    #[test]
    fn error_from_validator_state_error() {
        let state_error =
            validator::state::StateError::from(validator::state::StateErrorKind::DoubleSign);
        let error: Error = state_error.into();
        assert_eq!(error.kind(), &ErrorKind::DoubleSign);
    }
}
