//! Registry of information about known validators of the KMS

use std::sync::RwLock;

use once_cell::sync::Lazy;

use crate::{
    error::{Error, ErrorKind::*},
    keyring,
    prelude::*,
    Map,
};

use super::{Guard, Id, Validator};

/// State of Tendermint blockchain networks
pub static REGISTRY: Lazy<GlobalRegistry> = Lazy::new(GlobalRegistry::default);

/// Registry of the validators known to the KMS
#[derive(Default)]
pub struct Registry(Map<Id, Validator>);

impl Registry {
    /// Add an account key to a keyring for a validator stored in the registry
    pub fn add_account_key(
        &mut self,
        val_id: &Id,
        signer: keyring::ecdsa::Signer,
    ) -> Result<(), Error> {
        let val = self.0.get_mut(val_id).ok_or_else(|| {
            format_err!(
                InvalidKey,
                "can't add ECDSA signer {} to unregistered validator: {}",
                signer.provider(),
                val_id,
            )
        })?;
        val.keyring.add_ecdsa(signer)
    }

    /// Add a consensus key to a keyring for a validator stored in the registry
    pub fn add_consensus_key(
        &mut self,
        val_id: &Id,
        signer: keyring::ed25519::Signer,
    ) -> Result<(), Error> {
        let val = self.0.get_mut(val_id).ok_or_else(|| {
            format_err!(
                InvalidKey,
                "can't add Ed25519 signer {} to unregistered validator: {}",
                signer.provider(),
                val_id,
            )
        })?;
        val.keyring.add_ed25519(signer)
    }

    /// Register a `Validator` with the registry
    pub fn register_validator(&mut self, val: Validator) -> Result<(), Error> {
        let val_id = val.id.clone();

        if self.0.insert(val_id.clone(), val).is_none() {
            Ok(())
        } else {
            // TODO(tarcieri): handle updating the set of registered chains
            fail!(ConfigError, "validator already registered: {}", val_id)
        }
    }

    /// Get information about a particular validator ID (if registered)
    pub fn get_validator(&self, val_id: &Id) -> Option<&Validator> {
        self.0.get(val_id)
    }
}

/// Global registry of validators known to the KMS
// NOTE: The `RwLock` is a bit of futureproofing as this data structure is for the
// most part "immutable". New chains should be registered at boot time.
// The only case in which this structure may change is in the event of
// runtime configuration reloading, so the `RwLock` is included as
// futureproofing for such a feature.
//
// See: <https://github.com/tendermint/kms/issues/183>

#[derive(Default)]
pub struct GlobalRegistry(pub(super) RwLock<Registry>);

impl GlobalRegistry {
    /// Acquire a read-only (concurrent) lock to the internal validator registry
    pub fn get(&self) -> Guard<'_> {
        // TODO(tarcieri): better handle `PoisonError` here?
        self.0.read().unwrap().into()
    }

    /// Register a `Validator` with the registry
    pub fn register(&self, val: Validator) -> Result<(), Error> {
        // Acquire a mutable lock to the internal validator registry
        // TODO(tarcieri): better handle `PoisonError` here?
        let mut registry = self.0.write().unwrap();
        registry.register_validator(val)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    use crate::testing;
    use crate::validator::Id;
    use crate::validator::Validator;

    #[test]
    fn registered_new_validator() {
        let mut registry = Registry::default();
        let config = testing::validator::create_test_validator_config();
        let val = Validator::from_config(&config).unwrap();
        let result = registry.register_validator(val);

        assert!(result.is_ok());
    }

    #[test]
    fn register_existing_validator() {
        let mut registry = Registry::default();
        let config = testing::validator::create_test_validator_config();
        let val = Validator::from_config(&config).unwrap();
        let result = registry.register_validator(val);
        assert!(result.is_ok());

        let val = Validator::from_config(&config).unwrap();
        let result = registry.register_validator(val);
        assert!(result.is_err());
    }

    #[test]
    fn add_account_key_to_registered_validator() {
        let mut registry = Registry::default();
        let config = testing::validator::create_test_validator_config();
        let val = Validator::from_config(&config).unwrap();
        let val_id = val.id.clone();
        registry.register_validator(val).unwrap();

        let signer = testing::ecdsa::gen_signer();
        let result = registry.add_account_key(&val_id, signer);
        assert!(result.is_ok());
    }

    #[test]
    fn add_account_key_to_unregistered_validator() {
        let mut registry = Registry::default();
        let config = testing::validator::create_test_validator_config();
        let val = Validator::from_config(&config).unwrap();
        let val_id = val.id.clone();

        let signer = testing::ecdsa::gen_signer();
        let result = registry.add_account_key(&val_id, signer);
        assert!(result.is_err());
    }

    #[test]
    fn add_consensus_key_to_registered_validator() {
        let mut registry = Registry::default();
        let config = testing::validator::create_test_validator_config();
        let val = Validator::from_config(&config).unwrap();
        let val_id = val.id.clone();
        registry.register_validator(val).unwrap();

        let signer = testing::ed25519::gen_signer();
        let result = registry.add_consensus_key(&val_id, signer);
        assert!(result.is_ok());
    }

    #[test]
    fn add_consensus_key_to_unregistered_validator() {
        let mut registry = Registry::default();
        let config = testing::validator::create_test_validator_config();
        let val = Validator::from_config(&config).unwrap();
        let val_id = val.id.clone();

        let signer = testing::ed25519::gen_signer();
        let result = registry.add_consensus_key(&val_id, signer);
        assert!(result.is_err());
    }

    #[test]
    fn get_registered_validator() {
        let mut registry = Registry::default();
        let config = testing::validator::create_test_validator_config();
        let val = Validator::from_config(&config).unwrap();
        let val_id = val.id.clone();
        registry.register_validator(val).unwrap();

        let signer = testing::ed25519::gen_signer();
        let _result = registry.add_consensus_key(&val_id, signer);

        let result = registry.get_validator(&val_id);
        assert!(result.is_some());

        let val2 = result.unwrap();
        assert_eq!(val2.id, val_id);
    }

    #[test]
    fn get_unregistered_validator() {
        let registry = Registry::default();
        let val_id = Id::try_from("validator1").unwrap();

        let result = registry.get_validator(&val_id);
        assert!(result.is_none());
    }

    #[test]
    fn global_registry_register_validator() {
        let global_registry = GlobalRegistry::default();
        let config = testing::validator::create_test_validator_config();
        let val = Validator::from_config(&config).unwrap();

        let result = global_registry.register(val);
        assert!(result.is_ok());
    }

    #[test]
    fn global_registry_get_validator() {
        let global_registry = GlobalRegistry::default();
        let config = testing::validator::create_test_validator_config();
        let val = Validator::from_config(&config).unwrap();
        let val_id = val.id.clone();

        global_registry
            .register(val)
            .expect("failed to register validator");

        let guard = global_registry.get();
        let result = guard.get_validator(&val_id);
        assert!(result.is_some());
    }
}
