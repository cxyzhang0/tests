use std::sync::RwLockReadGuard;

use super::{Id, Registry, Validator};

/// Wrapper for a `RwLockReadGuard<'static, Registry>`, allowing access to
/// global information about particular Tendermint networks / "validators"
pub struct Guard<'lock>(RwLockReadGuard<'lock, Registry>);

impl<'lock> From<RwLockReadGuard<'lock, Registry>> for Guard<'lock> {
    fn from(guard: RwLockReadGuard<'lock, Registry>) -> Guard<'lock> {
        Guard(guard)
    }
}

impl<'lock> Guard<'lock> {
    /// Get information about a particular chain ID (if registered)
    pub fn get_validator(&self, val_id: &Id) -> Option<&Validator> {
        self.0.get_validator(val_id)
    }
}
