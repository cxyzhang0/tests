//! Unix domain socket connection to a validator

use std::io;

/// Protocol implementation of the UNIX socket domain connection
pub struct UnixConnection<IoHandler> {
    socket: IoHandler,
}

impl<IoHandler> UnixConnection<IoHandler>
where
    IoHandler: io::Read + io::Write + Send + Sync,
{
    /// Create a new `UnixConnection` for the given socket
    pub fn new(socket: IoHandler) -> Self {
        Self { socket }
    }
}

impl<IoHandler> io::Read for UnixConnection<IoHandler>
where
    IoHandler: io::Read + io::Write + Send + Sync,
{
    fn read(&mut self, data: &mut [u8]) -> Result<usize, io::Error> {
        self.socket.read(data)
    }
}

impl<IoHandler> io::Write for UnixConnection<IoHandler>
where
    IoHandler: io::Read + io::Write + Send + Sync,
{
    fn write(&mut self, data: &[u8]) -> Result<usize, io::Error> {
        self.socket.write(data)
    }

    fn flush(&mut self) -> Result<(), io::Error> {
        self.socket.flush()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::{self, Read, Write};

    struct MockIoHandler {
        read_data: Vec<u8>,
        write_data: Vec<u8>,
    }

    impl Read for MockIoHandler {
        fn read(&mut self, buf: &mut [u8]) -> io::Result<usize> {
            let len = self.read_data.len().min(buf.len());
            buf[..len].copy_from_slice(&self.read_data[..len]);
            self.read_data.drain(..len);
            Ok(len)
        }
    }

    impl Write for MockIoHandler {
        fn write(&mut self, buf: &[u8]) -> io::Result<usize> {
            self.write_data.extend_from_slice(buf);
            Ok(buf.len())
        }

        fn flush(&mut self) -> io::Result<()> {
            Ok(())
        }
    }

    #[test]
    fn unix_connection_reads_data() {
        let handler = MockIoHandler {
            read_data: b"hello".to_vec(),
            write_data: Vec::new(),
        };
        let mut conn = UnixConnection::new(handler);
        let mut buffer = [0; 5];
        let size = conn.read(&mut buffer).unwrap();
        assert_eq!(size, 5);
        assert_eq!(&buffer, b"hello");
    }

    #[test]
    fn unix_connection_writes_data() {
        let handler = MockIoHandler {
            read_data: Vec::new(),
            write_data: Vec::new(),
        };
        let mut conn = UnixConnection::new(handler);
        let size = conn.write(b"world").unwrap();
        assert_eq!(size, 5);
        assert_eq!(conn.socket.write_data, b"world");
    }

    #[test]
    fn unix_connection_flushes_data() {
        let handler = MockIoHandler {
            read_data: Vec::new(),
            write_data: Vec::new(),
        };
        let mut conn = UnixConnection::new(handler);
        let result = conn.flush();
        assert!(result.is_ok());
    }

    #[test]
    fn unix_connection_read_empty_data() {
        let handler = MockIoHandler {
            read_data: Vec::new(),
            write_data: Vec::new(),
        };
        let mut conn = UnixConnection::new(handler);
        let mut buffer = [0; 5];
        let size = conn.read(&mut buffer).unwrap();
        assert_eq!(size, 0);
    }

    #[test]
    fn unix_connection_write_empty_data() {
        let handler = MockIoHandler {
            read_data: Vec::new(),
            write_data: Vec::new(),
        };
        let mut conn = UnixConnection::new(handler);
        let size = conn.write(b"").unwrap();
        assert_eq!(size, 0);
        assert!(conn.socket.write_data.is_empty());
    }
}
