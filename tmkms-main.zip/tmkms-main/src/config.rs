//! Configuration file structures (with serde-derived parser)

use serde::Deserialize;

use self::provider::ProviderConfig;
pub use self::validator::*;

pub mod chain;
pub mod provider;
pub mod validator;

/// Environment variable containing path to config file
pub const CONFIG_ENV_VAR: &str = "TMKMS_CONFIG_FILE";

/// Name of the KMS configuration file
pub const CONFIG_FILE_NAME: &str = "tmkms.toml";

/// KMS configuration (i.e. TOML file parsed with serde)
#[derive(Default, Deserialize, Debug)]
#[serde(deny_unknown_fields)]
pub struct KmsConfig {
    /// Cryptographic signature provider configuration
    pub providers: ProviderConfig,

    /// Addresses of validator nodes
    #[serde(default)]
    pub validator: Vec<ValidatorConfig>,
}
