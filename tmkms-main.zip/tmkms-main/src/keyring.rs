//! Signing keyring. Presently specialized for Ed25519 and ECDSA.

use tendermint::{account, TendermintKey};

use crate::{
    config::provider::ProviderConfig,
    error::{Error, ErrorKind::*},
    prelude::*,
    validator, Map,
};

pub use self::{format::Format, providers::SigningProvider, signature::Signature};

pub mod ecdsa;
pub mod ed25519;
pub mod format;
pub mod providers;
pub mod signature;

/// File encoding for software-backed secret keys
pub type SecretKeyEncoding = subtle_encoding::Base64;

/// Signing keyring
pub struct KeyRing {
    /// ECDSA keys in the keyring
    ecdsa_keys: Map<TendermintKey, ecdsa::Signer>,

    /// Ed25519 keys in the keyring
    ed25519_keys: Map<TendermintKey, ed25519::Signer>,

    /// Formatting configuration when displaying keys (e.g. bech32)
    format: Format,
}

impl KeyRing {
    /// Create a new keyring
    pub fn new(format: Format) -> Self {
        Self {
            ecdsa_keys: Map::new(),
            ed25519_keys: Map::new(),
            format,
        }
    }

    /// Add na ECDSA key to the keyring, returning an error if we already have a
    /// signer registered for the given public key
    pub fn add_ecdsa(&mut self, signer: ecdsa::Signer) -> Result<(), Error> {
        let provider = signer.provider();
        let public_key = signer.public_key();
        let public_key_serialized = self.format.serialize(public_key);
        let key_type = match public_key {
            TendermintKey::AccountKey(_) => "account",
            TendermintKey::ConsensusKey(_) => unimplemented!(
                "ECDSA consensus keys unsupported: {:?}",
                public_key_serialized
            ),
        };

        info!(
            "[keyring:{}] added {} ECDSA key: {}",
            provider, key_type, public_key_serialized
        );

        if let Some(other) = self.ecdsa_keys.insert(public_key, signer) {
            fail!(
                InvalidKey,
                "[keyring:{}] duplicate key {} already registered as {}",
                provider,
                public_key_serialized,
                other.provider(),
            )
        } else {
            Ok(())
        }
    }

    /// Add a key to the keyring, returning an error if we already have a
    /// signer registered for the given public key
    pub fn add_ed25519(&mut self, signer: ed25519::Signer) -> Result<(), Error> {
        let provider = signer.provider();
        let public_key = signer.public_key();
        let public_key_serialized = self.format.serialize(public_key);
        let key_type = match public_key {
            TendermintKey::AccountKey(_) => unimplemented!(
                "Ed25519 account keys unsupported: {:?}",
                public_key_serialized
            ),
            TendermintKey::ConsensusKey(_) => "consensus",
        };

        info!(
            "[keyring:{}] added {} Ed25519 key: {}",
            provider, key_type, public_key_serialized
        );

        if let Some(other) = self.ed25519_keys.insert(public_key, signer) {
            fail!(
                InvalidKey,
                "[keyring:{}] duplicate key {} already registered as {}",
                provider,
                public_key_serialized,
                other.provider(),
            )
        } else {
            Ok(())
        }
    }

    /// Get the default Ed25519 (i.e. consensus) public key for this keyring
    pub fn default_pubkey(&self) -> Result<TendermintKey, Error> {
        if !self.ed25519_keys.is_empty() {
            let mut keys = self.ed25519_keys.keys();

            if keys.len() == 1 {
                Ok(*keys.next().unwrap())
            } else {
                fail!(InvalidKey, "expected only one ed25519 key in keyring");
            }
        } else if !self.ecdsa_keys.is_empty() {
            let mut keys = self.ecdsa_keys.keys();

            if keys.len() == 1 {
                Ok(*keys.next().unwrap())
            } else {
                fail!(InvalidKey, "expected only one ecdsa key in keyring");
            }
        } else {
            fail!(InvalidKey, "keyring is empty");
        }
    }

    /// Get ECDSA public key bytes for a given account ID
    pub fn get_account_pubkey(&self, account_id: account::Id) -> Option<tendermint::PublicKey> {
        for key in self.ecdsa_keys.keys() {
            if let TendermintKey::AccountKey(pk) = key {
                if account_id == account::Id::from(*pk) {
                    return Some(*pk);
                }
            }
        }

        None
    }

    /// Sign a message using ECDSA
    pub fn sign_ecdsa(
        &self,
        account_id: account::Id,
        msg: &[u8],
    ) -> Result<ecdsa::Signature, Error> {
        for (key, signer) in &self.ecdsa_keys {
            if let TendermintKey::AccountKey(pk) = key {
                if account_id == account::Id::from(*pk) {
                    return signer.sign(msg);
                }
            }
        }

        fail!(
            InvalidKey,
            "no ECDSA key in keyring for account ID: {}",
            account_id
        )
    }

    /// Sign a message using the secret key associated with the given public key
    /// (if it is in our keyring)
    pub fn sign(&self, public_key: Option<&TendermintKey>, msg: &[u8]) -> Result<Signature, Error> {
        if self.ed25519_keys.len() > 1 || self.ecdsa_keys.len() > 1 {
            fail!(SigningError, "expected only one key in keyring");
        }

        if !self.ed25519_keys.is_empty() {
            let signer = match public_key {
                Some(public_key) => self.ed25519_keys.get(public_key).ok_or_else(|| {
                    format_err!(
                        InvalidKey,
                        "not in keyring: {}",
                        match public_key {
                            TendermintKey::AccountKey(pk) => pk.to_bech32(""),
                            TendermintKey::ConsensusKey(pk) => pk.to_bech32(""),
                        }
                    )
                }),
                None => self
                    .ed25519_keys
                    .values()
                    .next()
                    .ok_or_else(|| format_err!(InvalidKey, "ed25519 keyring is empty")),
            }?;

            Ok(Signature::Ed25519(signer.sign(msg)?))
        } else if !self.ecdsa_keys.is_empty() {
            let signer = match public_key {
                Some(public_key) => self.ecdsa_keys.get(public_key).ok_or_else(|| {
                    format_err!(
                        InvalidKey,
                        "not in keyring: {}",
                        match public_key {
                            TendermintKey::AccountKey(pk) => pk.to_bech32(""),
                            TendermintKey::ConsensusKey(pk) => pk.to_bech32(""),
                        }
                    )
                }),
                None => self
                    .ecdsa_keys
                    .values()
                    .next()
                    .ok_or_else(|| format_err!(InvalidKey, "ecdsa keyring is empty")),
            }?;

            Ok(Signature::Ecdsa(signer.sign(msg)?))
        } else {
            Err(format_err!(InvalidKey, "keyring is empty").into())
        }
    }
}

/// Initialize the keyring from the configuration file
pub fn load_config(
    registry: &mut validator::Registry,
    config: &ProviderConfig,
) -> Result<(), Error> {
    #[cfg(feature = "softsign")]
    providers::softsign::init(registry, &config.softsign)?;

    #[cfg(feature = "yubihsm")]
    providers::yubihsm::init(registry, &config.yubihsm)?;

    #[cfg(feature = "ledger")]
    providers::ledgertm::init(registry, &config.ledgertm)?;

    #[cfg(feature = "fortanixdsm")]
    providers::fortanixdsm::init(registry, &config.fortanixdsm)?;

    #[cfg(feature = "p11hsm")]
    providers::p11hsm::init(registry, &config.p11hsm)?;

    Ok(())
}

#[cfg(test)]
mod tests {
    use ::signature::Verifier;

    use super::*;
    use crate::testing;

    fn create_test_keyring() -> KeyRing {
        KeyRing::new(Format::Bech32 {
            account_key_prefix: "wf".to_string(),
            consensus_key_prefix: "wf".to_string(),
        })
    }

    #[test]
    fn new_keyring_is_empty() {
        let keyring = create_test_keyring();
        assert!(keyring.ecdsa_keys.is_empty());
        assert!(keyring.ed25519_keys.is_empty());
    }

    #[test]
    fn add_ecdsa_key_successfully() {
        let mut keyring = create_test_keyring();
        let signer = testing::ecdsa::gen_signer();
        assert!(keyring.add_ecdsa(signer).is_ok());
    }

    #[test]
    fn add_ed25519_key_successfully() {
        let mut keyring = create_test_keyring();
        let signer = testing::ed25519::gen_signer();
        assert!(keyring.add_ed25519(signer).is_ok());
    }

    #[test]
    #[should_panic]
    fn add_ed25519_to_ecdsa_signer() {
        let mut keyring = create_test_keyring();
        let signer = testing::ecdsa::gen_cross_signer();
        keyring.add_ecdsa(signer.clone()).unwrap();
    }

    #[test]
    #[should_panic]
    fn add_p256_to_ed25519_signer() {
        let mut keyring = create_test_keyring();
        let signer = testing::ed25519::gen_cross_signer();
        keyring.add_ed25519(signer.clone()).unwrap();
    }

    #[test]
    fn add_duplicate_ed25519_key_fails() {
        let mut keyring = create_test_keyring();
        let signer = testing::ed25519::gen_signer();
        keyring.add_ed25519(signer.clone()).unwrap();
        let result = keyring.add_ed25519(signer);
        assert!(result.is_err());
    }

    #[test]
    fn add_duplicate_ecdsa_key_fails() {
        let mut keyring = create_test_keyring();
        let signer = testing::ecdsa::gen_signer();
        keyring.add_ecdsa(signer.clone()).unwrap();
        let result = keyring.add_ecdsa(signer);
        assert!(result.is_err());
        if let InvalidKey = result.unwrap_err().kind() {
            assert!(true);
        } else {
            assert!(false);
        }
    }

    #[test]
    fn default_ed_pubkey_returns_correct_key() {
        let mut keyring = create_test_keyring();
        let signer = testing::ed25519::gen_signer();
        keyring.add_ed25519(signer.clone()).unwrap();
        let public_key = signer.public_key();
        assert_eq!(keyring.default_pubkey().unwrap(), public_key);
    }
    #[test]
    fn default_ec_pubkey_returns_correct_key() {
        let mut keyring = create_test_keyring();
        let signer = testing::ecdsa::gen_signer();
        keyring.add_ecdsa(signer.clone()).unwrap();
        let public_key = signer.public_key();
        assert_eq!(keyring.default_pubkey().unwrap(), public_key);
    }

    #[test]
    fn default_pubkey_fails_when_empty() {
        let keyring = create_test_keyring();
        let result = keyring.default_pubkey();
        assert!(result.is_err());
        if let InvalidKey = result.unwrap_err().kind() {
            assert!(true);
        } else {
            assert!(false);
        }
    }

    #[test]
    fn default_pubkey_fails_when_2_ed_key() {
        let mut keyring = create_test_keyring();
        let signer = testing::ed25519::gen_signer();
        keyring.add_ed25519(signer.clone()).unwrap();
        let signer = testing::ed25519::gen_signer();
        keyring.add_ed25519(signer.clone()).unwrap();
        let result = keyring.default_pubkey();
        assert!(result.is_err());
    }

    #[test]
    fn default_pubkey_fails_when_2_ec_key() {
        let mut keyring = create_test_keyring();
        let signer = testing::ecdsa::gen_signer();
        keyring.add_ecdsa(signer.clone()).unwrap();
        let signer = testing::ecdsa::gen_signer();
        keyring.add_ecdsa(signer.clone()).unwrap();
        let result = keyring.default_pubkey();
        assert!(result.is_err());
    }

    #[test]
    fn get_account_pubkey_returns_correct_key() {
        let mut keyring = create_test_keyring();
        let signer = testing::ecdsa::gen_signer();
        keyring.add_ecdsa(signer.clone()).unwrap();
        let public_key = signer.public_key();
        if let TendermintKey::AccountKey(pk) = public_key {
            let account_id = account::Id::from(pk);
            assert_eq!(keyring.get_account_pubkey(account_id).unwrap(), pk);
        } else {
            panic!("unexpected public key type");
        };
    }

    #[test]
    fn get_account_pubkey_returns_none_for_missing_key() {
        let keyring = create_test_keyring();
        let account_id = account::Id::new([0u8; 20]);
        assert!(keyring.get_account_pubkey(account_id).is_none());
    }

    #[test]
    fn sign_ecdsa_successfully() {
        let mut keyring = create_test_keyring();
        let signer = testing::ecdsa::gen_signer();
        keyring.add_ecdsa(signer.clone()).unwrap();

        let public_key = signer.public_key();

        if let TendermintKey::AccountKey(pk) = public_key {
            let account_id = account::Id::from(pk);
            let msg = b"test message";
            assert!(keyring.sign_ecdsa(account_id, msg).is_ok());
            let verifying_key = testing::ecdsa::get_vk_from_signer(&signer);
            verifying_key
                .verify(msg, &keyring.sign_ecdsa(account_id, msg).unwrap())
                .unwrap();
        } else {
            panic!("unexpected public key type");
        };
    }

    #[test]
    fn sign_ecdsa_fails_for_missing_key() {
        let keyring = create_test_keyring();
        let account_id = account::Id::new([0u8; 20]);
        let msg = b"test message";
        let result = keyring.sign_ecdsa(account_id, msg);
        assert!(result.is_err());
        // assert_eq!(result.unwrap_err().kind(), ErrorKind::InvalidKey);
    }

    #[test]
    fn sign_successfully_with_ecdsa() {
        let mut keyring = create_test_keyring();
        let signer = testing::ecdsa::gen_signer();
        keyring.add_ecdsa(signer.clone()).unwrap();

        let public_key = signer.public_key();
        let msg = b"test message";
        assert!(keyring.sign(Some(&public_key), msg).is_ok());
    }
    #[test]
    fn sign_successfully_with_ecdsa_none_pk() {
        let mut keyring = create_test_keyring();
        let signer = testing::ecdsa::gen_signer();
        keyring.add_ecdsa(signer.clone()).unwrap();

        let msg = b"test message";
        assert!(keyring.sign(None, msg).is_ok());
    }
    #[test]
    fn sign_successfully_with_ed25519() {
        let mut keyring = create_test_keyring();
        let signer = testing::ed25519::gen_signer();
        keyring.add_ed25519(signer.clone()).unwrap();
        let public_key = signer.public_key();
        let msg = b"test message";
        assert!(keyring.sign(Some(&public_key), msg).is_ok());
    }
    #[test]
    fn sign_successfully_with_ed25519_none_pk() {
        let mut keyring = create_test_keyring();
        let signer = testing::ed25519::gen_signer();
        keyring.add_ed25519(signer.clone()).unwrap();
        let msg = b"test message";
        assert!(keyring.sign(None, msg).is_ok());
    }

    #[test]
    fn sign_fails_when_keyring_is_empty() {
        let keyring = create_test_keyring();
        let msg = b"test message";
        let result = keyring.sign(None, msg);
        assert!(result.is_err());
    }

    #[test]
    fn sign_fails_with_2_ed_keys() {
        let mut keyring = create_test_keyring();
        let signer = testing::ed25519::gen_signer();
        keyring.add_ed25519(signer.clone()).unwrap();
        let signer = testing::ed25519::gen_signer();
        keyring.add_ed25519(signer.clone()).unwrap();
        let public_key = signer.public_key();
        let msg = b"test message";
        assert!(keyring.sign(Some(&public_key), msg).is_err());
    }

    #[test]
    fn sign_fails_with_ecdsa_wrong_pk() {
        let mut keyring = create_test_keyring();
        let signer = testing::ecdsa::gen_signer();
        keyring.add_ecdsa(signer.clone()).unwrap();

        let signer = testing::ed25519::gen_signer();
        let wrong_public_key = signer.public_key();
        let msg = b"test message";
        assert!(keyring.sign(Some(&wrong_public_key), msg).is_err());
    }
    #[test]
    fn sign_failes_with_ed25519_wrong_pk() {
        let mut keyring = create_test_keyring();
        let signer = testing::ed25519::gen_signer();
        keyring.add_ed25519(signer.clone()).unwrap();
        let signer = testing::ed25519::gen_signer();
        let wrong_public_key = signer.public_key();
        let msg = b"test message";
        assert!(keyring.sign(Some(&wrong_public_key), msg).is_err());
    }

    #[test]
    fn load_config_successufully() {
        let _keyring = create_test_keyring();
        let registry = &mut validator::Registry::default();

        let config = ProviderConfig::default();

        let result = load_config(registry, &config);

        assert!(result.is_ok());
    }
}
