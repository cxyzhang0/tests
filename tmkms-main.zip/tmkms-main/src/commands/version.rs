//! Provide the version

use std::{option_env, process};

use abscissa_core::Command;
use clap::Parser;

use crate::prelude::*;

/// The `version` command
#[derive(Command, Debug, Default, Parser)]
pub struct VersionCommand {}

impl Runnable for VersionCommand {
    /// Run the KMS
    fn run(&self) {
        println!("{}", option_env!("CARGO_PKG_VERSION").unwrap_or("unknown"));
        process::exit(0);
    }
}

// tests hung
/*
#[cfg(test)]
mod tests {
    use super::*;
    use std::process;

    #[test]
    fn version_command_displays_version() {
        let cmd = VersionCommand {};
        let result = std::panic::catch_unwind(|| {
            cmd.run();
        });
        assert!(result.is_ok());
    }

    #[test]
    fn version_command_exits_with_code_0() {
        let cmd = VersionCommand {};
        let result = std::panic::catch_unwind(|| {
            cmd.run();
        });
        assert!(result.is_ok());
    }
}
*/
