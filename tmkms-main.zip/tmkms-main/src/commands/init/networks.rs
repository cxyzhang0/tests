//! Tendermint KMS configuration file networks

use std::{
    fmt::{self, Display},
    process,
};

use crate::prelude::*;

/// Tendermint networks we have config networks for
#[derive(Copy, Clone, Debug, Eq, PartialEq)]
pub enum Network {
    /// Terra `columbus` chain
    Columbus,

    /// Cosmos `cosmoshub` chain
    CosmosHub,

    /// Iris `irishub` chain
    IrisHub,

    /// Sentinel `sentinelhub` chain
    SentinelHub,

    /// Osmosis `osmosis` chain
    Osmosis,

    /// Persistence `core` chain
    Persistence,
}

impl Display for Network {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(match self {
            Network::Columbus => "columbus",
            Network::CosmosHub => "cosmoshub",
            Network::IrisHub => "irishub",
            Network::SentinelHub => "sentinelhub",
            Network::Osmosis => "osmosis",
            Network::Persistence => "core",
        })
    }
}

impl Network {
    /// Get a slice containing all known networks
    pub fn all() -> &'static [Network] {
        &[
            Network::Columbus,
            Network::CosmosHub,
            Network::IrisHub,
            Network::SentinelHub,
            Network::Osmosis,
            Network::Persistence,
        ]
    }

    /// Parse a network name from the chain ID prefix
    pub fn parse(s: &str) -> Self {
        match s {
            "columbus" => Network::Columbus,
            "cosmoshub" => Network::CosmosHub,
            "irishub" => Network::IrisHub,
            "sentinelhub" => Network::SentinelHub,
            "osmosis" => Network::Osmosis,
            "core" => Network::Persistence,
            other => {
                status_err!("unknown Tendermint network: `{}`", other);
                eprintln!("\nRegistered networks:");

                for network in Self::all() {
                    eprintln!("- {network}");
                }

                process::exit(1);
            }
        }
    }

    /// Get the current production chain ID for this network
    pub fn chain_id(&self) -> &str {
        match self {
            Network::Columbus => "columbus-3",
            Network::CosmosHub => "cosmoshub-3",
            Network::IrisHub => "irishub",
            Network::SentinelHub => "sentinelhub-2",
            Network::Osmosis => "osmosis-1",
            Network::Persistence => "core-1",
        }
    }

    /// Get the schema file for this network
    pub fn schema_file(&self) -> &str {
        match self {
            Network::Columbus => "terra.toml",
            Network::CosmosHub => "cosmos-sdk.toml",
            Network::IrisHub => "iris.toml",
            Network::SentinelHub => "sentinelhub.toml",
            Network::Osmosis => "osmosis.toml",
            Network::Persistence => "persistence.toml",
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn network_display_for_columbus() {
        assert_eq!(Network::Columbus.to_string(), "columbus");
    }

    #[test]
    fn network_display_for_cosmoshub() {
        assert_eq!(Network::CosmosHub.to_string(), "cosmoshub");
    }

    #[test]
    fn network_display_for_irishub() {
        assert_eq!(Network::IrisHub.to_string(), "irishub");
    }

    #[test]
    fn network_display_for_sentinelhub() {
        assert_eq!(Network::SentinelHub.to_string(), "sentinelhub");
    }

    #[test]
    fn network_display_for_osmosis() {
        assert_eq!(Network::Osmosis.to_string(), "osmosis");
    }

    #[test]
    fn network_display_for_persistence() {
        assert_eq!(Network::Persistence.to_string(), "core");
    }

    #[test]
    fn parse_valid_network_name() {
        assert_eq!(Network::parse("columbus"), Network::Columbus);
        assert_eq!(Network::parse("cosmoshub"), Network::CosmosHub);
        assert_eq!(Network::parse("irishub"), Network::IrisHub);
        assert_eq!(Network::parse("sentinelhub"), Network::SentinelHub);
        assert_eq!(Network::parse("osmosis"), Network::Osmosis);
        assert_eq!(Network::parse("core"), Network::Persistence);
    }
    /*
        #[test]
        #[should_panic(expected = "unknown Tendermint network")]
        fn parse_invalid_network_name() {
            Network::parse("unknown");
        }
    */
    #[test]
    fn chain_id_for_columbus() {
        assert_eq!(Network::Columbus.chain_id(), "columbus-3");
    }

    #[test]
    fn chain_id_for_cosmoshub() {
        assert_eq!(Network::CosmosHub.chain_id(), "cosmoshub-3");
    }

    #[test]
    fn chain_id_for_irishub() {
        assert_eq!(Network::IrisHub.chain_id(), "irishub");
    }

    #[test]
    fn chain_id_for_sentinelhub() {
        assert_eq!(Network::SentinelHub.chain_id(), "sentinelhub-2");
    }

    #[test]
    fn chain_id_for_osmosis() {
        assert_eq!(Network::Osmosis.chain_id(), "osmosis-1");
    }

    #[test]
    fn chain_id_for_persistence() {
        assert_eq!(Network::Persistence.chain_id(), "core-1");
    }

    #[test]
    fn schema_file_for_columbus() {
        assert_eq!(Network::Columbus.schema_file(), "terra.toml");
    }

    #[test]
    fn schema_file_for_cosmoshub() {
        assert_eq!(Network::CosmosHub.schema_file(), "cosmos-sdk.toml");
    }

    #[test]
    fn schema_file_for_irishub() {
        assert_eq!(Network::IrisHub.schema_file(), "iris.toml");
    }

    #[test]
    fn schema_file_for_sentinelhub() {
        assert_eq!(Network::SentinelHub.schema_file(), "sentinelhub.toml");
    }

    #[test]
    fn schema_file_for_osmosis() {
        assert_eq!(Network::Osmosis.schema_file(), "osmosis.toml");
    }

    #[test]
    fn schema_file_for_persistence() {
        assert_eq!(Network::Persistence.schema_file(), "persistence.toml");
    }
}
