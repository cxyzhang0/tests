use std::path::PathBuf;

use clap::Subcommand;

use crate::commands::p11hsm::keys::{
    generate::GenerateCommand, pubkey::PubkeyCommand, sign_verify::SignVerifyCommand,
};
use crate::prelude::{Command, Runnable};

mod generate;
mod pubkey;
mod sign_verify;

/// The `p11hsm keys` subcommand
#[derive(Command, Debug, Subcommand, Runnable)]
pub enum KeysCommand {
    /// generate an ed25519 keypair
    Generate(GenerateCommand),

    /// get the ed25519 public key
    Pubkey(PubkeyCommand),

    /// sign a message and verify the signature
    SignVerify(SignVerifyCommand),
}

impl KeysCommand {
    pub(crate) fn config_path(&self) -> Option<&PathBuf> {
        match self {
            KeysCommand::Generate(generate) => generate.config.as_ref(),
            KeysCommand::Pubkey(pubkey) => pubkey.config.as_ref(),
            KeysCommand::SignVerify(sign_verify) => sign_verify.config.as_ref(),
        }
    }
}
