//! p11hsm Diagnosis utility - get pkcs11 context

use std::path::PathBuf;

use abscissa_core::{status_err, Command, Runnable};
use clap::Parser;

use crate::commands::p11hsm::config;
use crate::p11hsm::{display_env_vars, make_sdk_context_without_slot};
use crate::prelude::info;

/// The `p11hsm diag p11context` subcommand
#[derive(Command, Debug, Default, Parser)]
pub struct P11contextCommand {
    /// path to tmkms.toml. optional. default to that defined by env var TMKMS_CONFIG_FILE or ./tmkms.toml
    #[clap(short = 'c', long = "config")]
    pub config: Option<PathBuf>,

    /// provider identifier. optional. default to the first provider
    #[clap(short = 'i', long = "id")]
    pub id: Option<String>,
}

impl Runnable for P11contextCommand {
    /// Get PKCS11 Context.
    fn run(&self) {
        let started = std::time::Instant::now();

        let config = config(&self.id);
        // set_env_vars(&config);

        display_env_vars(&config);

        let _ = make_sdk_context_without_slot(&config).unwrap_or_else(|e| {
            status_err!("couldn't get pkcs11 context: {}", e);
            std::process::exit(1);
        });
        info!("got pkcs11 context ({} ms)", started.elapsed().as_millis())
    }
}
