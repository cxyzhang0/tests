//! p11hsm Diagnosis utility - get slot info

use std::path::PathBuf;

use abscissa_core::{status_err, Runnable};
use clap::Parser;

use crate::commands::p11hsm::config;
use crate::p11hsm::{display_env_vars, make_sdk_context_without_slot};
use crate::prelude::{info, Command};

/// The `p11hsm diag slotinfo` subcommand
#[derive(Command, Debug, Default, Parser)]
pub struct SlotinfoCommand {
    /// path to tmkms.toml. optional. default to that defined by env var TMKMS_CONFIG_FILE or ./tmkms.toml
    #[clap(short = 'c', long = "config")]
    pub config: Option<PathBuf>,

    /// provider identifier. optional. default to the first provider
    #[clap(short = 'i', long = "id")]
    pub id: Option<String>,
}

impl Runnable for SlotinfoCommand {
    /// Get the slot info.
    fn run(&self) {
        let started = std::time::Instant::now();
        let config = config(&self.id);

        display_env_vars(&config);

        let ctx = make_sdk_context_without_slot(&config).unwrap_or_else(|e| {
            status_err!("couldn't get pkcs11 context: {}", e);
            std::process::exit(1);
        });
        info!("got pkcs11 context ({} ms)", started.elapsed().as_millis());

        // get slot info for each hsm
        for hsm in config.hsms {
            let slot = ctx.find_slot_by_label(&hsm.token_label).unwrap_or_else(|e| {
                status_err!("couldn't get slot: {}", e);
                std::process::exit(1);
            });

            info!(
                "got slot: {:?} for {} ({} ms)",
                slot,
                hsm.token_label,
                started.elapsed().as_millis()
            )
        }
    }
}
