//! p11hsm Diagnosis utility - get count of all slots

use std::path::PathBuf;

use abscissa_core::{status_err, Command, Runnable};
use clap::Parser;

use crate::commands::p11hsm::config;
use crate::p11hsm::{display_env_vars, make_sdk_context_without_slot};
use crate::prelude::info;

/// The `p11hsm diag slotcount` subcommand.
#[derive(Command, Debug, Default, Parser)]
pub struct SlotcountCommand {
    /// path to tmkms.toml. optional. default to that defined by env var TMKMS_CONFIG_FILE or ./tmkms.toml
    #[clap(short = 'c', long = "config")]
    pub config: Option<PathBuf>,

    /// provider identifier. optional. default to the first provider
    #[clap(short = 'i', long = "id")]
    pub id: Option<String>,
}

impl Runnable for SlotcountCommand {
    /// Get count of all slots.
    fn run(&self) {
        let started = std::time::Instant::now();
        let config = config(&self.id);

        display_env_vars(&config);

        let ctx = make_sdk_context_without_slot(&config).unwrap_or_else(|e| {
            status_err!("couldn't get pkcs11 context: {}", e);
            std::process::exit(1);
        });
        info!("got pkcs11 context ({} ms)", started.elapsed().as_millis());

        let slots = ctx.p11().get_all_slots().unwrap_or_else(|e| {
            status_err!("couldn't get slots: {}", e);
            std::process::exit(1);
        });

        info!(
            "slot count: {} ({} ms)",
            slots.len(),
            started.elapsed().as_millis()
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::PathBuf;

    #[test]
    fn slotcount_command_with_valid_config_and_id() {
        let cmd = SlotcountCommand {
            config: Some(PathBuf::from("/path/to/valid_config.toml")),
            id: Some("valid_id".to_string()),
        };
        let result = std::panic::catch_unwind(|| {
            cmd.run();
        });
        assert!(result.is_err());
    }

    #[test]
    fn slotcount_command_with_valid_config_and_no_id() {
        let cmd = SlotcountCommand {
            config: Some(PathBuf::from("/path/to/valid_config.toml")),
            id: None,
        };
        let result = std::panic::catch_unwind(|| {
            cmd.run();
        });
        assert!(result.is_err());
    }

    #[test]
    fn slotcount_command_with_no_config_and_valid_id() {
        let cmd = SlotcountCommand {
            config: None,
            id: Some("valid_id".to_string()),
        };
        let result = std::panic::catch_unwind(|| {
            cmd.run();
        });
        assert!(result.is_err());
    }

    #[test]
    fn slotcount_command_with_no_config_and_no_id() {
        let cmd = SlotcountCommand {
            config: None,
            id: None,
        };
        let result = std::panic::catch_unwind(|| {
            cmd.run();
        });
        assert!(result.is_err());
    }

    #[test]
    fn slotcount_command_with_invalid_config() {
        let cmd = SlotcountCommand {
            config: Some(PathBuf::from("/path/to/invalid_config.toml")),
            id: Some("valid_id".to_string()),
        };
        let result = std::panic::catch_unwind(|| {
            cmd.run();
        });
        assert!(result.is_err());
    }

    #[test]
    fn slotcount_command_with_invalid_id() {
        let cmd = SlotcountCommand {
            config: Some(PathBuf::from("/path/to/valid_config.toml")),
            id: Some("invalid_id".to_string()),
        };
        let result = std::panic::catch_unwind(|| {
            cmd.run();
        });
        assert!(result.is_err());
    }
}
