//! p11hsm Diagnosis utility - get sdk via login

use std::path::PathBuf;

use abscissa_core::{status_err, Runnable};
use clap::Parser;

use crate::commands::p11hsm::config;
use crate::p11hsm::{display_env_vars, make_sdk_context_without_slot, make_pkcs11_sdk};
use crate::prelude::{info, Command};

/// The `p11hsm diag login` subcommand
#[derive(Command, Debug, Default, Parser)]
pub struct LoginCommand {
    /// path to tmkms.toml. optional. default to that defined by env var TMKMS_CONFIG_FILE or ./tmkms.toml
    #[clap(short = 'c', long = "config")]
    pub config: Option<PathBuf>,

    /// provider identifier. optional. default to the first provider
    #[clap(short = 'i', long = "id")]
    pub id: Option<String>,
}

impl Runnable for LoginCommand {
    /// Get pkcs11 sdk via login.
    fn run(&self) {
        let started = std::time::Instant::now();
        let config = config(&self.id);

        display_env_vars(&config);

        let mut ctx = make_sdk_context_without_slot(&config).unwrap_or_else(|e| {
            status_err!("couldn't make pkcs11: {}", e);
            std::process::exit(1);
        });
        info!("got pkcs11 context ({} ms)", started.elapsed().as_millis());

        info!(
            "there are {} HSMs for provider: {} ({} ms)",
            config.hsms.len(),
            config.id,
            started.elapsed().as_millis()
        );
        // test login to each HSM
        for hsm in config.hsms {
            info!("logging in: {}", hsm.token_label);
            let sdk = make_pkcs11_sdk(&mut ctx, &hsm).unwrap_or_else(|e| {
                status_err!("couldn't make pkcs11 sdk: {}", e);
                std::process::exit(1);
            });
            info!(
                "logged in {} and got sdk ({} ms)",
                hsm.token_label,
                started.elapsed().as_millis()
            );
            sdk.close().unwrap_or_else(|e| {
                status_err!("couldn't close pkcs11 sdk.session: {}", e);
                std::process::exit(1);
            });
            info!(
                "closed pkcs11 sdk.session: ({} ms)",
                started.elapsed().as_millis()
            );
        }
    }
}
