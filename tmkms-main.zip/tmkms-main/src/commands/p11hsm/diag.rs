use std::path::PathBuf;

use abscissa_core::{Command, Runnable};
use clap::Subcommand;

use crate::commands::p11hsm::diag::login::LoginCommand;
use crate::commands::p11hsm::diag::p11context::P11contextCommand;
use crate::commands::p11hsm::diag::slotcount::SlotcountCommand;
use crate::commands::p11hsm::diag::slotinfo::SlotinfoCommand;

mod login;
mod p11context;
mod slotcount;
mod slotinfo;

/// The `p11hsm diag` (diagnosis) subcommand
#[derive(Command, Debug, Subcommand, Runnable)]
pub enum DiagCommand {
    /// Get Pkcs11 context
    P11context(P11contextCommand),

    /// Slot count
    Slotcount(SlotcountCommand),

    /// Slot info
    Slotinfo(SlotinfoCommand),

    /// Login
    Login(LoginCommand),
}

impl DiagCommand {
    pub(crate) fn config_path(&self) -> Option<&PathBuf> {
        match self {
            DiagCommand::P11context(p11context) => p11context.config.as_ref(),
            DiagCommand::Slotcount(slotcount) => slotcount.config.as_ref(),
            DiagCommand::Slotinfo(slotinfo) => slotinfo.config.as_ref(),
            DiagCommand::Login(login) => login.config.as_ref(),
        }
    }
}
