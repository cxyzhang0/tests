//! p11hsm key management - sign a message

use std::path::PathBuf;

use abscissa_core::{status_err, Runnable};
use clap::Parser;
use pkcs11::{init_sdk, CryptographAlgorithm, KeyLabel, SDK};
use subtle_encoding::hex;

use crate::commands::p11hsm::config;
use crate::p11hsm::{display_env_vars, get_hsm_id};
use crate::prelude::{info, Command};

/// The `p11hsm keys sign_verify` subcommand
#[derive(Command, Debug, Default, Parser)]
pub struct SignVerifyCommand {
    /// path to tmkms.toml. optional. default to that defined by env var TMKMS_CONFIG_FILE or ./tmkms.toml
    #[clap(short = 'c', long = "config")]
    pub config: Option<PathBuf>,

    /// provider identifier. optional. default to the first provider
    #[clap(short = 'i', long = "id")]
    pub id: Option<String>,

    /// token_label to identify the HSM. optional. default to the first HSM.
    #[clap(short = 't', long = "token-label")]
    pub token_label: Option<String>,

    /// key_label
    #[clap(short = 'l', long = "key-label")]
    pub key_label: String,

    /// message to sign. optional. default = "sign me"
    #[clap(short = 'm', long = "message")]
    pub message: Option<String>,
}

impl Runnable for SignVerifyCommand {
    /// Generate a new ed25519 key.
    fn run(&self) {
        let started = std::time::Instant::now();
        let config = config(&self.id);

        display_env_vars(&config);

        // the following is replace by init_sdk()
        /*
        let mut ctx = make_sdk_context_without_slot(&config).unwrap_or_else(|e| {
            status_err!("couldn't get pkcs11 context: {}", e);
            std::process::exit(1);
        });
        info!("got pkcs11 context ({} ms)", started.elapsed().as_millis());

        let sdk = get_sdk(&config, &mut ctx, &self.token_label);
        info!("got sdk ({} ms)", started.elapsed().as_millis());
        */

        let hsm_id = get_hsm_id(&config, &self.token_label);

        let ctx = init_sdk(
            &config.env_cfg,
            &config.cfg,
            config.env_module.as_deref(),
            config.module.as_deref(),
            config.hsms[hsm_id].token_label.as_str(),
            &config.hsms[hsm_id].user_pin.as_str(),
        ).unwrap_or_else(|e| {
            status_err!("couldn't init sdk: {}", e);
            std::process::exit(1);
        });

        let sdk = SDK::from_context(&ctx).unwrap_or_else(|e| {
            status_err!("couldn't make sdk from context: {}", e);
            std::process::exit(1);
        });

        info!("got sdk ({} ms)", started.elapsed().as_millis());
        let key_label = KeyLabel::from_short(&self.key_label, CryptographAlgorithm::Ed25519)
            .unwrap_or_else(|e| {
                status_err!("couldn't make key label: {}", e);
                std::process::exit(1);
            });

        let default_msg = "sign me".to_string();
        let msg = self.message.as_ref().unwrap_or(&default_msg);
        let data = msg.as_bytes();

        let sig = sdk.sign_eddsa(&key_label, data).unwrap_or_else(|e| {
            status_err!("couldn't sign message: {}", e);
            std::process::exit(1);
        });

        info!(
            "signed - algo: {:?}; key_label: {}; msg: {}; sig: {} ({} ms)",
            key_label.algorithm,
            key_label.short_label(),
            msg,
            String::from_utf8(hex::encode(sig.to_bytes())).unwrap(),
            started.elapsed().as_millis()
        );

        sdk.verify_sig_ed_outside_hsm(&key_label, data, &sig)
            .unwrap_or_else(|e| {
                status_err!("couldn't verify signature: {}", e);
                std::process::exit(1);
            });

        info!("sig verified ({} ms)", started.elapsed().as_millis())
    }
}
