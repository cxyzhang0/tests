use std::path::PathBuf;

use abscissa_core::{status_err, Runnable};
use clap::Parser;
use cosmrs::crypto::PublicKey as CosmrsPublicKey;
use cosmrs::proto::cosmos::crypto::ed25519::PubKey as CosmosEdPubKey;
use pkcs11::{init_sdk, CryptographAlgorithm, KeyLabel, SDK};
use subtle_encoding::hex;

use crate::commands::p11hsm::config;
use crate::p11hsm::{display_env_vars, get_hsm_id};
use crate::prelude::{info, Command};

/// The `p11hsm keys pubkey` subcommand
#[derive(Command, Debug, Default, Parser)]
pub struct PubkeyCommand {
    /// path to tmkms.toml. optional. default to that defined by env var TMKMS_CONFIG_FILE or ./tmkms.toml
    #[clap(short = 'c', long = "config")]
    pub config: Option<PathBuf>,

    /// provider identifier. optional. default to the first provider
    #[clap(short = 'i', long = "id")]
    pub id: Option<String>,

    /// token_label to identify the HSM. optional. default to the first HSM.
    #[clap(short = 't', long = "token-label")]
    pub token_label: Option<String>,

    /// key_label to identify the public key
    #[clap(short = 'l', long = "key-label")]
    pub key_label: String,
}

impl Runnable for PubkeyCommand {
    /// Generate a new ed25519 key.
    fn run(&self) {
        let started = std::time::Instant::now();
        let config = config(&self.id);

        display_env_vars(&config);

        // the following is replace by init_sdk()
        /*
        let mut ctx = make_sdk_context_without_slot(&config).unwrap_or_else(|e| {
            status_err!("couldn't get pkcs11 context: {}", e);
            std::process::exit(1);
        });
        info!("got pkcs11 context ({} ms)", started.elapsed().as_millis());

        let sdk = get_sdk(&config, &mut ctx, &self.token_label);

        info!("got sdk ({} ms)", started.elapsed().as_millis());
        */

        let hsm_id = get_hsm_id(&config, &self.token_label);

        let ctx = init_sdk(
            &config.env_cfg,
            &config.cfg,
            config.env_module.as_deref(),
            config.module.as_deref(),
            config.hsms[hsm_id].token_label.as_str(),
            &config.hsms[hsm_id].user_pin.as_str(),
        ).unwrap_or_else(|e| {
            status_err!("couldn't init sdk: {}", e);
            std::process::exit(1);
        });

        let sdk = SDK::from_context(&ctx).unwrap_or_else(|e| {
            status_err!("couldn't make sdk from context: {}", e);
            std::process::exit(1);
        });

        info!("got sdk ({} ms)", started.elapsed().as_millis());
        let key_label = KeyLabel::from_short(&self.key_label, CryptographAlgorithm::Ed25519)
            .unwrap_or_else(|e| {
                status_err!("couldn't make key label: {}", e);
                std::process::exit(1);
            });

        let public_key = sdk.get_ed_public_key(&key_label).unwrap_or_else(|e| {
            status_err!("couldn't get public key: {}", e);
            std::process::exit(1);
        });

        let pub_key = CosmosEdPubKey {
            key: public_key.as_bytes().to_vec(),
        };
        let cosmos_public_key = CosmrsPublicKey::try_from(pub_key.clone()).unwrap();

        info!(
            "algo: {:?}; key_label: {}; pub key hex: {}, pub key json: {} ({} ms)",
            key_label.algorithm,
            key_label.short_label(),
            String::from_utf8(hex::encode(public_key.as_bytes())).unwrap(),
            cosmos_public_key.to_json(),
            started.elapsed().as_millis()
        )
    }
}
