use std::path::PathBuf;
use std::process;

use abscissa_core::{status_err, Application, Command, Runnable};
use clap::Subcommand;

use crate::application::APP;
#[cfg(feature = "p11hsm")]
use crate::commands::p11hsm::diag::DiagCommand;
#[cfg(feature = "p11hsm")]
use crate::commands::p11hsm::keys::KeysCommand;
#[cfg(feature = "p11hsm")]
use crate::config::provider::p11hsm::P11hsmConfig;
use crate::prelude::info;

#[cfg(feature = "p11hsm")]
mod diag;
#[cfg(feature = "p11hsm")]
mod keys;

/// The `p11hsm` subcommand
#[cfg(feature = "p11hsm")]
#[derive(Command, Debug, Runnable, Subcommand)]
pub enum P11hsmCommand {
    /// diagnosis subcommands
    #[clap(subcommand)]
    Diag(DiagCommand),

    /// key management subcommands
    #[clap(subcommand)]
    Keys(KeysCommand),
}

#[cfg(feature = "p11hsm")]
impl P11hsmCommand {
    pub(super) fn config_path(&self) -> Option<&PathBuf> {
        match self {
            P11hsmCommand::Diag(diag) => diag.config_path(),
            P11hsmCommand::Keys(keys) => keys.config_path(),
        }
    }
}

#[cfg(feature = "p11hsm")]

pub fn config(id: &Option<String>) -> P11hsmConfig {
    let kms_config = APP.config();
    let p11hsm_configs = &kms_config.providers.p11hsm;

    if p11hsm_configs.is_empty() {
        status_err!("No p11hsm configuration found");
        process::exit(1);
    }

    info!("found {} p11hsm providers", p11hsm_configs.len());

    if let Some(id) = id {
        return p11hsm_configs
            .iter()
            .find(|c| c.id == *id)
            .unwrap_or_else(|| {
                status_err!("no p11hsm provider found for id: {}", id);
                process::exit(1);
            })
            .clone();
        // if let Some(p11) = p11hsm_configs.iter().find(|c| c.id == id) {
        //     return p11.clone()
        // }
    }

    info!(
        "use the first p11hsm provider - {}: {}={}",
        p11hsm_configs[0].id, p11hsm_configs[0].env_cfg, p11hsm_configs[0].cfg
    );

    // Note: if there are multiple p11hsm configurations, we will use the first one
    p11hsm_configs[0].clone()
}
