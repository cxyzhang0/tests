use crate::keyring::{ecdsa, SigningProvider};
use cosmrs::bip32::PrivateKey;
use k256::ecdsa as K256Ecdsa;
use rand_core::OsRng;
use tendermint::TendermintKey;

/// generate a signer
pub fn gen_signer() -> ecdsa::Signer {
    let signing_key = gen_key();
    let verifying_key = signing_key.verifying_key();
    ecdsa::Signer::new(
        SigningProvider::P11hsm,
        TendermintKey::AccountKey((*verifying_key).into()),
        Box::new(signing_key.clone()),
    )
}

/// generate a cross signer: ConsensusKey
/// This is for negative testing
pub fn gen_cross_signer() -> ecdsa::Signer {
    let signing_key = gen_key();
    let verifying_key = signing_key.verifying_key();
    ecdsa::Signer::new(
        SigningProvider::P11hsm,
        #[allow(clippy::clone_on_copy)]
        TendermintKey::ConsensusKey(verifying_key.clone().into()),
        Box::new(signing_key.clone()),
    )
}

/// get verifying key from signer
pub fn get_vk_from_signer(signer: &ecdsa::Signer) -> K256Ecdsa::VerifyingKey {
    #[allow(clippy::collapsible_match)]
    if let TendermintKey::AccountKey(key) = signer.public_key() {
        if let tendermint::PublicKey::Secp256k1(pk) = key {
            pk
        } else {
            panic!("unexpected public key type");
        }
    } else {
        panic!("unexpected public key type");
    }
}

/// generate a (random) secp256k1 key
pub fn gen_key() -> K256Ecdsa::SigningKey {
    K256Ecdsa::SigningKey::random(&mut OsRng)
}

/// generate secp256k1 tendermint private signing key
pub fn gen_k256_tendermint_public_key() -> TendermintKey {
    TendermintKey::AccountKey(gen_key().public_key().into())
}
