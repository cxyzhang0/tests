use crate::config::{ProtocolVersion, ValidatorConfig};
use crate::keyring;
use crate::validator::ChainId;
use std::path::PathBuf;
use tendermint::chain;
use tendermint_config::net;

/// Create a test `ValidatorConfig` for use in tests
pub fn create_test_validator_config() -> ValidatorConfig {
    ValidatorConfig {
        id: chain::Id::try_from("tf").unwrap(),
        addr: net::Address::Tcp {
            peer_id: None,
            host: "127.0.0.1".to_string(),
            port: 26656,
        },
        chain_id: ChainId::try_from("test_chain").unwrap(),
        reconnect: true,
        timeout: Some(30),
        secret_key: Some(PathBuf::from("./tests/support/secret_connection.key")),
        key_format: keyring::Format::Bech32 {
            account_key_prefix: "wf".to_string(),
            consensus_key_prefix: "wf".to_string(),
        },
        sign_extensions: false,
        state_file: Some(PathBuf::from("./tests/support/consensus-state.json")),
        max_height: Some(tendermint::block::Height::try_from(100u64).unwrap()),
        protocol_version: ProtocolVersion::V0_34,
        state_hook: None,
    }
}
