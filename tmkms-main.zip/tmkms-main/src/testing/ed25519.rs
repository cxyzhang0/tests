use crate::keyring::{ed25519, SigningProvider};
use ed25519_consensus;
use rand_core::{OsRng, RngCore};
use tendermint::{private_key, TendermintKey};

/// generate a singer
pub fn gen_signer() -> ed25519::Signer {
    let signing_key = gen_key();
    let verifying_key = signing_key.verifying_key();
    ed25519::Signer::new(
        SigningProvider::P11hsm,
        TendermintKey::ConsensusKey(verifying_key.clone().into()),
        Box::new(signing_key),
    )
}

/// generate a cross singer: AccountKey
/// /// This is for negative testing
pub fn gen_cross_signer() -> ed25519::Signer {
    let signing_key = gen_key();
    let verifying_key = signing_key.verifying_key();
    ed25519::Signer::new(
        SigningProvider::P11hsm,
        TendermintKey::AccountKey(verifying_key.clone().into()),
        Box::new(signing_key),
    )
}

/// get verifying key from signer
pub fn get_vk_from_signer(signer: &ed25519::Signer) -> ed25519::VerifyingKey {
    #[allow(clippy::collapsible_match)]
    if let TendermintKey::ConsensusKey(key) = signer.public_key() {
        if let tendermint::PublicKey::Ed25519(pk) = key {
            ed25519::VerifyingKey::try_from(pk.as_bytes()).unwrap()
        } else {
            panic!("unexpected public key type");
        }
    } else {
        panic!("unexpected public key type");
    }
}

/// generate a (random) ed25519 key
pub fn gen_key() -> ed25519::SigningKey {
    let consensus_key = gen_consensus_key();
    ed25519::SigningKey::from(consensus_key)
}

/// generate a (random) ed25519 key
pub fn gen_consensus_key() -> ed25519_consensus::SigningKey {
    ed25519_consensus::SigningKey::from(gen_random_bytes())
}

/// generate tendermint private signing key
pub fn gen_tendermint_private_key() -> private_key::Ed25519 {
    private_key::Ed25519::try_from(&gen_random_bytes()[..]).unwrap()
}

/// generate ed25519 tendermint private signing key
pub fn gen_ed25519_tendermint_public_key() -> TendermintKey {
    TendermintKey::ConsensusKey(
        private_key::Ed25519::try_from(&gen_random_bytes()[..])
            .unwrap()
            .verification_key()
            .into(),
    )
}

/// generate a random byte array of length ed25519::SigningKey::BYTE_SIZE
pub fn gen_random_bytes() -> [u8; ed25519::SigningKey::BYTE_SIZE] {
    let mut bytes = [0u8; ed25519::SigningKey::BYTE_SIZE];
    OsRng.fill_bytes(&mut bytes);
    bytes
}
