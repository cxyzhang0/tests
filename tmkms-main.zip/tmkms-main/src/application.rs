//! Abscissa `Application` for the KMS

use abscissa_core::{
    application::{self, AppCell},
    config::{self, CfgCell},
    terminal::{component::Terminal},
    trace, Application, Component, FrameworkError, StandardPaths,
};
use tracing_subscriber::{fmt, EnvFilter};
use crate::{commands::KmsCommand, config::KmsConfig};

/// Application state
pub static APP: AppCell<KmsApplication> = AppCell::new();

/// The `tmkms` application
#[derive(Debug, Default)]
pub struct KmsApplication {
    /// Application configuration.
    config: CfgCell<KmsConfig>,

    /// Application state.
    state: application::State<Self>,
}

impl Application for KmsApplication {
    /// Entrypoint command for this application.
    type Cmd = KmsCommand;

    /// Application configuration.
    type Cfg = KmsConfig;

    /// Paths to resources within the application.
    type Paths = StandardPaths;

    /// Accessor for application configuration.
    fn config(&self) -> config::Reader<KmsConfig> {
        self.config.read()
    }

    /// Borrow the application state immutably.
    fn state(&self) -> &application::State<Self> {
        &self.state
    }

    /// Register all components used by this application.
    ///
    /// If you would like to add additional components to your application
    /// beyond the default ones provided by the framework, this is the place
    /// to do so.
    ///
    /// Since we override `framework_components` to omit the default Tracing component,
    /// we also set up our own JSON or text  tracing subscriber here based on command-line options.
    fn register_components(&mut self, command: &Self::Cmd) -> Result<(), FrameworkError> {
        // Filter out Abscissa's default Tracing component so we can use our own
        let components = self.framework_components(command)?;

        // Initialize JSON tracing subscriber
        let filter = if command.verbose() {
            EnvFilter::new("debug")
        } else {
            EnvFilter::new("info")
        };

        if command.json() {
            let subscriber = fmt::Subscriber::builder()
                .json()
                .with_env_filter(filter)
                .with_target(true)
                .flatten_event(true)
                .finish();

            tracing::subscriber::set_global_default(subscriber)
                .expect("Failed to set JSON tracing subscriber");
        } else {
            let subscriber = fmt::Subscriber::builder()
                .with_env_filter(filter)
                .with_target(true)
                .finish();

            tracing::subscriber::set_global_default(subscriber)
                .expect("Failed to set text tracing subscriber");
        };

        // let components = self.framework_components(command)?;
        let mut component_registry = self.state.components_mut();
        component_registry.register(components)
    }

    /// Post-configuration lifecycle callback.
    ///
    /// Called regardless of whether config is loaded to indicate this is the
    /// time in app lifecycle when configuration would be loaded if
    /// possible.
    fn after_config(&mut self, config: Self::Cfg) -> Result<(), FrameworkError> {
        let mut component_registry = self.state.components_mut();
        component_registry.after_config(&config)?;
        self.config.set_once(config);
        Ok(())
    }

    /// Override framework_components to keep Terminal but drop Tracing
    /// ref: abscissa_core-0.7.0/src/application.rs
    fn framework_components(
        &mut self,
        command: &Self::Cmd,
    ) -> Result<Vec<Box<dyn Component<Self>>>, FrameworkError> {
        let terminal = Terminal::new(self.term_colors(command));
        // Intentionally omit Tracing — we set up our own JSON subscriber below
        Ok(vec![Box::new(terminal)])
    }

    /// Get tracing configuration from command-line options
    fn tracing_config(&self, command: &KmsCommand) -> trace::Config {
        if command.verbose() {
            trace::Config::verbose()
        } else {
            trace::Config::default()
        }
    }
}
