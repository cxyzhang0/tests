# TMKMS with PKCS11 HSM backend
This repo is a private fork of https://github.com/iqlusioninc/tmkms. See the original [README](README.md).  
The main contribution is to add a new feature, `p11hsm`, to the original `tmkms` crate.  
See [README p11hsm](README.p11hsm.md) and [Developer](Developer.md) for more information.

## apply linting
```shell
# Optimize Imports for the whole workspace: right-click on the workspace root folder in RustRover IDE and select Optimize Imports.
# unfortunately, the above does not remove unused imports.

# check the whole workspace. it will show unused imports, among other things.
# manually remove unused imports.
cargo check --workspace --all-features  
cargo check --all-features  

# Reformat the whole workspace: right-click on the workspace root folder in RustRover IDE and select Reformat Code.
# Or run the following commands.
cargo fmt --all --check # it will display the proposed changes.
cargo fmt --all

# clippy the whole workspace; review recommendations and make appropriate changes.
cargo clippy --workspace --all-features

```

# Integration tests
> ./tests are integration tests. To avoid cargo test running them by default, annotate them with #[ignore].
> * cargo test --features=p11hsm -- --ignored # run only ignored tests
> * cargo test --features=p11hsm -- --include-ignored # run all, including ignored