# Description: Dockerfile for testing tmkms p11hsm in linux.
#   Test result: musl is not working because it cannot dynamically load libpkcs11.so
#   Test result: gnu is working because it can dynamically load libpkcs11.so
#FROM --platform=linux/amd64 ubuntu:20.04
FROM --platform=linux/amd64 rust:1.76

ENV FXPKCS11_CFG=/opt/futurex/fxpkcs11-linux-4.58-422d/fxpkcs11.cfg
ENV SOFTHSM2_CONF=/etc/softhsm2.conf

# docker build -f p11hsm.Dockerfile -t tmkms:p11hsm .
# docker create --name tmkms-p11hsm -i -v $(pwd):/tmkms -v $HOME/futurex:/opt/futurex -v /etc/softhsm2.conf:/etc/softhsm2.conf -v /var/lib/softhsm:/var/lib/softhsm -w /tmkms tmkms:p11hsm
# docker start tmkms-p11hsm
#
# docker exec -it tmkms-p11hsm ls -lsa ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release
# docker exec -it tmkms-p11hsm ls -lsa /lib64
# docker exec -it tmkms-p11hsm ls -lsa /lib/x86_64-linux-gnu
# docker exec -it tmkms-p11hsm ldd --version
# docker exec -it tmkms-p11hsm /lib/x86_64-linux-gnu/libc.so.6
# glibc download link: https://ftp.gnu.org/gnu/glibc, or https://ftp.gnu.org/gnu/libc/
# manual install glibc: https://stackoverflow.com/questions/32316707/rhel-6-how-to-install-glibc-2-14-or-glibc-2-15

# docker exec -it tmkms-p11hsm ls -lsa /opt/futurex/fxpkcs11-linux-4.58-422d

# docker exec -it tmkms-p11hsm /opt/futurex/fxpkcs11-linux-4.58-422d/configTest
# docker exec -it tmkms-p11hsm ls -lsa /usr/local/lib/softhsm
# docker exec -it tmkms-p11hsm ls -lsa /var/lib/softhsm
# docker exec -it tmkms-p11hsm ls -lsa /etc
# docker exec -it tmkms-p11hsm openssl engine -vvvv

# docker exec -it tmkms-p11hsm ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm diag --help

# musl not working: docker exec -it tmkms-p11hsm ./target-p11-val-cli-musl/x86_64-unknown-linux-musl/release/tmkms p11hsm diag p11context -c ./tmkms.docker.toml

# Note for the following: -i softhsm is not working: Pkcs11::new error: libloading error (libcrypto.so.1.1: cannot open shared object file: No such file or directory)
#  libsofthsm2-linux.so was from https://github.com/Pkcs11Interop/Pkcs11Interop.X509Store/blob/master/src/Pkcs11Interop.X509Store.Tests/SoftHsm2/linux/libsofthsm2.so.txt

# docker exec -it tmkms-p11hsm ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm diag p11context -h
# docker exec -it tmkms-p11hsm ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm diag p11context -c ./tmkms.docker.toml
# docker exec -it tmkms-p11hsm ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm diag p11context -i futurex -c ./tmkms.docker.toml

# docker exec -it tmkms-p11hsm ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm diag slotcount -h
# docker exec -it tmkms-p11hsm ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm diag slotcount -c ./tmkms.docker.toml
# docker exec -it tmkms-p11hsm ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm diag slotcount -i futurex -c ./tmkms.docker.toml

# docker exec -it tmkms-p11hsm ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm diag slotinfo -h
# docker exec -it tmkms-p11hsm ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm diag slotinfo -c ./tmkms.docker.toml
# docker exec -it tmkms-p11hsm ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm diag slotinfo -i futurex -c ./tmkms.docker.toml

# docker exec -it tmkms-p11hsm ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm diag login -h
# docker exec -it tmkms-p11hsm ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm diag login -c ./tmkms.docker.toml
# docker exec -it tmkms-p11hsm ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm diag login -i futurex -c ./tmkms.docker.toml

# docker exec -it tmkms-p11hsm ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm keys -h

# docker exec -it tmkms-p11hsm ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm keys pubkey -h
# docker exec -it tmkms-p11hsm ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm keys pubkey -l "Slot Token 0/tmkms/ed25519-1/1" -c ./tmkms.docker.toml
# docker exec -it tmkms-p11hsm ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm keys pubkey -i futurex -t "Slot Token 0" -l "Slot Token 0/tmkms/ed25519-1/1" -c ./tmkms.docker.toml

# docker exec -it tmkms-p11hsm ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm keys generate -h
# docker exec -it tmkms-p11hsm ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm keys generate -l "Slot Token 0/tmkms/ed25519-1/1" -c ./tmkms.docker.toml
# docker exec -it tmkms-p11hsm ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm keys generate -i futurex -t "Slot Token 0" -l "Slot Token 0/tmkms/ed25519-1/1" -c ./tmkms.docker.toml

# docker exec -it tmkms-p11hsm ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm keys sign-verify -h
# docker exec -it tmkms-p11hsm ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm keys sign-verify -l "Slot Token 0/tmkms/ed25519-1/1" -c ./tmkms.docker.toml
# docker exec -it tmkms-p11hsm ./target-p11-val-cli-gnu/x86_64-unknown-linux-gnu/release/tmkms p11hsm keys sign-verify -i futurex -t "Slot Token 0" -l "Slot Token 0/tmkms/ed25519-1/1" -m "hello, world" -c ./tmkms.docker.toml

# docker exec -it tmkms-p11hsm openssl pkcs12 -in /opt/futurex/fxpkcs11-linux-4.58-422d/ClientCertificate-linux.p12 -nokeys -info
# openssl pkcs12 -in ~/futurex/fxpkcs11-linux-4.58-422d/ClientCertificate-linux.p12 -nokeys -info
# openssl pkcs12 -in ~/futurex/fxpkcs11-mac-arm-4.58-422d/ClientCertificate.p12 -nokeys -info