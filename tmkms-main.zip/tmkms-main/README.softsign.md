# TMKMS with softsign

## Example of tmkms.toml using softsign providers
```toml
### Software-based Signer Configuration
[[providers.softsign]]
val_ids = ["val-1"]
key_type = "consensus"
path = "/Users/johnz/Project/rust/cosmos/tmkms/.tmkms-softsign-val/secrets/priv_validator_key_1"

[[providers.softsign]]
val_ids = ["val-2"]
key_type = "consensus"
path = "/Users/johnz/Project/rust/cosmos/tmkms/.tmkms-softsign-val/secrets/priv_validator_key_2"

[[providers.softsign]]
val_ids = ["val-3"]
key_type = "consensus"
path = "/Users/johnz/Project/rust/cosmos/tmkms/.tmkms-softsign-val/secrets/priv_validator_key_3"

[[providers.softsign]]
val_ids = ["val-4"]
key_type = "consensus"
path = "/Users/johnz/Project/rust/cosmos/tmkms/.tmkms-softsign-val/secrets/priv_validator_key_4"


## Validator Configuration
[[validator]]
id = "val-1"
chain_id = "networkchain-1"
addr = "tcp://localhost:1111"
secret_key = "/Users/johnz/Project/rust/cosmos/tmkms/.tmkms-softsign-val/secrets/kms-identity.key"
key_format = { type = "bech32", account_key_prefix = "wf", consensus_key_prefix = "wf" }
sign_extensions = false # Should vote extensions for this chain be signed? (default: false)
state_file = "/Users/johnz/Project/rust/cosmos/tmkms/.tmkms-softsign-val/state/val-1-consensus.json"
protocol_version = "v0.34"
reconnect = true

[[validator]]
id = "val-2"
chain_id = "networkchain-1"
addr = "tcp://localhost:1112"
secret_key = "/Users/johnz/Project/rust/cosmos/tmkms/.tmkms-softsign-val/secrets/kms-identity.key"
key_format = { type = "bech32", account_key_prefix = "wf", consensus_key_prefix = "wf" }
sign_extensions = false # Should vote extensions for this chain be signed? (default: false)
state_file = "/Users/johnz/Project/rust/cosmos/tmkms/.tmkms-softsign-val/state/val-2-consensus.json"
protocol_version = "v0.34"
reconnect = true

[[validator]]
id = "val-3"
chain_id = "networkchain-1"
addr = "tcp://localhost:1113"
secret_key = "/Users/johnz/Project/rust/cosmos/tmkms/.tmkms-softsign-val/secrets/kms-identity.key"
key_format = { type = "bech32", account_key_prefix = "wf", consensus_key_prefix = "wf" }
sign_extensions = false # Should vote extensions for this chain be signed? (default: false)
state_file = "/Users/johnz/Project/rust/cosmos/tmkms/.tmkms-softsign-val/state/val-3-consensus.json"
protocol_version = "v0.34"
reconnect = true

[[validator]]
id = "val-4"
chain_id = "networkchain-1"
addr = "tcp://localhost:1114"
secret_key = "/Users/johnz/Project/rust/cosmos/tmkms/.tmkms-softsign-val/secrets/kms-identity.key"
key_format = { type = "bech32", account_key_prefix = "wf", consensus_key_prefix = "wf" }
sign_extensions = false # Should vote extensions for this chain be signed? (default: false)
state_file = "/Users/johnz/Project/rust/cosmos/tmkms/.tmkms-softsign-val/state/val-4-consensus.json"
protocol_version = "v0.34"
reconnect = true
```

