# TMKMS with PKCS11 HSM backend
This repo is a private fork of https://github.com/iqlusioninc/tmkms. See the original [README](README.md).  
The main contribution is to add a new feature, `p11hsm`, to the original `tmkms` crate.  
See [README p11hsm](README.p11hsm.md) and [Developer](Developer.md) for more information.  
We need to be able to fetch future changes in the original repo via upstream.
## upstream
```bash
git remote add upstream https://github.com/iqlusioninc/tmkms.git
git remote set-url --push upstream DISABLE
git remote -v
# should show something like this:
origin  https://github.com/wfblockchain/tmkms.git (fetch)
origin  https://github.com/wfblockchain/tmkms.git (push)
upstream        https://github.com/iqlusioninc/tmkms.git (fetch)
upstream        DISABLE (push)

# We can pull changes from the original repo like this:
git fetch upstream
# TBD: git rebase upstream/main or git merge upstream/main
# resolve any conflicts
# Review the upsteam PRs and merge appropriately or manually update the code

# ref: https://gist.github.com/0xjac/85097472043b697ab57ba1b1c7530274
# ref: https://docs.github.com/en/repositories/creating-and-managing-repositories/duplicating-a-repository
# ref: https://git-scm.com/docs/git-clone#Documentation/git-clone.txt---mirror
```
## Major files that are affected for the p11hsm feature
- [Cargo.toml](Cargo.toml)
- [Cargo.lock](Cargo.lock)
- [lib.rs](src/lib.rs)
- [config_builder.rs](src/commands/init/config_builder.rs)
- [error.rs](src/error.rs)
- [config provider.rs](src/config/provider.rs)
- [config p11hsm.rs](src/config/provider/p11hsm.rs)
- [keyring.rs](src/keyring.rs)
- [keyring providers.rs](src/keyring/providers.rs)
- [keyring p11hsm.rs](src/keyring/providers/p11hsm.rs)
- [softsign.rs](src/keyring/providers/softsign.rs) # fix a bug
- [template p11hsm.toml](src/commands/init/templates/keyring/p11hsm.toml)
- [test pkcs11.rs](tests/pkcs11.rs)
- 

### Validator-centric data model
- This change affected almost all files. 
- After the data model change, only softsign and p11hsm features are supported.
- Other features could be supported if necessary but testing is difficult. 

## apply linting
```shell
# Optimize Imports for the whole workspace: right-click on the workspace root folder in RustRover IDE and select Optimize Imports.
# unfortunately, the above does not remove unused imports.

# check the whole workspace. it will show unused imports, among other things.
# manually remove unused imports.
cargo check --workspace --all-features  
cargo check --all-features  

# Reformat the whole workspace: right-click on the workspace root folder in RustRover IDE and select Reformat Code.
# Or run the following commands.
cargo fmt --all --check # it will display the proposed changes.
cargo fmt --all

# clippy the whole workspace; review recommendations and make appropriate changes.
cargo clippy --workspace --all-features
## pedantic is too much but the docs warning is useful
cargo clippy --workspace --all-features -- --warn clippy::pedantic 

# fix clippy recommendations: may need to export __CARGO_FIX_YOLO=1
cargo fix #--allow-dirty --allow-staged
cargo clippy --fix #--allow-dirty -- -Dwarnings  
```

## Build tmkms binary
```shell
# gex is a neat tool for visualizing validator
go install github.com/cosmos/gex@latest
gex -p port

rustup toolchain list
# currently default using 1.75
# use 1.69 rust to see if it works
rustup default 1.69
# no, requries 1.72 because clap_builder v4.4.18 requires rustc 1.70.0 or newer
rustup default 1.75
```

### features=p11hsm
```shell
cargo build --release --features=p11hsm --target-dir ./target
# binary tmkms is created in ./target/release

./target/release/tmkms init ./.tmkms
# edit ./.tmkms/tmkms.toml per README.p11hsm.md

# start tmkms
SOFTHSM2_PIN=5678 ./target/release/tmkms start -c ./.tmkms/tmkms.toml

# p11hsm cli
./target/release/tmkms p11hsm --help

# p11hsm diag cli
./target/release/tmkms p11hsm diag --help

# p11hsm diag cli
./target/release/tmkms p11hsm diag p11context -h
./target/release/tmkms p11hsm diag p11context -c ./.tmkms/tmkms.toml
./target/release/tmkms p11hsm diag p11context -i softhsm -c ./.tmkms/tmkms.toml
./target/release/tmkms p11hsm diag p11context -i futurex -c ./.tmkms/tmkms.toml

./target/release/tmkms p11hsm diag slotcount -c ./.tmkms/tmkms.toml

./target/release/tmkms p11hsm diag slotinfo -h
./target/release/tmkms p11hsm diag slotinfo -c ./.tmkms/tmkms.toml
./target/release/tmkms p11hsm diag slotinfo -i softhsm -c ./.tmkms/tmkms.toml
./target/release/tmkms p11hsm diag slotinfo -i futurex -c ./.tmkms/tmkms.toml

./target/release/tmkms p11hsm diag login -h
SOFTHSM2_PIN=5678 ./target/release/tmkms p11hsm diag login -c ./.tmkms/tmkms.toml
SOFTHSM2_PIN=5678 ./target/release/tmkms p11hsm diag login -i softhsm -c ./.tmkms/tmkms.toml
FXHSM_PIN=safest ./target/release/tmkms p11hsm diag login -i futurex -c ./.tmkms/tmkms.toml

# p11hsm keys cli
./target/release/tmkms p11hsm keys --help

./target/release/tmkms p11hsm keys pubkey --help
SOFTHSM2_PIN=5678 ./target/release/tmkms p11hsm keys pubkey -l "Slot Token 0/tmkms/ed25519-1/1" -c ./.tmkms/tmkms.toml
FXHSM_PIN=safest ./target/release/tmkms p11hsm keys pubkey -i futurex -t "Slot Token 0" -l "Slot Token 0/tmkms/ed25519-1/1" -c ./.tmkms/tmkms.toml
FXHSM_PIN=safest ./target/release/tmkms p11hsm keys pubkey -i futurex -t "Slot Token 1" -l "Slot Token 0/tmkms/ed25519-1/1" -c ./.tmkms/tmkms.toml

./target/release/tmkms p11hsm keys generate --help
SOFTHSM2_PIN=5678 ./target/release/tmkms p11hsm keys generate -l "Slot Token 0/tmkms/ed25519-5/1" -c ./.tmkms/tmkms.toml
FXHSM_PIN=safest ./target/release/tmkms p11hsm keys generate -i futurex -t "Slot Token 0" -l "Slot Token 0/tmkms/ed25519-5/1" -c ./.tmkms/tmkms.toml

./target/release/tmkms p11hsm keys sign-verify --help

SOFTHSM2_PIN=5678 ./target/release/tmkms p11hsm keys sign-verify -l "Slot Token 0/tmkms/ed25519-1/1" -c ./.tmkms/tmkms.toml
SOFTHSM2_PIN=5678 ./target/release/tmkms p11hsm keys sign-verify -l "Slot Token 0/tmkms/ed25519-1/1" -m "hello world" -c ./.tmkms/tmkms.toml
FXHSM_PIN=safest ./target/release/tmkms p11hsm keys sign-verify -i futurex -t "Slot Token 0" -l "Slot Token 0/tmkms/ed25519-1/13" -m "hello world" -c ./.tmkms/tmkms.toml


```

### features=softsign
```shell
cargo build --release --features=softsign --target-dir ./target-softsign
# binary tmkms is created in ./target-softsign/release

./target-softsign/release/tmkms init ./.tmkms-softsign
# edit ./.tmkms-softsign/tmkms.toml

# generate secret_connection_key for each validator
./target-softsign/release/tmkms softsign keygen ./.tmkms-softsign/secrets/secret_connection_key_1
./target-softsign/release/tmkms softsign keygen ./.tmkms-softsign/secrets/secret_connection_key_2
./target-softsign/release/tmkms softsign keygen ./.tmkms-softsign/secrets/secret_connection_key_3
./target-softsign/release/tmkms softsign keygen ./.tmkms-softsign/secrets/secret_connection_key_4

./target-softsign/release/tmkms softsign keygen ./.tmkms-softsign/secrets/secret_connection_key_5
./target-softsign/release/tmkms softsign keygen ./.tmkms-softsign/secrets/secret_connection_key_6


# note: priv_validator_key_n.json were copied from /Users/johnz/Project/go/cosmos/ignite/wfchains/wfchain/testnet/priv_validator_keys/
./target-softsign/release/tmkms softsign import ./.tmkms-softsign/secrets/priv_validator_key_1.json ./.tmkms-softsign/secrets/priv_validator_key_1
./target-softsign/release/tmkms softsign import ./.tmkms-softsign/secrets/priv_validator_key_2.json ./.tmkms-softsign/secrets/priv_validator_key_2
./target-softsign/release/tmkms softsign import ./.tmkms-softsign/secrets/priv_validator_key_3.json ./.tmkms-softsign/secrets/priv_validator_key_3
./target-softsign/release/tmkms softsign import ./.tmkms-softsign/secrets/priv_validator_key_4.json ./.tmkms-softsign/secrets/priv_validator_key_4

./target-softsign/release/tmkms softsign import ./.tmkms-softsign/secrets/priv_validator_key_5.json ./.tmkms-softsign/secrets/priv_validator_key_5
./target-softsign/release/tmkms softsign import ./.tmkms-softsign/secrets/priv_validator_key_6.json ./.tmkms-softsign/secrets/priv_validator_key_6

# start tmkms
./target-softsign/release/tmkms start -c ./.tmkms-softsign/tmkms.toml
```

## Tests
### llvm-cov
> - https://lib.rs/crates/cargo-llvm-cov
> - llvm-cov does not build ./target/debug/tmkms which is required by integration_p11hsm tests. instead, it builds ./target/llvm-cov-target/debug/tmkms. 
> - - to be safe, run cargo test first.
> - - complete the story, some tests such as version_no_args in integration-p11hsm-runner calls cargo run (CmdRunner) which builds ./target/debug/tmkms.
> - 
```shell
# coverage by all tests
cargo test && \
cargo llvm-cov --tests --features=p11hsm 

# coverage by one target
cargo llvm-cov --test p11hsm
cargo llvm-cov --test pkcs11
cargo llvm-cov --test integration-p11hsm
cargo llvm-cov --test integration-p11hsm-runner

cargo llvm-cov --workspace --lib --tests --features=p11hsm

cargo llvm-cov --html
open target/llvm-cov/html/index.html
```

### tarpaulin
> - https://lib.rs/crates/cargo-tarpaulin
> - not working anymore
```shell
cargo tarpaulin
cargo tarpaulin --ignore-tests --features=p11hsm -- test-threads=10

```

### tests
```shell
# unit tests - p11hsm
cargo test p11hsm::tests:: --lib --features=p11hsm # only in ./src/p11hsm/tests.rs
cargo test keyring::tests:: --lib --features=p11hsm # only in ./src/keyring/tests.rs
cargo test session::tests:: --lib --features=p11hsm # only in ./src/session/tests.rs
cargo test rpc::tests:: --lib --features=p11hsm # only in ./src/rpc/tests.rs
cargo test commands::tests:: --lib --features=p11hsm # only in ./src/rpc/tests.rs
cargo test validator::tests:: --lib --features=p11hsm # only in ./src/validator/tests.rs
cargo test config::provider::tests:: --lib --features=p11hsm # only in ./src/config/provider/tests.rs
cargo test config::validator::tests:: --lib --features=p11hsm # only in ./src/config/validator/tests.rs
# integration tests - p11hsm
cargo test --test integration-p11hsm -- --test-threads=1
cargo test --test integration-p11hsm test_keygen # --features=p11hsm
cargo test --test integration-p11hsm test_handle_and_sign_proposal_account # --features=p11hsm
cargo test --test integration-p11hsm test_handle_and_sign_proposal_consensus # --features=p11hsm
cargo test --test integration-p11hsm test_handle_and_sign_vote_account # --features=p11hsm
cargo test --test integration-p11hsm test_handle_and_sign_vote_consensus # --features=p11hsm
cargo test --test integration-p11hsm test_exceed_max_height_account # --features=p11hsm
cargo test --test integration-p11hsm test_exceed_max_height_consensus # --features=p11hsm
cargo test --test integration-p11hsm test_handle_and_sign_get_publickey_account # --features=p11hsm
cargo test --test integration-p11hsm test_handle_and_sign_get_publickey_consensus # --features=p11hsm
cargo test --test integration-p11hsm test_handle_and_sign_ping_pong # --features=p11hsm
cargo test --test integration-p11hsm test_buffer_underflow_sign_proposal # --features=p11hsm

# integration tests - p11hsm-runner
cargo test --test integration-p11hsm-runner
cargo test --test integration-p11hsm-runner test_keygen # --features=p11hsm
cargo test --test integration-p11hsm-runner test_handle_and_sign_proposal_account # --features=p11hsm
cargo test --test integration-p11hsm-runner test_handle_and_sign_proposal_consensus # --features=p11hsm
cargo test --test integration-p11hsm-runner test_handle_and_sign_vote_account # --features=p11hsm
cargo test --test integration-p11hsm-runner test_handle_and_sign_vote_consensus # --features=p11hsm
cargo test --test integration-p11hsm-runner test_exceed_max_height_account # --features=p11hsm
cargo test --test integration-p11hsm-runner test_exceed_max_height_consensus # --features=p11hsm
cargo test --test integration-p11hsm-runner test_handle_and_sign_get_publickey_account # --features=p11hsm
cargo test --test integration-p11hsm-runner test_handle_and_sign_get_publickey_consensus # --features=p11hsm
cargo test --test integration-p11hsm-runner test_handle_and_sign_ping_pong # --features=p11hsm
cargo test --test integration-p11hsm-runner test_buffer_underflow_sign_proposal # --features=p11hsm

# integration tests - softsign: first,uncomment all in file integration_softsign.rs
cargo test --test integration-softsign test_handle_and_sign_proposal_account --features=softsign
cargo test --test integration-softsign test_handle_and_sign_proposal_consensus --features=softsign
cargo test --test integration-softsign test_handle_and_sign_vote_account --features=softsign
cargo test --test integration-softsign test_handle_and_sign_vote_consensus --features=softsign
cargo test --test integration-softsign test_exceed_max_height_account --features=softsign
cargo test --test integration-softsign test_exceed_max_height_consensus --features=softsign
cargo test --test integration-softsign test_handle_and_sign_get_publickey_account --features=softsign
cargo test --test integration-softsign test_handle_and_sign_get_publickey_consensus --features=softsign
cargo test --test integration-softsign test_handle_and_sign_ping_pong --features=softsign
cargo test --test integration-softsign test_buffer_underflow_sign_proposal --features=softsign

# ./tests are integration tests. To avoid cargo test running them by default, annotate them with #[ignore].
cargo test --features=p11hsm -- --ignored # run only ignored tests
cargo test --features=p11hsm -- --include-ignored # run all, including ignored
```

## Cross compile for linux targets on MacOs
ref: https://betterprogramming.pub/cross-compiling-rust-from-mac-to-linux-7fad5a454ab1
### musl does not support dynamic loading of libpkcs11.so
```shell
rustup target add x86_64-unknown-linux-musl
brew install FiloSottile/musl-cross/musl-cross
# edit ~/.cargo/config.toml by adding
[target.x86_64-unknown-linux-musl]
linker = "x86_64-linux-musl-gcc"

TARGET_CC=x86_64-linux-musl-gcc cargo build --release --features=p11hsm --target x86_64-unknown-linux-musl --target-dir ./target-p11-val-cli-musl

```
### gnu
```shell
rustup target add x86_64-unknown-linux-gnu
brew install SergioBenitez/osxct/x86_64-unknown-linux-gnu
# edit ~/.cargo/config.toml by adding
[target.x86_64-unknown-linux-gnu]
linker = "x86_64-unknown-linux-gnu-gcc"

TARGET_CC=x86_64-unknown-linux-gnu cargo build --release --features=p11hsm --target x86_64-unknown-linux-gnu --target-dir ./target-p11-val-cli-gnu
#TARGET_CC=x86_64-unknown-linux-gnu cargo build --release --features=p11hsm --target x86_64-unknown-linux-gnu --target-dir ./target-test-gnu

```

## Open Issues
- Thread safety. The code may not be thread safe.
PCSK11 Session implements only Send and intentionally prohibits implementing Sync for sharing across threads. They may have their reason for that.  
SDK which has inner Session in it implements both Sync and Send. That is because Signer in KeyRing requires both to satisfy the GlobalRegistry which has an inner Rc of Registry which has KeyRing.  
The potential issue may be when a p11hsm provider supports multiple validators - the provider has a single SDK which is shared via Arc among those validators. Is that the reason why every block has one or more "signing operation failed: signature error" among those validators, even though that does not seem to affect the service functionality.