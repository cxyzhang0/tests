use async_trait::async_trait;
use ecdsa::elliptic_curve::CurveArithmetic;
use ecdsa::PrimeCurve;
// use k256::ecdsa::{Signature, VerifyingKey};
use k256::Secp256k1;
use signature::Keypair;
use crate::SignatureError;

/// trait for signing messages asynchronously
/// somewhat modelled after Signer in RustCrypto signature crate
#[async_trait]
pub trait AsyncSigner<C = Secp256k1, S = ecdsa::Signature<C>>: Keypair<VerifyingKey = ecdsa::VerifyingKey<C>> + Sync + Send 
    where C: CurveArithmetic + PrimeCurve
{
    /// sign the hash of the provided raw message
    async fn sign(&self, msg: &[u8]) -> S {
        self.try_sign(msg)
            .await
            .expect("signature operation failed")
    }

    /// sign the message hash
    async fn sign_rehash(&self, msg_hash: [u8; 32]) -> S {
        self.try_sign_prehash(msg_hash)
            .await
            .expect("signature operation failed")
    }

    /// try to sign the hash of the provided raw message
    async fn try_sign(&self, msg: &[u8]) -> Result<S, SignatureError>;
    // fn try_sign(&self, msg: &[u8]) -> BoxFuture<anyhow::Result<S>>;

    /// try to sign the message hash
    async fn try_sign_prehash(&self, msg_hash: [u8; 32]) -> Result<S, SignatureError>;
}

// this generic implementation makes it impossible for any concrete implementation of AsyncSigner.
//  how to get an AsyncSigner to start with?
/*
#[async_trait]
impl<T, S> AsyncSigner<S> for T
where
    T: AsyncSigner<S>,
    T: Keypair<VerifyingKey = VerifyingKey> + Sync + Send
{
    async fn try_sign(&self, msg: &[u8]) -> Result<S, SignatureError> {
        self.try_sign(msg).await
    }

    async fn try_sign_prehash(&self, msg_hash: [u8; 32]) -> Result<S, SignatureError> {
        self.try_sign_prehash(msg_hash).await
    }
}
*/

/// a wrapper around an AsyncSigner trait object
pub struct AsyncSigningKey<C = Secp256k1, S = ecdsa::Signature<C>> 
    where C: CurveArithmetic + PrimeCurve
{
    inner: Box<dyn AsyncSigner<C, S>>,
}

impl<C: CurveArithmetic + PrimeCurve, S> AsyncSigningKey<C, S> {
    pub fn new(signer: Box<dyn AsyncSigner<C, S>>) -> Self {
        Self { inner: signer }
    }

    pub async fn sign(&self, msg: &[u8]) -> S {
        self.inner.sign(msg).await
    }

    pub async fn sign_prehash(&self, msg_hash: [u8; 32]) -> S {
        self.inner.sign_rehash(msg_hash).await
    }

    pub fn verifying_key(&self) -> ecdsa::VerifyingKey<C> {
        self.inner.verifying_key()
    }
}