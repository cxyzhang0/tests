use std::{fs, env};
use std::path::PathBuf;
use serde::Deserialize;
use thiserror::Error;
use zeroize::{Zeroize, Zeroizing};


/// Configuration option for authenticating to the HSM
#[derive(Clone, Debug, Deserialize)]
#[serde(deny_unknown_fields, untagged)]
pub enum AuthConfig {
    /// Path to a separate pin file
    Path {
        /// pkcs11 user pin file path
        pin_file: PathBuf,
    },
    /// Read pin directly from the config file
    String {
        /// pkcs11 user pin
        pin: Pin,
    },
    /// Read pin from environment variable
    Env {
        /// Environment variable name containing the pin
        pin_env: String,
    },
}

#[derive(Error, Debug)]
pub enum AuthConfigError {
    #[error("couldn't read pin from {path}: {source}")]
    PinFileReadError {
        path: PathBuf,
        #[source]
        source: std::io::Error,
    },
    #[error("couldn't read pin from environment variable {env_var}: {source}")]
    PinEnvError {
        env_var: String,
        #[source]
        source: std::env::VarError,
    },
}

impl AuthConfig {
    /// Retrieve Pin for this `AuthConfig`
    pub fn pin(&self) -> Result<String, AuthConfigError> {
        match self {
            AuthConfig::Path { pin_file } => {
                let pin = Zeroizing::new(
                    fs::read_to_string(pin_file).map_err(|e| AuthConfigError::PinFileReadError {
                            path: pin_file.clone(),
                            source: e,
                        })?
                );
                Ok(pin.trim_end().to_string())
            }
            AuthConfig::String { pin } => {
                Ok(pin.as_str().to_string())
            }
            AuthConfig::Env { pin_env } => {
                let pin = env::var(pin_env).map_err(|e| AuthConfigError::PinEnvError {
                    env_var: pin_env.clone(),
                    source: e,
                })?;
                Ok(pin)
            }
        }
    }
}

impl Default for AuthConfig {
    fn default() -> Self {
        AuthConfig::String {
            pin: Pin::default(),
        }
    }
}
/// PIN to the P11HSM
#[derive(Clone, Debug, Default, Deserialize, Zeroize)]
#[serde(deny_unknown_fields)]
#[zeroize(drop)]
pub struct Pin(String);

impl Pin {
    /// Public constructor for testing
    pub fn new(value: String) -> Self {
        Pin(value)
    }

    /// Getter method to avoid moving String out of Pin
    pub fn as_str(&self) -> &str {
        &self.0
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::io::Write;
    use tempfile::NamedTempFile;

    #[test]
    fn test_auth_config_default() {
        let auth = AuthConfig::default();
        match auth.pin() {
            Ok(pin) => assert_eq!(pin, ""),
            Err(e) => panic!("Expected Ok, got Err: {}", e),
        }
    }
    
    #[test]
    fn test_pin_new() {
        let pin = Pin::new("test_pin".to_string());
        assert_eq!(pin.as_str(), "test_pin");
    }

    #[test]
    fn test_pin_as_str() {
        let pin = Pin::new("my_secret_pin".to_string());
        assert_eq!(pin.as_str(), "my_secret_pin");
    }

    #[test]
    fn test_pin_clone() {
        let pin1 = Pin::new("original".to_string());
        let pin2 = pin1.clone();
        assert_eq!(pin1.as_str(), pin2.as_str());
    }

    #[test]
    fn test_auth_config_string_pin() {
        let pin = Pin::new("string_pin".to_string());
        let auth = AuthConfig::String { pin };
        match auth.pin() {
            Ok(pin) => assert_eq!(pin, "string_pin"),
            Err(e) => panic!("Expected Ok, got Err: {}", e),
        }
    }

    #[test]
    fn test_auth_config_path_pin() {
        let mut temp_file = NamedTempFile::new().unwrap();
        write!(temp_file, "file_pin").unwrap();

        let auth = AuthConfig::Path {
            pin_file: temp_file.path().to_path_buf(),
        };

        match auth.pin() {
            Ok(pin) => assert_eq!(pin, "file_pin"),
            Err(e) => panic!("Expected Ok, got Err: {}", e),
        }
    }

    #[test]
    fn test_auth_config_path_pin_with_whitespace() {
        let mut temp_file = NamedTempFile::new().unwrap();
        writeln!(temp_file, "pin_with_newline").unwrap();

        let auth = AuthConfig::Path {
            pin_file: temp_file.path().to_path_buf(),
        };

        match auth.pin() {
            Ok(pin) => assert_eq!(pin, "pin_with_newline"),
            Err(e) => panic!("Expected Ok, got Err: {}", e),
        }
    }

    #[test]
    fn test_auth_config_path_pin_no_trailing_newline() {
        let mut temp_file = NamedTempFile::new().unwrap();
        write!(temp_file, "no_newline").unwrap();

        let auth = AuthConfig::Path {
            pin_file: temp_file.path().to_path_buf(),
        };

        match auth.pin() {
            Ok(pin) => assert_eq!(pin, "no_newline"),
            Err(e) => panic!("Expected Ok, got Err: {}", e),
        }
    }

    #[test]
    fn test_auth_config_path_nonexistent_file() {
        let auth = AuthConfig::Path {
            pin_file: PathBuf::from("/nonexistent/path/to/pin"),
        };

        let result = auth.pin();
        assert!(result.is_err());
        assert!(matches!(result, Err(AuthConfigError::PinFileReadError { .. })));
    }

    #[test]
    fn test_deserialize_auth_config_string_json() {
        let json = r#"{"pin": "test_pin"}"#;
        let auth: AuthConfig = serde_json::from_str(json).unwrap();
        match auth.pin() {
            Ok(pin) => assert_eq!(pin, "test_pin"),
            Err(e) => panic!("Expected Ok, got Err: {}", e),
        }
    }

    #[test]
    fn test_deserialize_auth_config_path_json() {
        let mut temp_file = NamedTempFile::new().unwrap();
        writeln!(temp_file, "deserialized_pin").unwrap();

        let json = format!(r#"{{"pin_file": "{}"}}"#, temp_file.path().display());
        let auth: AuthConfig = serde_json::from_str(&json).unwrap();
        match auth.pin() {
            Ok(pin) => assert_eq!(pin, "deserialized_pin"),
            Err(e) => panic!("Expected Ok, got Err: {}", e),
        }
    }

    #[test]
    fn test_deserialize_auth_config_string_toml() {
        let toml = r#"pin = "test_pin""#;
        let auth: AuthConfig = toml::from_str(toml).unwrap();
        match auth.pin() {
            Ok(pin) => assert_eq!(pin, "test_pin"),
            Err(e) => panic!("Expected Ok, got Err: {}", e),
        }
    }

    #[test]
    fn test_deserialize_auth_config_path_toml() {
        let mut temp_file = NamedTempFile::new().unwrap();
        writeln!(temp_file, "deserialized_pin").unwrap();

        let toml = format!(r#"pin_file = "{}""#, temp_file.path().display());
        let auth: AuthConfig = toml::from_str(&toml).unwrap();
        match auth.pin() {
            Ok(pin) => assert_eq!(pin, "deserialized_pin"),
            Err(e) => panic!("Expected Ok, got Err: {}", e),
        }
    }

    #[test]
    fn test_auth_config_env_pin() {
        env::set_var("TEST_PIN_ENV", "env_pin");

        let auth = AuthConfig::Env {
            pin_env: "TEST_PIN_ENV".to_string(),
        };

        match auth.pin() {
            Ok(pin) => assert_eq!(pin, "env_pin"),
            Err(e) => panic!("Expected Ok, got Err: {}", e),
        }

        env::remove_var("TEST_PIN_ENV");
    }

    #[test]
    fn test_auth_config_env_pin_not_set() {
        let auth = AuthConfig::Env {
            pin_env: "NONEXISTENT_ENV_VAR".to_string(),
        };

        let result = auth.pin();
        assert!(result.is_err());
        assert!(matches!(result, Err(AuthConfigError::PinEnvError { .. })));
    }

    #[test]
    fn test_deserialize_auth_config_env_json() {
        env::set_var("TEST_PIN_JSON", "json_env_pin");

        let json = r#"{"pin_env": "TEST_PIN_JSON"}"#;
        let auth: AuthConfig = serde_json::from_str(json).unwrap();
        match auth.pin() {
            Ok(pin) => assert_eq!(pin, "json_env_pin"),
            Err(e) => panic!("Expected Ok, got Err: {}", e),
        }

        env::remove_var("TEST_PIN_JSON");
    }

    #[test]
    fn test_deserialize_auth_config_env_toml() {
        env::set_var("TEST_PIN_TOML", "toml_env_pin");

        let toml = r#"pin_env = "TEST_PIN_TOML""#;
        let auth: AuthConfig = toml::from_str(toml).unwrap();
        match auth.pin() {
            Ok(pin) => assert_eq!(pin, "toml_env_pin"),
            Err(e) => panic!("Expected Ok, got Err: {}", e),
        }

        env::remove_var("TEST_PIN_TOML");
    }

}
