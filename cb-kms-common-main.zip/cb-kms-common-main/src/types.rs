pub mod config;

#[derive(Copy, Debug, Clone, PartialEq, Eq, Hash)]
pub enum CryptographAlgorithm {
    Secp256k1,
    Ed25519,
    Secp256r1,
    RSA2048,
    AES,
}

impl From<String> for CryptographAlgorithm {
    fn from(s: String) -> Self {
        match s.to_uppercase().as_str() {
            "SECP256K1" => CryptographAlgorithm::Secp256k1,
            "ED25519" => CryptographAlgorithm::Ed25519,
            "SECP256R1" => CryptographAlgorithm::Secp256r1,
            "RSA2048" => CryptographAlgorithm::RSA2048,
            "AES" => CryptographAlgorithm::AES,
            _ => panic!("Algorithm {s} not supported"),
            // "secp256k1" => CryptographAlgorithm::Secp256k1,
            // "ed25519" => CryptographAlgorithm::Ed25519,
            // "secp256r1" => CryptographAlgorithm::Secp256r1,
            // "rsa2048" => CryptographAlgorithm::RSA2048,
            // _ => CryptographAlgorithm::Secp256k1,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_from_cryptography_algorithm_sucessfully() {
        let s = "sECp256k1".to_string();
        let a = CryptographAlgorithm::from(s);
        assert_eq!(a, CryptographAlgorithm::Secp256k1);

        let s = "eD25519".to_string();
        let a = CryptographAlgorithm::from(s);
        assert_eq!(a, CryptographAlgorithm::Ed25519);

        let s = "SecP256R1".to_string();
        let a = CryptographAlgorithm::from(s);
        assert_eq!(a, CryptographAlgorithm::Secp256r1);

        let s = "RsA2048".to_string();
        let a = CryptographAlgorithm::from(s);
        assert_eq!(a, CryptographAlgorithm::RSA2048);

    }

    #[test]
    #[should_panic]
    fn test_from_cryptography_algorithm_fail() {
        let s = "fail".to_string();
        let _a = CryptographAlgorithm::from(s);
    }
    
}
