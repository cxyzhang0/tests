package tokenfactory_test

import (
	errorsmod "cosmossdk.io/errors"
	"fmt"
	transfertypes "github.com/cosmos/ibc-go/v10/modules/apps/transfer/types"
	tokenfactory "github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/keeper"
	"testing"

	sdk "github.com/cosmos/cosmos-sdk/types"
	banktypes "github.com/cosmos/cosmos-sdk/x/bank/types"
	protov2 "google.golang.org/protobuf/proto"

	. "github.com/wfblockchain/coreblockchain/v2/x/tokenfactory" // adjust
)

// --------------------------------------------
// go test ./x/tokenfactory -run '^Test'
// --------------------------------------------
// --------------------------------------------
// Fake Token Factories
// --------------------------------------------
type fakeTF struct {
	paused map[string]bool
}

func (f fakeTF) IsPaused(denom string) bool {
	return f.paused[denom]
}

// Mock the actual paused check call (wrapper)
func makePausedChecker(f fakeTF) func(
	ctx sdk.Context, c sdk.Coin, t *tokenfactory.Keeper, ft *tokenfactory.Keeper,
) (bool, *errorsmod.Error) {
	return func(
		ctx sdk.Context, c sdk.Coin, _ *tokenfactory.Keeper, _ *tokenfactory.Keeper,
	) (bool, *errorsmod.Error) {
		if f.IsPaused(c.Denom) {
			return true, nil
		}
		return false, nil
	}
}

// --------------------------------------------
// Replace global function for unit testing
// --------------------------------------------
var originalCheckPaused = PausedChecker

func setChecker(fn func(sdk.Context, sdk.Coin, *tokenfactory.Keeper, *tokenfactory.Keeper) (bool, *errorsmod.Error)) {
	PausedChecker = fn
}

func restoreChecker() {
	PausedChecker = originalCheckPaused
}

// --------------------------------------------
// Tests
// --------------------------------------------

func TestCheckCoin_Paused(t *testing.T) {
	defer restoreChecker()
	tf := fakeTF{paused: map[string]bool{"ufoo": true}}

	setChecker(makePausedChecker(tf))

	ad := IsPausedDecorator{}
	err := ad.CheckCoin(sdk.Context{}, sdk.NewInt64Coin("ufoo", 10))

	if err == nil {
		t.Fatalf("expected error for paused coin")
	}
}

func TestCheckCoin_NotPaused(t *testing.T) {
	defer restoreChecker()
	tf := fakeTF{paused: map[string]bool{}}

	setChecker(makePausedChecker(tf))

	ad := IsPausedDecorator{}
	err := ad.CheckCoin(sdk.Context{}, sdk.NewInt64Coin("ubar", 10))

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
}

func TestCheckCoins(t *testing.T) {
	defer restoreChecker()
	tf := fakeTF{
		paused: map[string]bool{
			"ufoo": false,
			"ubar": true,
		},
	}

	setChecker(makePausedChecker(tf))

	coins := sdk.NewCoins(
		sdk.NewInt64Coin("ufoo", 10),
		sdk.NewInt64Coin("ubar", 20),
	)

	ad := IsPausedDecorator{}
	err := ad.CheckCoins(sdk.Context{}, coins)

	if err == nil {
		t.Fatalf("expected error for paused denom")
	}
}

func TestCheckMessage_MsgSend(t *testing.T) {
	defer restoreChecker()

	tf := fakeTF{paused: map[string]bool{"ufoo": true}}
	setChecker(makePausedChecker(tf))

	msg := &banktypes.MsgSend{
		FromAddress: "addr1",
		ToAddress:   "addr2",
		Amount: sdk.NewCoins(
			sdk.NewInt64Coin("ufoo", 10),
		),
	}

	ad := IsPausedDecorator{}
	err := ad.CheckMessage(sdk.Context{}, msg)

	if err == nil {
		t.Fatalf("expected error for paused MsgSend")
	}
}

func TestCheckMessage_MsgMultiSend(t *testing.T) {
	defer restoreChecker()

	tf := fakeTF{paused: map[string]bool{"ubar": true}}
	setChecker(makePausedChecker(tf))

	msg := &banktypes.MsgMultiSend{
		Inputs: []banktypes.Input{
			{
				Address: "addr1",
				Coins: sdk.NewCoins(
					sdk.NewInt64Coin("ufoo", 10),
					sdk.NewInt64Coin("ubar", 10),
				),
			},
		},
	}

	ad := IsPausedDecorator{}
	err := ad.CheckMessage(sdk.Context{}, msg)

	if err == nil {
		t.Fatalf("expected error for paused MsgMultiSend")
	}
}

func TestCheckMessage_MsgTransfer(t *testing.T) {
	defer restoreChecker()

	tf := fakeTF{paused: map[string]bool{"ufoo": true}}
	setChecker(makePausedChecker(tf))

	msg := &transfertypes.MsgTransfer{
		Token: sdk.NewInt64Coin("ufoo", 1),
	}

	ad := IsPausedDecorator{}
	err := ad.CheckMessage(sdk.Context{}, msg)

	if err == nil {
		t.Fatalf("expected error for paused MsgTransfer")
	}
}

func TestCheckMessage_IgnoresUnknownType(t *testing.T) {
	defer restoreChecker()
	setChecker(originalCheckPaused) // not used

	ad := IsPausedDecorator{}
	err := ad.CheckMessage(sdk.Context{}, unknownMsg{})

	if err != nil {
		t.Fatalf("unexpected error for unknown message: %v", err)
	}
}

func TestAnteHandle(t *testing.T) {
	defer restoreChecker()

	tf := fakeTF{paused: map[string]bool{"ufoo": true}}
	setChecker(makePausedChecker(tf))

	tx := mockTx{
		msgs: []sdk.Msg{
			&banktypes.MsgSend{
				Amount: sdk.NewCoins(sdk.NewInt64Coin("ufoo", 10)),
			},
		},
	}

	ad := IsPausedDecorator{}

	nextCalled := false
	next := func(ctx sdk.Context, tx sdk.Tx, simulate bool) (sdk.Context, error) {
		nextCalled = true
		return ctx, nil
	}

	_, err := ad.AnteHandle(sdk.Context{}, tx, false, next)

	if err == nil {
		t.Fatalf("expected error due to paused token")
	}
	if nextCalled {
		t.Fatalf("next handler should not have been called")
	}
}

// --------------------------------------------
// Minimal unknownMsg implements sdk.Msg; shared with blacklist tests
// --------------------------------------------
var _ sdk.Msg = unknownMsg{}

type unknownMsg struct{}

func (unknownMsg) Reset()         {}
func (unknownMsg) String() string { return "unknownMsg" }
func (unknownMsg) ProtoMessage()  {}

// --------------------------------------------
// Minimal mock tx; ; shared with blacklist tests
// --------------------------------------------
type mockTx struct{ msgs []sdk.Msg }

func (m mockTx) GetMsgsV2() ([]protov2.Message, error) {
	// Convert []sdk.Msg → []proto.Message
	out := make([]protov2.Message, len(m.msgs))
	for i, msg := range m.msgs {
		// All sdk.Msg must satisfy proto.Message
		pmsg, ok := msg.(protov2.Message)
		if !ok {
			return nil, fmt.Errorf("msg %T does not implement proto.Message", msg)
		}
		out[i] = pmsg
	}
	return out, nil
}

// Optional but often required by Tx interface depending on SDK version:
func (m mockTx) ValidateBasic() error { return nil }

func (m mockTx) GetMsgs() []sdk.Msg { return m.msgs }
