package poas

import (
	"encoding/json"
	authkeeper "github.com/cosmos/cosmos-sdk/x/auth/keeper"

	"cosmossdk.io/core/appmodule"

	"github.com/grpc-ecosystem/grpc-gateway/runtime"

	"github.com/spf13/cobra"

	"github.com/cosmos/cosmos-sdk/client"
	"github.com/cosmos/cosmos-sdk/codec"
	codectypes "github.com/cosmos/cosmos-sdk/codec/types"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/cosmos/cosmos-sdk/types/module"
	govkeeper "github.com/cosmos/cosmos-sdk/x/gov/keeper"
	stakingkeeper "github.com/cosmos/cosmos-sdk/x/staking/keeper"

	"github.com/wfblockchain/coreblockchain/v2/x/poas/keeper"
	"github.com/wfblockchain/coreblockchain/v2/x/poas/types"
)

// -------------------- AppModuleBasic --------------------

type AppModuleBasic struct{}

var _ module.AppModuleBasic = AppModuleBasic{}

func (AppModuleBasic) Name() string { return types.ModuleName }

func (AppModuleBasic) RegisterLegacyAminoCodec(cdc *codec.LegacyAmino) {
	types.RegisterLegacyAminoCodec(cdc)
}

func (AppModuleBasic) RegisterInterfaces(reg codectypes.InterfaceRegistry) {
	types.RegisterInterfaces(reg)
}

// v0.53 signature includes TxEncodingConfig
func (AppModuleBasic) ValidateGenesis(
	cdc codec.JSONCodec,
	_ client.TxEncodingConfig,
	_ json.RawMessage,
) error {
	// No custom validation (empty genesis)
	return nil
}

func (AppModuleBasic) DefaultGenesis(cdc codec.JSONCodec) json.RawMessage {
	// Proper empty genesis JSON ({}), via a typed default
	//return cdc.MustMarshalJSON(types.DefaultGenesis())
	return []byte(`{}`)
}

// Optional CLI hooks; return nil if you don't expose CLI
func (AppModuleBasic) GetTxCmd() *cobra.Command    { return nil }
func (AppModuleBasic) GetQueryCmd() *cobra.Command { return nil }

// v0.53: Basic must expose GRPC-Gateway routes (noop if none)
func (AppModuleBasic) RegisterGRPCGatewayRoutes(client.Context, *runtime.ServeMux) {}

// -------------------- AppModule --------------------

type AppModule struct {
	AppModuleBasic
	cdc codec.Codec
	ir  codectypes.InterfaceRegistry
	k   keeper.Keeper
	ak  authkeeper.AccountKeeper
	sk  *stakingkeeper.Keeper
}

// Satisfy older module interface
//var _ module.AppModule = AppModule{}

// Satisfy new core appmodule marker interfaces (v0.5x)
var _ appmodule.AppModule = AppModule{}

func NewAppModule(
	cdc codec.Codec,
	ir codectypes.InterfaceRegistry,
	k keeper.Keeper,
	ak authkeeper.AccountKeeper,
	sk *stakingkeeper.Keeper,
) AppModule {
	return AppModule{
		AppModuleBasic: AppModuleBasic{},
		cdc:            cdc,
		ir:             ir,
		k:              k,
		ak:             ak,
		sk:             sk,
	}
}

// Marker methods (no-op bodies) for core/appmodule
func (AppModule) IsAppModule()        {}
func (AppModule) IsOnePerModuleType() {}

func (am AppModule) RegisterServices(cfg module.Configurator) {
	types.RegisterMsgServer(cfg.MsgServer(), keeper.NewMsgServerImpl(am.k, am.ak, am.sk))
}

func (am AppModule) InitGenesis(
	_ sdk.Context,
	_ codec.JSONCodec,
	_ json.RawMessage,
) {
	// no state
}

func (am AppModule) ExportGenesis(
	_ sdk.Context,
	_ codec.JSONCodec,
) json.RawMessage {
	// empty export
	//return []byte(`{}`)
	return json.RawMessage("{}")
}

// v0.53 requires a consensus version for migrations; bump when you add migrations.
func (AppModule) ConsensusVersion() uint64 { return 1 }

// -------------------- Helper for app.go wiring --------------------

func NewKeeperForApp(
	ir codectypes.InterfaceRegistry,
	stakingK *stakingkeeper.Keeper,
	govK *govkeeper.Keeper,
) keeper.Keeper {
	return keeper.NewKeeper(ir, stakingK, govK)
}
