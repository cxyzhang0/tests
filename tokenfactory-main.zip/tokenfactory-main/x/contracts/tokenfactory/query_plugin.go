package tokenfactory

import (
	"encoding/json"
	"fmt"

	errorsmod "cosmossdk.io/errors"
	wasmvmtypes "github.com/CosmWasm/wasmvm/types"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/wfblockchain/coreblockchain/v2/x/contracts/tokenfactory/bindings"
)

func CustomQuerier(qp *QueryPlugin) func(ctx sdk.Context, request json.RawMessage) ([]byte, error) {
	return func(ctx sdk.Context, request json.RawMessage) ([]byte, error) {
		var contractQuery bindings.FactoryQuery
		if err := json.Unmarshal(request, &contractQuery); err != nil {
			return nil, errorsmod.Wrap(err, "failed to decode factory query")
		}

		if contractQuery.TF != nil {
			switch {
			case contractQuery.TF.Params != nil:
				resp, err := qp.Params(ctx, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "params"))
				}

				return encode(resp, "params")
			case contractQuery.TF.Owner != nil:
				resp, err := qp.Owner(ctx, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "owner"))
				}

				return encode(resp, "owner")
			case contractQuery.TF.MasterMinter != nil:
				resp, err := qp.MasterMinter(ctx, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "master minter"))
				}
				return encode(resp, "master minter")
			case contractQuery.TF.MinterController != nil:
				resp, err := qp.MinterController(ctx, contractQuery.TF.MinterController.Controller, contractQuery.TF.MinterController.Minter, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s: %s %s", "minter controller", contractQuery.TF.MinterController.Controller, contractQuery.TF.MinterController.Minter))
				}
				return encode(resp, "mint controller")
			case contractQuery.TF.AllMinterControllers != nil:
				resp, err := qp.AllMinterControllers(ctx, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "all minter controllers"))
				}
				return encode(resp, "all minter controllers")
			case contractQuery.TF.MintingDenom != nil:
				resp, err := qp.MintingDenom(ctx, contractQuery.TF.MintingDenom.Denom, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "minting denom"))
				}
				return encode(resp, "minting denom")
			case contractQuery.TF.AllMintingDenoms != nil:
				resp, err := qp.AllMintingDenoms(ctx, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "all minting denoms"))
				}
				return encode(resp, "all minting denoms")
			case contractQuery.TF.Minters != nil:
				resp, err := qp.Minters(ctx, contractQuery.TF.Minters.Address, contractQuery.TF.Minters.Denom, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s: %s", "minters", contractQuery.TF.Minters.Address))
				}
				return encode(resp, "minters")
			case contractQuery.TF.AllMinters != nil:
				resp, err := qp.AllMinters(ctx, contractQuery.TF.AllMinters.Address, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "all minters"))
				}
				return encode(resp, "all minters")
			case contractQuery.TF.Blacklister != nil:
				resp, err := qp.Blacklister(ctx, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "blacklister"))
				}
				return encode(resp, "blacklister")
			case contractQuery.TF.Pauser != nil:
				resp, err := qp.Pauser(ctx, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "pauser"))
				}
				return encode(resp, "pauser")
			case contractQuery.TF.Blacklisted != nil:
				resp, err := qp.Blacklisted(ctx, contractQuery.TF.Blacklisted.Address, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s: %s", "blacklisted", contractQuery.TF.Blacklisted.Address))
				}
				return encode(resp, "blacklisted")
			case contractQuery.TF.AllBlacklisted != nil:
				resp, err := qp.AllBlacklisted(ctx, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "all blacklisted"))
				}
				return encode(resp, "blacklisted")
			case contractQuery.TF.Paused != nil:
				resp, err := qp.Paused(ctx, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s", "paused"))
				}
				return encode(resp, "paused")

			default:
				return nil, wasmvmtypes.UnsupportedRequest{Kind: "unknown tokenfactory query variant"}
			}

		} else if contractQuery.Bank != nil {
			switch {
			case contractQuery.Bank.DenomMetadata != nil:
				resp, err := qp.DenomMetadata(ctx, contractQuery.Bank.DenomMetadata.Denom)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s: %s", "denom metadata", contractQuery.Bank.DenomMetadata.Denom))
				}

				return encode(resp, "denom metadata")

			case contractQuery.Bank.AllDenomMetadata != nil:
				resp := qp.AllDenomMetadata(ctx)

				return encode(resp, "denoms metadata")

			case contractQuery.Bank.FindDenomMetadata != nil:
				resp, err := qp.FindDenomMetadata(ctx, contractQuery.Bank.FindDenomMetadata)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to find denom metadata for %s %s", contractQuery.Bank.FindDenomMetadata.BaseDenom, contractQuery.Bank.FindDenomMetadata.Denom))
				}

				return encode(resp, "find denom metadata")

			case contractQuery.Bank.FindMetadataForDenom != nil:
				resp, err := qp.FindMetadataForDenom(ctx, contractQuery.Bank.FindMetadataForDenom)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to find metadata for denom %s", contractQuery.Bank.FindMetadataForDenom.Denom))
				}

				return encode(resp, "find metadata for denom")

			default:
				return nil, wasmvmtypes.UnsupportedRequest{Kind: "unknown bank query variant"}

			}
		} else if contractQuery.Feegrant != nil {
			switch {
			case contractQuery.Feegrant.FeeBasicAllowance != nil:
				resp, err := qp.FeeBasicAllowance(ctx, contractQuery.Feegrant.FeeBasicAllowance)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s: %s", "fee basic allowance", contractQuery.Feegrant.FeeBasicAllowance.Granter))
				}

				return encode(resp, "fee basic allowance")

			default:
				return nil, wasmvmtypes.UnsupportedRequest{Kind: "unknown feegrant query variant"}
			}
		} else {
			return nil, wasmvmtypes.UnsupportedRequest{Kind: "unknown factory query variant"}
		}
	}
}

func encode(resp any, msg string) ([]byte, error) {
	bz, err := json.Marshal(resp)
	if err != nil {
		return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to encode %s response", msg))
	}
	return bz, nil
}
