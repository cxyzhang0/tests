## Tests to showcase the functionality
```shell
# unit tests and integration tests (integration.rs and integration_extra.rs)
cargo test 

# other ./tests are manual integration tests. To avoid cargo test running them by default, annotate them with #[ignore].
cargo test -- --ignored # run only ignored tests
cargo test --test sdk -- --ignored # run only ignored tests in tests/sdk.rs
cargo test --test sdk_helper -- --ignored # run only ignored tests in tests/sdk_helper.sr
cargo test it_sign_verify_sig_ed25519_outside_hsm -- --ignored --exact # run a specific test
cargo test it_sign_verify_secp256r1 -- --ignored --exact # run a specific test
cargo test it_test_encrypt_decrypt -- --ignored --exact # run a specific test
cargo test -- --include-ignored # run all, including ignored
```

## Test coverage
```shell
# llvm-cov: https://lib.rs/crates/cargo-llvm-cov
cargo llvm-cov
cargo llvm-cov --html
open target/llvm-cov/html/index.html

# tarpaulin: https://lib.rs/crates/cargo-tarpaulin
cargo tarpaulin --ignore-tests
cargo tarpaulin --ignore-tests -- test-threads=10
```

## apply linting
```shell
# Optimize Imports for the whole workspace: right-click on the workspace root folder in RustRover IDE and select Optimize Imports.
# unfortunately, the above does not remove unused imports.

# check the whole workspace. it will show unused imports, among other things.
# manually remove unused imports.
cargo check --workspace --all-features  
cargo check --all-features  

# Reformat the whole workspace: right-click on the workspace root folder in RustRover IDE and select Reformat Code.
# Or run the following commands.
cargo fmt --all --check # it will display the proposed changes.
cargo fmt --all

# clippy the whole workspace; review recommendations and make appropriate changes.
cargo clippy --workspace --all-features
## pedantic is too strict, but the docs recommendation may be worth it.
cargo clippy --workspace --all-features -- --warn clippy::pedantic

# fix clippy recommendations: may need to export __CARGO_FIX_YOLO=1
cargo fix #--allow-dirty --allow-staged
cargo clippy --fix #--allow-dirty -- -Dwarnings  
```
