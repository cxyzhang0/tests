//! This crate is to integration-test init_sdk all by itself in this crate to avoid interference with other test crates
//!
use crate::integration_common::{
    init_pins, ENV_SOFTHSM2_CONF, MODULE, SOFTHSM2_CONF, TOKEN_LABEL, USER_PIN,
};
use pkcs11_sdk::init_sdk;
use serial_test::serial;

mod integration_common;

#[test]
#[serial]
fn it_fn_sdk_init_sdk() -> pkcs11_sdk::Result<()> {
    let (_, _) = init_pins()?;

    init_sdk(
        ENV_SOFTHSM2_CONF,
        SOFTHSM2_CONF,
        None,
        Some(MODULE),
        TOKEN_LABEL,
        USER_PIN,
    )?;

    Ok(())
}
