//! Manual integration tests of the symmetric SDK
//! Instead of using AES_KEY_LABEL defined in common.rs, we use an adhoc AES_KEY_LABEL defined locally.
//! This is useful to generate test KEKs for MPC nodes, for example.
use pkcs11_sdk::{Error, KeyLabel, Result};
use kms_common::types::CryptographAlgorithm;
use serial_test::serial;
use std::time::Instant;

mod common;
use common::get_sdk;

const AES_KEY_LABEL: &str = "slot-0/tsstrio-0/aes/1";
// const AES_KEY_LABEL: &str = "slot-0/tsstrio-1/aes/1";
#[ignore]
#[test]
#[serial]
fn it_aes_keygen() -> Result<()> {
    let start = Instant::now();
    let sdk = get_sdk()?;
    println!("Time elapsed after get_sdk(): {:?}", start.elapsed());

    let mut key_label = KeyLabel::from_short(&AES_KEY_LABEL, CryptographAlgorithm::AES)?;
    let persistent = false;

    let created = sdk.aes_keygen(&mut key_label, persistent)?;
    println!("Time elapsed after aes_keygen(): {:?}", start.elapsed());

    let got_handle = sdk.get_aes_key_handle(&key_label)?;
    println!(
        "Time elapsed after get_aes_key_handle(): {:?}",
        start.elapsed()
    );

    assert_eq!(created.0, got_handle);
    println!(
        "created handle: {}; got handle:{}; key label: {}",
        created.0,
        got_handle,
        created.1.short_label()
    );

    Ok(())
}

#[ignore]
#[test]
#[serial]
fn it_test_get_aes_key_label() -> Result<()> {
    let sdk = get_sdk()?;

    let key_label = KeyLabel::from_short(&AES_KEY_LABEL, CryptographAlgorithm::AES)?;

    sdk.get_aes_key_handle(&key_label)?;

    Ok(())
}

#[ignore]
#[test]
#[serial]
fn it_test_encrypt_decrypt() -> Result<()> {
    let start = Instant::now();
    let sdk = get_sdk()?;
    println!("Time elapsed after get_sdk(): {:?}", start.elapsed());

    let key_label = KeyLabel::from_short(&AES_KEY_LABEL, CryptographAlgorithm::AES)?;

    let data = b"encrypt me";

    let aad = b"additional data";

    let encrypted = sdk.encrypt(&key_label, data, aad)?;
    println!("Time elapsed after encrypt(): {:?}; ciphertext: {}", start.elapsed(), hex::encode(&encrypted));

    let decrypted = sdk.decrypt(&key_label, &encrypted, aad)?;
    println!("Time elapsed after decrypt(): {:?}", start.elapsed());

    assert_eq!(decrypted, data);

    let data = b"encrypt me not";
    assert_ne!(decrypted, data);

    Ok(())
}

#[ignore]
#[test]
#[serial]
fn it_test_decrypt_fail_ciphertext_short() -> Result<()> {
    let start = Instant::now();
    let sdk = get_sdk()?;
    println!("Time elapsed after get_sdk(): {:?}", start.elapsed());

    let key_label = KeyLabel::from_short(&AES_KEY_LABEL, CryptographAlgorithm::AES)?;

    let aad = b"additional data";

    let ct = vec![0u8; 10];

    let decrypted = sdk.decrypt(&key_label, &ct, aad);

    assert!(decrypted.is_err());

    if let Err(e) = decrypted {
        assert!(
            matches!(e, pkcs11_sdk::Error::GenericError(ref msg) if msg == "ciphertext is too short")
        );
        Ok(())
    } else {
        Err(Error::GenericError("unexpected error".to_string()))
    }
}
