use cryptoki::context::{CInitializeArgs, Pkcs11};
use cryptoki::session::UserType;
use cryptoki::slot::Slot;
use cryptoki::types::AuthPin;
use lazy_static::lazy_static;
use once_cell::sync::OnceCell;
use pkcs11_sdk::{Error, KeyLabel, Result, SDKContext, SDK};
use kms_common::types::CryptographAlgorithm;
use std::env;
use std::sync::Mutex;
use std::sync::Once;

pub static ENV_SOFTHSM2_CONF: &str = "SOFTHSM2_CONF";
pub static SOFTHSM2_CONF: &str = "./lib/softhsm2.conf";
pub static ENV_MODULE: &str = "PKCS11_SOFTHSM2_MODULE";
#[cfg(target_os = "macos")]
pub static MODULE: &str = "./lib/libsofthsm2-mac.so";
#[cfg(target_os = "linux")]
pub static MODULE: &str = "./lib/libsofthsm2-linux.so";
pub static USER_PIN: &str = "5678";
// The default SO pin
pub static SO_PIN: &str = "1234";
pub static TOKEN_LABEL: &str = "Slot Token 0";

#[allow(unused)]
pub static mut KEY_GENED: Mutex<bool> = Mutex::new(false);

lazy_static! {
    pub static ref ED_KEY_LABEL: String = format!("{}/{}", TOKEN_LABEL, "test/ed25519/1");
    pub static ref K256_KEY_LABEL: String = format!("{}/{}", TOKEN_LABEL, "test/secp256k1/1");
    pub static ref P256_KEY_LABEL: String = format!("{}/{}", TOKEN_LABEL, "test/secp256r1/1");
    pub static ref RSA_KEY_LABEL: String = format!("{}/{}", TOKEN_LABEL, "test/rsa2048/1");
    pub static ref AES_KEY_LABEL: String = format!("{}/{}", TOKEN_LABEL, "test/aes/1");
}
/*
Ideally, we just use SDK's init_sdk(...) to get the SDKContext.
But that assume token is already initialized.
So here we have our test-version of init_sdk_test(...).
We need to add token initialization to init_sdk_test(...) and
the rest of code is pretty much the same.
*/
#[allow(unused)]
struct Init {
    ctx: SDKContext,
    _sdk: Mutex<SDK>,
}

static INIT_CALL: Once = Once::new();
#[allow(unused)]
static INIT_CELL: OnceCell<Init> = OnceCell::new();

fn init_test_sdk() -> Result<&'static SDKContext> {
    init_config();

    let init = INIT_CELL.get_or_try_init(|| {
        print!("init_test_sdk - inside calling init_pins\n");
        let (p11, slot) = init_pins()?;

        let ctx = SDKContext::new_with_slot(p11, slot);

        // let sdk = SDK::from_context_with_login(&ctx, pin)?;
        let mut sdk = SDK::from_context(&ctx)?;
        sdk.login(USER_PIN)?;

        Ok(Init {
            ctx,
            _sdk: Mutex::new(sdk),
        })
    });

    init.map(|i| &i.ctx)
}

pub fn get_test_ctx() -> Result<&'static SDKContext> {
    let ctx = init_test_sdk()?;

    Ok(ctx)
}
pub fn get_test_sdk() -> Result<SDK> {
    let ctx = get_test_ctx()?;
    let mut sdk = SDK::from_context(&ctx)?;

    if !sdk.is_authorized() {
        sdk.login(USER_PIN)?;
    }

    Ok(sdk)
}
pub fn get_test_pkcs11() -> Result<Pkcs11> {
    // Pkcs11::new(
    //     env::var(ENV_MODULE)
    //         .unwrap_or_else(|_| MODULE.to_string()),
    // )
    //     .map_err(|e| Error::from(e))
    Pkcs11::new(MODULE.to_string()).map_err(|e| Error::from(e))
}

pub fn init_config() {
    INIT_CALL.call_once(|| {
        env::set_var(ENV_SOFTHSM2_CONF, SOFTHSM2_CONF);
        env::set_var(ENV_MODULE, MODULE);
    });
}

pub fn init_pins() -> Result<(Pkcs11, Slot)> {
    init_config();

    let pkcs11 = get_test_pkcs11()?;

    // initialize the library
    pkcs11.initialize(CInitializeArgs::OsThreads)?;

    // find a slot, get the first one
    let slot = pkcs11.get_slots_with_token()?.remove(0);

    let so_pin = AuthPin::new(SO_PIN.into());
    pkcs11.init_token(slot, &so_pin, TOKEN_LABEL)?;

    {
        // open a session
        let session = pkcs11.open_rw_session(slot)?;
        // log in the session
        session.login(UserType::So, Some(&so_pin))?;
        session.init_pin(&AuthPin::new(USER_PIN.into()))?;
    };

    Ok((pkcs11, slot))
}

#[allow(dead_code)]
pub fn keygen() -> Result<()> {
    unsafe {
        if *KEY_GENED.lock()? {
            return Ok(());
        }
    }
    let sdk = get_test_sdk()?;

    // test keygen for ed25519
    let mut key_label = KeyLabel::from_short(&ED_KEY_LABEL, CryptographAlgorithm::Ed25519)?;

    let persistent = true;

    let (_, _, _) = sdk.keygen(&mut key_label, persistent)?;

    // test keygen for k256
    let mut key_label = KeyLabel::from_short(&K256_KEY_LABEL, CryptographAlgorithm::Secp256k1)?;

    let persistent = true;

    let (_, _, _) = sdk.keygen(&mut key_label, persistent)?;

    // test keygen for k256 2
    // with same lable, sdk will generate version 2
    let mut key_label = KeyLabel::from_short(&K256_KEY_LABEL, CryptographAlgorithm::Secp256k1)?;

    let persistent = true;

    let (_, _, _) = sdk.keygen(&mut key_label, persistent)?;

    // test keygen for p256
    let mut key_label = KeyLabel::from_short(&P256_KEY_LABEL, CryptographAlgorithm::Secp256r1)?;

    let persistent = true;

    let (_, _, _) = sdk.keygen(&mut key_label, persistent)?;

    // test keygen for rsa2048
    let mut key_label = KeyLabel::from_short(&RSA_KEY_LABEL, CryptographAlgorithm::RSA2048)?;

    let persistent = true;

    let (_, _, _) = sdk.keygen(&mut key_label, persistent)?;

    // test aes 1
    let mut key_label = KeyLabel::from_short(&AES_KEY_LABEL, CryptographAlgorithm::AES)?;
    let persistent = true;

    let created = sdk.aes_keygen(&mut key_label, persistent)?;

    let got_handle = sdk.get_aes_key_handle(&key_label)?;

    assert_eq!(created.0, got_handle);

    // test aes 2
    // with same lable, sdk will generate version 2
    let mut key_label = KeyLabel::from_short(&AES_KEY_LABEL, CryptographAlgorithm::AES)?;
    let persistent = true;

    let created = sdk.aes_keygen(&mut key_label, persistent)?;

    let got_handle = sdk.get_aes_key_handle(&key_label)?;

    assert_eq!(created.0, got_handle);

    sdk.close()?;

    unsafe {
        KEY_GENED = Mutex::from(true);
    }

    Ok(())
}
