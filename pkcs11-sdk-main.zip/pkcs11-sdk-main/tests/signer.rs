use std::str::FromStr;
use std::sync::{Arc, Mutex};
use cosmos_grpc_client::{cosmos_sdk_proto::cosmos::{bank::v1beta1::MsgSend, base::v1beta1::Coin as ProtoCoin}, BroadcastMode, CoinType, GrpcClient, ProstMsgNameToAny};
use serial_test::serial;
use pkcs11_sdk::KeyLabel;
use pkcs11_sdk::signer::P11Signer;
use crate::common::{get_sdk, CHAIN_GRPC, CHAIN_PREFIX, DENOM, FAUCET_KEY_LABEL, GAS_ADJUSTMENT, GAS_PRICE, STAKE_DENOM, USER1_KEY_LABEL, USER2_KEY_LABEL};
use cosmos_wallet::cosmos_async_wallet;
use cosmrs::crypto::PublicKey;
use cosmrs::{Coin, Denom};
use cosmwasm_std::Decimal;
use k256::Secp256k1;
use kms_commom::async_signer::AsyncSigningKey;
use kms_commom::types::CryptographAlgorithm;

mod common;

#[ignore]
#[serial]
#[tokio::test(flavor = "multi_thread")]
async fn it_wallet_tx() -> pkcs11_sdk::Result<()> {
    let sdk = get_sdk()?;
    
    let kl_user1 = KeyLabel::from_short(&USER1_KEY_LABEL, CryptographAlgorithm::Secp256k1)?;
    let kl_user2 = KeyLabel::from_short(&USER2_KEY_LABEL, CryptographAlgorithm::Secp256k1)?;
    let kl_faucet = KeyLabel::from_short(&FAUCET_KEY_LABEL, CryptographAlgorithm::Secp256k1)?;
    
    let user2_acct = PublicKey::from(sdk.get_ec_public_key::<Secp256k1>(&kl_user2)?).account_id(CHAIN_PREFIX).unwrap();
    let faucet_acct = PublicKey::from(sdk.get_ec_public_key::<Secp256k1>(&kl_faucet)?).account_id(CHAIN_PREFIX).unwrap();
    
    let p11signer = P11Signer::new(Arc::new(Mutex::new(sdk)), kl_user1);

    let client = GrpcClient::new(CHAIN_GRPC).await?;

    let mut wallet = cosmos_async_wallet::Wallet::from_async_signing_key(
        client,
        AsyncSigningKey::new(Box::new(p11signer)),
        CHAIN_PREFIX,                       // Chain prefix
        CoinType::Cosmos, // = 118           // Coin type, use CoinType enum or any u64 number
        Decimal::from_str(GAS_PRICE).unwrap(), // Gas_price
        Decimal::from_str(GAS_ADJUSTMENT).unwrap(), // Gas adjustment
        STAKE_DENOM,
    )
        .await?;

    let msg = MsgSend {
        from_address: wallet.account_address(),
        to_address: user2_acct.to_string(),
        amount: vec![ProtoCoin {
            denom: DENOM.to_string(),
            amount: "100".to_string(),
        }],
    }
        .build_any();

    let sim = wallet
        .simulate_tx(vec![msg.clone()])
        .await?;

    let gas_used = Decimal::from_str(&sim.gas_info.unwrap().gas_used.to_string()).unwrap();

    let fee = cosmrs::tx::Fee {
        amount: vec![Coin {
            denom: Denom::from_str(STAKE_DENOM).unwrap(),
            amount: Decimal::one().to_uint_ceil().u128(),
        }],
        gas_limit: (gas_used * Decimal::from_str("2.0").unwrap() - Decimal::one())
            .to_uint_ceil()
            .u128() as u64,
        payer: None,
        granter: Some(cosmrs::AccountId::from_str(&faucet_acct.to_string()).unwrap()),
    };
    /*
    let fee = if SIMULATE_TX {
        None
    } else {
        Some(Fee::from_amount_and_gas(
            Coin {
                denom: Denom::from_str(STAKE_DENOM).unwrap(),
                amount: Amount::from(GAS_FEE),
            },
            GAS_LIMIT,
        ))
    };
    */
    let response = wallet
        .broadcast_tx(
            vec![msg],           // Vec<Any>: list of msgs to broadcast
            Some(fee), // fee: Option<Fee>, if not provided the tx is simulated to calculate the fee
            None,      // memo: Option<String>
            BroadcastMode::Sync, // Broadcast mode; Block/Sync/Async
        )
        .await?;

    println!("response: {response:#?}");
    
    Ok(())
    
}