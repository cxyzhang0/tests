use crate::integration_common::{
    get_test_ctx, get_test_sdk, keygen, AES_KEY_LABEL, ED_KEY_LABEL, K256_KEY_LABEL,
    P256_KEY_LABEL, RSA_KEY_LABEL, TOKEN_LABEL, USER_PIN,
};
use cryptoki::mechanism::MechanismType;
use ecdsa::signature::Verifier;
use ecdsa::Signature as EcSignature;
use k256::Secp256k1;
use p256::NistP256;
use pkcs11_sdk::{secure_hash, CryptographAlgorithm, Error, KeyLabel, Result, SDK};
use serial_test::serial;
use sha2::{Digest, Sha256, Sha512};
use signature::hazmat::PrehashVerifier;

mod integration_common;

#[test]
#[serial]
fn it_get_mechanism_list() -> Result<()> {
    let ctx = get_test_ctx()?;

    let ml = ctx.get_mechanism_list()?;

    println!("mechanism list: {:#?}", ml);

    Ok(())
}

#[test]
#[serial]
fn it_get_mechanism_info() -> Result<()> {
    let ctx = get_test_ctx()?;

    let mi = ctx.get_mechanism_info(MechanismType::AES_GCM)?;

    println!("mechanism list: {:#?}", mi);

    Ok(())
}

#[test]
#[serial]
fn it_get_slot() -> Result<()> {
    let ctx = get_test_ctx()?;

    let _slot = ctx.find_slot_by_label(TOKEN_LABEL)?;

    Ok(())
}

#[test]
#[serial]
fn it_fn_sdk_from_context_with_login() -> Result<()> {
    let ctx = get_test_ctx()?;

    SDK::from_context_with_login(ctx, USER_PIN)?;

    Ok(())
}

#[test]
#[serial]
fn it_fn_sdk_from_context_with_login_ok_invalid_pin() -> Result<()> {
    let sdk = get_test_sdk()?;
    sdk.logout()?;

    let ctx = get_test_ctx()?;

    let res = SDK::from_context_with_login(ctx, "bad pin");

    assert!(res.is_err());

    Ok(())
}

#[test]
#[serial]
fn it_fn_sdk_is_authorized_fail() -> Result<()> {
    let ctx = get_test_ctx()?;

    let sdk = SDK::from_context(ctx)?;

    sdk.logout()?;

    assert!(!sdk.is_authorized());

    Ok(())
}

#[test]
#[serial]
fn it_fn_sdk_keygen_not_authorized() -> Result<()> {
    let ctx = get_test_ctx()?;

    let sdk = SDK::from_context(ctx)?;

    sdk.logout()?;

    let mut key_label = KeyLabel::from_short(&ED_KEY_LABEL, CryptographAlgorithm::Ed25519)?;

    if let Err(e) = sdk.keygen(&mut key_label, false) {
        assert!(matches!(e, Error::NotAuthorized));
        Ok(())
    } else {
        Err(Error::GenericError("Should not happen".to_string()))
    }
}

#[test]
#[serial]
fn it_fn_sdk_sign_not_authorized() -> Result<()> {
    let ctx = get_test_ctx()?;

    let sdk = SDK::from_context(ctx)?;

    sdk.logout()?;

    let mut key_label = KeyLabel::from_short(&ED_KEY_LABEL, CryptographAlgorithm::Ed25519)?;

    if let Err(e) = sdk.sign(&mut key_label, b"sign me") {
        assert!(matches!(e, Error::NotAuthorized));
        Ok(())
    } else {
        Err(Error::GenericError("Should not happen".to_string()))
    }
}

#[test]
#[serial]
fn it_fn_sdk_get_public_key_ec_point_not_authorized() -> Result<()> {
    let ctx = get_test_ctx()?;

    let sdk = SDK::from_context(ctx)?;

    sdk.logout()?;

    let mut key_label = KeyLabel::from_short(&ED_KEY_LABEL, CryptographAlgorithm::Ed25519)?;

    if let Err(e) = sdk.get_public_key_ec_point(&mut key_label) {
        assert!(matches!(e, Error::NotAuthorized));
        Ok(())
    } else {
        Err(Error::GenericError("Should not happen".to_string()))
    }
}

#[test]
#[serial]
fn it_fn_sdk_get_public_key_ec_point_oid_not_authorized() -> Result<()> {
    let ctx = get_test_ctx()?;

    let sdk = SDK::from_context(ctx)?;

    sdk.logout()?;

    let mut key_label = KeyLabel::from_short(&ED_KEY_LABEL, CryptographAlgorithm::Ed25519)?;

    if let Err(e) = sdk.get_public_key_ec_point_oid(&mut key_label) {
        assert!(matches!(e, Error::NotAuthorized));
        Ok(())
    } else {
        Err(Error::GenericError("Should not happen".to_string()))
    }
}

#[test]
#[serial]
fn it_fn_sdk_get_public_key_ec_point_oid_no_key_handle() -> Result<()> {
    let sdk = get_test_sdk()?;

    let mut key_label = KeyLabel::from_short(
        &format!("{}/{}", TOKEN_LABEL, "test/badalgo/1"),
        CryptographAlgorithm::Ed25519,
    )?;

    let res = sdk.get_public_key_ec_point_oid(&mut key_label);

    assert!(res.is_err());

    Ok(())
}

#[test]
#[serial]
fn it_keygen() -> Result<()> {
    keygen()
}

#[test]
#[serial]
fn it_get_pub_key_handle() -> Result<()> {
    keygen()?;

    let sdk = get_test_sdk()?;
    // ed25519
    let key_label = KeyLabel::from_short(&ED_KEY_LABEL, CryptographAlgorithm::Ed25519)?;

    let res = sdk.get_key_handle(&key_label, true);

    assert!(
        res.is_ok(),
        "Can not find public key for {} {:?}",
        ED_KEY_LABEL.to_string(),
        res
    );
    // k256
    let key_label = KeyLabel::from_short(&K256_KEY_LABEL, CryptographAlgorithm::Secp256k1)?;

    let res = sdk.get_key_handle(&key_label, true);

    assert!(
        res.is_ok(),
        "Can not find public key for {} {:?}",
        K256_KEY_LABEL.to_string(),
        res
    );
    // p256
    let key_label = KeyLabel::from_short(&P256_KEY_LABEL, CryptographAlgorithm::Secp256r1)?;

    let res = sdk.get_key_handle(&key_label, true);

    assert!(
        res.is_ok(),
        "Can not find public key for {} {:?}",
        P256_KEY_LABEL.to_string(),
        res
    );
    // rsa
    let key_label = KeyLabel::from_short(&RSA_KEY_LABEL, CryptographAlgorithm::RSA2048)?;

    let res = sdk.get_key_handle(&key_label, true);

    assert!(
        res.is_ok(),
        "Can not find public key for {} {:?}",
        RSA_KEY_LABEL.to_string(),
        res
    );

    sdk.close()?;
    Ok(())
}

#[test]
#[serial]
fn it_get_priv_key_handle() -> Result<()> {
    keygen()?;

    let sdk = get_test_sdk()?;

    // ed25519
    let key_label = KeyLabel::from_short(&ED_KEY_LABEL, CryptographAlgorithm::Ed25519)?;

    let res = sdk.get_key_handle(&key_label, false);

    assert!(
        res.is_ok(),
        "Can not find private key for {} {:?}",
        ED_KEY_LABEL.to_string(),
        res
    );
    // k256
    let key_label = KeyLabel::from_short(&K256_KEY_LABEL, CryptographAlgorithm::Secp256k1)?;

    let res = sdk.get_key_handle(&key_label, false);

    assert!(
        res.is_ok(),
        "Can not find private key for {} {:?}",
        K256_KEY_LABEL.to_string(),
        res
    );
    // p256
    let key_label = KeyLabel::from_short(&P256_KEY_LABEL, CryptographAlgorithm::Secp256r1)?;

    let res = sdk.get_key_handle(&key_label, false);

    assert!(
        res.is_ok(),
        "Can not find private key for {} {:?}",
        P256_KEY_LABEL.to_string(),
        res
    );
    // rsa
    let key_label = KeyLabel::from_short(&RSA_KEY_LABEL, CryptographAlgorithm::RSA2048)?;

    let res = sdk.get_key_handle(&key_label, false);

    assert!(
        res.is_ok(),
        "Can not find private key for {} {:?}",
        RSA_KEY_LABEL.to_string(),
        res
    );

    sdk.close()?;
    Ok(())
}

#[test]
#[serial]
fn it_get_pub_key_ec_point() -> Result<()> {
    keygen()?;

    let sdk = get_test_sdk()?;

    // ed25519
    let key_label = KeyLabel::from_short(&ED_KEY_LABEL, CryptographAlgorithm::Ed25519)?;

    let ec_point = sdk.get_public_key_ec_point(&key_label)?;
    let l = ec_point.len();

    assert!(l == 32 || l == 34);

    // k256
    let key_label = KeyLabel::from_short(&K256_KEY_LABEL, CryptographAlgorithm::Secp256k1)?;

    let ec_point = sdk.get_public_key_ec_point(&key_label)?;
    let l = ec_point.len();

    assert_eq!(l, 67, "len {} is incorrect", l);

    // p256
    let key_label = KeyLabel::from_short(&P256_KEY_LABEL, CryptographAlgorithm::Secp256r1)?;

    let ec_point = sdk.get_public_key_ec_point(&key_label)?;
    let l = ec_point.len();

    assert_eq!(l, 67, "len {} is incorrect", l);

    sdk.close()?;
    Ok(())
}

#[test]
#[serial]
fn it_sign_verify_ed25519() -> Result<()> {
    keygen()?;

    let sdk = get_test_sdk()?;

    let key_label = KeyLabel::from_short(&ED_KEY_LABEL, CryptographAlgorithm::Ed25519)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();

    // sign data
    let sig = sdk.sign(&key_label, data)?;
    // verify sig - positive
    assert!(sdk.verify_sig(&key_label, data, &sig).is_ok());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    assert!(sdk.verify_sig(&key_label, data, &sig).is_err());
    sdk.close()?;
    Ok(())
}

#[test]
#[serial]
fn it_sign_verify_secp256k1() -> Result<()> {
    keygen()?;

    let sdk = get_test_sdk()?;

    let key_label = KeyLabel::from_short(&K256_KEY_LABEL, CryptographAlgorithm::Secp256k1)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();
    let hash = secure_hash(data);

    // sign data
    let sig = sdk.sign(&key_label, &hash[..])?;

    // verify sig - positive
    assert!(sdk.verify_sig(&key_label, &hash[..], &sig).is_ok());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    let hash = secure_hash(data);

    assert!(sdk.verify_sig(&key_label, &hash[..], &sig).is_err());

    sdk.close()?;
    Ok(())
}

#[test]
#[serial]
fn it_sign_verify_secp256r1() -> Result<()> {
    keygen()?;

    let sdk = get_test_sdk()?;

    let key_label = KeyLabel::from_short(&P256_KEY_LABEL, CryptographAlgorithm::Secp256r1)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();
    let hash = secure_hash(data);

    // sign data
    let sig = sdk.sign(&key_label, &hash[..])?;

    // verify sig - positive
    assert!(sdk.verify_sig(&key_label, &hash[..], &sig).is_ok());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    let hash = secure_hash(data);
    assert!(sdk.verify_sig(&key_label, &hash[..], &sig).is_err());

    sdk.close()?;
    Ok(())
}

#[test]
#[serial]
fn it_sign_verify_rsa2048() -> Result<()> {
    keygen()?;

    let sdk = get_test_sdk()?;

    let key_label = KeyLabel::from_short(&RSA_KEY_LABEL, CryptographAlgorithm::RSA2048)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();
    let hash = secure_hash(data);
    // let mut hasher = Sha256::new();
    // hasher.update(data);
    // let hash = hasher.finalize();
    // sign data
    let sig = sdk.sign(&key_label, &hash[..])?;

    // verify sig - positive
    assert!(sdk.verify_sig(&key_label, &hash[..], &sig).is_ok());

    // verify sig - positive
    let data = "sign me not".as_bytes();
    let hash = secure_hash(data);
    // let mut hasher = Sha256::new();
    // hasher.update(data);
    // let hash = hasher.finalize();
    assert!(sdk.verify_sig(&key_label, &hash[..], &sig).is_err());

    sdk.close()?;
    Ok(())
}

#[test]
#[serial]
fn it_sign_verify_sig_ed25519_outside_hsm() -> Result<()> {
    keygen()?;

    let sdk = get_test_sdk()?;

    let key_label = KeyLabel::from_short(&ED_KEY_LABEL, CryptographAlgorithm::Ed25519)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();

    // sign data
    let sig = sdk.sign_eddsa(&key_label, data)?;

    // verify sig - positive
    assert!(sdk
        .verify_sig_ed_outside_hsm(&key_label, data, &sig)
        .is_ok());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    assert!(sdk
        .verify_sig_ed_outside_hsm(&key_label, data, &sig)
        .is_err());

    sdk.close()?;
    Ok(())
}

#[test]
#[serial]
fn it_sign_verify_sig_secp256k1_outside_hsm_generic() -> Result<()> {
    keygen()?;

    let sdk = get_test_sdk()?;

    let key_label = KeyLabel::from_short(&K256_KEY_LABEL, CryptographAlgorithm::Secp256k1)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();

    // sign_ecdsa will hash the data before signing.
    // let hash = secure_hash(data);

    // sign data
    let sig = sdk.sign_ecdsa::<Secp256k1>(&key_label, data)?;

    // verify sig - positive
    assert!(sdk
        .verify_ec_outside_hsm::<Secp256k1>(&key_label, data, &sig)
        .is_ok());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    assert!(sdk
        .verify_ec_outside_hsm::<Secp256k1>(&key_label, data, &sig)
        .is_err());

    // this also works
    /*
        let public_key = sdk.get_ec_public_key::<Secp256k1>(&key_label)?;
        // verify sig - positive
        assert!(public_key.verify(&data[..], &sig).is_ok());

        // verify sig - negative
        let data = "sign me not".as_bytes();
        assert!(public_key.verify(&data[..], &sig).is_err());
    */

    sdk.close()?;
    Ok(())
}

#[test]
#[serial]
fn it_sign_verify_sig_secp256k1_outside_hsm() -> Result<()> {
    keygen()?;

    let sdk = get_test_sdk()?;

    let key_label = KeyLabel::from_short(&K256_KEY_LABEL, CryptographAlgorithm::Secp256k1)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();

    // sign_ecdsa will hash the data before signing.
    // let hash = secure_hash(data);

    // sign data
    let sig = sdk.sign_ecdsa::<Secp256k1>(&key_label, data)?;

    // verify sig - positive
    assert!(sdk
        .verify_sig_k256_outside_hsm(&key_label, data, &sig)
        .is_ok());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    assert!(sdk
        .verify_sig_k256_outside_hsm(&key_label, data, &sig)
        .is_err());

    // this also works
    /*
        let public_key = sdk.get_ec_public_key::<Secp256k1>(&key_label)?;
        // verify sig - positive
        assert!(public_key.verify(&data[..], &sig).is_ok());

        // verify sig - negative
        let data = "sign me not".as_bytes();
        assert!(public_key.verify(&data[..], &sig).is_err());
    */

    sdk.close()?;
    Ok(())
}

#[test]
#[serial]
fn it_sign_verify_sig_secp256r1_outside_hsm_generic() -> Result<()> {
    keygen()?;

    let sdk = get_test_sdk()?;

    let key_label = KeyLabel::from_short(&P256_KEY_LABEL, CryptographAlgorithm::Secp256r1)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();

    // sign_ecdsa will hash the data before signing.
    // let hash = secure_hash(data);

    // sign data
    let sig = sdk.sign_ecdsa::<NistP256>(&key_label, data)?;

    // verify sig - positive
    assert!(sdk
        .verify_ec_outside_hsm::<NistP256>(&key_label, data, &sig)
        .is_ok());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    assert!(sdk
        .verify_ec_outside_hsm::<NistP256>(&key_label, data, &sig)
        .is_err());

    /*
        let public_key = sdk.get_ec_public_key::<NistP256>(&key_label)?;
        // verify sig - positive
        assert!(public_key.verify(&data[..], &sig).is_ok());

        // verify sig - negative
        let data = "sign me not".as_bytes();
        assert!(public_key.verify(&data[..], &sig).is_err());
    */

    sdk.close()?;
    Ok(())
}

#[test]
#[serial]
fn it_sign_verify_sig_secp256r1_outside_hsm() -> Result<()> {
    keygen()?;

    let sdk = get_test_sdk()?;

    let key_label = KeyLabel::from_short(&P256_KEY_LABEL, CryptographAlgorithm::Secp256r1)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();

    // sign_ecdsa will hash the data before signing.
    // let hash = secure_hash(data);

    // sign data
    let sig = sdk.sign_ecdsa::<NistP256>(&key_label, data)?;

    // verify sig - positive
    assert!(sdk.verify_p256_outside_hsm(&key_label, data, &sig).is_ok());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    assert!(sdk.verify_p256_outside_hsm(&key_label, data, &sig).is_err());

    /*
        let public_key = sdk.get_ec_public_key::<NistP256>(&key_label)?;
        // verify sig - positive
        assert!(public_key.verify(&data[..], &sig).is_ok());

        // verify sig - negative
        let data = "sign me not".as_bytes();
        assert!(public_key.verify(&data[..], &sig).is_err());
    */

    sdk.close()?;
    Ok(())
}

#[test]
#[serial]
fn it_sign_verify_prehash_sig_secp256k1_outside_hsm() -> Result<()> {
    keygen()?;

    let sdk = get_test_sdk()?;

    let key_label = KeyLabel::from_short(&K256_KEY_LABEL, CryptographAlgorithm::Secp256k1)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();

    // sign_ecdsa will hash the data before signing.
    let hash = secure_hash(data);

    // sign data
    let sig = sdk.sign_ecdsa::<Secp256k1>(&key_label, data)?;

    // verify sig - positive
    assert!(sdk
        .verify_prehash_ec_outside_hsm::<Secp256k1>(&key_label, &hash[..], &sig)
        .is_ok());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    let hash = secure_hash(data);
    assert!(sdk
        .verify_prehash_ec_outside_hsm::<Secp256k1>(&key_label, &hash[..], &sig)
        .is_err());

    // this also works
    /*
        let public_key = sdk.get_ec_public_key::<Secp256k1>(&key_label)?;
        // verify sig - positive
        assert!(public_key.verify(&data[..], &sig).is_ok());

        // verify sig - negative
        let data = "sign me not".as_bytes();
        assert!(public_key.verify(&data[..], &sig).is_err());
    */

    sdk.close()?;
    Ok(())
}

#[test]
#[serial]
fn it_sign_verify_prehash_sig_secp256r1_outside_hsm() -> Result<()> {
    keygen()?;

    let sdk = get_test_sdk()?;

    let key_label = KeyLabel::from_short(&P256_KEY_LABEL, CryptographAlgorithm::Secp256r1)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();
    let hash = secure_hash(data);

    // sign data
    let sig = sdk.sign_ecdsa::<NistP256>(&key_label, &hash[..])?;

    // verify sig - positive
    assert!(sdk
        .verify_ec_outside_hsm::<NistP256>(&key_label, &hash[..], &sig)
        .is_ok());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    let hash = secure_hash(data);
    assert!(sdk
        .verify_prehash_ec_outside_hsm::<NistP256>(&key_label, &hash[..], &sig)
        .is_err());

    sdk.close()?;
    Ok(())
}

#[test]
#[serial]
fn it_sign_verify_sig_secp256k1_outside_hsm_integrated() -> Result<()> {
    keygen()?;

    let sdk = get_test_sdk()?;

    let key_label = KeyLabel::from_short(&K256_KEY_LABEL, CryptographAlgorithm::Secp256k1)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();
    // Only Sha256 will work. Sha384 and Sha512 will not work.
    let mut hasher = Sha256::new();
    hasher.update(data);
    let hash = hasher.finalize();

    // sign data
    let sig = sdk.sign(&key_label, &hash[..])?;

    println!("raw sig: {:?}", hex::encode(&sig));

    let sig = EcSignature::<Secp256k1>::from_slice(&sig).unwrap();
    let sig = if let Some(sig) = sig.normalize_s() {
        sig
    } else {
        sig
    };
    let public_key = sdk.get_k256_public_key(&key_label)?;
    assert!(public_key.verify(&data[..], &sig).is_ok());
    sdk.close()?;
    Ok(())
}

#[test]
#[serial]
fn it_sign_verify_prehash_sig_secp256k1_outside_hsm_integrated() -> Result<()> {
    keygen()?;

    let sdk = get_test_sdk()?;

    let key_label = KeyLabel::from_short(&K256_KEY_LABEL, CryptographAlgorithm::Secp256k1)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();
    // any of Sha256, Sha384, Sha512 will will work
    let mut hasher = Sha512::new();
    hasher.update(data);
    let hash = hasher.finalize();

    // sign data
    let sig = sdk.sign(&key_label, &hash[..])?;

    println!("raw sig: {:?}", hex::encode(&sig));

    let sig = EcSignature::<Secp256k1>::from_slice(&sig).unwrap();
    let sig = if let Some(sig) = sig.normalize_s() {
        sig
    } else {
        sig
    };
    // let sig2 = sig1.normalize_s();
    // let sig1 = if sig2.is_some() { sig2.unwrap() } else { sig1 };
    let public_key = sdk.get_k256_public_key(&key_label)?;
    assert!(public_key.verify_prehash(&hash[..], &sig).is_ok());
    /*
        sdk.verify_sig_ec_outside_hsm(&key_label, data, &sig).map_err(|e| {
            println!("error: {:?}", e);
            e
        })?;
        // verify sig - positive
        assert!(sdk.verify_sig_ec_outside_hsm(&key_label, data, &sig).is_ok());

        // verify sig - negative
        let data = "sign me not".as_bytes();
        assert!(sdk.verify_sig_ec_outside_hsm(&key_label, data, &sig).is_err());
    */
    sdk.close()?;
    Ok(())
}

#[test]
#[serial]
fn it_test_encrypt_decrypt() -> Result<()> {
    keygen()?;

    let sdk = get_test_sdk()?;

    let key_label = KeyLabel::from_short(&AES_KEY_LABEL, CryptographAlgorithm::AES)?;

    let data = b"encrypt me";

    let aad = b"additional data";

    let encrypted = sdk.encrypt(&key_label, data, aad)?;

    let decrypted = sdk.decrypt(&key_label, &encrypted, aad)?;

    assert_eq!(decrypted, data);

    let data = b"encrypt me not";
    assert_ne!(decrypted, data);

    Ok(())
}

#[test]
#[serial]
fn it_test_decrypt_fail_ciphertext_short() -> Result<()> {
    keygen()?;

    let sdk = get_test_sdk()?;

    let key_label = KeyLabel::from_short(&AES_KEY_LABEL, CryptographAlgorithm::AES)?;

    let aad = b"additional data";

    let ct = vec![0u8; 10];

    let decrypted = sdk.decrypt(&key_label, &ct, aad);

    assert!(decrypted.is_err());

    if let Err(e) = decrypted {
        assert!(
            matches!(e, pkcs11_sdk::Error::GenericError(ref msg) if msg == "ciphertext is too short")
        );
        Ok(())
    } else {
        Err(Error::GenericError("unexpected error".to_string()))
    }
}

#[test]
#[serial]
fn it_p11() -> Result<()> {
    let p11 = get_test_ctx()?;

    p11.p11();

    Ok(())
}

#[test]
#[serial]
fn it_slot() -> Result<()> {
    let p11 = get_test_ctx()?;

    p11.slot();

    Ok(())
}

#[test]
#[serial]
fn it_find_slot_by_label() -> Result<()> {
    let p11 = get_test_ctx()?;

    assert!(p11.find_slot_by_label("bad slot label").is_err());

    Ok(())
}
