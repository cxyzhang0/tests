use cryptoki::mechanism::MechanismType;
use ecdsa::Signature as EcSignature;
use ecdsa::signature::Verifier;
use k256::Secp256k1;
use p256::NistP256;
use serial_test::serial;
use sha2::{Digest, Sha256, Sha512};
use signature::hazmat::PrehashVerifier;
use pkcs11_sdk::{Result, CryptographAlgorithm, KeyLabel, secure_hash, SDKContext, Error};
use crate::integration_common::{get_test_ctx, get_test_pkcs11, get_test_sdk, keygen, MODULE, TOKEN_LABEL, USER_PIN};

mod integration_common;

#[test]
#[serial]
fn it_get_mechanism_list() -> Result<()> {
    let ctx = get_test_ctx()?;

    let ml = ctx.get_mechanism_list()?;

    println!("mechanism list: {:#?}", ml);

    Ok(())
}

#[test]
#[serial]
fn it_get_mechanism_info() -> Result<()> {
    let ctx = get_test_ctx()?;

    let mi = ctx.get_mechanism_info(MechanismType::AES_GCM)?;

    println!("mechanism list: {:#?}", mi);

    Ok(())
}

#[test]
#[serial]
fn it_get_slot() -> Result<()> {
    let ctx = get_test_ctx()?;

    let _slot = ctx.find_slot_by_label(TOKEN_LABEL)?;

    Ok(())
}

#[test]
#[serial]
fn it_keygen() -> Result<()> {
    unsafe { keygen() }
}

#[test]
#[serial]
fn it_get_pub_key_handle() -> Result<()> {
    unsafe { keygen()?; }

    let sdk = get_test_sdk()?;
    // ed25519
    let kls = format!("{}/{}", TOKEN_LABEL, "test/ed25519/1");
    let key_label = KeyLabel::from_short(&kls, CryptographAlgorithm::Ed25519)?;

    let res = sdk.get_key_handle(&key_label, true);

    assert!(res.is_ok(), "Can not find public key for {} {:?}", kls, res);
    // k256
    let kls = format!("{}/{}", TOKEN_LABEL, "test/secp256k1/1");
    let key_label = KeyLabel::from_short(&kls, CryptographAlgorithm::Secp256k1)?;

    let res = sdk.get_key_handle(&key_label, true);

    assert!(res.is_ok(), "Can not find public key for {} {:?}", kls, res);
    // p256
    let kls = format!("{}/{}", TOKEN_LABEL, "test/secp256r1/1");
    let key_label = KeyLabel::from_short(&kls, CryptographAlgorithm::Secp256k1)?;

    let res = sdk.get_key_handle(&key_label, true);

    assert!(res.is_ok(), "Can not find public key for {} {:?}", kls, res);
    // rsa
    let kls = format!("{}/{}", TOKEN_LABEL, "test/rsa2048/1");
    let key_label = KeyLabel::from_short(&kls, CryptographAlgorithm::RSA2048)?;

    let res = sdk.get_key_handle(&key_label, true);

    assert!(res.is_ok(), "Can not find public key for {} {:?}", kls, res);

    sdk.close()?;
    Ok(())
}

#[test]
#[serial]
fn it_get_priv_key_handle() -> Result<()> {
    unsafe { keygen()?; }

    let sdk = get_test_sdk()?;

    // ed25519
    let kls = format!("{}/{}", TOKEN_LABEL, "test/ed25519/1");
    let key_label = KeyLabel::from_short(&kls, CryptographAlgorithm::Ed25519)?;

    let res = sdk.get_key_handle(&key_label, false);

    assert!(res.is_ok(), "Can not find private key for {} {:?}", kls, res);
    // k256
    let kls = format!("{}/{}", TOKEN_LABEL, "test/secp256k1/1");
    let key_label = KeyLabel::from_short(&kls, CryptographAlgorithm::Secp256k1)?;

    let res = sdk.get_key_handle(&key_label, false);

    assert!(res.is_ok(), "Can not find private key for {} {:?}", kls, res);
    // p256
    let kls = format!("{}/{}", TOKEN_LABEL, "test/secp256r1/1");
    let key_label = KeyLabel::from_short(&kls, CryptographAlgorithm::Secp256k1)?;

    let res = sdk.get_key_handle(&key_label, false);

    assert!(res.is_ok(), "Can not find private key for {} {:?}", kls, res);
    // rsa
    let kls = format!("{}/{}", TOKEN_LABEL, "test/rsa2048/1");
    let key_label = KeyLabel::from_short(&kls, CryptographAlgorithm::RSA2048)?;

    let res = sdk.get_key_handle(&key_label, false);

    assert!(res.is_ok(), "Can not find private key for {} {:?}", kls, res);

    sdk.close()?;
    Ok(())
}

#[test]
#[serial]
fn it_get_pub_key_ec_point() -> Result<()> {
    unsafe { keygen()?; }

    let sdk = get_test_sdk()?;

    // ed25519
    let kls = format!("{}/{}", TOKEN_LABEL, "test/ed25519/1");
    let key_label = KeyLabel::from_short(&kls, CryptographAlgorithm::Ed25519)?;

    let ec_point = sdk.get_public_key_ec_point(&key_label)?;
    let l = ec_point.len();

    assert!(l == 32 || l == 34);

    // k256
    let kls = format!("{}/{}", TOKEN_LABEL, "test/secp256k1/1");
    let key_label = KeyLabel::from_short(&kls, CryptographAlgorithm::Secp256k1)?;

    let ec_point = sdk.get_public_key_ec_point(&key_label)?;
    let l = ec_point.len();

    assert_eq!(l, 67, "len {} is incorrect", l);

    // p256
    let kls = format!("{}/{}", TOKEN_LABEL, "test/secp256r1/1");
    let key_label = KeyLabel::from_short(&kls, CryptographAlgorithm::Secp256r1)?;

    let ec_point = sdk.get_public_key_ec_point(&key_label)?;
    let l = ec_point.len();

    assert_eq!(l, 67, "len {} is incorrect", l);

    sdk.close()?;
    Ok(())
}

#[test]
#[serial]
fn it_sign_verify_ed25519() -> Result<()> {
    unsafe { keygen()?; }

    let sdk = get_test_sdk()?;

    let kls = format!("{}/{}", TOKEN_LABEL, "test/ed25519/1");
    let key_label = KeyLabel::from_short(&kls, CryptographAlgorithm::Ed25519)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();

    // sign data
    let sig = sdk.sign(&key_label, data)?;
    // verify sig - positive
    assert!(sdk.verify_sig(&key_label, data, &sig).is_ok());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    assert!(sdk.verify_sig(&key_label, data, &sig).is_err());
    sdk.close()?;
    Ok(())
}

#[test]
#[serial]
fn it_sign_verify_secp256k1() -> Result<()> {
    unsafe { keygen()?; }

    let sdk = get_test_sdk()?;

    let kls = format!("{}/{}", TOKEN_LABEL, "test/secp256k1/1");
    let key_label = KeyLabel::from_short(&kls, CryptographAlgorithm::Secp256k1)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();
    let hash = secure_hash(data);

    // sign data
    let sig = sdk.sign(&key_label, &hash[..])?;

    // verify sig - positive
    assert!(sdk.verify_sig(&key_label, &hash[..], &sig).is_ok());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    let hash = secure_hash(data);

    assert!(sdk.verify_sig(&key_label, &hash[..], &sig).is_err());

    sdk.close()?;
    Ok(())
}

#[test]
#[serial]
fn it_sign_verify_secp256r1() -> Result<()> {
    unsafe { keygen()?; }

    let sdk = get_test_sdk()?;

    let kls = format!("{}/{}", TOKEN_LABEL, "test/secp256r1/1");
    let key_label = KeyLabel::from_short(&kls, CryptographAlgorithm::Secp256r1)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();
    let hash = secure_hash(data);

    // sign data
    let sig = sdk.sign(&key_label, &hash[..])?;

    // verify sig - positive
    assert!(sdk.verify_sig(&key_label, &hash[..], &sig).is_ok());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    let hash = secure_hash(data);
    assert!(sdk.verify_sig(&key_label, &hash[..], &sig).is_err());

    sdk.close()?;
    Ok(())
}

#[test]
#[serial]
fn it_sign_verify_rsa2048() -> Result<()> {
    unsafe { keygen()?; }

    let sdk = get_test_sdk()?;

    let kls = format!("{}/{}", TOKEN_LABEL, "test/rsa2048/1");
    let key_label = KeyLabel::from_short(&kls, CryptographAlgorithm::RSA2048)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();
    let hash = secure_hash(data);
    // let mut hasher = Sha256::new();
    // hasher.update(data);
    // let hash = hasher.finalize();
    // sign data
    let sig = sdk.sign(&key_label, &hash[..])?;

    // verify sig - positive
    assert!(sdk.verify_sig(&key_label, &hash[..], &sig).is_ok());

    // verify sig - positive
    let data = "sign me not".as_bytes();
    let hash = secure_hash(data);
    // let mut hasher = Sha256::new();
    // hasher.update(data);
    // let hash = hasher.finalize();
    assert!(sdk.verify_sig(&key_label, &hash[..], &sig).is_err());

    sdk.close()?;
    Ok(())
}

#[test]
#[serial]
fn it_sign_verify_sig_ed25519_outside_hsm() -> Result<()> {
    unsafe { keygen()?; }

    let sdk = get_test_sdk()?;

    let kls = format!("{}/{}", TOKEN_LABEL, "test/ed25519/1");
    let key_label = KeyLabel::from_short(&kls, CryptographAlgorithm::Ed25519)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();

    // sign data
    let sig = sdk.sign_eddsa(&key_label, data)?;

    // verify sig - positive
    assert!(sdk.verify_sig_ed_outside_hsm(&key_label, data, &sig).is_ok());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    assert!(sdk.verify_sig_ed_outside_hsm(&key_label, data, &sig).is_err());

    sdk.close()?;
    Ok(())
}

#[test]
#[serial]
fn it_sign_verify_sig_secp256k1_outside_hsm_generic() -> Result<()> {
    unsafe { keygen()?; }

    let sdk = get_test_sdk()?;

    let kls = format!("{}/{}", TOKEN_LABEL, "test/secp256k1/1");
    let key_label = KeyLabel::from_short(&kls, CryptographAlgorithm::Secp256k1)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();

    // sign_ecdsa will hash the data before signing.
    // let hash = secure_hash(data);

    // sign data
    let sig = sdk.sign_ecdsa::<Secp256k1>(&key_label, data)?;

    // verify sig - positive
    assert!(sdk.verify_ec_outside_hsm::<Secp256k1>(&key_label, data, &sig).is_ok());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    assert!(sdk.verify_ec_outside_hsm::<Secp256k1>(&key_label, data, &sig).is_err());

    // this also works
    /*
        let public_key = sdk.get_ec_public_key::<Secp256k1>(&key_label)?;
        // verify sig - positive
        assert!(public_key.verify(&data[..], &sig).is_ok());

        // verify sig - negative
        let data = "sign me not".as_bytes();
        assert!(public_key.verify(&data[..], &sig).is_err());
    */

    sdk.close()?;
    Ok(())
}

#[test]
#[serial]
fn it_sign_verify_sig_secp256k1_outside_hsm() -> Result<()> {
    unsafe { keygen()?; }

    let sdk = get_test_sdk()?;

    let kls = format!("{}/{}", TOKEN_LABEL, "test/secp256k1/1");
    let key_label = KeyLabel::from_short(&kls, CryptographAlgorithm::Secp256k1)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();

    // sign_ecdsa will hash the data before signing.
    // let hash = secure_hash(data);

    // sign data
    let sig = sdk.sign_ecdsa::<Secp256k1>(&key_label, data)?;

    // verify sig - positive
    assert!(sdk.verify_sig_k256_outside_hsm(&key_label, data, &sig).is_ok());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    assert!(sdk.verify_sig_k256_outside_hsm(&key_label, data, &sig).is_err());

    // this also works
    /*
        let public_key = sdk.get_ec_public_key::<Secp256k1>(&key_label)?;
        // verify sig - positive
        assert!(public_key.verify(&data[..], &sig).is_ok());

        // verify sig - negative
        let data = "sign me not".as_bytes();
        assert!(public_key.verify(&data[..], &sig).is_err());
    */

    sdk.close()?;
    Ok(())
}

#[test]
#[serial]
fn it_sign_verify_sig_secp256r1_outside_hsm_generic() -> Result<()> {
    unsafe { keygen()?; }

    let sdk = get_test_sdk()?;

    let kls = format!("{}/{}", TOKEN_LABEL, "test/secp256r1/1");
    let key_label = KeyLabel::from_short(&kls, CryptographAlgorithm::Secp256r1)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();

    // sign_ecdsa will hash the data before signing.
    // let hash = secure_hash(data);

    // sign data
    let sig = sdk.sign_ecdsa::<NistP256>(&key_label, data)?;

    // verify sig - positive
    assert!(sdk.verify_ec_outside_hsm::<NistP256>(&key_label, data, &sig).is_ok());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    assert!(sdk.verify_ec_outside_hsm::<NistP256>(&key_label, data, &sig).is_err());

    /*
        let public_key = sdk.get_ec_public_key::<NistP256>(&key_label)?;
        // verify sig - positive
        assert!(public_key.verify(&data[..], &sig).is_ok());

        // verify sig - negative
        let data = "sign me not".as_bytes();
        assert!(public_key.verify(&data[..], &sig).is_err());
    */

    sdk.close()?;
    Ok(())
}

#[test]
#[serial]
fn it_sign_verify_sig_secp256r1_outside_hsm() -> Result<()> {
    unsafe { keygen()?; }

    let sdk = get_test_sdk()?;

    let kls = format!("{}/{}", TOKEN_LABEL, "test/secp256r1/1");
    let key_label = KeyLabel::from_short(&kls, CryptographAlgorithm::Secp256r1)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();

    // sign_ecdsa will hash the data before signing.
    // let hash = secure_hash(data);

    // sign data
    let sig = sdk.sign_ecdsa::<NistP256>(&key_label, data)?;

    // verify sig - positive
    assert!(sdk.verify_p256_outside_hsm(&key_label, data, &sig).is_ok());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    assert!(sdk.verify_p256_outside_hsm(&key_label, data, &sig).is_err());

    /*
        let public_key = sdk.get_ec_public_key::<NistP256>(&key_label)?;
        // verify sig - positive
        assert!(public_key.verify(&data[..], &sig).is_ok());

        // verify sig - negative
        let data = "sign me not".as_bytes();
        assert!(public_key.verify(&data[..], &sig).is_err());
    */

    sdk.close()?;
    Ok(())
}

#[test]
#[serial]
fn it_sign_verify_prehash_sig_secp256k1_outside_hsm() -> Result<()> {
    unsafe { keygen()?; }

    let sdk = get_test_sdk()?;

    let kls = format!("{}/{}", TOKEN_LABEL, "test/secp256k1/1");
    let key_label = KeyLabel::from_short(&kls, CryptographAlgorithm::Secp256k1)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();

    // sign_ecdsa will hash the data before signing.
    let hash = secure_hash(data);

    // sign data
    let sig = sdk.sign_ecdsa::<Secp256k1>(&key_label, data)?;

    // verify sig - positive
    assert!(sdk.verify_prehash_ec_outside_hsm::<Secp256k1>(&key_label, &hash[..], &sig).is_ok());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    let hash = secure_hash(data);
    assert!(sdk.verify_prehash_ec_outside_hsm::<Secp256k1>(&key_label, &hash[..], &sig).is_err());

    // this also works
    /*
        let public_key = sdk.get_ec_public_key::<Secp256k1>(&key_label)?;
        // verify sig - positive
        assert!(public_key.verify(&data[..], &sig).is_ok());

        // verify sig - negative
        let data = "sign me not".as_bytes();
        assert!(public_key.verify(&data[..], &sig).is_err());
    */

    sdk.close()?;
    Ok(())
}

#[test]
#[serial]
fn it_sign_verify_prehash_sig_secp256r1_outside_hsm() -> Result<()> {
    unsafe { keygen()?; }

    let sdk = get_test_sdk()?;

    let kls = format!("{}/{}", TOKEN_LABEL, "test/secp256r1/1");
    let key_label = KeyLabel::from_short(&kls, CryptographAlgorithm::Secp256r1)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();
    let hash = secure_hash(data);

    // sign data
    let sig = sdk.sign_ecdsa::<NistP256>(&key_label, &hash[..])?;

    // verify sig - positive
    assert!(sdk.verify_ec_outside_hsm::<NistP256>(&key_label, &hash[..], &sig).is_ok());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    let hash = secure_hash(data);
    assert!(sdk.verify_prehash_ec_outside_hsm::<NistP256>(&key_label, &hash[..], &sig).is_err());

    sdk.close()?;
    Ok(())
}

#[test]
#[serial]
fn it_sign_verify_sig_secp256k1_outside_hsm_integrated() -> Result<()> {
    unsafe { keygen()?; }

    let sdk = get_test_sdk()?;

    let kls = format!("{}/{}", TOKEN_LABEL, "test/secp256k1/1");
    let key_label = KeyLabel::from_short(&kls, CryptographAlgorithm::Secp256k1)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();
    // Only Sha256 will work. Sha384 and Sha512 will not work.
    let mut hasher = Sha256::new();
    hasher.update(data);
    let hash = hasher.finalize();

    // sign data
    let sig = sdk.sign(&key_label, &hash[..])?;

    println!("raw sig: {:?}", hex::encode(&sig));

    let sig = EcSignature::<Secp256k1>::from_slice(&sig).unwrap();
    let sig = if let Some(sig) = sig.normalize_s() {
        sig
    } else {
        sig
    };
    let public_key = sdk.get_k256_public_key(&key_label)?;
    assert!(public_key.verify(&data[..], &sig).is_ok());
    sdk.close()?;
    Ok(())
}

#[test]
#[serial]
fn it_sign_verify_prehash_sig_secp256k1_outside_hsm_integrated() -> Result<()> {
    unsafe { keygen()?; }

    let sdk = get_test_sdk()?;

    let kls = format!("{}/{}", TOKEN_LABEL, "test/secp256k1/1");
    let key_label = KeyLabel::from_short(&kls, CryptographAlgorithm::Secp256k1)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();
    // any of Sha256, Sha384, Sha512 will will work
    let mut hasher = Sha512::new();
    hasher.update(data);
    let hash = hasher.finalize();

    // sign data
    let sig = sdk.sign(&key_label, &hash[..])?;

    println!("raw sig: {:?}", hex::encode(&sig));

    let sig = EcSignature::<Secp256k1>::from_slice(&sig).unwrap();
    let sig = if let Some(sig) = sig.normalize_s() {
        sig
    } else {
        sig
    };
    // let sig2 = sig1.normalize_s();
    // let sig1 = if sig2.is_some() { sig2.unwrap() } else { sig1 };
    let public_key = sdk.get_k256_public_key(&key_label)?;
    assert!(public_key.verify_prehash(&hash[..], &sig).is_ok());
    /*
        sdk.verify_sig_ec_outside_hsm(&key_label, data, &sig).map_err(|e| {
            println!("error: {:?}", e);
            e
        })?;
        // verify sig - positive
        assert!(sdk.verify_sig_ec_outside_hsm(&key_label, data, &sig).is_ok());

        // verify sig - negative
        let data = "sign me not".as_bytes();
        assert!(sdk.verify_sig_ec_outside_hsm(&key_label, data, &sig).is_err());
    */
    sdk.close()?;
    Ok(())
}

#[test]
#[serial]
fn it_test_encrypt_decrypt() -> Result<()> {
    unsafe { keygen()?; }

    let sdk = get_test_sdk()?;

    let kls = format!("{}/{}", TOKEN_LABEL, "test/aes/1");
    // let kls = "slot-0/tsstrio-1/aes/1";
    let key_label = KeyLabel::from_short(&kls, CryptographAlgorithm::AES)?;

    let data = b"encrypt me";

    let aad = b"additional data";

    let encrypted = sdk.encrypt(&key_label, data, aad)?;

    let decrypted = sdk.decrypt(&key_label, &encrypted, aad)?;

    assert_eq!(decrypted, data);

    let data = b"encrypt me not";
    assert_ne!(decrypted, data);

    Ok(())
}

#[test]
#[serial]
fn it_p11() -> Result<()> {
    let p11 = get_test_ctx()?;

    p11.p11();

    Ok(())
}

#[test]
#[serial]
fn it_slot() -> Result<()> {
    let p11 = get_test_ctx()?;

    p11.slot();

    Ok(())
}

#[test]
#[serial]
fn it_find_slot_by_label() -> Result<()> {
    let p11 = get_test_ctx()?;

    assert!(p11.find_slot_by_label("bad slot label").is_err());

    Ok(())
}