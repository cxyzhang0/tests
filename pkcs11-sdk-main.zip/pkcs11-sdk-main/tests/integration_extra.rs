use crate::integration_common::{init_config, init_pins, ENV_MODULE, MODULE, TOKEN_LABEL, USER_PIN};
use cryptoki::context::Pkcs11;
use pkcs11_sdk::{Result, SDKContext, SDK};
use serial_test::serial;

mod integration_common;

// IMPORTANT: every test should have this line at the beginning
// init_config(); unless there is test has init_pins() which already calls init_config().
// otherwise, default softhsm2 configuration will be used
#[test]
#[serial]
fn it_new_with_slot() -> Result<()> {
    init_config();

    let p11 = Pkcs11::new(MODULE)?;
    let _ctx = SDKContext::new(p11);

    Ok(())
}

#[test]
#[serial]
fn it_from_pkcs11_label() -> Result<()> {
    let (p11, _slot) = init_pins()?;

    let _ctx = SDKContext::from_pkcs11_label(p11, TOKEN_LABEL)?;

    Ok(())
}

#[test]
#[serial]
fn it_set_slot_by_id() -> Result<()> {
    let (p11, slot) = init_pins()?;
    let mut ctx = SDKContext::new(p11);

    let id = slot.id();

    assert!(ctx.set_slot_by_id(id).is_ok());

    Ok(())
}

#[test]
#[serial]
fn it_create_pkcs11_env_module() -> Result<()> {
    init_config();

    let _p11 = SDKContext::create_pkcs11(Some(ENV_MODULE), None)?;

    Ok(())
}

#[test]
#[serial]
fn it_create_pkcs11_module() -> Result<()> {
    init_config();
    let _p11 = SDKContext::create_pkcs11(None, Some(MODULE))?;

    Ok(())
}

#[test]
#[serial]
fn it_create_pkcs11_failure() -> Result<()> {
    init_config();
    assert!(SDKContext::create_pkcs11(None, None).is_err());

    Ok(())
}

#[test]
#[serial]
fn it_fn_sdk_new() -> Result<()> {
    let (_, _) = init_pins()?;

    SDK::new(None, Some(MODULE), TOKEN_LABEL, USER_PIN)?;

    Ok(())
}

#[test]
#[serial]
fn it_fn_sdk_new_fail_invalid_token_label() -> Result<()> {
    let (_, _) = init_pins()?;

    let res = SDK::new(None, Some(MODULE), "bad token label", USER_PIN);

    assert!(res.is_err());

    Ok(())
}
#[test]
#[serial]
fn it_fn_sdk_new_fail_invalid_pin() -> Result<()> {
    let (_, _) = init_pins()?;

    let res = SDK::new(None, Some(MODULE), TOKEN_LABEL, "bad pin");

    assert!(res.is_err());

    Ok(())
}
