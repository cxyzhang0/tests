use cryptoki::context::Pkcs11;
use serial_test::serial;
use pkcs11_sdk::{SDKContext, Result};
use crate::integration_common::{init_pins, MODULE, TOKEN_LABEL};

mod integration_common;

#[test]
#[serial]
fn it_new_with_slot() -> Result<()> {
    let p11 = Pkcs11::new(MODULE)?;
    let ctx = SDKContext::new(p11);

    Ok(())
}

#[test]
#[serial]
fn it_from_pkcs11_label() -> Result<()> {
    let (p11, slot) = init_pins()?;

    let ctx = SDKContext::from_pkcs11_label(p11, TOKEN_LABEL)?;

    Ok(())
}

#[test]
#[serial]
fn test_set_slot_by_id() -> Result<()> {
    let (p11, slot) = init_pins()?;
    let mut ctx = SDKContext::new(p11);

    let id = slot.id();

    assert!(ctx.set_slot_by_id(id).is_ok());

    Ok(())

}

#[test]
#[serial]
fn test_create_pkcs11() -> Result<()> {
    let p11 = SDKContext::create_pkcs11(None, Some(MODULE))?;

    Ok(())

}

#[test]
#[serial]
fn test_create_pkcs11_failure() -> Result<()> {
    assert!(SDKContext::create_pkcs11(None, None).is_err());

    Ok(())
}