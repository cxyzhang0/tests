//! This module contains the abstraction for the PKCS#11 provider and session provider.
//! The abstraction would enhance testability via mock.
//! Note: The abstraction is not complete and
//!  we may favor integration test with softhsm.
use crate::error::Result;
use cryptoki::mechanism::{Mechanism, MechanismType};
use cryptoki::object::ObjectHandle;
use cryptoki::slot::Slot;
#[allow(unused)]
pub trait Pkcs11Provider {
    fn initialize(&mut self) -> Result<()>;
    fn is_initialized(&self) -> bool;
    fn get_mechanism_list(&self) -> Result<Vec<MechanismType>>;
    fn open_rw_session(&self, slot_id: Slot) -> Result<Box<dyn SessionProvider>>;
}

#[allow(unused)]
pub trait SessionProvider {
    fn sign(&self, mechanism: &Mechanism, key: ObjectHandle, data: &[u8]) -> Result<Vec<u8>>;
    fn verify(
        &self,
        mechanism: &Mechanism,
        key: ObjectHandle,
        data: &[u8],
        signature: &[u8],
    ) -> Result<()>;
    fn close(self);
    fn logout(&self) -> Result<()>;
}
