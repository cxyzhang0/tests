//! This module contains the abstraction for the PKCS#11 provider and session provider.
//! The abstraction would enhance testability via mock.
//! Note: The abstraction is not complete and
//!  we may favor integration test with softhsm.
use crate::error::Result;
use cryptoki::mechanism::{Mechanism, MechanismType};
use cryptoki::object::ObjectHandle;
use cryptoki::slot::Slot;

#[allow(unused)]
/// Trait representing a PKCS#11 provider.
///
/// # Errors
///
/// Methods in this trait will return an error in case of:
/// * Initialization failures
/// * Mechanism list retrieval failures
/// * Session opening failures
pub trait Pkcs11Provider {
    /// Initializes the PKCS#11 provider.
    ///
    /// # Errors
    ///
    /// Returns an error if initialization fails.
    fn initialize(&mut self) -> Result<()>;

    /// Checks if the PKCS#11 provider is initialized.
    ///
    /// # Returns
    ///
    /// `true` if initialized, `false` otherwise.
    fn is_initialized(&self) -> bool;

    /// Retrieves the list of supported mechanisms.
    ///
    /// # Errors
    ///
    /// Returns an error if the mechanism list cannot be retrieved.
    fn get_mechanism_list(&self) -> Result<Vec<MechanismType>>;

    /// Opens a read-write session for the given slot.
    ///
    /// # Arguments
    ///
    /// * `slot_id` - The slot identifier.
    ///
    /// # Errors
    ///
    /// Returns an error if the session cannot be opened.
    fn open_rw_session(&self, slot_id: Slot) -> Result<Box<dyn SessionProvider>>;
}

#[allow(unused)]
/// Trait representing a session provider.
///
/// # Errors
///
/// Methods in this trait will return an error in case of:
/// * Signing failures
/// * Verification failures
/// * Logout failures
pub trait SessionProvider {
    /// Signs the given data using the specified mechanism and key.
    ///
    /// # Arguments
    ///
    /// * `mechanism` - The mechanism to use for signing.
    /// * `key` - The key handle.
    /// * `data` - The data to sign.
    ///
    /// # Returns
    ///
    /// A vector of bytes representing the signature.
    ///
    /// # Errors
    ///
    /// Returns an error if signing fails.
    fn sign(&self, mechanism: &Mechanism, key: ObjectHandle, data: &[u8]) -> Result<Vec<u8>>;

    /// Verifies the given signature using the specified mechanism and key.
    ///
    /// # Arguments
    ///
    /// * `mechanism` - The mechanism to use for verification.
    /// * `key` - The key handle.
    /// * `data` - The data to verify.
    /// * `signature` - The signature to verify.
    ///
    /// # Errors
    ///
    /// Returns an error if verification fails.
    fn verify(
        &self,
        mechanism: &Mechanism,
        key: ObjectHandle,
        data: &[u8],
        signature: &[u8],
    ) -> Result<()>;

    /// Closes the session.
    fn close(self);

    /// Logs out from the session.
    ///
    /// # Errors
    ///
    /// Returns an error if logout fails.
    fn logout(&self) -> Result<()>;
}