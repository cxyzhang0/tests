use crate::error::{Error, Result};
use crate::sdk::CryptographAlgorithm;
use ecdsa::signature::digest::Digest;
use regex::Regex;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct KeyLabel {
    pub prefix: String,
    pub key_ring: String,
    pub key: String,
    pub version: usize,
    pub algorithm: CryptographAlgorithm,
}

impl KeyLabel {
    pub fn new(
        prefix: String,
        key_ring: String,
        key: String,
        version: usize,
        algorithm: CryptographAlgorithm,
    ) -> Self {
        Self {
            prefix,
            key_ring,
            key,
            version,
            algorithm,
        }
    }

    pub fn from(label: &str, algorithm: CryptographAlgorithm) -> Result<Self> {
        let re = Regex::new(r".*/keyRings/.+/cryptoKeys/.+/cryptoKeyVersions/\d+").unwrap();
        if !re.is_match(label) {
            Err(Error::GenericError("Invalid label".to_string()))
        } else {
            re.split(label);
            let parts: Vec<&str> = label.split('/').collect();
            let n = parts.len();

            //TODO: this generic code does not compile because prefix does not live long enough
            /*
            let prefix: String = parts[0..n-6].join("/");
            Ok(Self {
                prefix: &prefix,
                key_ring: parts[n-5],
                key: parts[n-3],
                version: parts[n-1].parse::<usize>().unwrap(),
                algorithm,
            })
            */
            // if n != 7 { // this should not occur because of the regex check
            //     Err(Error::GenericError(format!("Invalid label - expecting 7 segments but getting: {}", n)))
            // } else {
            Ok(Self {
                prefix: parts[n - 7].to_string(),
                key_ring: parts[n - 5].to_string(),
                key: parts[n - 3].to_string(),
                version: parts[n - 1].parse::<usize>().unwrap(),
                algorithm,
            })
            // }
        }
    }

    pub fn from_short(label: &str, algorithm: CryptographAlgorithm) -> Result<Self> {
        let re = Regex::new(r".*/.+/.+/\d+").unwrap();
        if !re.is_match(label) {
            Err(Error::GenericError("Invalid label".to_string()))
        } else {
            re.split(label);
            let parts: Vec<&str> = label.split('/').collect();
            // if parts.len() != 4 { // this should not occur because of the regex check
            //     Err(Error::GenericError(format!("Invalid short label - expecting 4 segments but getting: {}", parts.len())))
            // } else {
            Ok(Self {
                prefix: parts[0].to_string(),
                key_ring: parts[1].to_string(),
                key: parts[2].to_string(),
                version: parts[3].parse::<usize>().unwrap(),
                algorithm,
            })
            // }
        }
    }

    pub fn label(&self) -> String {
        format!(
            "{}/keyRings/{}/cryptoKeys/{}/cryptoKeyVersions/{}",
            self.prefix, self.key_ring, self.key, self.version
        )
    }

    pub fn short_label(&self) -> String {
        format!(
            "{}/{}/{}/{}",
            self.prefix, self.key_ring, self.key, self.version
        )
    }

    pub fn string(&self) -> String {
        self.label()
    }

    pub fn short_string(&self) -> String {
        self.short_label()
    }

    // pub fn next(&mut self) -> &mut Self {
    //     self.version += 1;
    //     self
    // }

    pub fn next(&mut self) {
        self.version += 1;
    }
}

pub fn secure_hash_to_vec(data: &[u8]) -> Vec<u8> {
    // we can use digest() which is the wrapper of the commented code below
    /*
    let mut hasher = sha2::Sha256::new();
    hasher.update(data);
    hasher.finalize().to_vec()
    */
    sha2::Sha256::digest(data).to_vec()
}

pub fn secure_hash(data: &[u8]) -> [u8; 32] {
    sha2::Sha256::digest(data).into()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_key_label_new() {
        KeyLabel::new(
            "prefix".to_string(),
            "key_ring".to_string(),
            "key".to_string(),
            1,
            CryptographAlgorithm::Secp256r1,
        );
    }

    #[test]
    fn test_secure_hash() {
        let data = b"hello world";
        let hash = secure_hash(data);
        assert_eq!(hash.len(), 32);
    }

    #[test]
    fn test_secure_hash_to_vec() {
        let data = b"hello world";
        let hash = secure_hash_to_vec(data);
        assert_eq!(hash.len(), 32);
    }

    #[test]
    fn test_key_label() -> Result<()> {
        let pf = "Slot Token 0";
        let mut key_label = KeyLabel {
            prefix: pf.to_string(),
            key_ring: "WIM-test".to_string(),
            key: "id-ed25519-hsm-2".to_string(),
            version: 1,
            algorithm: CryptographAlgorithm::Ed25519,
        };
        let label = key_label.label();
        let short_label = key_label.short_label();
        assert_eq!(
            label, "Slot Token 0/keyRings/WIM-test/cryptoKeys/id-ed25519-hsm-2/cryptoKeyVersions/1",
            "labels are not equal"
        );
        assert_eq!(
            short_label, "Slot Token 0/WIM-test/id-ed25519-hsm-2/1",
            "short labels are not equal"
        );

        let kl = KeyLabel::from(&label, CryptographAlgorithm::Ed25519)?;
        assert_eq!(key_label, kl, "key labels are not equal");

        let skl = KeyLabel::from_short(&short_label, CryptographAlgorithm::Ed25519)?;
        assert_eq!(key_label, skl, "key labels are not equal");

        key_label.next();
        let next_short_label = key_label.short_string();
        assert_eq!(
            key_label.string(),
            "Slot Token 0/keyRings/WIM-test/cryptoKeys/id-ed25519-hsm-2/cryptoKeyVersions/2",
            "next labels are not equal"
        );
        assert_eq!(
            next_short_label, "Slot Token 0/WIM-test/id-ed25519-hsm-2/2",
            "next short labels are not equal"
        );

        Ok(())
    }

    #[test]
    fn test_key_label_from_fail_invalid_label() -> Result<()> {
        let label = "Slot Token 0/keyRings/WIM-test"; // too short
        let res = KeyLabel::from(label, CryptographAlgorithm::Ed25519);

        if let Err(e) = res {
            assert!(matches!(e, Error::GenericError(msg) if msg == String::from("Invalid label")));
            Ok(())
        } else {
            assert!(false);
            Err(Error::GenericError("Should not happen".to_string()))
        }
    }

    #[test]
    fn test_key_label_from_short_fail_invalid_label() -> Result<()> {
        let label = "Slot Token 0/keyRings/WIM-test"; // too short
        let res = KeyLabel::from_short(label, CryptographAlgorithm::Ed25519);

        if let Err(e) = res {
            assert!(matches!(e, Error::GenericError(msg) if msg == String::from("Invalid label")));
            Ok(())
        } else {
            assert!(false);
            Err(Error::GenericError("Should not happen".to_string()))
        }
    }
}
