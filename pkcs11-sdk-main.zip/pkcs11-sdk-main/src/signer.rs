use crate::{KeyLabel, SDK};
use async_trait::async_trait;
use k256::ecdsa::signature::{Keypair, Signer};
use k256::ecdsa::{Signature, VerifyingKey};
use k256::Secp256k1;
use kms_common::{self, async_signer};
use std::sync::{Arc, Mutex};

#[derive(Debug)]
pub struct P11Signer {
    sdk: Arc<Mutex<SDK>>,
    key_label: KeyLabel,
}

impl P11Signer {
    pub fn new(sdk: Arc<Mutex<SDK>>, key_label: KeyLabel) -> Self {
        Self { sdk, key_label }
    }

    pub fn from_vars(env_module: Option<&str>, module: Option<&str>, token_label: &str, pin: &str, key_label: KeyLabel) -> Self {
        let sdk = SDK::new(env_module, module, token_label, pin).unwrap();

        Self::new(Arc::new(Mutex::new(sdk)), key_label)
    }

}

impl Signer<Signature> for P11Signer {
    fn sign(&self, msg: &[u8]) -> Signature {
        self.try_sign(msg).unwrap()
    }

    fn try_sign(&self, msg: &[u8]) -> anyhow::Result<Signature, kms_common::SignatureError> {
        self.sdk.lock().unwrap().sign_ecdsa::<Secp256k1>(&self.key_label, msg).map_err(|e|
            kms_common::SignatureError::from_source(e))
    }
}

#[async_trait]
impl async_signer::AsyncSigner<Secp256k1, Signature> for P11Signer {
    async fn try_sign(&self, msg: &[u8]) -> anyhow::Result<Signature, kms_common::SignatureError> {
        self.sdk.lock().unwrap().sign_ecdsa::<Secp256k1>(&self.key_label, msg)
            .map_err(|e|  kms_common::SignatureError::from_source(e))
    }

    async fn try_sign_prehash(&self, msg_hash: [u8; 32]) -> Result<Signature, kms_common::SignatureError> {
        self.sdk.lock().unwrap().sign_ecdsa_prehash::<Secp256k1>(&self.key_label, msg_hash)
            .map_err(|e|  kms_common::SignatureError::from_source(e))    }
}

impl Keypair for P11Signer {
    type VerifyingKey = VerifyingKey;

    fn verifying_key(&self) -> Self::VerifyingKey {
        self.sdk.lock().unwrap().get_ec_public_key::<Secp256k1>(&self.key_label).unwrap()
    }
}

unsafe impl Send for P11Signer {}

unsafe impl Sync for P11Signer {}
