use anyhow::Error as AnyHowError;
use cryptoki::error::Error as P11HsmError;
use std::env::VarError;
use std::fmt::Display;
use std::sync::PoisonError;
use signature::Error as SignatureError;
use elliptic_curve::Error as CurveError;

// TODO: use anyhow::Error instead of ErrorWithStacktrace
//  to be consistent with SL and our other crates.
// #[derive(Debug)]
// pub struct ErrorWithStacktrace;

// impl<T: std::error::Error> From<T> for ErrorWithStacktrace {
//     fn from(p: T) -> Self {
//         panic!("Error: {:#?}", p);
//     }
// }
//
// pub type Result<T> = std::result::Result<T, ErrorWithStacktrace>;


#[derive(Debug)]
pub enum Error {
    InvalidConfig(&'static str),
    AlgorithmNotSupported,
    NotAuthorized,
    TokenNotFound,
    TokenNotSet,
    P11(P11HsmError),
    VarError(VarError),
    Signature(SignatureError),
    Curve(CurveError),
    GenericError(String),
}

impl Display for Error {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Error::InvalidConfig(e) => write!(f, "Invalid Config: {e}"),
            Error::AlgorithmNotSupported => write!(f, "Algorithm Not Supported"),
            Error::NotAuthorized => write!(f, "Session Not Authorized"),
            Error::TokenNotFound => write!(f, "Token Not Found"),
            Error::TokenNotSet => write!(f, "Token Not Set"),
            Error::P11(e) => write!(f, "PKCS11 Error: {e}"),
            Error::VarError(e) => write!(f, "Env Var Error: {e}"),
            Error::Signature(e) => write!(f, "Signature Error: {e}"),
            Error::Curve(e) => write!(f, "Elliptic curve Error: {e}"),
            Error::GenericError(e) => write!(f, "Generic Error: {e}"),
        }
    }
}

impl std::error::Error for Error {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Error::P11(e) => Some(e),
            Error::VarError(e) => Some(e),
            Error::Signature(e) => Some(e),
            _ => None,
        }
    }
}

impl From<AnyHowError> for Error {
    fn from(e: AnyHowError) -> Self {
        Error::GenericError(format!("Converted anyhow error: {e}"))
    }
}

impl <T> From<PoisonError<T>> for Error {
    fn from(e: PoisonError<T>) -> Self {
        Error::GenericError(format!("PoisonError: {e}"))
    }
}

impl From<P11HsmError> for Error {
    fn from(e: P11HsmError) -> Self {
        Error::P11(e)
    }
}

impl From<VarError> for Error {
    fn from(e: VarError) -> Self {
        Error::VarError(e)
    }
}

impl From<SignatureError> for Error {
    fn from(e: SignatureError) -> Self {
        Error::Signature(e)
    }
}

impl From<CurveError> for Error {
    fn from(e: CurveError) -> Self {
        Error::Curve(e)
    }
}
pub type Result<T> = anyhow::Result<T, Error>;

#[cfg(test)]
mod tests {
    use super::*;
    use std::env::VarError;
    use std::error::Error as StdError;
    use cryptoki::error::Error as P11HsmError;
    use signature::Error as SignatureError;
    use elliptic_curve::Error as CurveError;
    use anyhow::anyhow;

    fn create_anyhow_error() -> AnyHowError {
        anyhow!("test error")
    }

    #[test]
    fn invalid_config_error_display() {
        let error = Error::InvalidConfig("Invalid configuration");
        assert_eq!(format!("{}", error), "Invalid Config: Invalid configuration");
    }

    #[test]
    fn algorithm_not_supported_error_display() {
        let error = Error::AlgorithmNotSupported;
        assert_eq!(format!("{}", error), "Algorithm Not Supported");
    }

    #[test]
    fn not_authorized_error_display() {
        let error = Error::NotAuthorized;
        assert_eq!(format!("{}", error), "Session Not Authorized");
    }

    #[test]
    fn token_not_found_error_display() {
        let error = Error::TokenNotFound;
        assert_eq!(format!("{}", error), "Token Not Found");
    }

    #[test]
    fn token_not_set_error_display() {
        let error = Error::TokenNotSet;
        assert_eq!(format!("{}", error), "Token Not Set");
    }

    #[test]
    fn p11_error_display() {
        let p11_error = P11HsmError::NotSupported;
        let error = Error::P11(p11_error);
        assert!(format!("{}", error).contains("PKCS11 Error:"));
    }

    #[test]
    fn var_error_display() {
        let var_error = VarError::NotPresent;
        let error = Error::VarError(var_error);
        assert!(format!("{}", error).contains("Env Var Error:"));
    }

    #[test]
    fn signature_error_display() {
        let signature_error = SignatureError::new();
        let error = Error::Signature(signature_error);
        assert!(format!("{}", error).contains("Signature Error:"));
    }

    // #[test]
    // fn curve_error_display() {
    //     let curve_error = CurveError::new();
    //     let error = Error::Curve(curve_error);
    //     assert!(format!("{}", error).contains("Elliptic curve Error:"));
    // }

    #[test]
    fn generic_error_display() {
        let error = Error::GenericError("Generic error".to_string());
        assert_eq!(format!("{}", error), "Generic Error: Generic error");
    }

    #[test]
    fn anyhow_error_conversion() {
        let anyhow_error = create_anyhow_error();
        let error: Error = anyhow_error.into();
        assert!(format!("{}", error).contains("Converted anyhow error:"));
    }

    #[test]
    fn poison_error_conversion() {
        let poison_error: PoisonError<()> = PoisonError::new(());
        let error: Error = poison_error.into();
        assert!(format!("{}", error).contains("PoisonError:"));
    }

    // #[test]
    // fn p11_error_conversion() {
    //     let p11_error = P11HsmError::Module("PKCS11 module error".to_string());
    //     let error: Error = p11_error.into();
    //     assert!(format!("{}", error).contains("PKCS11 Error:"));
    // }

    #[test]
    fn var_error_conversion() {
        let var_error = VarError::NotPresent;
        let error: Error = var_error.into();
        assert!(format!("{}", error).contains("Env Var Error:"));
    }

    #[test]
    fn signature_error_conversion() {
        let signature_error = SignatureError::new();
        let error: Error = signature_error.into();
        assert!(format!("{}", error).contains("Signature Error:"));
    }

    // #[test]
    // fn curve_error_conversion() {
    //     let curve_error = CurveError::new();
    //     let error: Error = curve_error.into();
    //     assert!(format!("{}", error).contains("Elliptic curve Error:"));
    // }

    // #[test]
    // fn token_not_set_error_display() {
    //     let error = Error::TokenNotSet;
    //     assert_eq!(format!("{}", error), "Token Not Set");
    // }

    #[test]
    fn curve_error_display() {
        let curve_error = CurveError;
        let error = Error::Curve(curve_error);
        assert!(format!("{}", error).contains("Elliptic curve Error:"));
    }

    #[test]
    fn curve_error_conversion() {
        let curve_error = CurveError;
        let error: Error = curve_error.into();
        assert!(format!("{}", error).contains("Elliptic curve Error:"));
    }

    #[test]
    fn error_source() {
        let p11_error = P11HsmError::NotSupported;
        let error = Error::P11(p11_error);
        assert!(error.source().is_some());

        let var_error = VarError::NotPresent;
        let error = Error::VarError(var_error);
        assert!(error.source().is_some());

        let signature_error = SignatureError::new();
        let error = Error::Signature(signature_error);
        assert!(error.source().is_some());

        let error = Error::TokenNotSet;
        assert!(error.source().is_none());
    }
}
