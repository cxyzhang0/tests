## pkcs11-sdk
* This crate was created from and replaces the pkcs11 package of hsm-wallet workspace repo. 
* This crate includes the SDK to interface with HSM for key management
> Supported algorithms
> * ed25519 (Solana, Algorand, Cardano)
> * secp256k1 (Bitcoin, Ethereum)
> * secp256r1 (Corda)
> * rsa2048


### Prerequisites and dependencies
* Rust PKCS11 3.0 wrapper
> https://github.com/legounix/rust-cryptoki/tree/fix_mechanis_eddsa
> Note: The official cryptoki 0.4.1 in crates.io only supports PKCS11 2.4 which does not have eddsa. There is a PR for it.
* SOFTHSM 2.6.1 for testing
> download softhsm-2.6.1.tar.gz at https://dist.opendnssec.org/source/, unzip and install per README there.  
> Initialization
```
softhsm2-util --init-token --slot 0 --label "Slot Token 0" 
or 
test_init_pins() in pcsc11/tests.basic.rs (commented out)
```

* Or FutureX HSM for testing

### Open Issues
- Thread safety. PKCS11 SDK may not be thread safe.  
Session only implements Send and explicitly prohibits implementing Sync for sharing across threads. They may have their reason for that.  
SDK implements both Send and Sync to satisfy the requirement of clients, especially TMKMS.

- session management: each session can only handle operation initialization (such as find object init, signature init, or encryption init, etc) at a time.  
it is really the responsibility of the client (such as kms_svc) to manage sessions properly; before kms_svc implements session management, we globally synchronize get_key_handle as a quick workaround to help a demo.  
now how about signature, encryption, operations, etc?    
todo: the sdk needs to provide helpers for the client to manage sessions properly - test from_context and from_context_with_login to make sure they can create new sdks (which are new sessions).