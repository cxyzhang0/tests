// @generated
impl serde::Serialize for BalanceError {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.error_code.is_empty() {
            len += 1;
        }
        if !self.error_description.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.BalanceError", len)?;
        if !self.error_code.is_empty() {
            struct_ser.serialize_field("errorCode", &self.error_code)?;
        }
        if !self.error_description.is_empty() {
            struct_ser.serialize_field("errorDescription", &self.error_description)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for BalanceError {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "errorCode",
            "errorDescription",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            ErrorCode,
            ErrorDescription,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "errorCode" => Ok(GeneratedField::ErrorCode),
                            "errorDescription" => Ok(GeneratedField::ErrorDescription),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = BalanceError;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.BalanceError")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<BalanceError, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut error_code__ = None;
                let mut error_description__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::ErrorCode => {
                            if error_code__.is_some() {
                                return Err(serde::de::Error::duplicate_field("errorCode"));
                            }
                            error_code__ = Some(map_.next_value()?);
                        }
                        GeneratedField::ErrorDescription => {
                            if error_description__.is_some() {
                                return Err(serde::de::Error::duplicate_field("errorDescription"));
                            }
                            error_description__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(BalanceError {
                    error_code: error_code__.unwrap_or_default(),
                    error_description: error_description__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.BalanceError", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for BalanceRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.party.is_some() {
            len += 1;
        }
        if !self.currency.is_empty() {
            len += 1;
        }
        if !self.tracking_id.is_empty() {
            len += 1;
        }
        if !self.ref_number.is_empty() {
            len += 1;
        }
        if !self.request_date_time.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.BalanceRequest", len)?;
        if let Some(v) = self.party.as_ref() {
            struct_ser.serialize_field("party", v)?;
        }
        if !self.currency.is_empty() {
            struct_ser.serialize_field("currency", &self.currency)?;
        }
        if !self.tracking_id.is_empty() {
            struct_ser.serialize_field("trackingId", &self.tracking_id)?;
        }
        if !self.ref_number.is_empty() {
            struct_ser.serialize_field("refNumber", &self.ref_number)?;
        }
        if !self.request_date_time.is_empty() {
            struct_ser.serialize_field("requestDateTime", &self.request_date_time)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for BalanceRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "party",
            "currency",
            "trackingId",
            "refNumber",
            "requestDateTime",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Party,
            Currency,
            TrackingId,
            RefNumber,
            RequestDateTime,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "party" => Ok(GeneratedField::Party),
                            "currency" => Ok(GeneratedField::Currency),
                            "trackingId" => Ok(GeneratedField::TrackingId),
                            "refNumber" => Ok(GeneratedField::RefNumber),
                            "requestDateTime" => Ok(GeneratedField::RequestDateTime),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = BalanceRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.BalanceRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<BalanceRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut party__ = None;
                let mut currency__ = None;
                let mut tracking_id__ = None;
                let mut ref_number__ = None;
                let mut request_date_time__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Party => {
                            if party__.is_some() {
                                return Err(serde::de::Error::duplicate_field("party"));
                            }
                            party__ = map_.next_value()?;
                        }
                        GeneratedField::Currency => {
                            if currency__.is_some() {
                                return Err(serde::de::Error::duplicate_field("currency"));
                            }
                            currency__ = Some(map_.next_value()?);
                        }
                        GeneratedField::TrackingId => {
                            if tracking_id__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingId"));
                            }
                            tracking_id__ = Some(map_.next_value()?);
                        }
                        GeneratedField::RefNumber => {
                            if ref_number__.is_some() {
                                return Err(serde::de::Error::duplicate_field("refNumber"));
                            }
                            ref_number__ = Some(map_.next_value()?);
                        }
                        GeneratedField::RequestDateTime => {
                            if request_date_time__.is_some() {
                                return Err(serde::de::Error::duplicate_field("requestDateTime"));
                            }
                            request_date_time__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(BalanceRequest {
                    party: party__,
                    currency: currency__.unwrap_or_default(),
                    tracking_id: tracking_id__.unwrap_or_default(),
                    ref_number: ref_number__.unwrap_or_default(),
                    request_date_time: request_date_time__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.BalanceRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for BalanceResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.status.is_empty() {
            len += 1;
        }
        if self.message.is_some() {
            len += 1;
        }
        if self.data.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.BalanceResponse", len)?;
        if !self.status.is_empty() {
            struct_ser.serialize_field("status", &self.status)?;
        }
        if let Some(v) = self.message.as_ref() {
            struct_ser.serialize_field("message", v)?;
        }
        if let Some(v) = self.data.as_ref() {
            struct_ser.serialize_field("data", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for BalanceResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "status",
            "message",
            "data",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Status,
            Message,
            Data,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "status" => Ok(GeneratedField::Status),
                            "message" => Ok(GeneratedField::Message),
                            "data" => Ok(GeneratedField::Data),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = BalanceResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.BalanceResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<BalanceResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut status__ = None;
                let mut message__ = None;
                let mut data__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Status => {
                            if status__.is_some() {
                                return Err(serde::de::Error::duplicate_field("status"));
                            }
                            status__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Message => {
                            if message__.is_some() {
                                return Err(serde::de::Error::duplicate_field("message"));
                            }
                            message__ = map_.next_value()?;
                        }
                        GeneratedField::Data => {
                            if data__.is_some() {
                                return Err(serde::de::Error::duplicate_field("data"));
                            }
                            data__ = map_.next_value()?;
                        }
                    }
                }
                Ok(BalanceResponse {
                    status: status__.unwrap_or_default(),
                    message: message__,
                    data: data__,
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.BalanceResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for BalanceStatus {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        let variant = match self {
            Self::Unspecified => "BalanceStatus_UNSPECIFIED",
            Self::Success => "BalanceStatus_SUCCESS",
            Self::Failed => "BalanceStatus_FAILED",
        };
        serializer.serialize_str(variant)
    }
}
impl<'de> serde::Deserialize<'de> for BalanceStatus {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "BalanceStatus_UNSPECIFIED",
            "BalanceStatus_SUCCESS",
            "BalanceStatus_FAILED",
        ];

        struct GeneratedVisitor;

        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = BalanceStatus;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                write!(formatter, "expected one of: {:?}", &FIELDS)
            }

            fn visit_i64<E>(self, v: i64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Signed(v), &self)
                    })
            }

            fn visit_u64<E>(self, v: u64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Unsigned(v), &self)
                    })
            }

            fn visit_str<E>(self, value: &str) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                match value {
                    "BalanceStatus_UNSPECIFIED" => Ok(BalanceStatus::Unspecified),
                    "BalanceStatus_SUCCESS" => Ok(BalanceStatus::Success),
                    "BalanceStatus_FAILED" => Ok(BalanceStatus::Failed),
                    _ => Err(serde::de::Error::unknown_variant(value, FIELDS)),
                }
            }
        }
        deserializer.deserialize_any(GeneratedVisitor)
    }
}
impl serde::Serialize for BankBalanceRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.address.is_some() {
            len += 1;
        }
        if !self.denom.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.BankBalanceRequest", len)?;
        if let Some(v) = self.address.as_ref() {
            struct_ser.serialize_field("address", v)?;
        }
        if !self.denom.is_empty() {
            struct_ser.serialize_field("denom", &self.denom)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for BankBalanceRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "address",
            "denom",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Address,
            Denom,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "address" => Ok(GeneratedField::Address),
                            "denom" => Ok(GeneratedField::Denom),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = BankBalanceRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.BankBalanceRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<BankBalanceRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut address__ = None;
                let mut denom__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Address => {
                            if address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("address"));
                            }
                            address__ = map_.next_value()?;
                        }
                        GeneratedField::Denom => {
                            if denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("denom"));
                            }
                            denom__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(BankBalanceRequest {
                    address: address__,
                    denom: denom__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.BankBalanceRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for BankBalanceResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.key_label.is_some() {
            len += 1;
        }
        if self.address.is_some() {
            len += 1;
        }
        if !self.denom.is_empty() {
            len += 1;
        }
        if !self.value.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.BankBalanceResponse", len)?;
        if let Some(v) = self.key_label.as_ref() {
            struct_ser.serialize_field("keyLabel", v)?;
        }
        if let Some(v) = self.address.as_ref() {
            struct_ser.serialize_field("address", v)?;
        }
        if !self.denom.is_empty() {
            struct_ser.serialize_field("denom", &self.denom)?;
        }
        if !self.value.is_empty() {
            struct_ser.serialize_field("value", &self.value)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for BankBalanceResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "key_label",
            "keyLabel",
            "address",
            "denom",
            "value",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            KeyLabel,
            Address,
            Denom,
            Value,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "keyLabel" | "key_label" => Ok(GeneratedField::KeyLabel),
                            "address" => Ok(GeneratedField::Address),
                            "denom" => Ok(GeneratedField::Denom),
                            "value" => Ok(GeneratedField::Value),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = BankBalanceResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.BankBalanceResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<BankBalanceResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut key_label__ = None;
                let mut address__ = None;
                let mut denom__ = None;
                let mut value__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::KeyLabel => {
                            if key_label__.is_some() {
                                return Err(serde::de::Error::duplicate_field("keyLabel"));
                            }
                            key_label__ = map_.next_value()?;
                        }
                        GeneratedField::Address => {
                            if address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("address"));
                            }
                            address__ = map_.next_value()?;
                        }
                        GeneratedField::Denom => {
                            if denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("denom"));
                            }
                            denom__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Value => {
                            if value__.is_some() {
                                return Err(serde::de::Error::duplicate_field("value"));
                            }
                            value__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(BankBalanceResponse {
                    key_label: key_label__,
                    address: address__,
                    denom: denom__.unwrap_or_default(),
                    value: value__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.BankBalanceResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for BankSendRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.to_addr.is_empty() {
            len += 1;
        }
        if !self.value.is_empty() {
            len += 1;
        }
        if !self.denom.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.BankSendRequest", len)?;
        if !self.to_addr.is_empty() {
            struct_ser.serialize_field("toAddr", &self.to_addr)?;
        }
        if !self.value.is_empty() {
            struct_ser.serialize_field("value", &self.value)?;
        }
        if !self.denom.is_empty() {
            struct_ser.serialize_field("denom", &self.denom)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for BankSendRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "to_addr",
            "toAddr",
            "value",
            "denom",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            ToAddr,
            Value,
            Denom,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "toAddr" | "to_addr" => Ok(GeneratedField::ToAddr),
                            "value" => Ok(GeneratedField::Value),
                            "denom" => Ok(GeneratedField::Denom),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = BankSendRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.BankSendRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<BankSendRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut to_addr__ = None;
                let mut value__ = None;
                let mut denom__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::ToAddr => {
                            if to_addr__.is_some() {
                                return Err(serde::de::Error::duplicate_field("toAddr"));
                            }
                            to_addr__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Value => {
                            if value__.is_some() {
                                return Err(serde::de::Error::duplicate_field("value"));
                            }
                            value__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Denom => {
                            if denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("denom"));
                            }
                            denom__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(BankSendRequest {
                    to_addr: to_addr__.unwrap_or_default(),
                    value: value__.unwrap_or_default(),
                    denom: denom__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.BankSendRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for BankSendResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.txhash.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.BankSendResponse", len)?;
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for BankSendResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "txhash",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Txhash,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "txhash" => Ok(GeneratedField::Txhash),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = BankSendResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.BankSendResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<BankSendResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut txhash__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(BankSendResponse {
                    txhash: txhash__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.BankSendResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for BlacklistRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.address.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.BlacklistRequest", len)?;
        if !self.address.is_empty() {
            struct_ser.serialize_field("address", &self.address)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for BlacklistRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "address",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Address,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "address" => Ok(GeneratedField::Address),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = BlacklistRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.BlacklistRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<BlacklistRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut address__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Address => {
                            if address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("address"));
                            }
                            address__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(BlacklistRequest {
                    address: address__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.BlacklistRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for BlacklistResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.txhash.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.BlacklistResponse", len)?;
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for BlacklistResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "txhash",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Txhash,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "txhash" => Ok(GeneratedField::Txhash),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = BlacklistResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.BlacklistResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<BlacklistResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut txhash__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(BlacklistResponse {
                    txhash: txhash__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.BlacklistResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for BurnRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.denom.is_empty() {
            len += 1;
        }
        if !self.value.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.BurnRequest", len)?;
        if !self.denom.is_empty() {
            struct_ser.serialize_field("denom", &self.denom)?;
        }
        if !self.value.is_empty() {
            struct_ser.serialize_field("value", &self.value)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for BurnRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "denom",
            "value",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Denom,
            Value,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "denom" => Ok(GeneratedField::Denom),
                            "value" => Ok(GeneratedField::Value),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = BurnRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.BurnRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<BurnRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut denom__ = None;
                let mut value__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Denom => {
                            if denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("denom"));
                            }
                            denom__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Value => {
                            if value__.is_some() {
                                return Err(serde::de::Error::duplicate_field("value"));
                            }
                            value__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(BurnRequest {
                    denom: denom__.unwrap_or_default(),
                    value: value__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.BurnRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for BurnResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.txhash.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.BurnResponse", len)?;
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for BurnResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "txhash",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Txhash,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "txhash" => Ok(GeneratedField::Txhash),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = BurnResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.BurnResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<BurnResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut txhash__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(BurnResponse {
                    txhash: txhash__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.BurnResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for CashResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.party.is_some() {
            len += 1;
        }
        if !self.amount.is_empty() {
            len += 1;
        }
        if !self.currency.is_empty() {
            len += 1;
        }
        if !self.tracking_id.is_empty() {
            len += 1;
        }
        if !self.ref_number.is_empty() {
            len += 1;
        }
        if !self.request_date_time.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.CashResponse", len)?;
        if let Some(v) = self.party.as_ref() {
            struct_ser.serialize_field("party", v)?;
        }
        if !self.amount.is_empty() {
            struct_ser.serialize_field("amount", &self.amount)?;
        }
        if !self.currency.is_empty() {
            struct_ser.serialize_field("currency", &self.currency)?;
        }
        if !self.tracking_id.is_empty() {
            struct_ser.serialize_field("trackingId", &self.tracking_id)?;
        }
        if !self.ref_number.is_empty() {
            struct_ser.serialize_field("refNumber", &self.ref_number)?;
        }
        if !self.request_date_time.is_empty() {
            struct_ser.serialize_field("requestDateTime", &self.request_date_time)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for CashResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "party",
            "amount",
            "currency",
            "trackingId",
            "refNumber",
            "requestDateTime",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Party,
            Amount,
            Currency,
            TrackingId,
            RefNumber,
            RequestDateTime,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "party" => Ok(GeneratedField::Party),
                            "amount" => Ok(GeneratedField::Amount),
                            "currency" => Ok(GeneratedField::Currency),
                            "trackingId" => Ok(GeneratedField::TrackingId),
                            "refNumber" => Ok(GeneratedField::RefNumber),
                            "requestDateTime" => Ok(GeneratedField::RequestDateTime),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = CashResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.CashResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<CashResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut party__ = None;
                let mut amount__ = None;
                let mut currency__ = None;
                let mut tracking_id__ = None;
                let mut ref_number__ = None;
                let mut request_date_time__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Party => {
                            if party__.is_some() {
                                return Err(serde::de::Error::duplicate_field("party"));
                            }
                            party__ = map_.next_value()?;
                        }
                        GeneratedField::Amount => {
                            if amount__.is_some() {
                                return Err(serde::de::Error::duplicate_field("amount"));
                            }
                            amount__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Currency => {
                            if currency__.is_some() {
                                return Err(serde::de::Error::duplicate_field("currency"));
                            }
                            currency__ = Some(map_.next_value()?);
                        }
                        GeneratedField::TrackingId => {
                            if tracking_id__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingId"));
                            }
                            tracking_id__ = Some(map_.next_value()?);
                        }
                        GeneratedField::RefNumber => {
                            if ref_number__.is_some() {
                                return Err(serde::de::Error::duplicate_field("refNumber"));
                            }
                            ref_number__ = Some(map_.next_value()?);
                        }
                        GeneratedField::RequestDateTime => {
                            if request_date_time__.is_some() {
                                return Err(serde::de::Error::duplicate_field("requestDateTime"));
                            }
                            request_date_time__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(CashResponse {
                    party: party__,
                    amount: amount__.unwrap_or_default(),
                    currency: currency__.unwrap_or_default(),
                    tracking_id: tracking_id__.unwrap_or_default(),
                    ref_number: ref_number__.unwrap_or_default(),
                    request_date_time: request_date_time__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.CashResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for ConfigureMinterControllerRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.controller.is_empty() {
            len += 1;
        }
        if !self.minter.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.ConfigureMinterControllerRequest", len)?;
        if !self.controller.is_empty() {
            struct_ser.serialize_field("controller", &self.controller)?;
        }
        if !self.minter.is_empty() {
            struct_ser.serialize_field("minter", &self.minter)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for ConfigureMinterControllerRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "controller",
            "minter",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Controller,
            Minter,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "controller" => Ok(GeneratedField::Controller),
                            "minter" => Ok(GeneratedField::Minter),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = ConfigureMinterControllerRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.ConfigureMinterControllerRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<ConfigureMinterControllerRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut controller__ = None;
                let mut minter__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Controller => {
                            if controller__.is_some() {
                                return Err(serde::de::Error::duplicate_field("controller"));
                            }
                            controller__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Minter => {
                            if minter__.is_some() {
                                return Err(serde::de::Error::duplicate_field("minter"));
                            }
                            minter__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(ConfigureMinterControllerRequest {
                    controller: controller__.unwrap_or_default(),
                    minter: minter__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.ConfigureMinterControllerRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for ConfigureMinterControllerResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.txhash.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.ConfigureMinterControllerResponse", len)?;
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for ConfigureMinterControllerResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "txhash",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Txhash,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "txhash" => Ok(GeneratedField::Txhash),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = ConfigureMinterControllerResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.ConfigureMinterControllerResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<ConfigureMinterControllerResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut txhash__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(ConfigureMinterControllerResponse {
                    txhash: txhash__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.ConfigureMinterControllerResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for ConfigureMinterRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.address.is_empty() {
            len += 1;
        }
        if !self.allowance_denom.is_empty() {
            len += 1;
        }
        if !self.allowance_value.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.ConfigureMinterRequest", len)?;
        if !self.address.is_empty() {
            struct_ser.serialize_field("address", &self.address)?;
        }
        if !self.allowance_denom.is_empty() {
            struct_ser.serialize_field("allowanceDenom", &self.allowance_denom)?;
        }
        if !self.allowance_value.is_empty() {
            struct_ser.serialize_field("allowanceValue", &self.allowance_value)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for ConfigureMinterRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "address",
            "allowance_denom",
            "allowanceDenom",
            "allowance_value",
            "allowanceValue",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Address,
            AllowanceDenom,
            AllowanceValue,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "address" => Ok(GeneratedField::Address),
                            "allowanceDenom" | "allowance_denom" => Ok(GeneratedField::AllowanceDenom),
                            "allowanceValue" | "allowance_value" => Ok(GeneratedField::AllowanceValue),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = ConfigureMinterRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.ConfigureMinterRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<ConfigureMinterRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut address__ = None;
                let mut allowance_denom__ = None;
                let mut allowance_value__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Address => {
                            if address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("address"));
                            }
                            address__ = Some(map_.next_value()?);
                        }
                        GeneratedField::AllowanceDenom => {
                            if allowance_denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("allowanceDenom"));
                            }
                            allowance_denom__ = Some(map_.next_value()?);
                        }
                        GeneratedField::AllowanceValue => {
                            if allowance_value__.is_some() {
                                return Err(serde::de::Error::duplicate_field("allowanceValue"));
                            }
                            allowance_value__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(ConfigureMinterRequest {
                    address: address__.unwrap_or_default(),
                    allowance_denom: allowance_denom__.unwrap_or_default(),
                    allowance_value: allowance_value__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.ConfigureMinterRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for ConfigureMinterResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.txhash.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.ConfigureMinterResponse", len)?;
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for ConfigureMinterResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "txhash",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Txhash,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "txhash" => Ok(GeneratedField::Txhash),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = ConfigureMinterResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.ConfigureMinterResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<ConfigureMinterResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut txhash__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(ConfigureMinterResponse {
                    txhash: txhash__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.ConfigureMinterResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for CryptographAlgorithm {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        let variant = match self {
            Self::Unspecified => "CryptographAlgorithm_UNSPECIFIED",
            Self::Secp256k1 => "Secp256k1",
            Self::Ed25519 => "Ed25519",
            Self::Secp256r1 => "Secp256r1",
            Self::Rsa2048 => "RSA2048",
        };
        serializer.serialize_str(variant)
    }
}
impl<'de> serde::Deserialize<'de> for CryptographAlgorithm {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "CryptographAlgorithm_UNSPECIFIED",
            "Secp256k1",
            "Ed25519",
            "Secp256r1",
            "RSA2048",
        ];

        struct GeneratedVisitor;

        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = CryptographAlgorithm;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                write!(formatter, "expected one of: {:?}", &FIELDS)
            }

            fn visit_i64<E>(self, v: i64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Signed(v), &self)
                    })
            }

            fn visit_u64<E>(self, v: u64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Unsigned(v), &self)
                    })
            }

            fn visit_str<E>(self, value: &str) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                match value {
                    "CryptographAlgorithm_UNSPECIFIED" => Ok(CryptographAlgorithm::Unspecified),
                    "Secp256k1" => Ok(CryptographAlgorithm::Secp256k1),
                    "Ed25519" => Ok(CryptographAlgorithm::Ed25519),
                    "Secp256r1" => Ok(CryptographAlgorithm::Secp256r1),
                    "RSA2048" => Ok(CryptographAlgorithm::Rsa2048),
                    _ => Err(serde::de::Error::unknown_variant(value, FIELDS)),
                }
            }
        }
        deserializer.deserialize_any(GeneratedVisitor)
    }
}
impl serde::Serialize for DenomMetadata {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.description.is_empty() {
            len += 1;
        }
        if !self.denom_units.is_empty() {
            len += 1;
        }
        if !self.base.is_empty() {
            len += 1;
        }
        if !self.display.is_empty() {
            len += 1;
        }
        if !self.name.is_empty() {
            len += 1;
        }
        if !self.symbol.is_empty() {
            len += 1;
        }
        if self.uri.is_some() {
            len += 1;
        }
        if self.uri_hash.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.DenomMetadata", len)?;
        if !self.description.is_empty() {
            struct_ser.serialize_field("description", &self.description)?;
        }
        if !self.denom_units.is_empty() {
            struct_ser.serialize_field("denomUnits", &self.denom_units)?;
        }
        if !self.base.is_empty() {
            struct_ser.serialize_field("base", &self.base)?;
        }
        if !self.display.is_empty() {
            struct_ser.serialize_field("display", &self.display)?;
        }
        if !self.name.is_empty() {
            struct_ser.serialize_field("name", &self.name)?;
        }
        if !self.symbol.is_empty() {
            struct_ser.serialize_field("symbol", &self.symbol)?;
        }
        if let Some(v) = self.uri.as_ref() {
            struct_ser.serialize_field("uri", v)?;
        }
        if let Some(v) = self.uri_hash.as_ref() {
            struct_ser.serialize_field("uriHash", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for DenomMetadata {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "description",
            "denom_units",
            "denomUnits",
            "base",
            "display",
            "name",
            "symbol",
            "uri",
            "uri_hash",
            "uriHash",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Description,
            DenomUnits,
            Base,
            Display,
            Name,
            Symbol,
            Uri,
            UriHash,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "description" => Ok(GeneratedField::Description),
                            "denomUnits" | "denom_units" => Ok(GeneratedField::DenomUnits),
                            "base" => Ok(GeneratedField::Base),
                            "display" => Ok(GeneratedField::Display),
                            "name" => Ok(GeneratedField::Name),
                            "symbol" => Ok(GeneratedField::Symbol),
                            "uri" => Ok(GeneratedField::Uri),
                            "uriHash" | "uri_hash" => Ok(GeneratedField::UriHash),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = DenomMetadata;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.DenomMetadata")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<DenomMetadata, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut description__ = None;
                let mut denom_units__ = None;
                let mut base__ = None;
                let mut display__ = None;
                let mut name__ = None;
                let mut symbol__ = None;
                let mut uri__ = None;
                let mut uri_hash__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Description => {
                            if description__.is_some() {
                                return Err(serde::de::Error::duplicate_field("description"));
                            }
                            description__ = Some(map_.next_value()?);
                        }
                        GeneratedField::DenomUnits => {
                            if denom_units__.is_some() {
                                return Err(serde::de::Error::duplicate_field("denomUnits"));
                            }
                            denom_units__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Base => {
                            if base__.is_some() {
                                return Err(serde::de::Error::duplicate_field("base"));
                            }
                            base__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Display => {
                            if display__.is_some() {
                                return Err(serde::de::Error::duplicate_field("display"));
                            }
                            display__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Name => {
                            if name__.is_some() {
                                return Err(serde::de::Error::duplicate_field("name"));
                            }
                            name__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Symbol => {
                            if symbol__.is_some() {
                                return Err(serde::de::Error::duplicate_field("symbol"));
                            }
                            symbol__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Uri => {
                            if uri__.is_some() {
                                return Err(serde::de::Error::duplicate_field("uri"));
                            }
                            uri__ = map_.next_value()?;
                        }
                        GeneratedField::UriHash => {
                            if uri_hash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("uriHash"));
                            }
                            uri_hash__ = map_.next_value()?;
                        }
                    }
                }
                Ok(DenomMetadata {
                    description: description__.unwrap_or_default(),
                    denom_units: denom_units__.unwrap_or_default(),
                    base: base__.unwrap_or_default(),
                    display: display__.unwrap_or_default(),
                    name: name__.unwrap_or_default(),
                    symbol: symbol__.unwrap_or_default(),
                    uri: uri__,
                    uri_hash: uri_hash__,
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.DenomMetadata", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for DenomUnit {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.denom.is_empty() {
            len += 1;
        }
        if self.exponent.is_some() {
            len += 1;
        }
        if !self.aliases.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.DenomUnit", len)?;
        if !self.denom.is_empty() {
            struct_ser.serialize_field("denom", &self.denom)?;
        }
        if let Some(v) = self.exponent.as_ref() {
            struct_ser.serialize_field("exponent", v)?;
        }
        if !self.aliases.is_empty() {
            struct_ser.serialize_field("aliases", &self.aliases)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for DenomUnit {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "denom",
            "exponent",
            "aliases",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Denom,
            Exponent,
            Aliases,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "denom" => Ok(GeneratedField::Denom),
                            "exponent" => Ok(GeneratedField::Exponent),
                            "aliases" => Ok(GeneratedField::Aliases),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = DenomUnit;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.DenomUnit")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<DenomUnit, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut denom__ = None;
                let mut exponent__ = None;
                let mut aliases__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Denom => {
                            if denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("denom"));
                            }
                            denom__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Exponent => {
                            if exponent__.is_some() {
                                return Err(serde::de::Error::duplicate_field("exponent"));
                            }
                            exponent__ = 
                                map_.next_value::<::std::option::Option<::pbjson::private::NumberDeserialize<_>>>()?.map(|x| x.0)
                            ;
                        }
                        GeneratedField::Aliases => {
                            if aliases__.is_some() {
                                return Err(serde::de::Error::duplicate_field("aliases"));
                            }
                            aliases__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(DenomUnit {
                    denom: denom__.unwrap_or_default(),
                    exponent: exponent__,
                    aliases: aliases__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.DenomUnit", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for EchoRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.echo.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.EchoRequest", len)?;
        if !self.echo.is_empty() {
            struct_ser.serialize_field("echo", &self.echo)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for EchoRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "echo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Echo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "echo" => Ok(GeneratedField::Echo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = EchoRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.EchoRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<EchoRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut echo__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Echo => {
                            if echo__.is_some() {
                                return Err(serde::de::Error::duplicate_field("echo"));
                            }
                            echo__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(EchoRequest {
                    echo: echo__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.EchoRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for EchoResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.echo.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.EchoResponse", len)?;
        if !self.echo.is_empty() {
            struct_ser.serialize_field("echo", &self.echo)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for EchoResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "echo",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Echo,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "echo" => Ok(GeneratedField::Echo),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = EchoResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.EchoResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<EchoResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut echo__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Echo => {
                            if echo__.is_some() {
                                return Err(serde::de::Error::duplicate_field("echo"));
                            }
                            echo__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(EchoResponse {
                    echo: echo__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.EchoResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for ErrorCode {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        let variant = match self {
            Self::Unspecified => "ErrorCode_UNSPECIFIED",
            Self::InvalidCurrency => "INVALID_CURRENCY",
            Self::CordaFlowFailed => "CORDA_FLOW_FAILED",
            Self::PartiesNotFundingNode => "PARTIES_NOT_FUNDING_NODE",
            Self::PartiesCannotBeTheSame => "PARTIES_CANNOT_BE_THE_SAME",
            Self::FundingNodeCannotOriginatePayments => "FUNDING_NODE_CANNOT_ORIGINATE_PAYMENTS",
            Self::FundingNodeCannotReceivePayments => "FUNDING_NODE_CANNOT_RECEIVE_PAYMENTS",
            Self::NotSufficientFunds => "NOT_SUFFICIENT_FUNDS",
            Self::InsufficientNotLockedBalance => "INSUFFICIENT_NOT_LOCKED_BALANCE",
            Self::OriginatingPartyRequired => "ORIGINATING_PARTY_REQUIRED",
            Self::DataNotFound => "DATA_NOT_FOUND",
            Self::InvalidParty => "INVALID_PARTY",
        };
        serializer.serialize_str(variant)
    }
}
impl<'de> serde::Deserialize<'de> for ErrorCode {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "ErrorCode_UNSPECIFIED",
            "INVALID_CURRENCY",
            "CORDA_FLOW_FAILED",
            "PARTIES_NOT_FUNDING_NODE",
            "PARTIES_CANNOT_BE_THE_SAME",
            "FUNDING_NODE_CANNOT_ORIGINATE_PAYMENTS",
            "FUNDING_NODE_CANNOT_RECEIVE_PAYMENTS",
            "NOT_SUFFICIENT_FUNDS",
            "INSUFFICIENT_NOT_LOCKED_BALANCE",
            "ORIGINATING_PARTY_REQUIRED",
            "DATA_NOT_FOUND",
            "INVALID_PARTY",
        ];

        struct GeneratedVisitor;

        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = ErrorCode;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                write!(formatter, "expected one of: {:?}", &FIELDS)
            }

            fn visit_i64<E>(self, v: i64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Signed(v), &self)
                    })
            }

            fn visit_u64<E>(self, v: u64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Unsigned(v), &self)
                    })
            }

            fn visit_str<E>(self, value: &str) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                match value {
                    "ErrorCode_UNSPECIFIED" => Ok(ErrorCode::Unspecified),
                    "INVALID_CURRENCY" => Ok(ErrorCode::InvalidCurrency),
                    "CORDA_FLOW_FAILED" => Ok(ErrorCode::CordaFlowFailed),
                    "PARTIES_NOT_FUNDING_NODE" => Ok(ErrorCode::PartiesNotFundingNode),
                    "PARTIES_CANNOT_BE_THE_SAME" => Ok(ErrorCode::PartiesCannotBeTheSame),
                    "FUNDING_NODE_CANNOT_ORIGINATE_PAYMENTS" => Ok(ErrorCode::FundingNodeCannotOriginatePayments),
                    "FUNDING_NODE_CANNOT_RECEIVE_PAYMENTS" => Ok(ErrorCode::FundingNodeCannotReceivePayments),
                    "NOT_SUFFICIENT_FUNDS" => Ok(ErrorCode::NotSufficientFunds),
                    "INSUFFICIENT_NOT_LOCKED_BALANCE" => Ok(ErrorCode::InsufficientNotLockedBalance),
                    "ORIGINATING_PARTY_REQUIRED" => Ok(ErrorCode::OriginatingPartyRequired),
                    "DATA_NOT_FOUND" => Ok(ErrorCode::DataNotFound),
                    "INVALID_PARTY" => Ok(ErrorCode::InvalidParty),
                    _ => Err(serde::de::Error::unknown_variant(value, FIELDS)),
                }
            }
        }
        deserializer.deserialize_any(GeneratedVisitor)
    }
}
impl serde::Serialize for FindDenomMetadataResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.description.is_empty() {
            len += 1;
        }
        if !self.base.is_empty() {
            len += 1;
        }
        if !self.display.is_empty() {
            len += 1;
        }
        if !self.name.is_empty() {
            len += 1;
        }
        if !self.symbol.is_empty() {
            len += 1;
        }
        if !self.denom.is_empty() {
            len += 1;
        }
        if self.exponent != 0 {
            len += 1;
        }
        if !self.aliases.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.FindDenomMetadataResponse", len)?;
        if !self.description.is_empty() {
            struct_ser.serialize_field("description", &self.description)?;
        }
        if !self.base.is_empty() {
            struct_ser.serialize_field("base", &self.base)?;
        }
        if !self.display.is_empty() {
            struct_ser.serialize_field("display", &self.display)?;
        }
        if !self.name.is_empty() {
            struct_ser.serialize_field("name", &self.name)?;
        }
        if !self.symbol.is_empty() {
            struct_ser.serialize_field("symbol", &self.symbol)?;
        }
        if !self.denom.is_empty() {
            struct_ser.serialize_field("denom", &self.denom)?;
        }
        if self.exponent != 0 {
            struct_ser.serialize_field("exponent", &self.exponent)?;
        }
        if !self.aliases.is_empty() {
            struct_ser.serialize_field("aliases", &self.aliases)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for FindDenomMetadataResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "description",
            "base",
            "display",
            "name",
            "symbol",
            "denom",
            "exponent",
            "aliases",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Description,
            Base,
            Display,
            Name,
            Symbol,
            Denom,
            Exponent,
            Aliases,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "description" => Ok(GeneratedField::Description),
                            "base" => Ok(GeneratedField::Base),
                            "display" => Ok(GeneratedField::Display),
                            "name" => Ok(GeneratedField::Name),
                            "symbol" => Ok(GeneratedField::Symbol),
                            "denom" => Ok(GeneratedField::Denom),
                            "exponent" => Ok(GeneratedField::Exponent),
                            "aliases" => Ok(GeneratedField::Aliases),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = FindDenomMetadataResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.FindDenomMetadataResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<FindDenomMetadataResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut description__ = None;
                let mut base__ = None;
                let mut display__ = None;
                let mut name__ = None;
                let mut symbol__ = None;
                let mut denom__ = None;
                let mut exponent__ = None;
                let mut aliases__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Description => {
                            if description__.is_some() {
                                return Err(serde::de::Error::duplicate_field("description"));
                            }
                            description__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Base => {
                            if base__.is_some() {
                                return Err(serde::de::Error::duplicate_field("base"));
                            }
                            base__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Display => {
                            if display__.is_some() {
                                return Err(serde::de::Error::duplicate_field("display"));
                            }
                            display__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Name => {
                            if name__.is_some() {
                                return Err(serde::de::Error::duplicate_field("name"));
                            }
                            name__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Symbol => {
                            if symbol__.is_some() {
                                return Err(serde::de::Error::duplicate_field("symbol"));
                            }
                            symbol__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Denom => {
                            if denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("denom"));
                            }
                            denom__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Exponent => {
                            if exponent__.is_some() {
                                return Err(serde::de::Error::duplicate_field("exponent"));
                            }
                            exponent__ = 
                                Some(map_.next_value::<::pbjson::private::NumberDeserialize<_>>()?.0)
                            ;
                        }
                        GeneratedField::Aliases => {
                            if aliases__.is_some() {
                                return Err(serde::de::Error::duplicate_field("aliases"));
                            }
                            aliases__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(FindDenomMetadataResponse {
                    description: description__.unwrap_or_default(),
                    base: base__.unwrap_or_default(),
                    display: display__.unwrap_or_default(),
                    name: name__.unwrap_or_default(),
                    symbol: symbol__.unwrap_or_default(),
                    denom: denom__.unwrap_or_default(),
                    exponent: exponent__.unwrap_or_default(),
                    aliases: aliases__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.FindDenomMetadataResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for FindMetadataForDenomRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.denom.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.FindMetadataForDenomRequest", len)?;
        if !self.denom.is_empty() {
            struct_ser.serialize_field("denom", &self.denom)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for FindMetadataForDenomRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "denom",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Denom,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "denom" => Ok(GeneratedField::Denom),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = FindMetadataForDenomRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.FindMetadataForDenomRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<FindMetadataForDenomRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut denom__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Denom => {
                            if denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("denom"));
                            }
                            denom__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(FindMetadataForDenomRequest {
                    denom: denom__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.FindMetadataForDenomRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for FromMemberRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.tracking_id.is_empty() {
            len += 1;
        }
        if !self.txhash1.is_empty() {
            len += 1;
        }
        if !self.txhash2.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.FromMemberRequest", len)?;
        if !self.tracking_id.is_empty() {
            struct_ser.serialize_field("trackingId", &self.tracking_id)?;
        }
        if !self.txhash1.is_empty() {
            struct_ser.serialize_field("txhash1", &self.txhash1)?;
        }
        if !self.txhash2.is_empty() {
            struct_ser.serialize_field("txhash2", &self.txhash2)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for FromMemberRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "tracking_id",
            "trackingId",
            "txhash1",
            "txhash2",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            TrackingId,
            Txhash1,
            Txhash2,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "trackingId" | "tracking_id" => Ok(GeneratedField::TrackingId),
                            "txhash1" => Ok(GeneratedField::Txhash1),
                            "txhash2" => Ok(GeneratedField::Txhash2),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = FromMemberRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.FromMemberRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<FromMemberRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut tracking_id__ = None;
                let mut txhash1__ = None;
                let mut txhash2__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::TrackingId => {
                            if tracking_id__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingId"));
                            }
                            tracking_id__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Txhash1 => {
                            if txhash1__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash1"));
                            }
                            txhash1__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Txhash2 => {
                            if txhash2__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash2"));
                            }
                            txhash2__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(FromMemberRequest {
                    tracking_id: tracking_id__.unwrap_or_default(),
                    txhash1: txhash1__.unwrap_or_default(),
                    txhash2: txhash2__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.FromMemberRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GenKeyRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.key_label.is_empty() {
            len += 1;
        }
        if self.key_type != 0 {
            len += 1;
        }
        if self.algorithm != 0 {
            len += 1;
        }
        if self.persistent {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GenKeyRequest", len)?;
        if !self.key_label.is_empty() {
            struct_ser.serialize_field("keyLabel", &self.key_label)?;
        }
        if self.key_type != 0 {
            let v = KeyType::try_from(self.key_type)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", self.key_type)))?;
            struct_ser.serialize_field("keyType", &v)?;
        }
        if self.algorithm != 0 {
            let v = CryptographAlgorithm::try_from(self.algorithm)
                .map_err(|_| serde::ser::Error::custom(format!("Invalid variant {}", self.algorithm)))?;
            struct_ser.serialize_field("algorithm", &v)?;
        }
        if self.persistent {
            struct_ser.serialize_field("persistent", &self.persistent)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GenKeyRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "key_label",
            "keyLabel",
            "key_type",
            "keyType",
            "algorithm",
            "persistent",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            KeyLabel,
            KeyType,
            Algorithm,
            Persistent,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "keyLabel" | "key_label" => Ok(GeneratedField::KeyLabel),
                            "keyType" | "key_type" => Ok(GeneratedField::KeyType),
                            "algorithm" => Ok(GeneratedField::Algorithm),
                            "persistent" => Ok(GeneratedField::Persistent),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GenKeyRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GenKeyRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GenKeyRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut key_label__ = None;
                let mut key_type__ = None;
                let mut algorithm__ = None;
                let mut persistent__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::KeyLabel => {
                            if key_label__.is_some() {
                                return Err(serde::de::Error::duplicate_field("keyLabel"));
                            }
                            key_label__ = Some(map_.next_value()?);
                        }
                        GeneratedField::KeyType => {
                            if key_type__.is_some() {
                                return Err(serde::de::Error::duplicate_field("keyType"));
                            }
                            key_type__ = Some(map_.next_value::<KeyType>()? as i32);
                        }
                        GeneratedField::Algorithm => {
                            if algorithm__.is_some() {
                                return Err(serde::de::Error::duplicate_field("algorithm"));
                            }
                            algorithm__ = Some(map_.next_value::<CryptographAlgorithm>()? as i32);
                        }
                        GeneratedField::Persistent => {
                            if persistent__.is_some() {
                                return Err(serde::de::Error::duplicate_field("persistent"));
                            }
                            persistent__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GenKeyRequest {
                    key_label: key_label__.unwrap_or_default(),
                    key_type: key_type__.unwrap_or_default(),
                    algorithm: algorithm__.unwrap_or_default(),
                    persistent: persistent__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GenKeyRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GenKeyResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.key_label.is_empty() {
            len += 1;
        }
        if self.persisted {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GenKeyResponse", len)?;
        if !self.key_label.is_empty() {
            struct_ser.serialize_field("keyLabel", &self.key_label)?;
        }
        if self.persisted {
            struct_ser.serialize_field("persisted", &self.persisted)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GenKeyResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "key_label",
            "keyLabel",
            "persisted",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            KeyLabel,
            Persisted,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "keyLabel" | "key_label" => Ok(GeneratedField::KeyLabel),
                            "persisted" => Ok(GeneratedField::Persisted),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GenKeyResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GenKeyResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GenKeyResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut key_label__ = None;
                let mut persisted__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::KeyLabel => {
                            if key_label__.is_some() {
                                return Err(serde::de::Error::duplicate_field("keyLabel"));
                            }
                            key_label__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Persisted => {
                            if persisted__.is_some() {
                                return Err(serde::de::Error::duplicate_field("persisted"));
                            }
                            persisted__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GenKeyResponse {
                    key_label: key_label__.unwrap_or_default(),
                    persisted: persisted__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GenKeyResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetAllBlacklistedRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let len = 0;
        let struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetAllBlacklistedRequest", len)?;
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetAllBlacklistedRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                            Err(serde::de::Error::unknown_field(value, FIELDS))
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetAllBlacklistedRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetAllBlacklistedRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetAllBlacklistedRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                while map_.next_key::<GeneratedField>()?.is_some() {
                    let _ = map_.next_value::<serde::de::IgnoredAny>()?;
                }
                Ok(GetAllBlacklistedRequest {
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetAllBlacklistedRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetAllBlacklistedResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.blacklisted.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetAllBlacklistedResponse", len)?;
        if !self.blacklisted.is_empty() {
            struct_ser.serialize_field("blacklisted", &self.blacklisted)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetAllBlacklistedResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "blacklisted",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Blacklisted,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "blacklisted" => Ok(GeneratedField::Blacklisted),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetAllBlacklistedResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetAllBlacklistedResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetAllBlacklistedResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut blacklisted__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Blacklisted => {
                            if blacklisted__.is_some() {
                                return Err(serde::de::Error::duplicate_field("blacklisted"));
                            }
                            blacklisted__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetAllBlacklistedResponse {
                    blacklisted: blacklisted__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetAllBlacklistedResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetAllDenomMetadataRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let len = 0;
        let struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetAllDenomMetadataRequest", len)?;
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetAllDenomMetadataRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                            Err(serde::de::Error::unknown_field(value, FIELDS))
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetAllDenomMetadataRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetAllDenomMetadataRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetAllDenomMetadataRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                while map_.next_key::<GeneratedField>()?.is_some() {
                    let _ = map_.next_value::<serde::de::IgnoredAny>()?;
                }
                Ok(GetAllDenomMetadataRequest {
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetAllDenomMetadataRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetAllDenomMetadataResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.denom_metadata.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetAllDenomMetadataResponse", len)?;
        if !self.denom_metadata.is_empty() {
            struct_ser.serialize_field("denomMetadata", &self.denom_metadata)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetAllDenomMetadataResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "denom_metadata",
            "denomMetadata",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            DenomMetadata,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "denomMetadata" | "denom_metadata" => Ok(GeneratedField::DenomMetadata),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetAllDenomMetadataResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetAllDenomMetadataResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetAllDenomMetadataResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut denom_metadata__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::DenomMetadata => {
                            if denom_metadata__.is_some() {
                                return Err(serde::de::Error::duplicate_field("denomMetadata"));
                            }
                            denom_metadata__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetAllDenomMetadataResponse {
                    denom_metadata: denom_metadata__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetAllDenomMetadataResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetAllMinterControllersRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let len = 0;
        let struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetAllMinterControllersRequest", len)?;
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetAllMinterControllersRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                            Err(serde::de::Error::unknown_field(value, FIELDS))
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetAllMinterControllersRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetAllMinterControllersRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetAllMinterControllersRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                while map_.next_key::<GeneratedField>()?.is_some() {
                    let _ = map_.next_value::<serde::de::IgnoredAny>()?;
                }
                Ok(GetAllMinterControllersRequest {
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetAllMinterControllersRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetAllMinterControllersResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.minter_controllers.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetAllMinterControllersResponse", len)?;
        if !self.minter_controllers.is_empty() {
            struct_ser.serialize_field("minterControllers", &self.minter_controllers)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetAllMinterControllersResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "minter_controllers",
            "minterControllers",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            MinterControllers,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "minterControllers" | "minter_controllers" => Ok(GeneratedField::MinterControllers),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetAllMinterControllersResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetAllMinterControllersResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetAllMinterControllersResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut minter_controllers__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::MinterControllers => {
                            if minter_controllers__.is_some() {
                                return Err(serde::de::Error::duplicate_field("minterControllers"));
                            }
                            minter_controllers__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetAllMinterControllersResponse {
                    minter_controllers: minter_controllers__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetAllMinterControllersResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetAllMintersRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let len = 0;
        let struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetAllMintersRequest", len)?;
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetAllMintersRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                            Err(serde::de::Error::unknown_field(value, FIELDS))
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetAllMintersRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetAllMintersRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetAllMintersRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                while map_.next_key::<GeneratedField>()?.is_some() {
                    let _ = map_.next_value::<serde::de::IgnoredAny>()?;
                }
                Ok(GetAllMintersRequest {
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetAllMintersRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetAllMintersResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.minters.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetAllMintersResponse", len)?;
        if !self.minters.is_empty() {
            struct_ser.serialize_field("minters", &self.minters)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetAllMintersResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "minters",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Minters,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "minters" => Ok(GeneratedField::Minters),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetAllMintersResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetAllMintersResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetAllMintersResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut minters__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Minters => {
                            if minters__.is_some() {
                                return Err(serde::de::Error::duplicate_field("minters"));
                            }
                            minters__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetAllMintersResponse {
                    minters: minters__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetAllMintersResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetAllMintingDenomsRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let len = 0;
        let struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetAllMintingDenomsRequest", len)?;
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetAllMintingDenomsRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                            Err(serde::de::Error::unknown_field(value, FIELDS))
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetAllMintingDenomsRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetAllMintingDenomsRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetAllMintingDenomsRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                while map_.next_key::<GeneratedField>()?.is_some() {
                    let _ = map_.next_value::<serde::de::IgnoredAny>()?;
                }
                Ok(GetAllMintingDenomsRequest {
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetAllMintingDenomsRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetAllMintingDenomsResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.minting_denoms.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetAllMintingDenomsResponse", len)?;
        if !self.minting_denoms.is_empty() {
            struct_ser.serialize_field("mintingDenoms", &self.minting_denoms)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetAllMintingDenomsResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "minting_denoms",
            "mintingDenoms",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            MintingDenoms,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "mintingDenoms" | "minting_denoms" => Ok(GeneratedField::MintingDenoms),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetAllMintingDenomsResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetAllMintingDenomsResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetAllMintingDenomsResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut minting_denoms__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::MintingDenoms => {
                            if minting_denoms__.is_some() {
                                return Err(serde::de::Error::duplicate_field("mintingDenoms"));
                            }
                            minting_denoms__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetAllMintingDenomsResponse {
                    minting_denoms: minting_denoms__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetAllMintingDenomsResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetAurumConfigRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let len = 0;
        let struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetAurumConfigRequest", len)?;
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetAurumConfigRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                            Err(serde::de::Error::unknown_field(value, FIELDS))
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetAurumConfigRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetAurumConfigRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetAurumConfigRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                while map_.next_key::<GeneratedField>()?.is_some() {
                    let _ = map_.next_value::<serde::de::IgnoredAny>()?;
                }
                Ok(GetAurumConfigRequest {
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetAurumConfigRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetAurumConfigResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.owner.is_empty() {
            len += 1;
        }
        if !self.tf_address.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetAurumConfigResponse", len)?;
        if !self.owner.is_empty() {
            struct_ser.serialize_field("owner", &self.owner)?;
        }
        if !self.tf_address.is_empty() {
            struct_ser.serialize_field("tfAddress", &self.tf_address)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetAurumConfigResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "owner",
            "tf_address",
            "tfAddress",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Owner,
            TfAddress,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "owner" => Ok(GeneratedField::Owner),
                            "tfAddress" | "tf_address" => Ok(GeneratedField::TfAddress),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetAurumConfigResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetAurumConfigResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetAurumConfigResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut owner__ = None;
                let mut tf_address__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Owner => {
                            if owner__.is_some() {
                                return Err(serde::de::Error::duplicate_field("owner"));
                            }
                            owner__ = Some(map_.next_value()?);
                        }
                        GeneratedField::TfAddress => {
                            if tf_address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("tfAddress"));
                            }
                            tf_address__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetAurumConfigResponse {
                    owner: owner__.unwrap_or_default(),
                    tf_address: tf_address__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetAurumConfigResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetBlacklistedRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.address.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetBlacklistedRequest", len)?;
        if !self.address.is_empty() {
            struct_ser.serialize_field("address", &self.address)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetBlacklistedRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "address",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Address,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "address" => Ok(GeneratedField::Address),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetBlacklistedRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetBlacklistedRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetBlacklistedRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut address__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Address => {
                            if address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("address"));
                            }
                            address__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetBlacklistedRequest {
                    address: address__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetBlacklistedRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetBlacklistedResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.address.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetBlacklistedResponse", len)?;
        if !self.address.is_empty() {
            struct_ser.serialize_field("address", &self.address)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetBlacklistedResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "address",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Address,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "address" => Ok(GeneratedField::Address),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetBlacklistedResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetBlacklistedResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetBlacklistedResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut address__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Address => {
                            if address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("address"));
                            }
                            address__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetBlacklistedResponse {
                    address: address__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetBlacklistedResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetBlacklisterRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let len = 0;
        let struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetBlacklisterRequest", len)?;
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetBlacklisterRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                            Err(serde::de::Error::unknown_field(value, FIELDS))
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetBlacklisterRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetBlacklisterRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetBlacklisterRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                while map_.next_key::<GeneratedField>()?.is_some() {
                    let _ = map_.next_value::<serde::de::IgnoredAny>()?;
                }
                Ok(GetBlacklisterRequest {
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetBlacklisterRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetBlacklisterResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.address.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetBlacklisterResponse", len)?;
        if !self.address.is_empty() {
            struct_ser.serialize_field("address", &self.address)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetBlacklisterResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "address",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Address,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "address" => Ok(GeneratedField::Address),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetBlacklisterResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetBlacklisterResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetBlacklisterResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut address__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Address => {
                            if address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("address"));
                            }
                            address__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetBlacklisterResponse {
                    address: address__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetBlacklisterResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetDenomMetadataRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.denom.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetDenomMetadataRequest", len)?;
        if !self.denom.is_empty() {
            struct_ser.serialize_field("denom", &self.denom)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetDenomMetadataRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "denom",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Denom,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "denom" => Ok(GeneratedField::Denom),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetDenomMetadataRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetDenomMetadataRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetDenomMetadataRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut denom__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Denom => {
                            if denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("denom"));
                            }
                            denom__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetDenomMetadataRequest {
                    denom: denom__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetDenomMetadataRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetDenomMetadataResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.metadata.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetDenomMetadataResponse", len)?;
        if let Some(v) = self.metadata.as_ref() {
            struct_ser.serialize_field("metadata", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetDenomMetadataResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "metadata",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Metadata,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "metadata" => Ok(GeneratedField::Metadata),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetDenomMetadataResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetDenomMetadataResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetDenomMetadataResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut metadata__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Metadata => {
                            if metadata__.is_some() {
                                return Err(serde::de::Error::duplicate_field("metadata"));
                            }
                            metadata__ = map_.next_value()?;
                        }
                    }
                }
                Ok(GetDenomMetadataResponse {
                    metadata: metadata__,
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetDenomMetadataResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetFeeBasicAllowanceRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.grantee.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetFeeBasicAllowanceRequest", len)?;
        if let Some(v) = self.grantee.as_ref() {
            struct_ser.serialize_field("grantee", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetFeeBasicAllowanceRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "grantee",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Grantee,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "grantee" => Ok(GeneratedField::Grantee),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetFeeBasicAllowanceRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetFeeBasicAllowanceRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetFeeBasicAllowanceRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut grantee__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Grantee => {
                            if grantee__.is_some() {
                                return Err(serde::de::Error::duplicate_field("grantee"));
                            }
                            grantee__ = map_.next_value()?;
                        }
                    }
                }
                Ok(GetFeeBasicAllowanceRequest {
                    grantee: grantee__,
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetFeeBasicAllowanceRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetFeeBasicAllowanceResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.fee_basic_grant.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetFeeBasicAllowanceResponse", len)?;
        if let Some(v) = self.fee_basic_grant.as_ref() {
            struct_ser.serialize_field("feeBasicGrant", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetFeeBasicAllowanceResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "fee_basic_grant",
            "feeBasicGrant",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            FeeBasicGrant,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "feeBasicGrant" | "fee_basic_grant" => Ok(GeneratedField::FeeBasicGrant),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetFeeBasicAllowanceResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetFeeBasicAllowanceResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetFeeBasicAllowanceResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut fee_basic_grant__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::FeeBasicGrant => {
                            if fee_basic_grant__.is_some() {
                                return Err(serde::de::Error::duplicate_field("feeBasicGrant"));
                            }
                            fee_basic_grant__ = map_.next_value()?;
                        }
                    }
                }
                Ok(GetFeeBasicAllowanceResponse {
                    fee_basic_grant: fee_basic_grant__,
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetFeeBasicAllowanceResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetFeeBasicGrant {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.granter.is_empty() {
            len += 1;
        }
        if !self.grantee.is_empty() {
            len += 1;
        }
        if !self.allowance_denom.is_empty() {
            len += 1;
        }
        if !self.allowance_value.is_empty() {
            len += 1;
        }
        if !self.expiration.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetFeeBasicGrant", len)?;
        if !self.granter.is_empty() {
            struct_ser.serialize_field("granter", &self.granter)?;
        }
        if !self.grantee.is_empty() {
            struct_ser.serialize_field("grantee", &self.grantee)?;
        }
        if !self.allowance_denom.is_empty() {
            struct_ser.serialize_field("allowanceDenom", &self.allowance_denom)?;
        }
        if !self.allowance_value.is_empty() {
            struct_ser.serialize_field("allowanceValue", &self.allowance_value)?;
        }
        if !self.expiration.is_empty() {
            struct_ser.serialize_field("expiration", &self.expiration)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetFeeBasicGrant {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "granter",
            "grantee",
            "allowance_denom",
            "allowanceDenom",
            "allowance_value",
            "allowanceValue",
            "expiration",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Granter,
            Grantee,
            AllowanceDenom,
            AllowanceValue,
            Expiration,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "granter" => Ok(GeneratedField::Granter),
                            "grantee" => Ok(GeneratedField::Grantee),
                            "allowanceDenom" | "allowance_denom" => Ok(GeneratedField::AllowanceDenom),
                            "allowanceValue" | "allowance_value" => Ok(GeneratedField::AllowanceValue),
                            "expiration" => Ok(GeneratedField::Expiration),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetFeeBasicGrant;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetFeeBasicGrant")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetFeeBasicGrant, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut granter__ = None;
                let mut grantee__ = None;
                let mut allowance_denom__ = None;
                let mut allowance_value__ = None;
                let mut expiration__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Granter => {
                            if granter__.is_some() {
                                return Err(serde::de::Error::duplicate_field("granter"));
                            }
                            granter__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Grantee => {
                            if grantee__.is_some() {
                                return Err(serde::de::Error::duplicate_field("grantee"));
                            }
                            grantee__ = Some(map_.next_value()?);
                        }
                        GeneratedField::AllowanceDenom => {
                            if allowance_denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("allowanceDenom"));
                            }
                            allowance_denom__ = Some(map_.next_value()?);
                        }
                        GeneratedField::AllowanceValue => {
                            if allowance_value__.is_some() {
                                return Err(serde::de::Error::duplicate_field("allowanceValue"));
                            }
                            allowance_value__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Expiration => {
                            if expiration__.is_some() {
                                return Err(serde::de::Error::duplicate_field("expiration"));
                            }
                            expiration__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetFeeBasicGrant {
                    granter: granter__.unwrap_or_default(),
                    grantee: grantee__.unwrap_or_default(),
                    allowance_denom: allowance_denom__.unwrap_or_default(),
                    allowance_value: allowance_value__.unwrap_or_default(),
                    expiration: expiration__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetFeeBasicGrant", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetMasterMinterRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let len = 0;
        let struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetMasterMinterRequest", len)?;
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetMasterMinterRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                            Err(serde::de::Error::unknown_field(value, FIELDS))
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetMasterMinterRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetMasterMinterRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetMasterMinterRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                while map_.next_key::<GeneratedField>()?.is_some() {
                    let _ = map_.next_value::<serde::de::IgnoredAny>()?;
                }
                Ok(GetMasterMinterRequest {
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetMasterMinterRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetMasterMinterResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.address.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetMasterMinterResponse", len)?;
        if !self.address.is_empty() {
            struct_ser.serialize_field("address", &self.address)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetMasterMinterResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "address",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Address,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "address" => Ok(GeneratedField::Address),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetMasterMinterResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetMasterMinterResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetMasterMinterResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut address__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Address => {
                            if address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("address"));
                            }
                            address__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetMasterMinterResponse {
                    address: address__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetMasterMinterResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetMemberRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.id.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetMemberRequest", len)?;
        if !self.id.is_empty() {
            struct_ser.serialize_field("id", &self.id)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetMemberRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "id",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Id,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "id" => Ok(GeneratedField::Id),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetMemberRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetMemberRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetMemberRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut id__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Id => {
                            if id__.is_some() {
                                return Err(serde::de::Error::duplicate_field("id"));
                            }
                            id__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetMemberRequest {
                    id: id__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetMemberRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetMemberResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.id.is_empty() {
            len += 1;
        }
        if !self.addr.is_empty() {
            len += 1;
        }
        if !self.pubkey.is_empty() {
            len += 1;
        }
        if !self.grpc.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetMemberResponse", len)?;
        if !self.id.is_empty() {
            struct_ser.serialize_field("id", &self.id)?;
        }
        if !self.addr.is_empty() {
            struct_ser.serialize_field("addr", &self.addr)?;
        }
        if !self.pubkey.is_empty() {
            struct_ser.serialize_field("pubkey", &self.pubkey)?;
        }
        if !self.grpc.is_empty() {
            struct_ser.serialize_field("grpc", &self.grpc)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetMemberResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "id",
            "addr",
            "pubkey",
            "grpc",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Id,
            Addr,
            Pubkey,
            Grpc,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "id" => Ok(GeneratedField::Id),
                            "addr" => Ok(GeneratedField::Addr),
                            "pubkey" => Ok(GeneratedField::Pubkey),
                            "grpc" => Ok(GeneratedField::Grpc),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetMemberResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetMemberResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetMemberResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut id__ = None;
                let mut addr__ = None;
                let mut pubkey__ = None;
                let mut grpc__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Id => {
                            if id__.is_some() {
                                return Err(serde::de::Error::duplicate_field("id"));
                            }
                            id__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Addr => {
                            if addr__.is_some() {
                                return Err(serde::de::Error::duplicate_field("addr"));
                            }
                            addr__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Pubkey => {
                            if pubkey__.is_some() {
                                return Err(serde::de::Error::duplicate_field("pubkey"));
                            }
                            pubkey__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Grpc => {
                            if grpc__.is_some() {
                                return Err(serde::de::Error::duplicate_field("grpc"));
                            }
                            grpc__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetMemberResponse {
                    id: id__.unwrap_or_default(),
                    addr: addr__.unwrap_or_default(),
                    pubkey: pubkey__.unwrap_or_default(),
                    grpc: grpc__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetMemberResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetMembersRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let len = 0;
        let struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetMembersRequest", len)?;
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetMembersRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                            Err(serde::de::Error::unknown_field(value, FIELDS))
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetMembersRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetMembersRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetMembersRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                while map_.next_key::<GeneratedField>()?.is_some() {
                    let _ = map_.next_value::<serde::de::IgnoredAny>()?;
                }
                Ok(GetMembersRequest {
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetMembersRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetMembersResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.members.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetMembersResponse", len)?;
        if !self.members.is_empty() {
            struct_ser.serialize_field("members", &self.members)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetMembersResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "members",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Members,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "members" => Ok(GeneratedField::Members),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetMembersResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetMembersResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetMembersResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut members__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Members => {
                            if members__.is_some() {
                                return Err(serde::de::Error::duplicate_field("members"));
                            }
                            members__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetMembersResponse {
                    members: members__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetMembersResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetMinterControllerRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.controller.is_empty() {
            len += 1;
        }
        if !self.minter.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetMinterControllerRequest", len)?;
        if !self.controller.is_empty() {
            struct_ser.serialize_field("controller", &self.controller)?;
        }
        if !self.minter.is_empty() {
            struct_ser.serialize_field("minter", &self.minter)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetMinterControllerRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "controller",
            "minter",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Controller,
            Minter,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "controller" => Ok(GeneratedField::Controller),
                            "minter" => Ok(GeneratedField::Minter),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetMinterControllerRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetMinterControllerRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetMinterControllerRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut controller__ = None;
                let mut minter__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Controller => {
                            if controller__.is_some() {
                                return Err(serde::de::Error::duplicate_field("controller"));
                            }
                            controller__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Minter => {
                            if minter__.is_some() {
                                return Err(serde::de::Error::duplicate_field("minter"));
                            }
                            minter__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetMinterControllerRequest {
                    controller: controller__.unwrap_or_default(),
                    minter: minter__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetMinterControllerRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetMinterControllerResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.minter.is_empty() {
            len += 1;
        }
        if !self.controller.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetMinterControllerResponse", len)?;
        if !self.minter.is_empty() {
            struct_ser.serialize_field("minter", &self.minter)?;
        }
        if !self.controller.is_empty() {
            struct_ser.serialize_field("controller", &self.controller)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetMinterControllerResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "minter",
            "controller",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Minter,
            Controller,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "minter" => Ok(GeneratedField::Minter),
                            "controller" => Ok(GeneratedField::Controller),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetMinterControllerResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetMinterControllerResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetMinterControllerResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut minter__ = None;
                let mut controller__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Minter => {
                            if minter__.is_some() {
                                return Err(serde::de::Error::duplicate_field("minter"));
                            }
                            minter__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Controller => {
                            if controller__.is_some() {
                                return Err(serde::de::Error::duplicate_field("controller"));
                            }
                            controller__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetMinterControllerResponse {
                    minter: minter__.unwrap_or_default(),
                    controller: controller__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetMinterControllerResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetMintersRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.address.is_empty() {
            len += 1;
        }
        if !self.denom.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetMintersRequest", len)?;
        if !self.address.is_empty() {
            struct_ser.serialize_field("address", &self.address)?;
        }
        if !self.denom.is_empty() {
            struct_ser.serialize_field("denom", &self.denom)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetMintersRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "address",
            "denom",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Address,
            Denom,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "address" => Ok(GeneratedField::Address),
                            "denom" => Ok(GeneratedField::Denom),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetMintersRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetMintersRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetMintersRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut address__ = None;
                let mut denom__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Address => {
                            if address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("address"));
                            }
                            address__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Denom => {
                            if denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("denom"));
                            }
                            denom__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetMintersRequest {
                    address: address__.unwrap_or_default(),
                    denom: denom__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetMintersRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetMintersResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.address.is_empty() {
            len += 1;
        }
        if !self.allowance_denom.is_empty() {
            len += 1;
        }
        if !self.allowance_value.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetMintersResponse", len)?;
        if !self.address.is_empty() {
            struct_ser.serialize_field("address", &self.address)?;
        }
        if !self.allowance_denom.is_empty() {
            struct_ser.serialize_field("allowanceDenom", &self.allowance_denom)?;
        }
        if !self.allowance_value.is_empty() {
            struct_ser.serialize_field("allowanceValue", &self.allowance_value)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetMintersResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "address",
            "allowance_denom",
            "allowanceDenom",
            "allowance_value",
            "allowanceValue",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Address,
            AllowanceDenom,
            AllowanceValue,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "address" => Ok(GeneratedField::Address),
                            "allowanceDenom" | "allowance_denom" => Ok(GeneratedField::AllowanceDenom),
                            "allowanceValue" | "allowance_value" => Ok(GeneratedField::AllowanceValue),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetMintersResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetMintersResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetMintersResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut address__ = None;
                let mut allowance_denom__ = None;
                let mut allowance_value__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Address => {
                            if address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("address"));
                            }
                            address__ = Some(map_.next_value()?);
                        }
                        GeneratedField::AllowanceDenom => {
                            if allowance_denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("allowanceDenom"));
                            }
                            allowance_denom__ = Some(map_.next_value()?);
                        }
                        GeneratedField::AllowanceValue => {
                            if allowance_value__.is_some() {
                                return Err(serde::de::Error::duplicate_field("allowanceValue"));
                            }
                            allowance_value__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetMintersResponse {
                    address: address__.unwrap_or_default(),
                    allowance_denom: allowance_denom__.unwrap_or_default(),
                    allowance_value: allowance_value__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetMintersResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetMintingDenomRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.denom.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetMintingDenomRequest", len)?;
        if !self.denom.is_empty() {
            struct_ser.serialize_field("denom", &self.denom)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetMintingDenomRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "denom",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Denom,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "denom" => Ok(GeneratedField::Denom),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetMintingDenomRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetMintingDenomRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetMintingDenomRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut denom__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Denom => {
                            if denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("denom"));
                            }
                            denom__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetMintingDenomRequest {
                    denom: denom__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetMintingDenomRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetMintingDenomResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.denom.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetMintingDenomResponse", len)?;
        if !self.denom.is_empty() {
            struct_ser.serialize_field("denom", &self.denom)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetMintingDenomResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "denom",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Denom,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "denom" => Ok(GeneratedField::Denom),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetMintingDenomResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetMintingDenomResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetMintingDenomResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut denom__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Denom => {
                            if denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("denom"));
                            }
                            denom__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetMintingDenomResponse {
                    denom: denom__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetMintingDenomResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetMqMesssageFromQueueRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.queue_name.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetMqMesssageFromQueueRequest", len)?;
        if !self.queue_name.is_empty() {
            struct_ser.serialize_field("queueName", &self.queue_name)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetMqMesssageFromQueueRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "queue_name",
            "queueName",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            QueueName,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "queueName" | "queue_name" => Ok(GeneratedField::QueueName),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetMqMesssageFromQueueRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetMqMesssageFromQueueRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetMqMesssageFromQueueRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut queue_name__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::QueueName => {
                            if queue_name__.is_some() {
                                return Err(serde::de::Error::duplicate_field("queueName"));
                            }
                            queue_name__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetMqMesssageFromQueueRequest {
                    queue_name: queue_name__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetMqMesssageFromQueueRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetMqMesssageFromQueueResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.status.is_empty() {
            len += 1;
        }
        if !self.message.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetMqMesssageFromQueueResponse", len)?;
        if !self.status.is_empty() {
            struct_ser.serialize_field("status", &self.status)?;
        }
        if !self.message.is_empty() {
            struct_ser.serialize_field("message", &self.message)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetMqMesssageFromQueueResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "status",
            "message",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Status,
            Message,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "status" => Ok(GeneratedField::Status),
                            "message" => Ok(GeneratedField::Message),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetMqMesssageFromQueueResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetMqMesssageFromQueueResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetMqMesssageFromQueueResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut status__ = None;
                let mut message__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Status => {
                            if status__.is_some() {
                                return Err(serde::de::Error::duplicate_field("status"));
                            }
                            status__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Message => {
                            if message__.is_some() {
                                return Err(serde::de::Error::duplicate_field("message"));
                            }
                            message__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetMqMesssageFromQueueResponse {
                    status: status__.unwrap_or_default(),
                    message: message__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetMqMesssageFromQueueResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetOwnerRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let len = 0;
        let struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetOwnerRequest", len)?;
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetOwnerRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                            Err(serde::de::Error::unknown_field(value, FIELDS))
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetOwnerRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetOwnerRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetOwnerRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                while map_.next_key::<GeneratedField>()?.is_some() {
                    let _ = map_.next_value::<serde::de::IgnoredAny>()?;
                }
                Ok(GetOwnerRequest {
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetOwnerRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetOwnerResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.address.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetOwnerResponse", len)?;
        if !self.address.is_empty() {
            struct_ser.serialize_field("address", &self.address)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetOwnerResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "address",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Address,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "address" => Ok(GeneratedField::Address),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetOwnerResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetOwnerResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetOwnerResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut address__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Address => {
                            if address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("address"));
                            }
                            address__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetOwnerResponse {
                    address: address__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetOwnerResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetPausedRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let len = 0;
        let struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetPausedRequest", len)?;
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetPausedRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                            Err(serde::de::Error::unknown_field(value, FIELDS))
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetPausedRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetPausedRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetPausedRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                while map_.next_key::<GeneratedField>()?.is_some() {
                    let _ = map_.next_value::<serde::de::IgnoredAny>()?;
                }
                Ok(GetPausedRequest {
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetPausedRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetPausedResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.paused {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetPausedResponse", len)?;
        if self.paused {
            struct_ser.serialize_field("paused", &self.paused)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetPausedResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "paused",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Paused,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "paused" => Ok(GeneratedField::Paused),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetPausedResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetPausedResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetPausedResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut paused__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Paused => {
                            if paused__.is_some() {
                                return Err(serde::de::Error::duplicate_field("paused"));
                            }
                            paused__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetPausedResponse {
                    paused: paused__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetPausedResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetPauserRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let len = 0;
        let struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetPauserRequest", len)?;
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetPauserRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                            Err(serde::de::Error::unknown_field(value, FIELDS))
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetPauserRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetPauserRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetPauserRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                while map_.next_key::<GeneratedField>()?.is_some() {
                    let _ = map_.next_value::<serde::de::IgnoredAny>()?;
                }
                Ok(GetPauserRequest {
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetPauserRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetPauserResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.address.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetPauserResponse", len)?;
        if !self.address.is_empty() {
            struct_ser.serialize_field("address", &self.address)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetPauserResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "address",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Address,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "address" => Ok(GeneratedField::Address),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetPauserResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetPauserResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetPauserResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut address__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Address => {
                            if address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("address"));
                            }
                            address__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetPauserResponse {
                    address: address__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetPauserResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetPubKeyRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.key_label.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetPubKeyRequest", len)?;
        if let Some(v) = self.key_label.as_ref() {
            struct_ser.serialize_field("keyLabel", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetPubKeyRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "key_label",
            "keyLabel",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            KeyLabel,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "keyLabel" | "key_label" => Ok(GeneratedField::KeyLabel),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetPubKeyRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetPubKeyRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetPubKeyRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut key_label__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::KeyLabel => {
                            if key_label__.is_some() {
                                return Err(serde::de::Error::duplicate_field("keyLabel"));
                            }
                            key_label__ = map_.next_value()?;
                        }
                    }
                }
                Ok(GetPubKeyRequest {
                    key_label: key_label__,
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetPubKeyRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetPubKeyResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.key_label.is_empty() {
            len += 1;
        }
        if !self.pub_key.is_empty() {
            len += 1;
        }
        if !self.acct_addr.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetPubKeyResponse", len)?;
        if !self.key_label.is_empty() {
            struct_ser.serialize_field("keyLabel", &self.key_label)?;
        }
        if !self.pub_key.is_empty() {
            struct_ser.serialize_field("pubKey", &self.pub_key)?;
        }
        if !self.acct_addr.is_empty() {
            struct_ser.serialize_field("acctAddr", &self.acct_addr)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetPubKeyResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "key_label",
            "keyLabel",
            "pub_key",
            "pubKey",
            "acct_addr",
            "acctAddr",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            KeyLabel,
            PubKey,
            AcctAddr,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "keyLabel" | "key_label" => Ok(GeneratedField::KeyLabel),
                            "pubKey" | "pub_key" => Ok(GeneratedField::PubKey),
                            "acctAddr" | "acct_addr" => Ok(GeneratedField::AcctAddr),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetPubKeyResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetPubKeyResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetPubKeyResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut key_label__ = None;
                let mut pub_key__ = None;
                let mut acct_addr__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::KeyLabel => {
                            if key_label__.is_some() {
                                return Err(serde::de::Error::duplicate_field("keyLabel"));
                            }
                            key_label__ = Some(map_.next_value()?);
                        }
                        GeneratedField::PubKey => {
                            if pub_key__.is_some() {
                                return Err(serde::de::Error::duplicate_field("pubKey"));
                            }
                            pub_key__ = Some(map_.next_value()?);
                        }
                        GeneratedField::AcctAddr => {
                            if acct_addr__.is_some() {
                                return Err(serde::de::Error::duplicate_field("acctAddr"));
                            }
                            acct_addr__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetPubKeyResponse {
                    key_label: key_label__.unwrap_or_default(),
                    pub_key: pub_key__.unwrap_or_default(),
                    acct_addr: acct_addr__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetPubKeyResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetTfConfigRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let len = 0;
        let struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetTfConfigRequest", len)?;
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetTfConfigRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                            Err(serde::de::Error::unknown_field(value, FIELDS))
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetTfConfigRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetTfConfigRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetTfConfigRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                while map_.next_key::<GeneratedField>()?.is_some() {
                    let _ = map_.next_value::<serde::de::IgnoredAny>()?;
                }
                Ok(GetTfConfigRequest {
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetTfConfigRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GetTfConfigResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.owner.is_empty() {
            len += 1;
        }
        if self.is_tf {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GetTfConfigResponse", len)?;
        if !self.owner.is_empty() {
            struct_ser.serialize_field("owner", &self.owner)?;
        }
        if self.is_tf {
            struct_ser.serialize_field("isTf", &self.is_tf)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GetTfConfigResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "owner",
            "is_tf",
            "isTf",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Owner,
            IsTf,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "owner" => Ok(GeneratedField::Owner),
                            "isTf" | "is_tf" => Ok(GeneratedField::IsTf),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GetTfConfigResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GetTfConfigResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GetTfConfigResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut owner__ = None;
                let mut is_tf__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Owner => {
                            if owner__.is_some() {
                                return Err(serde::de::Error::duplicate_field("owner"));
                            }
                            owner__ = Some(map_.next_value()?);
                        }
                        GeneratedField::IsTf => {
                            if is_tf__.is_some() {
                                return Err(serde::de::Error::duplicate_field("isTf"));
                            }
                            is_tf__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GetTfConfigResponse {
                    owner: owner__.unwrap_or_default(),
                    is_tf: is_tf__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GetTfConfigResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GrantFeeBasicAllowanceRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.grantee.is_empty() {
            len += 1;
        }
        if !self.allowance_value.is_empty() {
            len += 1;
        }
        if self.hours_to_expire != 0 {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GrantFeeBasicAllowanceRequest", len)?;
        if !self.grantee.is_empty() {
            struct_ser.serialize_field("grantee", &self.grantee)?;
        }
        if !self.allowance_value.is_empty() {
            struct_ser.serialize_field("allowanceValue", &self.allowance_value)?;
        }
        if self.hours_to_expire != 0 {
            #[allow(clippy::needless_borrow)]
            struct_ser.serialize_field("hoursToExpire", ToString::to_string(&self.hours_to_expire).as_str())?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GrantFeeBasicAllowanceRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "grantee",
            "allowance_value",
            "allowanceValue",
            "hours_to_expire",
            "hoursToExpire",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Grantee,
            AllowanceValue,
            HoursToExpire,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "grantee" => Ok(GeneratedField::Grantee),
                            "allowanceValue" | "allowance_value" => Ok(GeneratedField::AllowanceValue),
                            "hoursToExpire" | "hours_to_expire" => Ok(GeneratedField::HoursToExpire),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GrantFeeBasicAllowanceRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GrantFeeBasicAllowanceRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GrantFeeBasicAllowanceRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut grantee__ = None;
                let mut allowance_value__ = None;
                let mut hours_to_expire__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Grantee => {
                            if grantee__.is_some() {
                                return Err(serde::de::Error::duplicate_field("grantee"));
                            }
                            grantee__ = Some(map_.next_value()?);
                        }
                        GeneratedField::AllowanceValue => {
                            if allowance_value__.is_some() {
                                return Err(serde::de::Error::duplicate_field("allowanceValue"));
                            }
                            allowance_value__ = Some(map_.next_value()?);
                        }
                        GeneratedField::HoursToExpire => {
                            if hours_to_expire__.is_some() {
                                return Err(serde::de::Error::duplicate_field("hoursToExpire"));
                            }
                            hours_to_expire__ = 
                                Some(map_.next_value::<::pbjson::private::NumberDeserialize<_>>()?.0)
                            ;
                        }
                    }
                }
                Ok(GrantFeeBasicAllowanceRequest {
                    grantee: grantee__.unwrap_or_default(),
                    allowance_value: allowance_value__.unwrap_or_default(),
                    hours_to_expire: hours_to_expire__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GrantFeeBasicAllowanceRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for GrantFeeBasicAllowanceResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.txhash.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.GrantFeeBasicAllowanceResponse", len)?;
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for GrantFeeBasicAllowanceResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "txhash",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Txhash,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "txhash" => Ok(GeneratedField::Txhash),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = GrantFeeBasicAllowanceResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.GrantFeeBasicAllowanceResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<GrantFeeBasicAllowanceResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut txhash__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(GrantFeeBasicAllowanceResponse {
                    txhash: txhash__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.GrantFeeBasicAllowanceResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for InstantiateContractRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.code_id != 0 {
            len += 1;
        }
        if !self.label.is_empty() {
            len += 1;
        }
        if !self.init_msg.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.InstantiateContractRequest", len)?;
        if self.code_id != 0 {
            #[allow(clippy::needless_borrow)]
            struct_ser.serialize_field("codeId", ToString::to_string(&self.code_id).as_str())?;
        }
        if !self.label.is_empty() {
            struct_ser.serialize_field("label", &self.label)?;
        }
        if !self.init_msg.is_empty() {
            struct_ser.serialize_field("initMsg", &self.init_msg)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for InstantiateContractRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "code_id",
            "codeId",
            "label",
            "init_msg",
            "initMsg",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            CodeId,
            Label,
            InitMsg,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "codeId" | "code_id" => Ok(GeneratedField::CodeId),
                            "label" => Ok(GeneratedField::Label),
                            "initMsg" | "init_msg" => Ok(GeneratedField::InitMsg),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = InstantiateContractRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.InstantiateContractRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<InstantiateContractRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut code_id__ = None;
                let mut label__ = None;
                let mut init_msg__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::CodeId => {
                            if code_id__.is_some() {
                                return Err(serde::de::Error::duplicate_field("codeId"));
                            }
                            code_id__ = 
                                Some(map_.next_value::<::pbjson::private::NumberDeserialize<_>>()?.0)
                            ;
                        }
                        GeneratedField::Label => {
                            if label__.is_some() {
                                return Err(serde::de::Error::duplicate_field("label"));
                            }
                            label__ = Some(map_.next_value()?);
                        }
                        GeneratedField::InitMsg => {
                            if init_msg__.is_some() {
                                return Err(serde::de::Error::duplicate_field("initMsg"));
                            }
                            init_msg__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(InstantiateContractRequest {
                    code_id: code_id__.unwrap_or_default(),
                    label: label__.unwrap_or_default(),
                    init_msg: init_msg__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.InstantiateContractRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for InstantiateContractResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.txhash.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.InstantiateContractResponse", len)?;
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for InstantiateContractResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "txhash",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Txhash,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "txhash" => Ok(GeneratedField::Txhash),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = InstantiateContractResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.InstantiateContractResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<InstantiateContractResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut txhash__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(InstantiateContractResponse {
                    txhash: txhash__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.InstantiateContractResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for InstantiateFtContractRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.code_id != 0 {
            len += 1;
        }
        if !self.label.is_empty() {
            len += 1;
        }
        if self.is_tf {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.InstantiateFtContractRequest", len)?;
        if self.code_id != 0 {
            #[allow(clippy::needless_borrow)]
            struct_ser.serialize_field("codeId", ToString::to_string(&self.code_id).as_str())?;
        }
        if !self.label.is_empty() {
            struct_ser.serialize_field("label", &self.label)?;
        }
        if self.is_tf {
            struct_ser.serialize_field("isTf", &self.is_tf)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for InstantiateFtContractRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "code_id",
            "codeId",
            "label",
            "is_tf",
            "isTf",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            CodeId,
            Label,
            IsTf,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "codeId" | "code_id" => Ok(GeneratedField::CodeId),
                            "label" => Ok(GeneratedField::Label),
                            "isTf" | "is_tf" => Ok(GeneratedField::IsTf),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = InstantiateFtContractRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.InstantiateFtContractRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<InstantiateFtContractRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut code_id__ = None;
                let mut label__ = None;
                let mut is_tf__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::CodeId => {
                            if code_id__.is_some() {
                                return Err(serde::de::Error::duplicate_field("codeId"));
                            }
                            code_id__ = 
                                Some(map_.next_value::<::pbjson::private::NumberDeserialize<_>>()?.0)
                            ;
                        }
                        GeneratedField::Label => {
                            if label__.is_some() {
                                return Err(serde::de::Error::duplicate_field("label"));
                            }
                            label__ = Some(map_.next_value()?);
                        }
                        GeneratedField::IsTf => {
                            if is_tf__.is_some() {
                                return Err(serde::de::Error::duplicate_field("isTf"));
                            }
                            is_tf__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(InstantiateFtContractRequest {
                    code_id: code_id__.unwrap_or_default(),
                    label: label__.unwrap_or_default(),
                    is_tf: is_tf__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.InstantiateFtContractRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for InstantiateFtContractResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.txhash.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.InstantiateFtContractResponse", len)?;
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for InstantiateFtContractResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "txhash",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Txhash,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "txhash" => Ok(GeneratedField::Txhash),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = InstantiateFtContractResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.InstantiateFtContractResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<InstantiateFtContractResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut txhash__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(InstantiateFtContractResponse {
                    txhash: txhash__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.InstantiateFtContractResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for KeyType {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        let variant = match self {
            Self::Unspecified => "KeyType_UNSPECIFIED",
            Self::Account => "Account",
            Self::Consensus => "Consensus",
        };
        serializer.serialize_str(variant)
    }
}
impl<'de> serde::Deserialize<'de> for KeyType {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "KeyType_UNSPECIFIED",
            "Account",
            "Consensus",
        ];

        struct GeneratedVisitor;

        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = KeyType;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                write!(formatter, "expected one of: {:?}", &FIELDS)
            }

            fn visit_i64<E>(self, v: i64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Signed(v), &self)
                    })
            }

            fn visit_u64<E>(self, v: u64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Unsigned(v), &self)
                    })
            }

            fn visit_str<E>(self, value: &str) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                match value {
                    "KeyType_UNSPECIFIED" => Ok(KeyType::Unspecified),
                    "Account" => Ok(KeyType::Account),
                    "Consensus" => Ok(KeyType::Consensus),
                    _ => Err(serde::de::Error::unknown_variant(value, FIELDS)),
                }
            }
        }
        deserializer.deserialize_any(GeneratedVisitor)
    }
}
impl serde::Serialize for MessageType {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        let variant = match self {
            Self::NotSet => "MessageType_NotSet",
            Self::Mt103 => "MT103",
            Self::Mt202 => "MT202",
        };
        serializer.serialize_str(variant)
    }
}
impl<'de> serde::Deserialize<'de> for MessageType {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "MessageType_NotSet",
            "MT103",
            "MT202",
        ];

        struct GeneratedVisitor;

        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = MessageType;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                write!(formatter, "expected one of: {:?}", &FIELDS)
            }

            fn visit_i64<E>(self, v: i64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Signed(v), &self)
                    })
            }

            fn visit_u64<E>(self, v: u64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Unsigned(v), &self)
                    })
            }

            fn visit_str<E>(self, value: &str) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                match value {
                    "MessageType_NotSet" => Ok(MessageType::NotSet),
                    "MT103" => Ok(MessageType::Mt103),
                    "MT202" => Ok(MessageType::Mt202),
                    _ => Err(serde::de::Error::unknown_variant(value, FIELDS)),
                }
            }
        }
        deserializer.deserialize_any(GeneratedVisitor)
    }
}
impl serde::Serialize for MintRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.address.is_empty() {
            len += 1;
        }
        if !self.denom.is_empty() {
            len += 1;
        }
        if !self.value.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.MintRequest", len)?;
        if !self.address.is_empty() {
            struct_ser.serialize_field("address", &self.address)?;
        }
        if !self.denom.is_empty() {
            struct_ser.serialize_field("denom", &self.denom)?;
        }
        if !self.value.is_empty() {
            struct_ser.serialize_field("value", &self.value)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for MintRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "address",
            "denom",
            "value",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Address,
            Denom,
            Value,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "address" => Ok(GeneratedField::Address),
                            "denom" => Ok(GeneratedField::Denom),
                            "value" => Ok(GeneratedField::Value),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = MintRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.MintRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<MintRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut address__ = None;
                let mut denom__ = None;
                let mut value__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Address => {
                            if address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("address"));
                            }
                            address__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Denom => {
                            if denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("denom"));
                            }
                            denom__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Value => {
                            if value__.is_some() {
                                return Err(serde::de::Error::duplicate_field("value"));
                            }
                            value__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(MintRequest {
                    address: address__.unwrap_or_default(),
                    denom: denom__.unwrap_or_default(),
                    value: value__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.MintRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for MintResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.txhash.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.MintResponse", len)?;
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for MintResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "txhash",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Txhash,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "txhash" => Ok(GeneratedField::Txhash),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = MintResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.MintResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<MintResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut txhash__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(MintResponse {
                    txhash: txhash__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.MintResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for NotificationType {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        let variant = match self {
            Self::Unspecified => "NotificationType_UNSPECIFIED",
            Self::Notifysender => "NOTIFYSENDER",
            Self::Transfernotification => "TRANSFERNOTIFICATION",
        };
        serializer.serialize_str(variant)
    }
}
impl<'de> serde::Deserialize<'de> for NotificationType {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "NotificationType_UNSPECIFIED",
            "NOTIFYSENDER",
            "TRANSFERNOTIFICATION",
        ];

        struct GeneratedVisitor;

        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = NotificationType;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                write!(formatter, "expected one of: {:?}", &FIELDS)
            }

            fn visit_i64<E>(self, v: i64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Signed(v), &self)
                    })
            }

            fn visit_u64<E>(self, v: u64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Unsigned(v), &self)
                    })
            }

            fn visit_str<E>(self, value: &str) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                match value {
                    "NotificationType_UNSPECIFIED" => Ok(NotificationType::Unspecified),
                    "NOTIFYSENDER" => Ok(NotificationType::Notifysender),
                    "TRANSFERNOTIFICATION" => Ok(NotificationType::Transfernotification),
                    _ => Err(serde::de::Error::unknown_variant(value, FIELDS)),
                }
            }
        }
        deserializer.deserialize_any(GeneratedVisitor)
    }
}
impl serde::Serialize for PauseRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let len = 0;
        let struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.PauseRequest", len)?;
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for PauseRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                            Err(serde::de::Error::unknown_field(value, FIELDS))
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = PauseRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.PauseRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<PauseRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                while map_.next_key::<GeneratedField>()?.is_some() {
                    let _ = map_.next_value::<serde::de::IgnoredAny>()?;
                }
                Ok(PauseRequest {
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.PauseRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for PauseResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.txhash.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.PauseResponse", len)?;
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for PauseResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "txhash",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Txhash,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "txhash" => Ok(GeneratedField::Txhash),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = PauseResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.PauseResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<PauseResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut txhash__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(PauseResponse {
                    txhash: txhash__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.PauseResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for PaymentRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.originating_party.is_some() {
            len += 1;
        }
        if self.beneficiary_party.is_some() {
            len += 1;
        }
        if self.amount != 0. {
            len += 1;
        }
        if !self.currency.is_empty() {
            len += 1;
        }
        if !self.message_type.is_empty() {
            len += 1;
        }
        if !self.payment_type.is_empty() {
            len += 1;
        }
        if !self.payment_instruction.is_empty() {
            len += 1;
        }
        if !self.tracking_id.is_empty() {
            len += 1;
        }
        if !self.send_business_date.is_empty() {
            len += 1;
        }
        if !self.request_date_time.is_empty() {
            len += 1;
        }
        if !self.custom1.is_empty() {
            len += 1;
        }
        if !self.custom2.is_empty() {
            len += 1;
        }
        if !self.custom3.is_empty() {
            len += 1;
        }
        if !self.custom4.is_empty() {
            len += 1;
        }
        if !self.custom5.is_empty() {
            len += 1;
        }
        if !self.custom6.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.PaymentRequest", len)?;
        if let Some(v) = self.originating_party.as_ref() {
            struct_ser.serialize_field("originatingParty", v)?;
        }
        if let Some(v) = self.beneficiary_party.as_ref() {
            struct_ser.serialize_field("beneficiaryParty", v)?;
        }
        if self.amount != 0. {
            struct_ser.serialize_field("amount", &self.amount)?;
        }
        if !self.currency.is_empty() {
            struct_ser.serialize_field("currency", &self.currency)?;
        }
        if !self.message_type.is_empty() {
            struct_ser.serialize_field("messageType", &self.message_type)?;
        }
        if !self.payment_type.is_empty() {
            struct_ser.serialize_field("paymentType", &self.payment_type)?;
        }
        if !self.payment_instruction.is_empty() {
            struct_ser.serialize_field("paymentInstruction", &self.payment_instruction)?;
        }
        if !self.tracking_id.is_empty() {
            struct_ser.serialize_field("trackingId", &self.tracking_id)?;
        }
        if !self.send_business_date.is_empty() {
            struct_ser.serialize_field("sendBusinessDate", &self.send_business_date)?;
        }
        if !self.request_date_time.is_empty() {
            struct_ser.serialize_field("requestDateTime", &self.request_date_time)?;
        }
        if !self.custom1.is_empty() {
            struct_ser.serialize_field("custom1", &self.custom1)?;
        }
        if !self.custom2.is_empty() {
            struct_ser.serialize_field("custom2", &self.custom2)?;
        }
        if !self.custom3.is_empty() {
            struct_ser.serialize_field("custom3", &self.custom3)?;
        }
        if !self.custom4.is_empty() {
            struct_ser.serialize_field("custom4", &self.custom4)?;
        }
        if !self.custom5.is_empty() {
            struct_ser.serialize_field("custom5", &self.custom5)?;
        }
        if !self.custom6.is_empty() {
            struct_ser.serialize_field("custom6", &self.custom6)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for PaymentRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "originatingParty",
            "beneficiaryParty",
            "amount",
            "currency",
            "messageType",
            "paymentType",
            "paymentInstruction",
            "trackingId",
            "sendBusinessDate",
            "requestDateTime",
            "custom1",
            "custom2",
            "custom3",
            "custom4",
            "custom5",
            "custom6",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            OriginatingParty,
            BeneficiaryParty,
            Amount,
            Currency,
            MessageType,
            PaymentType,
            PaymentInstruction,
            TrackingId,
            SendBusinessDate,
            RequestDateTime,
            Custom1,
            Custom2,
            Custom3,
            Custom4,
            Custom5,
            Custom6,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "originatingParty" => Ok(GeneratedField::OriginatingParty),
                            "beneficiaryParty" => Ok(GeneratedField::BeneficiaryParty),
                            "amount" => Ok(GeneratedField::Amount),
                            "currency" => Ok(GeneratedField::Currency),
                            "messageType" => Ok(GeneratedField::MessageType),
                            "paymentType" => Ok(GeneratedField::PaymentType),
                            "paymentInstruction" => Ok(GeneratedField::PaymentInstruction),
                            "trackingId" => Ok(GeneratedField::TrackingId),
                            "sendBusinessDate" => Ok(GeneratedField::SendBusinessDate),
                            "requestDateTime" => Ok(GeneratedField::RequestDateTime),
                            "custom1" => Ok(GeneratedField::Custom1),
                            "custom2" => Ok(GeneratedField::Custom2),
                            "custom3" => Ok(GeneratedField::Custom3),
                            "custom4" => Ok(GeneratedField::Custom4),
                            "custom5" => Ok(GeneratedField::Custom5),
                            "custom6" => Ok(GeneratedField::Custom6),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = PaymentRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.PaymentRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<PaymentRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut originating_party__ = None;
                let mut beneficiary_party__ = None;
                let mut amount__ = None;
                let mut currency__ = None;
                let mut message_type__ = None;
                let mut payment_type__ = None;
                let mut payment_instruction__ = None;
                let mut tracking_id__ = None;
                let mut send_business_date__ = None;
                let mut request_date_time__ = None;
                let mut custom1__ = None;
                let mut custom2__ = None;
                let mut custom3__ = None;
                let mut custom4__ = None;
                let mut custom5__ = None;
                let mut custom6__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::OriginatingParty => {
                            if originating_party__.is_some() {
                                return Err(serde::de::Error::duplicate_field("originatingParty"));
                            }
                            originating_party__ = map_.next_value()?;
                        }
                        GeneratedField::BeneficiaryParty => {
                            if beneficiary_party__.is_some() {
                                return Err(serde::de::Error::duplicate_field("beneficiaryParty"));
                            }
                            beneficiary_party__ = map_.next_value()?;
                        }
                        GeneratedField::Amount => {
                            if amount__.is_some() {
                                return Err(serde::de::Error::duplicate_field("amount"));
                            }
                            amount__ = 
                                Some(map_.next_value::<::pbjson::private::NumberDeserialize<_>>()?.0)
                            ;
                        }
                        GeneratedField::Currency => {
                            if currency__.is_some() {
                                return Err(serde::de::Error::duplicate_field("currency"));
                            }
                            currency__ = Some(map_.next_value()?);
                        }
                        GeneratedField::MessageType => {
                            if message_type__.is_some() {
                                return Err(serde::de::Error::duplicate_field("messageType"));
                            }
                            message_type__ = Some(map_.next_value()?);
                        }
                        GeneratedField::PaymentType => {
                            if payment_type__.is_some() {
                                return Err(serde::de::Error::duplicate_field("paymentType"));
                            }
                            payment_type__ = Some(map_.next_value()?);
                        }
                        GeneratedField::PaymentInstruction => {
                            if payment_instruction__.is_some() {
                                return Err(serde::de::Error::duplicate_field("paymentInstruction"));
                            }
                            payment_instruction__ = Some(map_.next_value()?);
                        }
                        GeneratedField::TrackingId => {
                            if tracking_id__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingId"));
                            }
                            tracking_id__ = Some(map_.next_value()?);
                        }
                        GeneratedField::SendBusinessDate => {
                            if send_business_date__.is_some() {
                                return Err(serde::de::Error::duplicate_field("sendBusinessDate"));
                            }
                            send_business_date__ = Some(map_.next_value()?);
                        }
                        GeneratedField::RequestDateTime => {
                            if request_date_time__.is_some() {
                                return Err(serde::de::Error::duplicate_field("requestDateTime"));
                            }
                            request_date_time__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Custom1 => {
                            if custom1__.is_some() {
                                return Err(serde::de::Error::duplicate_field("custom1"));
                            }
                            custom1__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Custom2 => {
                            if custom2__.is_some() {
                                return Err(serde::de::Error::duplicate_field("custom2"));
                            }
                            custom2__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Custom3 => {
                            if custom3__.is_some() {
                                return Err(serde::de::Error::duplicate_field("custom3"));
                            }
                            custom3__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Custom4 => {
                            if custom4__.is_some() {
                                return Err(serde::de::Error::duplicate_field("custom4"));
                            }
                            custom4__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Custom5 => {
                            if custom5__.is_some() {
                                return Err(serde::de::Error::duplicate_field("custom5"));
                            }
                            custom5__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Custom6 => {
                            if custom6__.is_some() {
                                return Err(serde::de::Error::duplicate_field("custom6"));
                            }
                            custom6__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(PaymentRequest {
                    originating_party: originating_party__,
                    beneficiary_party: beneficiary_party__,
                    amount: amount__.unwrap_or_default(),
                    currency: currency__.unwrap_or_default(),
                    message_type: message_type__.unwrap_or_default(),
                    payment_type: payment_type__.unwrap_or_default(),
                    payment_instruction: payment_instruction__.unwrap_or_default(),
                    tracking_id: tracking_id__.unwrap_or_default(),
                    send_business_date: send_business_date__.unwrap_or_default(),
                    request_date_time: request_date_time__.unwrap_or_default(),
                    custom1: custom1__.unwrap_or_default(),
                    custom2: custom2__.unwrap_or_default(),
                    custom3: custom3__.unwrap_or_default(),
                    custom4: custom4__.unwrap_or_default(),
                    custom5: custom5__.unwrap_or_default(),
                    custom6: custom6__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.PaymentRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for PaymentResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.id.is_empty() {
            len += 1;
        }
        if self.originating_party.is_some() {
            len += 1;
        }
        if self.beneficiary_party.is_some() {
            len += 1;
        }
        if self.amount != 0. {
            len += 1;
        }
        if !self.currency.is_empty() {
            len += 1;
        }
        if !self.payment_instruction.is_empty() {
            len += 1;
        }
        if !self.tracking_id.is_empty() {
            len += 1;
        }
        if !self.send_business_date.is_empty() {
            len += 1;
        }
        if !self.request_date_time.is_empty() {
            len += 1;
        }
        if !self.message_type.is_empty() {
            len += 1;
        }
        if !self.payment_type.is_empty() {
            len += 1;
        }
        if !self.notification_type.is_empty() {
            len += 1;
        }
        if !self.entry_date_time.is_empty() {
            len += 1;
        }
        if !self.payment_status.is_empty() {
            len += 1;
        }
        if !self.transaction_status.is_empty() {
            len += 1;
        }
        if !self.error_code.is_empty() {
            len += 1;
        }
        if !self.error_description.is_empty() {
            len += 1;
        }
        if !self.custom1.is_empty() {
            len += 1;
        }
        if !self.custom2.is_empty() {
            len += 1;
        }
        if !self.custom3.is_empty() {
            len += 1;
        }
        if !self.custom4.is_empty() {
            len += 1;
        }
        if !self.custom5.is_empty() {
            len += 1;
        }
        if !self.custom6.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.PaymentResponse", len)?;
        if !self.id.is_empty() {
            struct_ser.serialize_field("id", &self.id)?;
        }
        if let Some(v) = self.originating_party.as_ref() {
            struct_ser.serialize_field("originatingParty", v)?;
        }
        if let Some(v) = self.beneficiary_party.as_ref() {
            struct_ser.serialize_field("beneficiaryParty", v)?;
        }
        if self.amount != 0. {
            struct_ser.serialize_field("amount", &self.amount)?;
        }
        if !self.currency.is_empty() {
            struct_ser.serialize_field("currency", &self.currency)?;
        }
        if !self.payment_instruction.is_empty() {
            struct_ser.serialize_field("paymentInstruction", &self.payment_instruction)?;
        }
        if !self.tracking_id.is_empty() {
            struct_ser.serialize_field("trackingId", &self.tracking_id)?;
        }
        if !self.send_business_date.is_empty() {
            struct_ser.serialize_field("sendBusinessDate", &self.send_business_date)?;
        }
        if !self.request_date_time.is_empty() {
            struct_ser.serialize_field("requestDateTime", &self.request_date_time)?;
        }
        if !self.message_type.is_empty() {
            struct_ser.serialize_field("messageType", &self.message_type)?;
        }
        if !self.payment_type.is_empty() {
            struct_ser.serialize_field("paymentType", &self.payment_type)?;
        }
        if !self.notification_type.is_empty() {
            struct_ser.serialize_field("notificationType", &self.notification_type)?;
        }
        if !self.entry_date_time.is_empty() {
            struct_ser.serialize_field("entryDateTime", &self.entry_date_time)?;
        }
        if !self.payment_status.is_empty() {
            struct_ser.serialize_field("paymentStatus", &self.payment_status)?;
        }
        if !self.transaction_status.is_empty() {
            struct_ser.serialize_field("transactionStatus", &self.transaction_status)?;
        }
        if !self.error_code.is_empty() {
            struct_ser.serialize_field("errorCode", &self.error_code)?;
        }
        if !self.error_description.is_empty() {
            struct_ser.serialize_field("errorDescription", &self.error_description)?;
        }
        if !self.custom1.is_empty() {
            struct_ser.serialize_field("custom1", &self.custom1)?;
        }
        if !self.custom2.is_empty() {
            struct_ser.serialize_field("custom2", &self.custom2)?;
        }
        if !self.custom3.is_empty() {
            struct_ser.serialize_field("custom3", &self.custom3)?;
        }
        if !self.custom4.is_empty() {
            struct_ser.serialize_field("custom4", &self.custom4)?;
        }
        if !self.custom5.is_empty() {
            struct_ser.serialize_field("custom5", &self.custom5)?;
        }
        if !self.custom6.is_empty() {
            struct_ser.serialize_field("custom6", &self.custom6)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for PaymentResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "id",
            "originatingParty",
            "beneficiaryParty",
            "amount",
            "currency",
            "paymentInstruction",
            "trackingId",
            "sendBusinessDate",
            "requestDateTime",
            "messageType",
            "paymentType",
            "notificationType",
            "entryDateTime",
            "paymentStatus",
            "transactionStatus",
            "errorCode",
            "errorDescription",
            "custom1",
            "custom2",
            "custom3",
            "custom4",
            "custom5",
            "custom6",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Id,
            OriginatingParty,
            BeneficiaryParty,
            Amount,
            Currency,
            PaymentInstruction,
            TrackingId,
            SendBusinessDate,
            RequestDateTime,
            MessageType,
            PaymentType,
            NotificationType,
            EntryDateTime,
            PaymentStatus,
            TransactionStatus,
            ErrorCode,
            ErrorDescription,
            Custom1,
            Custom2,
            Custom3,
            Custom4,
            Custom5,
            Custom6,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "id" => Ok(GeneratedField::Id),
                            "originatingParty" => Ok(GeneratedField::OriginatingParty),
                            "beneficiaryParty" => Ok(GeneratedField::BeneficiaryParty),
                            "amount" => Ok(GeneratedField::Amount),
                            "currency" => Ok(GeneratedField::Currency),
                            "paymentInstruction" => Ok(GeneratedField::PaymentInstruction),
                            "trackingId" => Ok(GeneratedField::TrackingId),
                            "sendBusinessDate" => Ok(GeneratedField::SendBusinessDate),
                            "requestDateTime" => Ok(GeneratedField::RequestDateTime),
                            "messageType" => Ok(GeneratedField::MessageType),
                            "paymentType" => Ok(GeneratedField::PaymentType),
                            "notificationType" => Ok(GeneratedField::NotificationType),
                            "entryDateTime" => Ok(GeneratedField::EntryDateTime),
                            "paymentStatus" => Ok(GeneratedField::PaymentStatus),
                            "transactionStatus" => Ok(GeneratedField::TransactionStatus),
                            "errorCode" => Ok(GeneratedField::ErrorCode),
                            "errorDescription" => Ok(GeneratedField::ErrorDescription),
                            "custom1" => Ok(GeneratedField::Custom1),
                            "custom2" => Ok(GeneratedField::Custom2),
                            "custom3" => Ok(GeneratedField::Custom3),
                            "custom4" => Ok(GeneratedField::Custom4),
                            "custom5" => Ok(GeneratedField::Custom5),
                            "custom6" => Ok(GeneratedField::Custom6),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = PaymentResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.PaymentResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<PaymentResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut id__ = None;
                let mut originating_party__ = None;
                let mut beneficiary_party__ = None;
                let mut amount__ = None;
                let mut currency__ = None;
                let mut payment_instruction__ = None;
                let mut tracking_id__ = None;
                let mut send_business_date__ = None;
                let mut request_date_time__ = None;
                let mut message_type__ = None;
                let mut payment_type__ = None;
                let mut notification_type__ = None;
                let mut entry_date_time__ = None;
                let mut payment_status__ = None;
                let mut transaction_status__ = None;
                let mut error_code__ = None;
                let mut error_description__ = None;
                let mut custom1__ = None;
                let mut custom2__ = None;
                let mut custom3__ = None;
                let mut custom4__ = None;
                let mut custom5__ = None;
                let mut custom6__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Id => {
                            if id__.is_some() {
                                return Err(serde::de::Error::duplicate_field("id"));
                            }
                            id__ = Some(map_.next_value()?);
                        }
                        GeneratedField::OriginatingParty => {
                            if originating_party__.is_some() {
                                return Err(serde::de::Error::duplicate_field("originatingParty"));
                            }
                            originating_party__ = map_.next_value()?;
                        }
                        GeneratedField::BeneficiaryParty => {
                            if beneficiary_party__.is_some() {
                                return Err(serde::de::Error::duplicate_field("beneficiaryParty"));
                            }
                            beneficiary_party__ = map_.next_value()?;
                        }
                        GeneratedField::Amount => {
                            if amount__.is_some() {
                                return Err(serde::de::Error::duplicate_field("amount"));
                            }
                            amount__ = 
                                Some(map_.next_value::<::pbjson::private::NumberDeserialize<_>>()?.0)
                            ;
                        }
                        GeneratedField::Currency => {
                            if currency__.is_some() {
                                return Err(serde::de::Error::duplicate_field("currency"));
                            }
                            currency__ = Some(map_.next_value()?);
                        }
                        GeneratedField::PaymentInstruction => {
                            if payment_instruction__.is_some() {
                                return Err(serde::de::Error::duplicate_field("paymentInstruction"));
                            }
                            payment_instruction__ = Some(map_.next_value()?);
                        }
                        GeneratedField::TrackingId => {
                            if tracking_id__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingId"));
                            }
                            tracking_id__ = Some(map_.next_value()?);
                        }
                        GeneratedField::SendBusinessDate => {
                            if send_business_date__.is_some() {
                                return Err(serde::de::Error::duplicate_field("sendBusinessDate"));
                            }
                            send_business_date__ = Some(map_.next_value()?);
                        }
                        GeneratedField::RequestDateTime => {
                            if request_date_time__.is_some() {
                                return Err(serde::de::Error::duplicate_field("requestDateTime"));
                            }
                            request_date_time__ = Some(map_.next_value()?);
                        }
                        GeneratedField::MessageType => {
                            if message_type__.is_some() {
                                return Err(serde::de::Error::duplicate_field("messageType"));
                            }
                            message_type__ = Some(map_.next_value()?);
                        }
                        GeneratedField::PaymentType => {
                            if payment_type__.is_some() {
                                return Err(serde::de::Error::duplicate_field("paymentType"));
                            }
                            payment_type__ = Some(map_.next_value()?);
                        }
                        GeneratedField::NotificationType => {
                            if notification_type__.is_some() {
                                return Err(serde::de::Error::duplicate_field("notificationType"));
                            }
                            notification_type__ = Some(map_.next_value()?);
                        }
                        GeneratedField::EntryDateTime => {
                            if entry_date_time__.is_some() {
                                return Err(serde::de::Error::duplicate_field("entryDateTime"));
                            }
                            entry_date_time__ = Some(map_.next_value()?);
                        }
                        GeneratedField::PaymentStatus => {
                            if payment_status__.is_some() {
                                return Err(serde::de::Error::duplicate_field("paymentStatus"));
                            }
                            payment_status__ = Some(map_.next_value()?);
                        }
                        GeneratedField::TransactionStatus => {
                            if transaction_status__.is_some() {
                                return Err(serde::de::Error::duplicate_field("transactionStatus"));
                            }
                            transaction_status__ = Some(map_.next_value()?);
                        }
                        GeneratedField::ErrorCode => {
                            if error_code__.is_some() {
                                return Err(serde::de::Error::duplicate_field("errorCode"));
                            }
                            error_code__ = Some(map_.next_value()?);
                        }
                        GeneratedField::ErrorDescription => {
                            if error_description__.is_some() {
                                return Err(serde::de::Error::duplicate_field("errorDescription"));
                            }
                            error_description__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Custom1 => {
                            if custom1__.is_some() {
                                return Err(serde::de::Error::duplicate_field("custom1"));
                            }
                            custom1__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Custom2 => {
                            if custom2__.is_some() {
                                return Err(serde::de::Error::duplicate_field("custom2"));
                            }
                            custom2__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Custom3 => {
                            if custom3__.is_some() {
                                return Err(serde::de::Error::duplicate_field("custom3"));
                            }
                            custom3__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Custom4 => {
                            if custom4__.is_some() {
                                return Err(serde::de::Error::duplicate_field("custom4"));
                            }
                            custom4__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Custom5 => {
                            if custom5__.is_some() {
                                return Err(serde::de::Error::duplicate_field("custom5"));
                            }
                            custom5__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Custom6 => {
                            if custom6__.is_some() {
                                return Err(serde::de::Error::duplicate_field("custom6"));
                            }
                            custom6__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(PaymentResponse {
                    id: id__.unwrap_or_default(),
                    originating_party: originating_party__,
                    beneficiary_party: beneficiary_party__,
                    amount: amount__.unwrap_or_default(),
                    currency: currency__.unwrap_or_default(),
                    payment_instruction: payment_instruction__.unwrap_or_default(),
                    tracking_id: tracking_id__.unwrap_or_default(),
                    send_business_date: send_business_date__.unwrap_or_default(),
                    request_date_time: request_date_time__.unwrap_or_default(),
                    message_type: message_type__.unwrap_or_default(),
                    payment_type: payment_type__.unwrap_or_default(),
                    notification_type: notification_type__.unwrap_or_default(),
                    entry_date_time: entry_date_time__.unwrap_or_default(),
                    payment_status: payment_status__.unwrap_or_default(),
                    transaction_status: transaction_status__.unwrap_or_default(),
                    error_code: error_code__.unwrap_or_default(),
                    error_description: error_description__.unwrap_or_default(),
                    custom1: custom1__.unwrap_or_default(),
                    custom2: custom2__.unwrap_or_default(),
                    custom3: custom3__.unwrap_or_default(),
                    custom4: custom4__.unwrap_or_default(),
                    custom5: custom5__.unwrap_or_default(),
                    custom6: custom6__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.PaymentResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for PaymentStateRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.tracking_id.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.PaymentStateRequest", len)?;
        if !self.tracking_id.is_empty() {
            struct_ser.serialize_field("trackingId", &self.tracking_id)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for PaymentStateRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "tracking_id",
            "trackingId",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            TrackingId,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "trackingId" | "tracking_id" => Ok(GeneratedField::TrackingId),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = PaymentStateRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.PaymentStateRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<PaymentStateRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut tracking_id__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::TrackingId => {
                            if tracking_id__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingId"));
                            }
                            tracking_id__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(PaymentStateRequest {
                    tracking_id: tracking_id__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.PaymentStateRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for PaymentStateResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.resp.is_some() {
            len += 1;
        }
        if self.txhash.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.PaymentStateResponse", len)?;
        if let Some(v) = self.resp.as_ref() {
            struct_ser.serialize_field("resp", v)?;
        }
        if let Some(v) = self.txhash.as_ref() {
            struct_ser.serialize_field("txhash", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for PaymentStateResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "resp",
            "txhash",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Resp,
            Txhash,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "resp" => Ok(GeneratedField::Resp),
                            "txhash" => Ok(GeneratedField::Txhash),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = PaymentStateResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.PaymentStateResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<PaymentStateResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut resp__ = None;
                let mut txhash__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Resp => {
                            if resp__.is_some() {
                                return Err(serde::de::Error::duplicate_field("resp"));
                            }
                            resp__ = map_.next_value()?;
                        }
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = map_.next_value()?;
                        }
                    }
                }
                Ok(PaymentStateResponse {
                    resp: resp__,
                    txhash: txhash__,
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.PaymentStateResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for PaymentStateStatus {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        let variant = match self {
            Self::NotSet => "PaymentStateStatus_NotSet",
            Self::FundTransferred => "FundTransferred",
            Self::Confirmed => "Confirmed",
            Self::Rejected => "Rejected",
            Self::Defunded => "Defunded",
            Self::Funded => "Funded",
        };
        serializer.serialize_str(variant)
    }
}
impl<'de> serde::Deserialize<'de> for PaymentStateStatus {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "PaymentStateStatus_NotSet",
            "FundTransferred",
            "Confirmed",
            "Rejected",
            "Defunded",
            "Funded",
        ];

        struct GeneratedVisitor;

        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = PaymentStateStatus;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                write!(formatter, "expected one of: {:?}", &FIELDS)
            }

            fn visit_i64<E>(self, v: i64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Signed(v), &self)
                    })
            }

            fn visit_u64<E>(self, v: u64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Unsigned(v), &self)
                    })
            }

            fn visit_str<E>(self, value: &str) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                match value {
                    "PaymentStateStatus_NotSet" => Ok(PaymentStateStatus::NotSet),
                    "FundTransferred" => Ok(PaymentStateStatus::FundTransferred),
                    "Confirmed" => Ok(PaymentStateStatus::Confirmed),
                    "Rejected" => Ok(PaymentStateStatus::Rejected),
                    "Defunded" => Ok(PaymentStateStatus::Defunded),
                    "Funded" => Ok(PaymentStateStatus::Funded),
                    _ => Err(serde::de::Error::unknown_variant(value, FIELDS)),
                }
            }
        }
        deserializer.deserialize_any(GeneratedVisitor)
    }
}
impl serde::Serialize for PaymentStatus {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        let variant = match self {
            Self::Unknown => "Unknown",
            Self::Pending => "Pending",
            Self::Success => "Success",
            Self::Error => "Error",
        };
        serializer.serialize_str(variant)
    }
}
impl<'de> serde::Deserialize<'de> for PaymentStatus {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "Unknown",
            "Pending",
            "Success",
            "Error",
        ];

        struct GeneratedVisitor;

        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = PaymentStatus;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                write!(formatter, "expected one of: {:?}", &FIELDS)
            }

            fn visit_i64<E>(self, v: i64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Signed(v), &self)
                    })
            }

            fn visit_u64<E>(self, v: u64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Unsigned(v), &self)
                    })
            }

            fn visit_str<E>(self, value: &str) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                match value {
                    "Unknown" => Ok(PaymentStatus::Unknown),
                    "Pending" => Ok(PaymentStatus::Pending),
                    "Success" => Ok(PaymentStatus::Success),
                    "Error" => Ok(PaymentStatus::Error),
                    _ => Err(serde::de::Error::unknown_variant(value, FIELDS)),
                }
            }
        }
        deserializer.deserialize_any(GeneratedVisitor)
    }
}
impl serde::Serialize for PaymentTxResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.txhash.is_empty() {
            len += 1;
        }
        if !self.tracking_id.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.PaymentTxResponse", len)?;
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        if !self.tracking_id.is_empty() {
            struct_ser.serialize_field("trackingId", &self.tracking_id)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for PaymentTxResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "txhash",
            "tracking_id",
            "trackingId",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Txhash,
            TrackingId,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "txhash" => Ok(GeneratedField::Txhash),
                            "trackingId" | "tracking_id" => Ok(GeneratedField::TrackingId),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = PaymentTxResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.PaymentTxResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<PaymentTxResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut txhash__ = None;
                let mut tracking_id__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                        GeneratedField::TrackingId => {
                            if tracking_id__.is_some() {
                                return Err(serde::de::Error::duplicate_field("trackingId"));
                            }
                            tracking_id__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(PaymentTxResponse {
                    txhash: txhash__.unwrap_or_default(),
                    tracking_id: tracking_id__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.PaymentTxResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for PaymentType {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        let variant = match self {
            Self::Unknown => "PaymentType_Unknown",
            Self::Funding => "Funding",
            Self::Defunding => "Defunding",
            Self::Payment => "Payment",
        };
        serializer.serialize_str(variant)
    }
}
impl<'de> serde::Deserialize<'de> for PaymentType {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "PaymentType_Unknown",
            "Funding",
            "Defunding",
            "Payment",
        ];

        struct GeneratedVisitor;

        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = PaymentType;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                write!(formatter, "expected one of: {:?}", &FIELDS)
            }

            fn visit_i64<E>(self, v: i64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Signed(v), &self)
                    })
            }

            fn visit_u64<E>(self, v: u64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Unsigned(v), &self)
                    })
            }

            fn visit_str<E>(self, value: &str) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                match value {
                    "PaymentType_Unknown" => Ok(PaymentType::Unknown),
                    "Funding" => Ok(PaymentType::Funding),
                    "Defunding" => Ok(PaymentType::Defunding),
                    "Payment" => Ok(PaymentType::Payment),
                    _ => Err(serde::de::Error::unknown_variant(value, FIELDS)),
                }
            }
        }
        deserializer.deserialize_any(GeneratedVisitor)
    }
}
impl serde::Serialize for PostMqMessageResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.status.is_empty() {
            len += 1;
        }
        if !self.ret_data.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.PostMqMessageResponse", len)?;
        if !self.status.is_empty() {
            struct_ser.serialize_field("status", &self.status)?;
        }
        if !self.ret_data.is_empty() {
            struct_ser.serialize_field("retData", &self.ret_data)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for PostMqMessageResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "status",
            "ret_data",
            "retData",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Status,
            RetData,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "status" => Ok(GeneratedField::Status),
                            "retData" | "ret_data" => Ok(GeneratedField::RetData),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = PostMqMessageResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.PostMqMessageResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<PostMqMessageResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut status__ = None;
                let mut ret_data__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Status => {
                            if status__.is_some() {
                                return Err(serde::de::Error::duplicate_field("status"));
                            }
                            status__ = Some(map_.next_value()?);
                        }
                        GeneratedField::RetData => {
                            if ret_data__.is_some() {
                                return Err(serde::de::Error::duplicate_field("retData"));
                            }
                            ret_data__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(PostMqMessageResponse {
                    status: status__.unwrap_or_default(),
                    ret_data: ret_data__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.PostMqMessageResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for PostMqMessageToQueueRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.queue_name.is_empty() {
            len += 1;
        }
        if !self.message.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.PostMqMessageToQueueRequest", len)?;
        if !self.queue_name.is_empty() {
            struct_ser.serialize_field("queueName", &self.queue_name)?;
        }
        if !self.message.is_empty() {
            struct_ser.serialize_field("message", &self.message)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for PostMqMessageToQueueRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "queue_name",
            "queueName",
            "message",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            QueueName,
            Message,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "queueName" | "queue_name" => Ok(GeneratedField::QueueName),
                            "message" => Ok(GeneratedField::Message),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = PostMqMessageToQueueRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.PostMqMessageToQueueRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<PostMqMessageToQueueRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut queue_name__ = None;
                let mut message__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::QueueName => {
                            if queue_name__.is_some() {
                                return Err(serde::de::Error::duplicate_field("queueName"));
                            }
                            queue_name__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Message => {
                            if message__.is_some() {
                                return Err(serde::de::Error::duplicate_field("message"));
                            }
                            message__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(PostMqMessageToQueueRequest {
                    queue_name: queue_name__.unwrap_or_default(),
                    message: message__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.PostMqMessageToQueueRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for PostMqMessageToTopicRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.topic_string.is_empty() {
            len += 1;
        }
        if !self.message.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.PostMqMessageToTopicRequest", len)?;
        if !self.topic_string.is_empty() {
            struct_ser.serialize_field("topicString", &self.topic_string)?;
        }
        if !self.message.is_empty() {
            struct_ser.serialize_field("message", &self.message)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for PostMqMessageToTopicRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "topic_string",
            "topicString",
            "message",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            TopicString,
            Message,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "topicString" | "topic_string" => Ok(GeneratedField::TopicString),
                            "message" => Ok(GeneratedField::Message),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = PostMqMessageToTopicRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.PostMqMessageToTopicRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<PostMqMessageToTopicRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut topic_string__ = None;
                let mut message__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::TopicString => {
                            if topic_string__.is_some() {
                                return Err(serde::de::Error::duplicate_field("topicString"));
                            }
                            topic_string__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Message => {
                            if message__.is_some() {
                                return Err(serde::de::Error::duplicate_field("message"));
                            }
                            message__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(PostMqMessageToTopicRequest {
                    topic_string: topic_string__.unwrap_or_default(),
                    message: message__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.PostMqMessageToTopicRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for QueryTxRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.txhash.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.QueryTxRequest", len)?;
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for QueryTxRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "txhash",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Txhash,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "txhash" => Ok(GeneratedField::Txhash),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = QueryTxRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.QueryTxRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<QueryTxRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut txhash__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(QueryTxRequest {
                    txhash: txhash__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.QueryTxRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for QueryTxResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.txhash.is_empty() {
            len += 1;
        }
        if !self.status.is_empty() {
            len += 1;
        }
        if self.height != 0 {
            len += 1;
        }
        if self.index != 0 {
            len += 1;
        }
        if self.code != 0 {
            len += 1;
        }
        if !self.log.is_empty() {
            len += 1;
        }
        if !self.info.is_empty() {
            len += 1;
        }
        if self.gas_wanted != 0 {
            len += 1;
        }
        if self.gas_used != 0 {
            len += 1;
        }
        if self.num_events != 0 {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.QueryTxResponse", len)?;
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        if !self.status.is_empty() {
            struct_ser.serialize_field("status", &self.status)?;
        }
        if self.height != 0 {
            #[allow(clippy::needless_borrow)]
            struct_ser.serialize_field("height", ToString::to_string(&self.height).as_str())?;
        }
        if self.index != 0 {
            struct_ser.serialize_field("index", &self.index)?;
        }
        if self.code != 0 {
            struct_ser.serialize_field("code", &self.code)?;
        }
        if !self.log.is_empty() {
            struct_ser.serialize_field("log", &self.log)?;
        }
        if !self.info.is_empty() {
            struct_ser.serialize_field("info", &self.info)?;
        }
        if self.gas_wanted != 0 {
            #[allow(clippy::needless_borrow)]
            struct_ser.serialize_field("gasWanted", ToString::to_string(&self.gas_wanted).as_str())?;
        }
        if self.gas_used != 0 {
            #[allow(clippy::needless_borrow)]
            struct_ser.serialize_field("gasUsed", ToString::to_string(&self.gas_used).as_str())?;
        }
        if self.num_events != 0 {
            struct_ser.serialize_field("numEvents", &self.num_events)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for QueryTxResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "txhash",
            "status",
            "height",
            "index",
            "code",
            "log",
            "info",
            "gas_wanted",
            "gasWanted",
            "gas_used",
            "gasUsed",
            "num_events",
            "numEvents",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Txhash,
            Status,
            Height,
            Index,
            Code,
            Log,
            Info,
            GasWanted,
            GasUsed,
            NumEvents,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "txhash" => Ok(GeneratedField::Txhash),
                            "status" => Ok(GeneratedField::Status),
                            "height" => Ok(GeneratedField::Height),
                            "index" => Ok(GeneratedField::Index),
                            "code" => Ok(GeneratedField::Code),
                            "log" => Ok(GeneratedField::Log),
                            "info" => Ok(GeneratedField::Info),
                            "gasWanted" | "gas_wanted" => Ok(GeneratedField::GasWanted),
                            "gasUsed" | "gas_used" => Ok(GeneratedField::GasUsed),
                            "numEvents" | "num_events" => Ok(GeneratedField::NumEvents),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = QueryTxResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.QueryTxResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<QueryTxResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut txhash__ = None;
                let mut status__ = None;
                let mut height__ = None;
                let mut index__ = None;
                let mut code__ = None;
                let mut log__ = None;
                let mut info__ = None;
                let mut gas_wanted__ = None;
                let mut gas_used__ = None;
                let mut num_events__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Status => {
                            if status__.is_some() {
                                return Err(serde::de::Error::duplicate_field("status"));
                            }
                            status__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Height => {
                            if height__.is_some() {
                                return Err(serde::de::Error::duplicate_field("height"));
                            }
                            height__ = 
                                Some(map_.next_value::<::pbjson::private::NumberDeserialize<_>>()?.0)
                            ;
                        }
                        GeneratedField::Index => {
                            if index__.is_some() {
                                return Err(serde::de::Error::duplicate_field("index"));
                            }
                            index__ = 
                                Some(map_.next_value::<::pbjson::private::NumberDeserialize<_>>()?.0)
                            ;
                        }
                        GeneratedField::Code => {
                            if code__.is_some() {
                                return Err(serde::de::Error::duplicate_field("code"));
                            }
                            code__ = 
                                Some(map_.next_value::<::pbjson::private::NumberDeserialize<_>>()?.0)
                            ;
                        }
                        GeneratedField::Log => {
                            if log__.is_some() {
                                return Err(serde::de::Error::duplicate_field("log"));
                            }
                            log__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Info => {
                            if info__.is_some() {
                                return Err(serde::de::Error::duplicate_field("info"));
                            }
                            info__ = Some(map_.next_value()?);
                        }
                        GeneratedField::GasWanted => {
                            if gas_wanted__.is_some() {
                                return Err(serde::de::Error::duplicate_field("gasWanted"));
                            }
                            gas_wanted__ = 
                                Some(map_.next_value::<::pbjson::private::NumberDeserialize<_>>()?.0)
                            ;
                        }
                        GeneratedField::GasUsed => {
                            if gas_used__.is_some() {
                                return Err(serde::de::Error::duplicate_field("gasUsed"));
                            }
                            gas_used__ = 
                                Some(map_.next_value::<::pbjson::private::NumberDeserialize<_>>()?.0)
                            ;
                        }
                        GeneratedField::NumEvents => {
                            if num_events__.is_some() {
                                return Err(serde::de::Error::duplicate_field("numEvents"));
                            }
                            num_events__ = 
                                Some(map_.next_value::<::pbjson::private::NumberDeserialize<_>>()?.0)
                            ;
                        }
                    }
                }
                Ok(QueryTxResponse {
                    txhash: txhash__.unwrap_or_default(),
                    status: status__.unwrap_or_default(),
                    height: height__.unwrap_or_default(),
                    index: index__.unwrap_or_default(),
                    code: code__.unwrap_or_default(),
                    log: log__.unwrap_or_default(),
                    info: info__.unwrap_or_default(),
                    gas_wanted: gas_wanted__.unwrap_or_default(),
                    gas_used: gas_used__.unwrap_or_default(),
                    num_events: num_events__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.QueryTxResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for RemoveMinterControllerRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.controller.is_empty() {
            len += 1;
        }
        if !self.minter.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.RemoveMinterControllerRequest", len)?;
        if !self.controller.is_empty() {
            struct_ser.serialize_field("controller", &self.controller)?;
        }
        if !self.minter.is_empty() {
            struct_ser.serialize_field("minter", &self.minter)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for RemoveMinterControllerRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "controller",
            "minter",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Controller,
            Minter,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "controller" => Ok(GeneratedField::Controller),
                            "minter" => Ok(GeneratedField::Minter),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = RemoveMinterControllerRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.RemoveMinterControllerRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<RemoveMinterControllerRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut controller__ = None;
                let mut minter__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Controller => {
                            if controller__.is_some() {
                                return Err(serde::de::Error::duplicate_field("controller"));
                            }
                            controller__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Minter => {
                            if minter__.is_some() {
                                return Err(serde::de::Error::duplicate_field("minter"));
                            }
                            minter__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(RemoveMinterControllerRequest {
                    controller: controller__.unwrap_or_default(),
                    minter: minter__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.RemoveMinterControllerRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for RemoveMinterControllerResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.txhash.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.RemoveMinterControllerResponse", len)?;
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for RemoveMinterControllerResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "txhash",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Txhash,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "txhash" => Ok(GeneratedField::Txhash),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = RemoveMinterControllerResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.RemoveMinterControllerResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<RemoveMinterControllerResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut txhash__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(RemoveMinterControllerResponse {
                    txhash: txhash__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.RemoveMinterControllerResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for RemoveMinterRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.address.is_empty() {
            len += 1;
        }
        if !self.denom.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.RemoveMinterRequest", len)?;
        if !self.address.is_empty() {
            struct_ser.serialize_field("address", &self.address)?;
        }
        if !self.denom.is_empty() {
            struct_ser.serialize_field("denom", &self.denom)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for RemoveMinterRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "address",
            "denom",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Address,
            Denom,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "address" => Ok(GeneratedField::Address),
                            "denom" => Ok(GeneratedField::Denom),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = RemoveMinterRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.RemoveMinterRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<RemoveMinterRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut address__ = None;
                let mut denom__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Address => {
                            if address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("address"));
                            }
                            address__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Denom => {
                            if denom__.is_some() {
                                return Err(serde::de::Error::duplicate_field("denom"));
                            }
                            denom__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(RemoveMinterRequest {
                    address: address__.unwrap_or_default(),
                    denom: denom__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.RemoveMinterRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for RemoveMinterResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.txhash.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.RemoveMinterResponse", len)?;
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for RemoveMinterResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "txhash",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Txhash,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "txhash" => Ok(GeneratedField::Txhash),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = RemoveMinterResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.RemoveMinterResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<RemoveMinterResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut txhash__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(RemoveMinterResponse {
                    txhash: txhash__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.RemoveMinterResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for RequestFeeBasicAllowanceRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.allowance_value.is_empty() {
            len += 1;
        }
        if self.hours_to_expire != 0 {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.RequestFeeBasicAllowanceRequest", len)?;
        if !self.allowance_value.is_empty() {
            struct_ser.serialize_field("allowanceValue", &self.allowance_value)?;
        }
        if self.hours_to_expire != 0 {
            #[allow(clippy::needless_borrow)]
            struct_ser.serialize_field("hoursToExpire", ToString::to_string(&self.hours_to_expire).as_str())?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for RequestFeeBasicAllowanceRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "allowance_value",
            "allowanceValue",
            "hours_to_expire",
            "hoursToExpire",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            AllowanceValue,
            HoursToExpire,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "allowanceValue" | "allowance_value" => Ok(GeneratedField::AllowanceValue),
                            "hoursToExpire" | "hours_to_expire" => Ok(GeneratedField::HoursToExpire),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = RequestFeeBasicAllowanceRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.RequestFeeBasicAllowanceRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<RequestFeeBasicAllowanceRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut allowance_value__ = None;
                let mut hours_to_expire__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::AllowanceValue => {
                            if allowance_value__.is_some() {
                                return Err(serde::de::Error::duplicate_field("allowanceValue"));
                            }
                            allowance_value__ = Some(map_.next_value()?);
                        }
                        GeneratedField::HoursToExpire => {
                            if hours_to_expire__.is_some() {
                                return Err(serde::de::Error::duplicate_field("hoursToExpire"));
                            }
                            hours_to_expire__ = 
                                Some(map_.next_value::<::pbjson::private::NumberDeserialize<_>>()?.0)
                            ;
                        }
                    }
                }
                Ok(RequestFeeBasicAllowanceRequest {
                    allowance_value: allowance_value__.unwrap_or_default(),
                    hours_to_expire: hours_to_expire__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.RequestFeeBasicAllowanceRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for RequestFeeBasicAllowanceResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.txhash.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.RequestFeeBasicAllowanceResponse", len)?;
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for RequestFeeBasicAllowanceResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "txhash",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Txhash,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "txhash" => Ok(GeneratedField::Txhash),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = RequestFeeBasicAllowanceResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.RequestFeeBasicAllowanceResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<RequestFeeBasicAllowanceResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut txhash__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(RequestFeeBasicAllowanceResponse {
                    txhash: txhash__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.RequestFeeBasicAllowanceResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for RevokeFeeAllowanceRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.grantee.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.RevokeFeeAllowanceRequest", len)?;
        if !self.grantee.is_empty() {
            struct_ser.serialize_field("grantee", &self.grantee)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for RevokeFeeAllowanceRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "grantee",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Grantee,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "grantee" => Ok(GeneratedField::Grantee),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = RevokeFeeAllowanceRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.RevokeFeeAllowanceRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<RevokeFeeAllowanceRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut grantee__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Grantee => {
                            if grantee__.is_some() {
                                return Err(serde::de::Error::duplicate_field("grantee"));
                            }
                            grantee__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(RevokeFeeAllowanceRequest {
                    grantee: grantee__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.RevokeFeeAllowanceRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for RevokeFeeAllowanceResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.txhash.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.RevokeFeeAllowanceResponse", len)?;
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for RevokeFeeAllowanceResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "txhash",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Txhash,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "txhash" => Ok(GeneratedField::Txhash),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = RevokeFeeAllowanceResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.RevokeFeeAllowanceResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<RevokeFeeAllowanceResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut txhash__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(RevokeFeeAllowanceResponse {
                    txhash: txhash__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.RevokeFeeAllowanceResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for SetDenomMetadataRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if self.metadata.is_some() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.SetDenomMetadataRequest", len)?;
        if let Some(v) = self.metadata.as_ref() {
            struct_ser.serialize_field("metadata", v)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for SetDenomMetadataRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "metadata",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Metadata,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "metadata" => Ok(GeneratedField::Metadata),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = SetDenomMetadataRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.SetDenomMetadataRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<SetDenomMetadataRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut metadata__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Metadata => {
                            if metadata__.is_some() {
                                return Err(serde::de::Error::duplicate_field("metadata"));
                            }
                            metadata__ = map_.next_value()?;
                        }
                    }
                }
                Ok(SetDenomMetadataRequest {
                    metadata: metadata__,
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.SetDenomMetadataRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for SetDenomMetadataResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.txhash.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.SetDenomMetadataResponse", len)?;
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for SetDenomMetadataResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "txhash",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Txhash,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "txhash" => Ok(GeneratedField::Txhash),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = SetDenomMetadataResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.SetDenomMetadataResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<SetDenomMetadataResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut txhash__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(SetDenomMetadataResponse {
                    txhash: txhash__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.SetDenomMetadataResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for StoreCodeRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.wasm_file.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.StoreCodeRequest", len)?;
        if !self.wasm_file.is_empty() {
            struct_ser.serialize_field("wasmFile", &self.wasm_file)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for StoreCodeRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "wasm_file",
            "wasmFile",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            WasmFile,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "wasmFile" | "wasm_file" => Ok(GeneratedField::WasmFile),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = StoreCodeRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.StoreCodeRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<StoreCodeRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut wasm_file__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::WasmFile => {
                            if wasm_file__.is_some() {
                                return Err(serde::de::Error::duplicate_field("wasmFile"));
                            }
                            wasm_file__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(StoreCodeRequest {
                    wasm_file: wasm_file__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.StoreCodeRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for StoreCodeResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.txhash.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.StoreCodeResponse", len)?;
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for StoreCodeResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "txhash",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Txhash,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "txhash" => Ok(GeneratedField::Txhash),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = StoreCodeResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.StoreCodeResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<StoreCodeResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut txhash__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(StoreCodeResponse {
                    txhash: txhash__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.StoreCodeResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for TransactionStatus {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        let variant = match self {
            Self::Unspecified => "TransactionStatus_UNSPECIFIED",
            Self::Success => "SUCCESS",
            Self::Error => "ERROR",
        };
        serializer.serialize_str(variant)
    }
}
impl<'de> serde::Deserialize<'de> for TransactionStatus {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "TransactionStatus_UNSPECIFIED",
            "SUCCESS",
            "ERROR",
        ];

        struct GeneratedVisitor;

        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = TransactionStatus;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                write!(formatter, "expected one of: {:?}", &FIELDS)
            }

            fn visit_i64<E>(self, v: i64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Signed(v), &self)
                    })
            }

            fn visit_u64<E>(self, v: u64) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                i32::try_from(v)
                    .ok()
                    .and_then(|x| x.try_into().ok())
                    .ok_or_else(|| {
                        serde::de::Error::invalid_value(serde::de::Unexpected::Unsigned(v), &self)
                    })
            }

            fn visit_str<E>(self, value: &str) -> std::result::Result<Self::Value, E>
            where
                E: serde::de::Error,
            {
                match value {
                    "TransactionStatus_UNSPECIFIED" => Ok(TransactionStatus::Unspecified),
                    "SUCCESS" => Ok(TransactionStatus::Success),
                    "ERROR" => Ok(TransactionStatus::Error),
                    _ => Err(serde::de::Error::unknown_variant(value, FIELDS)),
                }
            }
        }
        deserializer.deserialize_any(GeneratedVisitor)
    }
}
impl serde::Serialize for UnblacklistRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.address.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.UnblacklistRequest", len)?;
        if !self.address.is_empty() {
            struct_ser.serialize_field("address", &self.address)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for UnblacklistRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "address",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Address,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "address" => Ok(GeneratedField::Address),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = UnblacklistRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.UnblacklistRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<UnblacklistRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut address__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Address => {
                            if address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("address"));
                            }
                            address__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(UnblacklistRequest {
                    address: address__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.UnblacklistRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for UnblacklistResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.txhash.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.UnblacklistResponse", len)?;
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for UnblacklistResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "txhash",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Txhash,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "txhash" => Ok(GeneratedField::Txhash),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = UnblacklistResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.UnblacklistResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<UnblacklistResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut txhash__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(UnblacklistResponse {
                    txhash: txhash__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.UnblacklistResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for UnpauseRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let len = 0;
        let struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.UnpauseRequest", len)?;
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for UnpauseRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                            Err(serde::de::Error::unknown_field(value, FIELDS))
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = UnpauseRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.UnpauseRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<UnpauseRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                while map_.next_key::<GeneratedField>()?.is_some() {
                    let _ = map_.next_value::<serde::de::IgnoredAny>()?;
                }
                Ok(UnpauseRequest {
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.UnpauseRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for UnpauseResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.txhash.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.UnpauseResponse", len)?;
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for UnpauseResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "txhash",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Txhash,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "txhash" => Ok(GeneratedField::Txhash),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = UnpauseResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.UnpauseResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<UnpauseResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut txhash__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(UnpauseResponse {
                    txhash: txhash__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.UnpauseResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for UpdateBlacklisterRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.address.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.UpdateBlacklisterRequest", len)?;
        if !self.address.is_empty() {
            struct_ser.serialize_field("address", &self.address)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for UpdateBlacklisterRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "address",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Address,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "address" => Ok(GeneratedField::Address),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = UpdateBlacklisterRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.UpdateBlacklisterRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<UpdateBlacklisterRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut address__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Address => {
                            if address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("address"));
                            }
                            address__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(UpdateBlacklisterRequest {
                    address: address__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.UpdateBlacklisterRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for UpdateBlacklisterResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.txhash.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.UpdateBlacklisterResponse", len)?;
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for UpdateBlacklisterResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "txhash",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Txhash,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "txhash" => Ok(GeneratedField::Txhash),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = UpdateBlacklisterResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.UpdateBlacklisterResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<UpdateBlacklisterResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut txhash__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(UpdateBlacklisterResponse {
                    txhash: txhash__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.UpdateBlacklisterResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for UpdateMasterMinterRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.address.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.UpdateMasterMinterRequest", len)?;
        if !self.address.is_empty() {
            struct_ser.serialize_field("address", &self.address)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for UpdateMasterMinterRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "address",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Address,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "address" => Ok(GeneratedField::Address),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = UpdateMasterMinterRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.UpdateMasterMinterRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<UpdateMasterMinterRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut address__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Address => {
                            if address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("address"));
                            }
                            address__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(UpdateMasterMinterRequest {
                    address: address__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.UpdateMasterMinterRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for UpdateMasterMinterResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.txhash.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.UpdateMasterMinterResponse", len)?;
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for UpdateMasterMinterResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "txhash",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Txhash,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "txhash" => Ok(GeneratedField::Txhash),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = UpdateMasterMinterResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.UpdateMasterMinterResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<UpdateMasterMinterResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut txhash__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(UpdateMasterMinterResponse {
                    txhash: txhash__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.UpdateMasterMinterResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for UpdateMemberRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.id.is_empty() {
            len += 1;
        }
        if !self.addr.is_empty() {
            len += 1;
        }
        if !self.pubkey.is_empty() {
            len += 1;
        }
        if !self.grpc.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.UpdateMemberRequest", len)?;
        if !self.id.is_empty() {
            struct_ser.serialize_field("id", &self.id)?;
        }
        if !self.addr.is_empty() {
            struct_ser.serialize_field("addr", &self.addr)?;
        }
        if !self.pubkey.is_empty() {
            struct_ser.serialize_field("pubkey", &self.pubkey)?;
        }
        if !self.grpc.is_empty() {
            struct_ser.serialize_field("grpc", &self.grpc)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for UpdateMemberRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "id",
            "addr",
            "pubkey",
            "grpc",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Id,
            Addr,
            Pubkey,
            Grpc,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "id" => Ok(GeneratedField::Id),
                            "addr" => Ok(GeneratedField::Addr),
                            "pubkey" => Ok(GeneratedField::Pubkey),
                            "grpc" => Ok(GeneratedField::Grpc),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = UpdateMemberRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.UpdateMemberRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<UpdateMemberRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut id__ = None;
                let mut addr__ = None;
                let mut pubkey__ = None;
                let mut grpc__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Id => {
                            if id__.is_some() {
                                return Err(serde::de::Error::duplicate_field("id"));
                            }
                            id__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Addr => {
                            if addr__.is_some() {
                                return Err(serde::de::Error::duplicate_field("addr"));
                            }
                            addr__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Pubkey => {
                            if pubkey__.is_some() {
                                return Err(serde::de::Error::duplicate_field("pubkey"));
                            }
                            pubkey__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Grpc => {
                            if grpc__.is_some() {
                                return Err(serde::de::Error::duplicate_field("grpc"));
                            }
                            grpc__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(UpdateMemberRequest {
                    id: id__.unwrap_or_default(),
                    addr: addr__.unwrap_or_default(),
                    pubkey: pubkey__.unwrap_or_default(),
                    grpc: grpc__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.UpdateMemberRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for UpdateMemberResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.id.is_empty() {
            len += 1;
        }
        if !self.txhash.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.UpdateMemberResponse", len)?;
        if !self.id.is_empty() {
            struct_ser.serialize_field("id", &self.id)?;
        }
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for UpdateMemberResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "id",
            "txhash",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Id,
            Txhash,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "id" => Ok(GeneratedField::Id),
                            "txhash" => Ok(GeneratedField::Txhash),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = UpdateMemberResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.UpdateMemberResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<UpdateMemberResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut id__ = None;
                let mut txhash__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Id => {
                            if id__.is_some() {
                                return Err(serde::de::Error::duplicate_field("id"));
                            }
                            id__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(UpdateMemberResponse {
                    id: id__.unwrap_or_default(),
                    txhash: txhash__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.UpdateMemberResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for UpdatePauserRequest {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.address.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.UpdatePauserRequest", len)?;
        if !self.address.is_empty() {
            struct_ser.serialize_field("address", &self.address)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for UpdatePauserRequest {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "address",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Address,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "address" => Ok(GeneratedField::Address),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = UpdatePauserRequest;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.UpdatePauserRequest")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<UpdatePauserRequest, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut address__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Address => {
                            if address__.is_some() {
                                return Err(serde::de::Error::duplicate_field("address"));
                            }
                            address__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(UpdatePauserRequest {
                    address: address__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.UpdatePauserRequest", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for UpdatePauserResponse {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.txhash.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.UpdatePauserResponse", len)?;
        if !self.txhash.is_empty() {
            struct_ser.serialize_field("txhash", &self.txhash)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for UpdatePauserResponse {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "txhash",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            Txhash,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "txhash" => Ok(GeneratedField::Txhash),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = UpdatePauserResponse;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.UpdatePauserResponse")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<UpdatePauserResponse, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut txhash__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::Txhash => {
                            if txhash__.is_some() {
                                return Err(serde::de::Error::duplicate_field("txhash"));
                            }
                            txhash__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(UpdatePauserResponse {
                    txhash: txhash__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.UpdatePauserResponse", FIELDS, GeneratedVisitor)
    }
}
impl serde::Serialize for X500Name {
    #[allow(deprecated)]
    fn serialize<S>(&self, serializer: S) -> std::result::Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        use serde::ser::SerializeStruct;
        let mut len = 0;
        if !self.common_name.is_empty() {
            len += 1;
        }
        if !self.organization_unit.is_empty() {
            len += 1;
        }
        if !self.organization.is_empty() {
            len += 1;
        }
        if !self.locality.is_empty() {
            len += 1;
        }
        if !self.state.is_empty() {
            len += 1;
        }
        if !self.country.is_empty() {
            len += 1;
        }
        let mut struct_ser = serializer.serialize_struct("wfdc2.wallet.v1.X500Name", len)?;
        if !self.common_name.is_empty() {
            struct_ser.serialize_field("commonName", &self.common_name)?;
        }
        if !self.organization_unit.is_empty() {
            struct_ser.serialize_field("organizationUnit", &self.organization_unit)?;
        }
        if !self.organization.is_empty() {
            struct_ser.serialize_field("organization", &self.organization)?;
        }
        if !self.locality.is_empty() {
            struct_ser.serialize_field("locality", &self.locality)?;
        }
        if !self.state.is_empty() {
            struct_ser.serialize_field("state", &self.state)?;
        }
        if !self.country.is_empty() {
            struct_ser.serialize_field("country", &self.country)?;
        }
        struct_ser.end()
    }
}
impl<'de> serde::Deserialize<'de> for X500Name {
    #[allow(deprecated)]
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        const FIELDS: &[&str] = &[
            "commonName",
            "organizationUnit",
            "organization",
            "locality",
            "state",
            "country",
        ];

        #[allow(clippy::enum_variant_names)]
        enum GeneratedField {
            CommonName,
            OrganizationUnit,
            Organization,
            Locality,
            State,
            Country,
        }
        impl<'de> serde::Deserialize<'de> for GeneratedField {
            fn deserialize<D>(deserializer: D) -> std::result::Result<GeneratedField, D::Error>
            where
                D: serde::Deserializer<'de>,
            {
                struct GeneratedVisitor;

                impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
                    type Value = GeneratedField;

                    fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                        write!(formatter, "expected one of: {:?}", &FIELDS)
                    }

                    #[allow(unused_variables)]
                    fn visit_str<E>(self, value: &str) -> std::result::Result<GeneratedField, E>
                    where
                        E: serde::de::Error,
                    {
                        match value {
                            "commonName" => Ok(GeneratedField::CommonName),
                            "organizationUnit" => Ok(GeneratedField::OrganizationUnit),
                            "organization" => Ok(GeneratedField::Organization),
                            "locality" => Ok(GeneratedField::Locality),
                            "state" => Ok(GeneratedField::State),
                            "country" => Ok(GeneratedField::Country),
                            _ => Err(serde::de::Error::unknown_field(value, FIELDS)),
                        }
                    }
                }
                deserializer.deserialize_identifier(GeneratedVisitor)
            }
        }
        struct GeneratedVisitor;
        impl<'de> serde::de::Visitor<'de> for GeneratedVisitor {
            type Value = X500Name;

            fn expecting(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                formatter.write_str("struct wfdc2.wallet.v1.X500Name")
            }

            fn visit_map<V>(self, mut map_: V) -> std::result::Result<X500Name, V::Error>
                where
                    V: serde::de::MapAccess<'de>,
            {
                let mut common_name__ = None;
                let mut organization_unit__ = None;
                let mut organization__ = None;
                let mut locality__ = None;
                let mut state__ = None;
                let mut country__ = None;
                while let Some(k) = map_.next_key()? {
                    match k {
                        GeneratedField::CommonName => {
                            if common_name__.is_some() {
                                return Err(serde::de::Error::duplicate_field("commonName"));
                            }
                            common_name__ = Some(map_.next_value()?);
                        }
                        GeneratedField::OrganizationUnit => {
                            if organization_unit__.is_some() {
                                return Err(serde::de::Error::duplicate_field("organizationUnit"));
                            }
                            organization_unit__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Organization => {
                            if organization__.is_some() {
                                return Err(serde::de::Error::duplicate_field("organization"));
                            }
                            organization__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Locality => {
                            if locality__.is_some() {
                                return Err(serde::de::Error::duplicate_field("locality"));
                            }
                            locality__ = Some(map_.next_value()?);
                        }
                        GeneratedField::State => {
                            if state__.is_some() {
                                return Err(serde::de::Error::duplicate_field("state"));
                            }
                            state__ = Some(map_.next_value()?);
                        }
                        GeneratedField::Country => {
                            if country__.is_some() {
                                return Err(serde::de::Error::duplicate_field("country"));
                            }
                            country__ = Some(map_.next_value()?);
                        }
                    }
                }
                Ok(X500Name {
                    common_name: common_name__.unwrap_or_default(),
                    organization_unit: organization_unit__.unwrap_or_default(),
                    organization: organization__.unwrap_or_default(),
                    locality: locality__.unwrap_or_default(),
                    state: state__.unwrap_or_default(),
                    country: country__.unwrap_or_default(),
                })
            }
        }
        deserializer.deserialize_struct("wfdc2.wallet.v1.X500Name", FIELDS, GeneratedVisitor)
    }
}
