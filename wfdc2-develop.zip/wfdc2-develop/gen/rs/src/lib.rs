pub mod wfdc2 {
    pub mod wallet {
        pub mod v1 {
            include!("wfdc2.wallet.v1.rs");
            // include!("wfdc2.wallet.v1.serde.rs");
        }

        // prost and serde both implement Serialize and Deserialize; so they conflict.
        /*
        pub mod serde {
            pub mod v1 {
                use crate::wfdc2::wallet::v1::*;
                include!("wfdc2.wallet.v1.serde.rs");
            }
        }
        */

        pub mod tonic {
            pub mod v1 {
                use crate::wfdc2::wallet::v1::*;
                // use crate::wfdc2::wallet::v1::serde::*;
                include!("wfdc2.wallet.v1.tonic.rs");
            }
        }
    }
}
