// @generated
/// Generated client implementations.
pub mod wallet_client {
    #![allow(unused_variables, dead_code, missing_docs, clippy::let_unit_value)]
    use tonic::codegen::*;
    use tonic::codegen::http::Uri;
    ///
    #[derive(Debug, Clone)]
    pub struct WalletClient<T> {
        inner: tonic::client::Grpc<T>,
    }
    impl WalletClient<tonic::transport::Channel> {
        /// Attempt to create a new client by connecting to a given endpoint.
        pub async fn connect<D>(dst: D) -> Result<Self, tonic::transport::Error>
        where
            D: TryInto<tonic::transport::Endpoint>,
            D::Error: Into<StdError>,
        {
            let conn = tonic::transport::Endpoint::new(dst)?.connect().await?;
            Ok(Self::new(conn))
        }
    }
    impl<T> WalletClient<T>
    where
        T: tonic::client::GrpcService<tonic::body::BoxBody>,
        T::Error: Into<StdError>,
        T::ResponseBody: Body<Data = Bytes> + Send + 'static,
        <T::ResponseBody as Body>::Error: Into<StdError> + Send,
    {
        pub fn new(inner: T) -> Self {
            let inner = tonic::client::Grpc::new(inner);
            Self { inner }
        }
        pub fn with_origin(inner: T, origin: Uri) -> Self {
            let inner = tonic::client::Grpc::with_origin(inner, origin);
            Self { inner }
        }
        pub fn with_interceptor<F>(
            inner: T,
            interceptor: F,
        ) -> WalletClient<InterceptedService<T, F>>
        where
            F: tonic::service::Interceptor,
            T::ResponseBody: Default,
            T: tonic::codegen::Service<
                http::Request<tonic::body::BoxBody>,
                Response = http::Response<
                    <T as tonic::client::GrpcService<tonic::body::BoxBody>>::ResponseBody,
                >,
            >,
            <T as tonic::codegen::Service<
                http::Request<tonic::body::BoxBody>,
            >>::Error: Into<StdError> + Send + Sync,
        {
            WalletClient::new(InterceptedService::new(inner, interceptor))
        }
        /// Compress requests with the given encoding.
        ///
        /// This requires the server to support it otherwise it might respond with an
        /// error.
        #[must_use]
        pub fn send_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.inner = self.inner.send_compressed(encoding);
            self
        }
        /// Enable decompressing responses.
        #[must_use]
        pub fn accept_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.inner = self.inner.accept_compressed(encoding);
            self
        }
        /// Limits the maximum size of a decoded message.
        ///
        /// Default: `4MB`
        #[must_use]
        pub fn max_decoding_message_size(mut self, limit: usize) -> Self {
            self.inner = self.inner.max_decoding_message_size(limit);
            self
        }
        /// Limits the maximum size of an encoded message.
        ///
        /// Default: `usize::MAX`
        #[must_use]
        pub fn max_encoding_message_size(mut self, limit: usize) -> Self {
            self.inner = self.inner.max_encoding_message_size(limit);
            self
        }
        /** diagnosis utility
*/
        pub async fn echo(
            &mut self,
            request: impl tonic::IntoRequest<super::EchoRequest>,
        ) -> std::result::Result<tonic::Response<super::EchoResponse>, tonic::Status> {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/Echo",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "Echo"));
            self.inner.unary(req, path, codec).await
        }
        /** admin
*/
        pub async fn store_code(
            &mut self,
            request: impl tonic::IntoRequest<super::StoreCodeRequest>,
        ) -> std::result::Result<
            tonic::Response<super::StoreCodeResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/StoreCode",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "StoreCode"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn instantiate_ft_contract(
            &mut self,
            request: impl tonic::IntoRequest<super::InstantiateFtContractRequest>,
        ) -> std::result::Result<
            tonic::Response<super::InstantiateFtContractResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/InstantiateFtContract",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new("wfdc2.wallet.v1.Wallet", "InstantiateFtContract"),
                );
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn instantiate_contract(
            &mut self,
            request: impl tonic::IntoRequest<super::InstantiateContractRequest>,
        ) -> std::result::Result<
            tonic::Response<super::InstantiateContractResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/InstantiateContract",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new("wfdc2.wallet.v1.Wallet", "InstantiateContract"),
                );
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn query_tx(
            &mut self,
            request: impl tonic::IntoRequest<super::QueryTxRequest>,
        ) -> std::result::Result<
            tonic::Response<super::QueryTxResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/QueryTx",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "QueryTx"));
            self.inner.unary(req, path, codec).await
        }
        /** keys
*/
        pub async fn gen_key(
            &mut self,
            request: impl tonic::IntoRequest<super::GenKeyRequest>,
        ) -> std::result::Result<tonic::Response<super::GenKeyResponse>, tonic::Status> {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/GenKey",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "GenKey"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn get_pub_key(
            &mut self,
            request: impl tonic::IntoRequest<super::GetPubKeyRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetPubKeyResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/GetPubKey",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "GetPubKey"));
            self.inner.unary(req, path, codec).await
        }
        /** bank
*/
        pub async fn get_bank_balance(
            &mut self,
            request: impl tonic::IntoRequest<super::BankBalanceRequest>,
        ) -> std::result::Result<
            tonic::Response<super::BankBalanceResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/GetBankBalance",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "GetBankBalance"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn bank_send(
            &mut self,
            request: impl tonic::IntoRequest<super::BankSendRequest>,
        ) -> std::result::Result<
            tonic::Response<super::BankSendResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/BankSend",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "BankSend"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn get_denom_metadata(
            &mut self,
            request: impl tonic::IntoRequest<super::GetDenomMetadataRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetDenomMetadataResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/GetDenomMetadata",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "GetDenomMetadata"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn get_all_denom_metadata(
            &mut self,
            request: impl tonic::IntoRequest<super::GetAllDenomMetadataRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetAllDenomMetadataResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/GetAllDenomMetadata",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new("wfdc2.wallet.v1.Wallet", "GetAllDenomMetadata"),
                );
            self.inner.unary(req, path, codec).await
        }
        /** tokenfactory tx
*/
        pub async fn update_master_minter(
            &mut self,
            request: impl tonic::IntoRequest<super::UpdateMasterMinterRequest>,
        ) -> std::result::Result<
            tonic::Response<super::UpdateMasterMinterResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/UpdateMasterMinter",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "UpdateMasterMinter"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn configure_minter_controller(
            &mut self,
            request: impl tonic::IntoRequest<super::ConfigureMinterControllerRequest>,
        ) -> std::result::Result<
            tonic::Response<super::ConfigureMinterControllerResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/ConfigureMinterController",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new(
                        "wfdc2.wallet.v1.Wallet",
                        "ConfigureMinterController",
                    ),
                );
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn remove_minter_controller(
            &mut self,
            request: impl tonic::IntoRequest<super::RemoveMinterControllerRequest>,
        ) -> std::result::Result<
            tonic::Response<super::RemoveMinterControllerResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/RemoveMinterController",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new("wfdc2.wallet.v1.Wallet", "RemoveMinterController"),
                );
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn configure_minter(
            &mut self,
            request: impl tonic::IntoRequest<super::ConfigureMinterRequest>,
        ) -> std::result::Result<
            tonic::Response<super::ConfigureMinterResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/ConfigureMinter",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "ConfigureMinter"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn remove_minter(
            &mut self,
            request: impl tonic::IntoRequest<super::RemoveMinterRequest>,
        ) -> std::result::Result<
            tonic::Response<super::RemoveMinterResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/RemoveMinter",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "RemoveMinter"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn update_blacklister(
            &mut self,
            request: impl tonic::IntoRequest<super::UpdateBlacklisterRequest>,
        ) -> std::result::Result<
            tonic::Response<super::UpdateBlacklisterResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/UpdateBlacklister",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "UpdateBlacklister"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn blacklist(
            &mut self,
            request: impl tonic::IntoRequest<super::BlacklistRequest>,
        ) -> std::result::Result<
            tonic::Response<super::BlacklistResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/Blacklist",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "Blacklist"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn unblacklist(
            &mut self,
            request: impl tonic::IntoRequest<super::UnblacklistRequest>,
        ) -> std::result::Result<
            tonic::Response<super::UnblacklistResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/Unblacklist",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "Unblacklist"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn update_pauser(
            &mut self,
            request: impl tonic::IntoRequest<super::UpdatePauserRequest>,
        ) -> std::result::Result<
            tonic::Response<super::UpdatePauserResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/UpdatePauser",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "UpdatePauser"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn pause(
            &mut self,
            request: impl tonic::IntoRequest<super::PauseRequest>,
        ) -> std::result::Result<tonic::Response<super::PauseResponse>, tonic::Status> {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/Pause",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "Pause"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn unpause(
            &mut self,
            request: impl tonic::IntoRequest<super::UnpauseRequest>,
        ) -> std::result::Result<
            tonic::Response<super::UnpauseResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/Unpause",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "Unpause"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn mint(
            &mut self,
            request: impl tonic::IntoRequest<super::MintRequest>,
        ) -> std::result::Result<tonic::Response<super::MintResponse>, tonic::Status> {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/Mint",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "Mint"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn burn(
            &mut self,
            request: impl tonic::IntoRequest<super::BurnRequest>,
        ) -> std::result::Result<tonic::Response<super::BurnResponse>, tonic::Status> {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/Burn",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "Burn"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn set_denom_metadata(
            &mut self,
            request: impl tonic::IntoRequest<super::SetDenomMetadataRequest>,
        ) -> std::result::Result<
            tonic::Response<super::SetDenomMetadataResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/SetDenomMetadata",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "SetDenomMetadata"));
            self.inner.unary(req, path, codec).await
        }
        /** tokenfactory query
*/
        pub async fn get_tf_config(
            &mut self,
            request: impl tonic::IntoRequest<super::GetTfConfigRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetTfConfigResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/GetTfConfig",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "GetTfConfig"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn get_owner(
            &mut self,
            request: impl tonic::IntoRequest<super::GetOwnerRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetOwnerResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/GetOwner",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "GetOwner"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn get_master_minter(
            &mut self,
            request: impl tonic::IntoRequest<super::GetMasterMinterRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetMasterMinterResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/GetMasterMinter",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "GetMasterMinter"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn get_minter_controller(
            &mut self,
            request: impl tonic::IntoRequest<super::GetMinterControllerRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetMinterControllerResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/GetMinterController",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new("wfdc2.wallet.v1.Wallet", "GetMinterController"),
                );
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn get_all_minter_controllers(
            &mut self,
            request: impl tonic::IntoRequest<super::GetAllMinterControllersRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetAllMinterControllersResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/GetAllMinterControllers",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new("wfdc2.wallet.v1.Wallet", "GetAllMinterControllers"),
                );
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn get_minting_denom(
            &mut self,
            request: impl tonic::IntoRequest<super::GetMintingDenomRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetMintingDenomResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/GetMintingDenom",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "GetMintingDenom"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn get_all_minting_denoms(
            &mut self,
            request: impl tonic::IntoRequest<super::GetAllMintingDenomsRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetAllMintingDenomsResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/GetAllMintingDenoms",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new("wfdc2.wallet.v1.Wallet", "GetAllMintingDenoms"),
                );
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn get_minters(
            &mut self,
            request: impl tonic::IntoRequest<super::GetMintersRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetMintersResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/GetMinters",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "GetMinters"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn get_all_minters(
            &mut self,
            request: impl tonic::IntoRequest<super::GetAllMintersRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetAllMintersResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/GetAllMinters",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "GetAllMinters"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn get_blacklister(
            &mut self,
            request: impl tonic::IntoRequest<super::GetBlacklisterRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetBlacklisterResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/GetBlacklister",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "GetBlacklister"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn get_pauser(
            &mut self,
            request: impl tonic::IntoRequest<super::GetPauserRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetPauserResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/GetPauser",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "GetPauser"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn get_blacklisted(
            &mut self,
            request: impl tonic::IntoRequest<super::GetBlacklistedRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetBlacklistedResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/GetBlacklisted",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "GetBlacklisted"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn get_all_blacklisted(
            &mut self,
            request: impl tonic::IntoRequest<super::GetAllBlacklistedRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetAllBlacklistedResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/GetAllBlacklisted",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "GetAllBlacklisted"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn get_paused(
            &mut self,
            request: impl tonic::IntoRequest<super::GetPausedRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetPausedResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/GetPaused",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "GetPaused"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn find_metadata_for_denom(
            &mut self,
            request: impl tonic::IntoRequest<super::FindMetadataForDenomRequest>,
        ) -> std::result::Result<
            tonic::Response<super::FindDenomMetadataResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/FindMetadataForDenom",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new("wfdc2.wallet.v1.Wallet", "FindMetadataForDenom"),
                );
            self.inner.unary(req, path, codec).await
        }
        /** aurum
*/
        pub async fn get_aurum_config(
            &mut self,
            request: impl tonic::IntoRequest<super::GetAurumConfigRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetAurumConfigResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/GetAurumConfig",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "GetAurumConfig"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn update_member(
            &mut self,
            request: impl tonic::IntoRequest<super::UpdateMemberRequest>,
        ) -> std::result::Result<
            tonic::Response<super::UpdateMemberResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/UpdateMember",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "UpdateMember"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn get_member(
            &mut self,
            request: impl tonic::IntoRequest<super::GetMemberRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetMemberResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/GetMember",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "GetMember"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn get_members(
            &mut self,
            request: impl tonic::IntoRequest<super::GetMembersRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetMembersResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/GetMembers",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "GetMembers"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn get_aurum_balance(
            &mut self,
            request: impl tonic::IntoRequest<super::BalanceRequest>,
        ) -> std::result::Result<
            tonic::Response<super::BalanceResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/GetAurumBalance",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "GetAurumBalance"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn process_aurum_balance(
            &mut self,
            request: impl tonic::IntoRequest<super::BalanceRequest>,
        ) -> std::result::Result<
            tonic::Response<super::BalanceResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/ProcessAurumBalance",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new("wfdc2.wallet.v1.Wallet", "ProcessAurumBalance"),
                );
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn aurum_tx(
            &mut self,
            request: impl tonic::IntoRequest<super::PaymentRequest>,
        ) -> std::result::Result<
            tonic::Response<super::PaymentTxResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/AurumTx",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "AurumTx"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn get_payment_state(
            &mut self,
            request: impl tonic::IntoRequest<super::PaymentStateRequest>,
        ) -> std::result::Result<
            tonic::Response<super::PaymentStateResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/GetPaymentState",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "GetPaymentState"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn process_aurum_tx(
            &mut self,
            request: impl tonic::IntoRequest<super::PaymentRequest>,
        ) -> std::result::Result<
            tonic::Response<super::PaymentResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/ProcessAurumTx",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "ProcessAurumTx"));
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn from_member(
            &mut self,
            request: impl tonic::IntoRequest<super::FromMemberRequest>,
        ) -> std::result::Result<
            tonic::Response<super::PaymentResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/FromMember",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "FromMember"));
            self.inner.unary(req, path, codec).await
        }
        /** feegrant
 feegrant - faucet wallet
*/
        pub async fn grant_fee_basic_allowance(
            &mut self,
            request: impl tonic::IntoRequest<super::GrantFeeBasicAllowanceRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GrantFeeBasicAllowanceResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/GrantFeeBasicAllowance",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new("wfdc2.wallet.v1.Wallet", "GrantFeeBasicAllowance"),
                );
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn revoke_fee_allowance(
            &mut self,
            request: impl tonic::IntoRequest<super::RevokeFeeAllowanceRequest>,
        ) -> std::result::Result<
            tonic::Response<super::RevokeFeeAllowanceResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/RevokeFeeAllowance",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(GrpcMethod::new("wfdc2.wallet.v1.Wallet", "RevokeFeeAllowance"));
            self.inner.unary(req, path, codec).await
        }
        /** feegrant - all wallets
*/
        pub async fn get_fee_basic_allowance(
            &mut self,
            request: impl tonic::IntoRequest<super::GetFeeBasicAllowanceRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetFeeBasicAllowanceResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/GetFeeBasicAllowance",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new("wfdc2.wallet.v1.Wallet", "GetFeeBasicAllowance"),
                );
            self.inner.unary(req, path, codec).await
        }
        /** feegrant - other wallets
*/
        pub async fn request_fee_basic_allowance(
            &mut self,
            request: impl tonic::IntoRequest<super::RequestFeeBasicAllowanceRequest>,
        ) -> std::result::Result<
            tonic::Response<super::RequestFeeBasicAllowanceResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/RequestFeeBasicAllowance",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new("wfdc2.wallet.v1.Wallet", "RequestFeeBasicAllowance"),
                );
            self.inner.unary(req, path, codec).await
        }
        /** ibm mq
*/
        pub async fn get_mq_messsage_from_queue(
            &mut self,
            request: impl tonic::IntoRequest<super::GetMqMesssageFromQueueRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetMqMesssageFromQueueResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/GetMQMesssageFromQueue",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new("wfdc2.wallet.v1.Wallet", "GetMQMesssageFromQueue"),
                );
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn post_mq_message_to_queue(
            &mut self,
            request: impl tonic::IntoRequest<super::PostMqMessageToQueueRequest>,
        ) -> std::result::Result<
            tonic::Response<super::PostMqMessageResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/PostMQMessageToQueue",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new("wfdc2.wallet.v1.Wallet", "PostMQMessageToQueue"),
                );
            self.inner.unary(req, path, codec).await
        }
        ///
        pub async fn post_mq_message_to_topic(
            &mut self,
            request: impl tonic::IntoRequest<super::PostMqMessageToTopicRequest>,
        ) -> std::result::Result<
            tonic::Response<super::PostMqMessageResponse>,
            tonic::Status,
        > {
            self.inner
                .ready()
                .await
                .map_err(|e| {
                    tonic::Status::new(
                        tonic::Code::Unknown,
                        format!("Service was not ready: {}", e.into()),
                    )
                })?;
            let codec = tonic::codec::ProstCodec::default();
            let path = http::uri::PathAndQuery::from_static(
                "/wfdc2.wallet.v1.Wallet/PostMQMessageToTopic",
            );
            let mut req = request.into_request();
            req.extensions_mut()
                .insert(
                    GrpcMethod::new("wfdc2.wallet.v1.Wallet", "PostMQMessageToTopic"),
                );
            self.inner.unary(req, path, codec).await
        }
    }
}
/// Generated server implementations.
pub mod wallet_server {
    #![allow(unused_variables, dead_code, missing_docs, clippy::let_unit_value)]
    use tonic::codegen::*;
    /// Generated trait containing gRPC methods that should be implemented for use with WalletServer.
    #[async_trait]
    pub trait Wallet: Send + Sync + 'static {
        /** diagnosis utility
*/
        async fn echo(
            &self,
            request: tonic::Request<super::EchoRequest>,
        ) -> std::result::Result<tonic::Response<super::EchoResponse>, tonic::Status>;
        /** admin
*/
        async fn store_code(
            &self,
            request: tonic::Request<super::StoreCodeRequest>,
        ) -> std::result::Result<
            tonic::Response<super::StoreCodeResponse>,
            tonic::Status,
        >;
        ///
        async fn instantiate_ft_contract(
            &self,
            request: tonic::Request<super::InstantiateFtContractRequest>,
        ) -> std::result::Result<
            tonic::Response<super::InstantiateFtContractResponse>,
            tonic::Status,
        >;
        ///
        async fn instantiate_contract(
            &self,
            request: tonic::Request<super::InstantiateContractRequest>,
        ) -> std::result::Result<
            tonic::Response<super::InstantiateContractResponse>,
            tonic::Status,
        >;
        ///
        async fn query_tx(
            &self,
            request: tonic::Request<super::QueryTxRequest>,
        ) -> std::result::Result<tonic::Response<super::QueryTxResponse>, tonic::Status>;
        /** keys
*/
        async fn gen_key(
            &self,
            request: tonic::Request<super::GenKeyRequest>,
        ) -> std::result::Result<tonic::Response<super::GenKeyResponse>, tonic::Status>;
        ///
        async fn get_pub_key(
            &self,
            request: tonic::Request<super::GetPubKeyRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetPubKeyResponse>,
            tonic::Status,
        >;
        /** bank
*/
        async fn get_bank_balance(
            &self,
            request: tonic::Request<super::BankBalanceRequest>,
        ) -> std::result::Result<
            tonic::Response<super::BankBalanceResponse>,
            tonic::Status,
        >;
        ///
        async fn bank_send(
            &self,
            request: tonic::Request<super::BankSendRequest>,
        ) -> std::result::Result<
            tonic::Response<super::BankSendResponse>,
            tonic::Status,
        >;
        ///
        async fn get_denom_metadata(
            &self,
            request: tonic::Request<super::GetDenomMetadataRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetDenomMetadataResponse>,
            tonic::Status,
        >;
        ///
        async fn get_all_denom_metadata(
            &self,
            request: tonic::Request<super::GetAllDenomMetadataRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetAllDenomMetadataResponse>,
            tonic::Status,
        >;
        /** tokenfactory tx
*/
        async fn update_master_minter(
            &self,
            request: tonic::Request<super::UpdateMasterMinterRequest>,
        ) -> std::result::Result<
            tonic::Response<super::UpdateMasterMinterResponse>,
            tonic::Status,
        >;
        ///
        async fn configure_minter_controller(
            &self,
            request: tonic::Request<super::ConfigureMinterControllerRequest>,
        ) -> std::result::Result<
            tonic::Response<super::ConfigureMinterControllerResponse>,
            tonic::Status,
        >;
        ///
        async fn remove_minter_controller(
            &self,
            request: tonic::Request<super::RemoveMinterControllerRequest>,
        ) -> std::result::Result<
            tonic::Response<super::RemoveMinterControllerResponse>,
            tonic::Status,
        >;
        ///
        async fn configure_minter(
            &self,
            request: tonic::Request<super::ConfigureMinterRequest>,
        ) -> std::result::Result<
            tonic::Response<super::ConfigureMinterResponse>,
            tonic::Status,
        >;
        ///
        async fn remove_minter(
            &self,
            request: tonic::Request<super::RemoveMinterRequest>,
        ) -> std::result::Result<
            tonic::Response<super::RemoveMinterResponse>,
            tonic::Status,
        >;
        ///
        async fn update_blacklister(
            &self,
            request: tonic::Request<super::UpdateBlacklisterRequest>,
        ) -> std::result::Result<
            tonic::Response<super::UpdateBlacklisterResponse>,
            tonic::Status,
        >;
        ///
        async fn blacklist(
            &self,
            request: tonic::Request<super::BlacklistRequest>,
        ) -> std::result::Result<
            tonic::Response<super::BlacklistResponse>,
            tonic::Status,
        >;
        ///
        async fn unblacklist(
            &self,
            request: tonic::Request<super::UnblacklistRequest>,
        ) -> std::result::Result<
            tonic::Response<super::UnblacklistResponse>,
            tonic::Status,
        >;
        ///
        async fn update_pauser(
            &self,
            request: tonic::Request<super::UpdatePauserRequest>,
        ) -> std::result::Result<
            tonic::Response<super::UpdatePauserResponse>,
            tonic::Status,
        >;
        ///
        async fn pause(
            &self,
            request: tonic::Request<super::PauseRequest>,
        ) -> std::result::Result<tonic::Response<super::PauseResponse>, tonic::Status>;
        ///
        async fn unpause(
            &self,
            request: tonic::Request<super::UnpauseRequest>,
        ) -> std::result::Result<tonic::Response<super::UnpauseResponse>, tonic::Status>;
        ///
        async fn mint(
            &self,
            request: tonic::Request<super::MintRequest>,
        ) -> std::result::Result<tonic::Response<super::MintResponse>, tonic::Status>;
        ///
        async fn burn(
            &self,
            request: tonic::Request<super::BurnRequest>,
        ) -> std::result::Result<tonic::Response<super::BurnResponse>, tonic::Status>;
        ///
        async fn set_denom_metadata(
            &self,
            request: tonic::Request<super::SetDenomMetadataRequest>,
        ) -> std::result::Result<
            tonic::Response<super::SetDenomMetadataResponse>,
            tonic::Status,
        >;
        /** tokenfactory query
*/
        async fn get_tf_config(
            &self,
            request: tonic::Request<super::GetTfConfigRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetTfConfigResponse>,
            tonic::Status,
        >;
        ///
        async fn get_owner(
            &self,
            request: tonic::Request<super::GetOwnerRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetOwnerResponse>,
            tonic::Status,
        >;
        ///
        async fn get_master_minter(
            &self,
            request: tonic::Request<super::GetMasterMinterRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetMasterMinterResponse>,
            tonic::Status,
        >;
        ///
        async fn get_minter_controller(
            &self,
            request: tonic::Request<super::GetMinterControllerRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetMinterControllerResponse>,
            tonic::Status,
        >;
        ///
        async fn get_all_minter_controllers(
            &self,
            request: tonic::Request<super::GetAllMinterControllersRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetAllMinterControllersResponse>,
            tonic::Status,
        >;
        ///
        async fn get_minting_denom(
            &self,
            request: tonic::Request<super::GetMintingDenomRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetMintingDenomResponse>,
            tonic::Status,
        >;
        ///
        async fn get_all_minting_denoms(
            &self,
            request: tonic::Request<super::GetAllMintingDenomsRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetAllMintingDenomsResponse>,
            tonic::Status,
        >;
        ///
        async fn get_minters(
            &self,
            request: tonic::Request<super::GetMintersRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetMintersResponse>,
            tonic::Status,
        >;
        ///
        async fn get_all_minters(
            &self,
            request: tonic::Request<super::GetAllMintersRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetAllMintersResponse>,
            tonic::Status,
        >;
        ///
        async fn get_blacklister(
            &self,
            request: tonic::Request<super::GetBlacklisterRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetBlacklisterResponse>,
            tonic::Status,
        >;
        ///
        async fn get_pauser(
            &self,
            request: tonic::Request<super::GetPauserRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetPauserResponse>,
            tonic::Status,
        >;
        ///
        async fn get_blacklisted(
            &self,
            request: tonic::Request<super::GetBlacklistedRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetBlacklistedResponse>,
            tonic::Status,
        >;
        ///
        async fn get_all_blacklisted(
            &self,
            request: tonic::Request<super::GetAllBlacklistedRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetAllBlacklistedResponse>,
            tonic::Status,
        >;
        ///
        async fn get_paused(
            &self,
            request: tonic::Request<super::GetPausedRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetPausedResponse>,
            tonic::Status,
        >;
        ///
        async fn find_metadata_for_denom(
            &self,
            request: tonic::Request<super::FindMetadataForDenomRequest>,
        ) -> std::result::Result<
            tonic::Response<super::FindDenomMetadataResponse>,
            tonic::Status,
        >;
        /** aurum
*/
        async fn get_aurum_config(
            &self,
            request: tonic::Request<super::GetAurumConfigRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetAurumConfigResponse>,
            tonic::Status,
        >;
        ///
        async fn update_member(
            &self,
            request: tonic::Request<super::UpdateMemberRequest>,
        ) -> std::result::Result<
            tonic::Response<super::UpdateMemberResponse>,
            tonic::Status,
        >;
        ///
        async fn get_member(
            &self,
            request: tonic::Request<super::GetMemberRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetMemberResponse>,
            tonic::Status,
        >;
        ///
        async fn get_members(
            &self,
            request: tonic::Request<super::GetMembersRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetMembersResponse>,
            tonic::Status,
        >;
        ///
        async fn get_aurum_balance(
            &self,
            request: tonic::Request<super::BalanceRequest>,
        ) -> std::result::Result<tonic::Response<super::BalanceResponse>, tonic::Status>;
        ///
        async fn process_aurum_balance(
            &self,
            request: tonic::Request<super::BalanceRequest>,
        ) -> std::result::Result<tonic::Response<super::BalanceResponse>, tonic::Status>;
        ///
        async fn aurum_tx(
            &self,
            request: tonic::Request<super::PaymentRequest>,
        ) -> std::result::Result<
            tonic::Response<super::PaymentTxResponse>,
            tonic::Status,
        >;
        ///
        async fn get_payment_state(
            &self,
            request: tonic::Request<super::PaymentStateRequest>,
        ) -> std::result::Result<
            tonic::Response<super::PaymentStateResponse>,
            tonic::Status,
        >;
        ///
        async fn process_aurum_tx(
            &self,
            request: tonic::Request<super::PaymentRequest>,
        ) -> std::result::Result<tonic::Response<super::PaymentResponse>, tonic::Status>;
        ///
        async fn from_member(
            &self,
            request: tonic::Request<super::FromMemberRequest>,
        ) -> std::result::Result<tonic::Response<super::PaymentResponse>, tonic::Status>;
        /** feegrant
 feegrant - faucet wallet
*/
        async fn grant_fee_basic_allowance(
            &self,
            request: tonic::Request<super::GrantFeeBasicAllowanceRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GrantFeeBasicAllowanceResponse>,
            tonic::Status,
        >;
        ///
        async fn revoke_fee_allowance(
            &self,
            request: tonic::Request<super::RevokeFeeAllowanceRequest>,
        ) -> std::result::Result<
            tonic::Response<super::RevokeFeeAllowanceResponse>,
            tonic::Status,
        >;
        /** feegrant - all wallets
*/
        async fn get_fee_basic_allowance(
            &self,
            request: tonic::Request<super::GetFeeBasicAllowanceRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetFeeBasicAllowanceResponse>,
            tonic::Status,
        >;
        /** feegrant - other wallets
*/
        async fn request_fee_basic_allowance(
            &self,
            request: tonic::Request<super::RequestFeeBasicAllowanceRequest>,
        ) -> std::result::Result<
            tonic::Response<super::RequestFeeBasicAllowanceResponse>,
            tonic::Status,
        >;
        /** ibm mq
*/
        async fn get_mq_messsage_from_queue(
            &self,
            request: tonic::Request<super::GetMqMesssageFromQueueRequest>,
        ) -> std::result::Result<
            tonic::Response<super::GetMqMesssageFromQueueResponse>,
            tonic::Status,
        >;
        ///
        async fn post_mq_message_to_queue(
            &self,
            request: tonic::Request<super::PostMqMessageToQueueRequest>,
        ) -> std::result::Result<
            tonic::Response<super::PostMqMessageResponse>,
            tonic::Status,
        >;
        ///
        async fn post_mq_message_to_topic(
            &self,
            request: tonic::Request<super::PostMqMessageToTopicRequest>,
        ) -> std::result::Result<
            tonic::Response<super::PostMqMessageResponse>,
            tonic::Status,
        >;
    }
    ///
    #[derive(Debug)]
    pub struct WalletServer<T: Wallet> {
        inner: _Inner<T>,
        accept_compression_encodings: EnabledCompressionEncodings,
        send_compression_encodings: EnabledCompressionEncodings,
        max_decoding_message_size: Option<usize>,
        max_encoding_message_size: Option<usize>,
    }
    struct _Inner<T>(Arc<T>);
    impl<T: Wallet> WalletServer<T> {
        pub fn new(inner: T) -> Self {
            Self::from_arc(Arc::new(inner))
        }
        pub fn from_arc(inner: Arc<T>) -> Self {
            let inner = _Inner(inner);
            Self {
                inner,
                accept_compression_encodings: Default::default(),
                send_compression_encodings: Default::default(),
                max_decoding_message_size: None,
                max_encoding_message_size: None,
            }
        }
        pub fn with_interceptor<F>(
            inner: T,
            interceptor: F,
        ) -> InterceptedService<Self, F>
        where
            F: tonic::service::Interceptor,
        {
            InterceptedService::new(Self::new(inner), interceptor)
        }
        /// Enable decompressing requests with the given encoding.
        #[must_use]
        pub fn accept_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.accept_compression_encodings.enable(encoding);
            self
        }
        /// Compress responses with the given encoding, if the client supports it.
        #[must_use]
        pub fn send_compressed(mut self, encoding: CompressionEncoding) -> Self {
            self.send_compression_encodings.enable(encoding);
            self
        }
        /// Limits the maximum size of a decoded message.
        ///
        /// Default: `4MB`
        #[must_use]
        pub fn max_decoding_message_size(mut self, limit: usize) -> Self {
            self.max_decoding_message_size = Some(limit);
            self
        }
        /// Limits the maximum size of an encoded message.
        ///
        /// Default: `usize::MAX`
        #[must_use]
        pub fn max_encoding_message_size(mut self, limit: usize) -> Self {
            self.max_encoding_message_size = Some(limit);
            self
        }
    }
    impl<T, B> tonic::codegen::Service<http::Request<B>> for WalletServer<T>
    where
        T: Wallet,
        B: Body + Send + 'static,
        B::Error: Into<StdError> + Send + 'static,
    {
        type Response = http::Response<tonic::body::BoxBody>;
        type Error = std::convert::Infallible;
        type Future = BoxFuture<Self::Response, Self::Error>;
        fn poll_ready(
            &mut self,
            _cx: &mut Context<'_>,
        ) -> Poll<std::result::Result<(), Self::Error>> {
            Poll::Ready(Ok(()))
        }
        fn call(&mut self, req: http::Request<B>) -> Self::Future {
            let inner = self.inner.clone();
            match req.uri().path() {
                "/wfdc2.wallet.v1.Wallet/Echo" => {
                    #[allow(non_camel_case_types)]
                    struct EchoSvc<T: Wallet>(pub Arc<T>);
                    impl<T: Wallet> tonic::server::UnaryService<super::EchoRequest>
                    for EchoSvc<T> {
                        type Response = super::EchoResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::EchoRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::echo(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = EchoSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/StoreCode" => {
                    #[allow(non_camel_case_types)]
                    struct StoreCodeSvc<T: Wallet>(pub Arc<T>);
                    impl<T: Wallet> tonic::server::UnaryService<super::StoreCodeRequest>
                    for StoreCodeSvc<T> {
                        type Response = super::StoreCodeResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::StoreCodeRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::store_code(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = StoreCodeSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/InstantiateFtContract" => {
                    #[allow(non_camel_case_types)]
                    struct InstantiateFtContractSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::InstantiateFtContractRequest>
                    for InstantiateFtContractSvc<T> {
                        type Response = super::InstantiateFtContractResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::InstantiateFtContractRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::instantiate_ft_contract(&inner, request)
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = InstantiateFtContractSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/InstantiateContract" => {
                    #[allow(non_camel_case_types)]
                    struct InstantiateContractSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::InstantiateContractRequest>
                    for InstantiateContractSvc<T> {
                        type Response = super::InstantiateContractResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::InstantiateContractRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::instantiate_contract(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = InstantiateContractSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/QueryTx" => {
                    #[allow(non_camel_case_types)]
                    struct QueryTxSvc<T: Wallet>(pub Arc<T>);
                    impl<T: Wallet> tonic::server::UnaryService<super::QueryTxRequest>
                    for QueryTxSvc<T> {
                        type Response = super::QueryTxResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::QueryTxRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::query_tx(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = QueryTxSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/GenKey" => {
                    #[allow(non_camel_case_types)]
                    struct GenKeySvc<T: Wallet>(pub Arc<T>);
                    impl<T: Wallet> tonic::server::UnaryService<super::GenKeyRequest>
                    for GenKeySvc<T> {
                        type Response = super::GenKeyResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GenKeyRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::gen_key(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GenKeySvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/GetPubKey" => {
                    #[allow(non_camel_case_types)]
                    struct GetPubKeySvc<T: Wallet>(pub Arc<T>);
                    impl<T: Wallet> tonic::server::UnaryService<super::GetPubKeyRequest>
                    for GetPubKeySvc<T> {
                        type Response = super::GetPubKeyResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetPubKeyRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::get_pub_key(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetPubKeySvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/GetBankBalance" => {
                    #[allow(non_camel_case_types)]
                    struct GetBankBalanceSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::BankBalanceRequest>
                    for GetBankBalanceSvc<T> {
                        type Response = super::BankBalanceResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::BankBalanceRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::get_bank_balance(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetBankBalanceSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/BankSend" => {
                    #[allow(non_camel_case_types)]
                    struct BankSendSvc<T: Wallet>(pub Arc<T>);
                    impl<T: Wallet> tonic::server::UnaryService<super::BankSendRequest>
                    for BankSendSvc<T> {
                        type Response = super::BankSendResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::BankSendRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::bank_send(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = BankSendSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/GetDenomMetadata" => {
                    #[allow(non_camel_case_types)]
                    struct GetDenomMetadataSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::GetDenomMetadataRequest>
                    for GetDenomMetadataSvc<T> {
                        type Response = super::GetDenomMetadataResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetDenomMetadataRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::get_denom_metadata(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetDenomMetadataSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/GetAllDenomMetadata" => {
                    #[allow(non_camel_case_types)]
                    struct GetAllDenomMetadataSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::GetAllDenomMetadataRequest>
                    for GetAllDenomMetadataSvc<T> {
                        type Response = super::GetAllDenomMetadataResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetAllDenomMetadataRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::get_all_denom_metadata(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetAllDenomMetadataSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/UpdateMasterMinter" => {
                    #[allow(non_camel_case_types)]
                    struct UpdateMasterMinterSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::UpdateMasterMinterRequest>
                    for UpdateMasterMinterSvc<T> {
                        type Response = super::UpdateMasterMinterResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::UpdateMasterMinterRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::update_master_minter(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = UpdateMasterMinterSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/ConfigureMinterController" => {
                    #[allow(non_camel_case_types)]
                    struct ConfigureMinterControllerSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<
                        super::ConfigureMinterControllerRequest,
                    > for ConfigureMinterControllerSvc<T> {
                        type Response = super::ConfigureMinterControllerResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<
                                super::ConfigureMinterControllerRequest,
                            >,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::configure_minter_controller(&inner, request)
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = ConfigureMinterControllerSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/RemoveMinterController" => {
                    #[allow(non_camel_case_types)]
                    struct RemoveMinterControllerSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::RemoveMinterControllerRequest>
                    for RemoveMinterControllerSvc<T> {
                        type Response = super::RemoveMinterControllerResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::RemoveMinterControllerRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::remove_minter_controller(&inner, request)
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = RemoveMinterControllerSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/ConfigureMinter" => {
                    #[allow(non_camel_case_types)]
                    struct ConfigureMinterSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::ConfigureMinterRequest>
                    for ConfigureMinterSvc<T> {
                        type Response = super::ConfigureMinterResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::ConfigureMinterRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::configure_minter(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = ConfigureMinterSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/RemoveMinter" => {
                    #[allow(non_camel_case_types)]
                    struct RemoveMinterSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::RemoveMinterRequest>
                    for RemoveMinterSvc<T> {
                        type Response = super::RemoveMinterResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::RemoveMinterRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::remove_minter(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = RemoveMinterSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/UpdateBlacklister" => {
                    #[allow(non_camel_case_types)]
                    struct UpdateBlacklisterSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::UpdateBlacklisterRequest>
                    for UpdateBlacklisterSvc<T> {
                        type Response = super::UpdateBlacklisterResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::UpdateBlacklisterRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::update_blacklister(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = UpdateBlacklisterSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/Blacklist" => {
                    #[allow(non_camel_case_types)]
                    struct BlacklistSvc<T: Wallet>(pub Arc<T>);
                    impl<T: Wallet> tonic::server::UnaryService<super::BlacklistRequest>
                    for BlacklistSvc<T> {
                        type Response = super::BlacklistResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::BlacklistRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::blacklist(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = BlacklistSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/Unblacklist" => {
                    #[allow(non_camel_case_types)]
                    struct UnblacklistSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::UnblacklistRequest>
                    for UnblacklistSvc<T> {
                        type Response = super::UnblacklistResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::UnblacklistRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::unblacklist(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = UnblacklistSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/UpdatePauser" => {
                    #[allow(non_camel_case_types)]
                    struct UpdatePauserSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::UpdatePauserRequest>
                    for UpdatePauserSvc<T> {
                        type Response = super::UpdatePauserResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::UpdatePauserRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::update_pauser(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = UpdatePauserSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/Pause" => {
                    #[allow(non_camel_case_types)]
                    struct PauseSvc<T: Wallet>(pub Arc<T>);
                    impl<T: Wallet> tonic::server::UnaryService<super::PauseRequest>
                    for PauseSvc<T> {
                        type Response = super::PauseResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::PauseRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::pause(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = PauseSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/Unpause" => {
                    #[allow(non_camel_case_types)]
                    struct UnpauseSvc<T: Wallet>(pub Arc<T>);
                    impl<T: Wallet> tonic::server::UnaryService<super::UnpauseRequest>
                    for UnpauseSvc<T> {
                        type Response = super::UnpauseResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::UnpauseRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::unpause(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = UnpauseSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/Mint" => {
                    #[allow(non_camel_case_types)]
                    struct MintSvc<T: Wallet>(pub Arc<T>);
                    impl<T: Wallet> tonic::server::UnaryService<super::MintRequest>
                    for MintSvc<T> {
                        type Response = super::MintResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::MintRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::mint(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = MintSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/Burn" => {
                    #[allow(non_camel_case_types)]
                    struct BurnSvc<T: Wallet>(pub Arc<T>);
                    impl<T: Wallet> tonic::server::UnaryService<super::BurnRequest>
                    for BurnSvc<T> {
                        type Response = super::BurnResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::BurnRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::burn(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = BurnSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/SetDenomMetadata" => {
                    #[allow(non_camel_case_types)]
                    struct SetDenomMetadataSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::SetDenomMetadataRequest>
                    for SetDenomMetadataSvc<T> {
                        type Response = super::SetDenomMetadataResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::SetDenomMetadataRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::set_denom_metadata(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = SetDenomMetadataSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/GetTfConfig" => {
                    #[allow(non_camel_case_types)]
                    struct GetTfConfigSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::GetTfConfigRequest>
                    for GetTfConfigSvc<T> {
                        type Response = super::GetTfConfigResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetTfConfigRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::get_tf_config(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetTfConfigSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/GetOwner" => {
                    #[allow(non_camel_case_types)]
                    struct GetOwnerSvc<T: Wallet>(pub Arc<T>);
                    impl<T: Wallet> tonic::server::UnaryService<super::GetOwnerRequest>
                    for GetOwnerSvc<T> {
                        type Response = super::GetOwnerResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetOwnerRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::get_owner(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetOwnerSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/GetMasterMinter" => {
                    #[allow(non_camel_case_types)]
                    struct GetMasterMinterSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::GetMasterMinterRequest>
                    for GetMasterMinterSvc<T> {
                        type Response = super::GetMasterMinterResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetMasterMinterRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::get_master_minter(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetMasterMinterSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/GetMinterController" => {
                    #[allow(non_camel_case_types)]
                    struct GetMinterControllerSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::GetMinterControllerRequest>
                    for GetMinterControllerSvc<T> {
                        type Response = super::GetMinterControllerResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetMinterControllerRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::get_minter_controller(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetMinterControllerSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/GetAllMinterControllers" => {
                    #[allow(non_camel_case_types)]
                    struct GetAllMinterControllersSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::GetAllMinterControllersRequest>
                    for GetAllMinterControllersSvc<T> {
                        type Response = super::GetAllMinterControllersResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<
                                super::GetAllMinterControllersRequest,
                            >,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::get_all_minter_controllers(&inner, request)
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetAllMinterControllersSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/GetMintingDenom" => {
                    #[allow(non_camel_case_types)]
                    struct GetMintingDenomSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::GetMintingDenomRequest>
                    for GetMintingDenomSvc<T> {
                        type Response = super::GetMintingDenomResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetMintingDenomRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::get_minting_denom(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetMintingDenomSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/GetAllMintingDenoms" => {
                    #[allow(non_camel_case_types)]
                    struct GetAllMintingDenomsSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::GetAllMintingDenomsRequest>
                    for GetAllMintingDenomsSvc<T> {
                        type Response = super::GetAllMintingDenomsResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetAllMintingDenomsRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::get_all_minting_denoms(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetAllMintingDenomsSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/GetMinters" => {
                    #[allow(non_camel_case_types)]
                    struct GetMintersSvc<T: Wallet>(pub Arc<T>);
                    impl<T: Wallet> tonic::server::UnaryService<super::GetMintersRequest>
                    for GetMintersSvc<T> {
                        type Response = super::GetMintersResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetMintersRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::get_minters(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetMintersSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/GetAllMinters" => {
                    #[allow(non_camel_case_types)]
                    struct GetAllMintersSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::GetAllMintersRequest>
                    for GetAllMintersSvc<T> {
                        type Response = super::GetAllMintersResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetAllMintersRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::get_all_minters(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetAllMintersSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/GetBlacklister" => {
                    #[allow(non_camel_case_types)]
                    struct GetBlacklisterSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::GetBlacklisterRequest>
                    for GetBlacklisterSvc<T> {
                        type Response = super::GetBlacklisterResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetBlacklisterRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::get_blacklister(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetBlacklisterSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/GetPauser" => {
                    #[allow(non_camel_case_types)]
                    struct GetPauserSvc<T: Wallet>(pub Arc<T>);
                    impl<T: Wallet> tonic::server::UnaryService<super::GetPauserRequest>
                    for GetPauserSvc<T> {
                        type Response = super::GetPauserResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetPauserRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::get_pauser(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetPauserSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/GetBlacklisted" => {
                    #[allow(non_camel_case_types)]
                    struct GetBlacklistedSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::GetBlacklistedRequest>
                    for GetBlacklistedSvc<T> {
                        type Response = super::GetBlacklistedResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetBlacklistedRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::get_blacklisted(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetBlacklistedSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/GetAllBlacklisted" => {
                    #[allow(non_camel_case_types)]
                    struct GetAllBlacklistedSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::GetAllBlacklistedRequest>
                    for GetAllBlacklistedSvc<T> {
                        type Response = super::GetAllBlacklistedResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetAllBlacklistedRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::get_all_blacklisted(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetAllBlacklistedSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/GetPaused" => {
                    #[allow(non_camel_case_types)]
                    struct GetPausedSvc<T: Wallet>(pub Arc<T>);
                    impl<T: Wallet> tonic::server::UnaryService<super::GetPausedRequest>
                    for GetPausedSvc<T> {
                        type Response = super::GetPausedResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetPausedRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::get_paused(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetPausedSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/FindMetadataForDenom" => {
                    #[allow(non_camel_case_types)]
                    struct FindMetadataForDenomSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::FindMetadataForDenomRequest>
                    for FindMetadataForDenomSvc<T> {
                        type Response = super::FindDenomMetadataResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::FindMetadataForDenomRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::find_metadata_for_denom(&inner, request)
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = FindMetadataForDenomSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/GetAurumConfig" => {
                    #[allow(non_camel_case_types)]
                    struct GetAurumConfigSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::GetAurumConfigRequest>
                    for GetAurumConfigSvc<T> {
                        type Response = super::GetAurumConfigResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetAurumConfigRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::get_aurum_config(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetAurumConfigSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/UpdateMember" => {
                    #[allow(non_camel_case_types)]
                    struct UpdateMemberSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::UpdateMemberRequest>
                    for UpdateMemberSvc<T> {
                        type Response = super::UpdateMemberResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::UpdateMemberRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::update_member(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = UpdateMemberSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/GetMember" => {
                    #[allow(non_camel_case_types)]
                    struct GetMemberSvc<T: Wallet>(pub Arc<T>);
                    impl<T: Wallet> tonic::server::UnaryService<super::GetMemberRequest>
                    for GetMemberSvc<T> {
                        type Response = super::GetMemberResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetMemberRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::get_member(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetMemberSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/GetMembers" => {
                    #[allow(non_camel_case_types)]
                    struct GetMembersSvc<T: Wallet>(pub Arc<T>);
                    impl<T: Wallet> tonic::server::UnaryService<super::GetMembersRequest>
                    for GetMembersSvc<T> {
                        type Response = super::GetMembersResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetMembersRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::get_members(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetMembersSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/GetAurumBalance" => {
                    #[allow(non_camel_case_types)]
                    struct GetAurumBalanceSvc<T: Wallet>(pub Arc<T>);
                    impl<T: Wallet> tonic::server::UnaryService<super::BalanceRequest>
                    for GetAurumBalanceSvc<T> {
                        type Response = super::BalanceResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::BalanceRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::get_aurum_balance(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetAurumBalanceSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/ProcessAurumBalance" => {
                    #[allow(non_camel_case_types)]
                    struct ProcessAurumBalanceSvc<T: Wallet>(pub Arc<T>);
                    impl<T: Wallet> tonic::server::UnaryService<super::BalanceRequest>
                    for ProcessAurumBalanceSvc<T> {
                        type Response = super::BalanceResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::BalanceRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::process_aurum_balance(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = ProcessAurumBalanceSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/AurumTx" => {
                    #[allow(non_camel_case_types)]
                    struct AurumTxSvc<T: Wallet>(pub Arc<T>);
                    impl<T: Wallet> tonic::server::UnaryService<super::PaymentRequest>
                    for AurumTxSvc<T> {
                        type Response = super::PaymentTxResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::PaymentRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::aurum_tx(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = AurumTxSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/GetPaymentState" => {
                    #[allow(non_camel_case_types)]
                    struct GetPaymentStateSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::PaymentStateRequest>
                    for GetPaymentStateSvc<T> {
                        type Response = super::PaymentStateResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::PaymentStateRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::get_payment_state(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetPaymentStateSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/ProcessAurumTx" => {
                    #[allow(non_camel_case_types)]
                    struct ProcessAurumTxSvc<T: Wallet>(pub Arc<T>);
                    impl<T: Wallet> tonic::server::UnaryService<super::PaymentRequest>
                    for ProcessAurumTxSvc<T> {
                        type Response = super::PaymentResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::PaymentRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::process_aurum_tx(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = ProcessAurumTxSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/FromMember" => {
                    #[allow(non_camel_case_types)]
                    struct FromMemberSvc<T: Wallet>(pub Arc<T>);
                    impl<T: Wallet> tonic::server::UnaryService<super::FromMemberRequest>
                    for FromMemberSvc<T> {
                        type Response = super::PaymentResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::FromMemberRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::from_member(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = FromMemberSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/GrantFeeBasicAllowance" => {
                    #[allow(non_camel_case_types)]
                    struct GrantFeeBasicAllowanceSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::GrantFeeBasicAllowanceRequest>
                    for GrantFeeBasicAllowanceSvc<T> {
                        type Response = super::GrantFeeBasicAllowanceResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GrantFeeBasicAllowanceRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::grant_fee_basic_allowance(&inner, request)
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GrantFeeBasicAllowanceSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/RevokeFeeAllowance" => {
                    #[allow(non_camel_case_types)]
                    struct RevokeFeeAllowanceSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::RevokeFeeAllowanceRequest>
                    for RevokeFeeAllowanceSvc<T> {
                        type Response = super::RevokeFeeAllowanceResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::RevokeFeeAllowanceRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::revoke_fee_allowance(&inner, request).await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = RevokeFeeAllowanceSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/GetFeeBasicAllowance" => {
                    #[allow(non_camel_case_types)]
                    struct GetFeeBasicAllowanceSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::GetFeeBasicAllowanceRequest>
                    for GetFeeBasicAllowanceSvc<T> {
                        type Response = super::GetFeeBasicAllowanceResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetFeeBasicAllowanceRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::get_fee_basic_allowance(&inner, request)
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetFeeBasicAllowanceSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/RequestFeeBasicAllowance" => {
                    #[allow(non_camel_case_types)]
                    struct RequestFeeBasicAllowanceSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::RequestFeeBasicAllowanceRequest>
                    for RequestFeeBasicAllowanceSvc<T> {
                        type Response = super::RequestFeeBasicAllowanceResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<
                                super::RequestFeeBasicAllowanceRequest,
                            >,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::request_fee_basic_allowance(&inner, request)
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = RequestFeeBasicAllowanceSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/GetMQMesssageFromQueue" => {
                    #[allow(non_camel_case_types)]
                    struct GetMQMesssageFromQueueSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::GetMqMesssageFromQueueRequest>
                    for GetMQMesssageFromQueueSvc<T> {
                        type Response = super::GetMqMesssageFromQueueResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::GetMqMesssageFromQueueRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::get_mq_messsage_from_queue(&inner, request)
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = GetMQMesssageFromQueueSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/PostMQMessageToQueue" => {
                    #[allow(non_camel_case_types)]
                    struct PostMQMessageToQueueSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::PostMqMessageToQueueRequest>
                    for PostMQMessageToQueueSvc<T> {
                        type Response = super::PostMqMessageResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::PostMqMessageToQueueRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::post_mq_message_to_queue(&inner, request)
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = PostMQMessageToQueueSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                "/wfdc2.wallet.v1.Wallet/PostMQMessageToTopic" => {
                    #[allow(non_camel_case_types)]
                    struct PostMQMessageToTopicSvc<T: Wallet>(pub Arc<T>);
                    impl<
                        T: Wallet,
                    > tonic::server::UnaryService<super::PostMqMessageToTopicRequest>
                    for PostMQMessageToTopicSvc<T> {
                        type Response = super::PostMqMessageResponse;
                        type Future = BoxFuture<
                            tonic::Response<Self::Response>,
                            tonic::Status,
                        >;
                        fn call(
                            &mut self,
                            request: tonic::Request<super::PostMqMessageToTopicRequest>,
                        ) -> Self::Future {
                            let inner = Arc::clone(&self.0);
                            let fut = async move {
                                <T as Wallet>::post_mq_message_to_topic(&inner, request)
                                    .await
                            };
                            Box::pin(fut)
                        }
                    }
                    let accept_compression_encodings = self.accept_compression_encodings;
                    let send_compression_encodings = self.send_compression_encodings;
                    let max_decoding_message_size = self.max_decoding_message_size;
                    let max_encoding_message_size = self.max_encoding_message_size;
                    let inner = self.inner.clone();
                    let fut = async move {
                        let inner = inner.0;
                        let method = PostMQMessageToTopicSvc(inner);
                        let codec = tonic::codec::ProstCodec::default();
                        let mut grpc = tonic::server::Grpc::new(codec)
                            .apply_compression_config(
                                accept_compression_encodings,
                                send_compression_encodings,
                            )
                            .apply_max_message_size_config(
                                max_decoding_message_size,
                                max_encoding_message_size,
                            );
                        let res = grpc.unary(method, req).await;
                        Ok(res)
                    };
                    Box::pin(fut)
                }
                _ => {
                    Box::pin(async move {
                        Ok(
                            http::Response::builder()
                                .status(200)
                                .header("grpc-status", "12")
                                .header("content-type", "application/grpc")
                                .body(empty_body())
                                .unwrap(),
                        )
                    })
                }
            }
        }
    }
    impl<T: Wallet> Clone for WalletServer<T> {
        fn clone(&self) -> Self {
            let inner = self.inner.clone();
            Self {
                inner,
                accept_compression_encodings: self.accept_compression_encodings,
                send_compression_encodings: self.send_compression_encodings,
                max_decoding_message_size: self.max_decoding_message_size,
                max_encoding_message_size: self.max_encoding_message_size,
            }
        }
    }
    impl<T: Wallet> Clone for _Inner<T> {
        fn clone(&self) -> Self {
            Self(Arc::clone(&self.0))
        }
    }
    impl<T: std::fmt::Debug> std::fmt::Debug for _Inner<T> {
        fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
            write!(f, "{:?}", self.0)
        }
    }
    impl<T: Wallet> tonic::server::NamedService for WalletServer<T> {
        const NAME: &'static str = "wfdc2.wallet.v1.Wallet";
    }
}
