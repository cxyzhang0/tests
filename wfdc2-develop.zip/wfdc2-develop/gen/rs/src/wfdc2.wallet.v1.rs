// @generated
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct StoreCodeRequest {
    #[prost(string, tag="1")]
    pub wasm_file: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct StoreCodeResponse {
    #[prost(string, tag="1")]
    pub txhash: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct InstantiateFtContractRequest {
    #[prost(uint64, tag="1")]
    pub code_id: u64,
    #[prost(string, tag="2")]
    pub label: ::prost::alloc::string::String,
    #[prost(bool, tag="3")]
    pub is_tf: bool,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct InstantiateFtContractResponse {
    #[prost(string, tag="1")]
    pub txhash: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct InstantiateContractRequest {
    #[prost(uint64, tag="1")]
    pub code_id: u64,
    #[prost(string, tag="2")]
    pub label: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub init_msg: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct InstantiateContractResponse {
    #[prost(string, tag="1")]
    pub txhash: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryTxRequest {
    #[prost(string, tag="1")]
    pub txhash: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct QueryTxResponse {
    #[prost(string, tag="1")]
    pub txhash: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub status: ::prost::alloc::string::String,
    #[prost(int64, tag="3")]
    pub height: i64,
    #[prost(int32, tag="4")]
    pub index: i32,
    #[prost(uint32, tag="5")]
    pub code: u32,
    #[prost(string, tag="6")]
    pub log: ::prost::alloc::string::String,
    #[prost(string, tag="7")]
    pub info: ::prost::alloc::string::String,
    #[prost(int64, tag="8")]
    pub gas_wanted: i64,
    #[prost(int64, tag="9")]
    pub gas_used: i64,
    #[prost(uint32, tag="10")]
    pub num_events: u32,
}
/// DenomUnit and DenomMetadata are copied from cosmos-sdk/x/bank/proto/cosmos/bank/v1beta1/bank.proto
/// todo: how can we use cosmos-sdk/x/bank/proto/cosmos/bank/v1beta1/bank.proto?
/// DenomUnit represents a struct that describes a given
/// denomination unit of the basic token.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct DenomUnit {
    /// denom represents the string name of the given denom unit (e.g uatom).
    #[prost(string, tag="1")]
    pub denom: ::prost::alloc::string::String,
    /// exponent represents power of 10 exponent that one must
    /// raise the base_denom to in order to equal the given DenomUnit's denom
    /// 1 denom = 10^exponent base_denom
    /// (e.g. with a base_denom of uatom, one can create a DenomUnit of 'atom' with
    /// exponent = 6, thus: 1 atom = 10^6 uatom).
    #[prost(uint32, optional, tag="2")]
    pub exponent: ::core::option::Option<u32>,
    /// aliases is a list of string aliases for the given denom
    #[prost(string, repeated, tag="3")]
    pub aliases: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
/// todo: how can we use cosmos-sdk/x/bank/proto/cosmos/bank/v1beta1/bank.proto?
/// Metadata represents a struct that describes
/// a basic token.
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct DenomMetadata {
    #[prost(string, tag="1")]
    pub description: ::prost::alloc::string::String,
    /// denom_units represents the list of DenomUnit's for a given coin
    #[prost(message, repeated, tag="2")]
    pub denom_units: ::prost::alloc::vec::Vec<DenomUnit>,
    /// base represents the base denom (should be the DenomUnit with exponent = 0).
    #[prost(string, tag="3")]
    pub base: ::prost::alloc::string::String,
    /// display indicates the suggested denom that should be
    /// displayed in clients.
    #[prost(string, tag="4")]
    pub display: ::prost::alloc::string::String,
    /// name defines the name of the token (eg: Cosmos Atom)
    #[prost(string, tag="5")]
    pub name: ::prost::alloc::string::String,
    /// symbol is the token symbol usually shown on exchanges (eg: ATOM). This can
    /// be the same as the display.
    #[prost(string, tag="6")]
    pub symbol: ::prost::alloc::string::String,
    /// URI to a document (on or off-chain) that contains additional information. Optional.
    #[prost(string, optional, tag="7")]
    pub uri: ::core::option::Option<::prost::alloc::string::String>,
    /// URIHash is a sha256 hash of a document pointed by URI. It's used to verify that
    /// the document didn't change. Optional.
    #[prost(string, optional, tag="8")]
    pub uri_hash: ::core::option::Option<::prost::alloc::string::String>,
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum MessageType {
    NotSet = 0,
    Mt103 = 1,
    Mt202 = 2,
}
impl MessageType {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            MessageType::NotSet => "MessageType_NotSet",
            MessageType::Mt103 => "MT103",
            MessageType::Mt202 => "MT202",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "MessageType_NotSet" => Some(Self::NotSet),
            "MT103" => Some(Self::Mt103),
            "MT202" => Some(Self::Mt202),
            _ => None,
        }
    }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum PaymentType {
    Unknown = 0,
    /// ("Funding")
    Funding = 1,
    /// ("Defunding")
    Defunding = 2,
    /// ("Payment")
    Payment = 3,
}
impl PaymentType {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            PaymentType::Unknown => "PaymentType_Unknown",
            PaymentType::Funding => "Funding",
            PaymentType::Defunding => "Defunding",
            PaymentType::Payment => "Payment",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "PaymentType_Unknown" => Some(Self::Unknown),
            "Funding" => Some(Self::Funding),
            "Defunding" => Some(Self::Defunding),
            "Payment" => Some(Self::Payment),
            _ => None,
        }
    }
}
/// / This one is not used.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum PaymentStateStatus {
    NotSet = 0,
    ///
    FundTransferred = 1,
    ///
    Confirmed = 2,
    ///
    Rejected = 3,
    ///
    Defunded = 4,
    ///
    Funded = 5,
}
impl PaymentStateStatus {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            PaymentStateStatus::NotSet => "PaymentStateStatus_NotSet",
            PaymentStateStatus::FundTransferred => "FundTransferred",
            PaymentStateStatus::Confirmed => "Confirmed",
            PaymentStateStatus::Rejected => "Rejected",
            PaymentStateStatus::Defunded => "Defunded",
            PaymentStateStatus::Funded => "Funded",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "PaymentStateStatus_NotSet" => Some(Self::NotSet),
            "FundTransferred" => Some(Self::FundTransferred),
            "Confirmed" => Some(Self::Confirmed),
            "Rejected" => Some(Self::Rejected),
            "Defunded" => Some(Self::Defunded),
            "Funded" => Some(Self::Funded),
            _ => None,
        }
    }
}
/// TODO: where is it coming from?
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum PaymentStatus {
    Unknown = 0,
    /// ("Pending")
    Pending = 1,
    /// ("Success")
    Success = 2,
    /// ("Error")
    Error = 3,
}
impl PaymentStatus {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            PaymentStatus::Unknown => "Unknown",
            PaymentStatus::Pending => "Pending",
            PaymentStatus::Success => "Success",
            PaymentStatus::Error => "Error",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "Unknown" => Some(Self::Unknown),
            "Pending" => Some(Self::Pending),
            "Success" => Some(Self::Success),
            "Error" => Some(Self::Error),
            _ => None,
        }
    }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum NotificationType {
    Unspecified = 0,
    Notifysender = 1,
    Transfernotification = 2,
}
impl NotificationType {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            NotificationType::Unspecified => "NotificationType_UNSPECIFIED",
            NotificationType::Notifysender => "NOTIFYSENDER",
            NotificationType::Transfernotification => "TRANSFERNOTIFICATION",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "NotificationType_UNSPECIFIED" => Some(Self::Unspecified),
            "NOTIFYSENDER" => Some(Self::Notifysender),
            "TRANSFERNOTIFICATION" => Some(Self::Transfernotification),
            _ => None,
        }
    }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum TransactionStatus {
    Unspecified = 0,
    Success = 1,
    Error = 2,
}
impl TransactionStatus {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            TransactionStatus::Unspecified => "TransactionStatus_UNSPECIFIED",
            TransactionStatus::Success => "SUCCESS",
            TransactionStatus::Error => "ERROR",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "TransactionStatus_UNSPECIFIED" => Some(Self::Unspecified),
            "SUCCESS" => Some(Self::Success),
            "ERROR" => Some(Self::Error),
            _ => None,
        }
    }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum ErrorCode {
    Unspecified = 0,
    /// ("100", "Invalid Currency")
    InvalidCurrency = 100,
    /// ("110", "Corda Flow Failed")
    CordaFlowFailed = 110,
    /// ("120", "Funding/Defunding must include Issuer Branch")
    PartiesNotFundingNode = 120,
    /// ("130", "Originating and beneficiary cannot be the same")
    PartiesCannotBeTheSame = 130,
    /// ("140", "Funding node cannot originate payments")
    FundingNodeCannotOriginatePayments = 140,
    /// ("150", "Funding node cannot receive payments")
    FundingNodeCannotReceivePayments = 150,
    /// ("160", "Not sufficient funds")
    NotSufficientFunds = 160,
    /// ("165", "Token count is too low")
    InsufficientNotLockedBalance = 165,
    /// ("170", "Originating party required")
    OriginatingPartyRequired = 170,
    /// ("180", "Data not found")
    DataNotFound = 180,
    /// ("200", "Invalid Party")
    InvalidParty = 200,
}
impl ErrorCode {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            ErrorCode::Unspecified => "ErrorCode_UNSPECIFIED",
            ErrorCode::InvalidCurrency => "INVALID_CURRENCY",
            ErrorCode::CordaFlowFailed => "CORDA_FLOW_FAILED",
            ErrorCode::PartiesNotFundingNode => "PARTIES_NOT_FUNDING_NODE",
            ErrorCode::PartiesCannotBeTheSame => "PARTIES_CANNOT_BE_THE_SAME",
            ErrorCode::FundingNodeCannotOriginatePayments => "FUNDING_NODE_CANNOT_ORIGINATE_PAYMENTS",
            ErrorCode::FundingNodeCannotReceivePayments => "FUNDING_NODE_CANNOT_RECEIVE_PAYMENTS",
            ErrorCode::NotSufficientFunds => "NOT_SUFFICIENT_FUNDS",
            ErrorCode::InsufficientNotLockedBalance => "INSUFFICIENT_NOT_LOCKED_BALANCE",
            ErrorCode::OriginatingPartyRequired => "ORIGINATING_PARTY_REQUIRED",
            ErrorCode::DataNotFound => "DATA_NOT_FOUND",
            ErrorCode::InvalidParty => "INVALID_PARTY",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "ErrorCode_UNSPECIFIED" => Some(Self::Unspecified),
            "INVALID_CURRENCY" => Some(Self::InvalidCurrency),
            "CORDA_FLOW_FAILED" => Some(Self::CordaFlowFailed),
            "PARTIES_NOT_FUNDING_NODE" => Some(Self::PartiesNotFundingNode),
            "PARTIES_CANNOT_BE_THE_SAME" => Some(Self::PartiesCannotBeTheSame),
            "FUNDING_NODE_CANNOT_ORIGINATE_PAYMENTS" => Some(Self::FundingNodeCannotOriginatePayments),
            "FUNDING_NODE_CANNOT_RECEIVE_PAYMENTS" => Some(Self::FundingNodeCannotReceivePayments),
            "NOT_SUFFICIENT_FUNDS" => Some(Self::NotSufficientFunds),
            "INSUFFICIENT_NOT_LOCKED_BALANCE" => Some(Self::InsufficientNotLockedBalance),
            "ORIGINATING_PARTY_REQUIRED" => Some(Self::OriginatingPartyRequired),
            "DATA_NOT_FOUND" => Some(Self::DataNotFound),
            "INVALID_PARTY" => Some(Self::InvalidParty),
            _ => None,
        }
    }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum KeyType {
    Unspecified = 0,
    /// ("Account")
    Account = 1,
    /// ("Consensus")
    Consensus = 2,
}
impl KeyType {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            KeyType::Unspecified => "KeyType_UNSPECIFIED",
            KeyType::Account => "Account",
            KeyType::Consensus => "Consensus",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "KeyType_UNSPECIFIED" => Some(Self::Unspecified),
            "Account" => Some(Self::Account),
            "Consensus" => Some(Self::Consensus),
            _ => None,
        }
    }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum CryptographAlgorithm {
    Unspecified = 0,
    /// ("Secp256r1")
    Secp256k1 = 1,
    /// ("Ed25519")
    Ed25519 = 2,
    /// ("Secp256r1")
    Secp256r1 = 3,
    /// ("RSA2048")
    Rsa2048 = 4,
}
impl CryptographAlgorithm {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            CryptographAlgorithm::Unspecified => "CryptographAlgorithm_UNSPECIFIED",
            CryptographAlgorithm::Secp256k1 => "Secp256k1",
            CryptographAlgorithm::Ed25519 => "Ed25519",
            CryptographAlgorithm::Secp256r1 => "Secp256r1",
            CryptographAlgorithm::Rsa2048 => "RSA2048",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "CryptographAlgorithm_UNSPECIFIED" => Some(Self::Unspecified),
            "Secp256k1" => Some(Self::Secp256k1),
            "Ed25519" => Some(Self::Ed25519),
            "Secp256r1" => Some(Self::Secp256r1),
            "RSA2048" => Some(Self::Rsa2048),
            _ => None,
        }
    }
}
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord, ::prost::Enumeration)]
#[repr(i32)]
pub enum BalanceStatus {
    Unspecified = 0,
    /// "SUCCESS"
    Success = 1,
    /// "FAILED"
    Failed = 2,
}
impl BalanceStatus {
    /// String value of the enum field names used in the ProtoBuf definition.
    ///
    /// The values are not transformed in any way and thus are considered stable
    /// (if the ProtoBuf definition does not change) and safe for programmatic use.
    pub fn as_str_name(&self) -> &'static str {
        match self {
            BalanceStatus::Unspecified => "BalanceStatus_UNSPECIFIED",
            BalanceStatus::Success => "BalanceStatus_SUCCESS",
            BalanceStatus::Failed => "BalanceStatus_FAILED",
        }
    }
    /// Creates an enum from field names used in the ProtoBuf definition.
    pub fn from_str_name(value: &str) -> ::core::option::Option<Self> {
        match value {
            "BalanceStatus_UNSPECIFIED" => Some(Self::Unspecified),
            "BalanceStatus_SUCCESS" => Some(Self::Success),
            "BalanceStatus_FAILED" => Some(Self::Failed),
            _ => None,
        }
    }
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct PaymentRequest {
    #[prost(message, optional, tag="1")]
    pub originating_party: ::core::option::Option<X500Name>,
    #[prost(message, optional, tag="2")]
    pub beneficiary_party: ::core::option::Option<X500Name>,
    #[prost(double, tag="3")]
    pub amount: f64,
    #[prost(string, tag="4")]
    pub currency: ::prost::alloc::string::String,
    /// MT202, MT103
    #[prost(string, tag="5")]
    pub message_type: ::prost::alloc::string::String,
    ///         MessageType messageType = 5; // MT202, MT103
    #[prost(string, tag="6")]
    pub payment_type: ::prost::alloc::string::String,
    ///         PaymentType paymentType = 6;
    #[prost(string, tag="7")]
    pub payment_instruction: ::prost::alloc::string::String,
    #[prost(string, tag="8")]
    pub tracking_id: ::prost::alloc::string::String,
    #[prost(string, tag="9")]
    pub send_business_date: ::prost::alloc::string::String,
    #[prost(string, tag="10")]
    pub request_date_time: ::prost::alloc::string::String,
    #[prost(string, tag="11")]
    pub custom1: ::prost::alloc::string::String,
    #[prost(string, tag="12")]
    pub custom2: ::prost::alloc::string::String,
    #[prost(string, tag="13")]
    pub custom3: ::prost::alloc::string::String,
    #[prost(string, tag="14")]
    pub custom4: ::prost::alloc::string::String,
    #[prost(string, tag="15")]
    pub custom5: ::prost::alloc::string::String,
    #[prost(string, tag="16")]
    pub custom6: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct PaymentTxResponse {
    #[prost(string, tag="1")]
    pub txhash: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub tracking_id: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct PaymentResponse {
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
    #[prost(message, optional, tag="2")]
    pub originating_party: ::core::option::Option<X500Name>,
    #[prost(message, optional, tag="3")]
    pub beneficiary_party: ::core::option::Option<X500Name>,
    #[prost(double, tag="4")]
    pub amount: f64,
    #[prost(string, tag="5")]
    pub currency: ::prost::alloc::string::String,
    #[prost(string, tag="6")]
    pub payment_instruction: ::prost::alloc::string::String,
    #[prost(string, tag="7")]
    pub tracking_id: ::prost::alloc::string::String,
    #[prost(string, tag="8")]
    pub send_business_date: ::prost::alloc::string::String,
    #[prost(string, tag="9")]
    pub request_date_time: ::prost::alloc::string::String,
    /// MT202, MT103
    #[prost(string, tag="10")]
    pub message_type: ::prost::alloc::string::String,
    /// //    MessageType messageType = 10; // MT202, MT103
    #[prost(string, tag="11")]
    pub payment_type: ::prost::alloc::string::String,
    /// //    PaymentType paymentType = 11;
    #[prost(string, tag="12")]
    pub notification_type: ::prost::alloc::string::String,
    /// //    NotificationType notificationType = 12;
    #[prost(string, tag="13")]
    pub entry_date_time: ::prost::alloc::string::String,
    #[prost(string, tag="14")]
    pub payment_status: ::prost::alloc::string::String,
    /// //    PaymentStateStatus paymentStatus = 14;
    #[prost(string, tag="15")]
    pub transaction_status: ::prost::alloc::string::String,
    /// //    TransactionStatus transactionStatus = 15;
    #[prost(string, tag="16")]
    pub error_code: ::prost::alloc::string::String,
    /// //    ErrorCode errorCode = 16;
    #[prost(string, tag="17")]
    pub error_description: ::prost::alloc::string::String,
    #[prost(string, tag="18")]
    pub custom1: ::prost::alloc::string::String,
    #[prost(string, tag="19")]
    pub custom2: ::prost::alloc::string::String,
    #[prost(string, tag="20")]
    pub custom3: ::prost::alloc::string::String,
    #[prost(string, tag="21")]
    pub custom4: ::prost::alloc::string::String,
    #[prost(string, tag="22")]
    pub custom5: ::prost::alloc::string::String,
    #[prost(string, tag="23")]
    pub custom6: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct X500Name {
    #[prost(string, tag="1")]
    pub common_name: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub organization_unit: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub organization: ::prost::alloc::string::String,
    #[prost(string, tag="4")]
    pub locality: ::prost::alloc::string::String,
    #[prost(string, tag="5")]
    pub state: ::prost::alloc::string::String,
    #[prost(string, tag="6")]
    pub country: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct PaymentStateRequest {
    #[prost(string, tag="1")]
    pub tracking_id: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct PaymentStateResponse {
    #[prost(message, optional, tag="1")]
    pub resp: ::core::option::Option<PaymentResponse>,
    #[prost(string, optional, tag="2")]
    pub txhash: ::core::option::Option<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct FromMemberRequest {
    #[prost(string, tag="1")]
    pub tracking_id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub txhash1: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub txhash2: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetAurumConfigRequest {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetAurumConfigResponse {
    #[prost(string, tag="1")]
    pub owner: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub tf_address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct UpdateMemberRequest {
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub addr: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub pubkey: ::prost::alloc::string::String,
    #[prost(string, tag="4")]
    pub grpc: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct UpdateMemberResponse {
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub txhash: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetMemberRequest {
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetMemberResponse {
    #[prost(string, tag="1")]
    pub id: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub addr: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub pubkey: ::prost::alloc::string::String,
    #[prost(string, tag="4")]
    pub grpc: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetMembersRequest {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetMembersResponse {
    #[prost(message, repeated, tag="1")]
    pub members: ::prost::alloc::vec::Vec<GetMemberResponse>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct BalanceRequest {
    #[prost(message, optional, tag="1")]
    pub party: ::core::option::Option<X500Name>,
    #[prost(string, tag="2")]
    pub currency: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub tracking_id: ::prost::alloc::string::String,
    #[prost(string, tag="4")]
    pub ref_number: ::prost::alloc::string::String,
    #[prost(string, tag="5")]
    pub request_date_time: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct BalanceResponse {
    #[prost(string, tag="1")]
    pub status: ::prost::alloc::string::String,
    ///     BalanceStatus status = 1;
    #[prost(message, optional, tag="2")]
    pub message: ::core::option::Option<BalanceError>,
    #[prost(message, optional, tag="3")]
    pub data: ::core::option::Option<CashResponse>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct CashResponse {
    #[prost(message, optional, tag="1")]
    pub party: ::core::option::Option<X500Name>,
    #[prost(string, tag="2")]
    pub amount: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub currency: ::prost::alloc::string::String,
    #[prost(string, tag="4")]
    pub tracking_id: ::prost::alloc::string::String,
    #[prost(string, tag="5")]
    pub ref_number: ::prost::alloc::string::String,
    #[prost(string, tag="6")]
    pub request_date_time: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct BalanceError {
    #[prost(string, tag="1")]
    pub error_code: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub error_description: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct BankBalanceRequest {
    #[prost(string, optional, tag="2")]
    pub address: ::core::option::Option<::prost::alloc::string::String>,
    #[prost(string, tag="3")]
    pub denom: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct BankBalanceResponse {
    #[prost(string, optional, tag="1")]
    pub key_label: ::core::option::Option<::prost::alloc::string::String>,
    #[prost(string, optional, tag="2")]
    pub address: ::core::option::Option<::prost::alloc::string::String>,
    #[prost(string, tag="3")]
    pub denom: ::prost::alloc::string::String,
    #[prost(string, tag="4")]
    pub value: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct BankSendRequest {
    #[prost(string, tag="1")]
    pub to_addr: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub value: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub denom: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct BankSendResponse {
    #[prost(string, tag="1")]
    pub txhash: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct FindMetadataForDenomRequest {
    #[prost(string, tag="1")]
    pub denom: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct FindDenomMetadataResponse {
    #[prost(string, tag="1")]
    pub description: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub base: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub display: ::prost::alloc::string::String,
    #[prost(string, tag="4")]
    pub name: ::prost::alloc::string::String,
    #[prost(string, tag="5")]
    pub symbol: ::prost::alloc::string::String,
    #[prost(string, tag="6")]
    pub denom: ::prost::alloc::string::String,
    #[prost(uint32, tag="7")]
    pub exponent: u32,
    #[prost(string, repeated, tag="9")]
    pub aliases: ::prost::alloc::vec::Vec<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EchoRequest {
    #[prost(string, tag="1")]
    pub echo: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct EchoResponse {
    #[prost(string, tag="1")]
    pub echo: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GrantFeeBasicAllowanceRequest {
    ///   string granter = 1;
    #[prost(string, tag="2")]
    pub grantee: ::prost::alloc::string::String,
    ///   string allowance_denom = 3;
    #[prost(string, tag="4")]
    pub allowance_value: ::prost::alloc::string::String,
    #[prost(uint64, tag="5")]
    pub hours_to_expire: u64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GrantFeeBasicAllowanceResponse {
    #[prost(string, tag="1")]
    pub txhash: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RevokeFeeAllowanceRequest {
    ///   string granter = 1;
    #[prost(string, tag="2")]
    pub grantee: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RevokeFeeAllowanceResponse {
    #[prost(string, tag="1")]
    pub txhash: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetFeeBasicAllowanceRequest {
    ///   string granter = 1;
    #[prost(string, optional, tag="2")]
    pub grantee: ::core::option::Option<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetFeeBasicAllowanceResponse {
    #[prost(message, optional, tag="1")]
    pub fee_basic_grant: ::core::option::Option<GetFeeBasicGrant>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetFeeBasicGrant {
    #[prost(string, tag="1")]
    pub granter: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub grantee: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub allowance_denom: ::prost::alloc::string::String,
    #[prost(string, tag="4")]
    pub allowance_value: ::prost::alloc::string::String,
    #[prost(string, tag="5")]
    pub expiration: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RequestFeeBasicAllowanceRequest {
    ///   string allowance_denom = 1;
    #[prost(string, tag="2")]
    pub allowance_value: ::prost::alloc::string::String,
    #[prost(uint64, tag="3")]
    pub hours_to_expire: u64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RequestFeeBasicAllowanceResponse {
    #[prost(string, tag="1")]
    pub txhash: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct KafkaEventHeader {
    #[prost(string, tag="1")]
    pub key: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub value: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ProduceKafkaEventRequest {
    #[prost(string, optional, tag="1")]
    pub topic: ::core::option::Option<::prost::alloc::string::String>,
    #[prost(string, optional, tag="2")]
    pub key: ::core::option::Option<::prost::alloc::string::String>,
    #[prost(message, repeated, tag="3")]
    pub headers: ::prost::alloc::vec::Vec<KafkaEventHeader>,
    #[prost(string, tag="4")]
    pub payload: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ProduceKafkaEventResponse {
    #[prost(oneof="produce_kafka_event_response::Resp", tags="1, 2")]
    pub resp: ::core::option::Option<produce_kafka_event_response::Resp>,
}
/// Nested message and enum types in `ProduceKafkaEventResponse`.
pub mod produce_kafka_event_response {
    #[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Oneof)]
    pub enum Resp {
        #[prost(message, tag="1")]
        Status(super::OffsetPartition),
        #[prost(string, tag="2")]
        Error(::prost::alloc::string::String),
    }
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct OffsetPartition {
    #[prost(int32, tag="1")]
    pub partition: i32,
    #[prost(int64, tag="2")]
    pub offset: i64,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GenKeyRequest {
    #[prost(string, tag="1")]
    pub key_label: ::prost::alloc::string::String,
    #[prost(enumeration="KeyType", tag="2")]
    pub key_type: i32,
    #[prost(enumeration="CryptographAlgorithm", tag="3")]
    pub algorithm: i32,
    #[prost(bool, tag="4")]
    pub persistent: bool,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GenKeyResponse {
    #[prost(string, tag="1")]
    pub key_label: ::prost::alloc::string::String,
    #[prost(bool, tag="2")]
    pub persisted: bool,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetPubKeyRequest {
    #[prost(string, optional, tag="1")]
    pub key_label: ::core::option::Option<::prost::alloc::string::String>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetPubKeyResponse {
    #[prost(string, tag="1")]
    pub key_label: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub pub_key: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub acct_addr: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetMqMesssageFromQueueRequest {
    #[prost(string, tag="1")]
    pub queue_name: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetMqMesssageFromQueueResponse {
    #[prost(string, tag="1")]
    pub status: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub message: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct PostMqMessageToQueueRequest {
    #[prost(string, tag="1")]
    pub queue_name: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub message: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct PostMqMessageResponse {
    #[prost(string, tag="1")]
    pub status: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub ret_data: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct PostMqMessageToTopicRequest {
    #[prost(string, tag="1")]
    pub topic_string: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub message: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetTfConfigRequest {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetTfConfigResponse {
    #[prost(string, tag="1")]
    pub owner: ::prost::alloc::string::String,
    #[prost(bool, tag="2")]
    pub is_tf: bool,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetOwnerRequest {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetOwnerResponse {
    #[prost(string, tag="1")]
    pub address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetMasterMinterRequest {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetMasterMinterResponse {
    #[prost(string, tag="1")]
    pub address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetMinterControllerRequest {
    #[prost(string, tag="1")]
    pub controller: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub minter: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetMinterControllerResponse {
    #[prost(string, tag="1")]
    pub minter: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub controller: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetAllMinterControllersRequest {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetAllMinterControllersResponse {
    #[prost(message, repeated, tag="1")]
    pub minter_controllers: ::prost::alloc::vec::Vec<GetMinterControllerResponse>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetMintingDenomRequest {
    #[prost(string, tag="1")]
    pub denom: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetMintingDenomResponse {
    #[prost(string, tag="1")]
    pub denom: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetAllMintingDenomsRequest {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetAllMintingDenomsResponse {
    #[prost(message, repeated, tag="1")]
    pub minting_denoms: ::prost::alloc::vec::Vec<GetMintingDenomResponse>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetMintersRequest {
    #[prost(string, tag="1")]
    pub address: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub denom: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetMintersResponse {
    #[prost(string, tag="1")]
    pub address: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub allowance_denom: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub allowance_value: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetAllMintersRequest {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetAllMintersResponse {
    #[prost(message, repeated, tag="1")]
    pub minters: ::prost::alloc::vec::Vec<GetMintersResponse>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetBlacklisterRequest {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetBlacklisterResponse {
    #[prost(string, tag="1")]
    pub address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetPauserRequest {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetPauserResponse {
    #[prost(string, tag="1")]
    pub address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetBlacklistedRequest {
    #[prost(string, tag="1")]
    pub address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetBlacklistedResponse {
    #[prost(string, tag="1")]
    pub address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetAllBlacklistedRequest {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetAllBlacklistedResponse {
    #[prost(message, repeated, tag="1")]
    pub blacklisted: ::prost::alloc::vec::Vec<GetBlacklistedResponse>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetPausedRequest {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetPausedResponse {
    #[prost(bool, tag="1")]
    pub paused: bool,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetDenomMetadataRequest {
    #[prost(string, tag="1")]
    pub denom: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetDenomMetadataResponse {
    #[prost(message, optional, tag="1")]
    pub metadata: ::core::option::Option<DenomMetadata>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetAllDenomMetadataRequest {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct GetAllDenomMetadataResponse {
    #[prost(message, repeated, tag="1")]
    pub denom_metadata: ::prost::alloc::vec::Vec<GetDenomMetadataResponse>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct UpdateMasterMinterRequest {
    #[prost(string, tag="1")]
    pub address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct UpdateMasterMinterResponse {
    #[prost(string, tag="1")]
    pub txhash: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ConfigureMinterControllerRequest {
    #[prost(string, tag="1")]
    pub controller: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub minter: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ConfigureMinterControllerResponse {
    #[prost(string, tag="1")]
    pub txhash: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RemoveMinterControllerRequest {
    #[prost(string, tag="1")]
    pub controller: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub minter: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RemoveMinterControllerResponse {
    #[prost(string, tag="1")]
    pub txhash: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ConfigureMinterRequest {
    #[prost(string, tag="1")]
    pub address: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub allowance_denom: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub allowance_value: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct ConfigureMinterResponse {
    #[prost(string, tag="1")]
    pub txhash: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RemoveMinterRequest {
    #[prost(string, tag="1")]
    pub address: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub denom: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct RemoveMinterResponse {
    #[prost(string, tag="1")]
    pub txhash: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct UpdateBlacklisterRequest {
    #[prost(string, tag="1")]
    pub address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct UpdateBlacklisterResponse {
    #[prost(string, tag="1")]
    pub txhash: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct BlacklistRequest {
    #[prost(string, tag="1")]
    pub address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct BlacklistResponse {
    #[prost(string, tag="1")]
    pub txhash: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct UnblacklistRequest {
    #[prost(string, tag="1")]
    pub address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct UnblacklistResponse {
    #[prost(string, tag="1")]
    pub txhash: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct UpdatePauserRequest {
    #[prost(string, tag="1")]
    pub address: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct UpdatePauserResponse {
    #[prost(string, tag="1")]
    pub txhash: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct PauseRequest {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct PauseResponse {
    #[prost(string, tag="1")]
    pub txhash: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct UnpauseRequest {
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct UnpauseResponse {
    #[prost(string, tag="1")]
    pub txhash: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MintRequest {
    #[prost(string, tag="1")]
    pub address: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub denom: ::prost::alloc::string::String,
    #[prost(string, tag="3")]
    pub value: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct MintResponse {
    #[prost(string, tag="1")]
    pub txhash: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct BurnRequest {
    #[prost(string, tag="1")]
    pub denom: ::prost::alloc::string::String,
    #[prost(string, tag="2")]
    pub value: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct BurnResponse {
    #[prost(string, tag="1")]
    pub txhash: ::prost::alloc::string::String,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SetDenomMetadataRequest {
    #[prost(message, optional, tag="1")]
    pub metadata: ::core::option::Option<DenomMetadata>,
}
#[allow(clippy::derive_partial_eq_without_eq)]
#[derive(Clone, PartialEq, ::prost::Message)]
pub struct SetDenomMetadataResponse {
    #[prost(string, tag="1")]
    pub txhash: ::prost::alloc::string::String,
}
include!("wfdc2.wallet.v1.serde.rs");
include!("wfdc2.wallet.v1.tonic.rs");
// @@protoc_insertion_point(module)