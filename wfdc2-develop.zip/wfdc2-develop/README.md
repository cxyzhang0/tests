# WFDC V2
It ports and rewrites the R3 Corda based Wells Fargo Digital Cash (WFDC) to run on Cosmos SDK based blockchains. We use V2 to distinguish it from the Corda version even though it attempts to match feature by feature including interfaces. The ideal product is one replacing the current production Corda network without any breaking impact on GBF.  
## cw-contracts
crates for cosmwasm smart contracts to perform functions similar to the Corda flows.
## wallet-svc
crate to build cosmwasm smart contract transactions and access HSM (and/or MPC in the future) keys to sign them, and use gRPC client to submit them to the blockchain. It provides gRPC (and REST) interface. It may have embedded MQ listener and sender to interface with the GBFDLT queues, similar to the current Spring interface layer.

## apply linting
```shell
# Optimize Imports for the whole workspace: right-click on the workspace root folder in RustRover IDE and select Optimize Imports.
# unfortunately, the above does not remove unused imports.

# check the whole workspace. it will show unused imports, among other things.
# manually remove unused imports.
cargo check --workspace --features=p11hsm --no-default-features 
cargo check --workspace --features=tsstrio --no-default-features 

# Reformat the whole workspace: right-click on the workspace root folder in RustRover IDE and select Reformat Code.
# Or run the following commands.
cargo fmt --all --check # it will display the proposed changes.
cargo fmt --all

# clippy the whole workspace; review recommendations and make appropriate changes.
cargo clippy --workspace
# or clippy an individual package
cargo clippy -p aurum
cargo clippy -p tokenfactory
cargo clippy -p wallet_svc --no-deps

```

## Notes:
* Mutex: tokio suggests using futures::lock::Mutex instead of std::sync::Mutex. We attempted to replace the latter with the former in wallet_svc - in wallet_svc crate proper, it is doable but in dependencies pkcs11 (sdk) and cosmos-pkcs11, the std version is used. We need to look deeper there.
>* One thing we can do is since tsstrio feature does not depend on pkcs11, we use futures' Mutex for it.