/*
use cosmwasm_schema::{cw_serde, QueryResponses};
use cosmwasm_std::{Coin, CustomQuery};
// use cosmwasm_std::{DenomMetadataResponse, AllDenomMetadataResponse};

#[cw_serde]
pub enum FactoryQuery {
    Tf(TokenfactoryQuery),
    Ftf(TokenfactoryQuery),
    /*
    We use BankQuery as stop-gap solution until we upgrade wasmd (wasmvm).
    Our current wasmvm 1.2.1 BankQuery does not have denom metadata queries.
    v1.3.0+ will have them.
     */
    Bank(BankQuery),
    Feegrant(FeegrantQuery),
}
#[cw_serde]
#[derive(QueryResponses)]
pub enum TokenfactoryQuery {
    #[returns(ParamsResponse)]
    Params {},

    #[returns(OwnerResponse)]
    Owner {},

    #[returns(MasterMinterResponse)]
    MasterMinter {},

    #[returns(MinterControllerResponse)]
    MinterController { controller: String, minter: String },

    #[returns(AllMinterControllersResponse)]
    AllMinterControllers {},

    #[returns(MintingDenomResponse)]
    MintingDenom { denom: String },

    #[returns(AllMintingDenomsResponse)]
    AllMintingDenoms {},

    #[returns(MintersResponse)]
    Minters { address: String, denom: String },

    #[returns(AllMintersResponse)]
    AllMinters {},

    #[returns(BlacklisterResponse)]
    Blacklister {},

    #[returns(PauserResponse)]
    Pauser {},

    #[returns(BlacklistedResponse)]
    Blacklisted { address: String },

    #[returns(AllBlacklistedResponse)]
    AllBlacklisted {},

    #[returns(PausedResponse)]
    Paused {},
}

#[cw_serde]
#[derive(QueryResponses)]
pub enum BankQuery {
    // denom is the base denom
    #[returns(DenomMetadataResponse)]
    DenomMetadata { denom: String },

    #[returns(AllDenomMetadataResponse)]
    AllDenomMetadata {},

    #[returns(FindDenomMetadataResponse)]
    FindDenomMetadata { base_denom: String, denom: String },

    #[returns(FindDenomMetadataResponse)]
    // denom is any denom, not just base denom
    FindMetadataForDenom { denom: String },
}

#[cw_serde]
#[derive(QueryResponses)]
pub enum FeegrantQuery {
    #[returns(FeeBasicAllowanceResponse)]
    FeeBasicAllowance { granter: String, grantee: String },
}
/*
#[cw_serde]
#[derive(QueryResponses)]
pub enum FiatTokenfactoryQuery {
    #[returns(ParamsResponse)]
    Params {},

    #[returns(OwnerResponse)]
    Owner {},

    #[returns(MasterMinterResponse)]
    MasterMinter {},

    #[returns(MinterControllerResponse)]
    MinterController { address: String },

    #[returns(AllMinterControllersResponse)]
    AllMinterControllers {},

    #[returns(MintingDenomResponse)]
    MintingDenom {},

    #[returns(MintersResponse)]
    Minters { address: String },

    #[returns(AllMintersResponse)]
    AllMinters {},

    #[returns(BlacklisterResponse)]
    Blacklister {},

    #[returns(PauserResponse)]
    Pauser {},

    #[returns(BlacklistedResponse)]
    Blacklisted { address: String },

    #[returns(AllBlacklistedResponse)]
    AllBlacklisted {},

    #[returns(PausedResponse)]
    Paused {},
}
*/
impl CustomQuery for FactoryQuery {}
impl cosmwasm_std::CustomMsg for FactoryQuery {}

// TODO: Are the following two impl for TokenfactoryQuery necessary?
//  No such impl for BankQuery and FeegrantQuery.
impl CustomQuery for TokenfactoryQuery {}
impl cosmwasm_std::CustomMsg for TokenfactoryQuery {}

impl CustomQuery for BankQuery {}
impl cosmwasm_std::CustomMsg for BankQuery {}

impl CustomQuery for FeegrantQuery {}
impl cosmwasm_std::CustomMsg for FeegrantQuery {}

// impl CustomQuery for FiatTokenfactoryQuery {}
// impl cosmwasm_std::CustomMsg for FiatTokenfactoryQuery {}
#[cw_serde]
pub struct ParamsResponse {
    pub params: Option<String>,
}

#[cw_serde]
pub struct OwnerResponse {
    pub address: String,
}
#[cw_serde]
pub struct MasterMinterResponse {
    pub address: String,
}
#[cw_serde]
pub struct MinterControllerResponse {
    pub minter: String,
    pub controller: String,
}
#[cw_serde]
pub struct AllMinterControllersResponse {
    pub minter_controllers: Vec<MinterControllerResponse>,
}

#[cw_serde]
pub struct MintingDenomResponse {
    pub denom: String,
}

#[cw_serde]
pub struct AllMintingDenomsResponse {
    pub minting_denoms: Vec<MintingDenomResponse>,
}

#[cw_serde]
pub struct MintersResponse {
    pub address: String,
    pub allowance: Coin,
}
#[cw_serde]
pub struct AllMintersResponse {
    pub minters: Vec<MintersResponse>,
}
#[cw_serde]
pub struct BlacklisterResponse {
    pub address: String,
}
#[cw_serde]
pub struct PauserResponse {
    pub address: String,
}
#[cw_serde]
pub struct BlacklistedResponse {
    pub address: String,
}
#[cw_serde]
pub struct AllBlacklistedResponse {
    pub blacklisted: Vec<BlacklistedResponse>,
}
#[cw_serde]
pub struct PausedResponse {
    pub paused: bool,
}

/*
DenomMetadataResponse and AllDenomMetadataResponse, and DenomMetadata and DenomUnit
are based on cosmwasm_std::{DenomMetadataResponse, AllDenomMetadataResponse}.
We make these changes to be consistent with the wasm bindings:
no pagination
remove uri and uri_hash because they are not used in the wasm bindings.
also use cw_serde instead.
 */
#[cw_serde]
pub struct DenomMetadataResponse {
    pub metadata: DenomMetadata,
}

#[cw_serde]
pub struct AllDenomMetadataResponse {
    pub metadatas: Vec<DenomMetadata>,
}

#[cw_serde]
pub struct FindDenomMetadataResponse {
    pub description: String,
    pub base: String,
    pub display: String,
    pub name: String,
    pub symbol: String,
    pub denom: String,
    pub exponent: u32,
    pub aliases: Vec<String>,
}

// this is copied from cosmos.bank.v1beta1 because the original does not implement deserialize
// except that we add Option<...> for uri and uri_hash
#[cw_serde]
pub struct DenomMetadata {
    pub description: String,
    /// denom_units represents the list of DenomUnit's for a given coin
    pub denom_units: Vec<DenomUnit>,
    /// base represents the base denom (should be the DenomUnit with exponent = 0).
    pub base: String,
    /// display indicates the suggested denom that should be
    /// displayed in clients.
    pub display: String,
    /// name defines the name of the token (eg: Cosmos Atom)
    ///
    /// Since: cosmos-sdk 0.43
    pub name: String,
    /// symbol is the token symbol usually shown on exchanges (eg: ATOM). This can
    /// be the same as the display.
    ///
    /// Since: cosmos-sdk 0.43
    pub symbol: String,
    /// URI to a document (on or off-chain) that contains additional information. Optional.
    ///
    /// Since: cosmos-sdk 0.46
    pub uri: Option<String>,
    /// URIHash is a sha256 hash of a document pointed by URI. It's used to verify that
    /// the document didn't change. Optional.
    ///
    /// Since: cosmos-sdk 0.46
    pub uri_hash: Option<String>,
}

// this is copied from cosmos.bank.v1beta1 because the original does not implement deserialize
// except that we add Option<> for exponent and aliases
#[cw_serde]
pub struct DenomUnit {
    /// denom represents the string name of the given denom unit (e.g uatom).
    pub denom: String,
    /// exponent represents power of 10 exponent that one must
    /// raise the base_denom to in order to equal the given DenomUnit's denom
    /// 1 denom = 10^exponent base_denom
    /// (e.g. with a base_denom of uatom, one can create a DenomUnit of 'atom' with
    /// exponent = 6, thus: 1 atom = 10^6 uatom).
    pub exponent: Option<u32>,
    /// aliases is a list of string aliases for the given denom
    pub aliases: Option<Vec<String>>,
}

#[cw_serde]
pub struct FeeBasicAllowanceResponse {
    pub allowance: FeeBasicGrant,
}

#[cw_serde]
pub struct FeeBasicGrant {
    pub granter: String,
    pub grantee: String,
    pub allowance: Coin,
    pub expiration: String,
}
*/