# scripts for aurum smart contract
## build wasm
```shell
cd aurum
# note: rust 1.8.0+ will produce large wasm file (over 1.2MB with optimized version over 1MB)
# note:  so use 1.7.5 to build wasm whose size is about 446KB. 
RUSTFLAGS='-C link-arg=-s' cargo wasm -v

# optimize wasm to produce aurum_optimized.wasm and also to support 1.70.0+ build
wasm-opt -Os --signext-lowering ../../../target/wasm32-unknown-unknown/release/aurum.wasm -o ../../../target/wasm32-unknown-unknown/release/aurum_optimized.wasm
# this is more optimized that the above. similar to cosmwasm/workspace-optimizer
wasm-opt -Oz --strip-debug \
  ../../../target/wasm32-unknown-unknown/release/aurum.wasm \
  -o ../../../target/wasm32-unknown-unknown/release/aurum_optimized.wasm
  
# validate aurum_optimized.wasm will pass
cosmwasm-check ../../../target/wasm32-unknown-unknown/release/aurum_optimized.wasm --available-capabilities "tokenfactory, fiattokenfactory, iterator, staking, cosmwasm_1_1, cosmwasm_1_2, cosmwasm_1_3" 

# schema
cargo run schema
```

## Deploy on noblefork chain
See https://github.com/wfblockchain/noblefork/blob/main/scripts_aurum.md .