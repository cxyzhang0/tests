use cosmwasm_std::{
    coin, to_json_binary, Deps, DepsMut, Env, MessageInfo, PageRequest, Response, StdResult,
    WasmMsg,
};
use cw2::set_contract_version;

use tokenfactory::msg::QueryMsg as TFQueryMsg;
use tokenfactory::msg::TokenfactoryContractMsg::{Burn, Mint};
use tokenfactory::{
    AllDenomMetadataResponse, BankQuery, FindDenomMetadataResponse, MintingDenomResponse,
    TokenfactoryQuery,
};

use crate::error::ContractError;
use crate::msg::{ExecuteMsg, InstantiateMsg};
use crate::state::{Config, PaymentState, CONFIG, PAYMENT_STATE};

use super::{MessageType, PaymentRequest, PaymentResponse, PaymentType};

const CONTRACT_NAME: &str = "crates.io:wfdc2-aurum";
const CONTRACT_VERSION: &str = env!("CARGO_PKG_VERSION");

#[allow(unused_imports)]
use cosmwasm_std::entry_point;

#[cfg_attr(not(feature = "library"), entry_point)]
#[allow(unused)]
pub fn instantiate(
    deps: DepsMut,
    _env: Env,
    info: MessageInfo,
    msg: InstantiateMsg,
) -> StdResult<Response> {
    set_contract_version(deps.storage, CONTRACT_NAME, CONTRACT_VERSION)?;
    
    let config = Config {
        owner: info.sender.to_owned(),
        tf_address: msg.tf_address.to_owned(),
    };

    CONFIG.save(deps.storage, &config)?;

    Ok(Response::new()
        .add_attribute(format!("{}_{}", crate::types::PACKAGE_NAME, "action"), "instantiate")
        .add_attribute(format!("{}_{}", crate::types::PACKAGE_NAME, "owner"), info.sender)
        .add_attribute(format!("{}_{}", crate::types::PACKAGE_NAME, "tf_address"), msg.tf_address))
}

#[cfg_attr(not(feature = "library"), entry_point)]
#[allow(unused)]
pub fn execute(
    deps: DepsMut,
    env: Env,
    info: MessageInfo,
    msg: ExecuteMsg,
) -> Result<Response, ContractError> {
    match msg {
        ExecuteMsg::UpdateMember { req } => exec::update_member(deps, env, info, req),
        ExecuteMsg::Fund { req } => exec::fund(deps, env, info, req),
        ExecuteMsg::Pay { req } => exec::pay(deps, env, info, req),
        ExecuteMsg::Defund { req } => exec::defund(deps, env, info, req),
        ExecuteMsg::ValidateMinterSender {} => exec::validate_minter_sender_tx(deps, env, info),
        ExecuteMsg::UpdateTxhash {
            tracking_id,
            txhash,
        } => exec::update_txhash(deps, env, info, tracking_id, txhash),
    }
}

mod exec {
    use cosmwasm_std::{Addr, BankMsg, Coin, CosmosMsg, Event};

    use tokenfactory::{AllMintersResponse, MintersResponse, TokenfactoryQuery};

    use crate::state::{to_base_amount, MemberState, MEMBER_STATE};

    use super::*;

    pub(super) fn update_member(
        deps: DepsMut,
        _env: Env,
        _info: MessageInfo,
        req: MemberState,
    ) -> Result<Response, ContractError> {
        validate_minter_sender(&deps, _env, _info)?;

        let addr = deps.api.addr_validate(req.addr.as_ref())?;
        let member_state = MemberState {
            id: req.id.to_owned(),
            addr,
            pubkey: req.pubkey.to_owned(),
            grpc: req.grpc.to_owned(),
        };
        MEMBER_STATE.save(deps.storage, req.id.to_owned(), &member_state)?;

        Ok(Response::new()
            .add_attribute(format!("{}_{}", crate::types::PACKAGE_NAME, "action"), "add_member")
            .add_attribute(format!("{}_{}", crate::types::PACKAGE_NAME, "id"), req.id)
            .add_attribute(format!("{}_{}", crate::types::PACKAGE_NAME, "addr"), req.addr)
            .add_attribute(format!("{}_{}", crate::types::PACKAGE_NAME, "pubkey"), req.pubkey)
            .add_attribute(format!("{}_{}", crate::types::PACKAGE_NAME, "grpc"), req.grpc))
    }
    
    pub(super) fn fund(
        deps: DepsMut,
        env: Env,
        info: MessageInfo,
        req: PaymentRequest,
    ) -> Result<Response, ContractError> {
        let config = CONFIG.load(deps.storage)?;

        let metadata = lookup_metadata_for_denom_by_wasm_smart(
            &deps.as_ref(),
            req.currency.to_owned(),
            &config,
        )?;
        // make sure the minting denom is what is in req
        let base_denom = validate_minting_denom(&deps.as_ref(), &config, metadata.base)?;

        // originator must be a member
        let originator_id = req.originating_party.to_owned().unwrap().id();
        let originator_member = MEMBER_STATE.load(deps.storage, originator_id)?;
        let originator = originator_member.addr;
        // sender must be the originator
        if info.sender != originator {
            return Err(ContractError::Unauthorized {
                sender: info.sender,
            });
        }
        // make sure the sender is the minter
        // TODO: the minter check below may not be necessary since tokenfactory is the ultimate authority
        get_minter(&deps, info.sender.to_owned(), base_denom.to_string())?;

        // beneficiary address
        let beneficiary_id = req.beneficiary_party.to_owned().unwrap().id();
        let beneficiary_member = MEMBER_STATE.load(deps.storage, beneficiary_id)?;
        let beneficiary = beneficiary_member.addr;
        // beneficiary cannot be the originator
        if beneficiary == originator {
            return Err(ContractError::Unauthorized {
                sender: beneficiary.to_owned(),
            });
        }

        let base_amount = to_base_amount(req.amount, metadata.exponent);

        // message_type MT202
        validate_message_type(&req, MessageType::Mt202)?;

        // payment_type Funding
        validate_payment_type(&req, PaymentType::Funding)?;

        // uniqueness check of tracking_id
        validate_unique_tracking_id(&deps, &req)?;

        let payment_state = make_payment_state(&env, &info, req.to_owned());
        PAYMENT_STATE().save(deps.storage, req.tracking_id.to_owned(), &payment_state)?;

        // tf mint msg
        let mint_msg = &tokenfactory::msg::ExecuteMsg::Tf(Mint {
            orig_sender: Some(info.sender.to_string()),
            address: beneficiary.to_string(),
            denom: base_denom.to_owned(),
            value: base_amount.to_string(),
        });
        let msg = WasmMsg::Execute {
            contract_addr: config.tf_address.to_string(),
            msg: to_json_binary(&mint_msg)?,
            funds: vec![],
        };
        
        let resp = build_response_with_attributes(
            "fund",
            &req.tracking_id,
            &originator.to_string(),
            &beneficiary.to_string(),
            &base_amount.to_string(),
            &base_denom,
        );
        
        /*
        custom event wasm-aurum cannot be used in websocket query filter 
        probably due to the hyphen.
         */
        // let event = build_event(
        //     "fund",
        //     &req.tracking_id,
        //     &originator.to_string(),
        //     &beneficiary.to_string(),
        //     &base_amount.to_string(),
        //     &base_denom,
        // );

        Ok(resp
            .add_message(msg)
            // .add_event(event)
        )
    }

    pub(super) fn get_minter(deps: &DepsMut, addr: Addr, denom: String) -> Result<MintersResponse, ContractError> {
        let config = CONFIG.load(deps.storage)?;

        // make sure the sender is the minter
        let minters_query = TFQueryMsg::Tf(TokenfactoryQuery::Minters { 
            address: addr.to_string(), 
            denom: denom.to_owned()
        });

        let resp: StdResult<MintersResponse> = deps
            .querier
            .query_wasm_smart(config.tf_address.to_string(), &minters_query);
        
        resp.map_err(|_| ContractError::UnauthorizedMinterDenom {
            sender: addr,
            denom,
        })
    }

    pub(super) fn validate_minter(deps: &DepsMut, addr: Addr) -> Result<(), ContractError> {
        let config = CONFIG.load(deps.storage)?;

        // make sure the sender is the minter
        let minters_query = TFQueryMsg::Tf(TokenfactoryQuery::AllMinters {});

        let resp: StdResult<AllMintersResponse> = deps
            .querier
            .query_wasm_smart(config.tf_address.to_string(), &minters_query);

        if resp.is_err() {
            Err(ContractError::UnauthorizedMinter { sender: addr })
        } else {
            let minters = resp?.minters;
            if minters
                .iter()
                .find(|minter| minter.address == addr.to_string())
                .is_none()
            {
                return Err(ContractError::UnauthorizedMinter {
                    sender: addr,
                });
            }
            
            Ok(())
        }
    }

    pub(super) fn validate_minter_sender(
        deps: &DepsMut,
        _env: Env,
        info: MessageInfo,
    ) -> Result<(), ContractError> {
        validate_minter(deps, info.sender)
    }

    /// validate that the sender is a minter
    /// it is no-op either way but intended for testing in the mock env how cross-contract
    /// queries work, especially the target contract query is custom.
    pub(super) fn validate_minter_sender_tx(
        deps: DepsMut,
        env: Env,
        info: MessageInfo,
    ) -> Result<Response, ContractError> {
        validate_minter_sender(&deps, env, info)?;

        Ok(Response::new().add_attribute(format!("{}_{}", crate::types::PACKAGE_NAME, "action"), "validate_minter_sender"))
    }

    pub(super) fn pay(
        deps: DepsMut,
        env: Env,
        info: MessageInfo,
        req: PaymentRequest,
    ) -> Result<Response, ContractError> {
        let config = CONFIG.load(deps.storage)?;

        // make sure the minting denom is what is in req
        let metadata = lookup_metadata_for_denom_by_wasm_smart(
            &deps.as_ref(),
            req.currency.to_owned(),
            &config,
        )?;
        // TODO: the minting denom check below may not be necessary since tokenfactory is the ultimate authority
        let base_denom = validate_minting_denom(&deps.as_ref(), &config, metadata.base)?;

        // originator must be a member
        let originator_id = req.originating_party.to_owned().unwrap().id();
        let originator_member = MEMBER_STATE.load(deps.storage, originator_id)?;
        let originator = originator_member.addr;
        // sender must be the originator
        if info.sender != originator {
            return Err(ContractError::Unauthorized {
                sender: info.sender,
            });
        }
        // originator cannot be the minter
        if get_minter(&deps, originator.to_owned(), base_denom.to_string()).is_ok() {
            return Err(ContractError::Unauthorized {
                sender: originator.to_owned(),
            });
        }

        // beneficiary address
        let beneficiary_id = req.beneficiary_party.to_owned().unwrap().id();
        let beneficiary_member = MEMBER_STATE.load(deps.storage, beneficiary_id)?;
        let beneficiary = beneficiary_member.addr;
        // beneficiary cannot be the originator
        if beneficiary == originator {
            return Err(ContractError::Unauthorized {
                sender: beneficiary.to_owned(),
            });
        }
        // beneficiary cannot be the minter
        if get_minter(&deps, beneficiary.to_owned(), base_denom.to_string()).is_ok() {
            return Err(ContractError::Unauthorized {
                sender: beneficiary.to_owned(),
            });
        }

        // coin
        let base_amount = to_base_amount(req.amount, metadata.exponent);
        let coin = validate_paid_amount(&info, base_amount, &base_denom)?;

        // message_type MT103
        validate_message_type(&req, MessageType::Mt103)?;

        // payment_type Payment
        validate_payment_type(&req, PaymentType::Payment)?;

        // uniqueness check of tracking_id
        validate_unique_tracking_id(&deps, &req)?;

        let payment_state = make_payment_state(&env, &info, req.to_owned());
        PAYMENT_STATE().save(deps.storage, req.tracking_id.to_owned(), &payment_state)?;

        let bank_msg = BankMsg::Send {
            to_address: beneficiary.to_string(),
            amount: vec![coin],
        };

        let resp = build_response_with_attributes(
            "pay",
            &req.tracking_id,
            &originator.to_string(),
            &beneficiary.to_string(),
            &base_amount.to_string(),
            &base_denom,
        );

        /*
        custom event wasm-aurum cannot be used in websocket query filter 
        probably due to the hyphen.
         */
        // let event = build_event(
        //     "pay",
        //     &req.tracking_id,
        //     &originator.to_string(),
        //     &beneficiary.to_string(),
        //     &base_amount.to_string(),
        //     &base_denom,
        // );

        Ok(resp
            .add_message(bank_msg)
            // .add_event(event)
        )
    }

    pub(super) fn defund(
        deps: DepsMut,
        env: Env,
        info: MessageInfo,
        req: PaymentRequest,
    ) -> Result<Response, ContractError> {
        let config = CONFIG.load(deps.storage)?;

        let metadata = lookup_metadata_for_denom_by_wasm_smart(
            &deps.as_ref(),
            req.currency.to_owned(),
            &config,
        )?;
        // make sure the minting denom is what is in req
        // TODO: the minting denom check below may not be necessary since tokenfactory is the ultimate authority
        let base_denom = validate_minting_denom(&deps.as_ref(), &config, metadata.base)?;

        // originator must be a member
        let originator_id = req.originating_party.to_owned().unwrap().id();
        let originator_member = MEMBER_STATE.load(deps.storage, originator_id)?;
        let originator = originator_member.addr;
        // sender must be the originator
        if info.sender != originator {
            return Err(ContractError::Unauthorized {
                sender: info.sender,
            });
        }
        // originator cannot be the minter
        if get_minter(&deps, originator.to_owned(), base_denom.to_string()).is_ok() {
            return Err(ContractError::Unauthorized {
                sender: originator.to_owned(),
            });
        }
        // beneficiary address
        let beneficiary_id = req.beneficiary_party.to_owned().unwrap().id();
        let beneficiary_member = MEMBER_STATE.load(deps.storage, beneficiary_id)?;
        let beneficiary = beneficiary_member.addr;
        // beneficiary cannot be the originator
        if beneficiary == originator {
            return Err(ContractError::Unauthorized {
                sender: beneficiary.to_owned(),
            });
        }
        // make sure beneficiary is the minter
        get_minter(&deps, beneficiary.to_owned(), base_denom.to_string())?;
        
        // coin
        let base_amount = to_base_amount(req.amount, metadata.exponent);
        let coin = validate_paid_amount(&info, base_amount, &base_denom)?;

        // message_type MT202
        validate_message_type(&req, MessageType::Mt202)?;

        // payment_type Payment
        validate_payment_type(&req, PaymentType::Defunding)?;

        // uniqueness check of tracking_id
        validate_unique_tracking_id(&deps, &req)?;

        let payment_state = make_payment_state(&env, &info, req.to_owned());
        PAYMENT_STATE().save(deps.storage, req.tracking_id.to_owned(), &payment_state)?;

        let bank_msg = BankMsg::Send {
            to_address: beneficiary.to_string(),
            amount: vec![coin],
        };

        // for burn, we set orig_sender to the beneficiary which is the minter
        let burn_msg = &tokenfactory::msg::ExecuteMsg::Tf(Burn {
            orig_sender: Some(beneficiary.to_string()),
            denom: base_denom.to_owned(),
            value: base_amount.to_string(),
        });
        let wasm_msg = WasmMsg::Execute {
            contract_addr: config.tf_address.to_string(),
            msg: to_json_binary(&burn_msg)?,
            funds: vec![],
        };

        let msgs: Vec<CosmosMsg> = vec![bank_msg.into(), wasm_msg.into()];

        let resp = build_response_with_attributes(
            "defund",
            &req.tracking_id,
            &originator.to_string(),
            &beneficiary.to_string(),
            &base_amount.to_string(),
            &base_denom,
        );

        /*
        custom event wasm-aurum cannot be used in websocket query filter 
        probably due to the hyphen.
         */
        // let event = build_event(
        //     "defund",
        //     &req.tracking_id,
        //     &originator.to_string(),
        //     &beneficiary.to_string(),
        //     &base_amount.to_string(),
        //     &base_denom,
        // );

        Ok(resp
            .add_messages(msgs)
            // .add_event(event)
        )
    }

    pub(super) fn update_txhash(
        deps: DepsMut,
        _env: Env,
        _info: MessageInfo,
        tracking_id: String,
        txhash: String,
    ) -> Result<Response, ContractError> {
        let mut payment_state = PAYMENT_STATE().load(deps.storage, tracking_id.clone())?;
        payment_state.txhash = Some(txhash.clone());
        PAYMENT_STATE().save(deps.storage, tracking_id.clone(), &payment_state)?;
        
        Ok(Response::new()
            .add_attribute(format!("{}_{}", crate::types::PACKAGE_NAME, "action"), "update_txhash")
            .add_attribute(format!("{}_{}", crate::types::PACKAGE_NAME, "tracking_id"), tracking_id)
            .add_attribute(format!("{}_{}", crate::types::PACKAGE_NAME, "txhash"), txhash))
    }

    // response with consistent aurum attributes
    // for fund, pay and defund
    fn build_response_with_attributes(
        action: &str, 
        tracking_id: &str,
        originator: &str,
        beneficiary: &str,
        amount: &str,
        denom: &str,
    ) -> Response {
        Response::new()
            .add_attribute(format!("{}_{}", crate::types::PACKAGE_NAME, "action"), action)
            .add_attribute(format!("{}_{}", crate::types::PACKAGE_NAME, "tracking_id"), tracking_id)
            .add_attribute(format!("{}_{}", crate::types::PACKAGE_NAME, "originator"), originator)
            .add_attribute(format!("{}_{}", crate::types::PACKAGE_NAME, "beneficiary"), beneficiary)
            .add_attribute(format!("{}_{}", crate::types::PACKAGE_NAME, "amount"), amount)
            .add_attribute(format!("{}_{}", crate::types::PACKAGE_NAME, "denom"), denom)
    }

    // custom aurum event with consistent attributes
    // for fund, pay and defund
    // note: it is not used because the published event type wasm-aurum cannot be used in websocket query filter
    // probably due to the hyphen.
    // instead, we use wasm event type with attribute keys prefixed with aurum, see build_response_with_attributes(...)
    #[allow(dead_code)]
    fn build_event(
        action: &str,
        tracking_id: &str,
        originator: &str,
        beneficiary: &str,
        amount: &str,
        denom: &str,
    ) -> Event {
        Event::new(crate::types::PACKAGE_NAME)
            .add_attribute("action", action)
            .add_attribute("tracking_id", tracking_id)
            .add_attribute("originator", originator)
            .add_attribute("beneficiary", beneficiary)
            .add_attribute("amount", amount)
            .add_attribute("denom", denom)
    }

    fn validate_paid_amount(
        info: &MessageInfo,
        base_amount: u128,
        minting_denom: &String,
    ) -> Result<Coin, ContractError> {
        let paid_amount = cw_utils::must_pay(info, minting_denom)?.u128();
        if paid_amount != base_amount {
            return Err(ContractError::InvalidAmount {
                expected: paid_amount,
                got: base_amount,
            });
        }
        Ok(coin(paid_amount, minting_denom.to_owned()))
    }

    fn validate_message_type(
        req: &PaymentRequest,
        expected: MessageType,
    ) -> Result<(), ContractError> {
        // message_type MT202
        if MessageType::from_str_name(req.message_type.as_str()) != Some(expected.to_owned()) {
            return Err(ContractError::InvalidMessageType {
                expected: expected.as_str_name().to_string(),
                got: req.message_type.to_owned(),
            });
        }
        Ok(())
    }

    fn validate_payment_type(
        req: &PaymentRequest,
        expected: PaymentType,
    ) -> Result<(), ContractError> {
        // payment_type Payment
        if PaymentType::from_str_name(req.payment_type.as_str()) != Some(expected.to_owned()) {
            return Err(ContractError::InvalidPaymentType {
                expected: expected.as_str_name().to_string(),
                got: req.payment_type.to_owned(),
            });
        }
        Ok(())
    }

    fn validate_minting_denom(
        deps: &Deps,
        config: &Config,
        base_denom: String,
    ) -> Result<String, ContractError> {
        let minting_denom = get_minting_denom(deps, config, base_denom.to_owned())?;
        if minting_denom != base_denom {
            return Err(ContractError::InvalidCurrency {
                expected: minting_denom,
                got: base_denom,
            });
        }
        Ok(minting_denom)
    }

    fn validate_unique_tracking_id(
        deps: &DepsMut,
        req: &PaymentRequest,
    ) -> Result<(), ContractError> {
        if PAYMENT_STATE().has(deps.storage, req.tracking_id.clone()) {
            return Err(ContractError::TrackingIdExists {
                tracking_id: req.tracking_id.clone(),
            });
        }

        Ok(())
    }

    fn make_payment_state(
        env: &Env,
        _info: &MessageInfo,
        req: PaymentRequest,
    ) -> PaymentState {
        // PaymentResponse and PaymentState
        let mut payment_resp: PaymentResponse = req.into();
        payment_resp.entry_date_time = env.block.time.seconds().to_string();

        PaymentState {
            resp: payment_resp,
            txhash: None,
        }
    }
}

/// validate the provided base_denom is indeed a minting denom. if yes, return it.
pub(crate) fn get_minting_denom(deps: &Deps, config: &Config, base_denom: String) -> Result<String, ContractError> {
    let minting_demon_query = TFQueryMsg::Tf(TokenfactoryQuery::MintingDenom { denom: base_denom });
    let resp: StdResult<MintingDenomResponse> = deps
        .querier
        .query_wasm_smart(config.tf_address.to_string(), &minting_demon_query);
    if resp.is_err() {
        return Err(ContractError::MintingDenomNotFound {});
    }
    let minting_denom = resp?.denom;
    Ok(minting_denom)
}

// lookup the base denom corresponding to currency
// return (base denom, exponent of the currency)
// NOTE: this fn uses query_all_denom_metadata which is from coswasm_1_3.
// NOTE: wasmvm 1.2.1 does not support query_all_denom_metadata.
pub(crate) fn _lookup_denom(deps: &Deps, currency: String) -> Result<(String, u32), ContractError> {
    let metadata_list = deps.querier.query_all_denom_metadata(PageRequest {
        key: None,
        limit: 0,
        reverse: false,
    })?;
    for metadata in metadata_list.metadata {
        if let Some(u) = metadata
            .denom_units
            .iter()
            .find(|unit| unit.denom == currency)
        {
            return Ok((metadata.base, u.exponent));
        }
    }
    Err(ContractError::BaseDenomNotFound { currency })
}

// lookup the denom metadata corresponding to currency
// NOTE: this uses query by wasm binding
// This is the optimized version of lookup the denom metadata for any denom
pub fn lookup_metadata_for_denom_by_wasm_smart(
    deps: &Deps,
    currency: String,
    config: &Config,
) -> Result<FindDenomMetadataResponse, ContractError> {
    let q = TFQueryMsg::Bank(BankQuery::FindMetadataForDenom {
        denom: currency.to_owned(),
    });

    let resp: StdResult<FindDenomMetadataResponse> = deps
        .querier
        .query_wasm_smart(config.tf_address.to_string(), &q);
    if resp.is_err() {
        return Err(ContractError::BaseDenomNotFound { currency });
    }
    Ok(resp.unwrap())
}

#[deprecated(note = "use lookup_metadata_for_denom_by_wasm_smart")]
// lookup the base denom corresponding to currency
// return (base denom, exponent of the currency)
// NOTE: this uses query by wasm binding
pub fn _lookup_denom_by_wasm_smart(
    deps: &Deps,
    currency: String,
    config: &Config,
) -> Result<(String, u32), ContractError> {
    let q = TFQueryMsg::Bank(BankQuery::AllDenomMetadata {});
    let resp: StdResult<AllDenomMetadataResponse> = deps
        .querier
        .query_wasm_smart(config.tf_address.to_string(), &q);
    if resp.is_err() {
        return Err(ContractError::MintingDenomNotFound {});
    }
    let metadata_list = resp.unwrap().metadatas;

    for metadata in metadata_list {
        if let Some(u) = metadata
            .denom_units
            .iter()
            .find(|unit| unit.denom == currency)
        {
            return Ok((metadata.base, u.exponent.unwrap_or(0)));
            // return Ok((metadata.base, u.exponent.or(Some(0)).unwrap()));
        }
    }
    Err(ContractError::BaseDenomNotFound { currency })
}

// lookup the exponent of the currency
// NOTE: wasmvm 1.2.1 does not support query_denom_metadata.
pub(crate) fn _lookup_currency_exponent(
    deps: &Deps,
    base_denom: String,
    currency: String,
) -> Result<u32, ContractError> {
    let metadata = deps.querier.query_denom_metadata(base_denom)?;

    if let Some(u) = metadata
        .denom_units
        .iter()
        .find(|unit| unit.denom == currency)
    {
        return Ok(u.exponent);
    }
    Err(ContractError::BaseDenomNotFound { currency })
}

// lookup the exponent of the currency
pub(crate) fn _lookup_currency_exponent_by_wasm_smart(
    deps: &Deps,
    base_denom: String,
    currency: String,
    config: &Config,
) -> Result<u32, ContractError> {
    let q = TFQueryMsg::Bank(BankQuery::FindDenomMetadata {
        base_denom: base_denom.to_owned(),
        denom: currency.to_owned(),
    });
    let resp: StdResult<FindDenomMetadataResponse> = deps
        .querier
        .query_wasm_smart(config.tf_address.to_string(), &q);
    if resp.is_err() {
        return Err(ContractError::BaseDenomNotFound { currency });
    }
    let resp = resp.unwrap();

    Ok(resp.exponent)
}
