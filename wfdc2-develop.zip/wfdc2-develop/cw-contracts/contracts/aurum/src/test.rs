use cosmwasm_std::{to_json_binary, Binary, Coin, ContractResult};

use tokenfactory::msg::QueryMsg;
use tokenfactory::{MintersResponse, OwnerResponse, TokenfactoryQuery};

pub fn custom_query_execute(query: &QueryMsg) -> ContractResult<Binary> {
    match query {
        QueryMsg::Tf(TokenfactoryQuery::Minters { address: _, denom }) => {
            to_json_binary(&MintersResponse {
                address: "minter".to_string(),
                allowance: Coin::new(1000u128, denom),
            })
            .into()
        }
        _default => to_json_binary(&OwnerResponse {
            address: "".to_string(),
        })
        .into(),
    }
}
