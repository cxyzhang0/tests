### test scripts
> playground tests has subscribers (listeners)
> postman has websocket endpoints