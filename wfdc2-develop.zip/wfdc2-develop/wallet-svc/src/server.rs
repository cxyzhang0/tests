//! grpc server for wallet service
use std::fs;
use std::io::Read;
use std::str::FromStr;
use std::time::{Duration, Instant};

use abscissa_core::prelude::error;
use abscissa_core::Application;
use abscissa_tokio::tokio;
use cosmos_grpc_client::cosmos_sdk_proto::cosmos::{
    bank::v1beta1::MsgSend, base::v1beta1::Coin as ProtoCoin,
};
use cosmos_grpc_client::cosmos_sdk_proto::cosmwasm::wasm::v1::MsgExecuteContract;
use cosmos_grpc_client::cosmos_sdk_proto::Any;
use cosmos_grpc_client::{BroadcastMode, CoinType, Decimal, GrpcClient, ProstMsgNameToAny};
use cosmos_grpc_client::cosmos_sdk_proto::cosmos::tx::v1beta1::GetTxResponse;
#[cfg(feature = "p11hsm")]
use pkcs11::signer::P11Signer;
use cosmrs::proto::cosmos::bank::v1beta1::{QueryBalanceRequest, QueryDenomMetadataRequest, QueryDenomsMetadataRequest};
use cosmrs::proto::cosmos::tx::v1beta1::{BroadcastTxResponse, GetTxRequest};
use cosmrs::proto::cosmwasm::wasm::v1::{AccessConfig, MsgInstantiateContract, MsgStoreCode};
use cosmrs::{Coin, Denom};
use cosmwasm_std::{Addr};
use flate2::read::GzEncoder;
#[cfg(feature = "tsstrio")]
use mpc_wallet::sdk::{TrioSDK};
#[cfg(feature = "tsstrio")]
use mpc_wallet::traits::MpcTssSDK;
// use mpc_wallet::traits::MpcSigningKey;
#[cfg(feature = "p11hsm")]
use pkcs11::{CryptographAlgorithm as SDKCryptographAlgorithm, KeyLabel};
use time::format_description;
use tonic::{async_trait, Request, Response, Status};

use aurum::state::{to_base_amount, MemberState};
use aurum::{
    msg::{ExecuteMsg as AurumExecuteMsg, QueryMsg as AurumQueryMsg},
    state::Config as AurumConfigResponse,
    BalanceResponse as AurumBalanceResponse, MemberStates, PaymentRequest as AurumPaymentRequest,
    PaymentStateResponse as AurumPaymentStateResponse,
};
use tokenfactory::msg::{
    ExecuteMsg, FeegrantContractMsg, InstantiateMsg, QueryMsg, TokenfactoryContractMsg,
};
use tokenfactory::state::Config as TfConfigResponse;
use tokenfactory::{AllBlacklistedResponse, AllMinterControllersResponse, AllMintersResponse, AllMintingDenomsResponse, BankQuery, BlacklistedResponse, BlacklisterResponse, FeeBasicAllowanceResponse, FeegrantQuery, FindDenomMetadataResponse as TfFindDenomMetadataResponse, MasterMinterResponse, MinterControllerResponse, MintersResponse, MintingDenomResponse, OwnerResponse, PausedResponse, PauserResponse, TokenfactoryQuery};
// use tokenfactory_bindings::query::{DenomMetadata as BindingsDenomMetadata, DenomUnit as BindingsDenomUnit};
use crate::application::APP;
use crate::config::IBMMQConfig;
use crate::mq::parse_payment_request;
#[cfg(feature = "p11hsm")]
use crate::p11hsm::{do_keygen, get_pub_key_from_label};
use crate::prelude::info;
use crate::proto::wallet_client::WalletClient;
#[cfg(feature = "p11hsm")]
use crate::proto::CryptographAlgorithm as ProtoAlgorithm;
use crate::proto::{
    BalanceRequest, BalanceResponse, BlacklistRequest, BlacklistResponse, EchoRequest,
    EchoResponse, GetAllBlacklistedRequest, GetAllBlacklistedResponse, GetBlacklistedRequest,
    GetBlacklistedResponse, GetBlacklisterRequest, GetBlacklisterResponse, GetPausedRequest,
    GetPausedResponse, GetPauserRequest, GetPauserResponse, InstantiateContractRequest,
    InstantiateContractResponse, InstantiateFtContractRequest, InstantiateFtContractResponse,
    PauseRequest, PauseResponse, PaymentRequest, PaymentResponse, PaymentStateRequest,
    PaymentStateResponse, PaymentTxResponse, PaymentType, QueryTxRequest, QueryTxResponse,
    RemoveMinterControllerRequest, RemoveMinterControllerResponse, RemoveMinterRequest,
    RemoveMinterResponse, StoreCodeRequest, StoreCodeResponse, UnblacklistRequest,
    UnblacklistResponse, UnpauseRequest, UnpauseResponse, UpdateBlacklisterRequest,
    UpdateBlacklisterResponse, UpdatePauserRequest, UpdatePauserResponse,
};

use crate::proto::{
    BankBalanceRequest, BankBalanceResponse, BankSendRequest, BankSendResponse, BurnRequest,
    BurnResponse, ConfigureMinterControllerRequest, ConfigureMinterControllerResponse,
    ConfigureMinterRequest, ConfigureMinterResponse, GenKeyRequest, GenKeyResponse,
    GetAllMinterControllersRequest, GetAllMinterControllersResponse, GetAllMintersRequest,
    GetAllMintersResponse, GetMasterMinterRequest, GetMasterMinterResponse,
    GetMinterControllerRequest, GetMinterControllerResponse, GetMintersRequest, GetMintersResponse,
    GetMintingDenomRequest, GetMintingDenomResponse, GetOwnerRequest, GetOwnerResponse,
    GetPubKeyRequest, GetPubKeyResponse, MintRequest, MintResponse, UpdateMasterMinterRequest,
    UpdateMasterMinterResponse,
    BalanceError, CashResponse, FindDenomMetadataResponse, FindMetadataForDenomRequest, GetAllMintingDenomsRequest, GetAllMintingDenomsResponse, GetAurumConfigRequest, GetAurumConfigResponse, GetFeeBasicAllowanceRequest, GetFeeBasicAllowanceResponse, GetFeeBasicGrant, GetMemberRequest, GetMemberResponse, GetMembersRequest, GetMembersResponse, GetMqMesssageFromQueueRequest, GetMqMesssageFromQueueResponse, GetTfConfigRequest, GetTfConfigResponse, GrantFeeBasicAllowanceRequest, GrantFeeBasicAllowanceResponse, PostMqMessageResponse, PostMqMessageToQueueRequest, PostMqMessageToTopicRequest, RequestFeeBasicAllowanceRequest, RequestFeeBasicAllowanceResponse, RevokeFeeAllowanceRequest, RevokeFeeAllowanceResponse, UpdateMemberRequest, UpdateMemberResponse,
    SetDenomMetadataRequest, SetDenomMetadataResponse,
    GetAllDenomMetadataRequest, GetAllDenomMetadataResponse, GetDenomMetadataRequest, GetDenomMetadataResponse,
};
use crate::proto::{
    ErrorCode, FromMemberRequest, NotificationType, PaymentStatus, TransactionStatus,
};

use crate::types::{convert_balance_request, convert_balance_response, convert_denom_metadata, convert_denom_metadata_2, convert_payment_request, convert_payment_state_response, payment_request_to_payment_response};
use crate::{mq, AsyncSigningKey, AsyncWallet, ProtoWallet};

#[cfg(feature = "tsstrio")]
use crate::tss::get_pub_key;

/// WalletService implements ProtoWallet
#[derive(Debug, Default)]
pub struct WalletService {}

impl WalletService {
    /// Create a new instance of WalletService
    pub fn new() -> Self {
        Self {}
    }

    // broadcast_cw_tx
    async fn broadcast_cw_tx(
        &self,
        contract: String,
        msg: Vec<u8>,
        coin: Option<ProtoCoin>,
    ) -> Result<BroadcastTxResponse, Status> {
        let config = APP.config();

        #[cfg(feature = "p11hsm")]
        let (_vk, _pk, account_id) = get_pub_key_from_label(
            config.provider.p11hsm.key_label.clone(),
            config.chain_node.prefix.clone(),
        )
        .await?;

        #[cfg(feature = "tsstrio")]
        let (_vk, _pk, account_id) = {
            let vk = APP.sdk().lock().unwrap().verifying_key().unwrap();
            get_pub_key(vk, config.chain_node.prefix.clone()).await?
        };

        let msg = MsgExecuteContract {
            sender: account_id.to_string(),
            contract,
            msg,
            funds: match coin {
                None => vec![],
                Some(c) => vec![c],
            },
        }
            .build_any();
        // .map_err(|e| Status::invalid_argument(e.to_string()))?; // convert to Any

        self.broadcast_tx(msg).await
    }

    // broadcast_tx
    pub(crate) async fn broadcast_tx(&self, msg: Any) -> Result<BroadcastTxResponse, Status> {
        let config = APP.config();

        #[cfg(feature = "p11hsm")]
        let signer = P11Signer::new(
            APP.sdk(),
            KeyLabel::from_short(
                &config.provider.p11hsm.key_label,
                SDKCryptographAlgorithm::Secp256k1,
            )
            .map_err(|e| Status::internal(e.to_string()))?,
        );
        #[cfg(feature = "tsstrio")]
        let signer = {
            let mutex = APP.sdk();
            let sdk = mutex.lock().unwrap();
            TrioSDK {
                share: sdk.share.clone(),
                algorithm: sdk.algorithm.clone(),
                user_sk: sdk.user_sk.clone(),
                server_vk: sdk.server_vk.clone(),
                server: sdk.server.clone(),
                finish_server: sdk.finish_server.clone(),
                chain_path: sdk.chain_path.clone(),
                keygen_endpoint: sdk.keygen_endpoint.clone(),
                refresh_endpoint: sdk.refresh_endpoint.clone(),
                recovery_endpoint: sdk.recovery_endpoint.clone(),
                sign_endpoint: sdk.sign_endpoint.clone(),
                presign_endpoint: sdk.presign_endpoint.clone(),
                finish_endpoint: sdk.finish_endpoint.clone(),
            }
        };
        let signing_key = AsyncSigningKey::new(Box::new(signer));

        let client =
            WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await?;

        let gas_price = Decimal::from_str(&config.chain_node.gas_price)
            .map_err(|e| Status::internal(e.to_string()))?;
        let gas_adjustment = Decimal::from_str(&config.chain_node.gas_adjustment)
            .map_err(|e| Status::internal(e.to_string()))?;
        let gas_denom = config.chain_node.gas_denom.clone();

        let mut wallet = AsyncWallet::from_async_signing_key(
            client,
            signing_key,
            config.chain_node.prefix.as_str(),
            CoinType::Cosmos,
            gas_price,
            gas_adjustment,
            &gas_denom,
        )
        .await
        .map_err(|e| Status::internal(e.to_string()))?;

        let sim = wallet
            .simulate_tx(vec![msg.clone()])
            .await
            .map_err(|e| Status::internal(e.to_string()))?;

        let gas_used = Decimal::from_str(&sim.gas_info.unwrap().gas_used.to_string())
            .map_err(|e| Status::internal(e.to_string()))?;

        let fee = cosmrs::tx::Fee {
            amount: vec![Coin {
                denom: Denom::from_str(&gas_denom).unwrap(),
                amount: (gas_price * gas_adjustment * gas_used + Decimal::one())
                    .to_uint_ceil()
                    .u128(),
            }],
            gas_limit: (gas_used * gas_adjustment - Decimal::one())
                .to_uint_ceil()
                .u128() as u64,
            payer: None,
            granter: Some(cosmrs::AccountId::from_str(&config.faucet.address).unwrap()),
        };

        let response = wallet
            .broadcast_tx(
                vec![msg],           // Vec<Any>: list of msgs to broadcast
                Some(fee), //None, // fee: Option<Fee>, if not provided the tx is simulated to calculate the fee
                None,      // memo: Option<String>
                BroadcastMode::Sync, // Broadcast mode; Block/Sync/Async
            )
            .await
            .map_err(|e| Status::internal(e.to_string()))?;

        Ok(response)
    }

    /// helper to get the cosmos grpc client with the correct return type for
    /// ProtoWallet trait.
    pub(crate) async fn get_cosmos_grpc_client(addr: String) -> Result<GrpcClient, Status> {
        GrpcClient::new(addr.leak())
            .await
            .map_err(|e| Status::internal(e.to_string()))
    }

    // query_tx is a utility to query a transaction by its hash
    // in case of error in result, it still returns Ok with the error info
    async fn query_tx_with_client(
        &self,
        request: Request<QueryTxRequest>,
        mut client: GrpcClient,
    ) -> Result<Response<QueryTxResponse>, Status> {
        let req = request.into_inner();

        match client
            .clients
            .tx
            .get_tx(GetTxRequest {
                hash: req.txhash.clone(),
            })
            .await
        {
            Ok(resp) => {
                let resp = resp.into_inner();
                let tx_response = match resp.tx_response {
                    Some(tx) => tx,
                    None => return Err(Status::internal("tx_response not found".to_string())),
                };
                Ok(Response::new(QueryTxResponse {
                    txhash: tx_response.txhash,
                    status: "ok".to_string(), //
                    height: tx_response.height,
                    index: -1, // TODO: how to get the index?
                    code: tx_response.code,
                    log: tx_response.raw_log,
                    info: tx_response.info,
                    gas_wanted: tx_response.gas_wanted,
                    gas_used: tx_response.gas_used,
                    num_events: tx_response.events.len() as u32,
                }))
            }
            Err(e) => {
                Ok(Response::new(QueryTxResponse {
                    txhash: req.txhash,
                    status: e.code().to_string(),
                    height: 0,
                    index: -1,
                    code: 0, // code is not applicable in case of error
                    log: e
                        .message()
                        .parse()
                        .map_err(|_| Status::internal("failed to pass message".to_string()))?,
                    info: e.to_string(),
                    gas_wanted: 0,
                    gas_used: 0,
                    num_events: 0,
                }))
            }
        }
    }

    // execute_aurum_tx executes an aurum tx: funding, payment, or defunding
    // note: it will not panic so the caller will always get result.
    async fn execute_aurum_tx(
        &self,
        request: &PaymentRequest,
    ) -> Result<Response<PaymentTxResponse>, Status> {
        let config = APP.config();

        let payment_type = match PaymentType::from_str_name(&request.payment_type) {
            Some(t) => t,
            None => {
                error!("***** invalid payment type: {}", request.payment_type);
                return Err(Status::invalid_argument(format!(
                    "invalid payment type: {}",
                    request.payment_type
                )));
            }
        };

        let payment_request: AurumPaymentRequest = convert_payment_request(request.clone());
        let tracking_id = payment_request.tracking_id.clone();

        // get base denom and convert amount to base amount
        let metadata = self
            .find_metadata_for_denom(Request::new(FindMetadataForDenomRequest {
                denom: payment_request.currency.clone(),
            }))
            .await
            .map_err(|e| {
                error!(
                    "***** failed to find metadata for denom {}: {}",
                    payment_request.currency.clone(),
                    e.to_string()
                );
                Status::internal(e.to_string())
            })?;
        let metadata = metadata.into_inner();
        let base_denom = metadata.base;
        let exponent = metadata.exponent;
        let value = to_base_amount(payment_request.amount, exponent);
        let mut coin = Some(ProtoCoin {
            denom: base_denom,
            amount: value.to_string(),
        });

        let execute_msg = match payment_type {
            PaymentType::Funding => {
                coin = None;
                AurumExecuteMsg::Fund {
                    req: payment_request,
                }
            }
            PaymentType::Payment => AurumExecuteMsg::Pay {
                req: payment_request,
            },
            PaymentType::Defunding => AurumExecuteMsg::Defund {
                req: payment_request,
            },
            PaymentType::Unknown => {
                error!("***** unspecified payment type: {}", request.payment_type);
                return Err(Status::invalid_argument(format!(
                    "unspecified payment type: {}",
                    request.payment_type
                )));
            }
        };

        let execute_msg = serde_json::to_vec(&execute_msg).map_err(|e| {
            error!("***** failed to_vec: {}", e.to_string());
            Status::invalid_argument(e.to_string())
        })?;

        let response = self
            .broadcast_cw_tx(config.chain_node.aurum_contract.clone(), execute_msg, coin)
            .await
            .map_err(|e| {
                error!("***** failed to broadcast_cw_tx: {}", e.to_string());
                Status::internal(e.to_string())
            })?;

        Ok(Response::new(PaymentTxResponse {
            txhash: match response.tx_response {
                Some(tx) => tx.txhash,
                None => return Err(Status::internal("txhash unavailable".to_string())),
            },
            tracking_id,
        }))
    }

    // get_aurum_balance
    // this fn should not panic because process_aurum_balance uses it.
    async fn get_aurum_balance(
        &self,
        req: &BalanceRequest,
    ) -> Result<Response<BalanceResponse>, Status> {
        let config = APP.config();

        let client =
            WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await?;

        let query_msg = AurumQueryMsg::Balance {
            req: convert_balance_request(req),
        };

        let resp = client
            // .wasm_query_contract
            .query_smart_contract::<AurumQueryMsg, AurumBalanceResponse>(
                config.chain_node.aurum_contract.clone(),
                query_msg,
            )
            .await
            .map_err(|e| {
                error!("***** failed get_aurum_balance: {}", e.to_string());
                Status::internal(e.to_string())
            })?;

        Ok(Response::new(convert_balance_response(resp)))
    }

    fn payment_type_to_notifysender_topic_string(
        &self,
        conf: &IBMMQConfig,
        payment_type: &str,
    ) -> String {
        match PaymentType::from_str_name(payment_type).unwrap() {
            PaymentType::Funding => conf.funding_notifysender_topic_string.clone(),
            PaymentType::Payment => conf.payment_notifysender_topic_string.clone(),
            PaymentType::Defunding => conf.defunding_notifysender_topic_string.clone(),
            _ => "".to_string(),
        }
    }

    fn payment_type_to_transfernotification_topic_string(
        &self,
        conf: &IBMMQConfig,
        payment_type: &str,
    ) -> String {
        match PaymentType::from_str_name(payment_type).unwrap() {
            PaymentType::Payment => conf.payment_transfernotification_topic_string.clone(),
            PaymentType::Defunding => conf.defunding_transfernotification_topic_string.clone(),
            // note: funding has no transfer notification
            _ => "".to_string(),
        }
    }

    /// process_payment_request is called by the mq listener once it gets a parsed payment request.
    pub async fn process_payment_request(&self, request: PaymentRequest) -> Result<String, Status> {
        let config = APP.config();

        let aurum_req = Request::new(request);
        let resp = self.process_aurum_tx(aurum_req).await?.into_inner();

        // note: we may not need _pretty because it adds \n
        let payload = serde_json::to_string(&resp)
            .map_err(|e| Status::invalid_argument(format!("json to_string error: {}", e)))?;
        // let payload = serde_json::to_string_pretty(&resp).map_err(|e| Status::invalid_argument(format!("json to_string error: {}", e.to_string())))?;

        let topic_string =
            self.payment_type_to_notifysender_topic_string(&config.ibm_mq, &resp.payment_type);
        // info!("notify sender - post topic string: {}", topic_string);

        let post_resp = self
            .post_mq_message_to_topic(Request::new(PostMqMessageToTopicRequest {
                topic_string,
                message: payload.clone(),
            }))
            .await?
            .into_inner();
        info!(
            "notify sender sent - tracking_id: {}; status {}; return data: {}",
            resp.tracking_id, post_resp.status, post_resp.ret_data
        );

        let ret = format!(
            "post status: {}; post return data: {}",
            post_resp.status, post_resp.ret_data
        );

        Ok(ret)
    }

    async fn pool_txhash(
        &self,
        txhash: String,
    ) -> Result<GetTxResponse, Status> {
        let config = APP.config();
        let mut client =
            WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await?;

        let interval = Duration::from_millis(config.chain_node.tx_poll_interval);
        let time_out = Duration::from_millis(config.chain_node.tx_poll_timeout);
        let deadline = Instant::now() + time_out;
        let tx_resp: Result<GetTxResponse, Status> = loop {
            let res = client
                .clients
                .tx
                .get_tx(GetTxRequest {
                    hash: txhash.clone(),
                })
                .await;

            if let Ok(resp) = res {
                break Ok(resp.into_inner())
            }

            tokio::time::sleep(interval).await;

            if Instant::now() > deadline {
                break Err(Status::deadline_exceeded("tx not found before timeout".to_string()))
            }
        };
        tx_resp
    }
}

#[async_trait]
impl ProtoWallet for WalletService {
    // diagnosis utility
    async fn echo(&self, request: Request<EchoRequest>) -> Result<Response<EchoResponse>, Status> {
        let req = request.into_inner();
        Ok(Response::new(EchoResponse { echo: req.echo }))
    }

    async fn store_code(
        &self,
        request: Request<StoreCodeRequest>,
    ) -> Result<Response<StoreCodeResponse>, Status> {
        let config = APP.config();

        let req = request.into_inner();

        #[cfg(feature = "p11hsm")]
        let (_vk, _pk, account_id) = get_pub_key_from_label(
            config.provider.p11hsm.key_label.clone(),
            config.chain_node.prefix.clone(),
        )
        .await?;

        #[cfg(feature = "tsstrio")]
        let (_vk, _pk, account_id) = {
            let vk = APP.sdk().lock().unwrap().verifying_key().unwrap();
            get_pub_key(vk, config.chain_node.prefix.clone()).await?
        };

        let wasm = fs::read(req.wasm_file.clone()).map_err(|e| {
            Status::invalid_argument(format!("Failed to read wasm file {}: {}", req.wasm_file, e))
        })?;
        // &wasm[..] is the same as wasm.as_slice()
        let mut gz = GzEncoder::new(&wasm[..], flate2::Compression::default());
        // let mut gz = GzEncoder::new(wasm.as_slice(), flate2::Compression::default());
        let mut compressed = Vec::new();
        let _ = gz
            .read_to_end(&mut compressed)
            .map_err(|e| Status::internal(format!("Failed to gzip: {}", e)));

        let msg = MsgStoreCode {
            sender: account_id.to_string(),
            wasm_byte_code: compressed,
            // TODO: wallet holder can instantiate the contract
            //  do we need to pass in the address(es) that can instantiate the contract?
            instantiate_permission: Some(AccessConfig {
                permission: 4,           // any one of the addresses can instantiate the contract
                address: "".to_string(), // deprecated, use addresses
                addresses: vec![account_id.to_string()],
            }),
        }
        .build_any();

        let response = self.broadcast_tx(msg).await?;

        Ok(Response::new(StoreCodeResponse {
            txhash: match response.tx_response {
                Some(tx) => tx.txhash,
                None => return Err(Status::internal("txhash unavailable".to_string())),
            },
        }))
    }

    async fn instantiate_ft_contract(
        &self,
        request: Request<InstantiateFtContractRequest>,
    ) -> Result<Response<InstantiateFtContractResponse>, Status> {
        let config = APP.config();

        let req = request.into_inner();

        #[cfg(feature = "p11hsm")]
        let (_vk, _pk, account_id) = get_pub_key_from_label(
            config.provider.p11hsm.key_label.clone(),
            config.chain_node.prefix.clone(),
        )
        .await?;

        #[cfg(feature = "tsstrio")]
        let (_vk, _pk, account_id) = {
            let vk = APP.sdk().lock().unwrap().verifying_key().unwrap();
            get_pub_key(vk, config.chain_node.prefix.clone()).await?
        };
        let init_msg = InstantiateMsg { is_tf: req.is_tf };

        info!("init_msg: {:?}", init_msg);
        let msg = MsgInstantiateContract {
            sender: account_id.to_string(),
            code_id: req.code_id,
            label: req.label,
            msg: serde_json::to_vec(&init_msg)
                .map_err(|e| Status::invalid_argument(e.to_string()))?,
            admin: account_id.to_string(),
            funds: vec![],
        }
        .build_any();

        let response = self.broadcast_tx(msg).await?;

        Ok(Response::new(InstantiateFtContractResponse {
            txhash: match response.tx_response {
                Some(tx) => tx.txhash,
                None => return Err(Status::internal("txhash unavailable".to_string())),
            },
        }))
    }

    async fn instantiate_contract(
        &self,
        request: Request<InstantiateContractRequest>,
    ) -> Result<Response<InstantiateContractResponse>, Status> {
        let config = APP.config();

        let req = request.into_inner();

        #[cfg(feature = "p11hsm")]
        let (_vk, _pk, account_id) = get_pub_key_from_label(
            config.provider.p11hsm.key_label.clone(),
            config.chain_node.prefix.clone(),
        )
        .await?;

        #[cfg(feature = "tsstrio")]
        let (_vk, _pk, account_id) = {
            let vk = APP.sdk().lock().unwrap().verifying_key().unwrap();
            get_pub_key(vk, config.chain_node.prefix.clone()).await?
        };

        let init_msg = req.init_msg;

        info!("init_msg: {:?}", init_msg);
        let msg = MsgInstantiateContract {
            sender: account_id.to_string(),
            code_id: req.code_id,
            label: req.label,
            msg: init_msg.into_bytes(),
            admin: account_id.to_string(),
            funds: vec![],
        }
        .build_any();

        let response = self.broadcast_tx(msg).await?;

        Ok(Response::new(InstantiateContractResponse {
            txhash: match response.tx_response {
                Some(tx) => tx.txhash,
                None => return Err(Status::internal("txhash unavailable".to_string())),
            },
        }))
    }

    // query_tx is a utility to query a transaction by its hash
    // in case of error in result, it still returns Ok with the error info
    async fn query_tx(
        &self,
        request: Request<QueryTxRequest>,
    ) -> Result<Response<QueryTxResponse>, Status> {
        let config = APP.config();

        let client = WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await?;

        self.query_tx_with_client(request, client).await
    }

    // keys
    #[cfg(feature = "p11hsm")]
    async fn gen_key(
        &self,
        request: Request<GenKeyRequest>,
    ) -> Result<Response<GenKeyResponse>, Status> {
        let req = request.into_inner();

        let algo = SDKCryptographAlgorithm::from(
            ProtoAlgorithm::as_str_name(&req.algorithm()).to_string(),
        );
        let key_label = KeyLabel::from_short(&req.key_label, algo)
            .map_err(|e| Status::invalid_argument(e.to_string()))?;

        let key_label = do_keygen(key_label, req.persistent).await?;

        Ok(Response::new(GenKeyResponse {
            key_label: key_label.short_string(),
            persisted: req.persistent,
        }))
    }

    #[cfg(feature = "tsstrio")]
    async fn gen_key(
        &self,
        _request: Request<GenKeyRequest>,
    ) -> Result<Response<GenKeyResponse>, Status> {
        todo!("gen_key")
    }

    async fn get_pub_key(
        &self,
        request: Request<GetPubKeyRequest>,
    ) -> Result<Response<GetPubKeyResponse>, Status> {
        let config = APP.config();

        #[cfg(feature = "p11hsm")]
        let (kl, vk, account_id) = {
            let req = request.into_inner();
            let kl = match req.key_label {
                Some(kl) => kl,
                None => config.provider.p11hsm.key_label.clone(),
            };

            let (vk, _pk, account_id) =
                get_pub_key_from_label(kl.clone(), config.chain_node.prefix.clone()).await?;
            (kl, vk, account_id)
        };

        #[cfg(feature = "tsstrio")]
        let (kl, vk, account_id) = {
            let vk = APP.sdk().lock().unwrap().verifying_key().unwrap();
            let sdk = APP.sdk();
            let sdk = sdk.lock().unwrap();
            let share = sdk.share.clone().unwrap();
            // these work if futures::lock::Mutex is used
            /*
            let sdk = APP.sdk();
            let sdk = sdk.lock().unwrap();
            let vk = sdk.verifying_key().unwrap();
            let share_handle = sdk.share_handle;           
            */
            let id = hex::encode(
                share.key_id
            );
            //let (vk, _pk, account_id) = get_pub_key(vk, config.chain_node.prefix.clone()).await?;
            let account_id = sdk.account(config.chain_node.prefix.as_str(), config.provider.tsstrio.chain_path.as_str());
            (id, vk, account_id)
        };

        Ok(Response::new(GetPubKeyResponse {
            key_label: kl,
            pub_key: hex::encode(vk.to_sec1_bytes()),
            acct_addr: account_id.to_string(),
        }))
    }

    // bank
    async fn get_bank_balance(
        &self,
        request: Request<BankBalanceRequest>,
    ) -> Result<Response<BankBalanceResponse>, Status> {
        let config = APP.config();

        let req = request.into_inner();

        let mut is_for_self = false;

        let addr = if let Some(addr) = req.address.clone() {
            addr
        } else {
            #[cfg(feature = "p11hsm")]
            let (_vk, _pk, account_id) = get_pub_key_from_label(
                config.provider.p11hsm.key_label.clone(),
                config.chain_node.prefix.clone(),
            )
            .await?;
            #[cfg(feature = "tsstrio")]
            let (_vk, _pk, account_id) = {
                let vk = APP.sdk().lock().unwrap().verifying_key().unwrap();
                get_pub_key(vk, config.chain_node.prefix.clone()).await?
            };

            is_for_self = true;
            account_id.to_string()
        };

        let mut client =
            WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await?;

        let bal_req = QueryBalanceRequest {
            address: addr.clone(),
            denom: req.denom,
        };

        let resp = client
            .clients
            .bank
            .balance(bal_req)
            .await
            .map_err(|e| Status::internal(e.to_string()))?;
         let resp = resp.into_inner();

        #[cfg(feature = "p11hsm")]
        let key_label = if is_for_self {
            Some(config.provider.p11hsm.key_label.clone())
        } else {
            None
        };

        #[cfg(feature = "tsstrio")]
        let key_label = if is_for_self {
            let id = hex::encode(
                APP.sdk().lock().unwrap().share.clone().unwrap().key_id);
            Some(id)
        } else {
            None
        };

        Ok(Response::new(BankBalanceResponse {
            key_label,
            address: Some(addr),
            denom: match resp.balance.clone() {
                None => "bank balance unavailable".to_string(),
                Some(bal) => bal.denom,
            },
            // TODO: replace/handle unwrap
            value: resp.balance.unwrap().amount,
        }))
    }

    async fn bank_send(
        &self,
        request: Request<BankSendRequest>,
    ) -> Result<Response<BankSendResponse>, Status> {
        let config = APP.config();

        let req = request.into_inner();

        #[cfg(feature = "p11hsm")]
        let (_vk, _pk, account_id) = get_pub_key_from_label(
            config.provider.p11hsm.key_label.clone(),
            config.chain_node.prefix.clone(),
        )
        .await?;

        #[cfg(feature = "tsstrio")]
        let (_vk, _pk, account_id) = {
            let vk = APP.sdk().lock().unwrap().verifying_key().unwrap();
            get_pub_key(vk, config.chain_node.prefix.clone()).await?
        };

        let msg = MsgSend {
            from_address: account_id.to_string(),
            to_address: req.to_addr,
            amount: vec![ProtoCoin {
                denom: req.denom,
                amount: req.value.to_string(),
            }],
        }
        .build_any();

        let response = self.broadcast_tx(msg).await?;

        Ok(Response::new(BankSendResponse {
            txhash: match response.tx_response {
                Some(tx) => tx.txhash,
                None => return Err(Status::internal("txhash unavailable".to_string())),
            },
        }))
    }

    async fn get_denom_metadata(
        &self,
        request: Request<GetDenomMetadataRequest>,
    ) -> Result<Response<GetDenomMetadataResponse>, Status> {
        let config = APP.config();

        let req = request.into_inner();

        let mut client =
            WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await?;

        let denom_metadata_req = QueryDenomMetadataRequest { denom: req.denom };  
        
        let resp = client
            .clients
            .bank
            .denom_metadata(denom_metadata_req)
            .await
            .map_err(|e| Status::internal(e.to_string()))?;
        let mut resp = resp.into_inner();

        Ok(Response::new(GetDenomMetadataResponse {
            metadata: resp.metadata.take().map(convert_denom_metadata),
        }))
    }
    
    async fn get_all_denom_metadata(
        &self,
        request: Request<GetAllDenomMetadataRequest>,
    ) -> Result<Response<GetAllDenomMetadataResponse>, Status> {
        let config = APP.config();

        let _req = request.into_inner();

        let mut client =
            WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await?;

        let resp = client
            .clients
            .bank
            .denoms_metadata(QueryDenomsMetadataRequest { pagination: None })
            .await
            .map_err(|e| Status::internal(e.to_string()))?;
        let resp = resp.into_inner();

        let metadata = resp.metadatas.into_iter().map(convert_denom_metadata).map(|m| GetDenomMetadataResponse { metadata: Some(m) }).collect();

        Ok(Response::new(GetAllDenomMetadataResponse { denom_metadata: metadata }))
    }
    
    // tokenfactory tx
    async fn update_master_minter(
        &self,
        request: Request<UpdateMasterMinterRequest>,
    ) -> Result<Response<UpdateMasterMinterResponse>, Status> {
        let config = APP.config();

        let req = request.into_inner();

        let execute_msg = ExecuteMsg::Tf(TokenfactoryContractMsg::UpdateMasterMinter {
            address: req.address,
        });

        let execute_msg = serde_json::to_vec(&execute_msg)
            .map_err(|e| Status::invalid_argument(e.to_string()))?;

        let response = self
            .broadcast_cw_tx(
                config.chain_node.tokenfactory_contract.clone(),
                execute_msg,
                None,
            )
            .await?;

        Ok(Response::new(UpdateMasterMinterResponse {
            txhash: match response.tx_response {
                Some(tx) => tx.txhash,
                None => return Err(Status::internal("txhash unavailable".to_string())),
            },
        }))
    }

    async fn configure_minter_controller(
        &self,
        request: Request<ConfigureMinterControllerRequest>,
    ) -> Result<Response<ConfigureMinterControllerResponse>, Status> {
        let config = APP.config();

        let req = request.into_inner();

        let execute_msg = ExecuteMsg::Tf(TokenfactoryContractMsg::ConfigureMinterController {
            controller: req.controller,
            minter: req.minter,
        });

        let execute_msg = serde_json::to_vec(&execute_msg)
            .map_err(|e| Status::invalid_argument(e.to_string()))?;

        let response = self
            .broadcast_cw_tx(
                config.chain_node.tokenfactory_contract.clone(),
                execute_msg,
                None,
            )
            .await?;

        Ok(Response::new(ConfigureMinterControllerResponse {
            txhash: match response.tx_response {
                Some(tx) => tx.txhash,
                None => return Err(Status::internal("txhash unavailable".to_string())),
            },
        }))
    }

    async fn remove_minter_controller(
        &self,
        request: Request<RemoveMinterControllerRequest>,
    ) -> Result<Response<RemoveMinterControllerResponse>, Status> {
        let config = APP.config();

        let req = request.into_inner();

        let execute_msg = ExecuteMsg::Tf(TokenfactoryContractMsg::RemoveMinterController {
            controller: req.controller,
            minter: req.minter,
        });

        let execute_msg = serde_json::to_vec(&execute_msg)
            .map_err(|e| Status::invalid_argument(e.to_string()))?;

        let response = self
            .broadcast_cw_tx(
                config.chain_node.tokenfactory_contract.clone(),
                execute_msg,
                None,
            )
            .await?;

        Ok(Response::new(RemoveMinterControllerResponse {
            txhash: match response.tx_response {
                Some(tx) => tx.txhash,
                None => return Err(Status::internal("txhash unavailable".to_string())),
            },
        }))
    }

    async fn configure_minter(
        &self,
        request: Request<ConfigureMinterRequest>,
    ) -> Result<Response<ConfigureMinterResponse>, Status> {
        let config = APP.config();

        let req = request.into_inner();

        let execute_msg = ExecuteMsg::Tf(TokenfactoryContractMsg::ConfigureMinter {
            address: req.address,
            allowance_denom: req.allowance_denom,
            allowance_value: req.allowance_value,
        });

        let execute_msg = serde_json::to_vec(&execute_msg)
            .map_err(|e| Status::invalid_argument(e.to_string()))?;

        let response = self
            .broadcast_cw_tx(
                config.chain_node.tokenfactory_contract.clone(),
                execute_msg,
                None,
            )
            .await?;

        Ok(Response::new(ConfigureMinterResponse {
            txhash: match response.tx_response {
                Some(tx) => tx.txhash,
                None => return Err(Status::internal("txhash unavailable".to_string())),
            },
        }))
    }

    async fn remove_minter(
        &self,
        request: Request<RemoveMinterRequest>,
    ) -> Result<Response<RemoveMinterResponse>, Status> {
        let config = APP.config();

        let req = request.into_inner();

        let execute_msg = ExecuteMsg::Tf(TokenfactoryContractMsg::RemoveMinter {
            address: req.address,
            denom: req.denom,
        });

        let execute_msg = serde_json::to_vec(&execute_msg)
            .map_err(|e| Status::invalid_argument(e.to_string()))?;

        let response = self
            .broadcast_cw_tx(
                config.chain_node.tokenfactory_contract.clone(),
                execute_msg,
                None,
            )
            .await?;

        Ok(Response::new(RemoveMinterResponse {
            txhash: match response.tx_response {
                Some(tx) => tx.txhash,
                None => return Err(Status::internal("txhash unavailable".to_string())),
            },
        }))
    }

    async fn update_blacklister(
        &self,
        request: Request<UpdateBlacklisterRequest>,
    ) -> Result<Response<UpdateBlacklisterResponse>, Status> {
        let config = APP.config();

        let req = request.into_inner();

        let execute_msg = ExecuteMsg::Tf(TokenfactoryContractMsg::UpdateBlacklister {
            address: req.address,
        });

        let execute_msg = serde_json::to_vec(&execute_msg)
            .map_err(|e| Status::invalid_argument(e.to_string()))?;

        let response = self
            .broadcast_cw_tx(
                config.chain_node.tokenfactory_contract.clone(),
                execute_msg,
                None,
            )
            .await?;

        Ok(Response::new(UpdateBlacklisterResponse {
            txhash: match response.tx_response {
                Some(tx) => tx.txhash,
                None => return Err(Status::internal("txhash unavailable".to_string())),
            },
        }))
    }

    async fn blacklist(
        &self,
        request: Request<BlacklistRequest>,
    ) -> Result<Response<BlacklistResponse>, Status> {
        let config = APP.config();

        let req = request.into_inner();

        let execute_msg = ExecuteMsg::Tf(TokenfactoryContractMsg::Blacklist {
            address: req.address,
        });

        let execute_msg = serde_json::to_vec(&execute_msg)
            .map_err(|e| Status::invalid_argument(e.to_string()))?;

        let response = self
            .broadcast_cw_tx(
                config.chain_node.tokenfactory_contract.clone(),
                execute_msg,
                None,
            )
            .await?;

        Ok(Response::new(BlacklistResponse {
            txhash: match response.tx_response {
                Some(tx) => tx.txhash,
                None => return Err(Status::internal("txhash unavailable".to_string())),
            },
        }))
    }

    async fn unblacklist(
        &self,
        request: Request<UnblacklistRequest>,
    ) -> Result<Response<UnblacklistResponse>, Status> {
        let config = APP.config();

        let req = request.into_inner();

        let execute_msg = ExecuteMsg::Tf(TokenfactoryContractMsg::Unblacklist {
            address: req.address,
        });

        let execute_msg = serde_json::to_vec(&execute_msg)
            .map_err(|e| Status::invalid_argument(e.to_string()))?;

        let response = self
            .broadcast_cw_tx(
                config.chain_node.tokenfactory_contract.clone(),
                execute_msg,
                None,
            )
            .await?;

        Ok(Response::new(UnblacklistResponse {
            txhash: match response.tx_response {
                Some(tx) => tx.txhash,
                None => return Err(Status::internal("txhash unavailable".to_string())),
            },
        }))
    }

    async fn update_pauser(
        &self,
        request: Request<UpdatePauserRequest>,
    ) -> Result<Response<UpdatePauserResponse>, Status> {
        let config = APP.config();

        let req = request.into_inner();

        let execute_msg = ExecuteMsg::Tf(TokenfactoryContractMsg::UpdatePauser {
            address: req.address,
        });

        let execute_msg = serde_json::to_vec(&execute_msg)
            .map_err(|e| Status::invalid_argument(e.to_string()))?;

        let response = self
            .broadcast_cw_tx(
                config.chain_node.tokenfactory_contract.clone(),
                execute_msg,
                None,
            )
            .await?;

        Ok(Response::new(UpdatePauserResponse {
            txhash: match response.tx_response {
                Some(tx) => tx.txhash,
                None => return Err(Status::internal("txhash unavailable".to_string())),
            },
        }))
    }

    async fn pause(
        &self,
        request: Request<PauseRequest>,
    ) -> Result<Response<PauseResponse>, Status> {
        let config = APP.config();

        let _req = request.into_inner();

        let execute_msg = ExecuteMsg::Tf(TokenfactoryContractMsg::Pause {});

        let execute_msg = serde_json::to_vec(&execute_msg)
            .map_err(|e| Status::invalid_argument(e.to_string()))?;

        let response = self
            .broadcast_cw_tx(
                config.chain_node.tokenfactory_contract.clone(),
                execute_msg,
                None,
            )
            .await?;

        Ok(Response::new(PauseResponse {
            txhash: match response.tx_response {
                Some(tx) => tx.txhash,
                None => return Err(Status::internal("txhash unavailable".to_string())),
            },
        }))
    }

    async fn unpause(
        &self,
        request: Request<UnpauseRequest>,
    ) -> Result<Response<UnpauseResponse>, Status> {
        let config = APP.config();

        let _req = request.into_inner();

        let execute_msg = ExecuteMsg::Tf(TokenfactoryContractMsg::Unpause {});

        let execute_msg = serde_json::to_vec(&execute_msg)
            .map_err(|e| Status::invalid_argument(e.to_string()))?; // convert to Any

        let response = self
            .broadcast_cw_tx(
                config.chain_node.tokenfactory_contract.clone(),
                execute_msg,
                None,
            )
            .await?;

        Ok(Response::new(UnpauseResponse {
            txhash: match response.tx_response {
                Some(tx) => tx.txhash,
                None => return Err(Status::internal("txhash unavailable".to_string())),
            },
        }))
    }

    async fn mint(&self, request: Request<MintRequest>) -> Result<Response<MintResponse>, Status> {
        let config = APP.config();

        let req = request.into_inner();

        let execute_msg = ExecuteMsg::Tf(TokenfactoryContractMsg::Mint {
            orig_sender: None,
            address: req.address,
            denom: req.denom,
            value: req.value,
        });

        let execute_msg = serde_json::to_vec(&execute_msg)
            .map_err(|e| Status::invalid_argument(e.to_string()))?; // convert to Any

        let response = self
            .broadcast_cw_tx(
                config.chain_node.tokenfactory_contract.clone(),
                execute_msg,
                None,
            )
            .await?;

        Ok(Response::new(MintResponse {
            txhash: match response.tx_response {
                Some(tx) => tx.txhash,
                None => return Err(Status::internal("txhash unavailable".to_string())),
            },
        }))
    }

    async fn burn(&self, request: Request<BurnRequest>) -> Result<Response<BurnResponse>, Status> {
        let config = APP.config();

        let req = request.into_inner();

        let execute_msg = ExecuteMsg::Tf(TokenfactoryContractMsg::Burn {
            orig_sender: None,
            denom: req.denom,
            value: req.value,
        });

        let execute_msg = serde_json::to_vec(&execute_msg)
            .map_err(|e| Status::invalid_argument(e.to_string()))?; // convert to Any

        let response = self
            .broadcast_cw_tx(
                config.chain_node.tokenfactory_contract.clone(),
                execute_msg,
                None,
            )
            .await?;

        Ok(Response::new(BurnResponse {
            txhash: match response.tx_response {
                Some(tx) => tx.txhash,
                None => return Err(Status::internal("txhash unavailable".to_string())),
            },
        }))
    }

    async fn set_denom_metadata(&self, request: Request<SetDenomMetadataRequest>) -> Result<Response<SetDenomMetadataResponse>, Status> {
        let config = APP.config();

        let req = request.into_inner();

        let metadata = req.metadata.unwrap();

        let execute_msg = ExecuteMsg::Tf(TokenfactoryContractMsg::SetDenomMetadata {
            orig_sender: None,
            metadata: convert_denom_metadata_2(metadata),
        });
        
        // let mut denom_units = vec![];
        // for du in metadata.denom_units {
        //     denom_units.push(BindingsDenomUnit {
        //         denom: du.denom,
        //         exponent: du.exponent,
        //         aliases: Some(du.aliases),
        //     });
        // }
        // 
        // let execute_msg = ExecuteMsg::Tf(TokenfactoryContractMsg::SetDenomMetadata {
        //     orig_sender: None,
        //     metadata: BindingsDenomMetadata {
        //         description: metadata.description,
        //         denom_units,
        //         base: metadata.base,
        //         display: metadata.display,
        //         name: metadata.name,
        //         symbol: metadata.symbol,
        //         uri: metadata.uri,
        //         uri_hash: metadata.uri_hash,
        //     },
        // });

        let execute_msg = serde_json::to_vec(&execute_msg)
            .map_err(|e| Status::invalid_argument(e.to_string()))?; // convert to Any

        let response = self
            .broadcast_cw_tx(
                config.chain_node.tokenfactory_contract.clone(),
                execute_msg,
                None,
            )
            .await?;

        Ok(Response::new(SetDenomMetadataResponse {
            txhash: match response.tx_response {
                Some(tx) => tx.txhash,
                None => return Err(Status::internal("txhash unavailable".to_string())),
            },
        }))
    }

    // tokenfactory query
    async fn get_tf_config(
        &self,
        request: Request<GetTfConfigRequest>,
    ) -> Result<Response<GetTfConfigResponse>, Status> {
        let config = APP.config();

        let _req = request.into_inner();

        let client =
            WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await?;

        let query_msg = QueryMsg::Config {};

        let resp = client
            .query_smart_contract::<QueryMsg, TfConfigResponse>(
                config.chain_node.tokenfactory_contract.clone(),
                query_msg,
            )
            .await
            .map_err(|e| Status::internal(e.to_string()))?;

        Ok(Response::new(GetTfConfigResponse {
            owner: resp.owner.to_string(),
            is_tf: resp.is_tf,
        }))
    }

    async fn get_owner(
        &self,
        request: Request<GetOwnerRequest>,
    ) -> Result<Response<GetOwnerResponse>, Status> {
        let config = APP.config();

        let _req = request.into_inner();

        let client =
            WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await?;

        let query_msg = QueryMsg::Tf(TokenfactoryQuery::Owner {});

        let resp = client
            .query_smart_contract::<QueryMsg, OwnerResponse>(
                config.chain_node.tokenfactory_contract.clone(),
                query_msg,
            )
            .await
            .map_err(|e| Status::internal(e.to_string()))?;

        Ok(Response::new(GetOwnerResponse {
            address: resp.address,
        }))
    }

    async fn get_master_minter(
        &self,
        request: Request<GetMasterMinterRequest>,
    ) -> Result<Response<GetMasterMinterResponse>, Status> {
        let config = APP.config();

        let _req = request.into_inner();

        let client =
            WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await?;

        let query_msg = QueryMsg::Tf(TokenfactoryQuery::MasterMinter {});

        let resp = client
            .query_smart_contract::<QueryMsg, MasterMinterResponse>(
                config.chain_node.tokenfactory_contract.clone(),
                query_msg,
            )
            .await
            .map_err(|e| Status::internal(e.to_string()))?;

        Ok(Response::new(GetMasterMinterResponse {
            address: resp.address,
        }))
    }

    async fn get_minter_controller(
        &self,
        request: Request<GetMinterControllerRequest>,
    ) -> Result<Response<GetMinterControllerResponse>, Status> {
        let config = APP.config();

        let req = request.into_inner();

        let client =
            WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await?;

        let query_msg = QueryMsg::Tf(TokenfactoryQuery::MinterController {
            controller: req.controller,
            minter: req.minter,
        });

        let resp = client
            .query_smart_contract::<QueryMsg, MinterControllerResponse>(
                config.chain_node.tokenfactory_contract.clone(),
                query_msg,
            )
            .await
            .map_err(|e| Status::internal(e.to_string()))?;

        Ok(Response::new(GetMinterControllerResponse {
            minter: resp.minter,
            controller: resp.controller,
        }))
    }

    async fn get_all_minter_controllers(
        &self,
        request: Request<GetAllMinterControllersRequest>,
    ) -> Result<Response<GetAllMinterControllersResponse>, Status> {
        let config = APP.config();

        let _req = request.into_inner();

        let client =
            WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await?;

        let query_msg = QueryMsg::Tf(TokenfactoryQuery::AllMinterControllers {});

        let resp = client
            .query_smart_contract::<QueryMsg, AllMinterControllersResponse>(
                config.chain_node.tokenfactory_contract.clone(),
                query_msg,
            )
            .await
            .map_err(|e| Status::internal(e.to_string()))?;

        let mut minter_controllers = vec![];
        for mc in resp.minter_controllers {
            minter_controllers.push(GetMinterControllerResponse {
                minter: mc.minter,
                controller: mc.controller,
            })
        }

        Ok(Response::new(GetAllMinterControllersResponse {
            minter_controllers,
        }))
    }

    async fn get_minting_denom(
        &self,
        request: Request<GetMintingDenomRequest>,
    ) -> Result<Response<GetMintingDenomResponse>, Status> {
        let config = APP.config();

        let req = request.into_inner();

        let client =
            WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await?;

        let query_msg = QueryMsg::Tf(TokenfactoryQuery::MintingDenom { denom: req.denom });

        let resp = client
            .query_smart_contract::<QueryMsg, MintingDenomResponse>(
                config.chain_node.tokenfactory_contract.clone(),
                query_msg,
            )
            .await
            .map_err(|e| Status::internal(e.to_string()))?;
        Ok(Response::new(GetMintingDenomResponse { denom: resp.denom }))
    }

    async fn get_all_minting_denoms(
        &self,
        request: Request<GetAllMintingDenomsRequest>,
    ) -> Result<Response<GetAllMintingDenomsResponse>, Status> {
        let config = APP.config();

        let _req = request.into_inner();

        let client =
            WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await?;

        let query_msg = QueryMsg::Tf(TokenfactoryQuery::AllMintingDenoms {});

        let resp = client
            .query_smart_contract::<QueryMsg, AllMintingDenomsResponse>(
                config.chain_node.tokenfactory_contract.clone(),
                query_msg,
            )
            .await
            .map_err(|e| Status::internal(e.to_string()))?;

        let mut denoms = vec![];
        for d in resp.minting_denoms {
            denoms.push(GetMintingDenomResponse { denom: d.denom });
        }

        Ok(Response::new(GetAllMintingDenomsResponse { minting_denoms: denoms }))
    }

    async fn get_minters(
        &self,
        request: Request<GetMintersRequest>,
    ) -> Result<Response<GetMintersResponse>, Status> {
        let config = APP.config();

        let req = request.into_inner();

        let client =
            WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await?;

        let query_msg = QueryMsg::Tf(TokenfactoryQuery::Minters {
            address: req.address,
            denom: req.denom,
        });

        let resp = client
            .query_smart_contract::<QueryMsg, MintersResponse>(
                config.chain_node.tokenfactory_contract.clone(),
                query_msg,
            )
            .await
            .map_err(|e| Status::internal(e.to_string()))?;

        Ok(Response::new(GetMintersResponse {
            address: resp.address,
            allowance_denom: resp.allowance.denom,
            allowance_value: resp.allowance.amount.to_string(),
        }))
    }

    async fn get_all_minters(
        &self,
        request: Request<GetAllMintersRequest>,
    ) -> Result<Response<GetAllMintersResponse>, Status> {
        let config = APP.config();

        let _req = request.into_inner();

        let client =
            WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await?;

        let query_msg = QueryMsg::Tf(TokenfactoryQuery::AllMinters {});

        let resp = client
            .query_smart_contract::<QueryMsg, AllMintersResponse>(
                config.chain_node.tokenfactory_contract.clone(),
                query_msg,
            )
            .await
            .map_err(|e| Status::internal(e.to_string()))?;

        let mut minters = vec![];
        for m in resp.minters {
            minters.push(GetMintersResponse {
                address: m.address,
                allowance_denom: m.allowance.denom,
                allowance_value: m.allowance.amount.to_string(),
            })
        }

        Ok(Response::new(GetAllMintersResponse { minters }))
    }

    async fn get_blacklister(
        &self,
        request: Request<GetBlacklisterRequest>,
    ) -> Result<Response<GetBlacklisterResponse>, Status> {
        let config = APP.config();

        let _req = request.into_inner();

        let client =
            WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await?;

        let query_msg = QueryMsg::Tf(TokenfactoryQuery::Blacklister {});

        let resp = client
            .query_smart_contract::<QueryMsg, BlacklisterResponse>(
                config.chain_node.tokenfactory_contract.clone(),
                query_msg,
            )
            .await
            .map_err(|e| Status::internal(e.to_string()))?;

        Ok(Response::new(GetBlacklisterResponse {
            address: resp.address,
        }))
    }

    async fn get_pauser(
        &self,
        request: Request<GetPauserRequest>,
    ) -> Result<Response<GetPauserResponse>, Status> {
        let config = APP.config();

        let _req = request.into_inner();

        let client =
            WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await?;

        let query_msg = QueryMsg::Tf(TokenfactoryQuery::Pauser {});

        let resp = client
            .query_smart_contract::<QueryMsg, PauserResponse>(
                config.chain_node.tokenfactory_contract.clone(),
                query_msg,
            )
            .await
            .map_err(|e| Status::internal(e.to_string()))?;

        Ok(Response::new(GetPauserResponse {
            address: resp.address,
        }))
    }

    async fn get_blacklisted(
        &self,
        request: Request<GetBlacklistedRequest>,
    ) -> Result<Response<GetBlacklistedResponse>, Status> {
        let config = APP.config();

        let req = request.into_inner();

        let client =
            WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await?;

        let query_msg = QueryMsg::Tf(TokenfactoryQuery::Blacklisted {
            address: req.address,
        });

        let resp = client
            .query_smart_contract::<QueryMsg, BlacklistedResponse>(
                config.chain_node.tokenfactory_contract.clone(),
                query_msg,
            )
            .await
            .map_err(|e| Status::internal(e.to_string()))?;

        Ok(Response::new(GetBlacklistedResponse {
            address: resp.address,
        }))
    }

    async fn get_all_blacklisted(
        &self,
        request: Request<GetAllBlacklistedRequest>,
    ) -> Result<Response<GetAllBlacklistedResponse>, Status> {
        let config = APP.config();

        let _req = request.into_inner();

        let client =
            WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await?;

        let query_msg = QueryMsg::Tf(TokenfactoryQuery::AllBlacklisted {});

        let resp = client
            .query_smart_contract::<QueryMsg, AllBlacklistedResponse>(
                config.chain_node.tokenfactory_contract.clone(),
                query_msg,
            )
            .await
            .map_err(|e| Status::internal(e.to_string()))?;

        let mut blacklisted = vec![];
        for b in resp.blacklisted {
            blacklisted.push(GetBlacklistedResponse { address: b.address })
        }

        Ok(Response::new(GetAllBlacklistedResponse { blacklisted }))
    }

    async fn get_paused(
        &self,
        request: Request<GetPausedRequest>,
    ) -> Result<Response<GetPausedResponse>, Status> {
        let config = APP.config();

        let _req = request.into_inner();

        let client =
            WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await?;

        let query_msg = QueryMsg::Tf(TokenfactoryQuery::Paused {});

        let resp = client
            .query_smart_contract::<QueryMsg, PausedResponse>(
                config.chain_node.tokenfactory_contract.clone(),
                query_msg,
            )
            .await
            .map_err(|e| Status::internal(e.to_string()))?;

        Ok(Response::new(GetPausedResponse {
            paused: resp.paused,
        }))
    }

    async fn find_metadata_for_denom(
        &self,
        request: Request<FindMetadataForDenomRequest>,
    ) -> Result<Response<FindDenomMetadataResponse>, Status> {
        let config = APP.config();

        let req = request.into_inner();

        let client =
            WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await?;

        let query_msg = QueryMsg::Bank(BankQuery::FindMetadataForDenom {
            denom: req.denom.to_owned(),
        });

        let resp = client
            .query_smart_contract::<QueryMsg, TfFindDenomMetadataResponse>(
                config.chain_node.tokenfactory_contract.clone(),
                query_msg,
            )
            .await
            .map_err(|e| {
                error!(
                    "***** failed to find metadata for denom {}: {}",
                    req.denom,
                    e.to_string()
                );
                Status::internal(e.to_string())
            })?;

        Ok(Response::new(FindDenomMetadataResponse {
            description: resp.description,
            base: resp.base,
            display: resp.display,
            name: resp.name,
            symbol: resp.symbol,
            denom: resp.denom,
            exponent: resp.exponent,
            aliases: resp.aliases,
        }))
    }

    // aurum query
    async fn get_aurum_config(
        &self,
        request: Request<GetAurumConfigRequest>,
    ) -> Result<Response<GetAurumConfigResponse>, Status> {
        let config = APP.config();

        let _req = request.into_inner();

        let client =
            WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await?;

        let query_msg = AurumQueryMsg::Config {};

        let resp = client
            .query_smart_contract::<AurumQueryMsg, AurumConfigResponse>(
                config.chain_node.aurum_contract.clone(),
                query_msg,
            )
            .await
            .map_err(|e| Status::internal(e.to_string()))?;

        Ok(Response::new(GetAurumConfigResponse {
            owner: resp.owner.to_string(),
            tf_address: resp.tf_address.to_string(),
        }))
    }

    async fn update_member(
        &self,
        request: Request<UpdateMemberRequest>,
    ) -> Result<Response<UpdateMemberResponse>, Status> {
        let config = APP.config();

        let req = request.into_inner();

        #[cfg(feature = "p11hsm")]
        let (_vk, _pk, _account_id) = get_pub_key_from_label(
            config.provider.p11hsm.key_label.clone(),
            config.chain_node.prefix.clone(),
        )
        .await?;

        #[cfg(feature = "tsstrio")]
        let (_vk, _pk, _account_id) = {
            let vk = APP.sdk().lock().unwrap().verifying_key().unwrap();
            get_pub_key(vk, config.chain_node.prefix.clone()).await?
        };

        let execute_msg = AurumExecuteMsg::UpdateMember {
            req: MemberState {
                id: req.id.to_owned(),
                addr: Addr::unchecked(req.addr),
                pubkey: req.pubkey,
                grpc: req.grpc,
            },
        };

        let execute_msg = serde_json::to_vec(&execute_msg).map_err(|e| {
            error!("***** failed to_vec: {}", e.to_string());
            Status::invalid_argument(e.to_string())
        })?;

        let response = self
            .broadcast_cw_tx(config.chain_node.aurum_contract.clone(), execute_msg, None)
            .await
            .map_err(|e| {
                error!("***** failed to broadcast_cw_tx: {}", e.to_string());
                Status::internal(e.to_string())
            })?;

        Ok(Response::new(UpdateMemberResponse {
            id: req.id,
            txhash: match response.tx_response {
                Some(tx) => tx.txhash,
                None => return Err(Status::internal("txhash unavailable".to_string())),
            },
        }))
    }

    async fn get_member(
        &self,
        request: Request<GetMemberRequest>,
    ) -> Result<Response<GetMemberResponse>, Status> {
        let config = APP.config();

        let req = request.into_inner();

        let client =
            WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await?;

        let query_msg = AurumQueryMsg::MemberState { id: req.id };

        let resp = client
            .query_smart_contract::<AurumQueryMsg, MemberState>(
                config.chain_node.aurum_contract.clone(),
                query_msg,
            )
            .await
            .map_err(|e| Status::internal(e.to_string()))?;

        Ok(Response::new(GetMemberResponse {
            id: resp.id,
            addr: resp.addr.to_string(),
            pubkey: resp.pubkey,
            grpc: resp.grpc,
        }))
    }

    async fn get_members(
        &self,
        request: Request<GetMembersRequest>,
    ) -> Result<Response<GetMembersResponse>, Status> {
        let config = APP.config();

        let _req = request.into_inner();

        let client =
            WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await?;

        let query_msg = AurumQueryMsg::MemberStates {};

        let resp = client
            .query_smart_contract::<AurumQueryMsg, MemberStates>(
                config.chain_node.aurum_contract.clone(),
                query_msg,
            )
            .await
            .map_err(|e| Status::internal(e.to_string()))?; // convert to Any

        let mut members = vec![];
        for m in resp.members {
            members.push(GetMemberResponse {
                id: m.id,
                addr: m.addr.to_string(),
                pubkey: m.pubkey,
                grpc: m.grpc,
            })
        }

        Ok(Response::new(GetMembersResponse { members }))
    }

    // get_aurum_balance
    // this fn should not panic because process_aurum_balance uses it.
    async fn get_aurum_balance(
        &self,
        request: Request<BalanceRequest>,
    ) -> Result<Response<BalanceResponse>, Status> {
        let req = request.get_ref();
        self.get_aurum_balance(req).await

        /*
        let config = APP.config();

        let mut client = WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await?;

        let query_msg = AurumQueryMsg::Balance {
            req: convert_balance_request(&req),
        };

        let resp = client.wasm_query_contract::<AurumQueryMsg, AurumBalanceResponse>(config.chain_node.aurum_contract.clone(), query_msg).await
            .map_err(|e| {
                error!("***** failed get_aurum_balance: {}", e.to_string());
                Status::internal(e.to_string())
            })?;

        Ok(Response::new(convert_balance_response(resp)))
        */
    }

    // process_aurum_balance is client facing similar to process_aurum_tx.
    // it wraps get_aurum_balance and always returns Ok.
    async fn process_aurum_balance(
        &self,
        request: Request<BalanceRequest>,
    ) -> Result<Response<BalanceResponse>, Status> {
        let req = request.get_ref();
        let res = self.get_aurum_balance(req).await;
        match res {
            Ok(r) => return Ok(r),
            Err(e) => {
                error!("***** failed process_aurum_balance: {}", e.to_string());
                return Ok(Response::new(BalanceResponse {
                    status: TransactionStatus::Error.as_str_name().to_string(),
                    message: Some(BalanceError {
                        error_code: (ErrorCode::DataNotFound as i32).to_string(),
                        error_description: e.to_string(),
                    }),
                    data: Some(CashResponse {
                        party: req.party.to_owned(),
                        amount: "".to_string(),
                        currency: req.currency.to_owned(),
                        tracking_id: req.tracking_id.to_owned(),
                        ref_number: req.ref_number.to_owned(),
                        request_date_time: req.ref_number.to_owned(),
                    }),
                }));
            }
        }
    }

    // aurum_tx executes an aurum tx: funding, payment, or defunding
    // note: it will not panic so the caller will always get result.
    async fn aurum_tx(
        &self,
        request: Request<PaymentRequest>,
    ) -> Result<Response<PaymentTxResponse>, Status> {
        let req = request.get_ref();

        self.execute_aurum_tx(req).await
    }

    async fn get_payment_state(
        &self,
        request: Request<PaymentStateRequest>,
    ) -> Result<Response<PaymentStateResponse>, Status> {
        let config = APP.config();

        #[cfg(feature = "p11hsm")]
        let (_vk, _pk, _account_id) = get_pub_key_from_label(
            config.provider.p11hsm.key_label.clone(),
            config.chain_node.prefix.clone(),
        )
        .await?;

        #[cfg(feature = "tsstrio")]
        let (_vk, _pk, _account_id) = {
            let vk = APP.sdk().lock().unwrap().verifying_key().unwrap();
            get_pub_key(vk, config.chain_node.prefix.clone()).await?
        };

        let req = request.into_inner();

        let client =
            WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await?;

        let query_msg = AurumQueryMsg::PaymentState {
            tracking_id: req.tracking_id,
        };

        let resp = client
            .query_smart_contract::<AurumQueryMsg, AurumPaymentStateResponse>(
                config.chain_node.aurum_contract.clone(),
                query_msg,
            )
            .await
            .map_err(|e| Status::internal(e.to_string()))?;

        Ok(Response::new(convert_payment_state_response(
            resp, None, None, None, None, None,
        )))
    }

    // process_aurum_tx handles end-to-end:
    //   it accepts MQ listener request and responds back with the result of aurum tx processing.
    // it calls aurum_tx to handle on-chain money movement and payment_state.
    //  if err, includes error code in notify sender response
    // if ok, it polls txhash for the final aurum tx commitment result.
    //  if poll times out, it includes error code in notify sender response
    // if ok, it updates payment state with txhash.
    //  if err, includes error code in notify sender response
    // if ok, it polls txhash for the final update_txhash commitment result.
    //  if polls times out, it includes error code in notify sender response
    // x use websocket instead - if ok, it calls the other member's from_member endpoint to notify the member of the tx result.
    // notifies sender of success.
    // Note: it always return Ok, even in case of error.
    async fn process_aurum_tx(
        &self,
        request: Request<PaymentRequest>,
    ) -> Result<Response<PaymentResponse>, Status> {
        let config = APP.config();
        let req = request.get_ref();

        // execute aurum tx
        info!(
            "***** process_aurum_tx - execute_aurum_tx - tracking_id: {}",
            req.tracking_id
        );
        let res = self.execute_aurum_tx(req).await;
        if let Err(e) = res {
            let resp = payment_request_to_payment_response(
                req,
                NotificationType::Notifysender,
                PaymentStatus::Error,
                TransactionStatus::Error,
                ErrorCode::CordaFlowFailed,
                ErrorCode::CordaFlowFailed.as_str_name().to_string(),
            );

            error!(
                "***** failed process_aurum_tx - execute_aurum_tx - tracking_id {}: {} {} {};",
                req.tracking_id,
                e.code().to_string(),
                e.message(),
                e.to_string()
            );

            return Ok(Response::new(resp));
        };
        // it is safe to unwrap.
        let payment_tx_response = res.unwrap().into_inner();

        let pool_resp = self.pool_txhash(payment_tx_response.txhash.clone()).await?;
        /*
        let res = WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await;
        if let Err(e) = res {
            let resp = payment_request_to_payment_response(
                req,
                NotificationType::Notifysender,
                PaymentStatus::Error,
                TransactionStatus::Error,
                ErrorCode::CordaFlowFailed,
                e.to_string(),
            );

            error!("***** failed process_aurum_tx - get_cosmos_grpc_client - tracking_id {} txhash {}: {} {} {};",
                req.tracking_id,
                payment_tx_response.txhash,
                e.code().to_string(),
                e.message(),
                e.to_string());

            return Ok(Response::new(resp));
        };
        // it is safe to unwrap
        let mut client = res.unwrap();

        // poll aurum tx
        let interval = Duration::from_millis(config.chain_node.tx_poll_interval);
        let time_out = Duration::from_millis(config.chain_node.tx_poll_timeout);
        let deadline = Instant::now() + time_out;
        info!(
            "***** process_aurum_tx - poll aurum tx get_tx - tracking_id: {}; txhash: {}",
            req.tracking_id, payment_tx_response.txhash
        );
        let tx_resp = loop {
            let res = client
                .clients
                .tx
                .get_tx(GetTxRequest {
                    hash: payment_tx_response.txhash.clone(),
                })
                .await;
            if let Ok(resp) = res {
                break resp.into_inner();
            }

            tokio::time::sleep(interval).await;
            if Instant::now() > deadline {
                // it is safe to unwrap.
                let e = res.unwrap_err();
                let resp = payment_request_to_payment_response(
                    req,
                    NotificationType::Notifysender,
                    PaymentStatus::Error,
                    TransactionStatus::Error,
                    ErrorCode::CordaFlowFailed,
                    e.to_string(),
                );
                error!("***** failed process_aurum_tx - aurum get_tx timed out - tracking_id {} txhash {}: {} {} {}",
                    req.tracking_id,
                    payment_tx_response.txhash,
                    e.code().to_string(),
                    e.message(),
                    e.to_string());

                return Ok(Response::new(resp));
                // return Err(Status::deadline_exceeded("tx not found".to_string()))
            }
        };
        let tx_response = tx_resp.tx_response.unwrap();
        */
        let tx_response = pool_resp.tx_response.ok_or(Status::internal(
            "pool tx got None for tx_response".to_string(),
        ))?;

        info!("***** process_aurum_tx - got aurum tx - tracking_id {} txhash {} height {} gas_wanted {} gas_used {} num_events {}", req.tracking_id, tx_response.txhash, tx_response.height, tx_response.gas_wanted, tx_response.gas_used, tx_response.events.len());

        // update payment state with txhash
        info!(
            "***** process_aurum_tx - update_txhash - tracking_id: {} txhash {}",
            req.tracking_id, tx_response.txhash
        );

        let execute_msg = AurumExecuteMsg::UpdateTxhash {
            tracking_id: req.tracking_id.clone(),
            txhash: tx_response.txhash,
        };
        let execute_msg = serde_json::to_vec(&execute_msg)
            .map_err(|e| Status::invalid_argument(e.to_string()))?;
        let res = self
            .broadcast_cw_tx(config.chain_node.aurum_contract.clone(), execute_msg, None)
            .await;
        if let Err(e) = res {
            let resp = payment_request_to_payment_response(
                req,
                NotificationType::Notifysender,
                PaymentStatus::Error,
                TransactionStatus::Error,
                ErrorCode::CordaFlowFailed,
                e.to_string(),
            );
            error!(
                "***** failed process_aurum_tx - update_txhash - tracking_id {} txhash {}: {};",
                req.tracking_id,
                payment_tx_response.txhash.clone(),
                e.to_string()
            );
            return Ok(Response::new(resp));
        }

        // it is safe to unwrap
        let update_tx_response = res.unwrap().tx_response.unwrap();

        let pool_resp = self.pool_txhash(update_tx_response.txhash).await?;
        let tx_response = pool_resp.tx_response.ok_or(Status::internal(
            "pool tx got None for tx_response".to_string(),
        ))?;
        /*
        // poll update_txhash tx
        let interval = Duration::from_millis(config.chain_node.tx_poll_interval);
        let time_out = Duration::from_millis(config.chain_node.tx_poll_timeout);
        let deadline = Instant::now() + time_out;
        info!(
            "***** process_aurum_tx - poll update_txhash tx get_tx - tracking_id: {}; txhash: {}",
            req.tracking_id, update_tx_response.txhash
        );
        let tx_resp = loop {
            let res = client
                .clients
                .tx
                .get_tx(GetTxRequest {
                    hash: update_tx_response.txhash.clone(),
                })
                .await;
            if let Ok(resp) = res {
                break resp.into_inner();
            }

            tokio::time::sleep(interval).await;
            if Instant::now() > deadline {
                // it is safe to unwrap.
                let e = res.unwrap_err();
                let resp = payment_request_to_payment_response(
                    req,
                    NotificationType::Notifysender,
                    PaymentStatus::Error,
                    TransactionStatus::Error,
                    ErrorCode::CordaFlowFailed,
                    e.to_string(),
                );
                error!("***** failed process_aurum_tx - update_txhash get_tx timed out - tracking_id {} txhash {}: {} {} {}",
                    req.tracking_id,
                    update_tx_response.txhash,
                    e.code().to_string(),
                    e.message(),
                    e.to_string());

                return Ok(Response::new(resp));
                // return Err(Status::deadline_exceeded("tx not found".to_string()))
            }
        };
        let tx_response = tx_resp.tx_response.unwrap();
        */
        info!("***** process_aurum_tx - got update_txhash tx - tracking_id {} txhash {} height {} gas_wanted {} gas_used {} num_events {}", req.tracking_id, tx_response.txhash, tx_response.height, tx_response.gas_wanted, tx_response.gas_used, tx_response.events.len());

        // query payment state
        info!(
            "***** process_aurum_tx - query payment state - tracking_id: {}",
            req.tracking_id
        );
        let query_msg = AurumQueryMsg::PaymentState {
            tracking_id: req.tracking_id.clone(),
        };

        let client =
            WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await?;

        let res = client
            .query_smart_contract::<AurumQueryMsg, AurumPaymentStateResponse>(
                config.chain_node.aurum_contract.clone(),
                query_msg,
            )
            .await;
        // TODO: this error handling may be redundant since the success of update_txhash above should guarantee res is Some.
        if let Err(e) = res {
            let resp = payment_request_to_payment_response(
                req,
                NotificationType::Notifysender,
                PaymentStatus::Error,
                TransactionStatus::Error,
                ErrorCode::CordaFlowFailed,
                e.to_string(),
            );
            error!("***** failed process_aurum_tx - query payment state - tracking_id {} txhash {}: {};",
                req.tracking_id,
                payment_tx_response.txhash,
                e.to_string());

            return Ok(Response::new(resp));
        };

        // it is safe to unwrap
        let payment_state_response = res.unwrap();
        assert_eq!(
            payment_state_response.txhash.clone().unwrap(),
            payment_tx_response.txhash
        );

        // skip calling beneficiary's from_member; it is replaced by websocket
/*
        // beneficiary
        let beneficiary_id = convert_x500_name(req.beneficiary_party.to_owned().unwrap()).id();
        let res = self
            .get_member(Request::new(GetMemberRequest {
                id: beneficiary_id.clone(),
            }))
            .await;
        if let Err(e) = res {
            let resp = payment_request_to_payment_response(
                req,
                NotificationType::Notifysender,
                PaymentStatus::Error,
                TransactionStatus::Error,
                ErrorCode::InvalidParty,
                ErrorCode::InvalidParty.as_str_name().to_string(),
            );
            error!("***** failed process_aurum_tx - beneficiary get_member - tracking_id: {} beneficiary_id: {}; {}",
                req.tracking_id,
                beneficiary_id,
                e.to_string());
            return Ok(Response::new(resp));
        };
        let beneficiary = res.unwrap().into_inner();
        // TODO: only payment and defunding need to notify member
        // TODO: should calling from_member be in another thread?
        let uri = format!("http://{}", beneficiary.grpc);
        info!(
            "***** process_aurum_tx - connect member - tracking_id: {}; uri: {}",
            req.tracking_id, uri
        );
        let res = WalletClient::connect(uri).await;
        // let res = WalletClient::connect("http:://localhost:8092").await;
        if let Err(e) = res {
            let resp = payment_request_to_payment_response(
                req,
                NotificationType::Notifysender,
                PaymentStatus::Error,
                TransactionStatus::Error,
                ErrorCode::CordaFlowFailed,
                e.to_string(),
            );
            error!(
                "***** failed process_aurum_tx - connect member - tracking_id {} txhash {}: {};",
                req.tracking_id,
                payment_tx_response.txhash,
                e.to_string()
            );
            return Ok(Response::new(resp));
        };

        // it is safe to unwrap
        let mut member_client = res.unwrap();
        info!(
            "***** process_aurum_tx - call from_member - tracking_id: {}; txhash: {}",
            req.tracking_id, payment_tx_response.txhash
        );
        let res = member_client
            .from_member(Request::new(FromMemberRequest {
                txhash: payment_tx_response.txhash.to_owned(),
                tracking_id: req.tracking_id.clone(),
            }))
            .await;

        if let Err(e) = res {
            let resp = payment_request_to_payment_response(
                req,
                NotificationType::Notifysender,
                PaymentStatus::Error,
                TransactionStatus::Error,
                ErrorCode::CordaFlowFailed,
                e.to_string(),
            );
            error!(
                "***** failed process_aurum_tx - from_member - tracking_id {} txhash {}: {};",
                req.tracking_id,
                payment_tx_response.txhash,
                e.to_string()
            );
            return Ok(Response::new(resp));
        };
*/

        // notify sender of success
        info!(
            "***** process_aurum_tx - notify sender - tracking_id: {}; txhash: {}",
            req.tracking_id, payment_tx_response.txhash
        );
        let payment_state_response = convert_payment_state_response(
            payment_state_response,
            Some(NotificationType::Notifysender),
            Some(PaymentStatus::Success),
            Some(TransactionStatus::Success),
            Some(ErrorCode::Unspecified),
            Some(ErrorCode::Unspecified.as_str_name().to_string()),
        );

        Ok(Response::new(payment_state_response.resp.unwrap()))
    }

    // from_member process member's notification of aurum tx completion
    // it validates the txhash on chain
    // it validates payment state
    // send transfer notification to MQ
    // it return transfer notification response
    // todo: potentially add more data to FromMemberRequest such as originator, beneficiary, amount, denom for deeper validation.
    async fn from_member(
        &self,
        request: Request<FromMemberRequest>,
    ) -> Result<Response<PaymentResponse>, Status> {
        let config = APP.config();

        let req = request.into_inner();
        let tracking_id = req.tracking_id.clone();
        // txhash1 is the Fund/Pay/Defund tx hash
        let txhash1 = req.txhash1.clone();
        // txhash2 is the UpdateTxhash tx hash
        let txhash2 = req.txhash2.clone();

        let pool_resp = self.pool_txhash(txhash2.clone()).await?;
        let tx_response = pool_resp.tx_response.ok_or(Status::internal(
            "pool tx got None for tx_response".to_string(),
        ))?;
        /*

        let mut client =
            WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await?;

        info!(
            "***** from_member - get_tx - tracking_id: {}; txhash: {}",
            req.tracking_id, req.txhash
        );
        let res = client
            .clients
            .tx
            .get_tx(GetTxRequest {
                hash: txhash.clone(),
            })
            .await
            .map_err(|e| {
                error!(
                    "***** failed from_member - get_tx - txhash {}: {};",
                    txhash,
                    e.to_string()
                );
                Status::internal(e.to_string())
            })?;

        let tx_response = res.into_inner().tx_response.unwrap();
        */
        info!("***** from_member - got tx - tracking_id {} txhash {} height {} gas_wanted {} gas_used {} num_events {}", req.tracking_id, tx_response.txhash, tx_response.height, tx_response.gas_wanted, tx_response.gas_used, tx_response.events.len());

        info!(
            "***** from_member - query payment state - tracking_id: {}",
            req.tracking_id
        );
        let query_msg = AurumQueryMsg::PaymentState {
            tracking_id: tracking_id.clone(),
        };

        let client =
            WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await?;

        let payment_state_response = client.query_smart_contract::<AurumQueryMsg, AurumPaymentStateResponse>(config.chain_node.aurum_contract.clone(), query_msg).await
            .map_err(|e| {
                error!("***** failed from_member - query payment state - tracking_id {} txhash {}: {};",
                    tracking_id,
                    txhash1,
                    e.to_string());
                Status::internal(e.to_string())
            })?;

        // ensure txhash matches
        if payment_state_response.txhash.is_none() {
            error!("***** failed from_member - missing txhash in payment state - tracking_id {} expected txhash {}", tracking_id, txhash1);
            return Err(Status::invalid_argument(
                "missing txhash in payment state".to_string(),
            ));
        };

        let ps_txhash = payment_state_response.txhash.clone().unwrap();
        if !ps_txhash.eq(&txhash1) {
            error!("***** failed from_member - txhash mismatch - tracking_id {} expected txhash {} actual txhash {}", tracking_id, txhash1, ps_txhash);
            return Err(Status::invalid_argument("txhash mismatch".to_string()));
        };

        info!(
            "***** from_member - notification - tracking_id: {}",
            req.tracking_id
        );
        let payment_state_response = convert_payment_state_response(
            payment_state_response,
            Some(NotificationType::Transfernotification),
            Some(PaymentStatus::Success),
            Some(TransactionStatus::Success),
            Some(ErrorCode::Unspecified),
            Some(ErrorCode::Unspecified.as_str_name().to_string()),
        );

        // send payment_state_response to MQ
        let payment_resp = payment_state_response.resp.unwrap();
        let payload = serde_json::to_string(&payment_resp)
            .map_err(|e| Status::invalid_argument(format!("json to_string error: {}", e)))?;

        let topic_string = self.payment_type_to_transfernotification_topic_string(
            &config.ibm_mq,
            &payment_resp.payment_type,
        );
        info!("post topic string: {}", topic_string);

        if !topic_string.is_empty() {
            let post_resp = self
                .post_mq_message_to_topic(Request::new(PostMqMessageToTopicRequest {
                    topic_string,
                    message: payload.clone(),
                }))
                .await?
                .into_inner();
            info!(
                "transfer notification sent - tracking_id: {}; status {}; return data: {}",
                payment_resp.tracking_id, post_resp.status, post_resp.ret_data
            );
        }

        Ok(Response::new(payment_resp))
    }

    // grant_fee_basic_allowance grants a basic allowance to grantee
    // if the wallet is faucet, do the grant; ow, call faucet's grant_fee_basic_allowance.
    // if there is an existing allowance and it has expired, revoke it first.
    async fn grant_fee_basic_allowance(
        &self,
        request: Request<GrantFeeBasicAllowanceRequest>,
    ) -> Result<Response<GrantFeeBasicAllowanceResponse>, Status> {
        let config = APP.config();

        #[cfg(feature = "p11hsm")]
        let (_vk, _pk, account_id) = get_pub_key_from_label(
            config.provider.p11hsm.key_label.clone(),
            config.chain_node.prefix.clone(),
        )
        .await?;

        #[cfg(feature = "tsstrio")]
        let (_vk, _pk, account_id) = {
            let vk = APP.sdk().lock().unwrap().verifying_key().unwrap();
            get_pub_key(vk, config.chain_node.prefix.clone()).await?
        };

        if account_id.to_string() != config.faucet.address {
            return Err(Status::permission_denied("not faucet".to_string()));
        }

        let granter = config.faucet.address.clone();

        let req = request.into_inner();

        let get_req = GetFeeBasicAllowanceRequest {
            grantee: Some(req.grantee.clone()),
        };

        let get_resp = self.get_fee_basic_allowance(Request::new(get_req)).await;
        if get_resp.is_ok() {
            let resp = get_resp.unwrap().into_inner();
            let grant = resp.fee_basic_grant.unwrap();
            let format = format_description::parse(
                "[year]-[month]-[day] [hour]:[minute]:[second].[subsecond] [offset_hour sign:mandatory][offset_minute] UTC",
                // "[year]-[month]-[day] [hour]:[minute]:[second].[subsecond] [offset_hour sign:mandatory][offset_minute][offset_second] UTC",
            ).unwrap();

            let expiration = time::OffsetDateTime::parse(&grant.expiration, &format).unwrap();
            if expiration.le(&time::OffsetDateTime::now_utc()) {
                let revoke_req = RevokeFeeAllowanceRequest {
                    grantee: req.grantee.clone(),
                };

                let revoke_resp = self.revoke_fee_allowance(Request::new(revoke_req)).await;
                if revoke_resp.is_err() {
                    return Err(revoke_resp.err().unwrap());
                }
                let revoke_resp = revoke_resp.unwrap().into_inner();

                let pool_resp = self.pool_txhash(revoke_resp.txhash).await?;
                let tx_response = pool_resp.tx_response.ok_or(Status::internal(
                    "pool tx got None for tx_response".to_string(),
                ))?;
                /*
                // poll tx
                let res =
                    WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await;
                let mut client = res.unwrap();
                let interval = Duration::from_millis(config.chain_node.tx_poll_interval);
                let time_out = Duration::from_millis(config.chain_node.tx_poll_timeout);
                let deadline = Instant::now() + time_out;
                info!(
                    "***** grant_fee_basic_allowance - poll revoke tx get_tx - txhash: {}",
                    revoke_resp.txhash
                );
                let tx_resp = loop {
                    let res = client
                        .clients
                        .tx
                        .get_tx(GetTxRequest {
                            hash: revoke_resp.txhash.clone(),
                        })
                        .await;

                    if let Ok(resp) = res {
                        break resp.into_inner();
                    }

                    tokio::time::sleep(interval).await;
                    if Instant::now() > deadline {
                        // it is safe to unwrap.
                        let e = res.unwrap_err();
                        error!("***** failed grant_fee_basic_allowance - poll revoke tx get_tx timed out - txhash {}; error: {}", revoke_resp.txhash, e);

                        return Err(Status::deadline_exceeded("tx not found".to_string()));
                    }
                };
                let tx_response = tx_resp.tx_response.unwrap();
                */
                info!("***** grant_fee_basic_allowance - got revoke tx - txhash {} height {} gas_wanted {} gas_used {} num_events {}", tx_response.txhash, tx_response.height, tx_response.gas_wanted, tx_response.gas_used, tx_response.events.len());
            } else {
                return Err(Status::internal(
                    "there is an existing grant in effect".to_string(),
                ));
            }
        };

        let allowance_value: u128 = req.allowance_value.parse().map_err(|_| {
            Status::invalid_argument("allowance_value must be a valid u128 number")
        })?;
        let config_allowance_value: u128 = config.faucet.allowance_value.parse().map_err(|_| {
            Status::invalid_argument("allowance_value must be a valid u128 number")
        })?;

        let allowance_value = config_allowance_value.min(allowance_value);
        let hours_to_expire = config.faucet.hours_to_expire.min(req.hours_to_expire);
        let execute_msg = ExecuteMsg::Feegrant(FeegrantContractMsg::GrantFeeBasicAllowance {
            granter,
            grantee: req.grantee,
            allowance_denom: config.chain_node.gas_denom.clone(),
            allowance_value: allowance_value.to_string(),
            hours_to_expire,
        });

        let execute_msg = serde_json::to_vec(&execute_msg)
            .map_err(|e| Status::invalid_argument(e.to_string()))?;

        let response = self
            .broadcast_cw_tx(
                config.chain_node.tokenfactory_contract.clone(),
                execute_msg,
                None,
            )
            .await?;

        Ok(Response::new(GrantFeeBasicAllowanceResponse {
            txhash: match response.tx_response {
                Some(tx) => tx.txhash,
                None => return Err(Status::internal("txhash unavailable".to_string())),
            },
        }))
    }

    async fn revoke_fee_allowance(
        &self,
        request: Request<RevokeFeeAllowanceRequest>,
    ) -> Result<Response<RevokeFeeAllowanceResponse>, Status> {
        let config = APP.config();

        #[cfg(feature = "p11hsm")]
        let (_vk, _pk, account_id) = get_pub_key_from_label(
            config.provider.p11hsm.key_label.clone(),
            config.chain_node.prefix.clone(),
        )
        .await?;

        #[cfg(feature = "tsstrio")]
        let (_vk, _pk, account_id) = {
            let vk = APP.sdk().lock().unwrap().verifying_key().unwrap();
            get_pub_key(vk, config.chain_node.prefix.clone()).await?
        };

        if account_id.to_string() != config.faucet.address {
            return Err(Status::permission_denied("not faucet".to_string()));
        }

        let req = request.into_inner();

        let execute_msg = ExecuteMsg::Feegrant(FeegrantContractMsg::RevokeFeeAllowance {
            granter: config.faucet.address.clone(),
            grantee: req.grantee,
        });

        let execute_msg = serde_json::to_vec(&execute_msg)
            .map_err(|e| Status::invalid_argument(e.to_string()))?;

        let response = self
            .broadcast_cw_tx(
                config.chain_node.tokenfactory_contract.clone(),
                execute_msg,
                None,
            )
            .await?;

        Ok(Response::new(RevokeFeeAllowanceResponse {
            txhash: match response.tx_response {
                Some(tx) => tx.txhash,
                None => return Err(Status::internal("txhash unavailable".to_string())),
            },
        }))
    }

    async fn get_fee_basic_allowance(
        &self,
        request: Request<GetFeeBasicAllowanceRequest>,
    ) -> Result<Response<GetFeeBasicAllowanceResponse>, Status> {
        let config = APP.config();

        #[cfg(feature = "p11hsm")]
        let (_vk, _pk, account_id) = get_pub_key_from_label(
            config.provider.p11hsm.key_label.clone(),
            config.chain_node.prefix.clone(),
        )
        .await?;

        #[cfg(feature = "tsstrio")]
        let (_vk, _pk, account_id) = {
            let vk = APP.sdk().lock().unwrap().verifying_key().unwrap();
            get_pub_key(vk, config.chain_node.prefix.clone()).await?
        };

        let req = request.into_inner();

        let grantee = match req.grantee {
            Some(g) => g,
            None => account_id.to_string(),
        };

        let client =
            WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await?;

        let query_msg = QueryMsg::Feegrant(FeegrantQuery::FeeBasicAllowance {
            granter: config.faucet.address.clone(),
            grantee,
        });

        let resp = client
            .query_smart_contract::<QueryMsg, FeeBasicAllowanceResponse>(
                config.chain_node.tokenfactory_contract.clone(),
                query_msg,
            )
            .await
            .map_err(|e| {
                // error!("***** failed fee_basic_allowance: {}", e.to_string());
                Status::internal(e.to_string())
            })?;

        Ok(Response::new(GetFeeBasicAllowanceResponse {
            fee_basic_grant: Some(GetFeeBasicGrant {
                granter: resp.allowance.granter,
                grantee: resp.allowance.grantee,
                allowance_denom: resp.allowance.allowance.denom,
                allowance_value: resp.allowance.allowance.amount.to_string(),
                expiration: resp.allowance.expiration,
            }),
        }))
    }

    async fn request_fee_basic_allowance(
        &self,
        request: Request<RequestFeeBasicAllowanceRequest>,
    ) -> Result<Response<RequestFeeBasicAllowanceResponse>, Status> {
        let config = APP.config();

        #[cfg(feature = "p11hsm")]
        let (_vk, _pk, account_id) = get_pub_key_from_label(
            config.provider.p11hsm.key_label.clone(),
            config.chain_node.prefix.clone(),
        )
        .await?;

        #[cfg(feature = "tsstrio")]
        let (_vk, _pk, account_id) = {
            let vk = APP.sdk().lock().unwrap().verifying_key().unwrap();
            get_pub_key(vk, config.chain_node.prefix.clone()).await?
        };

        if account_id.to_string() == config.faucet.address {
            return Err(Status::permission_denied(
                "faucet cannot request fee allowance".to_string(),
            ));
        }

        let uri = format!("http://{}", config.faucet.grpc);
        let mut faucet_client = WalletClient::connect(uri)
            .await
            .map_err(|e| Status::internal(e.to_string()))?;

        let req = request.into_inner();

        let faucet_request = GrantFeeBasicAllowanceRequest {
            grantee: account_id.to_string(),
            allowance_value: req.allowance_value,
            hours_to_expire: req.hours_to_expire,
        };
        let res = faucet_client
            .grant_fee_basic_allowance(Request::new(faucet_request))
            .await;

        Ok(Response::new(RequestFeeBasicAllowanceResponse {
            txhash: match res {
                Ok(r) => r.into_inner().txhash,
                Err(e) => {
                    error!(
                        "***** failed request_fee_basic_allowance: {}",
                        e.to_string()
                    );
                    "".to_string()
                }
            },
        }))
    }

    // ibm mq
    // (manually) get_mq_messsage_from_queue does the following:
    // get message from queue,
    // process_aurum_tx,
    // post message to topic
    // return response from the above
    async fn get_mq_messsage_from_queue(
        &self,
        request: Request<GetMqMesssageFromQueueRequest>,
    ) -> Result<Response<GetMqMesssageFromQueueResponse>, Status> {
        let config = APP.config();

        let req = request.into_inner();

        if !config.ibm_mq.is_queue_valid(req.queue_name.as_str()) {
            return Err(Status::invalid_argument(format!(
                "queue name: {} is invalid",
                req.queue_name
            )));
        }

        let api_req = mq::Request::new_for_queue(&config.ibm_mq, req.queue_name);

        info!("get_mq_message_from_queue - url: {}", api_req.get_url());

        let resp = api_req
            .rest_get(config.ibm_mq.dev_mode)
            .await
            .map_err(|e| Status::internal(format!("get mq message error: {}", e)))?;

        let status = resp.status().to_string();

        let body = resp
            .text_with_charset("utf-8")
            .await
            .map_err(|e| Status::internal(format!("utf-8 parse error: {}", e)))?;

        // call process_aurum_tx
        let payment_req = parse_payment_request::<PaymentRequest>(&body).map_err(|e| {
            Status::invalid_argument(format!("body: {} -  json parse error: {}", body, e))
        })?;

        let tracking_id = payment_req.tracking_id.clone();

        let ret = self.process_payment_request(payment_req).await?;

        Ok(Response::new(GetMqMesssageFromQueueResponse {
            status, // get status
            message: format!("tracking_id: {}; post result: {}", tracking_id, ret),
        }))
    }

    async fn post_mq_message_to_queue(
        &self,
        request: Request<PostMqMessageToQueueRequest>,
    ) -> Result<Response<PostMqMessageResponse>, Status> {
        let config = APP.config();

        let req = request.into_inner();

        if !config.ibm_mq.is_queue_valid(req.queue_name.as_str()) {
            return Err(Status::invalid_argument(format!(
                "queue: {} is invalid",
                req.queue_name
            )));
        }

        let api_req = mq::Request::new_for_queue(&config.ibm_mq, req.queue_name);

        info!("post_mq_message_to_queue - url: {}", api_req.get_url());

        let resp = api_req
            .rest_post(req.message, config.ibm_mq.dev_mode)
            .await
            .map_err(|e| Status::internal(format!("post mq message error: {}", e)))?;

        let status = resp.status().to_string();

        let body = resp
            .text_with_charset("utf-8")
            .await
            .map_err(|e| Status::internal(format!("utf-8 parse error: {}", e)))?;

        Ok(Response::new(PostMqMessageResponse {
            status,
            ret_data: body,
        }))
    }

    async fn post_mq_message_to_topic(
        &self,
        request: Request<PostMqMessageToTopicRequest>,
    ) -> Result<Response<PostMqMessageResponse>, Status> {
        let config = APP.config();

        let req = request.into_inner();

        if !config.ibm_mq.is_topic_valid(req.topic_string.as_str()) {
            return Err(Status::invalid_argument(format!(
                "topic string: {} is invalid",
                req.topic_string
            )));
        }

        let api_req = mq::Request::new_for_topic(&config.ibm_mq, req.topic_string);

        info!("post_mq_message_to_topic - url: {}", api_req.get_url());

        let resp = api_req
            .rest_post(req.message, config.ibm_mq.dev_mode)
            .await
            .map_err(|e| Status::internal(format!("post mq message error: {}", e)))?;

        let status = resp.status().to_string();

        let body = resp
            .text_with_charset("utf-8")
            .await
            .map_err(|e| Status::internal(format!("utf-8 parse error: {}", e)))?;

        Ok(Response::new(PostMqMessageResponse {
            status,
            ret_data: body,
        }))
    }
}
