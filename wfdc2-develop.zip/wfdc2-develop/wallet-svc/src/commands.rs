//! WalletSvc Subcommands
//!
//! This is where you specify the subcommands of your application.
//!
//! The default application comes with two subcommands:
//!
//! - `start`: launches the application
//! - `--version`: print application version
//!
//! See the `impl Configurable` below for how to specify the path to the
//! application's configuration file.

use std::path::PathBuf;

use abscissa_core::{config::Override, Command, Configurable, FrameworkError, Runnable};

use crate::commands::admin::AdminCommand;
use crate::commands::async_echo::AsyncEchoCmd;

#[cfg(feature = "p11hsm")]
use crate::commands::diag::DiagCommand;
#[cfg(feature = "tsstrio")]
use crate::commands::diag::DiagCommand;

use crate::commands::echo::EchoCmd;
use crate::commands::keys::KeysCommand;
use crate::commands::query::QueryCommand;
use crate::commands::tx::TxCommand;
use crate::config::WalletSvcConfig;

use self::start::StartCmd;

mod echo;
mod start;

mod admin;
mod async_echo;

#[cfg(feature = "p11hsm")]
mod diag;

#[cfg(feature = "tsstrio")]
mod diag;

mod keys;
mod query;
mod tx;

/// WalletSvc Configuration Filename
pub const CONFIG_FILE: &str = "wallet_svc.toml";

/// WalletSvc Subcommands
/// Subcommands need to be listed in an enum.
#[derive(clap::Parser, Command, Debug, Runnable)]
pub enum WalletSvcCmd {
    /// The `echo` subcommand
    Echo(EchoCmd),
    /// The `async-echo` subcommand
    AsyncEcho(AsyncEchoCmd),
    /// The `admin` subcommand
    #[command(subcommand)]
    Admin(AdminCommand),
    /// The `diag(nosis)` subcommand
    // #[cfg(feature = "p11hsm")]
    // #[command(subcommand)]
    // Diag(DiagCommand),
    /// The `diag(nosis)` subcommand
    #[cfg(any(feature = "p11hsm", feature = "tsstrio"))]
    #[command(subcommand)]
    Diag(DiagCommand),
    
    /// The `keys` subcommand
    #[command(subcommand)]
    Keys(KeysCommand),
    /// The `tx` subcommand
    #[command(subcommand)]
    Tx(TxCommand),
    /// The `query` subcommand
    #[command(subcommand)]
    Query(QueryCommand),
    /// The `start` tonic grpc server subcommand
    Start(StartCmd),
}

/// Entry point for the application. It needs to be a struct to allow using subcommands!
#[derive(clap::Parser, Command, Debug)]
#[command(author, about, version)]
pub struct EntryPoint {
    #[command(subcommand)]
    cmd: WalletSvcCmd,

    /// Enable verbose logging
    #[arg(short, long)]
    pub verbose: bool,

    /// Use the specified config file
    #[arg(short, long)]
    pub config: Option<String>,
}

impl Runnable for EntryPoint {
    fn run(&self) {
        self.cmd.run()
    }
}

/// This trait allows you to define how application configuration is loaded.
impl Configurable<WalletSvcConfig> for EntryPoint {
    /// Location of the configuration file
    fn config_path(&self) -> Option<PathBuf> {
        // Check if the config file exists, and if it does not, ignore it.
        // If you'd like for a missing configuration file to be a hard error
        // instead, always return `Some(CONFIG_FILE)` here.
        let filename = self
            .config
            .as_ref()
            .map(PathBuf::from)
            .unwrap_or_else(|| CONFIG_FILE.into());

        if filename.exists() {
            Some(filename)
        } else {
            None
        }
    }

    /// Apply changes to the config after it's been loaded, e.g. overriding
    /// values in a config file using command-line options.
    ///
    /// This can be safely deleted if you don't want to override config
    /// settings from command-line options.
    fn process_config(&self, config: WalletSvcConfig) -> Result<WalletSvcConfig, FrameworkError> {
        match &self.cmd {
            WalletSvcCmd::Echo(cmd) => cmd.override_config(config), //Ok(config),
            WalletSvcCmd::AsyncEcho(cmd) => cmd.override_config(config), //Ok(config),
            // If you don't need special overrides for some
            // subcommands, you can just use a catch all
            _ => Ok(config),
        }
    }
}
