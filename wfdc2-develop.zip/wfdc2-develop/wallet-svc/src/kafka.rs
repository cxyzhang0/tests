use abscissa_core::{format_err, Application};
use abscissa_core::tracing::info;
use abscissa_tokio::tokio;
use rdkafka::config::RDKafkaLogLevel;
use rdkafka::consumer::{CommitMode, Consumer, StreamConsumer};
use rdkafka::{Message};
use rdkafka::message::{BorrowedMessage, Header, OwnedHeaders};
use rdkafka::producer::{FutureProducer, FutureRecord};
use rdkafka::util::Timeout;
use serde::Deserialize;
use wfdc2_proto::wfdc2::wallet::v1::PaymentRequest;
use crate::application::APP;
use crate::error::{Error};
use crate::error::ErrorKind::KafkaError;
use crate::server::WalletService;

// producer parameters
#[allow(dead_code)]
const MESSAGE_TIMEOUT_MS: &str = "5000";
#[allow(dead_code)]
const QUEUE_TIMEOUT_MS: Timeout = Timeout::Never;

// consumer parameters
#[allow(dead_code)]
const ENABLE_PARTITION_EOF: &str = "false";
#[allow(dead_code)]
const SESSION_TIMEOUT_MS: &str = "6000";
#[allow(dead_code)]
const ENABLE_AUTO_COMMIT: &str = "false";
#[allow(dead_code)]
const STATISTICS_INTERVAL_MS: &str = "3600000"; // 1 hr
#[allow(dead_code)]
const AUTO_OFFSET_RESET: &str = "smallest";
#[allow(dead_code)]
const LOG_LEVEL: RDKafkaLogLevel = RDKafkaLogLevel::Debug;

pub struct KafkaClient {
    bootstrap_servers: String,
    subscribe_topic: String,
    publish_topic: String,
    consumer_group_id: String,
}

impl KafkaClient {
    #[allow(dead_code)]
    pub fn new(bootstrap_servers: String, subscribe_topic: String, publish_topic: String, consumer_group_id: String) -> Self {
        Self {
            bootstrap_servers,
            subscribe_topic,
            publish_topic,
            consumer_group_id,
        }
    }
    
    pub fn new_from_config() -> Self {
        let config = APP.config();
        Self {
            bootstrap_servers: config.kafka.bootstrap_servers.clone(),
            subscribe_topic: config.kafka.subscribe_topic.clone(),
            publish_topic: config.kafka.publish_topic.clone(),
            consumer_group_id: config.kafka.consumer_group_id.clone(),
        }
    }
    
    pub fn set_publish_topic(&mut self, publish_topic: String) {
        self.publish_topic = publish_topic;
    }
    
    pub fn is_kafka_enabled() -> bool {
        let config = APP.config();
        !config.kafka.bootstrap_servers.is_empty()
    }

    pub async fn produce(&self, event: String, key: Option<String>, headers: Vec<Header<'_, &str>>) -> Result<(i32, i64), Error> {
        let producer: &FutureProducer = &rdkafka::ClientConfig::new()
            .set("bootstrap.servers", &self.bootstrap_servers)
            .set("message.timeout.ms", MESSAGE_TIMEOUT_MS)
            .create()?;

        let mut record: FutureRecord<'_, str, String> = FutureRecord::to(&self.publish_topic)
            // .key("key") // 
            // .headers(owned_headers)
            .payload(&event);
        
        // todo: use a better way to set the key
        let mut k: String = "".to_string();
        if let Some(key) = key {
            k = key;
        }
        if !k.is_empty() {
            record = record.key(&k);
        }
        
        let mut owned_headers = OwnedHeaders::new();
        for h in headers {
            owned_headers = owned_headers.insert(h);
        }
        record = record.headers(owned_headers);
        
        let delivery_status = producer.send(record, QUEUE_TIMEOUT_MS).await;

        match delivery_status {
            Ok(delivery) => {
                //info!("Message delivered to partition {} offset {}", delivery.0, delivery.1),
                Ok(delivery) 
            }
            Err((e, _p)) => {
                // info!("Failed to deliver message: {:?}, {:?}", e, p);
                // if let Some(payload) = p.payload() {
                //     info!("Message payload: {:?}", String::from_utf8_lossy(payload));
                // }
                Err(e.into())
            }
        }
    }

    pub async fn consume(&self) -> Result<(), Error> {
        let consumer: &StreamConsumer = &rdkafka::ClientConfig::new()
            .set("group.id", &self.consumer_group_id)
            .set("bootstrap.servers", &self.bootstrap_servers)
            .set("enable.partition.eof", ENABLE_PARTITION_EOF)
            .set("session.timeout.ms", SESSION_TIMEOUT_MS)
            .set("enable.auto.commit", ENABLE_AUTO_COMMIT)
            .set("statistics.interval.ms", STATISTICS_INTERVAL_MS)
            .set("auto.offset.reset", AUTO_OFFSET_RESET)
            .set_log_level(LOG_LEVEL)
            .create()?;

        consumer
            .subscribe(&[&self.subscribe_topic])?;

        loop {
            match consumer.recv().await {
                Err(e) => return Err(e.into()),
                Ok(m) => {
                    self.handle_message(&m).await?;
                    consumer.commit_message(&m, CommitMode::Async)?;
                }
            };
        }
    }

    async fn handle_message(&self, message: &BorrowedMessage<'_>) -> Result<(), Error> {
        let payload = match message.payload_view::<str>() {
            None => return Err(KafkaError.context("payload is empty").into()),
            Some(Ok(s)) => s,
            Some(Err(e)) => {
                return Err(KafkaError.context(e.to_string()).into())
            }
        };
        
        match parse_payment_request::<PaymentRequest>(payload) {
            Ok(payment_req) => {
                // todo: validate payment_req against headers for request_type, tracking_id, etc
                info!("Kafka message: {:?}", payment_req);
                // process payment request
                tokio::spawn(async move {
                    let ws = WalletService::default();
                    let _ = ws.process_payment_request(payment_req).await;
                });
            }
            Err(e) => {
                return Err(KafkaError.context(e).into())
            }
        }
        // println!("key: '{:?}', payload: '{}', topic: {}, partition: {}, offset: {}, timestamp: {:?}",
        //          message.key(), payload, message.topic(), message.partition(), message.offset(), message.timestamp(),);
        // if let Some(headers) = message.headers() {
        //     for header in headers.iter() {
        //         println!("  Header {:#?}: {:?}", header.key, header.value);
        //     }
        // }
        
        Ok(())
    }

}

/// generic json parser
// todo: it is the same as that in mq.rs except for the error
pub fn parse_payment_request<'a, T>(body: &'a str) -> Result<T, Error>
where
    T: Deserialize<'a>,
{
    let payment_req: T = serde_json::from_str(body)
        // .map_err(|e| KafkaError.context(format!("parse_payment_request error: {}", e)))?;
        .map_err(|e| format_err!(KafkaError, "parse_payment_request error: {}", e))?;
    Ok(payment_req)
}



