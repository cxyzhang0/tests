//! Error types

use std::{
    fmt::{self, Display},
    io,
    ops::Deref,
};

use abscissa_core::error::{BoxError, Context};
use thiserror::Error;

/// Kinds of errors
#[derive(Copy, Clone, Debug, Eq, Error, PartialEq)]
pub enum ErrorKind {
    /// Error in configuration file
    #[error("config error")]
    Config,

    /// Input/output error
    #[error("I/O error")]
    Io,

    /// PKCS11 HSM provider error
    #[error("PKCS11 HSM error")]
    P11hsmError,

    /// MQ error
    #[error("MQ error")]
    MqError,

    /// serde_json error
    #[error("serde_json error")]
    SerdeJsonError,

    /// Tonic status
    #[error("Tonic status")]
    TonicStatus,
    
    /// Websocket error
    #[error("Websocket error")]
    WebsocketError,
}

impl ErrorKind {
    /// Create an error context from this error
    pub fn context(self, source: impl Into<BoxError>) -> Context<ErrorKind> {
        Context::new(self, Some(source.into()))
    }
}

/// Error type
#[derive(Debug)]
pub struct Error(Box<Context<ErrorKind>>);

impl Deref for Error {
    type Target = Context<ErrorKind>;

    fn deref(&self) -> &Context<ErrorKind> {
        &self.0
    }
}

impl Display for Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

impl std::error::Error for Error {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        self.0.source()
    }
}

impl From<ErrorKind> for Error {
    fn from(kind: ErrorKind) -> Self {
        Context::new(kind, None).into()
    }
}

impl From<Context<ErrorKind>> for Error {
    fn from(context: Context<ErrorKind>) -> Self {
        Error(Box::new(context))
    }
}

impl From<io::Error> for Error {
    fn from(err: io::Error) -> Self {
        ErrorKind::Io.context(err).into()
    }
}

impl From<serde_json::Error> for Error {
    fn from(err: serde_json::Error) -> Self {
        ErrorKind::SerdeJsonError.context(err).into()
    }
}

impl From<tonic::Status> for Error {
    fn from(err: tonic::Status) -> Self {
        ErrorKind::TonicStatus.context(err).into()
    }
}
