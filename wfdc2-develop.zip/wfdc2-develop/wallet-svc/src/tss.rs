//! mpc tss utility
use cosmrs::crypto::secp256k1::VerifyingKey;
use cosmrs::crypto::PublicKey;
use cosmrs::AccountId;
use tonic::Status;

pub(crate) async fn get_pub_key(
    vk: VerifyingKey,
    prefix: String,
) -> Result<(VerifyingKey, PublicKey, AccountId), Status> {
    //let vk = VerifyingKey::from(vk);
    let pk = PublicKey::from(&vk);
    let account_id = pk.account_id(&prefix).unwrap();

    Ok((vk, pk, account_id))
}
