#![allow(unused_imports)]
use std::str::FromStr;

use cosmwasm_std::Decimal;
use time::format_description;
use time::format_description::well_known::{Iso8601, Rfc3339};

use aurum::{ErrorCode, NotificationType};

#[allow(unused)]
const DATE_FORMAT_STR: &'static str = "%Y-%m-%d][%H:%M:%S";

#[test]
fn test_enum_value() {
    let ns = NotificationType::Notifysender;
    let value = ns as u32;
    assert_eq!(value, 1);

    let nsf = ErrorCode::NotSufficientFunds;
    let value = nsf as u32;
    assert_eq!(value, 160);
}

// ref: https://time-rs.github.io/book/api/well-known-format-descriptions.html
// ref: https://docs.rs/time/latest/time/format_description/well_known/struct.Iso8601.html
// ref: https://docs.rs/time/latest/time/format_description/well_known/struct.Rfc3339.html
#[test]
fn test_utc_now() {
    let now = time::OffsetDateTime::now_utc();
    println!("now to_string: {}", now.to_string());
    // now: "2024-03-22 18:51:41.077105 +00:00:00"
    // println!("{}", format!(DATE_FORMAT_STR, now));
    // now.format(DATE_FORMAT_STR).unwrap()
    let format = format_description::parse(
        "[year]-[month]-[day] [hour]:[minute]:[second].[subsecond]",
        // "[year]-[month]-[day] [hour]:[minute]:[second].[subsecond] [offset_hour sign:mandatory]:[offset_minute]:[offset_second]",
    )
    .unwrap();
    // let format = format_description::well_known;
    println!("now format: {}", now.format(&format).unwrap());
    println!(
        "now Iso8601::DATE_TIME: {}",
        now.format(&Iso8601::DATE_TIME).unwrap()
    );
    println!("now Rfc3339: {}", now.format(&Rfc3339).unwrap());
}

#[test]
fn test_parse_str() {
    let format = format_description::parse(
        // "[year]-[month]-[day] [hour]:[minute]:[second].[subsecond]",
        "[year]-[month]-[day] [hour]:[minute]:[second].[subsecond] [offset_hour sign:mandatory][offset_minute] UTC",
        // "[year]-[month]-[day] [hour]:[minute]:[second].[subsecond] [offset_hour sign:mandatory][offset_minute][offset_second] UTC",
    ).unwrap();
    // let format = format_description::well_known;
    let t = time::OffsetDateTime::parse("2024-06-10 23:13:04.080583 +0000 UTC", &format).unwrap();
    // let t = time::OffsetDateTime::parse("2024-03-22 18:51:41.077105 +000000 UTC", &format).unwrap();

    let now = time::OffsetDateTime::now_utc();

    assert!(now.lt(&t));
    assert!(t.gt(&now));

    println!("t: {:?}", t.format(&format).unwrap());
    println!("now: {:?}", now.format(&format).unwrap());
}

#[test]
fn test_decimal_to_f64() {
    let decimal = Decimal::from_str("100.12").unwrap();
    let decimal_f64 = decimal.to_string().parse::<f64>().unwrap();
    println!("decimal_f64: {}", decimal_f64);
    assert_eq!(decimal_f64, 100.12);
}

#[test]
fn test_u32_to_u64() {
    let u32_val = 100u32;
    let u64_val = u32_val as u64;
    let u32_val2 = 200u32;
    let u64_val2 = u32_val2 as u64;

    println!("u64_val {} little endian: {:?}", u64_val, u64_val.to_le_bytes());
    println!("u64_val {} big endian: {:?}", u64_val, u64_val.to_be_bytes());

    println!(
        "u64_val | (u64_val2 >> 32) little endian: {:?}",
        (u64_val | (u64_val2 >> 32)).to_le_bytes()
    );
    println!(
        "u64_val | (u64_val2 << 32) little endian: {:?}",
        (u64_val | (u64_val2 << 32)).to_le_bytes()
    );
}
