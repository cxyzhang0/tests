//! WalletSvc
//!
//! Application based on the [Abscissa] framework.
//!
//! [Abscissa]: https://github.com/iqlusioninc/abscissa

// Tip: Deny warnings with `RUSTFLAGS="-D warnings"` environment variable in CI

// #![forbid(unsafe_code)]
#![warn(
    missing_docs,
    rust_2018_idioms,
    trivial_casts,
    unused_lifetimes,
    unused_qualifications
)]

#[cfg(all(feature = "p11hsm", feature = "tsstrio"))]
compile_error!("feature `p11hsm` and `tsstrio` cannot be enabled at the same time");

#[cfg(not(any(feature = "p11hsm", feature = "tsstrio")))]
compile_error!(
    "please enable one of the following features with cargo's --features argument: \
    `p11hsm`, `tsstrio` (e.g. --features=p11hsm)"
);

/// MPCWallet is actually AsyncWallet
pub use cosmos_wallet::cosmos_async_wallet::Wallet as AsyncWallet;

pub use kms_commom::async_signer::AsyncSigningKey;
// pub use mpc_wallet::traits::MpcSigningKey as AsyncSigningKey;

pub use wfdc2_proto::wfdc2::wallet::v1 as proto;

pub use crate::proto::wallet_server::Wallet as ProtoWallet;

pub mod application;
pub mod commands;
pub mod config;
pub mod error;

#[cfg(feature = "p11hsm")]
pub mod p11hsm;

#[cfg(feature = "tsstrio")]
pub mod tss;

pub mod mq;
pub mod prelude;

/// This module contains the implementation of the wallet server
pub mod server;

#[cfg(test)]
mod tests;

mod types;
/// This module contains the implementation of the websocket client
pub mod websocket;

#[cfg(feature = "kafka")]
mod kafka;
