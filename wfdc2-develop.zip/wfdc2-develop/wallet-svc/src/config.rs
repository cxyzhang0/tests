//! WalletSvc Config
//!
//! See instructions in `commands.rs` to specify the path to your
//! application's configuration file and/or command-line options
//! for specifying it.

use serde::{Deserialize, Serialize};

use crate::config::chain_node::ChainNodeConfig;
use crate::config::echo::EchoConfig;
use crate::config::faucet::FaucetConfig;
pub use crate::config::ibm_mq::IBMMQConfig;
use crate::config::provider::ProviderConfig;
use crate::config::wallet_server::WalletServerConfig;

mod chain_node;
mod echo;
mod faucet;
mod ibm_mq;
/// Provider configuration
pub mod provider;
mod wallet_server;

/// WalletSvc Configuration
#[derive(Clone, Debug, Default, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct WalletSvcConfig {
    /// echo configuration
    pub echo: EchoConfig,
    /// kms provider configuration
    pub provider: ProviderConfig,
    ///  chain node grpc configuration
    pub chain_node: ChainNodeConfig,
    ///  faucet configuration
    pub faucet: FaucetConfig,
    /// wallet server grpc configuration
    pub wallet_server: WalletServerConfig,
    /// ibm mq configuration
    pub ibm_mq: IBMMQConfig,
}
