//! WalletSvc Abscissa Application

#[cfg(feature = "tsstrio")]
use std::path::PathBuf;
use std::sync::{Arc, Mutex};
// use futures::lock::Mutex;

#[cfg(feature = "p11hsm")]
use abscissa_core::FrameworkErrorKind;
use abscissa_core::{
    application::{self, AppCell},
    config::{self, CfgCell},
    trace, Application, FrameworkError, StandardPaths,
};
use abscissa_tokio::TokioComponent;
#[cfg(feature = "tsstrio")]
use mpc_wallet::sdk::TrioSDK;
#[cfg(feature = "p11hsm")]
use pkcs11::{SDK, init_sdk};
// #[cfg(feature = "p11hsm")]
// use crate::p11hsm::{display_env_vars, make_sdk_context_without_slot, make_pkcs11_sdk};
use crate::{commands::EntryPoint, config::WalletSvcConfig};

/// Application state
pub static APP: AppCell<WalletSvcApp> = AppCell::new();

/// WalletSvc Application
#[derive(Debug)]
pub struct WalletSvcApp {
    /// Application configuration.
    config: CfgCell<WalletSvcConfig>,

    /// Application state.
    state: application::State<Self>,
    
    /// PKCS11 SDK
    #[cfg(feature = "p11hsm")]
    sdk: Option<Arc<Mutex<SDK>>>,

    /// Trio SDK
    #[cfg(feature = "tsstrio")]
    // triosdk: Option<Arc<TrioSDK>>,
    triosdk: Option<Arc<Mutex<TrioSDK>>>,
}
#[cfg(feature = "p11hsm")]
impl WalletSvcApp {
    /// Get the PKCS11 SDK
    pub fn sdk(&self) -> Arc<Mutex<SDK>> {
        self.sdk.as_ref().unwrap().clone()
    }

    /// Get the optional PKCS11 SDK for diagnostic purposes
    pub fn raw_sdk(&self) -> Option<&Arc<Mutex<SDK>>> {
        self.sdk.as_ref()
    }
    
}

#[cfg(feature = "tsstrio")]
impl WalletSvcApp {
    /// Get the Trio SDK
    pub fn sdk(&self) -> Arc<Mutex<TrioSDK>> {
        Arc::clone(self.triosdk.as_ref().unwrap())//.clone()
    }

    /// Get the optional PKCS11 SDK for diagnostic purposes
    pub fn raw_sdk(&self) -> Option<&Arc<Mutex<TrioSDK>>> {
        self.triosdk.as_ref()
    }
}

/// Initialize a new application instance.
///
/// By default no configuration is loaded, and the framework state is
/// initialized to a default, empty state (no components, threads, etc).
#[cfg(feature = "p11hsm")]
impl Default for WalletSvcApp {
    fn default() -> Self {
        Self {
            config: CfgCell::default(),
            state: application::State::default(),
            sdk: None,
        }
    }
}

#[cfg(feature = "tsstrio")]
impl Default for WalletSvcApp {
    fn default() -> Self {
        Self {
            config: CfgCell::default(),
            state: application::State::default(),
            triosdk: None,
        }
    }
}

impl Application for WalletSvcApp {
    /// Entrypoint command for this application.
    type Cmd = EntryPoint;

    /// Application configuration.
    type Cfg = WalletSvcConfig;

    /// Paths to resources within the application.
    type Paths = StandardPaths;

    /// Accessor for application configuration.
    fn config(&self) -> config::Reader<WalletSvcConfig> {
        self.config.read()
    }

    /// Borrow the application state immutably.
    fn state(&self) -> &application::State<Self> {
        &self.state
    }

    /// Register all components used by this application.
    ///
    /// If you would like to add additional components to your application
    /// beyond the default ones provided by the framework, this is the place
    /// to do so.
    fn register_components(&mut self, command: &Self::Cmd) -> Result<(), FrameworkError> {
        let mut framework_components = self.framework_components(command)?;
        framework_components.push(Box::new(TokioComponent::new()?));

        let mut app_components = self.state.components_mut();
        app_components.register(framework_components)
    }

    /// Post-configuration lifecycle callback.
    ///
    /// Called regardless of whether config is loaded to indicate this is the
    /// time in app lifecycle when configuration would be loaded if
    /// possible.
    #[cfg(feature = "p11hsm")]
    fn after_config(&mut self, config: Self::Cfg) -> Result<(), FrameworkError> {
        // Configure components
        let mut components = self.state.components_mut();
        components.after_config(&config)?;
        self.config.set_once(config.clone());

        /*
        // set p11 sdk based on config
        display_env_vars(&config.provider.p11hsm);

        let mut sdk_context = make_sdk_context_without_slot(&config.provider.p11hsm)
            .map_err(|e| FrameworkErrorKind::ConfigError.context(e.to_string()))?;

        let sdk = make_pkcs11_sdk(&mut sdk_context, &config.provider.p11hsm)
            .map_err(|e| FrameworkErrorKind::ConfigError.context(e.to_string()))?;
        */
        
        let ctx = init_sdk(
            &config.provider.p11hsm.env_cfg,
            &config.provider.p11hsm.cfg,
            config.provider.p11hsm.env_module.as_deref(), //.as_ref().map(Deref::deref),
            config.provider.p11hsm.module.as_deref(), //.as_ref().map(Deref::deref),
            &config.provider.p11hsm.token_label,
            &config.provider.p11hsm.user_pin,
        ).map_err(|e| FrameworkErrorKind::ConfigError.context(e.to_string()))?;
        
        let sdk = SDK::from_context(&ctx).map_err(|e| FrameworkErrorKind::ConfigError.context(e.to_string()))?;
        self.sdk = Some(Arc::new(Mutex::new(sdk)));

        Ok(())
    }

    #[cfg(feature = "tsstrio")]
    fn after_config(&mut self, config: Self::Cfg) -> Result<(), FrameworkError> {
        // Configure components
        let mut components = self.state.components_mut();
        components.after_config(&config)?;
        self.config.set_once(config.clone());

        let config = config.provider.tsstrio;

        let share: Option<PathBuf> = config.share.map(|s| s.parse().unwrap());
        let sdk = TrioSDK::default()
            .add_algorithm(config.algorithm.as_str())
            .add_share_from_file(share)
            .add_user_sk_from_file(config.user_sk.parse().unwrap())
            .add_server_vk(config.server_vk.as_str())
            .add_server_url(config.server.parse().unwrap())
            .add_finish_server_url(config.finish_server.parse().unwrap())
            .add_chain_path(config.chain_path.as_str())
            .add_keygen_endpoint(config.keygen_endpoint.as_str())
            .add_refresh_endpoint(config.refresh_endpoint.as_str())
            .add_recovery_endpoint(config.recovery_endpoint.as_str())
            .add_sign_endpoint(config.sign_endpoint.as_str())
            .add_presign_endpoint(config.presign_endpoint.as_str())
            .add_finish_endpoint(config.finish_endpoint.as_str());

        self.triosdk = Some(Arc::new(Mutex::new(sdk)));

        Ok(())
    }

    /// Get tracing configuration from command-line options
    fn tracing_config(&self, command: &EntryPoint) -> trace::Config {
        if command.verbose {
            trace::Config::verbose()
        } else {
            trace::Config::default()
        }
    }
}
