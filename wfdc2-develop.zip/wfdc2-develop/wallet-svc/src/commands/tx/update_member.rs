use abscissa_core::{status_err, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::prelude::{info, Command};
use crate::proto::UpdateMemberRequest;
use crate::server::WalletService;
use crate::ProtoWallet;

#[derive(clap::Parser, Command, Debug)]
pub struct UpdateMemberCommand {
    /// id of X509 name
    #[clap(short = 'i', long = "id", required = true)]
    id: String,
    /// acct address
    #[clap(short = 'a', long = "addr", required = true)]
    addr: String,
    /// public key
    #[clap(short = 'k', long = "pk", required = true)]
    pubkey: String,
    /// grpc endpoint
    #[clap(short = 'g', long = "grpc", required = true)]
    grpc: String,
}

impl Runnable for UpdateMemberCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(UpdateMemberRequest {
                id: self.id.to_owned(),
                addr: self.addr.to_owned(),
                pubkey: self.pubkey.to_owned(),
                grpc: self.grpc.to_owned(),
            });

            let resp = svc
                .update_member(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!("failed to update member: {}", e);
                    std::process::exit(1);
                })
                .into_inner();

            info!("***** update member id {} txhash: {}", self.id, resp.txhash);
        });
    }
}
