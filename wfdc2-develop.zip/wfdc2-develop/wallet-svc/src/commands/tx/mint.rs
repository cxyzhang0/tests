use abscissa_core::{status_err, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::prelude::{info, Command};
use crate::proto::MintRequest;
use crate::server::WalletService;
use crate::ProtoWallet;

#[derive(clap::Parser, Command, Debug)]
pub struct MintCommand {
    /// mint to address
    #[clap(short = 'a', long = "addr", required = true)]
    address: String,
    /// denomination of token to be minted
    #[clap(short = 'd', long = "denom", required = true)]
    denom: String,
    /// value of token to be minted
    #[clap(short = 'v', long = "value", required = true)]
    value: u128,
}

impl Runnable for MintCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(MintRequest {
                address: self.address.clone(),
                denom: self.denom.clone(),
                value: self.value.to_string(),
            });

            let resp = svc
                .mint(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!(
                        "failed to mint to {}; denom {}; value {}: {}",
                        self.address,
                        self.denom,
                        self.value,
                        e
                    );
                    std::process::exit(1);
                })
                .into_inner();

            info!("***** mint txhash: {}", resp.txhash);
        });
    }
}
