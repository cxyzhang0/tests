use abscissa_core::{status_err, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::prelude::{info, Command};
use crate::proto::UnpauseRequest;
use crate::server::WalletService;
use crate::ProtoWallet;

#[derive(clap::Parser, Command, Debug)]
pub struct UnpauseCommand {}

impl Runnable for UnpauseCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(UnpauseRequest {});

            let resp = svc
                .unpause(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!("failed to unpause {}", e);
                    std::process::exit(1);
                })
                .into_inner();

            info!("***** unpause txhash: {}", resp.txhash);
        });
    }
}
