use abscissa_core::{status_err, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::prelude::{info, Command};
use crate::proto::PauseRequest;
use crate::server::WalletService;
use crate::ProtoWallet;

#[derive(clap::Parser, Command, Debug)]
pub struct PauseCommand {}

impl Runnable for PauseCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(PauseRequest {});

            let resp = svc
                .pause(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!("failed to pause {}", e);
                    std::process::exit(1);
                })
                .into_inner();

            info!("***** pause txhash: {}", resp.txhash);
        });
    }
}
