use abscissa_core::{status_err, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::prelude::{info, Command};
use crate::proto::RevokeFeeAllowanceRequest;
use crate::server::WalletService;
use crate::ProtoWallet;

#[derive(clap::Parser, Command, Debug)]
pub struct RevokeFeeAllowanceCommand {
    /// grantee account address
    #[clap(short = 'g', long = "grantee")]
    grantee: String,
}

impl Runnable for RevokeFeeAllowanceCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(RevokeFeeAllowanceRequest {
                grantee: self.grantee.to_owned(),
            });

            let resp = svc
                .revoke_fee_allowance(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!("failed to revoke fee allowance: {}", e);
                    std::process::exit(1);
                })
                .into_inner();

            info!("***** revoke fee allowance txhash: {}", resp.txhash);
        });
    }
}
