use abscissa_core::{status_err, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::prelude::{info, Command};
use crate::proto::RemoveMinterRequest;
use crate::server::WalletService;
use crate::ProtoWallet;

#[derive(clap::Parser, Command, Debug)]
pub struct RemoveMinterCommand {
    /// minter address
    #[clap(short = 'a', long = "addr", required = true)]
    address: String,
    /// denom
    #[clap(short = 'd', long = "denom", required = true)]
    denom: String,    
}

impl Runnable for RemoveMinterCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(RemoveMinterRequest {
                address: self.address.clone(),
                denom: self.denom.clone(),
            });

            let resp = svc
                .remove_minter(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!("failed to remove minter {}: {}", self.address, e);
                    std::process::exit(1);
                })
                .into_inner();

            info!("***** remove minter txhash: {}", resp.txhash);
        });
    }
}
