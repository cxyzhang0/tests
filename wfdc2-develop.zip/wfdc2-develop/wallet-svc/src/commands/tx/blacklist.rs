use abscissa_core::{status_err, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::prelude::{info, Command};
use crate::proto::BlacklistRequest;
use crate::server::WalletService;
use crate::ProtoWallet;

#[derive(clap::Parser, Command, Debug)]
pub struct BlacklistCommand {
    /// blacklister address
    #[clap(short = 'a', long = "addr", required = true)]
    address: String,
}

impl Runnable for BlacklistCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(BlacklistRequest {
                address: self.address.clone(),
            });

            let resp = svc
                .blacklist(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!("failed to blacklist {}: {}", self.address, e);
                    std::process::exit(1);
                })
                .into_inner();

            info!("***** blacklist txhash: {}", resp.txhash);
        });
    }
}
