use abscissa_core::{status_err, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::prelude::{info, Command};
use crate::proto::UnblacklistRequest;
use crate::server::WalletService;
use crate::ProtoWallet;

#[derive(clap::Parser, Command, Debug)]
pub struct UnblacklistCommand {
    /// unblacklist address
    #[clap(short = 'a', long = "addr", required = true)]
    address: String,
}

impl Runnable for UnblacklistCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(UnblacklistRequest {
                address: self.address.clone(),
            });

            let resp = svc
                .unblacklist(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!("failed to unblacklist {}: {}", self.address, e);
                    std::process::exit(1);
                })
                .into_inner();

            info!("***** unblacklist txhash: {}", resp.txhash);
        });
    }
}
