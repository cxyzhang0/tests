use abscissa_core::tracing::info;
use abscissa_core::{status_err, Command, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::proto::ConfigureMinterRequest;
use crate::server::WalletService;
use crate::ProtoWallet;

#[derive(clap::Parser, Command, Debug)]
pub struct ConfigureMinterCommand {
    /// minter address
    #[clap(short = 'a', long = "addr", required = true)]
    address: String,
    /// denom allowed for the minter
    #[clap(short = 'd', long = "denom", required = true)]
    allowance_denom: String,
    /// total allowed for the minter
    #[clap(short = 'v', long = "value", required = true)]
    allowance_value: u128,
}

impl Runnable for ConfigureMinterCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(ConfigureMinterRequest {
                address: self.address.clone(),
                allowance_denom: self.allowance_denom.clone(),
                allowance_value: self.allowance_value.to_string(),
            });

            let resp = svc
                .configure_minter(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!("failed to configure minter: {}", e);
                    std::process::exit(1);
                })
                .into_inner();

            info!("***** configure minter txhash: {}", resp.txhash);
        });
    }
}
