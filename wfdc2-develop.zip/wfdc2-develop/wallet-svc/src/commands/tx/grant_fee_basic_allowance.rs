use abscissa_core::{status_err, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::prelude::{info, Command};
use crate::proto::GrantFeeBasicAllowanceRequest;
use crate::server::WalletService;
use crate::ProtoWallet;

#[derive(clap::Parser, Command, Debug)]
pub struct GrantFeeBasicAllowanceCommand {
    /// grantee account address
    #[clap(short = 'g', long = "grantee", required = true)]
    grantee: String,
    /// total allowed for the grantee
    #[clap(short = 'v', long = "value", required = true)]
    allowance_value: u128,
    /// hours until expiration
    #[clap(short = 'e', long = "hours", required = true)]
    hours_to_expire: u64,
}

impl Runnable for GrantFeeBasicAllowanceCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(GrantFeeBasicAllowanceRequest {
                grantee: self.grantee.to_owned(),
                allowance_value: self.allowance_value.to_string(),
                hours_to_expire: self.hours_to_expire,
            });

            let resp = svc
                .grant_fee_basic_allowance(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!("failed to grant fee basic allowance: {}", e);
                    std::process::exit(1);
                })
                .into_inner();

            info!("***** grant fee basic allowance txhash: {}", resp.txhash);
        });
    }
}
