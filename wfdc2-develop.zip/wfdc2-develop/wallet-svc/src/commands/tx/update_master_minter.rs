use abscissa_core::{status_err, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::prelude::{info, Command};
use crate::proto::UpdateMasterMinterRequest;
use crate::server::WalletService;
use crate::ProtoWallet;

#[derive(clap::Parser, Command, Debug)]
pub struct UpdateMasterMinterCommand {
    /// master minter address
    #[clap(short = 'a', long = "addr", required = true)]
    address: String,
}

impl Runnable for UpdateMasterMinterCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(UpdateMasterMinterRequest {
                address: self.address.clone(),
            });

            let resp = svc
                .update_master_minter(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!("failed to update master minter {}: {}", self.address, e);
                    std::process::exit(1);
                })
                .into_inner();

            info!("***** update master minter txhash: {}", resp.txhash);
        });
    }
}
