use abscissa_core::{status_err, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::prelude::{info, Command};
use crate::proto::UpdatePauserRequest;
use crate::server::WalletService;
use crate::ProtoWallet;

#[derive(clap::Parser, Command, Debug)]
pub struct UpdatePauserCommand {
    /// pauser address
    #[clap(short = 'a', long = "addr", required = true)]
    address: String,
}

impl Runnable for UpdatePauserCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(UpdatePauserRequest {
                address: self.address.clone(),
            });

            let resp = svc
                .update_pauser(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!("failed to update pauser {}: {}", self.address, e);
                    std::process::exit(1);
                })
                .into_inner();

            info!("***** update pauser txhash: {}", resp.txhash);
        });
    }
}
