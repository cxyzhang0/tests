use abscissa_core::tracing::info;
use abscissa_core::{status_err, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::prelude::Command;
use crate::proto::ConfigureMinterControllerRequest;
use crate::server::WalletService;
use crate::ProtoWallet;

#[derive(clap::Parser, Command, Debug)]
pub struct ConfigureMinterControllerCommand {
    /// controller address
    #[clap(short = 'c', long = "controller", required = true)]
    controller: String,
    /// minter address
    #[clap(short = 'm', long = "minter", required = true)]
    minter: String,
}

impl Runnable for ConfigureMinterControllerCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(ConfigureMinterControllerRequest {
                controller: self.controller.clone(),
                minter: self.minter.clone(),
            });

            let resp = svc
                .configure_minter_controller(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!("failed to configure minter controller: {}", e);
                    std::process::exit(1);
                })
                .into_inner();

            info!("***** configure minter controller txhash: {}", resp.txhash);
        });
    }
}
