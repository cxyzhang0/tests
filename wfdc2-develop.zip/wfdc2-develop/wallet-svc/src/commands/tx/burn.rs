use abscissa_core::{status_err, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::prelude::{info, Command};
use crate::proto::BurnRequest;
use crate::server::WalletService;
use crate::ProtoWallet;

#[derive(clap::Parser, Command, Debug)]
pub struct BurnCommand {
    /// denomination of token to be burned
    #[clap(short = 'd', long = "denom", required = true)]
    denom: String,
    /// value of token to be burned
    #[clap(short = 'v', long = "value", required = true)]
    value: u128,
}

impl Runnable for BurnCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(BurnRequest {
                denom: self.denom.clone(),
                value: self.value.to_string(),
            });

            let resp = svc
                .burn(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!(
                        "failed to burn denom {}; value {}: {}",
                        self.denom,
                        self.value,
                        e
                    );
                    std::process::exit(1);
                })
                .into_inner();

            info!("***** burn tx hash: {}", resp.txhash);
        });
    }
}
