use abscissa_core::{status_err, Command, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::prelude::info;
use crate::proto::BankSendRequest;
use crate::server::WalletService;
use crate::ProtoWallet;

#[derive(clap::Parser, Command, Debug)]
pub struct BankSendCommand {
    /// to account address
    #[clap(long = "to_addr", required = true)]
    to_addr: String,
    /// value of token to be sent
    #[clap(short = 'v', long = "value", required = true)]
    value: u128,
    /// denomination of token to be sent
    #[clap(short = 'd', long = "denom", required = true)]
    denom: String,
}

impl Runnable for BankSendCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(BankSendRequest {
                to_addr: self.to_addr.clone(),
                value: self.value.to_string(),
                denom: self.denom.clone(),
            });

            let resp = svc
                .bank_send(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!("failed to get bank send: {}", e);
                    std::process::exit(1);
                })
                .into_inner();

            info!("***** bank send txhash: {}", resp.txhash);

            /*
                        let config = APP.config();

                        let signer = P11Signer::new(
                            APP.sdk(),
                            KeyLabel::from_short(&config.provider.p11hsm.key_label, SDKCryptographAlgorithm::Secp256k1).unwrap(),
                        );

                        let signing_key = MpcSigningKey::new(Box::new(signer));

                        let mut client = WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await
                            .unwrap_or_else(|e| {
                                status_err!("failed to connect to chain {}: {}", config.chain_node.grpc, e);
                                std::process::exit(1);
                            });

                        let mut wallet = AsyncWallet::from_mpc(
                            &mut client,
                            signing_key,
                            config.chain_node.prefix.as_str(),
                            CoinType::Cosmos,
                            Decimal::from_str(&config.chain_node.gas_price).unwrap(), // Gas_price
                            Decimal::from_str(&config.chain_node.gas_adjustment).unwrap(),   // Gas adjustment
                            &config.chain_node.gas_denom,                       // Gas denom
                        )
                            .await
                            .unwrap();

                        let msg = MsgSend {
                            from_address: wallet.account_address(),
                            to_address: self.to_addr.clone(),
                            amount: vec![ProtoCoin {
                                denom: self.denom.clone(),
                                amount: self.value.to_string(),
                            }],
                        }
                            .to_any()
                            .unwrap();

                        let response = wallet
                            .broadcast_tx(
                                &mut client,
                                vec![msg],           // Vec<Any>: list of msgs to broadcast
                                None,                // memo: Option<String>
                                None, // fee: Option<Fee>, if not provided the tx is simulated to calculate the fee
                                BroadcastMode::Sync, // Broadcast mode; Block/Sync/Async
                            )
                            .await
                            .unwrap();

                        info!("***** bank send tx hash: {}", response.tx_response.unwrap().txhash)
            */
        });
    }
}
