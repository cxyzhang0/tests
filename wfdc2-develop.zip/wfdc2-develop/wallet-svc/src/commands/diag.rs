use crate::commands::diag::run::RunCommand;
use crate::prelude::{Command, Runnable};

mod run;

#[derive(clap::Parser, Command, Debug, Runnable)]
pub enum DiagCommand {
    /// Run diagnosis
    Run(RunCommand),
    
    // todo: remove the following commented-out code
    /*
    /// Get Pkcs11 context
    P11context(P11contextCommand),

    /// Slot count
    Slotcount(SlotcountCommand),

    /// Slot info
    Slotinfo(SlotinfoCommand),

    /// Login
    Login(LoginCommand),
    */
}
