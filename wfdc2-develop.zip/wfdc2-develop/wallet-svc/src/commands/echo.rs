//! `echo` subcommand

use abscissa_core::{config, Command, FrameworkError, Runnable};

use crate::config::WalletSvcConfig;
/// App-local prelude includes `app_reader()`/`app_writer()`/`app_config()`
/// accessors along with logging macros. Customize as you see fit.
use crate::prelude::*;

/// `echo` subcommand
///
/// The `Parser` proc macro generates an option parser based on the struct
/// definition, and is defined in the `clap` crate. See their documentation
/// for a more comprehensive example:
///
/// <https://docs.rs/clap/>
#[derive(clap::Parser, Command, Debug)]
pub struct EchoCmd {
    /// echo vec of strings seperated by ',', e.g., -e Alice,Bob or -e Alice -e Bob
    #[clap(short = 'e', long = "echo", num_args = 0.., value_delimiter = ',')]
    // #[clap(short = 'e', long = "echo", default_value = "pong", num_args = 0.., value_delimiter = ',')]
    echo: Vec<String>,
}
//
impl Runnable for EchoCmd {
    // Start the application.
    fn run(&self) {
        let config = APP.config();
        println!("Echo: {}", &config.echo.echo);
    }
}

impl config::Override<WalletSvcConfig> for EchoCmd {
    // Process the given command line options, overriding settings from
    // a configuration file using explicit flags taken from command-line
    // arguments.
    fn override_config(
        &self,
        mut config: WalletSvcConfig,
    ) -> Result<WalletSvcConfig, FrameworkError> {
        if !self.echo.is_empty() {
            config.echo.echo = self.echo.join(" ");
        }

        Ok(config)
    }
}
