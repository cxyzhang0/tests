use abscissa_core::{status_err, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::prelude::{info, Command};
use crate::proto::GetMemberRequest;
use crate::server::WalletService;
use crate::ProtoWallet;

#[derive(clap::Parser, Command, Debug)]
pub struct GetMemberCommand {
    /// id of X509 name
    #[clap(short = 'i', long = "id", required = true)]
    id: String,
}

impl Runnable for GetMemberCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(GetMemberRequest {
                id: self.id.clone(),
            });

            let resp = svc
                .get_member(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!("failed to get member: {}", e);
                    std::process::exit(1);
                })
                .into_inner();

            info!(
                "***** member: id: {}; addr: {}; pubkey: {}; grpc: {}",
                resp.id, resp.addr, resp.pubkey, resp.grpc
            )
        });
    }
}
