use abscissa_core::{status_err, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::prelude::{info, Command};
use crate::proto::QueryTxRequest;
use crate::server::WalletService;
use crate::ProtoWallet;

#[derive(clap::Parser, Command, Debug)]
pub struct QueryTxCommand {
    /// tx hash
    #[clap(short = 't', long = "hash", required = true)]
    txhash: String,
}

impl Runnable for QueryTxCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(QueryTxRequest {
                txhash: self.txhash.clone(),
            });

            let resp = svc
                .query_tx(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!("failed to query tx: {}", e);
                    std::process::exit(1);
                })
                .into_inner();

            info!(
                "***** query_tx - txhash {}; status {}; height {}",
                resp.txhash, resp.status, resp.height
            );
            info!("***** query_tx - log {}", resp.log);
            info!(
                "***** query_tx - gas_wanted {}; gas_used {}; num_events {}",
                resp.gas_wanted, resp.gas_used, resp.num_events
            );
        });
    }
}
