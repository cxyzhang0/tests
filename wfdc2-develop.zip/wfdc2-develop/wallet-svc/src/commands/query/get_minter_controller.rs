use abscissa_core::{status_err, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::prelude::{info, Command};
use crate::proto::GetMinterControllerRequest;
use crate::server::WalletService;
use crate::ProtoWallet;

#[derive(clap::Parser, Command, Debug)]
pub struct GetMinterControllerCommand {
    /// controller address
    #[clap(short = 'c', long = "controller", required = true)]
    controller: String,
    /// minter address
    #[clap(short = 'm', long = "minter", required = true)]
    minter: String,
}

impl Runnable for GetMinterControllerCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(GetMinterControllerRequest {
                controller: self.controller.clone(),
                minter: self.minter.clone(),
            });

            let resp = svc
                .get_minter_controller(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!("failed to get minter controller: {}", e);
                    std::process::exit(1);
                })
                .into_inner();

            info!(
                "***** controller: {}; minter: {}",
                resp.controller, resp.minter
            )
        });
    }
}
