use abscissa_core::{status_err, Command, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::prelude::info;
use crate::proto::GetMintersRequest;
use crate::server::WalletService;
use crate::ProtoWallet;

#[derive(clap::Parser, Command, Debug)]
pub struct GetMinterCommand {
    /// minter address
    #[clap(short = 'a', long = "addr", required = true)]
    address: String,
    /// denom
    #[clap(short = 'd', long = "denom", required = true)]
    denom: String,
}

impl Runnable for GetMinterCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(GetMintersRequest {
                address: self.address.clone(),
                denom: self.denom.clone(),
            });

            let resp = svc
                .get_minters(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!("failed to get minter {}: {}", self.address, e);
                    std::process::exit(1);
                })
                .into_inner();

            info!(
                "***** minter: {}; allowance_denom: {}; allowance_value: {}",
                resp.address, resp.allowance_denom, resp.allowance_value
            )
        });
    }
}
