use abscissa_core::{status_err, Command, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::prelude::info;
use crate::proto::GetBlacklisterRequest;
use crate::server::WalletService;
use crate::ProtoWallet;

#[derive(clap::Parser, Command, Debug)]
pub struct GetBlacklisterCommand {}
impl Runnable for GetBlacklisterCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(GetBlacklisterRequest {});

            let resp = svc
                .get_blacklister(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!("failed to get blacklister: {}", e);
                    std::process::exit(1);
                })
                .into_inner();

            info!("***** blacklister: {}", resp.address);
        });
    }
}
