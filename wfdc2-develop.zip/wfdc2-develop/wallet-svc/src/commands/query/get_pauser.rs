use abscissa_core::{status_err, Command, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::prelude::info;
use crate::proto::GetPauserRequest;
use crate::server::WalletService;
use crate::ProtoWallet;

#[derive(clap::Parser, Command, Debug)]
pub struct GetPauserCommand {}
impl Runnable for GetPauserCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(GetPauserRequest {});

            let resp = svc
                .get_pauser(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!("failed to get pauser: {}", e);
                    std::process::exit(1);
                })
                .into_inner();

            info!("***** pauser: {}", resp.address);
        });
    }
}
