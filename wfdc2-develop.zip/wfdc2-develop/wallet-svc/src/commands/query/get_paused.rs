use abscissa_core::{status_err, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::prelude::{info, Command};
use crate::proto::GetPausedRequest;
use crate::server::WalletService;
use crate::ProtoWallet;

#[derive(clap::Parser, Command, Debug)]
pub struct GetPausedCommand {}
impl Runnable for GetPausedCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(GetPausedRequest {});

            let resp = svc
                .get_paused(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!("failed to get paused: {}", e);
                    std::process::exit(1);
                })
                .into_inner();

            info!("***** paused: {}", resp.paused);
        });
    }
}
