use abscissa_core::{status_err, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::prelude::{info, Command};
use crate::proto::GetBlacklistedRequest;
use crate::server::WalletService;
use crate::ProtoWallet;

#[derive(clap::Parser, Command, Debug)]
pub struct GetBlacklistedCommand {
    /// blacklisted address
    #[clap(short = 'a', long = "addr", required = true)]
    address: String,
}

impl Runnable for GetBlacklistedCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(GetBlacklistedRequest {
                address: self.address.clone(),
            });

            let resp = svc
                .get_blacklisted(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!("failed to get blacklisted {}: {}", self.address, e);
                    std::process::exit(1);
                })
                .into_inner();

            info!("***** {} is blacklisted", resp.address)
        });
    }
}
