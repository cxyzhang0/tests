use abscissa_core::tracing::info;
use abscissa_core::{status_err, Runnable};
use tonic::Request;

use wfdc2_proto::wfdc2::wallet::v1::GetFeeBasicAllowanceRequest;

use crate::application::APP;
use crate::prelude::Command;
use crate::server::WalletService;
use crate::ProtoWallet;

#[derive(clap::Parser, Command, Debug)]
pub struct GetFeeBasicAllowanceCommand {
    /// optional grantee account address. if not provided, use key label in config
    #[clap(short = 'g', long = "grantee")]
    grantee: Option<String>,
}

impl Runnable for GetFeeBasicAllowanceCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(GetFeeBasicAllowanceRequest {
                grantee: self.grantee.clone(),
            });

            let resp = svc
                .get_fee_basic_allowance(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!("failed to get fee basic allowance: {}", e);
                    std::process::exit(1);
                })
                .into_inner();

            info!("***** fee basic allowance: {:?}", resp.fee_basic_grant);
        });
    }
}
