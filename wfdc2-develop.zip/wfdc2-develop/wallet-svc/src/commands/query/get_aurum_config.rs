use abscissa_core::{status_err, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::prelude::{info, Command};
use crate::proto::GetAurumConfigRequest;
use crate::server::WalletService;
use crate::ProtoWallet;

#[derive(clap::Parser, Command, Debug)]
pub struct GetAurumConfigCommand {}

impl Runnable for GetAurumConfigCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(GetAurumConfigRequest {});

            let resp = svc
                .get_aurum_config(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!("failed to get aurum config: {}", e);
                    std::process::exit(1);
                })
                .into_inner();

            info!(
                "***** aurum config - owner {}; tf_address {}",
                resp.owner, resp.tf_address
            );
        });
    }
}
