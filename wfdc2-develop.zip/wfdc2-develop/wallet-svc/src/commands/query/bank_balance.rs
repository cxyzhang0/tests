use abscissa_core::tracing::info;
use abscissa_core::{status_err, Command, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::proto::wallet_server::Wallet;
use crate::proto::BankBalanceRequest;
use crate::server::WalletService;

#[derive(clap::Parser, Command, Debug)]
pub struct GetBankBalanceCommand {
    // /// optional key label in this format: `[prefix]/[key ring]/[key]/[version]`, e.g., `Slot Token 0/wfdc2/usa/1`
    // #[clap(short = 'l', long = "kl")]
    // key_label: Option<String>,
    /// optional account address. if not provided, use key label in config
    #[clap(short = 'a', long = "addr")]
    address: Option<String>,
    /// denomination of token whose balance is being requested
    #[clap(short = 'd', long = "denom", required = true)]
    denom: String,
}

impl Runnable for GetBankBalanceCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(BankBalanceRequest {
                address: self.address.clone(),
                denom: self.denom.clone(),
            });

            let resp = svc
                .get_bank_balance(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!("failed to get bank balance: {}", e);
                    std::process::exit(1);
                })
                .into_inner();

            info!(
                "***** bank balance - key label: {:?}; address: {:?}; denom: {}; value: {}",
                resp.key_label, resp.address, resp.denom, resp.value
            );

            /*
            let config = APP.config();

            let mut is_for_kl = false;

            let addr = if let Some(addr) = self.address.clone() {
                addr
            } else {
                let (_vk, _pk, account_id) = get_pub_key_from_label(config.provider.p11hsm.key_label.clone(), config.chain_node.prefix.clone()).await
                    .unwrap_or_else(|e| {
                        status_err!("failed to get pub key for key label {}: {}", config.provider.p11hsm.key_label, e);
                        std::process::exit(1);
                    });

                is_for_kl = true;

                account_id.to_string()
            };

            let mut client = WalletService::get_cosmos_grpc_client(config.chain_node.grpc.clone()).await
                .unwrap_or_else(|e| {
                    status_err!("failed to connect to chain {}: {}", config.chain_node.grpc, e);
                    std::process::exit(1);
                });

            let bal_req = QueryBalanceRequest { address: addr.clone(), denom: self.denom.clone() };

            let resp = client.clients.bank.balance(bal_req).await
                .unwrap_or_else(|e| {
                    status_err!("failed to get balance: {}", e);
                    std::process::exit(1);
                });

            let resp = resp.into_inner();

            if is_for_kl {
                info!("***** bank balance - key label: {:?}; address: {}; denom: {}; value: {}",
                config.provider.p11hsm.key_label, addr, resp.balance.clone().unwrap().denom, resp.balance.clone().unwrap().amount)
            } else {
                info!("***** bank balance - address: {}; denom: {}; value: {}",
                addr, resp.balance.clone().unwrap().denom, resp.balance.clone().unwrap().amount)
            }
            */
        });
    }
}
