use abscissa_core::{status_err, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::prelude::{info, Command};
use crate::proto::GetTfConfigRequest;
use crate::server::WalletService;
use crate::ProtoWallet;

#[derive(clap::Parser, Command, Debug)]
pub struct GetTfConfigCommand {}

impl Runnable for GetTfConfigCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(GetTfConfigRequest {});

            let resp = svc
                .get_tf_config(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!("failed to get tokenfactory config: {}", e);
                    std::process::exit(1);
                })
                .into_inner();

            info!(
                "***** tokenfactory config - owner {}; is_tf {}",
                resp.owner, resp.is_tf
            );
        });
    }
}
