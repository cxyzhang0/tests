use abscissa_core::{status_err, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::prelude::{info, Command};
use crate::proto::GetMasterMinterRequest;
use crate::server::WalletService;
use crate::ProtoWallet;

#[derive(clap::Parser, Command, Debug)]
pub struct GetMasterMinterCommand {}

impl Runnable for GetMasterMinterCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(GetMasterMinterRequest {});

            let resp = svc
                .get_master_minter(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!("failed to get master minter: {}", e);
                    std::process::exit(1);
                })
                .into_inner();

            info!("***** master minter: {}", resp.address)
        });
    }
}
