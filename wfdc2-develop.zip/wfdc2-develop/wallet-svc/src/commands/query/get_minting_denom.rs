use abscissa_core::{status_err, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::prelude::{info, Command};
use crate::proto::GetMintingDenomRequest;
use crate::server::WalletService;
use crate::ProtoWallet;

#[derive(clap::Parser, Command, Debug)]
pub struct GetMintingDenomCommand {
    /// denom
    #[clap(short = 'd', long = "denom", required = true)]
    denom: String    
}

impl Runnable for GetMintingDenomCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(GetMintingDenomRequest { denom: self.denom.clone() });

            let resp = svc
                .get_minting_denom(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!("failed to get minting denom: {}", e);
                    std::process::exit(1);
                })
                .into_inner();

            info!("***** minting denom: {}", resp.denom)
        });
    }
}
