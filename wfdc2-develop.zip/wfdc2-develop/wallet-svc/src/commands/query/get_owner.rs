use abscissa_core::{status_err, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::prelude::{info, Command};
use crate::proto::GetOwnerRequest;
use crate::server::WalletService;
use crate::ProtoWallet;

#[derive(clap::Parser, Command, Debug)]
pub struct GetOwnerCommand {}
impl Runnable for GetOwnerCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(GetOwnerRequest {});

            let resp = svc
                .get_owner(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!("failed to get owner: {}", e);
                    std::process::exit(1);
                })
                .into_inner();

            info!("***** owner: {}", resp.address);
        });
    }
}
