use abscissa_core::{Command, Runnable};

use crate::commands::tx::bank_send::BankSendCommand;
use crate::commands::tx::blacklist::BlacklistCommand;
use crate::commands::tx::burn::BurnCommand;
use crate::commands::tx::configure_minter::ConfigureMinterCommand;
use crate::commands::tx::configure_minter_controller::ConfigureMinterControllerCommand;
use crate::commands::tx::grant_fee_basic_allowance::GrantFeeBasicAllowanceCommand;
use crate::commands::tx::mint::MintCommand;
use crate::commands::tx::pause::PauseCommand;
use crate::commands::tx::remove_minter::RemoveMinterCommand;
use crate::commands::tx::remove_minter_controller::RemoveMinterControllerCommand;
use crate::commands::tx::request_fee_basic_allowance::RequestFeeBasicAllowanceCommand;
use crate::commands::tx::revoke_fee_allowance::RevokeFeeAllowanceCommand;
use crate::commands::tx::unblacklist::UnblacklistCommand;
use crate::commands::tx::unpause::UnpauseCommand;
use crate::commands::tx::update_blacklister::UpdateBlacklisterCommand;
use crate::commands::tx::update_master_minter::UpdateMasterMinterCommand;
use crate::commands::tx::update_member::UpdateMemberCommand;
use crate::commands::tx::update_pauser::UpdatePauserCommand;

mod bank_send;
mod blacklist;
mod burn;
mod configure_minter;
mod configure_minter_controller;
mod grant_fee_basic_allowance;
mod mint;
mod pause;
mod remove_minter;
mod remove_minter_controller;
mod request_fee_basic_allowance;
mod revoke_fee_allowance;
mod unblacklist;
mod unpause;
mod update_blacklister;
mod update_master_minter;
mod update_member;
mod update_pauser;

#[derive(clap::Parser, Command, Debug, Runnable)]
pub enum TxCommand {
    /// The `bank-send` subcommand
    BankSend(BankSendCommand),
    /// The `update-master-minter` subcommand
    UpdateMasterMinter(UpdateMasterMinterCommand),
    /// The `configure-minter-controller` subcommand
    ConfigureMinterController(ConfigureMinterControllerCommand),
    /// The `remove-minter-controller` subcommand
    RemoveMinterController(RemoveMinterControllerCommand),
    /// The `configure-minter` subcommand
    ConfigureMinter(ConfigureMinterCommand),
    /// The `remove-minter` subcommand
    RemoveMinter(RemoveMinterCommand),
    /// The `update-blacklister` subcommand
    UpdateBlacklister(UpdateBlacklisterCommand),
    /// The `blacklist` subcommand
    Blacklist(BlacklistCommand),
    /// The `unblacklist` subcommand
    Unblacklist(UnblacklistCommand),
    /// The `update-pauser` subcommand
    UpdatePauser(UpdatePauserCommand),
    /// The `pause` subcommand
    Pause(PauseCommand),
    /// The `unpause` subcommand
    Unpause(UnpauseCommand),
    /// The `mint` subcommand
    Mint(MintCommand),
    /// The `burn` subcommand
    Burn(BurnCommand),
    /// The `update-member` subcommand
    UpdateMember(UpdateMemberCommand),
    /// The `grant-fee-basic-allowance` subcommand
    GrantFeeBasicAllowance(GrantFeeBasicAllowanceCommand),
    /// The `request-fee-basic-allowance` subcommand
    RequestFeeBasicAllowance(RequestFeeBasicAllowanceCommand),
    /// The `revoke-fee-allowance` subcommand
    RevokeFeeAllowance(RevokeFeeAllowanceCommand),
}
