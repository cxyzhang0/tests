use abscissa_core::{Runnable};

use crate::application::APP;
use crate::prelude::{info, Command};

#[derive(clap::Parser, Command, Debug)]
pub struct RunCommand {}

impl Runnable for RunCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            assert!(APP.raw_sdk().is_some());

            info!(
                "diagnosis-run successfully - got raw sdk",
            )
        });
    }
}
