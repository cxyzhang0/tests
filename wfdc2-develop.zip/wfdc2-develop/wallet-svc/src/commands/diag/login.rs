// todo: remove this file
/*
use abscissa_core::{status_err, Application, Runnable};

use crate::application::APP;
use crate::p11hsm::{display_env_vars, make_pkcs11_sdk, make_sdk_context_without_slot};
use crate::prelude::{info, Command};

#[derive(clap::Parser, Command, Debug)]
pub struct LoginCommand {}

impl Runnable for LoginCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            // let started = std::time::Instant::now();

            // let config = APP.config();

            // display_env_vars(&config.provider.p11hsm);
            
            assert!(APP.raw_sdk().is_some())
/*
            let binding = APP.sdk_context();
            let p11 = binding.lock().unwrap_or_else(|e| {
                status_err!("couldn't get exclusive lock on pkcs11 context: {}", e);
                std::process::exit(1);
            });
            info!(
                "got exclusive lock on pkcs11 context ({} ms)",
                started.elapsed().as_millis()
            );

            info!(
                "logout and close previous session ({} ms)",
                started.elapsed().as_millis()
            );
            SDK::open_close_session(&p11, &config.provider.p11hsm.token_label).unwrap_or_else(|e| {
                status_err!("couldn't get exclusive lock on pkcs11 context: {}", e);
                std::process::exit(1);
            });
*/
            /*
            let mut ctx = make_sdk_context_without_slot(&config.provider.p11hsm).unwrap_or_else(|e| {
                status_err!("couldn't get pkcs11 context: {}", e);
                std::process::exit(1);
            });
            info!("got pkcs11 context ({} ms)", started.elapsed().as_millis());

            info!("logging in: {}", config.provider.p11hsm.token_label);
            let sdk = make_pkcs11_sdk(&mut ctx, &config.provider.p11hsm).unwrap_or_else(|e| {
                status_err!("couldn't make pkcs11 sdk: {}", e);
                std::process::exit(1);
            });
            info!(
                "logged in {} and got sdk ({} ms)",
                config.provider.p11hsm.token_label,
                started.elapsed().as_millis()
            );
            sdk.close().unwrap_or_else(|e| {
                status_err!("couldn't close pkcs11 sdk.session: {}", e);
                std::process::exit(1);
            });
            info!(
                "closed pkcs11 sdk.session: ({} ms)",
                started.elapsed().as_millis()
            )
            */
        });
    }
}
*/