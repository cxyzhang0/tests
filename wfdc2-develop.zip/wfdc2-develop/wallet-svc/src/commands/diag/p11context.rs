// todo: remove this file
/*
use abscissa_core::{status_err, Application, Runnable};

use crate::application::APP;
use crate::p11hsm::{display_env_vars, make_sdk_context_without_slot};
use crate::prelude::{info, Command};

#[derive(clap::Parser, Command, Debug)]
pub struct P11contextCommand {}

impl Runnable for P11contextCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let started = std::time::Instant::now();

            let config = APP.config();

            display_env_vars(&config.provider.p11hsm);

            let _ctx = make_sdk_context_without_slot(&config.provider.p11hsm).unwrap_or_else(|e| {
                status_err!("couldn't get pkcs11 context: {}", e);
                std::process::exit(1);
            });
            info!("got pkcs11 context ({} ms)", started.elapsed().as_millis());
        });
    }
}
*/