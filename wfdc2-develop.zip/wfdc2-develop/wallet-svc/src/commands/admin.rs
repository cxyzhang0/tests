use crate::commands::admin::instantiate_contract::InstantiateContractCommand;
use crate::commands::admin::instantiate_ft_contract::InstantiateFtContractCommand;
use crate::commands::admin::store_code::StoreCodeCommand;
use crate::prelude::{Command, Runnable};

mod instantiate_contract;
mod instantiate_ft_contract;
mod store_code;

#[derive(clap::Parser, Command, Debug, Runnable)]
pub enum AdminCommand {
    /// The `store_code` subcommand
    StoreCode(StoreCodeCommand),

    /// The `instantiate_ft_contract` subcommand
    InstantiateFtContract(InstantiateFtContractCommand),

    /// The `instantiate_contract` subcommand
    InstantiateContract(InstantiateContractCommand),
}
