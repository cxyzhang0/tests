use abscissa_core::{Command, Runnable};

use crate::commands::keys::genkey::GenKeyCommand;
use crate::commands::keys::pubkey::GetPubKeyCommand;

mod genkey;
mod pubkey;

#[derive(clap::Parser, Command, Debug, Runnable)]
pub enum KeysCommand {
    /// The `gen-key` subcommand
    GenKey(GenKeyCommand),
    /// The `get-pub-key` subcommand
    GetPubKey(GetPubKeyCommand),
}
