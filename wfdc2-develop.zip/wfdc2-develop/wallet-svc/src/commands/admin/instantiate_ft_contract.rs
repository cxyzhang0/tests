use abscissa_core::{status_err, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::prelude::{info, Command};
use crate::proto::wallet_server::Wallet;
use crate::proto::InstantiateFtContractRequest;
use crate::server::WalletService;

#[derive(clap::Parser, Command, Debug)]
pub struct InstantiateFtContractCommand {
    /// stored contract code id
    #[clap(short = 'i', long = "id")]
    pub code_id: u64,
    /// label for the contract
    #[clap(short = 'l', long = "label")]
    pub label: String,
    /// whether it is tokenfactory or fiat-tokenfactory
    #[clap(short = 't', long = "tf")]
    pub is_tf: bool,
}

impl Runnable for InstantiateFtContractCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(InstantiateFtContractRequest {
                code_id: self.code_id,
                label: self.label.clone(),
                is_tf: self.is_tf,
            });

            let resp = svc
                .instantiate_ft_contract(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!(
                        "failed to instantiate contract for code {}: {}",
                        self.code_id,
                        e
                    );
                    std::process::exit(1);
                })
                .into_inner();

            info!("***** instantiate contract txhash: {}", resp.txhash);
        });
    }
}
