use abscissa_core::{status_err, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::prelude::{info, Command};
use crate::proto::wallet_server::Wallet;
use crate::proto::StoreCodeRequest;
use crate::server::WalletService;

#[derive(clap::Parser, Command, Debug)]
pub struct StoreCodeCommand {
    /// wasm file (full path) to store
    #[clap(short = 'w', long = "wasm")]
    pub wasm_file: String,
}

impl Runnable for StoreCodeCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(StoreCodeRequest {
                wasm_file: self.wasm_file.clone(),
            });

            let resp = svc
                .store_code(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!("failed to store code {}: {}", self.wasm_file, e);
                    std::process::exit(1);
                })
                .into_inner();

            info!("***** store code txhash: {}", resp.txhash);
        });
    }
}
