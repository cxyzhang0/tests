use abscissa_core::{status_err, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::prelude::{info, Command};
use crate::proto::wallet_server::Wallet;
use crate::proto::InstantiateContractRequest;
use crate::server::WalletService;

#[derive(clap::Parser, Command, Debug)]
pub struct InstantiateContractCommand {
    /// stored contract code id
    #[clap(short = 'i', long = "id")]
    pub code_id: u64,
    /// label for the contract
    #[clap(short = 'l', long = "label")]
    pub label: String,
    /// contract instantiate message
    #[clap(short = 'm', long = "msg")]
    pub init_msg: String,
}

impl Runnable for InstantiateContractCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(InstantiateContractRequest {
                code_id: self.code_id,
                label: self.label.clone(),
                init_msg: self.init_msg.clone(),
            });

            let resp = svc
                .instantiate_contract(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!(
                        "failed to instantiate contract for code {}: {}",
                        self.code_id,
                        e
                    );
                    std::process::exit(1);
                })
                .into_inner();

            info!("***** instantiate contract txhash: {}", resp.txhash);
        });
    }
}
