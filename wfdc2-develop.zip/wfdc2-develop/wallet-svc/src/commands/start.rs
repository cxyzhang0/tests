//! `start` subcommand -

use std::net::SocketAddr;

use abscissa_core::{Command, Runnable};
use abscissa_tokio::tokio;
use tonic::transport::Server;

use crate::mq::listener;
/// App-local prelude includes `app_reader()`/`app_writer()`/`app_config()`
/// accessors along with logging macros. Customize as you see fit.
use crate::prelude::*;
use crate::proto::wallet_server::WalletServer;
use crate::server::WalletService;
use crate::websocket::WebSocketClient;

/// `start` subcommand
///
/// The `Parser` proc macro generates an option parser based on the struct
/// definition, and is defined in the `clap` crate. See their documentation
/// for a more comprehensive example:
///
/// <https://docs.rs/clap/>
#[derive(clap::Parser, Command, Debug)]
pub struct StartCmd {}

impl Runnable for StartCmd {
    /// Start the application.
    fn run(&self) {
        let wallet_service = WalletService::default();
        // this is the working original with only one task.
        /*
        let _ = abscissa_tokio::run(&APP, async {
            let config = APP.config();
            let addr: SocketAddr = config.wallet_server.grpc.parse().unwrap();
            info!("Starting WalletService on {}", addr.clone().to_string());
            Server::builder()
                .add_service(WalletServer::new(wallet_service))
                .serve(addr)
                .await
                .unwrap();
            info!("WalletService started on {}", addr.to_string())
        });
        */ 

        // start 3 tasks: grpc server, IBM MQ listener, websocket client; and join them
        let _ = abscissa_tokio::run(&APP, async {
            let h1 = tokio::spawn(async move {
                let config = APP.config();
                let addr: SocketAddr = config.wallet_server.grpc.parse().unwrap();
                info!("starting WalletService on {}", addr.clone().to_string());
                Server::builder()
                    .add_service(WalletServer::new(wallet_service))
                    .serve(addr)
                    .await
                    .unwrap();
                // this is not reachable
                info!("WalletService started on {}", addr.to_string())
            });

            let config = APP.config();

            let mut h2: Option<tokio::task::JoinHandle<()>> = None;
            let mut h3: Option<tokio::task::JoinHandle<()>> = None;
            
            if config.ibm_mq.applicable {
                h2 = Some(tokio::spawn(async move {
                    info!("starting IBM MQ listener");
                    listener().await;
                }));
                // let (_, _) = tokio::join!(h1, h2);
            } else {
                info!("IBM MQ is not applicable");
                // let _ = tokio::join!(h1);
            };
            
            if !config.chain_node.websocket.is_empty() {
                let websocket_client = WebSocketClient::new();
                h3 = Some(tokio::spawn(async move {
                    info!("starting websocket client");
                    websocket_client.subscribe().await.unwrap();
                }));
            }
            
            match (h2, h3) {
                (Some(h2), Some(h3)) => {
                    let (_, _, _) = tokio::join!(h1, h2, h3);
                }
                (Some(h2), None) => {
                    let (_, _) = tokio::join!(h1, h2);
                }
                (None, Some(h3)) => {
                    let (_, _) = tokio::join!(h1, h3);
                }
                (None, None) => {
                    let _ = tokio::join!(h1);
                }
                
            }
            
        });

        // not reachable
        info!("WalletService started")
    }
}
