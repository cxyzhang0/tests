use abscissa_core::{Command, Runnable};

use crate::commands::query::bank_balance::GetBankBalanceCommand;
use crate::commands::query::get_aurum_config::GetAurumConfigCommand;
use crate::commands::query::get_blacklisted::GetBlacklistedCommand;
use crate::commands::query::get_blacklister::GetBlacklisterCommand;
use crate::commands::query::get_fee_basic_allowance::GetFeeBasicAllowanceCommand;
use crate::commands::query::get_master_minter::GetMasterMinterCommand;
use crate::commands::query::get_member::GetMemberCommand;
use crate::commands::query::get_minter::GetMinterCommand;
use crate::commands::query::get_minter_controller::GetMinterControllerCommand;
use crate::commands::query::get_minting_denom::GetMintingDenomCommand;
use crate::commands::query::get_owner::GetOwnerCommand;
use crate::commands::query::get_paused::GetPausedCommand;
use crate::commands::query::get_pauser::GetPauserCommand;
use crate::commands::query::get_tf_config::GetTfConfigCommand;
use crate::commands::query::query_tx::QueryTxCommand;

mod bank_balance;
mod get_aurum_config;
mod get_blacklisted;
mod get_blacklister;
mod get_fee_basic_allowance;
mod get_master_minter;
mod get_member;
mod get_minter;
mod get_minter_controller;
mod get_minting_denom;
mod get_owner;
mod get_paused;
mod get_pauser;
mod get_tf_config;
mod query_tx;

#[derive(clap::Parser, Command, Debug, Runnable)]
pub enum QueryCommand {
    /// The `get-bank-balance` subcommand
    GetBankBalance(GetBankBalanceCommand),
    /// The `get-owner` subcommand
    GetOwner(GetOwnerCommand),
    /// The `get-master-minter` subcommand
    GetMasterMinter(GetMasterMinterCommand),
    /// The `get-minter-controller` subcommand
    GetMinterController(GetMinterControllerCommand),
    /// The `get-minting-denom` subcommand
    GetMintingDenom(GetMintingDenomCommand),
    /// The `get-minter` subcommand
    GetMinter(GetMinterCommand),
    /// The `get-blacklister` subcommand
    GetBlacklister(GetBlacklisterCommand),
    /// The `get-pauser` subcommand
    GetPauser(GetPauserCommand),
    /// The `get-blacklisted` subcommand
    GetBlacklisted(GetBlacklistedCommand),
    /// The `get-paused` subcommand
    GetPaused(GetPausedCommand),
    /// The `query-tx` subcommand
    QueryTx(QueryTxCommand),
    /// The `get-tf-config` subcommand
    GetTfConfig(GetTfConfigCommand),
    /// The `get-aurum-config` subcommand
    GetAurumConfig(GetAurumConfigCommand),
    /// The `get-member` subcommand
    GetMember(GetMemberCommand),
    /// The `get-fee-basic-allowance` subcommand
    GetFeeBasicAllowance(GetFeeBasicAllowanceCommand),
}
