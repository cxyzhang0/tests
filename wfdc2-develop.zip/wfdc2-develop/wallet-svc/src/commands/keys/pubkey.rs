use abscissa_core::{status_err, Command, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::prelude::info;
use crate::proto::GetPubKeyRequest;
use crate::server::WalletService;
use crate::ProtoWallet;

#[derive(clap::Parser, Command, Debug)]
pub struct GetPubKeyCommand {
    /// key label in this format: `[prefix]/[key ring]/[key]/[version]`, e.g., `Slot Token 0/wfdc2/usa/1`
    #[clap(short = 'l', long = "kl")]
    key_label: Option<String>,
}

impl Runnable for GetPubKeyCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let req = Request::new(GetPubKeyRequest {
                key_label: self.key_label.clone(),
            });

            let resp = svc
                .get_pub_key(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!("failed to get pub key: {}", e);
                    std::process::exit(1);
                })
                .into_inner();

            info!(
                "***** key label: {:?}; pub key: {}; acct addr: {}",
                resp.key_label, resp.pub_key, resp.acct_addr
            );

            /*
                        let config = APP.config();

                        let (vk, _, account_id) = get_pub_key_from_label(self.key_label.clone(), config.chain_node.prefix.clone()).await
                            .unwrap_or_else(|e| {
                                status_err!("failed to get pub key from key label {}: {}", self.key_label.clone(), e);
                                std::process::exit(1);
                            });

                        info!("***** key label: {}; pub key: {}; acct addr: {}", self.key_label, hex::encode(vk.to_sec1_bytes()), account_id.to_string())
            */
        });
    }
}
