use abscissa_core::{status_err, Command, Runnable};
use tonic::Request;

use crate::application::APP;
use crate::prelude::info;
use crate::proto::{CryptographAlgorithm, GenKeyRequest, KeyType};
use crate::server::WalletService;
use crate::ProtoWallet;

#[derive(clap::Parser, Command, Debug)]
pub struct GenKeyCommand {
    /// key label in this format: `[prefix]/[key ring]/[key]/[version]`, e.g., `Slot Token 0/wfdc2/usa/1`
    #[clap(
        short = 'l', long = "kl",
        required = true,
        value_name = "key_label",
        // help_heading = "REQUIRED",
        help = "key label in this format: `[prefix]/[key ring]/[key]/[version]`"
    )]
    key_label: String,

    /// key type, account or consensus, currently not used
    #[clap(short = 't', long = "kt")]
    key_type: String,

    /// cryptographic algorithm, Secp256k1, Secp256r1, Ed25519, or RSA2048
    #[clap(short = 'a', long = "al")]
    algorithm: String,

    /// whether to persist the generated key depending on whether or not this flag is set.
    #[clap(long = "persistent")]
    persistent: bool,
}

impl Runnable for GenKeyCommand {
    fn run(&self) {
        let _ = abscissa_tokio::run(&APP, async {
            let svc = WalletService::new();

            let key_type = KeyType::from_str_name(&self.key_type).unwrap_or_else(|| {
                status_err!("invalid key type: {}", self.key_type);
                std::process::exit(1);
            });

            let algo = CryptographAlgorithm::from_str_name(&self.algorithm).unwrap_or_else(|| {
                status_err!("invalid algorithm: {}", self.algorithm);
                std::process::exit(1);
            });

            let req = Request::new(GenKeyRequest {
                key_label: self.key_label.clone(),
                key_type: key_type.into(),
                algorithm: algo.into(),
                persistent: self.persistent,
            });

            let resp = svc
                .gen_key(req)
                .await
                .unwrap_or_else(|e| {
                    status_err!("failed to gen key: {}", e);
                    std::process::exit(1);
                })
                .into_inner();

            info!(
                "***** new key generated - key label: {}; persisted: {}",
                resp.key_label, resp.persisted
            );

            /*
             let config = APP.config();

             let algo =
                 SDKCryptographAlgorithm::from(self.algorithm.clone());

             let mut key_label = KeyLabel::from_short(&self.key_label, algo)
                 .unwrap_or_else(|e| {
                     status_err!("couldn't pass key lable: {}", e);
                     std::process::exit(1);
                 });

             // Note: for some reason, calling sdk.keygen directly here would hang
             //  So we wrap the sdk.keygen in an async fn do_keygen which is also
             //  used in WalletService.
             let key_label = do_keygen(key_label, self.persistent).await
                 .unwrap_or_else(|e| {
                     status_err!("failed to generate key: {}", e);
                     std::process::exit(1);
                 });

             let (vk, _, account_id) = get_pub_key_from_label(key_label.short_label(), config.chain_node.prefix.clone()).await
                 .unwrap_or_else(|e| {
                     status_err!("failed to generate key: {}", e);
                     std::process::exit(1);
                 });

             info!("***** key label: {}; pub key: {}; acct addr: {}; persisted: {}", key_label.short_label(), hex::encode(vk.to_sec1_bytes()), account_id.to_string(), self.persistent)
            */
        });
    }
}
