//! p11hsm utility
// use std::env;
// use std::sync::Once;

// use abscissa_core::{format_err, status_err};
use cosmrs::crypto::secp256k1::VerifyingKey;
use cosmrs::crypto::PublicKey;
use cosmrs::AccountId;
use pkcs11::{CryptographAlgorithm as SDKCryptographAlgorithm, KeyLabel};
use tonic::Status;

use crate::application::APP;
// use crate::config::provider::p11hsm::P11hsmConfig;
// use crate::error::Error;
// use crate::error::ErrorKind::P11hsmError;
// use crate::prelude::info;

/*
#[deprecated(note = "replaced by SDK init_sdk()")]
/// One-time function call
pub(crate) static INIT: Once = Once::new();

#[deprecated(note = "replaced by SDK init_sdk()")]
/// Perform one-time environment variable setup
// TODO: why we are able to set env vars for both fx and softhsm? Is it because they are different?
pub(crate) fn set_env_vars(config: &P11hsmConfig) {
    INIT.call_once(|| {
        env::set_var(&config.env_cfg, &config.cfg);
    });
    info!("env var set - {}={:?}", &config.env_cfg, &config.cfg);
}

#[deprecated(note = "replaced by SDK init_sdk()")]
/// Display environment variables
pub(crate) fn display_env_vars(config: &P11hsmConfig) {
    info!("env_cfg: {}; cfg: {:?}", config.env_cfg, config.cfg);
    info!(
        "evn_module: {:?}; module: {:?}",
        config.env_module, config.module
    );
}

#[deprecated(note = "replaced by SDK init_sdk()")]
/// Create a new SDLContext without slot
pub(crate) fn make_sdk_context_without_slot(config: &P11hsmConfig) -> Result<SDKContext, Error> {
    set_env_vars(config);

    let p11 = SDKContext::create_pkcs11(config.env_module.as_deref(), config.module.as_deref())
        .map_err(|e| format_err!(P11hsmError, "pkcs11 creation error: {}", e))?;

    info!(
        "new pkcs11 created - env_module: {:?}; module = {:?}",
        &config.env_module, &config.module,
    );
    info!("pkcs11 library: {:?})", p11.get_library_info().unwrap(),);

    Ok(SDKContext::new(p11))
}

#[deprecated(note = "replaced by SDK init_sdk()")]
/// Create a new pkcs11 sdk with login
/// ctx: &mut SDKContext without slot
pub(crate) fn make_pkcs11_sdk(ctx: &mut SDKContext, config: &P11hsmConfig) -> Result<SDK, Error> {
    info!("set context slot: {}", config.token_label);
    ctx.set_slot_by_label(&config.token_label)
        .map_err(|e| format_err!(P11hsmError, "sdk context set_slot_by_label error: {}", e))?;

    info!("create sdk from context without login");
    let mut sdk = SDK::from_context(&ctx).unwrap_or_else(|e| {
        status_err!("couldn't make sdk from context (prior to login): {}", e);
        std::process::exit(1);
    });

    info!("logging in: {}", config.token_label);
    sdk.login(&config.user_pin).map_err(|e| format_err!(P11hsmError, "sdk login error: {}", e))?;
    
    info!("sdk session: {}", sdk.session(),);

    Ok(sdk)
}
*/
pub(crate) async fn do_keygen(
    mut key_label: KeyLabel,
    persistent: bool,
) -> Result<KeyLabel, Status> {
    let sdk = APP.sdk();

    let sdk = sdk.lock().map_err(|e| Status::internal(e.to_string()))?;

    let (_, _, key_label) = sdk
        .keygen(&mut key_label, persistent)
        .map_err(|e| Status::internal(e.to_string()))?;

    Ok(key_label)
}

pub(crate) async fn get_pub_key_from_label(
    key_label: String,
    prefix: String,
) -> Result<(VerifyingKey, PublicKey, AccountId), Status> {
    let sdk = APP.sdk();

    let sdk = sdk.lock().map_err(|e| Status::internal(e.to_string()))?;

    let algo = SDKCryptographAlgorithm::Secp256k1;
    let key_label = KeyLabel::from_short(&key_label, algo)
        .map_err(|e| Status::invalid_argument(e.to_string()))?;

    let vk = sdk
        .get_k256_public_key(&key_label)
        .map_err(|e| Status::internal(e.to_string()))?;

    let pk = PublicKey::from(vk);

    let account_id = pk.account_id(&prefix).unwrap();

    Ok((vk, pk, account_id))
}
