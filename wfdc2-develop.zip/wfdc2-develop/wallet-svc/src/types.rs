use std::str::FromStr;
use cosmrs::proto::cosmos::bank;
use cosmwasm_std::Decimal;
use time::format_description::well_known::Rfc3339;

use aurum::{
    BalanceRequest as AurumBalanceRequest, BalanceResponse as AurumBalanceResponse,
    PaymentRequest as AurumPaymentRequest, PaymentResponse as AurumPaymentResponse,
    PaymentStateResponse as AurumPaymentStateResponse, X500Name as AurumX500Name,
};

use crate::proto::{BalanceRequest, BalanceResponse, PaymentRequest, X500Name, BalanceError, CashResponse, DenomMetadata, DenomUnit, ErrorCode, NotificationType, PaymentResponse, PaymentStateResponse, PaymentStatus, TransactionStatus};
use tokenfactory_bindings::query::{DenomMetadata as BindingsDenomMetadata, DenomUnit as BindingsDenomUnit};

pub(crate) fn convert_x500_name(from: X500Name) -> AurumX500Name {
    AurumX500Name {
        common_name: from.common_name,
        organization_unit: from.organization_unit,
        organization: from.organization,
        locality: from.locality,
        state: from.state,
        country: from.country,
    }
}

pub(crate) fn convert_x500_name_2(from: AurumX500Name) -> X500Name {
    X500Name {
        common_name: from.common_name,
        organization_unit: from.organization_unit,
        organization: from.organization,
        locality: from.locality,
        state: from.state,
        country: from.country,
    }
}

pub(crate) fn convert_payment_request(from: PaymentRequest) -> AurumPaymentRequest {
    AurumPaymentRequest {
        originating_party: from.originating_party.map(convert_x500_name),
        beneficiary_party: from.beneficiary_party.map(convert_x500_name),
        amount: Decimal::from_str(&from.amount.to_string()).unwrap(),
        currency: from.currency,
        message_type: from.message_type,
        payment_type: from.payment_type,
        payment_instruction: from.payment_instruction,
        tracking_id: from.tracking_id,
        send_business_date: from.send_business_date,
        request_date_time: from.request_date_time,
        custom1: from.custom1,
        custom2: from.custom2,
        custom3: from.custom3,
        custom4: from.custom4,
        custom5: from.custom5,
        custom6: from.custom6,
    }
}

pub(crate) fn convert_balance_request(from: &BalanceRequest) -> AurumBalanceRequest {
    AurumBalanceRequest {
        party: from.party.clone().map(convert_x500_name),
        currency: from.currency.clone(),
        tracking_id: from.tracking_id.clone(),
        ref_number: from.ref_number.clone(),
        request_date_time: from.request_date_time.clone(),
    }
}

pub(crate) fn convert_balance_response(from: AurumBalanceResponse) -> BalanceResponse {
    let message = from.message.unwrap();
    let data = from.data.unwrap();
    let party = data.party.unwrap();

    BalanceResponse {
        status: from.status,
        message: Some(BalanceError {
            error_code: message.error_code,
            error_description: message.error_description,
        }),
        data: Some(CashResponse {
            party: Some(X500Name {
                common_name: party.common_name,
                organization_unit: party.organization_unit,
                organization: party.organization,
                locality: party.locality,
                state: party.state,
                country: party.country,
            }),
            amount: data.amount,
            currency: data.currency,
            tracking_id: data.tracking_id,
            ref_number: data.ref_number,
            request_date_time: data.request_date_time,
        }),
    }
}

pub(crate) fn convert_payment_response(
    from: AurumPaymentResponse,
    notification_type: Option<NotificationType>,
    payment_status: Option<PaymentStatus>,
    transaction_status: Option<TransactionStatus>,
    error_code: Option<ErrorCode>,
    error_description: Option<String>,
) -> PaymentResponse {
    PaymentResponse {
        id: from.id,
        originating_party: from.originating_party.map(convert_x500_name_2),
        beneficiary_party: from.beneficiary_party.map(convert_x500_name_2),
        amount: from.amount.to_string().parse::<f64>().unwrap(),
        currency: from.currency,
        payment_instruction: from.payment_instruction,
        tracking_id: from.tracking_id,
        send_business_date: from.send_business_date,
        request_date_time: from.request_date_time,
        message_type: from.message_type,
        payment_type: from.payment_type,
        notification_type: match notification_type {
            Some(t) => t.as_str_name().to_string(),
            None => from.notification_type,
        },
        entry_date_time: from.entry_date_time,
        payment_status: match payment_status {
            Some(s) => s.as_str_name().to_string(),
            None => from.payment_status,
        },
        transaction_status: match transaction_status {
            Some(s) => s.as_str_name().to_string(),
            None => from.transaction_status,
        },
        error_code: match error_code {
            Some(c) => (c as i32).to_string(),
            None => from.error_code,
        },
        error_description: match error_description {
            Some(d) => d,
            None => from.error_description,
        },
        custom1: from.custom1,
        custom2: from.custom2,
        custom3: from.custom3,
        custom4: from.custom4,
        custom5: from.custom5,
        custom6: from.custom6,
    }
}
pub(crate) fn convert_payment_state_response(
    from: AurumPaymentStateResponse,
    notification_type: Option<NotificationType>,
    payment_status: Option<PaymentStatus>,
    transaction_status: Option<TransactionStatus>,
    error_code: Option<ErrorCode>,
    error_description: Option<String>,
) -> PaymentStateResponse {
    PaymentStateResponse {
        resp: Some(convert_payment_response(
            from.resp.unwrap(),
            notification_type,
            payment_status,
            transaction_status,
            error_code,
            error_description,
        )),
        txhash: from.txhash,
    }
}

// payment response from payment request
// depending on where it is called, the caller may need to provide the following:
//  notification_type, payment_status, transaction_status, error_code, error_description
pub(crate) fn payment_request_to_payment_response(
    request: &PaymentRequest,
    notification_type: NotificationType,
    payment_status: PaymentStatus,
    transaction_status: TransactionStatus,
    error_code: ErrorCode,
    error_description: String,
) -> PaymentResponse {
    let request = request.clone();
    PaymentResponse {
        id: request.tracking_id.clone(),
        originating_party: request.originating_party,
        beneficiary_party: request.beneficiary_party,
        amount: request.amount,
        currency: request.currency,
        payment_instruction: request.payment_instruction,
        tracking_id: request.tracking_id,
        send_business_date: request.send_business_date,
        request_date_time: request.request_date_time,
        message_type: request.message_type,
        payment_type: request.payment_type,
        notification_type: notification_type.as_str_name().to_string(),
        entry_date_time: time::OffsetDateTime::now_utc().format(&Rfc3339).unwrap(),
        payment_status: payment_status.as_str_name().to_string(),
        transaction_status: transaction_status.as_str_name().to_string(),
        error_code: (error_code as i32).to_string(),
        error_description,
        custom1: request.custom1,
        custom2: request.custom2,
        custom3: request.custom3,
        custom4: request.custom4,
        custom5: request.custom5,
        custom6: request.custom6,
    }
}

pub(crate) fn _describe_error_code(code: ErrorCode) -> String {
    match code {
        ErrorCode::Unspecified => "Unspecified".to_string(),
        ErrorCode::InvalidCurrency => "Invalid currency".to_string(),
        ErrorCode::CordaFlowFailed => "Corda flow failed".to_string(),
        ErrorCode::PartiesNotFundingNode => {
            "Funding/Defunding must include Issuer Branch".to_string()
        }
        ErrorCode::PartiesCannotBeTheSame => {
            "Originating and Beneficiary parties cannot be the same".to_string()
        }
        ErrorCode::FundingNodeCannotOriginatePayments => {
            "Funding node cannot originate payments".to_string()
        }
        ErrorCode::FundingNodeCannotReceivePayments => {
            "Funding node cannot receive payments".to_string()
        }
        ErrorCode::NotSufficientFunds => "Not sufficient funds".to_string(),
        ErrorCode::InsufficientNotLockedBalance => "Token count is too low".to_string(),
        ErrorCode::OriginatingPartyRequired => "Originating party is required".to_string(),
        ErrorCode::DataNotFound => "Data not found".to_string(),
        ErrorCode::InvalidParty => "Invalid party".to_string(),
    }
}

pub(crate) fn convert_denom_unit(from: bank::v1beta1::DenomUnit) -> DenomUnit {
    DenomUnit {
        denom: from.denom,
        exponent: Some(from.exponent),
        aliases: from.aliases,
    }
}

pub(crate) fn convert_denom_unit_2(from: DenomUnit) -> BindingsDenomUnit {
    BindingsDenomUnit {
        denom: from.denom,
        exponent: from.exponent,
        aliases: Some(from.aliases),
    }
}

pub(crate) fn convert_denom_metadata_2(from: DenomMetadata) -> BindingsDenomMetadata  {
    let denom_units = from.denom_units.into_iter().map(convert_denom_unit_2).collect();

    BindingsDenomMetadata {
        base: from.base,
        display: from.display,
        description: from.description,
        denom_units,
        symbol: from.symbol,
        uri: from.uri,
        name: from.name,
        uri_hash: from.uri_hash,
    }
}

pub(crate) fn convert_denom_metadata(from: bank::v1beta1::Metadata) -> DenomMetadata {
    let denom_units = from.denom_units.into_iter().map(convert_denom_unit).collect();

    DenomMetadata {
        base: from.base,
        display: from.display,
        description: from.description,
        denom_units,
        symbol: from.symbol,
        uri: Some(from.uri),
        name: from.name,
        uri_hash: Some(from.uri_hash),
    }
}
