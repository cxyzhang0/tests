use std::collections::HashMap;
use std::fmt::Display;
use std::sync::{Arc, Mutex};
use abscissa_core::{status_err, Application};
use abscissa_core::tracing::info;
use futures_util::{SinkExt, StreamExt};
use lazy_static::lazy_static;
use serde_json::json;
use tokio_tungstenite::{connect_async, tungstenite::protocol::Message};
use tonic::{Request};
use url::Url;
use crate::proto::{FromMemberRequest, GetPubKeyRequest};
use crate::application::APP;
use crate::error::{Error, ErrorKind};
use crate::prelude::warn;
use crate::server::WalletService;
use crate::ProtoWallet;

#[derive(Debug)]
struct AurumAttrs {
    action: String,
    tracking_id: String,
    originator: String,
    beneficiary: String,
    amount: String,
    denom: String,
    txhash: String,
}

impl Display for AurumAttrs {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "action: {}, tracking_id: {}, originator: {}, beneficiary: {}, amount: {}, denom: {}, txhash: {}", self.action, self.tracking_id, self.originator, self.beneficiary, self.amount, self.denom, self.txhash)
    }
}

const WEBSOCKET_SUBSCRIBE_JSONRPC_VERSION: &str = "2.0";
const WEBSOCKET_SUBSCRIBE_ID_PREFIX: &str = "wfdc2-wallet-svc";

const TM_EVENT: &str = "tm.event='Tx'";
const WASM: &str = "wasm";
const MESSAGE_MODULE: &str = "message.module='wasm'";
const AURUM_ACTION_KEY: &str = "aurum_action";
const AURUM_TRACKING_ID_KEY: &str = "aurum_tracking_id";
const AURUM_ORIGINATOR_KEY: &str = "aurum_originator";
const AURUM_BENEFICIARY_KEY: &str = "aurum_beneficiary";
const AURUM_AMOUNT_KEY: &str = "aurum_amount";
const AURUM_DENOM_KEY: &str = "aurum_denom";
const AURUM_TXHASH_KEY: &str = "aurum_txhash";
const FUND_ACTION: &str = "'fund'";
const PAY_ACTION: &str = "'pay'";
const DEFUND_ACTION: &str = "'defund'";
const UPDATE_TXHASH_ACTION: &str = "'update_txhash'";
const UPDATE_TXHASH: &str = "update_txhash";

lazy_static! {
    static ref WEBSOCKET_SUBSCRIBE_QUERIES: [String; 4] = [
    format!("{TM_EVENT} AND {MESSAGE_MODULE} AND {WASM}.{AURUM_ACTION_KEY}={FUND_ACTION}"),
    format!("{TM_EVENT} AND {MESSAGE_MODULE} AND {WASM}.{AURUM_ACTION_KEY}={PAY_ACTION}"),
    format!("{TM_EVENT} AND {MESSAGE_MODULE} AND {WASM}.{AURUM_ACTION_KEY}={DEFUND_ACTION}"),
    format!("{TM_EVENT} AND {MESSAGE_MODULE} AND {WASM}.{AURUM_ACTION_KEY}={UPDATE_TXHASH_ACTION}"),        
    ];
}

/// WebSocketClient handles all the websocket operations for a wallet's GBF transfer notification function.
/// Use map to link the two aurum types of transactions: fund/pay/defund and update_txhash.
///     map: tracking_id -> AurumAttrs
pub struct WebSocketClient {
    wallet_svc: WalletService,
    map: Arc<Mutex<HashMap<String, AurumAttrs>>>,
}

impl WebSocketClient {
    /// Creates a new WebSocketClient instance.
    pub fn new() -> Self {
        Self {
            wallet_svc: WalletService::new(),
            map: Arc::new(Mutex::new(HashMap::new())),
        }
    }

    /// Determine whether websocket is enabled by checking the websocket URL in the config.
    pub fn is_websocket_enabled() -> bool {
        let config = APP.config();
        !config.chain_node.websocket.is_empty()
    }
    
    /// Subscribes to the filtered WebSocket events and processes incoming messages.
    pub async fn subscribe(&self) -> Result<(), Error> {
        use uuid::Uuid;
        
        let config = APP.config();

        let kl = config.provider.p11hsm.key_label.clone();
        // let prefix = config.chain_node.prefix.clone();
        let my_addr = self.get_my_addr(kl).await?;

        let ws_url = Url::parse(&config.chain_node.websocket)
            .map_err(|e| ErrorKind::Config.context(format!("failed to parse websocket URL: {}", e)))?;

        // Connect to WebSocket
        let (mut ws_stream, _) = connect_async(ws_url)
            .await
            .map_err(|e| ErrorKind::WebsocketError.context(format!("failed to connect to websocket: {}", e)))?;

        for (i, query) in WEBSOCKET_SUBSCRIBE_QUERIES.iter().enumerate() {
            let mut appended_query = query.clone();
            if i <= 2 {
                appended_query = format!(
                    "{query} AND {WASM}.{AURUM_BENEFICIARY_KEY}='{my_addr}'"
                );
            }
            // Subscribe to events
            let subscribe_msg = json!({
            "jsonrpc": WEBSOCKET_SUBSCRIBE_JSONRPC_VERSION,
            "id": format!("{}-{}", WEBSOCKET_SUBSCRIBE_ID_PREFIX, Uuid::new_v4()),
            "method": "subscribe",
            "params": {
                "query": appended_query
            }
            });
            info!("subscription {}: {}", i, subscribe_msg.to_string());

            // Send subscription request
            ws_stream
                .send(Message::Text(subscribe_msg.to_string()))
                .await
                .expect("Failed to send subscription");
        }
        // Process incoming messages
        while let Some(msg) = ws_stream.next().await {
            match msg {
                Ok(Message::Text(text)) => {
                    self.handle_message(&text).await?;
                }
                Err(e) => warn!("WebSocket error: {}", e),
                _ => {} // Ignore other message types
            }
        }

        Ok(())
    }

    async fn handle_message(&self, msg: &str) -> Result<(), Error> {
        // Parse the message and extract the relevant fields
        let parsed: serde_json::Value = serde_json::from_str(msg)?;
        if let Some(result) = parsed.get("result") {
            // make sure result.query is one of the subscribed queries
            if let Some(query) = result["query"].as_str() {
                if WEBSOCKET_SUBSCRIBE_QUERIES.iter().enumerate().any(|(_, q)| {
                    query.starts_with(q)
                }) {
                    if let Some(data) = result.get("data") {
                        // get data type: must exist
                        let data_type = data["type"].as_str().expect("data type must exist!");

                        // get tx_hash: one and only one
                        let tx_hash = result["events"]
                            .get("tx.hash")
                            .expect("consolidated events must have tx.hash!")
                            .as_array()
                            .expect("tx.hash must be an array!");
                        assert_eq!(tx_hash.len(), 1, "tx.hash array must have only one element!");
                        let tx_hash = tx_hash
                            .first()
                            .expect("tx.hash array must have at least one element!")
                            .as_str()
                            .expect("tx.hash must be a string!");

                        info!("New CosmWasm Event by query: {}", query);
                        info!("data type: {} tx_hash: {}", data_type, tx_hash);

                        // select action, tracking_id, originator, beneficiary, amount, denom
                        // use raw_events: all expect(...) can be replaced with unwrap()
                        let raw_events = &data["value"]["TxResult"]["result"]["events"].as_array().expect("events must be an array!");

                        let aurum_event = &raw_events.iter().find(
                            |event| {
                                event["type"].as_str().expect("event type must exist!") == WASM &&
                                    event["attributes"].as_array().expect("attributes must be an array!").iter()
                                        .any(|attr| attr["key"].as_str().expect("key must exist!") == AURUM_ACTION_KEY)
                            }
                        ).expect("aurum event must exist!");

                        let action = aurum_event["attributes"].as_array().expect("attributes must be an array!")
                            .iter().find(|attr| attr["key"].as_str().expect("key must exist!") == AURUM_ACTION_KEY)
                            .expect("action must exist!");
                        info!("raw aurum action - {}: {}", action["key"].as_str().expect("key must exist!"), action["value"].as_str().expect("value must exist!"));
                        let action = action["value"].as_str().expect("action must exist!");

                        let tracking_id = aurum_event["attributes"].as_array().expect("attributes must be an array!")
                            .iter().find(|attr| attr["key"].as_str().expect("key must exist!") == AURUM_TRACKING_ID_KEY)
                            .expect("tracking_id must exist!");
                        info!("raw aurum tracking_id - {}: {}", tracking_id["key"].as_str().expect("key must exist!"), tracking_id["value"].as_str().expect("value must exist!"));
                        let tracking_id = tracking_id["value"].as_str().expect("tracking_id must exist!");

                        if action != UPDATE_TXHASH {
                            let originator = aurum_event["attributes"].as_array().expect("attributes must be an array!")
                                .iter().find(|attr| attr["key"].as_str().expect("key must exist!") == AURUM_ORIGINATOR_KEY)
                                .expect("originator must exist!");
                            info!("raw aurum originator - {}: {}", originator["key"].as_str().expect("key must exist!"), originator["value"].as_str().expect("value must exist!"));
                            let originator = originator["value"].as_str().expect("originator must exist!");

                            let beneficiary = aurum_event["attributes"].as_array().expect("attributes must be an array!")
                                .iter().find(|attr| attr["key"].as_str().expect("key must exist!") == AURUM_BENEFICIARY_KEY)
                                .expect("beneficiary must exist!");
                            info!("raw aurum beneficiary - {}: {}", beneficiary["key"].as_str().expect("key must exist!"), beneficiary["value"].as_str().expect("value must exist!"));
                            let beneficiary = beneficiary["value"].as_str().expect("beneficiary must exist!");

                            let amount = aurum_event["attributes"].as_array().expect("attributes must be an array!")
                                .iter().find(|attr| attr["key"].as_str().expect("key must exist!") == AURUM_AMOUNT_KEY)
                                .expect("amount must exist!");
                            info!("raw aurum amount - {}: {}", amount["key"].as_str().expect("key must exist!"), amount["value"].as_str().expect("value must exist!"));
                            let amount = amount["value"].as_str().expect("amount must exist!");

                            let denom = aurum_event["attributes"].as_array().expect("attributes must be an array!")
                                .iter().find(|attr| attr["key"].as_str().expect("key must exist!") == AURUM_DENOM_KEY)
                                .expect("denom must exist!");
                            info!("raw aurum denom - {}: {}", denom["key"].as_str().expect("key must exist!"), denom["value"].as_str().expect("value must exist!"));
                            let denom = denom["value"].as_str().expect("denom must exist!");
                            let map = Arc::clone(&self.map);
                            map.lock().unwrap().insert(
                                tracking_id.to_string(),
                                AurumAttrs {
                                    action: action.to_string(),
                                    tracking_id: tracking_id.to_string(),
                                    originator: originator.to_string(),
                                    beneficiary: beneficiary.to_string(),
                                    amount: amount.to_string(),
                                    denom: denom.to_string(),
                                    txhash: tx_hash.to_string(),
                                }
                            );
                    } else {
                            let aurum_txhash = aurum_event["attributes"].as_array().expect("attributes must be an array!").iter().find(|attr| attr["key"].as_str().expect("key must exist!") == AURUM_TXHASH_KEY).expect("aurum_txhash must exist!");
                            info!("raw aurum_txhash - {}: {}", aurum_txhash["key"].as_str().expect("key must exist!"), aurum_txhash["value"].as_str().expect("value must exist!"));
                            let aurum_txhash = aurum_txhash["value"].as_str().expect("aurum_txhash must exist!");
                            
                            let map = Arc::clone(&self.map);
                            let aurum_attrs = map.lock().unwrap().remove(tracking_id);
                            if let Some(attrs) = aurum_attrs {
                                info!("aurum_attrs found for tracking_id: {}: {}", tracking_id, attrs);
                                let _ = self.call_from_member(aurum_txhash.to_string(), tx_hash.to_string(), tracking_id.to_string()).await;
                            } else {
                                info!("aurum_attrs not found for tracking_id: {}", tracking_id);
                            }
                            // this will cause compilation error: MutexGuard is not Send
                            /*
                            match map.lock() {
                                Ok(mut map) => {
                                    if map.contains_key(tracking_id) {
                                        let aurum_attrs = map.remove(tracking_id).unwrap();
                                        info!("aurum_attrs found for tracking_id: {}: {}", tracking_id, aurum_attrs);
                                        {
                                            let _ = self.call_from_member(aurum_txhash.to_string(), tx_hash.to_string(), tracking_id.to_string()).await;
                                        };
                                    }
                                }
                                Err(e) => {
                                    error!("Failed to lock MAP: {}", e);
                                }
                            }
                            */
                        }
                        info!("-------------------");
                    }
                }
            }
        }

        Ok(())

    }

    async fn get_my_addr(&self, kl: String) -> Result<String, Error> {

        let req = Request::new(GetPubKeyRequest {
            key_label: Some(kl),
        });

        let resp = self.wallet_svc
            .get_pub_key(req)
            .await?
            .into_inner();

        Ok(resp.acct_addr)
    }

    // wrapper around WalletService.from_member
    // todo: potentially send more data such as originator, beneficiary, amount, denom for deeper validation.
    async fn call_from_member(&self, txhash1: String, txhash2: String, tracking_id: String) {
        let req = Request::new(FromMemberRequest {
            tracking_id,
            txhash1,
            txhash2,
        });

        let resp = self.wallet_svc
            .from_member(req)
            .await;

        match resp {
            Ok(resp) => {
                info!("from_member response: {}", resp.into_inner().transaction_status);
            }
            Err(e) => {
                status_err!("from_member failed: {}", e);
                std::process::exit(1);
            }
        }
    }
}