use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Default, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
/// configuration for IBM MQ
pub struct IBMMQConfig {
    /// whether the configuration is applicable
    pub applicable: bool,
    /// whether the server is in dev mode
    pub dev_mode: bool,
    /// mqweb host or address
    pub mqweb_host: String,
    /// mqweb port
    pub mqweb_port: String,
    /// rest api base
    pub api_base: String,
    /// rest token
    pub csrftoken: String,
    /// qmgr name
    pub queue_manager: String,
    /// api app user
    pub app_user: String,
    /// api app password
    pub app_password: String,
    /// listener pool interval in ms
    pub listener_interval: u64,
    /// request queue for wallet
    pub request_queue: String,
    /// backout queue for wallet
    pub error_queue: String,
    /// if branch wallet, topic string for payment notifysender
    pub payment_notifysender_topic_string: String,
    /// if branch wallet, topic string for payment tranfernotification
    pub payment_transfernotification_topic_string: String,
    /// if branch wallet, topic string for defunding notifysender
    pub defunding_notifysender_topic_string: String,
    /// if issuer wallet, topic string for defunding transfernotification
    pub defunding_transfernotification_topic_string: String,
    /// if issuer wallet, topic string for funding notifysender
    pub funding_notifysender_topic_string: String,
}

impl IBMMQConfig {
    /// validate a given queue against the configuration
    pub fn is_queue_valid(&self, queue: &str) -> bool {
        queue == self.request_queue || queue == self.error_queue
    }

    /// validate a given topic string against the configuration
    pub fn is_topic_valid(&self, topic: &str) -> bool {
        topic == self.payment_notifysender_topic_string
            || topic == self.payment_transfernotification_topic_string
            || topic == self.defunding_notifysender_topic_string
            || topic == self.defunding_transfernotification_topic_string
            || topic == self.funding_notifysender_topic_string
    }
}
