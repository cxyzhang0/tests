use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Default, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct EchoConfig {
    /// The echo string.
    pub echo: String,
}

/*
impl Default for Echo {
    fn default() -> Self {
        Self {
            echo: "pong".to_owned(),
        }
    }
}
*/
