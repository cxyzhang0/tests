use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Default, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct KafkaConfig {
    pub bootstrap_servers: String,
    pub subscribe_topic: String,
    pub consumer_group_id: String,
    pub publish_topic: String,
}
