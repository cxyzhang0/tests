use std::fmt;

#[cfg(feature = "p11hsm")]
use crate::config::provider::p11hsm::P11hsmConfig;
#[cfg(feature = "tsstrio")]
use crate::config::provider::tsstrio::TssTrioConfig;
use serde::{Deserialize, Serialize};

/// Configuration for PKCS11 HSM
#[cfg(feature = "p11hsm")]
pub mod p11hsm;
/// Configuration for TSS TRIO
#[cfg(feature = "tsstrio")]
pub mod tsstrio;

#[derive(Clone, Debug, Default, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
/// Provider configuration
pub struct ProviderConfig {
    /// PKCS11 HSM configuration
    #[cfg(feature = "p11hsm")]
    #[serde(default)]
    pub p11hsm: P11hsmConfig,
    /// TSS TRIO configuration
    #[cfg(feature = "tsstrio")]
    #[serde(default)]
    pub tsstrio: TssTrioConfig,
}

/// Types of cryptographic keys
// TODO(tarcieri): move this into a provider-agnostic module
#[derive(Clone, Debug, Default, Deserialize, Serialize)]
pub enum KeyType {
    /// Account keys
    #[serde(rename = "account")]
    #[default]
    Account,

    /// Consensus keys
    #[serde(rename = "consensus")]
    Consensus,
}

// default is derived from the Default trait so the following is not needed
/*
impl Default for KeyType {
    fn default() -> Self {
        KeyType::Account
    }
}
*/
impl fmt::Display for KeyType {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            KeyType::Account => f.write_str("account"),
            KeyType::Consensus => f.write_str("consensus"),
        }
    }
}
