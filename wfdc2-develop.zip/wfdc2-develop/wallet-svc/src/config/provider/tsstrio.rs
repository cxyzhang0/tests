use serde::{Deserialize, Serialize};

use crate::config::provider::KeyType;

#[derive(Clone, Debug, Default, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
/// Configure struct for TSS TRIO
pub struct TssTrioConfig {
    /// path to local share
    pub share: Option<String>,
    
    /// algorithm
    pub algorithm: String,

    /// path to user secret key (ed25519)
    pub user_sk: String,

    /// hex encoded server public key
    pub server_vk: String,

    /// server url
    pub server: String,

    /// finish server url
    pub finish_server: String,
    
    /// chain path
    pub chain_path: String,

    /// dkg endpoint
    pub keygen_endpoint: String,

    /// keyshare refresh endpoint
    pub refresh_endpoint: String,

    /// keyshare recovery endpoint
    pub recovery_endpoint: String,

    /// dsg endpoint
    pub sign_endpoint: String,
    
    /// presign endpoint
    pub presign_endpoint: String,
    
    /// finish endpoint
    pub finish_endpoint: String,

    /// Type of key (account vs consensus, default consensus)
    #[serde(default)]
    pub key_type: KeyType,
}
