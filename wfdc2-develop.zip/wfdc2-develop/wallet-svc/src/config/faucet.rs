use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Default, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct FaucetConfig {
    pub grpc: String,
    pub address: String,
    pub allowance_value: String,
    pub hours_to_expire: u64,
}
