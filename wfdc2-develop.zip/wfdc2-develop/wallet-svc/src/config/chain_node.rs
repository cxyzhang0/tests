use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Default, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ChainNodeConfig {
    pub grpc: String,
    pub websocket: String,
    pub prefix: String,
    pub gas_denom: String,
    pub gas_price: String,
    pub gas_adjustment: String,
    pub tx_poll_interval: u64,
    pub tx_poll_timeout: u64,
    pub tokenfactory_contract: String,
    pub aurum_contract: String,
}
