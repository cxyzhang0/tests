//! mq related artifacts
use std::time::Duration;

use abscissa_core::tracing::{error, info};
use abscissa_core::{format_err, Application};
use abscissa_tokio::tokio;
use base64::{engine::general_purpose, Engine};
use serde::Deserialize;

use wfdc2_proto::wfdc2::wallet::v1::PaymentRequest;

use crate::application::APP;
use crate::config::IBMMQConfig;
use crate::error::Error;
use crate::error::ErrorKind::MqError;
use crate::server::WalletService;

/// Struct for REST API request
#[derive(Default)]
pub struct Request {
    url: String,
    base64: String,
    content_type: String,
    csrftoken: String,
}

impl Request {
    /// caller ensures queue is either request_queue or error_queue in the config
    pub fn new_for_queue(conf: &IBMMQConfig, queue: String) -> Self {
        Self {
            url: Self::url_for_queue(conf, queue),
            base64: Self::base64(conf),
            content_type: Self::content_type(),
            csrftoken: conf.csrftoken.to_string(),
        }
    }

    /// caller ensures topic_string is one of the topic stings in the config
    pub fn new_for_topic(conf: &IBMMQConfig, topic_string: String) -> Self {
        Self {
            url: Self::url_for_topic(conf, topic_string),
            base64: Self::base64(conf),
            content_type: Self::content_type(),
            csrftoken: conf.csrftoken.to_string(),
        }
    }

    /// forms the URL for queue
    /// caller ensures queue is either request_queue or error_queue in the config
    fn url_for_queue(conf: &IBMMQConfig, queue: String) -> String {
        let https = "https://";
        // Combines variables to form URL
        let url = format!(
            "{}{}:{}{}{}{}{}{}{}",
            https,
            &conf.mqweb_host,
            &conf.mqweb_port,
            &conf.api_base,
            "messaging/qmgr/",
            &conf.queue_manager,
            "/queue/",
            queue,
            "/message"
        );
        url
    }

    /// forms the URL for topic
    /// caller ensures topic_string is one of the topic strings in the config
    fn url_for_topic(conf: &IBMMQConfig, topic_string: String) -> String {
        let https = "https://";
        // combines variables to form URL
        let url = format!(
            "{}{}:{}{}{}{}{}{}{}",
            https,
            &conf.mqweb_host,
            &conf.mqweb_port,
            &conf.api_base,
            "messaging/qmgr/",
            &conf.queue_manager,
            "/topic/",
            topic_string,
            "/message"
        );
        url
    }

    /// encode basic authentication based on user and password
    fn base64(conf: &IBMMQConfig) -> String {
        format!(
            "{} {}",
            "Basic",
            general_purpose::STANDARD.encode(format!("{}:{}", &conf.app_user, &conf.app_password))
        )
    }

    /// sets correct content type
    fn content_type() -> String {
        "application/json".to_owned()
    }

    /// deque
    pub async fn rest_get(&self, is_dev: bool) -> Result<reqwest::Response, reqwest::Error> {
        let client = reqwest::Client::builder()
            .danger_accept_invalid_certs(is_dev)
            .build()?;
        // let client = reqwest::Client::new(); // use builder for better error handling
        self.rest_get_with_client(&client).await
    }

    /// deque with a given client
    pub async fn rest_get_with_client(
        &self,
        client: &reqwest::Client,
    ) -> Result<reqwest::Response, reqwest::Error> {
        let res = client
            .delete(&self.url)
            .header("Authorization", &self.base64)
            .header("Content-Type", &self.content_type)
            .header("ibm-mq-rest-csrf-token", &self.csrftoken)
            // .header("X-CSRF-Token", &self.csrftoken)
            .send()
            .await?;
        Ok(res)
    }

    /// put a message on queue or publish to a topic
    pub async fn rest_post(
        &self,
        msg: String,
        is_dev: bool,
    ) -> Result<reqwest::Response, reqwest::Error> {
        let client = reqwest::Client::builder()
            .danger_accept_invalid_certs(is_dev)
            .build()?;
        self.rest_post_with_client(&client, msg).await
    }

    /// put a message on queue or publish to a topic with a given client
    pub async fn rest_post_with_client(
        &self,
        client: &reqwest::Client,
        msg: String,
    ) -> Result<reqwest::Response, reqwest::Error> {
        let res = client
            .post(&self.url)
            .header("Authorization", &self.base64)
            .header("Content-Type", &self.content_type)
            .header("ibm-mq-rest-csrf-token", &self.csrftoken)
            .body(msg)
            .send()
            .await?;
        Ok(res)
    }

    /// return the rest url
    pub fn get_url(&self) -> String {
        self.url.clone()
    }

    /// return the base64 encoded user:password
    pub fn get_base64(&self) -> String {
        self.base64.clone()
    }

    /// return the content type
    pub fn get_content_type(&self) -> String {
        self.content_type.clone()
    }

    /// return the csrf token
    pub fn get_csrftoken(&self) -> String {
        self.csrftoken.clone()
    }
}

/// this is the listener for the IBM MQ
pub async fn listener() {
    let config = APP.config();

    let client = reqwest::Client::builder()
        .danger_accept_invalid_certs(config.ibm_mq.dev_mode)
        .build()
        .unwrap();

    let request = Request::new_for_queue(&config.ibm_mq, config.ibm_mq.request_queue.clone());

    let request_bo = Request::new_for_queue(&config.ibm_mq, config.ibm_mq.error_queue.clone());

    let interval = Duration::from_millis(config.ibm_mq.listener_interval);

    let mut is_connect_error = false;
    loop {
        match request.rest_get_with_client(&client).await {
            Ok(res) => {
                is_connect_error = false;
                match res.text_with_charset("utf-8").await {
                    Ok(body) => {
                        // info!("mq listener - got message body: {}", body);
                        // process the message
                        if body.is_empty() {
                            tokio::time::sleep(interval).await;
                        } else {
                            match parse_payment_request::<PaymentRequest>(&body) {
                                Ok(payment_req) => {
                                    info!("mq listener - got payment request: {:?}", payment_req);
                                    // process payment request
                                    tokio::spawn(async move {
                                        let ws = WalletService::default();
                                        let _ = ws.process_payment_request(payment_req).await;
                                    });
                                }
                                Err(e) => {
                                    info!("mq listener - payment request parse error: {}", e);
                                    request_bo
                                        .rest_post_with_client(
                                            &client,
                                            format!("parse error: {}; body: {}", e, body),
                                        )
                                        .await
                                        .unwrap();
                                }
                            }
                        }
                    }
                    Err(e) => {
                        info!(
                            "mq listener - utf-8 parse error: detail: {}, {}",
                            get_error_detail(&e),
                            e
                        );
                        request_bo
                            .rest_post_with_client(&client, e.to_string())
                            .await
                            .unwrap();
                    }
                }
            }
            Err(e) => {
                // TODO: do we need to check other error types? also, may need to extend interval if error continues.
                if !is_connect_error {
                    error!("mq listener error: detail: {}, {}", get_error_detail(&e), e);
                }
                tokio::time::sleep(interval).await;
                is_connect_error = e.is_connect();
            }
        }
    }
}

pub(crate) fn get_error_detail(e: &reqwest::Error) -> String {
    let mut error_string: String = "".to_string();
    if e.is_body() {
        error_string += "body/";
    }
    if e.is_builder() {
        error_string += "builder/";
    }
    if e.is_connect() {
        error_string += "connect/";
    }
    if e.is_decode() {
        error_string += "decode/";
    }
    if e.is_redirect() {
        error_string += "redirect/";
    }
    if e.is_request() {
        error_string += "request/";
    }
    if e.is_status() {
        error_string += "status/";
    }
    if e.is_timeout() {
        error_string += "timeout/";
    }
    error_string
}

/// generic json parser
pub fn parse_payment_request<'a, T>(body: &'a str) -> Result<T, Error>
where
    T: Deserialize<'a>,
{
    let payment_req: T = serde_json::from_str(body)
        .map_err(|e| format_err!(MqError, "parse_payment_request error: {}", e))?;
    Ok(payment_req)
}
