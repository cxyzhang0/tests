# WalletSvc

WalletSvc is an application interacting with the tokenfactory Cosmos SDK chain via cosmwasm smart contracts. Mostly importantly, the wallet private key is protected by HSM.

## Getting Started

This application is authored using [Abscissa], a Rust application framework.

For more information, see:

[Documentation]

[Abscissa]: https://github.com/iqlusioninc/abscissa
[Documentation]: https://docs.rs/abscissa_core/

See [examples of running the app.](./scripts.md)