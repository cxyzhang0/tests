```shell
# kafka
dkc -f kafka-docker-compose.yml up -d
dkc -f kafka-docker-compose.yml down

docker exec -it kafka /bin/bash
 
## create topics
### issuer: request and response
docker exec -it kafka /opt/kafka/bin/kafka-topics.sh \
 --bootstrap-server localhost:9092 \
 --create \
 --topic gbf.gbfdlt.request.issuer \
 --partitions 3 \
 --replication-factor 1 

docker exec -it kafka /opt/kafka/bin/kafka-topics.sh \
 --bootstrap-server localhost:9092 \
 --create \
 --topic gbfdlt.gbf.response.issuer \
 --partitions 3 \
 --replication-factor 1 

### usa: request and response
docker exec -it kafka /opt/kafka/bin/kafka-topics.sh \
 --bootstrap-server localhost:9092 \
 --create \
 --topic gbf.gbfdlt.request.usa \
 --partitions 3 \
 --replication-factor 1 

docker exec -it kafka /opt/kafka/bin/kafka-topics.sh \
 --bootstrap-server localhost:9092 \
 --create \
 --topic gbfdlt.gbf.response.usa \
 --partitions 3 \
 --replication-factor 1 

### can: request and response
docker exec -it kafka /opt/kafka/bin/kafka-topics.sh \
 --bootstrap-server localhost:9092 \
 --create \
 --topic gbf.gbfdlt.request.can \
 --partitions 3 \
 --replication-factor 1 

docker exec -it kafka /opt/kafka/bin/kafka-topics.sh \
 --bootstrap-server localhost:9092 \
 --create \
 --topic gbfdlt.gbf.response.can \
 --partitions 3 \
 --replication-factor 1 
  
 
docker exec -it kafka /opt/kafka/bin/kafka-topics.sh \
 --bootstrap-server localhost:9092 \
 --list

docker exec -it kafka /opt/kafka/bin/kafka-topics.sh \
 --bootstrap-server localhost:9092 \
 --describe \
 --topic gbf.gbfdlt.request.can
    
docker exec -it kafka /opt/kafka/bin/kafka-consumer-groups.sh \
 --bootstrap-server localhost:9092 \
 --describe \
 --group CAN_GROUP
 
docker exec -it kafka /opt/kafka/bin/kafka-console-producer.sh \
 --topic gbf.gbfdlt.request.can \
 --bootstrap-server localhost:9092

docker exec -it kafka /opt/kafka/bin/kafka-console-consumer.sh \
 --topic gbf.gbfdlt.request.can \
 --from-beginning \
 --bootstrap-server localhost:9092

```