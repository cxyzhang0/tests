```shell
# kafka
dkc -f kafka-docker-compose.yml up -d
dkc -f kafka-docker-compose.yml down

docker exec -it kafka /bin/bash

docker exec -it kafka /opt/kafka/bin/kafka-topics.sh \
 --bootstrap-server localhost:9092 \
 --create \
 --topic gbf.gbfdlt.request.issuer \
 --partitions 3 \
 --replication-factor 1 

docker exec -it kafka /opt/kafka/bin/kafka-topics.sh \
 --bootstrap-server localhost:9092 \
 --create \
 --topic gbfdlt.gbf.response.issuer \
 --partitions 3 \
 --replication-factor 1 
 
docker exec -it kafka /opt/kafka/bin/kafka-topics.sh \
 --bootstrap-server localhost:9092 \
 --list

docker exec -it kafka /opt/kafka/bin/kafka-topics.sh \
 --bootstrap-server localhost:9092 \
 --describe \
 --topic gbf.gbfdlt.request.can
    
docker exec -it kafka /opt/kafka/bin/kafka-consumer-groups.sh \
 --bootstrap-server localhost:9092 \
 --describe \
 --group CAN_GROUP
 
docker exec -it kafka /opt/kafka/bin/kafka-console-producer.sh \
 --topic gbf.gbfdlt.request.can \
 --bootstrap-server localhost:9092

docker exec -it kafka /opt/kafka/bin/kafka-console-consumer.sh \
 --topic gbf.gbfdlt.request.can \
 --from-beginning \
 --bootstrap-server localhost:9092

```