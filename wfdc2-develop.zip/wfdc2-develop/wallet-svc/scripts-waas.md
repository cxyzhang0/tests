# scripts for wallet-svc in preparation of wass integtration
## cli
```shell
# in root
## build

cargo build -p wallet_svc --no-default-features --features=p11hsm --release

alias ws=./target/release/wallet_svc

## basic chect 
ws -h
ws -c ./wallet-svc/wallet_svc.toml echo
ws -c ./wallet-svc/wallet_svc.toml async-echo
 
## generate keys
ws -c ./wallet-svc/wallet_svc-faucet.toml keys gen-key -l "Slot Token 0/wfdc2/faucet/1" -t "Account" -a "Secp256k1" --persistent
ws -c ./wallet-svc/wallet_svc-owner.toml keys gen-key -l "Slot Token 0/wfdc2/owner/1" -t "Account" -a "Secp256k1" --persistent
ws -c ./wallet-svc/wallet_svc-masterminter.toml keys gen-key -l "Slot Token 0/wfdc2/masterminter/1" -t "Account" -a "Secp256k1" --persistent
ws -c ./wallet-svc/wallet_svc-mintercontroller.toml keys gen-key -l "Slot Token 0/wfdc2/mintercontroller/1" -t "Account" -a "Secp256k1" --persistent
ws -c ./wallet-svc/wallet_svc-minter.toml keys gen-key -l "Slot Token 0/wfdc2/minter/1" -t "Account" -a "Secp256k1" --persistent
ws -c ./wallet-svc/wallet_svc.toml keys gen-key -l "Slot Token 0/wfdc2/blacklister/1" -t "Account" -a "Secp256k1" --persistent
ws -c ./wallet-svc/wallet_svc.toml keys gen-key -l "Slot Token 0/wfdc2/pauser/1" -t "Account" -a "Secp256k1" --persistent
ws -c ./wallet-svc/wallet_svc-usa.toml keys gen-key -l "Slot Token 0/wfdc2/usa/1" -t "Account" -a "Secp256k1" --persistent
ws -c ./wallet-svc/wallet_svc-can.toml keys gen-key -l "Slot Token 0/wfdc2/can/1" -t "Account" -a "Secp256k1" --persistent
ws -c ./wallet-svc/wallet_svc.toml keys gen-key -l "Slot Token 0/wfdc2/user1/1" -t "Account" -a "Secp256k1" --persistent
ws -c ./wallet-svc/wallet_svc.toml keys gen-key -l "Slot Token 0/wfdc2/user2/1" -t "Account" -a "Secp256k1" --persistent

## use these address in tokenfactory play_wallet.sh
ws -c ./wallet-svc/wallet_svc-faucet.toml keys get-pub-key -l "Slot Token 0/wfdc2/faucet/1" # wf1qaeezv8jp5kyye3ykassrt5e7vucxuy0uxp4ar
ws -c ./wallet-svc/wallet_svc.toml keys get-pub-key -l "Slot Token 0/wfdc2/owner/1" # wf1v939lk0wvq3daxafadvs07ekcg67am7dsyrap7
ws -c ./wallet-svc/wallet_svc.toml keys get-pub-key -l "Slot Token 0/wfdc2/masterminter/1" # wf16f4zjgvu0m5msxh552vx9wqcv78hru9j50ymdj
ws -c ./wallet-svc/wallet_svc.toml keys get-pub-key -l "Slot Token 0/wfdc2/mintercontroller/1" # wf1etnzw2lhydq7dw7uz66qkxwxv9jpcsqu00w5uf
ws -c ./wallet-svc/wallet_svc.toml keys get-pub-key -l "Slot Token 0/wfdc2/minter/1" # wf1kzegqsp06gfsyzkxxzpgfalakl3y2uydphn0qv
ws -c ./wallet-svc/wallet_svc.toml keys get-pub-key -l "Slot Token 0/wfdc2/blacklister/1" # wf1009sd3s088g9wmwqag6pmghr5a429jaaq7rjdj
ws -c ./wallet-svc/wallet_svc.toml keys get-pub-key -l "Slot Token 0/wfdc2/pauser/1" # wf1nvcy5hz3d55lnndhsnhzs4rpu86dpk046h7dnt
ws -c ./wallet-svc/wallet_svc.toml keys get-pub-key -l "Slot Token 0/wfdc2/usa/1" # wf12atm0klmhpp6mp768gf0esxmwcjx8mmazagyvf
ws -c ./wallet-svc/wallet_svc.toml keys get-pub-key -l "Slot Token 0/wfdc2/can/1" # wf1jetp404420sfvjshy9mtp7r8uy87jcym4cskda
ws -c ./wallet-svc/wallet_svc.toml keys get-pub-key -l "Slot Token 0/wfdc2/user1/1" # wf18jvphye4nnlxs4j2p6py3w3ct30emuuq2h7w9q
ws -c ./wallet-svc/wallet_svc.toml keys get-pub-key -l "Slot Token 0/wfdc2/user2/1" # wf13s7azh9xj3x83amz22tr4z73c4dyj0rvej9my4

## query balance
ws -c ./wallet-svc/wallet_svc-usa.toml query get-bank-balance -d "uwfUSD"
ws -c ./wallet-svc/wallet_svc-usa.toml query get-bank-balance -a "wf1v939lk0wvq3daxafadvs07ekcg67am7dsyrap7" -d "uwfUSD"

## load wasm code
ws -c ./wallet-svc/wallet_svc-faucet.toml admin store-code -w ./target/wasm32-unknown-unknown/release/tokenfactory_optimized.wasm

## instantiate tf contract
ws -c ./wallet-svc/wallet_svc-faucet.toml admin instantiate-contract -i 1 -l "tokenfactory" -m "{ \"is_tf\": true }"

## grant fee to owner
ws -c ./wallet-svc/wallet_svc-faucet.toml tx grant-fee-basic-allowance -g "wf1v939lk0wvq3daxafadvs07ekcg67am7dsyrap7" -v 1000000 -e 24
## grant fee to masterminter
ws -c ./wallet-svc/wallet_svc-faucet.toml tx grant-fee-basic-allowance -g "wf16f4zjgvu0m5msxh552vx9wqcv78hru9j50ymdj" -v 1000000 -e 24
## grant fee to mintercontroller
ws -c ./wallet-svc/wallet_svc-faucet.toml tx grant-fee-basic-allowance -g "wf1etnzw2lhydq7dw7uz66qkxwxv9jpcsqu00w5uf" -v 1000000 -e 24
## grant fee to minter
ws -c ./wallet-svc/wallet_svc-faucet.toml tx grant-fee-basic-allowance -g "wf1kzegqsp06gfsyzkxxzpgfalakl3y2uydphn0qv" -v 1000000 -e 24
## grant fee to usa
ws -c ./wallet-svc/wallet_svc-faucet.toml tx grant-fee-basic-allowance -g "wf12atm0klmhpp6mp768gf0esxmwcjx8mmazagyvf" -v 1000000 -e 24
## grant fee to user1
ws -c ./wallet-svc/wallet_svc-faucet.toml tx grant-fee-basic-allowance -g "wf18jvphye4nnlxs4j2p6py3w3ct30emuuq2h7w9q" -v 1000000 -e 24


## query fee grant
ws -c ./wallet-svc/wallet_svc-faucet.toml query get-fee-basic-allowance -g "wf1etnzw2lhydq7dw7uz66qkxwxv9jpcsqu00w5uf"

## set masterminter
ws -c ./wallet-svc/wallet_svc-owner.toml tx update-master-minter -a "wf16f4zjgvu0m5msxh552vx9wqcv78hru9j50ymdj"

## configure mintercontroller
ws -c ./wallet-svc/wallet_svc-masterminter.toml tx configure-minter-controller -c "wf1etnzw2lhydq7dw7uz66qkxwxv9jpcsqu00w5uf" -m "wf1kzegqsp06gfsyzkxxzpgfalakl3y2uydphn0qv"

## configure minter
ws -c ./wallet-svc/wallet_svc-mintercontroller.toml tx configure-minter -a "wf1kzegqsp06gfsyzkxxzpgfalakl3y2uydphn0qv" -d "uwfUSD" -v 10000000000

## mint to some address
ws -c ./wallet-svc/wallet_svc-minter.toml tx mint -h
ws -c ./wallet-svc/wallet_svc-minter.toml tx mint -a "wf12atm0klmhpp6mp768gf0esxmwcjx8mmazagyvf" -d "uwfUSD" -v 10


```

