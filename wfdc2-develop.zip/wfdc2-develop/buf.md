## install buf
```shell
brew install bufbuild/buf/buf
```

## code generate
```shell
# run in top level directory
buf lint
buf format
## generate code
buf generate proto --template ./proto/buf.gen.yaml
## generate with debug
buf generate proto --template ./proto/buf.gen.yaml --debug -v 

```