use alloy::network::TxSigner;
use alloy::{
    primitives::{Address as AlloyAddress, Signature as AlloySignature, B256},
    signers::{Error as AlloySignerError},
};
use alloy::consensus::SignableTransaction;
use cosmrs::bip32::secp256k1::ecdsa::signature::Keypair;
use cosmrs::bip32::secp256k1::Secp256k1;
use ecdsa::{Signature};
use kms_common::async_signer::AsyncSigner;
use kms_common::SignatureError;
use nom::AsBytes;
use prost::bytes::Bytes;
use tonic::async_trait;
use tonic::transport::Channel;
use crate::{kms_proto};
use crate::authenticated_client::AuthenticatedClient;
use crate::error::ErrorKind;
use crate::evm::types::{compute_recovery_id_k256, pk_to_address};
use crate::proto::{KeyType};
use crate::Result;

/// A signer that uses a remote KMS service to sign messages.
#[derive(Debug, Clone)]
pub struct KmsSigner {
    kms_grpc: String,
    kms_provider_uuid: String,
    key_name: String,
    key_type: KeyType,
    vk: ecdsa::VerifyingKey<Secp256k1>,
    jwt: Option<String>,
}

impl KmsSigner {
    /// Create a new KmsSigner
    pub async fn new(kms_grpc: String, kms_provider_uuid: String, key_name: String, key_type: KeyType, jwt: Option<String>) -> Result<Self> {
        let uri = format!("http://{}", &kms_grpc);

        let kms_client = kms_proto::kms_svc_client::KmsSvcClient::connect(uri)
            .await
            .map_err(|e| ErrorKind::Io.context(format!("Failed to connect to KMS server {}", e.to_string())))?;

        let mut kms_client: AuthenticatedClient<kms_proto::kms_svc_client::KmsSvcClient<Channel>> = AuthenticatedClient::new(kms_client, jwt.clone());

        match key_type {
            KeyType::Secp256k1 => {},
            _ => return Err(ErrorKind::InvalidData.context("Invalid key type").into()),
        }

        let kms_req = kms_proto::GetPubKeyRequest {
            header: Some(kms_proto::Header {
                uuid: kms_provider_uuid.clone(),
                app_name: "blkchn_svc".to_string(),
            }),
            key_name: key_name.clone(),
            attributes: Some(kms_proto::KeyAttributes {
                key_type: key_type.into(),
            }),
        };
        let kms_req = kms_client.authenticate(kms_req);

        let kms_resp = kms_client.get_pub_key(kms_req).await
            .map_err(|e| ErrorKind::KmsSvcError.context(format!("Failed to get public key from KMS server: {}", e)))?.into_inner();

        let pk = elliptic_curve::PublicKey::<Secp256k1>::from_sec1_bytes(&kms_resp.pub_key)
            .map_err(|e| ErrorKind::InvalidData.context(format!("Failed to parse public key from KMS server: {}", e)))?;
        let vk = ecdsa::VerifyingKey::from(&pk);

        Ok(Self {
            kms_grpc,
            kms_provider_uuid,
            key_name,
            key_type,
            vk,
            jwt,
        })
    }

    /// returns an alloy signature
    pub async fn alloy_sign_hash(&self, msg_hash: &B256) -> anyhow::Result<AlloySignature, AlloySignerError> {
        // copy hash bytes
        let mut digest_bytes: [u8; 32] = [0u8; 32];
        digest_bytes.copy_from_slice(msg_hash.as_bytes());

        let sig = self.try_sign_prehash(digest_bytes).await?;

        // compute recid via k256
        let recid = compute_recovery_id_k256(digest_bytes, &sig, &self.vk.to_encoded_point(false).as_bytes())
            .map_err(|e| AlloySignerError::message(e.to_string()))?;

        // parity: recid odd -> true
        let parity = (recid & 1) == 1;

        // Convert to alloy Signature (alloy provides constructor that accepts k256 signature + parity)
        let alloy_sig = AlloySignature::from_signature_and_parity(sig, parity);

        Ok(alloy_sig)
    }

    ///
    pub async fn get_authenticated_client(&self) -> Result<AuthenticatedClient<kms_proto::kms_svc_client::KmsSvcClient<Channel>>> {
        let uri = format!("http://{}", &self.kms_grpc);

        let kms_client = kms_proto::kms_svc_client::KmsSvcClient::connect(uri)
            .await
            .map_err(|e| ErrorKind::Io.context(format!("Failed to connect to KMS server {}", e.to_string())))?;

        Ok(AuthenticatedClient::new(kms_client, self.jwt.clone()))
    }
}

impl Keypair for KmsSigner {
    type VerifyingKey = ecdsa::VerifyingKey<Secp256k1>;

    fn verifying_key(&self) -> Self::VerifyingKey {
        self.vk
    }
}

#[async_trait]
impl AsyncSigner<Secp256k1, Signature<Secp256k1>>  for KmsSigner {
    async fn try_sign(&self, msg: &[u8]) -> anyhow::Result<Signature<Secp256k1>, SignatureError> {
        let mut kms_client = self.get_authenticated_client().await
            .map_err(|e| SignatureError::from_source(e))?;

        let kms_req = kms_proto::SignMsgRequest {
            header: Some(kms_proto::Header {
                uuid: self.kms_provider_uuid.clone(),
                app_name: "blkchn_svc".to_string(),
            }),
            key_name: self.key_name.clone(),
            attributes: Some(kms_proto::KeyAttributes {
                key_type: self.key_type.into(),
            }),
            msg: Bytes::from(msg.to_vec()),
        };
        let kms_req = kms_client.authenticate(kms_req);

        let kms_resp = kms_client.sign_msg(kms_req).await
            .map_err(|e| SignatureError::from_source(e))?.into_inner();

        let sig = Signature::<Secp256k1>::from_slice(&kms_resp.sig)?;

        Ok(sig)
    }

    async fn try_sign_prehash(&self, msg_hash: [u8; 32]) -> anyhow::Result<Signature<Secp256k1>, SignatureError> {
        let mut kms_client = self.get_authenticated_client().await
            .map_err(|e| SignatureError::from_source(e))?;

        let kms_req = kms_proto::SignPrehashRequest {
            header: Some(kms_proto::Header {
                uuid: self.kms_provider_uuid.clone(),
                app_name: "blkchn_svc".to_string(),
            }),
            key_name: self.key_name.clone(),
            attributes: Some(kms_proto::KeyAttributes {
                key_type: self.key_type.into(),
            }),
            hash: Bytes::from(msg_hash.to_vec()),
        };
        let kms_req = kms_client.authenticate(kms_req);

        let kms_resp = kms_client.sign_prehash(kms_req).await
            .map_err(|e| SignatureError::from_source(e))?.into_inner();

        let sig = Signature::<Secp256k1>::from_slice(&kms_resp.sig)?;

        Ok(sig)
    }
}

#[async_trait]
impl TxSigner<AlloySignature> for KmsSigner {
    fn address(&self) -> AlloyAddress {
        pk_to_address(self.vk.to_encoded_point(false).as_bytes()).expect("valid verifying key")
    }

    async fn sign_transaction(&self, tx: &mut dyn SignableTransaction<AlloySignature>) -> anyhow::Result<AlloySignature, AlloySignerError>
    {
        let sig_hash = tx.signature_hash();

        self.alloy_sign_hash(&sig_hash).await
    }
}

pub(crate) mod interceptor {
    use tonic::{Request, Status};
    use tonic::metadata::MetadataValue;
    use tonic::service::Interceptor;

    #[derive(Debug, Clone)]
    pub struct JwtInterceptor {
        token: String,
    }

    impl JwtInterceptor {
        pub fn new(token: String) -> Self {
            Self { token }
        }
    }

    impl Interceptor for JwtInterceptor {
        fn call(&mut self, mut req: Request<()>) -> Result<Request<()>, Status> {
            // Intercept the request and perform any necessary logic
            println!("Inside JwtInterceptor - Intercepted request: extensions {:?}; metadata {:?}", req.extensions(), req.metadata());

            // You can modify the request here if needed
            let token: MetadataValue<_> = format!("Bearer {}", self.token)
                .parse()
                .map_err(|e| Status::unauthenticated(format!("Unable to parse jwt token - {}", e)))?;

            req.metadata_mut().insert("authorization", token);

            Ok(req)
        }
    }
}
