use abscissa_core::Application;
use tower_oauth2_resource_server::server::OAuth2ResourceServer;
use tower_oauth2_resource_server::tenant::TenantConfiguration;
use crate::application::APP;
use crate::error::{Error, ErrorKind};

#[derive(Default)]
pub(crate) struct AuthZServer;

impl AuthZServer {
    /// Decide if authz server is enabled from a raw URL string.
    pub(crate) fn is_authz_server_enabled_value(authz_server: &str) -> bool {
        !authz_server.trim().is_empty()
    }

    /// Build an OAuth2ResourceServer using the same config fields as production.
    pub(crate) async fn build_authz_server_from_parts(
        authz_server: &str,
        audience: &str,
        jwks_url: &str,
    ) -> Result<OAuth2ResourceServer, Error> {
        let tenant_config = TenantConfiguration::builder(authz_server.to_owned())
            .audiences(&[audience])
            .jwks_url(jwks_url.to_owned())
            .build()
            .await
            .map_err(|e| {
                ErrorKind::AuthZError.context(format!("Failed to build TenantConfiguration: {}", e))
            })?;

        let oauth2_resource_server = OAuth2ResourceServer::builder()
            .add_tenant(tenant_config)
            .build()
            .await
            .map_err(|e| {
                ErrorKind::AuthZError.context(format!(
                    "Failed to build OAuth2ResourceServer: {}",
                    e
                ))
            })?;

        Ok(oauth2_resource_server)
    }

    pub(crate) fn is_authz_server_enabled() -> bool {
        let config = APP.config();
        Self::is_authz_server_enabled_value(&config.blkchn_server.authz_server)
    }

    pub(crate) async fn get_authz_server() -> Result<OAuth2ResourceServer, Error> {
        let config = APP.config();
        Self::build_authz_server_from_parts(
            &config.blkchn_server.authz_server,
            &config.blkchn_server.audience,
            &config.blkchn_server.jwks_url,
        )
            .await
    }
}

