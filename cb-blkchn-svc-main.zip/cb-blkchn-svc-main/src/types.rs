use crate::error::{Error, ErrorKind};
use crate::proto::{NtfDenom, TfDenom, Chain};

#[derive(Debug, Clone)]
pub enum Denom {
    Tf(TfDenom),
    Ntf(NtfDenom),
}

impl TryFrom<String> for Denom {
    type Error = Error;

    fn try_from(value: String) -> Result<Self, Self::Error> {
        match TfDenom::from_str_name(value.as_ref()) {
            Some(denom) => Ok(Denom::Tf(denom)),
            None => {
                match NtfDenom::from_str_name(value.as_ref()) {
                    Some(denom) => Ok(Denom::Ntf(denom)),
                    None => Err(ErrorKind::InvalidData.context("Invalid denom").into()),
                }
            }
        }

        // match value.as_str() {
        //     "uwfUSD" => Ok(Denom::Tf(TfDenom::UwfUsd)),
        //     "wSAT" => Ok(Denom::Tf(TfDenom::WSat)),
        //     "wWEI" => Ok(Denom::Tf(TfDenom::WWei)),
        //     "wLAM" => Ok(Denom::Tf(TfDenom::WLam)),
        //     "SAT" => Ok(Denom::Ntf(NtfDenom::Sat)),
        //     "WEI" => Ok(Denom::Ntf(NtfDenom::Wei)),
        //     "LAM" => Ok(Denom::Ntf(NtfDenom::Lam)),
        //     _ => Err(ErrorKind::InvalidData.context("Invalid denom").into()),
        // }
    }


}

#[derive(Debug)]
pub enum ChainType {
    Cosmos,
    Evm,
    Bitcoin,
    Unsupported,
}

// impl From<Option<Chain>> for ChainType {
//     fn from(value: Option<Chain>) -> Self {
//         match value.unwrap_or(Chain::Tokenfactory) {
//             Chain::Ethereum | Chain::Base | Chain::Anvil => ChainType::Evm,
//             Chain::Tokenfactory => ChainType::Cosmos,
//             Chain::Bitcoin => ChainType::Bitcoin,
//             _ => ChainType::Unsupported,
//         }
//     }
// }

impl From<Chain> for ChainType {
    fn from(value: Chain) -> Self {
        match value {
            Chain::Ethereum | Chain::Base | Chain::Anvil => ChainType::Evm,
            Chain::Tokenfactory => ChainType::Cosmos,
            Chain::Bitcoin => ChainType::Bitcoin,
            _ => ChainType::Unsupported,
        }
    }
}

#[cfg(test)]
mod types_tests {
    use crate::types::{ChainType, Denom};
    use crate::proto::{Chain, NtfDenom, TfDenom};

    #[test]
    fn denom_try_from_tf_branch_uses_proto_enum_names() {
        // Avoid hardcoding strings by using generated enum names
        let v = TfDenom::from_i32(0).expect("TfDenom should have 0 variant");
        let name = v.as_str_name().to_string();

        let d = Denom::try_from(name).expect("should parse a valid TfDenom");
        match d {
            Denom::Tf(_) => {}
            _ => panic!("expected Denom::Tf"),
        }
    }

    #[test]
    fn denom_try_from_ntf_branch_uses_proto_enum_names() {
        let v = NtfDenom::from_i32(0).expect("NtfDenom should have 0 variant");
        let name = v.as_str_name().to_string();

        let d = Denom::try_from(name).expect("should parse a valid NtfDenom");
        match d {
            Denom::Ntf(_) => {}
            _ => panic!("expected Denom::Ntf"),
        }
    }

    #[test]
    fn denom_try_from_invalid_errors() {
        let err = Denom::try_from("THIS_IS_NOT_A_REAL_DENOM".to_string()).unwrap_err();
        let s = format!("{err}");
        assert!(!s.is_empty());
    }

    #[test]
    fn chain_type_mapping_is_covered() {
        assert!(matches!(ChainType::from(Chain::Tokenfactory), ChainType::Cosmos));
        assert!(matches!(ChainType::from(Chain::Ethereum), ChainType::Evm));
        assert!(matches!(ChainType::from(Chain::Bitcoin), ChainType::Bitcoin));
    }
}

#[cfg(test)]
mod tf_types_tests {
    use crate::tf::types::pk_to_address;
    use prost::bytes::Bytes;

    #[test]
    fn pk_to_address_invalid_pubkey_errors() {
        let bad = Bytes::from_static(&[1, 2, 3, 4, 5]);
        let prefix = "cosmos".to_string();

        let err = pk_to_address(&bad, &prefix).unwrap_err();
        let s = format!("{err}");
        assert!(!s.is_empty());
    }

    #[test]
    fn pk_to_address_valid_pubkey_works() {
        use k256::ecdsa::SigningKey;

        let sk = SigningKey::random(&mut rand::thread_rng());
        let vk = sk.verifying_key();
        let uncompressed = vk.to_encoded_point(false);
        let pk_bytes = Bytes::from(uncompressed.as_bytes().to_vec());

        let prefix = "cosmos".to_string();
        let account = pk_to_address(&pk_bytes, &prefix).expect("should derive account id");

        assert!(account.to_string().starts_with("cosmos"));
    }
}
#[cfg(test)]
mod evm_types {
    use crate::evm::types::{compute_recovery_id_k256, pk_to_address};

    #[test]
    fn pk_to_address_returns_20_byte_address() {
        use k256::ecdsa::SigningKey;

        let sk = SigningKey::random(&mut rand::thread_rng());
        let vk = sk.verifying_key();
        let uncompressed = vk.to_encoded_point(false);

        let addr = pk_to_address(uncompressed.as_bytes()).expect("pk_to_address should work");
        let bytes = addr.as_slice();

        assert_eq!(bytes.len(), 20);
        assert!(bytes.iter().any(|b| *b != 0));
    }

    #[test]
    fn compute_recovery_id_rejects_invalid_pubkey_format() {
        use k256::ecdsa::{signature::Signer, SigningKey};

        // produce a *valid* signature
        let sk = SigningKey::random(&mut rand::thread_rng());
        let hash = [7u8; 32];
        let sig = sk.sign(&hash);

        // invalid pubkey length triggers the branch we want
        let err = compute_recovery_id_k256(hash, &sig, &[1, 2, 3]).unwrap_err();

        let msg = format!("{err}");
        assert!(msg.contains("expected 65-byte") || !msg.is_empty());
    }

    #[test]
    fn compute_recovery_id_finds_matching_one_of_four() {
        use k256::ecdsa::{signature::hazmat::PrehashSigner, SigningKey};

        let sk = SigningKey::random(&mut rand::thread_rng());
        let vk = sk.verifying_key();
        let pub_uncompressed = vk.to_encoded_point(false).as_bytes().to_vec();

        let hash = [9u8; 32];
        let sig = sk.sign_prehash(&hash).expect("sign_prehash");

        let recid = compute_recovery_id_k256(hash, &sig, &pub_uncompressed).expect("should find recid");
        assert!(recid <= 3);
    }
}