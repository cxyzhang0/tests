// This is replaced by src/coverage_runtime_tests.rs.
// Placeholder for future integrations tests if necessary.
/*
use kms_commom::async_signer::AsyncSigner;
use kms_svc_proto::kms_svc_v1::{DescribeRequest, DescribeResponse, GenKeyRequest, GenKeyResponse, ListKeyTypesRequest, ListKeyTypesResponse, ListProvidersRequest, ListProvidersResponse, PingRequest, PingResponse};
use tonic::{Request, Response, Status};
use tonic::transport::Server;

#[derive(Clone)]
struct MockKms {
    sk: k256::ecdsa::SigningKey,
}

#[tonic::async_trait]
impl cb_blkchn_svc::kms_proto::kms_svc_server::KmsSvc for MockKms {
    async fn ping(&self, _request: Request<PingRequest>) -> Result<Response<PingResponse>, Status> {
        todo!()
    }

    async fn describe(&self, _request: Request<DescribeRequest>) -> Result<Response<DescribeResponse>, Status> {
        todo!()
    }

    async fn list_providers(&self, _request: Request<ListProvidersRequest>) -> Result<Response<ListProvidersResponse>, Status> {
        todo!()
    }

    async fn list_provider_key_types(&self, _request: Request<ListKeyTypesRequest>) -> Result<Response<ListKeyTypesResponse>, Status> {
        todo!()
    }

    async fn gen_key(&self, _request: Request<GenKeyRequest>) -> Result<Response<GenKeyResponse>, Status> {
        todo!()
    }

    async fn get_pub_key(
        &self,
        _request: Request<cb_blkchn_svc::kms_proto::GetPubKeyRequest>,
    ) -> Result<Response<cb_blkchn_svc::kms_proto::GetPubKeyResponse>, Status> {

        let vk = self.sk.verifying_key();
        let pub_uncompressed = vk.to_encoded_point(false);

        Ok(Response::new(cb_blkchn_svc::kms_proto::GetPubKeyResponse {
            header: None,
            key_name: "".to_string(),
            attributes: None,
            pub_key: prost::bytes::Bytes::from(pub_uncompressed.as_bytes().to_vec()),
        }))
    }

    async fn sign_msg(
        &self,
        request: Request<cb_blkchn_svc::kms_proto::SignMsgRequest>,
    ) -> Result<Response<cb_blkchn_svc::kms_proto::SignMsgResponse>, Status> {
        use k256::ecdsa::signature::Signer;

        let msg = request.into_inner().msg;
        let sig: k256::ecdsa::Signature = self.sk.sign(msg.as_ref());

        Ok(Response::new(cb_blkchn_svc::kms_proto::SignMsgResponse {
            header: None,
            key_name: "".to_string(),
            attributes: None,
            msg,
            sig: prost::bytes::Bytes::from(sig.to_bytes().to_vec()),
        }))
    }

    async fn sign_prehash(
        &self,
        request: Request<cb_blkchn_svc::kms_proto::SignPrehashRequest>,
    ) -> Result<Response<cb_blkchn_svc::kms_proto::SignPrehashResponse>, Status> {
        use k256::ecdsa::signature::hazmat::PrehashSigner;

        let hash = request.into_inner().hash;
        let hash: [u8; 32] = hash
            .as_ref()
            .try_into()
            .map_err(|_| Status::invalid_argument("hash must be 32 bytes"))?;

        let sig: k256::ecdsa::Signature = self
            .sk
            .sign_prehash(&hash)
            .map_err(|e| Status::internal(e.to_string()))?;

        Ok(Response::new(cb_blkchn_svc::kms_proto::SignPrehashResponse {
            header: None,
            key_name: "".to_string(),
            attributes: None,
            hash: Default::default(),
            sig: prost::bytes::Bytes::from(sig.to_bytes().to_vec()),
        }))
    }
}

use once_cell::sync::OnceCell;

static GLOBAL_KMS_GRPC: OnceCell<String> = OnceCell::new();

fn kms_grpc_global() -> String {
    GLOBAL_KMS_GRPC
        .get_or_init(|| {
            // Bind once (std listener so it can move into a thread easily)
            let std_listener = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
            std_listener.set_nonblocking(true).unwrap();
            let addr = std_listener.local_addr().unwrap();

            // Dedicated thread + its own Tokio runtime => server lives for whole process
            std::thread::spawn(move || {
                let rt = tokio::runtime::Runtime::new().unwrap();
                rt.block_on(async move {
                    let listener = tokio::net::TcpListener::from_std(std_listener).unwrap();
                    let incoming = tokio_stream::wrappers::TcpListenerStream::new(listener);

                    let sk = k256::ecdsa::SigningKey::random(&mut rand::thread_rng());
                    let svc = MockKms { sk };

                    Server::builder()
                        .add_service(cb_blkchn_svc::kms_proto::kms_svc_server::KmsSvcServer::new(svc))
                        .serve_with_incoming(incoming)
                        .await
                        .unwrap();
                });
            });

            format!("127.0.0.1:{}", addr.port())
        })
        .clone()
}
/*
async fn start_mock_kms() -> (String, tokio::task::JoinHandle<()>) {
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let addr = listener.local_addr().unwrap();

    let sk = k256::ecdsa::SigningKey::random(&mut rand::thread_rng());
    let svc = MockKms { sk };

    let handle = tokio::spawn(async move {
        Server::builder()
            .add_service(cb_blkchn_svc::kms_proto::kms_svc_server::KmsSvcServer::new(svc))
            .serve_with_incoming(tokio_stream::wrappers::TcpListenerStream::new(listener))
            .await
            .unwrap();
    });

    (format!("127.0.0.1:{}", addr.port()), handle)
}
*/
#[tokio::test(flavor = "multi_thread")]
async fn kms_mock_executes_paths() {
    // let (kms_grpc, _h) = start_mock_kms().await;
    let kms_grpc = kms_grpc_global();

    // Use the real client from your signer module (this executes signer.rs heavily)
    // NOTE: adjust if your API differs; the goal is to create the signer and call methods.
    let client = cb_blkchn_svc::signer::KmsSigner::new(
        kms_grpc.clone(),
        "test-provider-uuid".to_string(),
        "key".to_string(),
        cb_blkchn_svc::proto::KeyType::Secp256k1,
        None,
    )
        .await
        .expect("connect to mock kms");

    // call get_pubkey path
    let _ = client
        .sign_rehash([0u8; 32])
        .await;

    // call sign_msg path
    let _ = client
        .sign(&[0u8; 32])
        .await;

    let _ = client
        .try_sign_prehash([0u8; 32])
        .await;

    // call sign_msg path
    let _ = client
        .try_sign(&[0u8; 32])
        .await;

}
*/