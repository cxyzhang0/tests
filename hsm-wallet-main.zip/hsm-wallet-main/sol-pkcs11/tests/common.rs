use pkcs11::{Result, /*ErrorWithStacktrace,*/ KeyLabel, SDK, CryptographAlgorithm};
use serial_test::serial;
use solana_client::rpc_client::RpcClient;
use solana_sdk::system_program;
use sol_pkcs11::{build_burn_tx, build_create_associated_token_account_tx, build_mint_to_tx, build_transfer_tx, build_transfer_tx_hsmsigner, build_transfer_tx_hsmsigners, get_balance, get_solana_pubkey, request_air_drop};
use sol_pkcs11::{build_create_account_mint_tx, build_initialize_mint_tx};

// The default module path
pub static MODULE: &str = "/usr/local/lib/softhsm/libsofthsm2.so";
// The default user pin
pub static USER_PIN: &str = "5678";
// The default SO pin
pub static SO_PIN: &str = "1234";
// The default token label
pub static TOKEN_LABEL: &str = "Slot Token 0";
// Solana devnet
pub static RPC_URL: &str = "https://api.devnet.solana.com";


#[test]
#[serial]
fn get_system_program_id() -> Result<()> {
    println!("system program id: {}", system_program::id());
    Ok(())
}

#[test]
#[serial]
fn get_token_program_id() -> Result<()> {
    println!("token program id: {}", spl_token::id());
    Ok(())
}

#[test]
#[serial]
/*
Slot Token 0/spl-token/id-ed25519-hsm-1/
0: GHzRAkNPDDeKLtitegFgRoGrKiUqyZg9Hyo4VFY9397P
1: Dkg9aaukddbuSmsnmUXUQKWsVECnytWWChW1bFafAomk
2: HWRD3mFFTKycocvdHMR5PWjpi9T3zKdod7V2Etnc9E8v

Slot Token 0/WIM-test/id-ed25519-hsm-2/
1: CgX933UxijLwBHKvX1D4xmeCDCuNmfD1qijFDQGQSULb
2: 8UgHH8nybtRh9MrXRze8aZFnqrGEC9r3QT77CP1437J7
3: 61MET326Mhy7YjTeeTsPgksufbeZkMiWfLTcP6mhqDEG
 */
fn it_get_solana_public_key() -> Result<()> {
    // let kls = "Slot Token 0/spl-token/id-ed25519-hsm-1/2";
    let kls = "Slot Token 0/WIM-test/id-ed25519-hsm-2/3";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Ed25519)?;

    let sdk = SDK::new(MODULE, TOKEN_LABEL, USER_PIN)?;

    let pub_key = get_solana_pubkey(&sdk, &key_label)?;


    println!("public key: {}", pub_key.to_string());

    Ok(())
}

#[test]
#[serial]
fn it_request_air_drop() -> Result<()> {
    let kls = "Slot Token 0/WIM-test/id-ed25519-hsm-2/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Ed25519)?;

    let client = RpcClient::new(RPC_URL);
    let sdk = SDK::new(MODULE, TOKEN_LABEL, USER_PIN)?;

    let sig = request_air_drop(&sdk, &client, &key_label, /**/0.0001)?;
    println!("tx sig: {}", sig.to_string());

    Ok(())
}
/**/
#[test]
#[serial]
fn it_get_balance() -> Result<()> {
    let kls = "Slot Token 0/WIM-test/id-ed25519-hsm-2/2";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Ed25519)?;

    let client = RpcClient::new(RPC_URL);
    let sdk = SDK::new(MODULE, TOKEN_LABEL, USER_PIN)?;

    let balance = get_balance(&sdk, &client, &key_label)?;

    println!("balance for {}: {}", kls, balance);

    Ok(())
}

#[test]
#[serial]
fn it_build_transfer_tx_hsmsigner() -> Result<()> {
    let kls_payer = "Slot Token 0/WIM-test/id-ed25519-hsm-2/1";
    let payer = KeyLabel::from_short(kls_payer, CryptographAlgorithm::Ed25519)?;

    let kls_payee = "Slot Token 0/WIM-test/id-ed25519-hsm-2/2";
    let payee = KeyLabel::from_short(kls_payee, CryptographAlgorithm::Ed25519)?;

    let client = RpcClient::new(RPC_URL);
    let sdk = SDK::new(MODULE, TOKEN_LABEL, USER_PIN)?;

    let recent_blockhash = client.get_latest_blockhash()?;
    let tx = build_transfer_tx_hsmsigner(&sdk, recent_blockhash, &payer, &payee, 1000000)?;

    let sig = client.send_transaction(&tx)?;
    // let sig = client.send_and_confirm_transaction(&tx)?;

    println!("tx sig: {}", sig.to_string());
    // loop {
    //     let confirmed = client.confirm_transaction(&sig)?;
    //     if confirmed {
    //         break;
    //     }
    // }

    Ok(())
}

#[test]
#[serial]
fn it_build_transfer_tx_hsmsigners() -> Result<()> {
    let kls_payer = "Slot Token 0/WIM-test/id-ed25519-hsm-2/1";
    let payer = KeyLabel::from_short(kls_payer, CryptographAlgorithm::Ed25519)?;

    let kls_payee = "Slot Token 0/WIM-test/id-ed25519-hsm-2/3";
    let payee = KeyLabel::from_short(kls_payee, CryptographAlgorithm::Ed25519)?;

    let client = RpcClient::new(RPC_URL);
    let sdk = SDK::new(MODULE, TOKEN_LABEL, USER_PIN)?;

    let recent_blockhash = client.get_latest_blockhash()?;
    let tx = build_transfer_tx_hsmsigners(&sdk, recent_blockhash, &payer, &payee, 1000000)?;

    let sig = client.send_transaction(&tx)?;
    // let sig = client.send_and_confirm_transaction(&tx)?;

    println!("tx sig: {}", sig.to_string());
    // loop {
    //     let confirmed = client.confirm_transaction(&sig)?;
    //     if confirmed {
    //         break;
    //     }
    // }

    Ok(())
}

#[test]
#[serial]
fn it_build_create_account_mint_tx() -> Result<()> {
    let kls_payer = "Slot Token 0/WIM-test/id-ed25519-hsm-2/1";
    let payer = KeyLabel::from_short(kls_payer, CryptographAlgorithm::Ed25519)?;

    let kls_pool_mint = "Slot Token 0/spl-token/id-ed25519-hsm-1/0";
    let pool_mint = KeyLabel::from_short(kls_pool_mint, CryptographAlgorithm::Ed25519)?;

    let client = RpcClient::new(RPC_URL);
    let sdk = SDK::new(MODULE, TOKEN_LABEL, USER_PIN)?;

    let recent_blockhash = client.get_latest_blockhash()?;
    let tx = build_create_account_mint_tx(
        &sdk,
        recent_blockhash,
        &payer,
        &pool_mint,
    )?;

    let sig = client.send_transaction(&tx)?;

    println!("tx sig: {}", sig.to_string());

    Ok(())

}

#[test]
#[serial]
fn it_build_initialize_mint_tx() -> Result<()> {
    let kls_payer = "Slot Token 0/WIM-test/id-ed25519-hsm-2/1";
    let payer = KeyLabel::from_short(kls_payer, CryptographAlgorithm::Ed25519)?;

    let kls_mint_authority = "Slot Token 0/WIM-test/id-ed25519-hsm-2/1";
    let mint_authority = KeyLabel::from_short(kls_mint_authority, CryptographAlgorithm::Ed25519)?;

    let kls_freeze_authority = "Slot Token 0/WIM-test/id-ed25519-hsm-2/1";
    let freeze_authority = KeyLabel::from_short(kls_freeze_authority, CryptographAlgorithm::Ed25519)?;

    let kls_pool_mint = "Slot Token 0/spl-token/id-ed25519-hsm-1/0";
    let pool_mint = KeyLabel::from_short(kls_pool_mint, CryptographAlgorithm::Ed25519)?;

    let client = RpcClient::new(RPC_URL);
    let sdk = SDK::new(MODULE, TOKEN_LABEL, USER_PIN)?;

    let recent_blockhash = client.get_latest_blockhash()?;
    let tx = build_initialize_mint_tx(
        &sdk,
        recent_blockhash,
        &payer,
        &pool_mint,
        &mint_authority,
        &freeze_authority,
        6
    )?;

    let sig = client.send_transaction(&tx)?;

    println!("tx sig: {}", sig.to_string());

    Ok(())

}

#[test]
#[serial]
fn it_build_create_associated_token_account_tx() -> Result<()> {
    let kls_payer = "Slot Token 0/WIM-test/id-ed25519-hsm-2/1";
    let payer = KeyLabel::from_short(kls_payer, CryptographAlgorithm::Ed25519)?;

    let kls_pool_mint = "Slot Token 0/spl-token/id-ed25519-hsm-1/0";
    let pool_mint = KeyLabel::from_short(kls_pool_mint, CryptographAlgorithm::Ed25519)?;

    let kls_wallet = "Slot Token 0/WIM-test/id-ed25519-hsm-2/3";
    let wallet = KeyLabel::from_short(kls_wallet, CryptographAlgorithm::Ed25519)?;

    let client = RpcClient::new(RPC_URL);
    let sdk = SDK::new(MODULE, TOKEN_LABEL, USER_PIN)?;

    let recent_blockhash = client.get_latest_blockhash()?;
    let tx = build_create_associated_token_account_tx(
        &sdk,
        recent_blockhash,
        &payer,
        &pool_mint,
        &wallet,
    )?;

    let sig = client.send_transaction(&tx)?;

    println!("tx sig: {}", sig.to_string());

    Ok(())

}

#[test]
#[serial]
fn it_build_mint_to_tx() -> Result<()> {
    let kls_payer = "Slot Token 0/WIM-test/id-ed25519-hsm-2/1";
    let payer = KeyLabel::from_short(kls_payer, CryptographAlgorithm::Ed25519)?;

    let kls_pool_mint = "Slot Token 0/spl-token/id-ed25519-hsm-1/0";
    let pool_mint = KeyLabel::from_short(kls_pool_mint, CryptographAlgorithm::Ed25519)?;

    let kls_wallet = "Slot Token 0/WIM-test/id-ed25519-hsm-2/2";
    let wallet = KeyLabel::from_short(kls_wallet, CryptographAlgorithm::Ed25519)?;

    let kls_mint_authority = "Slot Token 0/WIM-test/id-ed25519-hsm-2/1";
    let mint_authority = KeyLabel::from_short(kls_mint_authority, CryptographAlgorithm::Ed25519)?;

    let client = RpcClient::new(RPC_URL);
    let sdk = SDK::new(MODULE, TOKEN_LABEL, USER_PIN)?;

    let recent_blockhash = client.get_latest_blockhash()?;
    let tx = build_mint_to_tx(
        &sdk,
        recent_blockhash,
        &payer,
        &pool_mint,
        &wallet,
        &mint_authority,
        100_1000_000,
    )?;

    let sig = client.send_transaction(&tx)?;

    println!("tx sig: {}", sig.to_string());

    Ok(())

}

#[test]
#[serial]
fn it_build_transfer_tx() -> Result<()> {
    let kls_payer = "Slot Token 0/WIM-test/id-ed25519-hsm-2/2";
    let payer = KeyLabel::from_short(kls_payer, CryptographAlgorithm::Ed25519)?;

    let kls_pool_mint = "Slot Token 0/spl-token/id-ed25519-hsm-1/0";
    let pool_mint = KeyLabel::from_short(kls_pool_mint, CryptographAlgorithm::Ed25519)?;

    let kls_from = "Slot Token 0/WIM-test/id-ed25519-hsm-2/2";
    let from = KeyLabel::from_short(kls_from, CryptographAlgorithm::Ed25519)?;

    let kls_to = "Slot Token 0/WIM-test/id-ed25519-hsm-2/3";
    let to = KeyLabel::from_short(kls_to, CryptographAlgorithm::Ed25519)?;

    let client = RpcClient::new(RPC_URL);
    let sdk = SDK::new(MODULE, TOKEN_LABEL, USER_PIN)?;

    let recent_blockhash = client.get_latest_blockhash()?;
    let tx = build_transfer_tx(
        &sdk,
        recent_blockhash,
        &payer,
        &pool_mint,
        &from,
        &to,
        1_000_000,
    )?;

    let sig = client.send_transaction(&tx)?;

    println!("tx sig: {}", sig.to_string());

    Ok(())

}

#[test]
#[serial]
fn it_build_burn_tx() -> Result<()> {
    let kls_payer = "Slot Token 0/WIM-test/id-ed25519-hsm-2/2";
    let payer = KeyLabel::from_short(kls_payer, CryptographAlgorithm::Ed25519)?;

    let kls_pool_mint = "Slot Token 0/spl-token/id-ed25519-hsm-1/0";
    let pool_mint = KeyLabel::from_short(kls_pool_mint, CryptographAlgorithm::Ed25519)?;

    let kls_wallet = "Slot Token 0/WIM-test/id-ed25519-hsm-2/2";
    let wallet = KeyLabel::from_short(kls_wallet, CryptographAlgorithm::Ed25519)?;

    let client = RpcClient::new(RPC_URL);
    let sdk = SDK::new(MODULE, TOKEN_LABEL, USER_PIN)?;

    let recent_blockhash = client.get_latest_blockhash()?;
    let tx = build_burn_tx(
        &sdk,
        recent_blockhash,
        &payer,
        &pool_mint,
        &wallet,
        500_000_000,
    )?;

    let sig = client.send_transaction(&tx)?;

    println!("tx sig: {}", sig.to_string());

    Ok(())

}
