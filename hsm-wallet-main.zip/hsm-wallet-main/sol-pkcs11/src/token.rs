use pkcs11::{Result, ErrorWithStacktrace, KeyLabel, SDK, /*CryptographAlgorithm*/};
use solana_sdk::{
    transaction::Transaction,
    hash:: Hash,
    message::Message,
    rent::Rent,
    system_instruction,
};
use solana_sdk::pubkey::Pubkey;
use spl_token::solana_program::program_pack::Pack;
use spl_token::state::Mint;
use spl_associated_token_account::{
    instruction::{create_associated_token_account, create_associated_token_account_idempotent},
    get_associated_token_address,
};
use crate::{get_solana_pubkey, HSMSigners};
// use spl_token::*;

pub fn build_create_account_mint_tx(
    sdk: &SDK,
    recent_blockhash: Hash,
    payer: &KeyLabel,
    pool_mint: &KeyLabel,
) -> Result<Transaction> {
    if let Ok(payer_pubkey) = get_solana_pubkey(sdk, payer) {
        if let Ok(mint_pubkey) = get_solana_pubkey(sdk, pool_mint) {
            let rent = Rent::default();
            let mint_rent = rent.minimum_balance(Mint::LEN);
            let inst = system_instruction::create_account(
                &payer_pubkey,
                &mint_pubkey,
                mint_rent,
                Mint::LEN as u64,
                &spl_token::id(),
            );
            let msg = Message::new(
                &[inst],
                Some(&payer_pubkey),
            );
            let mut tx = Transaction::new_unsigned(msg);
            let hsm_signers = HSMSigners::new(
                sdk,
                vec![payer, pool_mint],
            );
            tx.sign(&hsm_signers, recent_blockhash);
            return Ok(tx)
        }
    }

    Err(ErrorWithStacktrace)
}

pub fn build_initialize_mint_tx(
    sdk: &SDK,
    recent_blockhash: Hash,
    payer: &KeyLabel,
    pool_mint: &KeyLabel,
    mint_authority: &KeyLabel,
    freeze_authority: &KeyLabel,
    decimals: u8,
) -> Result<Transaction> {
    let mint = get_solana_pubkey(sdk, pool_mint).unwrap();
    if let Ok(payer_pubkey) = get_solana_pubkey(sdk, payer) {
        if let Ok(mint_authority_pubkey) = get_solana_pubkey(sdk, mint_authority) {
            if let Ok(_freeze_authority_pubkey) = get_solana_pubkey(sdk, freeze_authority) {
                if let Ok(inst) = spl_token::instruction::initialize_mint(
                    &spl_token::id(),
                    &mint,
                    &mint_authority_pubkey,
                    Some(&_freeze_authority_pubkey),
                    decimals,
                ) {
                    let msg = Message::new(
                        &[inst],
                        Some(&payer_pubkey),
                    );
                    let mut tx = Transaction::new_unsigned(msg);
                    let hsm_signers = HSMSigners::new(sdk, vec![payer]);
                    tx.sign(&hsm_signers, recent_blockhash);
                    return Ok(tx)                }
            }
        }
    }

    Err(ErrorWithStacktrace)
}

pub fn build_create_associated_token_account_tx(
    sdk: &SDK,
    recent_blockhash: Hash,
    payer: &KeyLabel,
    pool_mint: &KeyLabel,
    wallet: &KeyLabel
) -> Result<Transaction> {
    let payer_pubkey = get_solana_pubkey(sdk, payer).unwrap();
    let mint_pubkey = get_solana_pubkey(sdk, pool_mint).unwrap();
    let wallet_pubkey = get_solana_pubkey(sdk, wallet).unwrap();
    let inst = create_associated_token_account(
        &payer_pubkey,
        &wallet_pubkey,
        &mint_pubkey,
        &spl_token::id(),
    );
    let msg = Message::new(
        &[inst],
        Some(&payer_pubkey),
    );
    let mut tx = Transaction::new_unsigned(msg);
    let hsm_signers = HSMSigners::new(sdk, vec![payer]);
    tx.sign(&hsm_signers, recent_blockhash);
    Ok(tx)
}

pub fn build_mint_to_tx(
    sdk: &SDK,
    recent_blockhash: Hash,
    payer: &KeyLabel,
    pool_mint: &KeyLabel,
    wallet: &KeyLabel,
    mint_authority: &KeyLabel,
    amount: u64,
) -> Result<Transaction> {
    let payer_pubkey = get_solana_pubkey(sdk, payer).unwrap();
    let mint = get_solana_pubkey(sdk, pool_mint).unwrap();
    let wallet_address = get_solana_pubkey(sdk, wallet).unwrap();
    let mint_authority_pubkey = get_solana_pubkey(sdk, mint_authority).unwrap();
    let associated_token_account = get_associated_token_address(&wallet_address, &mint);
    let inst = spl_token::instruction::mint_to(
        &spl_token::id(),
        &mint,
        &associated_token_account,
        &mint_authority_pubkey,
        &[],
        amount,
    ).unwrap();
    let msg = Message::new(
        &[inst],
        Some(&payer_pubkey),
    );
    let mut tx = Transaction::new_unsigned(msg);
    let hsm_signers = HSMSigners::new(sdk, vec![payer, mint_authority]);
    tx.sign(&hsm_signers, recent_blockhash);

    Ok(tx)
}

pub fn build_transfer_tx(
    sdk: &SDK,
    recent_blockhash: Hash,
    payer: &KeyLabel,
    pool_mint: &KeyLabel,
    from: &KeyLabel,
    to: &KeyLabel,
    amount: u64,
) -> Result<Transaction> {
    let payer_pubkey = get_solana_pubkey(sdk, payer).unwrap();
    let mint = get_solana_pubkey(sdk, pool_mint).unwrap();
    let from_pubkey = get_solana_pubkey(sdk, from).unwrap();
    let to_pubkey = get_solana_pubkey(sdk, to).unwrap();
    let from_associated_token_account = get_associated_token_address(&from_pubkey, &mint);
    let to_associated_token_account = get_associated_token_address(&to_pubkey, &mint);
    let inst = spl_token::instruction::transfer(
        &spl_token::id(),
        &from_associated_token_account,
        &to_associated_token_account,
        &from_pubkey,
        &[],
        amount,
    ).unwrap();
    let msg = Message::new(
        &[inst],
        Some(&payer_pubkey),
    );
    let mut tx = Transaction::new_unsigned(msg);
    let hsm_signers = HSMSigners::new(sdk, vec![payer, from]);
    tx.sign(&hsm_signers, recent_blockhash);

    Ok(tx)
}

pub fn build_burn_tx(
    sdk: &SDK,
    recent_blockhash: Hash,
    payer: &KeyLabel,
    pool_mint: &KeyLabel,
    wallet: &KeyLabel,
    amount: u64,
) -> Result<Transaction> {
    let payer_pubkey = get_solana_pubkey(sdk, payer).unwrap();
    let mint = get_solana_pubkey(sdk, pool_mint).unwrap();
    let wallet_address = get_solana_pubkey(sdk, wallet).unwrap();
    let associated_token_account = get_associated_token_address(&wallet_address, &mint);
    let inst = spl_token::instruction::burn(
        &spl_token::id(),
        &associated_token_account,
        &mint,
        &wallet_address,
        &[],
        amount,
    ).unwrap();
    let msg = Message::new(
        &[inst],
        Some(&payer_pubkey),
    );
    let mut tx = Transaction::new_unsigned(msg);
    let hsm_signers = HSMSigners::new(sdk, vec![payer, wallet]);
    tx.sign(&hsm_signers, recent_blockhash);

    Ok(tx)
}