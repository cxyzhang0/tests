use std::str::FromStr;
use solana_sdk::pubkey::Pubkey;

pub const TOKEN_2022: &str = "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb";

pub fn token2022_id() -> Pubkey {
    Pubkey::from_str(TOKEN_2022).unwrap()
}



#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn it_token2022_id() {
        assert_eq!(token2022_id().to_string(), String::from(TOKEN_2022))
    }

}