use pkcs11::{Result, ErrorWithStacktrace, KeyLabel, SDK, /*CryptographAlgorithm*/};
use solana_sdk::{pubkey::Pubkey, signer::{/*Signer,*/ SignerError}};
use core::result::Result as CoreResult;
use solana_sdk::signature::Signature;
use solana_sdk::signers::Signers;

pub fn get_solana_pubkey(sdk: &SDK, key_label: &KeyLabel) -> Result<Pubkey> {
    if let Ok(pub_key) = sdk.get_public_key(key_label) {
        return Ok(Pubkey::from(pub_key.to_bytes()))
    }

    Err(ErrorWithStacktrace)
}

#[derive(Debug)]
pub struct HSMSigners <'a>{
    pub sdk: &'a SDK,
    pub key_labels: Vec<&'a KeyLabel <'a>>,
}

impl <'a> HSMSigners <'a> {
    pub fn new(sdk: &'a SDK, key_labels: Vec<&'a KeyLabel<'a>> ) -> Self {
        Self {
            sdk,
            key_labels
        }
    }
}
impl <'a> Signers for HSMSigners <'a>{
    fn pubkeys(&self) -> Vec<Pubkey> {
        if let Ok(pubkeys) = self.try_pubkeys() {
            return pubkeys
        }
        panic!("failed to get pubkey")
    }

    fn try_pubkeys(&self) -> CoreResult<Vec<Pubkey>, SignerError> {
        let mut pubkeys: Vec<Pubkey> = vec![];
        for key_label in &self.key_labels {
            if let Ok(pubkey) = get_solana_pubkey(self.sdk, key_label) {
                pubkeys.push(pubkey);
            } else {
                return Err(SignerError::Custom(String::from("failed to get solana key")))
            }
        }
        Ok(pubkeys)
    }

    fn sign_message(&self, message: &[u8]) -> Vec<Signature> {
        if let Ok(sigs) = self.try_sign_message(message) {
            return sigs
        }
        panic!("failed to sign")
    }

    fn try_sign_message(&self, message: &[u8]) -> CoreResult<Vec<Signature>, SignerError> {
        let mut sigs: Vec<Signature> = vec![];
        for key_label in &self.key_labels {
            if let Ok(sig) = self.sdk.sign(key_label, message) {
                sigs.push(Signature::new(&sig[..]));
            }
            else {
                return Err(SignerError::Custom(String::from("failed to sign")))
            }
        }
        Ok(sigs)
    }

    fn is_interactive(&self) -> bool {
        false
    }
}

#[derive(Debug)]
pub struct HSMSigner <'a>{
    pub sdk: &'a SDK,
    pub key_label: &'a KeyLabel <'a>,
}

impl <'a> HSMSigner <'a> {
    pub fn new(sdk: &'a SDK, key_label: &'a KeyLabel<'a> ) -> Self {
        Self {
            sdk,
            key_label
        }
    }
}
impl <'a> Signers for HSMSigner <'a>{
    fn pubkeys(&self) -> Vec<Pubkey> {
        if let Ok(pubkeys) = self.try_pubkeys() {
            return pubkeys
        }
        panic!("failed to get pubkey")
    }

    fn try_pubkeys(&self) -> CoreResult<Vec<Pubkey>, SignerError> {
        if let Ok(pubkey) = get_solana_pubkey(self.sdk, self.key_label) {
            Ok(vec![pubkey])
        } else {
            Err(SignerError::Custom(String::from("failed to get solana key")))
        }
    }

    fn sign_message(&self, message: &[u8]) -> Vec<Signature> {
        if let Ok(sigs) = self.try_sign_message(message) {
            return sigs
        }
        panic!("failed to sign")
    }

    fn try_sign_message(&self, message: &[u8]) -> CoreResult<Vec<Signature>, SignerError> {
        if let Ok(sig) = self.sdk.sign(self.key_label, message) {
            Ok(vec![Signature::new(&sig[..])])
        } else {
            Err(SignerError::Custom(String::from("failed to sign")))
        }
    }

    fn is_interactive(&self) -> bool {
        false
    }
}
