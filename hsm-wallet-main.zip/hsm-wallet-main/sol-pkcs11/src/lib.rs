pub mod helper;
pub mod token;
pub mod token2022;
pub use helper::*;
pub use token::*;
pub use token2022::*;

use pkcs11::{Result, ErrorWithStacktrace, KeyLabel, SDK, /*CryptographAlgorithm*/};
// use borsh::{BorshSerialize, BorshDeserialize};
use solana_client::rpc_client::RpcClient;
use solana_sdk::{
    hash::Hash,
    //instruction::Instruction,
    message::Message,
    // pubkey::Pubkey,
    signature::{/*Keypair, Signer,*/ Signature},
    system_instruction,
    // system_program,
    // system_transaction,
    transaction::Transaction,
};
// use solana_sdk::signers::Signers;

const LAMPORTS_PER_SOL: f64 = 1_000_000_000.0;

pub fn request_air_drop(
    sdk: &SDK,
    client: &RpcClient,
    key_label: &KeyLabel,
    // pub_key: &Pubkey,
    amount_sol: f64
) -> Result<Signature> {
    let pub_key = get_solana_pubkey(sdk, key_label)?;
    let sig: Signature = client.request_airdrop(&pub_key, (amount_sol * LAMPORTS_PER_SOL) as u64)?;
    // loop {
    //     let confirmed = client.confirm_transaction(&sig)?;
    //     if confirmed {
    //         break;
    //     }
    // }
    Ok(sig)
}

pub fn get_balance(
    sdk: &SDK,
    client: &RpcClient,
    key_label: &KeyLabel,
) -> Result<f64> {
    if let Ok(pub_key) = get_solana_pubkey(sdk, key_label) {
        if let Ok(balance) = client.get_balance(&pub_key) {
            return Ok((balance as f64) /LAMPORTS_PER_SOL)
        }
    }

    Err(ErrorWithStacktrace)
}

pub fn build_transfer_tx_hsmsigner(
    sdk: &SDK,
    recent_blockhash: Hash,
    // client: &RpcClient,
    payer: &KeyLabel,
    payee: &KeyLabel,
    amount: u64, // lamports
) -> Result<Transaction> {
    if let Ok(from_pubkey) = get_solana_pubkey(sdk, payer) {
        if let Ok(to_pubkey) = get_solana_pubkey(sdk, payee) {
            // let id = system_program::id();
            let inst = system_instruction::transfer(
                &from_pubkey, &to_pubkey, amount);
            let msg = Message::new(
                &[inst],
                Some(&from_pubkey),
            );
            // let recent_blockhash = client.get_latest_blockhash()?;
            let mut tx = Transaction::new_unsigned(msg);
            let hsm_signer = HSMSigner::new(sdk, payer);
            tx.sign(&hsm_signer, recent_blockhash);
            return Ok(tx)
        }
    }

    Err(ErrorWithStacktrace)
}

pub fn build_transfer_tx_hsmsigners(
    sdk: &SDK,
    recent_blockhash: Hash,
    // client: &RpcClient,
    payer: &KeyLabel,
    payee: &KeyLabel,
    amount: u64, // lamports
) -> Result<Transaction> {
    if let Ok(from_pubkey) = get_solana_pubkey(sdk, payer) {
        if let Ok(to_pubkey) = get_solana_pubkey(sdk, payee) {
            // let id = system_program::id();
            let inst = system_instruction::transfer(&from_pubkey, &to_pubkey, amount);
            let msg = Message::new(
                &[inst],
                Some(&from_pubkey),
            );
            // let recent_blockhash = client.get_latest_blockhash()?;
            let mut tx = Transaction::new_unsigned(msg);
            let hsm_signers = HSMSigners::new(sdk, vec![payer]);
            tx.sign(&hsm_signers, recent_blockhash);
            return Ok(tx)
        }
    }

    Err(ErrorWithStacktrace)
}

