## sol-pkcs11
* Solana transaction building  
> Solana and most of the 3-rd generation blockchains (Algorand, Cardano) use ed25519.
> ed25519 is not supported by any one of the cloud vendors.
> Only on-prem HSM is an option. We use SOFTHSM for testing the codes.

* Tests to showcase the functionality
