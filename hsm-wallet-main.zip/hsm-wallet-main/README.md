# hsm-wallet (formerly wallet-rust)
This workspace contains the following crates:
## pkcs11
SDK to interface with HSM for key management
> Supported algorithms
> * ed25519 (Cosmos (validators), Solana, Algorand, Cardano)
> * secp256k1 (Cosmos, Bitcoin, Ethereum)
> * secp256r1 (Corda)
> * rsa2048

> Tested with the following HSMs
> * SoftHSM
> * FutureX
## cosmos-pkcs11
HSM-enabled wallet in Rust
> * P11Signer to showcase pkcs11 SDK
> * P11Signer wallet for Cosmos transaction

> Tested with the following HSMs
> * SoftHSM
> * FutureX
## sol-pkcs11
HSM-enabled wallet in Rust
> * Solana transaction building to showcase ed25519 
> * Solana and most of the 3-rd generation blockchains (Algorand, Cardano) use ed25519.
> * ed25519 is not supported by any one of the cloud vendors.
> * Only on-prem HSM is an option. We use SOFTHSM for testing the codes.

> Tested with the following HSMs
> * SoftHSM
## hashicorp
* SDK to interface with Hashicorp Vault for key management
> Supported algorithms
> * secp256k1
> * secp256r1
> * ed25519
* Integration tests to demonstrate the use of the k256 SDK to create wallets and build and sign transactions on Cosmos chains.


**TODO:** Due to dependency conflicts between sol-pkcs11 and hashicorp, currently only pkcs11, cosmos-pkcs11 and hashicorp are enabled by inclusion in the workspace members until it is resolved.
