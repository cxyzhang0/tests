use std::sync::{Arc, Mutex};
use async_trait::async_trait;
use k256::ecdsa::{Error as EcdsaError, Signature, VerifyingKey};
use k256::ecdsa::signature::{Keypair, Signer};
use k256::Secp256k1;
use pkcs11::{KeyLabel, SDK};

#[derive(Debug)]
pub struct P11Signer {
    sdk: Arc<Mutex<SDK>>,
    key_label: KeyLabel,
}

impl P11Signer {
    pub fn new(sdk: Arc<Mutex<SDK>>, key_label: KeyLabel) -> Self {
        Self { sdk, key_label }
    }

    pub fn from_vars(env_module: Option<&str>, module: Option<&str>, token_label: &str, pin: &str, key_label: KeyLabel) -> Self {
        let sdk = SDK::new(env_module, module, token_label, pin).unwrap();

        Self::new(Arc::new(Mutex::new(sdk)), key_label)
    }

}

impl Signer<Signature> for P11Signer {
    fn sign(&self, msg: &[u8]) -> Signature {
        self.try_sign(msg).unwrap()
    }

    fn try_sign(&self, msg: &[u8]) -> anyhow::Result<Signature, EcdsaError> {
        self.sdk.lock().unwrap().sign_ecdsa::<Secp256k1>(&self.key_label, msg).map_err(|_|
            EcdsaError::new())
    }
}

#[async_trait]
impl mpc_wallet::traits::AsyncSigner<Signature> for P11Signer {
    async fn try_sign(&mut self, msg: &[u8]) -> anyhow::Result<Signature> {
        self.sdk.lock().unwrap().sign_ecdsa::<Secp256k1>(&self.key_label, msg)
            .map_err(|e| anyhow::Error::msg(format!("sign_ecdsa error: {}", e)))
    }
}

impl Keypair for P11Signer {
    type VerifyingKey = VerifyingKey;

    fn verifying_key(&self) -> Self::VerifyingKey {
        self.sdk.lock().unwrap().get_ec_public_key::<Secp256k1>(&self.key_label).unwrap()
    }
}

unsafe impl Send for P11Signer {}

unsafe impl Sync for P11Signer {}
