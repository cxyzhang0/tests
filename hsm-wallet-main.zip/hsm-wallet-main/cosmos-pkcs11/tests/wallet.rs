// path does not work because it has imports which cannot be resolved
// #[path = "../../pkcs11/tests/common.rs"] mod common;
// use common::{ENV_FXPKCS11_CFG, ENV_MODULE, ENV_SOFTHSM2_CONF, FXPKCS11_CFG, init, MODULE, SOFTHSM2_CONF, TOKEN_LABEL, USER_PIN, _SO_PIN};

mod common;

use std::str::FromStr;
use cosmos_grpc_client::{BroadcastMode, CoinType, Decimal, GrpcClient, Wallet};
use cosmos_sdk_proto::cosmos::{bank::v1beta1::MsgSend, base::v1beta1::Coin as ProtoCoin};
use cosmos_sdk_proto::cosmwasm::wasm::v1::{MsgExecuteContract, QuerySmartContractStateRequest};
use cosmos_sdk_proto::traits::MessageExt;
use cosmrs::crypto::secp256k1::SigningKey;
use difi_core_2::msg::{CoinBalancesResponse, ExecuteMsg, QueryMsg};
use mpc_wallet::test_util::{CHAIN_GRPC, CHAIN_PREFIX, DENOM, STAKE_DENOM};
use mpc_wallet::utils::pk_to_account;
use cosmos_pkcs11::signer::P11Signer;
use pkcs11::{CryptographAlgorithm, KeyLabel};
use crate::common::{ENV_MODULE, init, MODULE, TOKEN_LABEL, USER_PIN};

// FutureX "Slot Token 0/WIM-test/secp256k1-hsm-1/1"
const FX_PK1: &str = "02473288f8a7cb855379f62eda13259422a5d00409dc8207536c5ca8940d9ad063";
const FX_ACCT1: &str = "wf1y5xncqtnlkc7fgclald3kkerq63c287w8mqsvr";
// FutureX "Slot Token 0/WIM-test/secp256k1-hsm-1/2"
const FX_PK2: &str = "02bc0263578faf4bea34c566b4faad3f11a69e8e3aae429b5cce145bb57b302db7";
const FX_ACCT2: &str = "wf17czrm0706zkkxw9q0ytqkug4w9ppjzaus2aefc";
const CONTRACT_ADDRESS: &str = "wf14hj2tavq8fpesdwxxcu44rty3hh90vhujrvcmstl4zr3txmfvw9s2s4a5q";
#[test]
fn it_pk_to_account() {
    let account = pk_to_account(FX_PK1, CHAIN_PREFIX);
    assert_eq!(account, FX_ACCT1);
    let account = pk_to_account(FX_PK2, CHAIN_PREFIX);
    assert_eq!(account, FX_ACCT2);
    // println!("{}", pk_to_account(FX_PK1, "cosmwasm"));
    // println!("{}", pk_to_account("020b7371aa2361bbb5d216b8bb24f9728adbebe8bb93c0e37a9f12c42b99226ea0", "wf"));
}

#[tokio::test]
async fn it_wallet_sign_tx_signer() {
    init();
    let mut gcp_client = GrpcClient::new(CHAIN_GRPC).await.unwrap();

    let kls = "Slot Token 0/WIM-test/secp256k1-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Secp256k1).unwrap();

    let signer = P11Signer::from_vars(Some(ENV_MODULE), Some(MODULE), TOKEN_LABEL, USER_PIN, key_label);
    let signing_key = SigningKey::new(Box::new(signer));

    let mut wallet = Wallet::from_signer(
        &mut gcp_client,
        signing_key,
        CHAIN_PREFIX,
        CoinType::Cosmos,
        Decimal::from_str("0.120").unwrap(), // Gas_price
        Decimal::from_str("2.0").unwrap(),   // Gas adjustment
        STAKE_DENOM,                         // Gas denom
    ).await.unwrap();

    let msg = MsgSend {
        from_address: wallet.account_address(),
        to_address: FX_ACCT2.to_string(),
        amount: vec![ProtoCoin {
            denom: DENOM.to_string(),
            amount: "100".to_string(),
        }],
    }
        .to_any()
        .unwrap();

    let response = wallet
        .broadcast_tx(
            &mut gcp_client,
            vec![msg],           // Vec<Any>: list of msgs to broadcast
            None,                // memo: Option<String>
            None, // fee: Option<Fee>, if not provided the tx is simulated to calculate the fee
            BroadcastMode::Sync, // Broadcast mode; Block/Sync/Async
        )
        .await
        .unwrap();

    println!("response: {response:#?}")
}

#[tokio::test]
async fn it_wallet_sign_execute_contract_tx_signer() {
    init();
    let mut gcp_client = GrpcClient::new(CHAIN_GRPC).await.unwrap();

    let kls = "Slot Token 0/WIM-test/secp256k1-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Secp256k1).unwrap();

    let signer = P11Signer::from_vars(Some(ENV_MODULE), Some(MODULE), TOKEN_LABEL, USER_PIN, key_label);
    let signing_key = SigningKey::new(Box::new(signer));

    let mut wallet = Wallet::from_signer(
        &mut gcp_client,
        signing_key,
        CHAIN_PREFIX,
        CoinType::Cosmos,
        Decimal::from_str("0.120").unwrap(), // Gas_price
        Decimal::from_str("2.0").unwrap(),   // Gas adjustment
        STAKE_DENOM,                         // Gas denom
    ).await.unwrap();

    let execute_msg = ExecuteMsg::SendCoin {
        recipient: FX_ACCT2.to_string(),
    };

    let execute_msg = serde_json::to_vec(&execute_msg).unwrap();

    let msg = MsgExecuteContract {
        sender: wallet.account_address(),
        contract: CONTRACT_ADDRESS.to_string(),
        msg: execute_msg,
        funds: vec![ProtoCoin {
            denom: DENOM.to_string(),
            amount: "100".to_string(),
        }],
    }
        .to_any()
        .unwrap();

    let response = wallet
        .broadcast_tx(
            &mut gcp_client,
            vec![msg],           // Vec<Any>: list of msgs to broadcast
            None,                // memo: Option<String>
            None, // fee: Option<Fee>, if not provided the tx is simulated to calculate the fee
            BroadcastMode::Sync, // Broadcast mode; Block/Sync/Async
        )
        .await
        .unwrap();

    println!("response: {response:#?}")
}

#[tokio::test]
async fn it_wallet_query_contract_state() {
    init();
    let mut gcp_client = GrpcClient::new(CHAIN_GRPC).await.unwrap();

    let query_msg = QueryMsg::CoinBalances {
        address: FX_ACCT2.to_string(),
    };

    let resp = gcp_client.wasm_query_contract::<QueryMsg, CoinBalancesResponse>(CONTRACT_ADDRESS, query_msg).await.unwrap();

    println!("response: {resp:#?}")
}
