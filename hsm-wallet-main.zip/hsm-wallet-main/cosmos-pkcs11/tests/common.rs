// This file is a subset of pkcs11/tests/common.rs

use std::env;
use std::sync::Once;

// Turn on either SOFTHSM2 or FutureX by commenting out the other below.
// SOFTHSM2
/*
// The env for module if any
pub static ENV_MODULE: &str = "PKCS11_SOFTHSM2_MODULE";
// The default module path
pub static MODULE: &str = "/usr/local/lib/softhsm/libsofthsm2.so";
// The default user pin
pub static USER_PIN: &str = "5678";
// The default SO pin
pub static _SO_PIN: &str = "1234";
// The default token label
pub static TOKEN_LABEL: &str = "Slot Token 0";
*/

// FutureX

pub static ENV_MODULE: &str = "FXPKCS11_MODULE";
// The default module path
pub static MODULE: &str = "/Users/johnz/futurex/fxpkcs11-mac-arm-4.58-422d/libfxpkcs11.dylib";
// The default user pin
pub static USER_PIN: &str = "safest";
// The default SO pin
pub static _SO_PIN: &str = "1234";
// The default token label
pub static TOKEN_LABEL: &str = "Slot Token 0";
// pub static TOKEN_LABEL: &str = "us01crypto01test.virtucrypt.com:";


// config
pub const ENV_SOFTHSM2_CONF: &str = "SOFTHSM2_CONF";
pub const SOFTHSM2_CONF: &str = "/etc/softhsm2.conf";

pub const ENV_FXPKCS11_CFG: &str = "FXPKCS11_CFG";
pub const FXPKCS11_CFG: &str = "/Users/johnz/futurex/fxpkcs11-mac-arm-4.58-422d/fxpkcs11.cfg";

static INIT: Once = Once::new();

pub fn init() {
    INIT.call_once(|| {
        env::set_var(ENV_SOFTHSM2_CONF, SOFTHSM2_CONF);
        env::set_var(ENV_FXPKCS11_CFG, FXPKCS11_CFG);
    });
}