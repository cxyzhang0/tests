use std::time::Instant;
use serial_test::serial;
use crate::common::get_sdk;
use pkcs11::{CryptographAlgorithm, KeyLabel, Result};

mod common;
#[ignore]
#[test]
#[serial]
fn it_aes_keygen() -> Result<()> {
    let start  = Instant::now();
    let sdk = get_sdk()?;
    println!("Time elapsed after get_sdk(): {:?}", start.elapsed());

    // let kls = "slot-0/tsstrio-0/aes/1";
    let kls = "slot-0/tsstrio-1/aes/1";
    let mut key_label = KeyLabel::from_short(kls, CryptographAlgorithm::AES)?;
    let persistent = false;
    
    let created = sdk.aes_keygen(&mut key_label, persistent)?;
    println!("Time elapsed after aes_keygen(): {:?}", start.elapsed());
    
    let got_handle = sdk.get_aes_key_handle(&key_label)?;
    println!("Time elapsed after get_aes_key_handle(): {:?}", start.elapsed());

    assert_eq!(created.0, got_handle);
    println!("created handle: {}; got handle:{}; key label: {}", created.0, got_handle, created.1.short_label());
    
    Ok(())

}

#[ignore]
#[test]
#[serial]
fn it_test_encrypt_decrypt() -> Result<()> {
    let start = Instant::now();
    let sdk = get_sdk()?;
    println!("Time elapsed after get_sdk(): {:?}", start.elapsed());

    let kls = "slot-0/tsstrio-0/aes/1";
    // let kls = "slot-0/tsstrio-1/aes/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::AES)?;
    
    let data = b"encrypt me";
    
    let aad = b"additional data";
    
    let encrypted = sdk.encrypt(&key_label, data, aad)?;
    println!("Time elapsed after encrypt(): {:?}", start.elapsed());
    
    let decrypted = sdk.decrypt(&key_label, &encrypted, aad)?;
    println!("Time elapsed after decrypt(): {:?}", start.elapsed());
    
    assert_eq!(decrypted, data);

    let data = b"encrypt me not";
    assert_ne!(decrypted, data);

    Ok(())
}