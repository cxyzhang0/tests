use std::time::Instant;
use cryptoki::context::{CInitializeArgs, Function, Pkcs11};
use cryptoki::mechanism::MechanismType;
use ecdsa::Signature as EcSignature;
use ecdsa::signature::Verifier;
use k256::ecdsa::signature::hazmat::PrehashVerifier;
use k256::Secp256k1;
use p256::NistP256;
use serial_test::serial;
use sha2::{Digest, Sha256, Sha512};
use cryptoki::error::Error as P11HsmError;
use pkcs11::Error;

use pkcs11::{Result, CryptographAlgorithm, KeyLabel, SDK, secure_hash, SDKContext};

use crate::common::{ENV_MODULE, init, MODULE, TOKEN_LABEL, TOKEN_LABEL_1, USER_PIN, get_sdk, get_sdk_new};

mod common;

fn get_test_pkcs11() -> Result<Pkcs11> {
    init();

    let p11 = SDKContext::create_pkcs11(Some(ENV_MODULE), Some(MODULE))?;
    
    Ok(p11)
}
fn get_test_sdk_context() -> Result<SDKContext> {
    let p11 = get_test_pkcs11()?;

    let ctx = SDKContext::new(p11);

    Ok(ctx)
}

// same module cannot be initialized more than once.
// this test is also covered in it_initialize_two_modules.
#[ignore]
#[test]
#[serial]
fn it_cannot_initialize_same_module_twice() -> Result<()> {
    let p11 = get_test_pkcs11()?;

    assert!(p11.is_initialized(), "pkcs11 is not initialized");

    let p11_2 = get_test_pkcs11();

    // println!("p11_2: {:?}", p11_2);

    match p11_2 {
        // todo: how to catch CryptokiAlreadyInitialized - Err(Error::P11(P11HsmError::AlreadyInitialized)) => Ok(()),
        Err(e) => {
            println!("expected: {:?}", e);
            Ok(())
        },
        Ok(_) => Err(Error::P11(P11HsmError::NotSupported)) //panic!("initializing twice should not have been allowed"),
    }
}

// two modules with different file path and names will pass even they are the same file
// two modules with the same file path and names will fail
#[ignore]
#[test]
#[serial]
fn it_initialize_two_modules() -> Result<()> {
    let start = Instant::now();
    init();

    let module1 = "/Users/johnz/futurex/fxpkcs11-mac-arm-5.5-5d0b/libfxpkcs11.dylib";

    // this together with module1 will fail AlreadyInitialized
    // two dlls have the same file path and name
    // let module2 = "/Users/johnz/futurex/fxpkcs11-mac-arm-5.5-5d0b/libfxpkcs11.dylib";

    // this together with module1 will succeed even if the two copies are identical
    let module2 = "/Users/johnz/futurex/fxpkcs11-mac-arm-5.5-5d0b/libfxpkcs11-copy.dylib";
    
    // this together with module1 will succeed because .dylib is different
    // let module2 = "/Users/johnz/futurex/fxpkcs11-mac-arm-4.59-8551/libfxpkcs11.dylib";

    // this together with module1 will succeed because .dylib is different
    // let module2 = "/usr/local/lib/softhsm/libsofthsm2.so";

    let p11_1 =  Pkcs11::new(module1)?;
    // let p11_1 =  SDKContext::create_pkcs11(None, Some(fxmodule))?;
    println!("time elapsed after new p11_1: {}ms", start.elapsed().as_millis());

    let p11_2 =  Pkcs11::new(module2)?;
    // let p11_2 =  SDKContext::create_pkcs11(None, Some(shmodule))?;
    println!("time elapsed after new p11_2: {}ms", start.elapsed().as_millis());
    
    p11_1.initialize(CInitializeArgs::OsThreads)?;
    println!("time elapsed after initializing p11_1: {}ms", start.elapsed().as_millis());

    p11_2.initialize(CInitializeArgs::OsThreads)?;
    println!("time elapsed after initializing p11_2: {}ms", start.elapsed().as_millis());

    assert!(p11_1.is_initialized(), "fx pkcs11 is not initialized");

    assert!(p11_2.is_initialized(), "softhsm pkcs11 is not initialized");

    Ok(())
}

#[ignore]
#[test]
#[serial]
fn it_is_initialized() -> Result<()> {
    let p11 = get_test_pkcs11()?;

    assert!(p11.is_initialized(), "pkcs11 is not initialized");

    match p11.initialize(CInitializeArgs::OsThreads) {
        Err(P11HsmError::AlreadyInitialized) => Ok(()),
        Err(e) => Err(Error::P11(e)), //  panic!("unexpected initialization error: {}", e),
        Ok(_) => Err(Error::P11(P11HsmError::NotSupported)) //panic!("initializing twice should not have been allowed"),
    }
}

#[ignore]
#[test]
#[serial]
fn it_get_mechanism_list() -> Result<()> {
    let mut ctx = get_test_sdk_context()?;

    ctx.set_slot_by_label(TOKEN_LABEL)?;

    let ml = ctx.get_mechanism_list()?;

    println!("mechanism list: {:#?}", ml);

    Ok(())
}

#[ignore]
#[test]
#[serial]
fn it_get_mechanism_info() -> Result<()> {
    let mut ctx = get_test_sdk_context()?;

    ctx.set_slot_by_label(TOKEN_LABEL)?;

    let mt = MechanismType::AES_GCM;

    let mi = ctx.get_mechanism_info(mt)?;

    println!("mechanism: {} - mechanism info: {:#?}", mt, mi);

    Ok(())
}
#[ignore]
#[test]
#[serial]
fn it_is_fn_supported() -> Result<()> {
    let ctx = get_test_sdk_context()?;

    // todo: this contradicts FX doc which says C_SetPIN is not supported
    //   ref: https://portal.futurex.com/documentation/developer-documentation/general-purpose-7_6/Default.htm#PKCS11_Integration/Differences%20BETWEEN%20PKCS%2011.htm#_Toc477866251?TocPath=PKCS-11%2520TECHNICAL%2520REFERENCE%257C_____6
    assert!(
        ctx.p11().is_fn_supported(Function::SetPIN),
        "C_SetPIN is not supported"
    );

    // todo: this contradicts FX doc which says C_InitToken is not supported
    assert!(
        ctx.p11().is_fn_supported(Function::InitToken),
        "C_InitToken is not supported"
    );

    // todo: this contradicts FX doc which says C_InitPIN is not supported
    assert!(
        ctx.p11().is_fn_supported(Function::InitPIN),
        "C_InitPIN is not supported"
    );


    Ok(())
}

#[ignore]
#[test]
#[serial]
fn it_get_sdk_context() -> Result<()> {
    get_test_sdk_context()?;
    
    Ok(())
}

#[ignore]
#[test]
#[serial]
fn it_get_sdk_context_with_slot() -> Result<()> {
    let p11 = get_test_pkcs11()?;

    let _ctx = SDKContext::from_pkcs11_label(p11, TOKEN_LABEL)?;
    
    Ok(())
}
#[ignore]
#[test]
#[serial]
fn it_get_all_slot() -> Result<()> {
    let ctx = get_test_sdk_context()?;
    
    let _all_slot = ctx.p11().get_all_slots()?;
    
    Ok(())
}

#[ignore]
#[test]
#[serial]
fn it_get_slot() -> Result<()> {
    let ctx = get_test_sdk_context()?;
    
    let _slot = ctx.find_slot_by_label(TOKEN_LABEL)?;
    
    Ok(())
}

#[ignore]
#[test]
#[serial]
fn it_get_rw_session() -> Result<()> {
    let mut ctx = get_test_sdk_context()?;
    
    ctx.set_slot_by_label(TOKEN_LABEL)?;
    
    let session = ctx.open_rw_session()?;
    
    session.close();

    Ok(())
}

#[ignore]
#[test]
#[serial]
fn it_get_session() -> Result<()> {
    let mut ctx = get_test_sdk_context()?;

    ctx.set_slot_by_label(TOKEN_LABEL)?;

    let mut sdk = SDK::from_context(&ctx)?;

    sdk.login(USER_PIN)?;

    sdk.close()
}

#[ignore]
#[test]
#[serial]
fn it_get_sdk() -> Result<()> {
    let start  = Instant::now();
    let sdk = get_sdk()?;
    println!("Time elapsed after get_sdk(): {:?}", start.elapsed());

    sdk.close()?;

    Ok(())
}

/// This is for FX only
#[ignore]
#[test]
#[serial]
fn it_get_sdk2() -> Result<()> {
    let start  = Instant::now();
    let mut ctx = get_test_sdk_context()?;
    ctx.set_slot_by_label(TOKEN_LABEL)?;
    println!("Time elapsed after get_test_pkcs11: {:?}", start.elapsed());

    let mut sdk = SDK::from_context(&ctx)?;
    sdk.login(USER_PIN)?;
    println!("Time elapsed after 1st SDK::from_pkcs11: {:?}", start.elapsed());

    ctx.set_slot_by_label(TOKEN_LABEL_1)?;
    let sdk2 = SDK::from_context_with_login(&ctx, USER_PIN)?;

    println!("Time elapsed after SDK::from_pkcs11: {:?}", start.elapsed());

    sdk.close()?;
    sdk2.close()?;

    Ok(())
}
#[ignore]
#[test]
#[serial]
fn it_keygen() -> Result<()> {
    let start  = Instant::now();
    let sdk = get_sdk()?;

    println!("Time elapsed after get_sdk(): {:?}", start.elapsed());

    // test keygen for ed25519
    let kls = "slot-0/tsstrio-0/ed25519/1";
    // let kls = "slot-0/tsstrio-0/ed25519-long-oid/1";
    // let kls = "go/test/id-ed25519-hsm-1/1";
    // let kls = "Slot Token 0/WIM-test/id-ed25519-hsm-1/1";
    // let kls = "Slot Token 0/spl-token/id-ed25519-hsm-1/1";
    let mut key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Ed25519)?;

    let persistent = false;

    let (public, private, key_label) = sdk.keygen(&mut key_label, persistent)?;

    println!("algo: {:?}; key_label: {}; persisted: {}; pub key handle: {:?}; priv key handle: {:?}; ", key_label.algorithm, key_label.short_label(), persistent, public, private);
    println!("Time elapsed: {:?}", start.elapsed());
    // println!("public key: {:?}; private key: {:?}; key_label: {:?}", public, private, key_label);

    // test keygen for k256
    let kls = "Slot Token 0/WIM-test/secp256k1-hsm-1/1";
    let mut key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Secp256k1)?;

    let persistent = false;

    let (public, private, key_label) = sdk.keygen(&mut key_label, persistent)?;

    println!("algo: {:?}; key_label: {}; persisted: {}; pub key handle: {:?}; priv key handle: {:?}; ", key_label.algorithm, key_label.short_label(), persistent, public, private);
    println!("Time elapsed: {:?}", start.elapsed());

    // test keygen for p256
    let kls = "Slot Token 0/WIM-test/secp256r1-hsm-1/1";
    let mut key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Secp256r1)?;

    let persistent = false;

    let (public, private, key_label) = sdk.keygen(&mut key_label, persistent)?;

    println!("algo: {:?}; key_label: {}; persisted: {}; pub key handle: {:?}; priv key handle: {:?}; ", key_label.algorithm, key_label.short_label(), persistent, public, private);
    println!("Time elapsed: {:?}", start.elapsed());

    // test keygen for rsa2048
    let kls = "Slot Token 0/WIM-test/rsa2048-hsm-1/1";
    let mut key_label = KeyLabel::from_short(kls, CryptographAlgorithm::RSA2048)?;

    let persistent = false;

    let (public, private, key_label) = sdk.keygen(&mut key_label, persistent)?;

    println!("algo: {:?}; key_label: {}; persisted: {}; pub key handle: {:?}; priv key handle: {:?}; ", key_label.algorithm, key_label.short_label(), persistent, public, private);
    println!("Time elapsed: {:?}", start.elapsed());

    sdk.close()?;
    Ok(())
}

#[ignore]
#[test]
#[serial]
fn it_get_pub_key_handle() -> Result<()> {
    let start = Instant::now();
    let sdk = get_sdk()?;
    println!("Time elapsed post get_sdk(): {:?}", start.elapsed());
    // ed25519
    let kls = "Slot Token 0/WIM-test/id-ed25519-hsm-1/2";
    // let kls = "Slot Token 0/spl-token/id-ed25519-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Ed25519)?;

    let res = sdk.get_key_handle(&key_label, true);

    assert!(res.is_ok(), "Can not find public key for {} {:?}", kls, res);
    println!("Time elapsed: {:?}", start.elapsed());
    // k256
    let kls = "Slot Token 0/WIM-test/secp256k1-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Secp256k1)?;

    let res = sdk.get_key_handle(&key_label, true);

    assert!(res.is_ok(), "Can not find public key for {} {:?}", kls, res);
    println!("Time elapsed: {:?}", start.elapsed());
    // p256
    let kls = "Slot Token 0/WIM-test/secp256r1-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Secp256k1)?;

    let res = sdk.get_key_handle(&key_label, true);

    assert!(res.is_ok(), "Can not find public key for {} {:?}", kls, res);
    println!("Time elapsed: {:?}", start.elapsed());
    // rsa
    let kls = "Slot Token 0/WIM-test/rsa2048-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::RSA2048)?;

    let res = sdk.get_key_handle(&key_label, true);

    assert!(res.is_ok(), "Can not find public key for {} {:?}", kls, res);
    println!("Time elapsed: {:?}", start.elapsed());

    sdk.close()?;
    Ok(())
}

#[ignore]
#[test]
#[serial]
fn it_get_priv_key_handle() -> Result<()> {
    let start = Instant::now();
    let sdk = get_sdk()?;
    println!("Time elapsed post get_sdk(): {:?}", start.elapsed());
    // ed25519
    let kls = "Slot Token 0/WIM-test/id-ed25519-hsm-1/2";
    // let kls = "Slot Token 0/spl-token/id-ed25519-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Ed25519)?;

    let res = sdk.get_key_handle(&key_label, false);

    assert!(res.is_ok(), "Can not find public key for {} {:?}", kls, res);
    println!("Time elapsed: {:?}", start.elapsed());
    // k256
    let kls = "Slot Token 0/WIM-test/secp256k1-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Secp256k1)?;

    let res = sdk.get_key_handle(&key_label, false);

    assert!(res.is_ok(), "Can not find public key for {} {:?}", kls, res);
    println!("Time elapsed: {:?}", start.elapsed());
    // p256
    let kls = "Slot Token 0/WIM-test/secp256r1-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Secp256k1)?;

    let res = sdk.get_key_handle(&key_label, false);

    assert!(res.is_ok(), "Can not find public key for {} {:?}", kls, res);
    println!("Time elapsed: {:?}", start.elapsed());
    // rsa
    let kls = "Slot Token 0/WIM-test/rsa2048-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::RSA2048)?;

    let res = sdk.get_key_handle(&key_label, false);

    assert!(res.is_ok(), "Can not find public key for {} {:?}", kls, res);
    println!("Time elapsed: {:?}", start.elapsed());

    sdk.close()?;
    Ok(())
}

#[ignore]
#[test]
#[serial]
fn it_get_pub_key_ec_point() -> Result<()> {
    let start = Instant::now();
    let sdk = get_sdk()?;

    println!("Time elapsed post get_sdk(): {:?}", start.elapsed());

    // ed25519
    let kls = "slot-0/tsstrio-0/ed25519/1";
    // let kls = "slot-0/tsstrio-0/ed25519-imported/1";
    // let kls = "slot-0/tsstrio-0/ed25519-long-oid/1";
    // let kls = "Slot Token 0/WIM-test/id-ed25519-hsm-1/2";
    // let kls = "Slot Token 0/spl-token/id-ed25519-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Ed25519)?;

    let ec_point = sdk.get_public_key_ec_point(&key_label)?;
    let l = ec_point.len();

    assert!(l == 32 || l == 34);

    println!("algo: {:?}, key_label: {}; ec point: {:?}; len: {}", key_label.algorithm, key_label.short_label(), ec_point, l);
    println!("Time elapsed: {:?}", start.elapsed());
    // k256
    let kls = "Slot Token 0/WIM-test/secp256k1-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Secp256k1)?;

    let ec_point = sdk.get_public_key_ec_point(&key_label)?;
    let l = ec_point.len();

    assert_eq!(l, 67, "len {} is incorrect", l);

    println!("algo: {:?}, key_label: {}; ec point: {:?}; len: {}", key_label.algorithm, key_label.short_label(), ec_point, l);
    println!("Time elapsed: {:?}", start.elapsed());
    // p256
    let kls = "Slot Token 0/WIM-test/secp256r1-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Secp256r1)?;

    let ec_point = sdk.get_public_key_ec_point(&key_label)?;
    let l = ec_point.len();

    assert_eq!(l, 67, "len {} is incorrect", l);

    println!("algo: {:?}, key_label: {}; ec point: {:?}; len: {}", key_label.algorithm, key_label.short_label(), ec_point, l);
    println!("Time elapsed: {:?}", start.elapsed());
    sdk.close()?;
    Ok(())
}

#[ignore]
#[test]
#[serial]
// TODO: oids don't match those in SUPPORTED_ALGORITHMS
fn it_get_pub_key_ec_point_oid() -> Result<()> {
    let start = Instant::now();
    let sdk = get_sdk()?;

    println!("Time elapsed post get_sdk(): {:?}", start.elapsed());

    // ed25519
    let kls = "Slot Token 0/WIM-test/id-ed25519-hsm-1/2";
    // let kls = "Slot Token 0/spl-token/id-ed25519-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Ed25519)?;

    let (ec_point, oid) = sdk.get_public_key_ec_point_oid(&key_label)?;
    let l = ec_point.len();

    assert!(l == 32 || l == 34);

    println!("algo: {:?}, key_label: {}; ec point: {:?}; len: {}; oid: {:?}", key_label.algorithm, key_label.short_label(), ec_point, l, oid);
    println!("Time elapsed: {:?}", start.elapsed());
    // k256
    let kls = "Slot Token 0/WIM-test/secp256k1-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Secp256k1)?;

    let (ec_point, oid) = sdk.get_public_key_ec_point_oid(&key_label)?;
    let l = ec_point.len();

    assert_eq!(l, 67, "len {} is incorrect", l);

    println!("algo: {:?}, key_label: {}; ec point: {:?}; len: {}; oid: {:?}", key_label.algorithm, key_label.short_label(), ec_point, l, oid);
    println!("Time elapsed: {:?}", start.elapsed());
    // p256
    let kls = "Slot Token 0/WIM-test/secp256r1-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Secp256r1)?;

    let (ec_point, oid) = sdk.get_public_key_ec_point_oid(&key_label)?;
    let l = ec_point.len();

    assert_eq!(l, 67, "len {} is incorrect", l);

    println!("algo: {:?}, key_label: {}; ec point: {:?}; len: {}; oid: {:?}", key_label.algorithm, key_label.short_label(), ec_point, l, oid);
    println!("Time elapsed: {:?}", start.elapsed());
    sdk.close()?;
    Ok(())
}
#[ignore]
#[test]
#[serial]
fn it_get_ed_public_key() -> Result<()> {
    let sdk = get_sdk()?;

    // use "go/test/id-ed25519-hsm-1/1" which was created after the fix for ed der encoding.
    // let kls = "slot-0/tsstrio-1/ed25519/1";
    let kls = "slot-0/tsstrio-0/ed25519/1";
    // let kls = "slot-0/tsstrio-0/ed25519-imported/1";
    // let kls = "slot-0/tsstrio-0/ed25519-long-oid/1";
    // let kls = "go/test/id-ed25519-hsm-1/1";
    // let kls = "Slot Token 0/WIM-test/id-ed25519-hsm-1/5";
    // let kls = "Slot Token 0/spl-token/id-ed25519-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Ed25519)?;

    let public_key = sdk.get_ed_public_key(&key_label)?;

    println!("algo: {:?}; key_label: {}; pub key: {}", key_label.algorithm, key_label.short_label(), hex::encode(public_key.as_bytes()));

    sdk.close()?;
    Ok(())
}

#[ignore]
#[test]
#[serial]
fn it_get_ec_public_key() -> Result<()> {
    let sdk = get_sdk()?;

    // k256
    let kls = "Slot Token 0/WIM-test/secp256k1-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Secp256k1)?;

    let public_key = sdk.get_ec_public_key::<Secp256k1>(&key_label)?;

    println!("algo: {:?}; key_label: {}; pub key: {}", key_label.algorithm, key_label.short_label() ,hex::encode(public_key.to_sec1_bytes()));

    // p256
    let kls = "Slot Token 0/WIM-test/secp256r1-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Secp256r1)?;

    let public_key = sdk.get_ec_public_key::<NistP256>(&key_label)?;

    println!("algo: {:?}; key_label: {}; pub key: {}", key_label.algorithm, key_label.short_label() ,hex::encode(public_key.to_sec1_bytes()));

    sdk.close()?;
    Ok(())
}

#[ignore]
#[test]
#[serial]
fn it_sign_verify_ed25519() -> Result<()> {
    let start = Instant::now();
    let sdk = get_sdk()?;
    println!("Time elapsed post get_sdk(): {:?}", start.elapsed());

    let kls = "slot-0/tsstrio-0/ed25519/1";
    // let kls = "slot-0/tsstrio-0/ed25519-long-oid/1";
    // let kls = "Slot Token 0/WIM-test/id-ed25519-hsm-1/5";

    // let kls = "Slot Token 0/spl-token/id-ed25519-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Ed25519)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();

    // sign data
    let sig = sdk.sign(&key_label, data)?;
    println!("Time elapsed post sign(): {:?}", start.elapsed());
    // verify sig - positive
    assert!(sdk.verify_sig(&key_label, data, &sig).is_ok());
    println!("Time elapsed post verify(): {:?}", start.elapsed());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    assert!(sdk.verify_sig(&key_label, data, &sig).is_err());
    println!("Time elapsed post verify() - negative: {:?}", start.elapsed());
    sdk.close()?;
    Ok(())
}

/// This is for FX only
#[ignore]
#[test]
#[serial]
fn it_sign_verify_ed25519_by_sdk_sdk2() -> Result<()> {
    let start = Instant::now();
    let mut ctx = get_test_sdk_context()?;
    ctx.set_slot_by_label(TOKEN_LABEL)?;
    println!("Time elapsed post get_test_pkcs11: {:?}", start.elapsed());

    let mut sdk = SDK::from_context(&ctx)?;
    sdk.login(USER_PIN)?;
    println!("Time elapsed post 1st SDK::from_pkcs11: {:?}", start.elapsed());

    ctx.set_slot_by_label(TOKEN_LABEL_1)?;
    let mut sdk2 = SDK::from_context(&ctx)?;
    sdk2.login(USER_PIN)?;
    println!("Time elapsed post 2nd SDK::from_pkcs11: {:?}", start.elapsed());

    // sdk
    println!("***** start with sdk: {:?}", start.elapsed());

    let kls = "Slot Token 0/WIM-test/id-ed25519-hsm-1/4";

    // let kls = "Slot Token 0/spl-token/id-ed25519-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Ed25519)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();

    // sign data
    let sig = sdk.sign(&key_label, data)?;
    println!("Time elapsed post sign(): {:?}", start.elapsed());
    // verify sig - positive
    assert!(sdk.verify_sig(&key_label, data, &sig).is_ok());
    println!("Time elapsed post verify(): {:?}", start.elapsed());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    assert!(sdk.verify_sig(&key_label, data, &sig).is_err());
    println!("Time elapsed post verify() - negative: {:?}", start.elapsed());

    // sdk2
    println!("***** start with sdk2: {:?}", start.elapsed());
    let kls = "Slot Token 0/WIM-test/id-ed25519-hsm-1/5";

    // let kls = "Slot Token 0/spl-token/id-ed25519-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Ed25519)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();

    // sign data
    let sig = sdk2.sign(&key_label, data)?;
    println!("Time elapsed post sign(): {:?}", start.elapsed());
    // verify sig - positive
    assert!(sdk2.verify_sig(&key_label, data, &sig).is_ok());
    println!("Time elapsed post verify(): {:?}", start.elapsed());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    assert!(sdk2.verify_sig(&key_label, data, &sig).is_err());
    println!("Time elapsed post verify() - negative: {:?}", start.elapsed());


    sdk.close()?;
    sdk2.close()?;
    Ok(())
}
// Note: for k256, p256 and rsa sign and verify with FX HSM, data/msg needs to be
//  hashed.
//  SOFTHSM2 does not require hashing.
//  For ed25519, data/msg does not need to be hashed for both FX HSM and SOFTHSM2.
#[ignore]
#[test]
#[serial]
fn it_sign_verify_secp256k1() -> Result<()> {
    let sdk = get_sdk()?;

    let kls = "Slot Token 0/WIM-test/secp256k1-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Secp256k1)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();
    let hash = secure_hash(data);

    // sign data
    let sig = sdk.sign(&key_label, &hash[..])?;

    // verify sig - positive
    assert!(sdk.verify_sig(&key_label, &hash[..], &sig).is_ok());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    let hash = secure_hash(data);

    assert!(sdk.verify_sig(&key_label, &hash[..], &sig).is_err());

    sdk.close()?;
    Ok(())
}

#[ignore]
#[test]
#[serial]
fn it_sign_verify_secp256r1() -> Result<()> {
    let sdk = get_sdk()?;

    let kls = "Slot Token 0/WIM-test/secp256r1-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Secp256r1)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();
    let hash = secure_hash(data);

    // sign data
    let sig = sdk.sign(&key_label, &hash[..])?;

    // verify sig - positive
    assert!(sdk.verify_sig(&key_label, &hash[..], &sig).is_ok());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    let hash = secure_hash(data);
    assert!(sdk.verify_sig(&key_label, &hash[..], &sig).is_err());

    sdk.close()?;
    Ok(())
}

#[ignore]
#[test]
#[serial]
fn it_sign_verify_rsa2048() -> Result<()> {
    let sdk = get_sdk()?;

    let kls = "Slot Token 0/WIM-test/rsa2048-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::RSA2048)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();
    let hash = secure_hash(data);
    // let mut hasher = Sha256::new();
    // hasher.update(data);
    // let hash = hasher.finalize();
    // sign data
    let sig = sdk.sign(&key_label, &hash[..])?;

    // verify sig - positive
    assert!(sdk.verify_sig(&key_label, &hash[..], &sig).is_ok());

    // verify sig - positive
    let data = "sign me not".as_bytes();
    let hash = secure_hash(data);
    // let mut hasher = Sha256::new();
    // hasher.update(data);
    // let hash = hasher.finalize();
    assert!(sdk.verify_sig(&key_label, &hash[..], &sig).is_err());

    sdk.close()?;
    Ok(())
}

#[ignore]
#[test]
#[serial]
fn it_sign_verify_sig_ed25519_outside_hsm() -> Result<()> {
    let sdk = get_sdk()?;

    // use "go/test/id-ed25519-hsm-1/1" which was created after the fix for ed der encoding.
    let kls = "slot-0/tsstrio-0/ed25519/1";
    // let kls = "slot-0/tsstrio-0/ed25519-imported/1";
    // let kls = "go/test/id-ed25519-hsm-1/1";
    // let kls = "Slot Token 0/WIM-test/id-ed25519-hsm-1/2";
    // let kls = "Slot Token 0/spl-token/id-ed25519-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Ed25519)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();

    // sign data
    let sig = sdk.sign_eddsa(&key_label, data)?;

    // verify sig - positive
    assert!(sdk.verify_sig_ed_outside_hsm(&key_label, data, &sig).is_ok());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    assert!(sdk.verify_sig_ed_outside_hsm(&key_label, data, &sig).is_err());

    sdk.close()?;
    Ok(())
}

#[ignore]
#[test]
#[serial]
fn it_sign_verify_sig_secp256k1_outside_hsm_generic() -> Result<()> {
    let sdk = get_sdk()?;

    let kls = "Slot Token 0/WIM-test/secp256k1-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Secp256k1)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();

    // sign_ecdsa will hash the data before signing.
    // let hash = secure_hash(data);

    // sign data
    let sig = sdk.sign_ecdsa::<Secp256k1>(&key_label, data)?;

    // verify sig - positive
    assert!(sdk.verify_ec_outside_hsm::<Secp256k1>(&key_label, data, &sig).is_ok());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    assert!(sdk.verify_ec_outside_hsm::<Secp256k1>(&key_label, data, &sig).is_err());

    // this also works
/*
    let public_key = sdk.get_ec_public_key::<Secp256k1>(&key_label)?;
    // verify sig - positive
    assert!(public_key.verify(&data[..], &sig).is_ok());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    assert!(public_key.verify(&data[..], &sig).is_err());
*/

    sdk.close()?;
    Ok(())
}

#[ignore]
#[test]
#[serial]
fn it_sign_verify_sig_secp256k1_outside_hsm() -> Result<()> {
    let sdk = get_sdk()?;

    let kls = "Slot Token 0/WIM-test/secp256k1-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Secp256k1)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();

    // sign_ecdsa will hash the data before signing.
    // let hash = secure_hash(data);

    // sign data
    let sig = sdk.sign_ecdsa::<Secp256k1>(&key_label, data)?;

    // verify sig - positive
    assert!(sdk.verify_sig_k256_outside_hsm(&key_label, data, &sig).is_ok());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    assert!(sdk.verify_sig_k256_outside_hsm(&key_label, data, &sig).is_err());

    // this also works
    /*
        let public_key = sdk.get_ec_public_key::<Secp256k1>(&key_label)?;
        // verify sig - positive
        assert!(public_key.verify(&data[..], &sig).is_ok());
    
        // verify sig - negative
        let data = "sign me not".as_bytes();
        assert!(public_key.verify(&data[..], &sig).is_err());
    */

    sdk.close()?;
    Ok(())
}

#[ignore]
#[test]
#[serial]
fn it_sign_verify_sig_secp256r1_outside_hsm_generic() -> Result<()> {
    let sdk = get_sdk()?;

    let kls = "Slot Token 0/WIM-test/secp256r1-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Secp256r1)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();

    // sign_ecdsa will hash the data before signing.
    // let hash = secure_hash(data);

    // sign data
    let sig = sdk.sign_ecdsa::<NistP256>(&key_label, data)?;

    // verify sig - positive
    assert!(sdk.verify_ec_outside_hsm::<NistP256>(&key_label, data, &sig).is_ok());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    assert!(sdk.verify_ec_outside_hsm::<NistP256>(&key_label, data, &sig).is_err());

    /*
        let public_key = sdk.get_ec_public_key::<NistP256>(&key_label)?;
        // verify sig - positive
        assert!(public_key.verify(&data[..], &sig).is_ok());

        // verify sig - negative
        let data = "sign me not".as_bytes();
        assert!(public_key.verify(&data[..], &sig).is_err());
    */

    sdk.close()?;
    Ok(())
}

#[ignore]
#[test]
#[serial]
fn it_sign_verify_sig_secp256r1_outside_hsm() -> Result<()> {
    let sdk = get_sdk()?;

    let kls = "Slot Token 0/WIM-test/secp256r1-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Secp256r1)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();

    // sign_ecdsa will hash the data before signing.
    // let hash = secure_hash(data);

    // sign data
    let sig = sdk.sign_ecdsa::<NistP256>(&key_label, data)?;

    // verify sig - positive
    assert!(sdk.verify_p256_outside_hsm(&key_label, data, &sig).is_ok());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    assert!(sdk.verify_p256_outside_hsm(&key_label, data, &sig).is_err());

    /*
        let public_key = sdk.get_ec_public_key::<NistP256>(&key_label)?;
        // verify sig - positive
        assert!(public_key.verify(&data[..], &sig).is_ok());

        // verify sig - negative
        let data = "sign me not".as_bytes();
        assert!(public_key.verify(&data[..], &sig).is_err());
    */

    sdk.close()?;
    Ok(())
}

#[ignore]
#[test]
#[serial]
fn it_sign_verify_prehash_sig_secp256k1_outside_hsm() -> Result<()> {
    let sdk = get_sdk()?;

    let kls = "Slot Token 0/WIM-test/secp256k1-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Secp256k1)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();

    // sign_ecdsa will hash the data before signing.
    let hash = secure_hash(data);

    // sign data
    let sig = sdk.sign_ecdsa::<Secp256k1>(&key_label, data)?;

    // verify sig - positive
    assert!(sdk.verify_prehash_ec_outside_hsm::<Secp256k1>(&key_label, &hash[..], &sig).is_ok());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    let hash = secure_hash(data);
    assert!(sdk.verify_prehash_ec_outside_hsm::<Secp256k1>(&key_label, &hash[..], &sig).is_err());

    // this also works
    /*
        let public_key = sdk.get_ec_public_key::<Secp256k1>(&key_label)?;
        // verify sig - positive
        assert!(public_key.verify(&data[..], &sig).is_ok());

        // verify sig - negative
        let data = "sign me not".as_bytes();
        assert!(public_key.verify(&data[..], &sig).is_err());
    */

    sdk.close()?;
    Ok(())
}

// p256 verify_prehash does not work as expected - always err
// so ignore this test.
#[test]
#[serial]
#[ignore]
fn it_sign_verify_prehash_sig_secp256r1_outside_hsm() -> Result<()> {
    let sdk = get_sdk()?;

    let kls = "Slot Token 0/WIM-test/secp256r1-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Secp256r1)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();
    let hash = secure_hash(data);

    // sign data
    let sig = sdk.sign_ecdsa::<NistP256>(&key_label, &hash[..])?;

    // verify sig - positive
    assert!(sdk.verify_ec_outside_hsm::<NistP256>(&key_label, &hash[..], &sig).is_ok());

    // verify sig - negative
    let data = "sign me not".as_bytes();
    let hash = secure_hash(data);
    assert!(sdk.verify_prehash_ec_outside_hsm::<NistP256>(&key_label, &hash[..], &sig).is_err());

    sdk.close()?;
    Ok(())
}

/*
Test Secp256k1 signature verification.
This test was useful to debug the signature verification issue.
Now we should use sdk.verify_sig_ec_outside_hsm instead.
 */
#[ignore]
#[test]
#[serial]
fn it_sign_verify_sig_secp256k1_outside_hsm_integrated() -> Result<()> {
    let sdk = get_sdk()?;

    let kls = "Slot Token 0/WIM-test/secp256k1-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Secp256k1)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();
    // Only Sha256 will work. Sha384 and Sha512 will not work.
    let mut hasher = Sha256::new();
    hasher.update(data);
    let hash = hasher.finalize();

    // sign data
    let sig = sdk.sign(&key_label, &hash[..])?;

    println!("raw sig: {:?}", hex::encode(&sig));

    let sig = EcSignature::<Secp256k1>::from_slice(&sig).unwrap();
    let sig = if let Some(sig) = sig.normalize_s() {
        sig
    } else {
        sig
    };
    let public_key = sdk.get_k256_public_key(&key_label)?;
    assert!(public_key.verify(&data[..], &sig).is_ok());
    sdk.close()?;
    Ok(())
}

#[ignore]
#[test]
#[serial]
fn it_sign_verify_prehash_sig_secp256k1_outside_hsm_integrated() -> Result<()> {
    let sdk = get_sdk()?;

    let kls = "Slot Token 0/WIM-test/secp256k1-hsm-1/1";
    let key_label = KeyLabel::from_short(kls, CryptographAlgorithm::Secp256k1)?;

    // data to sign
    // let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];
    let data = "sign me".as_bytes();
    // any of Sha256, Sha384, Sha512 will will work
    let mut hasher = Sha512::new();
    hasher.update(data);
    let hash = hasher.finalize();

    // sign data
    let sig = sdk.sign(&key_label, &hash[..])?;

    println!("raw sig: {:?}", hex::encode(&sig));

    let sig = EcSignature::<Secp256k1>::from_slice(&sig).unwrap();
    let sig = if let Some(sig) = sig.normalize_s() {
        sig
    } else {
        sig
    };
    // let sig2 = sig1.normalize_s();
    // let sig1 = if sig2.is_some() { sig2.unwrap() } else { sig1 };
    let public_key = sdk.get_k256_public_key(&key_label)?;
    assert!(public_key.verify_prehash(&hash[..], &sig).is_ok());
    /*
        sdk.verify_sig_ec_outside_hsm(&key_label, data, &sig).map_err(|e| {
            println!("error: {:?}", e);
            e
        })?;
        // verify sig - positive
        assert!(sdk.verify_sig_ec_outside_hsm(&key_label, data, &sig).is_ok());

        // verify sig - negative
        let data = "sign me not".as_bytes();
        assert!(sdk.verify_sig_ec_outside_hsm(&key_label, data, &sig).is_err());
    */
    sdk.close()?;
    Ok(())
}
