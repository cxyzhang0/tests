// Copyright 2021 Contributors to the Parsec project.
// SPDX-License-Identifier: Apache-2.0

use std::env;
use std::sync::Once;
use pkcs11::{SDK, init_sdk};
//use asn1::parse;
// use ed25519_dalek::ed25519;
// use ed25519_dalek::{PublicKey};
// use ed25519::signature::Keypair;

/*
#[derive(Debug)]
pub struct ErrorWithStacktrace;

impl<T: std::error::Error> From<T> for ErrorWithStacktrace {
    fn from(p: T) -> Self {
        panic!("Error: {:#?}", p);
    }
}

pub type Result<T> = std::result::Result<T, ErrorWithStacktrace>;
*/

// Turn on either SOFTHSM2 or FutureX by commenting out the other below.
// SOFTHSM2
/*
// The env for module if any
pub static ENV_MODULE: &str = "PKCS11_SOFTHSM2_MODULE";
// The default module path
pub static MODULE: &str = "/usr/local/lib/softhsm/libsofthsm2.so";
// The default user pin
pub static USER_PIN: &str = "5678";
// The default SO pin
pub static _SO_PIN: &str = "1234";
// The default token label
pub static TOKEN_LABEL: &str = "Slot Token 0";
pub static TOKEN_LABEL_1: &str = "Slot Token 1";
*/

// FutureX

pub static ENV_MODULE: &str = "FXPKCS11_MODULE";
// The default module path
pub static MODULE: &str = "/Users/johnz/futurex/fxpkcs11-mac-arm-5.7-e7c4/libfxpkcs11.dylib";
// pub static MODULE: &str = "/Users/johnz/futurex/fxpkcs11-mac-arm-5.8-ca64/libfxpkcs11.dylib"; // may not be official
// pub static MODULE: &str = "/Users/johnz/futurex/fxpkcs11-mac-arm-5.5-5d0b/libfxpkcs11.dylib";
// pub static MODULE: &str = "/Users/johnz/futurex/fxpkcs11-mac-arm-4.59-8551/libfxpkcs11.dylib";
// pub static MODULE: &str = "/Users/johnz/futurex/fxpkcs11-mac-arm-5.0-f069/libfxpkcs11.dylib";
// pub static MODULE: &str = "/Users/johnz/futurex/fxpkcs11-mac-arm-4.58-422d/libfxpkcs11.dylib";
// The default user pin
pub static USER_PIN: &str = "safest";
// The default SO pin
pub static _SO_PIN: &str = "1234";
// The default token label
pub static TOKEN_LABEL: &str = "Slot Token 0";
// pub static TOKEN_LABEL: &str = "us01crypto01test.virtucrypt.com:";
pub static TOKEN_LABEL_1: &str = "Slot Token 1";


// config
pub const ENV_SOFTHSM2_CONF: &str = "SOFTHSM2_CONF";
pub const SOFTHSM2_CONF: &str = "/etc/softhsm2.conf";

pub const ENV_FXPKCS11_CFG: &str = "FXPKCS11_CFG";
pub const FXPKCS11_CFG: &str = "/Users/johnz/futurex/fxpkcs11-mac-arm-5.7-e7c4/fxpkcs11.cfg";
// pub const FXPKCS11_CFG: &str = "/Users/johnz/futurex/fxpkcs11-mac-arm-4.58-422d/fxpkcs11.cfg";


static INIT: Once = Once::new();

pub fn init() {
    INIT.call_once(|| {
        env::set_var(ENV_SOFTHSM2_CONF, SOFTHSM2_CONF);
        env::set_var(ENV_FXPKCS11_CFG, FXPKCS11_CFG);
    });
}

pub fn get_sdk() -> pkcs11::Result<SDK> {
    init();
    let sdk = SDK::new(Some(ENV_MODULE), Some(MODULE), TOKEN_LABEL, USER_PIN)?;

    Ok(sdk)
}

// todo: get_sdk_new() can only be used to run tests one at a time, in IDE for example.
// it is using SoftHsm's config.
pub fn get_sdk_new() -> pkcs11::Result<SDK> {
    let ctx = init_sdk(
        ENV_SOFTHSM2_CONF,
        SOFTHSM2_CONF,
        Some(ENV_MODULE),
        Some(MODULE),
        TOKEN_LABEL,
        USER_PIN,
    )?;
    let sdk = SDK::from_context(&ctx)?;
    /* 
        note: sdk is fully logged in even thought its new session is not explicitly logged in.
        that is because in fn init_sdk(...), the (private) Init's private _sdk holds a logged-in session.
        so any future session opened on ctx will be automatically logged in regardless of threads.
        that is the feature of PKCS11 sessions.    
    */
    
    Ok(sdk)
}

/*
// Initialize slot with TOKEN_LABEL, SO_PIN and USER_PIN
// WARNING: all existing data will be lost.
// To preserve the data, this function should not be called. Instead,
// use pkcs11-tool or softhsm2-util to do the initialization; or somehow call
// this function once and only once.
// NOTE: FXPKCS11 does not support C_InitToken, C_SetPIN, C_InitPIN.
pub fn init_pins() -> (Pkcs11, Slot) {
    // env::set
    let mut pkcs11 =
        Pkcs11::new(env::var(ENV_MODULE).unwrap_or_else(|_| MODULE.to_string())).unwrap();

    // initialize the library
    pkcs11.initialize(CInitializeArgs::OsThreads).unwrap();

    // find a slot, get the first one
    let slot = pkcs11.get_slots_with_token().unwrap().remove(0);

    pkcs11.init_token(slot, SO_PIN, TOKEN_LABEL).unwrap();

    {
        // open a session
        let session = pkcs11.open_rw_session(slot).unwrap();
        // log in the session
        session.login(UserType::So, Some(SO_PIN)).unwrap();
        session.init_pin(USER_PIN).unwrap();
    }

    (pkcs11, slot)
}
*/