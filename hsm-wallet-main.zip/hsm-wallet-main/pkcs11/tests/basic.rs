// source: https://github.com/parallaxsecond/rust-cryptoki/blob/main/cryptoki/tests/basic.rs 
// All the tests work. But "mod common;" cannot be used once in tests so it conflicts with the same in tests/sdk.rs.
// So we comment it all out but keep it for reference just in case we missed something in sdk.

/*
/ Copyright 2021 Contributors to the Parsec project.
// SPDX-License-Identifier: Apache-2.0

mod common;
mod sdk;

use crate::common::{
    get_ec_point, get_private_key_handle, get_public_key, get_public_key_handle, sign, verify_sig,
};
use common::{/*init_pins,*/ get_pkcs11, get_slot};
use common::{Result, ENV_MODULE, MODULE, SO_PIN, TOKEN_LABEL, USER_PIN};
use cryptoki::error::{Error, RvError};
use cryptoki::mechanism::Mechanism;
use cryptoki::object::{Attribute, AttributeInfo, AttributeType, KeyType, ObjectClass};
use cryptoki::session::{SessionState, UserType};
use serial_test::serial;
use std::collections::HashMap;
use std::thread;
// This test will wipe out the whole keys database.
/*
#[test]
#[serial]
// #[ignore]
fn test_init_pins() -> Result<()> {
    let (_, _) = init_pins();

    Ok(())
}
*/

#[test]
#[serial]
fn test_get_slot() -> Result<()> {
    let pkcs11 = get_pkcs11();
    let slot = get_slot(&pkcs11, TOKEN_LABEL)?;
    let info = pkcs11.get_token_info(slot)?;
    assert_eq!(TOKEN_LABEL, info.label());
    Ok(())
}

#[test]
#[serial]
// use persistent to indicate whether or not to save the new keys.
fn generate_ed25519_keypair() -> Result<()> {
    // whether or not to persist the new keys
    let persistent = false;

    // let (pkcs11, slot) = init_pins();
    let pkcs11 = get_pkcs11();
    let slot = get_slot(&pkcs11, TOKEN_LABEL)?;

    // open a session on slot
    let session = pkcs11.open_rw_session(slot)?;

    // log in the session
    session.login(UserType::User, Some(USER_PIN))?;

    // get mechanism
    let mechanism = Mechanism::EccEdwardsKeyPairGen;

    // oid for id-ed25519
    let oid: Vec<u8> = vec![0x06, 0x03, 0x2B, 0x65, 0x70]; // id-ed25519
                                                           // let oid: Vec<u8> = vec![0x06, 0x09, 0x2B, 0x06, 0x01, 0x04, 0x01, 0xDA, 0x47, 0x0F, 0x01]; // ed25519, does not work

    // pub key template
    let pub_key_template = vec![
        Attribute::EcParams(oid),
        Attribute::Verify(true),
        Attribute::Token(persistent),
        // Attribute::Label(Vec::from("TestEd25519".as_bytes())),
        Attribute::Label(Vec::from(
            "Slot Token 0/WIM-test/id-ed25519-hsm-2/3".as_bytes(),
        )),
        Attribute::Private(false),
    ];

    // priv key template
    let priv_key_template = vec![
        Attribute::Sign(true),
        Attribute::Sensitive(true),
        Attribute::Extractable(true),
        Attribute::Token(persistent),
        // Attribute::Label(Vec::from("TestEd25519".as_bytes())),
        Attribute::Label(Vec::from(
            "Slot Token 0/WIM-test/id-ed25519-hsm-2/3".as_bytes(),
        )),
    ];

    // generate a key pair
    let (_, _) = session.generate_key_pair(&mechanism, &pub_key_template, &priv_key_template)?;

    Ok(())
}

#[test]
#[serial]
fn test_get_private_key_handle() -> Result<()> {
    let key_label = "Slot Token 0/WIM-test/id-ed25519-hsm-1/1";
    let pkcs11 = get_pkcs11();
    let slot = get_slot(&pkcs11, TOKEN_LABEL)?;

    // open a session on slot
    let session = pkcs11.open_rw_session(slot)?;

    // log in the session
    session.login(UserType::User, Some(USER_PIN))?;
    let res = get_private_key_handle(&session, key_label);
    assert!(res.is_ok(), "Can not find private key for {}", key_label);

    Ok(())
}

#[test]
#[serial]
fn test_get_public_key_handle() -> Result<()> {
    let key_label = "Slot Token 0/WIM-test/id-ed25519-hsm-1/1";
    let pkcs11 = get_pkcs11();
    let slot = get_slot(&pkcs11, TOKEN_LABEL)?;

    // open a session on slot
    let session = pkcs11.open_rw_session(slot)?;

    // log in the session
    session.login(UserType::User, Some(USER_PIN))?;
    let res = get_public_key_handle(&session, key_label);
    assert!(res.is_ok(), "Can not find public key for {}", key_label);

    Ok(())
}

#[test]
#[serial]
fn test_get_ec_point() -> Result<()> {
    let key_label = "Slot Token 0/WIM-test/id-ed25519-hsm-1/1";
    let pkcs11 = get_pkcs11();
    let slot = get_slot(&pkcs11, TOKEN_LABEL)?;

    // open a session on slot
    let session = pkcs11.open_rw_session(slot)?;

    // log in the session
    session.login(UserType::User, Some(USER_PIN))?;

    let ec_point = get_ec_point(&session, key_label)?;

    let l = ec_point.len();
    assert_eq!(l, 34, "len {} is incorrect", l);

    Ok(())
}

#[test]
#[serial]
fn test_get_public_key() -> Result<()> {
    let key_label = "Slot Token 0/WIM-test/id-ed25519-hsm-1/1";
    let pkcs11 = get_pkcs11();
    let slot = get_slot(&pkcs11, TOKEN_LABEL)?;

    // open a session on slot
    let session = pkcs11.open_rw_session(slot)?;

    // log in the session
    session.login(UserType::User, Some(USER_PIN))?;

    let public_key = get_public_key(&session, key_label)?;

    // println!("{:?}", public_key.as_bytes());
    // println!("{}", String::from_utf8_lossy(public_key.as_bytes()));
    // println!("{:X?}", public_key.as_bytes());
    println!("public key: {}", hex::encode(public_key.as_bytes()));

    Ok(())
}

#[test]
#[serial]
// use existing keypair to sign and verify.
fn test_sign_verify_ed25519() -> Result<()> {
    let key_label = "Slot Token 0/WIM-test/id-ed25519-hsm-1/1";

    let pkcs11 = get_pkcs11();
    let slot = get_slot(&pkcs11, TOKEN_LABEL)?;

    // open a session on slot
    let session = pkcs11.open_rw_session(slot)?;

    // log in the session
    session.login(UserType::User, Some(USER_PIN))?;

    // data to sign
    let data = b"\x30\x06\x02\x01\x01\x02\x01\x03";
    // let data = &[0xFF, 0x55, 0xDD];

    // sign data
    let sig = sign(&session, key_label, &Mechanism::Eddsa, data)?;

    // verify the signature
    verify_sig(&session, key_label, &Mechanism::Eddsa, data, &sig)?;

    Ok(())
}

#[test]
#[serial]
// generate key pair, sign, verify and delete key pair.
fn sign_verify_ed25519() -> Result<()> {
    // let (pkcs11, slot) = init_pins();
    let pkcs11 = get_pkcs11();
    let slot = get_slot(&pkcs11, TOKEN_LABEL)?;

    // open a session on slot
    let session = pkcs11.open_rw_session(slot)?;

    // log in the session
    session.login(UserType::User, Some(USER_PIN))?;

    // get mechanism
    let mechanism = Mechanism::EccEdwardsKeyPairGen;

    // oid for id-ed25519
    let oid: Vec<u8> = vec![0x06, 0x03, 0x2B, 0x65, 0x70]; // id-ed25519
                                                           // let oid: Vec<u8> = vec![0x06, 0x09, 0x2B, 0x06, 0x01, 0x04, 0x01, 0xDA, 0x47, 0x0F, 0x01]; // ed25519, does not work

    // pub key template
    let pub_key_template = vec![
        Attribute::EcParams(oid),
        Attribute::Verify(true),
        Attribute::Token(true),
        Attribute::Label(Vec::from("TestEd25519".as_bytes())),
        // Attribute::Label(Vec::from("Slot Token 0/WIM-test/id-ed25519-hsm-2/2".as_bytes())),
        Attribute::Private(false),
    ];

    // priv key template
    let priv_key_template = vec![
        Attribute::Sign(true),
        Attribute::Sensitive(true),
        Attribute::Extractable(true),
        Attribute::Token(true),
        Attribute::Label(Vec::from("TestEd25519".as_bytes())),
        // Attribute::Label(Vec::from("Slot Token 0/WIM-test/id-ed25519-hsm-2/2".as_bytes())),
    ];

    // generate a key pair
    let (public, private) =
        session.generate_key_pair(&mechanism, &pub_key_template, &priv_key_template)?;

    // data to sign
    let data = [0xFF, 0x55, 0xDD];

    // sign something with it
    let signature = session.sign(&Mechanism::Eddsa, private, &data)?;

    // verify the signature
    session.verify(&Mechanism::Eddsa, public, &data, &signature)?;

    // delete keys
    session.destroy_object(public)?;
    session.destroy_object(private)?;

    Ok(())
}

#[test]
#[serial]
// generate key pair, sign, verify and delete key pair.
fn sign_verify_secp256k1() -> Result<()> {
    // let (pkcs11, slot) = init_pins();
    let pkcs11 = get_pkcs11();
    let slot = get_slot(&pkcs11, TOKEN_LABEL)?;

    // open a session on slot
    let session = pkcs11.open_rw_session(slot)?;

    // log in the session
    session.login(UserType::User, Some(USER_PIN))?;

    // get mechanism
    let mechanism = Mechanism::EccKeyPairGen;

    // oid for secp256k1
    let oid: Vec<u8> = vec![0x06, 0x05, 0x2B, 0x81, 0x04, 0x00, 0x0A];

    // pub key template
    let pub_key_template = vec![
        Attribute::EcParams(oid),
        Attribute::Verify(true),
        Attribute::Token(true),
        Attribute::Label(Vec::from("TestSecp256k1".as_bytes())),
        // Attribute::Private(false),
    ];

    // priv key template
    let priv_key_template = vec![
        Attribute::Sign(true),
        Attribute::Sensitive(true),
        Attribute::Extractable(true),
        Attribute::Token(true),
        Attribute::Label(Vec::from("TestSecp256k1".as_bytes())),
    ];

    // generate a key pair
    let (public, private) =
        session.generate_key_pair(&mechanism, &pub_key_template, &priv_key_template)?;

    // data to sign
    let data = [0xFF, 0x55, 0xDD];

    // sign something with it
    let signature = session.sign(&Mechanism::Ecdsa, private, &data)?;

    // verify the signature
    session.verify(&Mechanism::Ecdsa, public, &data, &signature)?;

    // delete keys
    session.destroy_object(public)?;
    session.destroy_object(private)?;

    Ok(())
}

#[test]
#[serial]
// generate key pair, sign, verify and delete key pair.
fn sign_verify_rsa() -> Result<()> {
    // let (pkcs11, slot) = init_pins();
    let pkcs11 = get_pkcs11();
    let slot = get_slot(&pkcs11, TOKEN_LABEL)?;

    // open a session
    let session = pkcs11.open_rw_session(slot)?;

    // log in the session
    session.login(UserType::User, Some(USER_PIN))?;

    // get mechanism
    let mechanism = Mechanism::RsaPkcsKeyPairGen;

    let public_exponent: Vec<u8> = vec![0x01, 0x00, 0x01];
    let modulus_bits = 1024;

    // pub key template
    let pub_key_template = vec![
        Attribute::Token(true),
        Attribute::Private(false),
        Attribute::PublicExponent(public_exponent),
        Attribute::ModulusBits(modulus_bits.into()),
    ];

    // priv key template
    let priv_key_template = vec![Attribute::Token(true)];

    // generate a key pair
    let (public, private) =
        session.generate_key_pair(&mechanism, &pub_key_template, &priv_key_template)?;

    // data to sign
    let data = [0xFF, 0x55, 0xDD];

    // sign something with it
    let signature = session.sign(&Mechanism::RsaPkcs, private, &data)?;

    // verify the signature
    session.verify(&Mechanism::RsaPkcs, public, &data, &signature)?;

    // delete keys
    session.destroy_object(public)?;
    session.destroy_object(private)?;

    Ok(())
}

#[test]
#[serial]
fn encrypt_decrypt() -> Result<()> {
    // let (pkcs11, slot) = init_pins();
    let pkcs11 = get_pkcs11();
    let slot = get_slot(&pkcs11, TOKEN_LABEL)?;

    // open a session
    let session = pkcs11.open_rw_session(slot)?;

    // log in the session
    session.login(UserType::User, Some(USER_PIN))?;

    // get mechanism
    let mechanism = Mechanism::RsaPkcsKeyPairGen;

    let public_exponent: Vec<u8> = vec![0x01, 0x00, 0x01];
    let modulus_bits = 1024;

    // pub key template
    let pub_key_template = vec![
        Attribute::Token(true),
        Attribute::Private(false),
        Attribute::PublicExponent(public_exponent),
        Attribute::ModulusBits(modulus_bits.into()),
        Attribute::Encrypt(true),
    ];

    // priv key template
    let priv_key_template = vec![Attribute::Token(true), Attribute::Decrypt(true)];

    // generate a key pair
    let (public, private) =
        session.generate_key_pair(&mechanism, &pub_key_template, &priv_key_template)?;

    // data to encrypt
    let data = vec![0xFF, 0x55, 0xDD];

    // encrypt something with it
    let encrypted_data = session.encrypt(&Mechanism::RsaPkcs, public, &data)?;

    // decrypt
    let decrypted_data = session.decrypt(&Mechanism::RsaPkcs, private, &encrypted_data)?;

    // The decrypted buffer is bigger than the original one.
    assert_eq!(data, decrypted_data);

    // delete keys
    session.destroy_object(public)?;
    session.destroy_object(private)?;

    Ok(())
}

#[test]
#[serial]
fn derive_key() -> Result<()> {
    // let (pkcs11, slot) = init_pins();
    let pkcs11 = get_pkcs11();
    let slot = get_slot(&pkcs11, TOKEN_LABEL)?;

    // open a session
    let session = pkcs11.open_rw_session(slot)?;

    // log in the session
    session.login(UserType::User, Some(USER_PIN))?;

    // get mechanism
    let mechanism = Mechanism::EccKeyPairGen;

    let secp256r1_oid: Vec<u8> = vec![0x06, 0x08, 0x2A, 0x86, 0x48, 0xCE, 0x3D, 0x03, 0x01, 0x07];

    // pub key template
    let pub_key_template = vec![
        Attribute::Token(true),
        Attribute::Private(false),
        Attribute::Derive(true),
        Attribute::KeyType(KeyType::EC),
        Attribute::Verify(true),
        Attribute::EcParams(secp256r1_oid),
    ];

    // priv key template
    let priv_key_template = vec![
        Attribute::Token(true),
        Attribute::Private(true),
        Attribute::Sensitive(true),
        Attribute::Extractable(false),
        Attribute::Derive(true),
        Attribute::Sign(true),
    ];

    // generate a key pair
    let (public, private) =
        session.generate_key_pair(&mechanism, &pub_key_template, &priv_key_template)?;

    let ec_point_attribute = session
        .get_attributes(public, &[AttributeType::EcPoint])?
        .remove(0);

    let ec_point = if let Attribute::EcPoint(point) = ec_point_attribute {
        point
    } else {
        panic!("Expected EC point attribute.");
    };

    use cryptoki::mechanism::elliptic_curve::*;
    use std::convert::TryInto;

    let params = Ecdh1DeriveParams {
        kdf: EcKdfType::NULL,
        shared_data_len: 0_usize.try_into()?,
        shared_data: std::ptr::null(),
        public_data_len: (*ec_point).len().try_into()?,
        public_data: ec_point.as_ptr() as *const std::ffi::c_void,
    };

    let shared_secret = session.derive_key(
        &Mechanism::Ecdh1Derive(params),
        private,
        &[
            Attribute::Class(ObjectClass::SECRET_KEY),
            Attribute::KeyType(KeyType::GENERIC_SECRET),
            Attribute::Sensitive(false),
            Attribute::Extractable(true),
            Attribute::Token(false),
        ],
    )?;

    let value_attribute = session
        .get_attributes(shared_secret, &[AttributeType::Value])?
        .remove(0);
    let value = if let Attribute::Value(value) = value_attribute {
        value
    } else {
        panic!("Expected value attribute.");
    };

    assert_eq!(value.len(), 32);

    // delete keys
    session.destroy_object(public)?;
    session.destroy_object(private)?;

    Ok(())
}

#[test]
#[serial]
fn import_export() -> Result<()> {
    // let (pkcs11, slot) = init_pins();
    let pkcs11 = get_pkcs11();
    let slot = get_slot(&pkcs11, TOKEN_LABEL)?;

    // open a session
    let session = pkcs11.open_rw_session(slot)?;

    // log in the session
    session.login(UserType::User, Some(USER_PIN))?;

    let public_exponent: Vec<u8> = vec![0x01, 0x00, 0x01];
    let modulus = vec![0xFF; 1024];

    let template = vec![
        Attribute::Token(true),
        Attribute::Private(false),
        Attribute::PublicExponent(public_exponent),
        Attribute::Modulus(modulus.clone()),
        Attribute::Class(ObjectClass::PUBLIC_KEY),
        Attribute::KeyType(KeyType::RSA),
        Attribute::Verify(true),
    ];

    {
        // Intentionally forget the object handle to find it later
        let _public_key = session.create_object(&template)?;
    }

    let is_it_the_public_key = session.find_objects(&template)?.remove(0);

    let attribute_info = session
        .get_attribute_info(is_it_the_public_key, &[AttributeType::Modulus])?
        .remove(0);

    if let AttributeInfo::Available(size) = attribute_info {
        assert_eq!(size, 1024);
    } else {
        panic!("The Modulus attribute was expected to be present.")
    };

    let attr = session
        .get_attributes(is_it_the_public_key, &[AttributeType::Modulus])?
        .remove(0);

    if let Attribute::Modulus(modulus_cmp) = attr {
        assert_eq!(modulus[..], modulus_cmp[..]);
    } else {
        panic!("Expected the Modulus attribute.");
    }

    // delete key
    session.destroy_object(is_it_the_public_key)?;

    Ok(())
}

#[test]
#[serial]
fn get_token_info() -> Result<()> {
    // let (pkcs11, slot) = init_pins();
    let pkcs11 = get_pkcs11();
    let slot = get_slot(&pkcs11, TOKEN_LABEL)?;

    let info = pkcs11.get_token_info(slot)?;
    assert_eq!("SoftHSM project", info.manufacturer_id());

    Ok(())
}

#[test]
#[serial]
fn wrap_and_unwrap_key() -> Result<()> {
    // let (pkcs11, slot) = init_pins();
    let pkcs11 = get_pkcs11();
    let slot = get_slot(&pkcs11, TOKEN_LABEL).unwrap();

    // open a session
    let session = pkcs11.open_rw_session(slot).unwrap();

    // log in the session
    session.login(UserType::User, Some(USER_PIN)).unwrap();

    let key_to_be_wrapped_template = vec![
        Attribute::Token(true),
        // the key needs to be extractable to be suitable for being wrapped
        Attribute::Extractable(true),
        Attribute::Encrypt(true),
    ];

    // generate a secret key that will be wrapped
    let key_to_be_wrapped = session
        .generate_key(&Mechanism::Des3KeyGen, &key_to_be_wrapped_template)
        .unwrap();

    // Des3Ecb input length must be a multiple of 8
    // see: PKCS#11 spec Table 10-10, DES-ECB Key And Data Length Constraints
    let encrypted_with_original = session
        .encrypt(
            &Mechanism::Des3Ecb,
            key_to_be_wrapped,
            &[1, 2, 3, 4, 5, 6, 7, 8],
        )
        .unwrap();

    // pub key template
    let pub_key_template = vec![
        Attribute::Token(true),
        Attribute::Private(true),
        Attribute::PublicExponent(vec![0x01, 0x00, 0x01]),
        Attribute::ModulusBits(1024.into()),
        // key needs to have "wrap" attribute to wrap other keys
        Attribute::Wrap(true),
    ];

    // priv key template
    let priv_key_template = vec![Attribute::Token(true)];

    let (wrapping_key, unwrapping_key) = session
        .generate_key_pair(
            &Mechanism::RsaPkcsKeyPairGen,
            &pub_key_template,
            &priv_key_template,
        )
        .unwrap();

    let wrapped_key = session
        .wrap_key(&Mechanism::RsaPkcs, wrapping_key, key_to_be_wrapped)
        .unwrap();
    assert_eq!(wrapped_key.len(), 128);

    let unwrapped_key = session
        .unwrap_key(
            &Mechanism::RsaPkcs,
            unwrapping_key,
            &wrapped_key,
            &[
                Attribute::Token(true),
                Attribute::Private(true),
                Attribute::Encrypt(true),
                Attribute::Class(ObjectClass::SECRET_KEY),
                Attribute::KeyType(KeyType::DES3),
            ],
        )
        .unwrap();

    let encrypted_with_unwrapped = session
        .encrypt(
            &Mechanism::Des3Ecb,
            unwrapped_key,
            &[1, 2, 3, 4, 5, 6, 7, 8],
        )
        .unwrap();
    assert_eq!(encrypted_with_original, encrypted_with_unwrapped);

    session.destroy_object(key_to_be_wrapped)?;
    session.destroy_object(wrapping_key)?;
    session.destroy_object(unwrapping_key)?;
    session.destroy_object(unwrapped_key)?;

    Ok(())
}

#[test]
#[serial]
fn login_feast() {
    const SESSIONS: usize = 100;

    // let (pkcs11, slot) = init_pins();
    let pkcs11 = get_pkcs11();
    let slot = get_slot(&pkcs11, TOKEN_LABEL).unwrap();

    let mut threads = Vec::new();

    for _ in 0..SESSIONS {
        let pkcs11 = pkcs11.clone();
        threads.push(thread::spawn(move || {
            let session = pkcs11.open_rw_session(slot).unwrap();
            match session.login(UserType::User, Some(USER_PIN)) {
                Ok(_) | Err(Error::Pkcs11(RvError::UserAlreadyLoggedIn)) => {}
                Err(e) => panic!("Bad error response: {}", e),
            }
            match session.login(UserType::User, Some(USER_PIN)) {
                Ok(_) | Err(Error::Pkcs11(RvError::UserAlreadyLoggedIn)) => {}
                Err(e) => panic!("Bad error response: {}", e),
            }
            match session.login(UserType::User, Some(USER_PIN)) {
                Ok(_) | Err(Error::Pkcs11(RvError::UserAlreadyLoggedIn)) => {}
                Err(e) => panic!("Bad error response: {}", e),
            }
            match session.logout() {
                Ok(_) | Err(Error::Pkcs11(RvError::UserNotLoggedIn)) => {}
                Err(e) => panic!("Bad error response: {}", e),
            }
            match session.logout() {
                Ok(_) | Err(Error::Pkcs11(RvError::UserNotLoggedIn)) => {}
                Err(e) => panic!("Bad error response: {}", e),
            }
            match session.logout() {
                Ok(_) | Err(Error::Pkcs11(RvError::UserNotLoggedIn)) => {}
                Err(e) => panic!("Bad error response: {}", e),
            }
        }));
    }

    for thread in threads {
        thread.join().unwrap();
    }
}

#[test]
#[serial]
fn get_info_test() -> Result<()> {
    // let (pkcs11, _) = init_pins();
    let pkcs11 = get_pkcs11();

    let info = pkcs11.get_library_info()?;

    assert_eq!(info.cryptoki_version().major(), 2);
    assert_eq!(info.cryptoki_version().minor(), 40);
    assert_eq!(info.manufacturer_id(), String::from("SoftHSM"));
    Ok(())
}

#[test]
#[serial]
fn get_slot_info_test() -> Result<()> {
    // let (pkcs11, slot) = init_pins();
    let pkcs11 = get_pkcs11();
    let slot = get_slot(&pkcs11, TOKEN_LABEL).unwrap();

    let slot_info = pkcs11.get_slot_info(slot)?;
    assert!(slot_info.token_present());
    assert!(!slot_info.hardware_slot());
    assert!(!slot_info.removable_device());
    assert_eq!(slot_info.manufacturer_id(), String::from("SoftHSM project"));
    Ok(())
}

#[test]
#[serial]
fn get_session_info_test() -> Result<()> {
    // let (pkcs11, slot) = init_pins();
    let pkcs11 = get_pkcs11();
    let slot = get_slot(&pkcs11, TOKEN_LABEL).unwrap();

    {
        let session = pkcs11.open_ro_session(slot)?;
        let session_info = session.get_session_info()?;
        assert!(!session_info.read_write());
        assert_eq!(session_info.slot_id(), slot);
        assert!(matches!(
            session_info.session_state(),
            SessionState::RoPublic
        ));

        session.login(UserType::User, Some(USER_PIN))?;
        let session_info = session.get_session_info()?;
        assert!(!session_info.read_write());
        assert_eq!(session_info.slot_id(), slot);
        assert!(matches!(session_info.session_state(), SessionState::RoUser));
        session.logout()?;
        if let Err(cryptoki::error::Error::Pkcs11(rv_error)) =
            session.login(UserType::So, Some(SO_PIN))
        {
            assert_eq!(rv_error, RvError::SessionReadOnlyExists)
        } else {
            panic!("Should error when attempting to log in as CKU_SO on a read-only session");
        }
    }

    let session = pkcs11.open_rw_session(slot)?;
    let session_info = session.get_session_info()?;
    assert!(session_info.read_write());
    assert_eq!(session_info.slot_id(), slot);
    assert!(matches!(
        session_info.session_state(),
        SessionState::RwPublic
    ));

    session.login(UserType::User, Some(USER_PIN))?;
    let session_info = session.get_session_info()?;
    assert!(session_info.read_write());
    assert_eq!(session_info.slot_id(), slot);
    assert!(matches!(session_info.session_state(), SessionState::RwUser,));
    session.logout()?;
    session.login(UserType::So, Some(SO_PIN))?;
    let session_info = session.get_session_info()?;
    assert!(session_info.read_write());
    assert_eq!(session_info.slot_id(), slot);
    assert!(matches!(
        session_info.session_state(),
        SessionState::RwSecurityOfficer
    ));

    Ok(())
}

#[test]
#[serial]
fn generate_random_test() -> Result<()> {
    // let (pkcs11, slot) = init_pins();
    let pkcs11 = get_pkcs11();
    let slot = get_slot(&pkcs11, TOKEN_LABEL).unwrap();

    let session = pkcs11.open_ro_session(slot)?;

    let poor_seed: [u8; 32] = [0; 32];
    session.seed_random(&poor_seed)?;

    let mut random_data: [u8; 32] = [0; 32];
    session.generate_random_slice(&mut random_data)?;

    // This of course assumes the RBG in the the SoftHSM is not terrible
    assert!(!random_data.iter().all(|&x| x == 0));

    let random_vec = session.generate_random_vec(32)?;
    assert_eq!(random_vec.len(), 32);

    assert!(!random_vec.iter().all(|&x| x == 0));
    Ok(())
}

#[test]
#[serial]
fn set_pin_test() -> Result<()> {
    let new_user_pin = "123456";
    // let (pkcs11, slot) = init_pins();
    let pkcs11 = get_pkcs11();
    let slot = get_slot(&pkcs11, TOKEN_LABEL).unwrap();

    let session = pkcs11.open_rw_session(slot)?;

    session.login(UserType::User, Some(USER_PIN))?;
    session.set_pin(USER_PIN, new_user_pin)?;
    session.logout()?;
    session.login(UserType::User, Some(new_user_pin))?;

    // revert
    session.set_pin(new_user_pin, USER_PIN)?;

    Ok(())
}

#[test]
#[serial]
fn get_attribute_info_test() -> Result<()> {
    // let (pkcs11, slot) = init_pins();
    let pkcs11 = get_pkcs11();
    let slot = get_slot(&pkcs11, TOKEN_LABEL).unwrap();

    // open a session
    let session = pkcs11.open_rw_session(slot)?;

    // log in the session
    session.login(UserType::User, Some(USER_PIN))?;

    // get mechanism
    let mechanism = Mechanism::RsaPkcsKeyPairGen;

    let public_exponent: Vec<u8> = vec![0x01, 0x00, 0x01];
    let modulus_bits = 2048;

    // pub key template
    let pub_key_template = vec![
        Attribute::Token(false),
        Attribute::Private(false),
        Attribute::PublicExponent(public_exponent),
        Attribute::ModulusBits(modulus_bits.into()),
    ];

    // priv key template
    let priv_key_template = vec![
        Attribute::Token(false),
        Attribute::Sensitive(true),
        Attribute::Extractable(false),
    ];

    // generate a key pair
    let (public, private) =
        session.generate_key_pair(&mechanism, &pub_key_template, &priv_key_template)?;

    let pub_attribs = vec![AttributeType::PublicExponent, AttributeType::Modulus];
    let mut priv_attribs = pub_attribs.clone();
    priv_attribs.push(AttributeType::PrivateExponent);

    let attrib_info = session.get_attribute_info(public, &pub_attribs)?;
    let hash = pub_attribs
        .iter()
        .zip(attrib_info.iter())
        .collect::<HashMap<_, _>>();

    if let AttributeInfo::Available(size) = hash[&AttributeType::Modulus] {
        assert_eq!(*size, 2048 / 8);
    } else {
        panic!("Modulus should not return Unavailable for an RSA public key");
    }

    match hash[&AttributeType::PublicExponent] {
        AttributeInfo::Available(_) => {}
        _ => panic!("Public Exponent should not return Unavailable for an RSA public key"),
    }

    let attrib_info = session.get_attribute_info(private, &priv_attribs)?;
    let hash = priv_attribs
        .iter()
        .zip(attrib_info.iter())
        .collect::<HashMap<_, _>>();

    if let AttributeInfo::Available(size) = hash[&AttributeType::Modulus] {
        assert_eq!(*size, 2048 / 8);
    } else {
        panic!("Modulus should not return Unavailable on an RSA private key");
    }

    match hash[&AttributeType::PublicExponent] {
        AttributeInfo::Available(_) => {}
        _ => panic!("PublicExponent should not return Unavailable on an RSA private key"),
    }

    match hash[&AttributeType::PrivateExponent] {
        AttributeInfo::Sensitive => {}
        _ => panic!("Private Exponent of RSA private key should be sensitive"),
    }

    let hash = session.get_attribute_info_map(private, priv_attribs)?;
    if let AttributeInfo::Available(size) = hash[&AttributeType::Modulus] {
        assert_eq!(size, 2048 / 8);
    } else {
        panic!("Modulus should not return Unavailable on an RSA private key");
    }

    match hash[&AttributeType::PublicExponent] {
        AttributeInfo::Available(_) => {}
        _ => panic!("Public Exponent should not return Unavailable for an RSA private key"),
    }

    match hash[&AttributeType::PrivateExponent] {
        AttributeInfo::Sensitive => {}
        _ => panic!("Private Exponent of RSA private key should be sensitive"),
    }

    Ok(())
}

#[test]
#[serial]
fn aes_key_attributes_test() -> Result<()> {
    // let (pkcs11, slot) = init_pins();
    let pkcs11 = get_pkcs11();
    let slot = get_slot(&pkcs11, TOKEN_LABEL).unwrap();

    // open a session
    let session = pkcs11.open_rw_session(slot)?;

    // log in the session
    session.login(UserType::User, Some(USER_PIN))?;

    // get mechanism
    let mechanism = Mechanism::AesKeyGen;

    // pub key template
    let key_template = vec![
        Attribute::Class(ObjectClass::SECRET_KEY),
        Attribute::Token(true),
        Attribute::Sensitive(true),
        Attribute::ValueLen(16.into()),
        Attribute::KeyType(KeyType::AES),
        Attribute::Label(b"testAES".to_vec()),
        Attribute::Private(true),
    ];

    // generate a key pair
    let key = session.generate_key(&mechanism, &key_template)?;

    let mut attributes_result =
        session.get_attributes(key, &[AttributeType::EndDate, AttributeType::StartDate])?;

    if let Some(Attribute::StartDate(date)) = attributes_result.pop() {
        assert!(date.is_empty());
    } else {
        panic!("Last attribute was not a start date");
    }

    if let Some(Attribute::EndDate(date)) = attributes_result.pop() {
        assert!(date.is_empty());
    } else {
        panic!("First attribute was not an end date");
    }

    session.destroy_object(key)?;

    Ok(())
}

*/