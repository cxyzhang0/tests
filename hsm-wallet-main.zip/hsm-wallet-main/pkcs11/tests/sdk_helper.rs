mod common;

use pkcs11::{Result, CryptographAlgorithm, KeyLabel};

#[ignore]
#[test]
fn test_key_label() -> Result<()> {
    let pf = "Slot Token 0";
    let mut key_label = KeyLabel {
        prefix: pf.to_string(),
        key_ring: "WIM-test".to_string(),
        key: "id-ed25519-hsm-2".to_string(),
        version: 1,
        algorithm: CryptographAlgorithm::Ed25519,
    };
    let label = key_label.label();
    let short_label = key_label.short_label();
    assert_eq!(
        label, "Slot Token 0/keyRings/WIM-test/cryptoKeys/id-ed25519-hsm-2/cryptoKeyVersions/1",
        "labels are not equal"
    );
    assert_eq!(
        short_label, "Slot Token 0/WIM-test/id-ed25519-hsm-2/1",
        "short labels are not equal"
    );

    let kl = KeyLabel::from(&label, CryptographAlgorithm::Ed25519)?;
    assert_eq!(key_label, kl, "key labels are not equal");

    let skl = KeyLabel::from_short(&short_label, CryptographAlgorithm::Ed25519)?;
    assert_eq!(key_label, skl, "key labels are not equal");

    key_label.next();
    let next_short_label = key_label.short_string();
    assert_eq!(
        key_label.string(),
        "Slot Token 0/keyRings/WIM-test/cryptoKeys/id-ed25519-hsm-2/cryptoKeyVersions/2",
        "next labels are not equal"
    );
    assert_eq!(
        next_short_label, "Slot Token 0/WIM-test/id-ed25519-hsm-2/2",
        "next short labels are not equal"
    );

    Ok(())
}


