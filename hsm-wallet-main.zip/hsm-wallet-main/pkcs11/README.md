## pkcs11 
* This crate includes the SDK to interface with HSM for key management
> Supported algorithms
> * ed25519 (Solana, Algorand, Cardano)
> * secp256k1 (Bitcoin, Ethereum)
> * secp256r1 (Corda)
> * rsa2048

* Tests to showcase the functionality
> ./tests are integration tests. To avoid cargo test running them by default, annotate them with #[ignore].
> * cargo test -p pkcs11 -- --ignored # run only ignored tests
> * cargo test -p pkcs11 --test sdk -- --ignored # run only ignored tests in tests/sdk.rs
> * cargo test -p pkcs11 --test sdk_helper -- --ignored # run only ignored tests in tests/sdk_helper.sr
> * cargo test -p pkcs11  it_sign_verify_sig_ed25519_outside_hsm -- --ignored --exact # run a specific test
> * cargo test -p pkcs11  it_sign_verify_secp256r1 -- --ignored --exact # run a specific test
> * cargo test -p pkcs11  it_test_encrypt_decrypt -- --ignored --exact # run a specific test
> * cargo test -p pkcs11 -- --include-ignored # run all, including ignored

### Prerequisites and dependencies
* Rust PKCS11 3.0 wrapper
> https://github.com/legounix/rust-cryptoki/tree/fix_mechanis_eddsa
> Note: The official cryptoki 0.4.1 in crates.io only supports PKCS11 2.4 which does not have eddsa. There is a PR for it.
* SOFTHSM 2.6.1 for testing
> download softhsm-2.6.1.tar.gz at https://dist.opendnssec.org/source/, unzip and install per README there.  
> Initialization
```
softhsm2-util --init-token --slot 0 --label "Slot Token 0" 
or 
test_init_pins() in pcsc11/tests.basic.rs (commented out)
```

* Or FutureX HSM for testing

### Open Issues
- Thread safety. PKCS11 SDK may not be thread safe.  
Session only implements Send and explicitly prohibits implementing Sync for sharing across threads. They may have their reason for that.  
SDK implements both Send and Sync to satisfy the requirement of clients, especially TMKMS.

