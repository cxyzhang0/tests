use anyhow::Error as AnyHowError;
use cryptoki::error::Error as P11HsmError;
use std::env::VarError;
use std::fmt::Display;
use std::sync::PoisonError;
use signature::Error as SignatureError;
use elliptic_curve::Error as CurveError;

// TODO: use anyhow::Error instead of ErrorWithStacktrace
//  to be consistent with SL and our other crates.
// #[derive(Debug)]
// pub struct ErrorWithStacktrace;

// impl<T: std::error::Error> From<T> for ErrorWithStacktrace {
//     fn from(p: T) -> Self {
//         panic!("Error: {:#?}", p);
//     }
// }
//
// pub type Result<T> = std::result::Result<T, ErrorWithStacktrace>;


#[derive(Debug)]
pub enum Error {
    InvalidConfig(&'static str),
    AlgorithmNotSupported,
    NotAuthorized,
    TokenNotFound,
    TokenNotSet,
    P11(P11HsmError),
    VarError(VarError),
    Signature(SignatureError),
    Curve(CurveError),
    GenericError(String),
}

impl Display for Error {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Error::InvalidConfig(e) => write!(f, "Invalid Config: {e}"),
            Error::AlgorithmNotSupported => write!(f, "Algorithm Not Supported"),
            Error::NotAuthorized => write!(f, "Session Not Authorized"),
            Error::TokenNotFound => write!(f, "Token Not Found"),
            Error::TokenNotSet => write!(f, "Token Not Set"),
            Error::P11(e) => write!(f, "PKCS11 Error: {e}"),
            Error::VarError(e) => write!(f, "Env Var Error: {e}"),
            Error::Signature(e) => write!(f, "Signature Error: {e}"),
            Error::Curve(e) => write!(f, "Elliptic curve Error: {e}"),
            Error::GenericError(e) => write!(f, "Generic Error: {e}"),
        }
    }
}

impl std::error::Error for Error {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Error::P11(e) => Some(e),
            Error::VarError(e) => Some(e),
            Error::Signature(e) => Some(e),
            _ => None,
        }
    }
}

impl From<AnyHowError> for Error {
    fn from(e: AnyHowError) -> Self {
        Error::GenericError(format!("Converted anyhow error: {e}"))
    }
}

impl <T> From<PoisonError<T>> for Error {
    fn from(e: PoisonError<T>) -> Self {
        Error::GenericError(format!("PoisonError: {e}"))
    }
}

impl From<P11HsmError> for Error {
    fn from(e: P11HsmError) -> Self {
        Error::P11(e)
    }
}

impl From<VarError> for Error {
    fn from(e: VarError) -> Self {
        Error::VarError(e)
    }
}

impl From<SignatureError> for Error {
    fn from(e: SignatureError) -> Self {
        Error::Signature(e)
    }
}

impl From<CurveError> for Error {
    fn from(e: CurveError) -> Self {
        Error::Curve(e)
    }
}
pub type Result<T> = anyhow::Result<T, Error>;