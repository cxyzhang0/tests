use std::array::TryFromSliceError;
use crate::helper::*;
use crate::error::{Error, Result};
use cryptoki::context::{CInitializeArgs, Pkcs11};
use cryptoki::slot::Slot;
use cryptoki::{
    mechanism::Mechanism,
    object::{Attribute, AttributeType, KeyType, ObjectClass, ObjectHandle},
    session::Session,
};
use elliptic_curve::generic_array::ArrayLength;
use elliptic_curve::sec1::{FromEncodedPoint, ModulusSize, ToEncodedPoint};
use elliptic_curve::{AffinePoint, CurveArithmetic, FieldBytesSize, PublicKey};
use ecdsa::hazmat::{DigestPrimitive, VerifyPrimitive};
use ecdsa::signature::hazmat::PrehashVerifier;
use ecdsa::{PrimeCurve, Signature as EcSignature, SignatureSize, VerifyingKey as EcVerifyingKey};
use ed25519_dalek::{Signature as EdSignature, Verifier, VerifyingKey as EdVerifyingKey};
use k256::Secp256k1;
use p256::NistP256;
use lazy_static::lazy_static;
// include!("helper.rs"); // with include!, sdk does not have access to helper objects
use std::borrow::Borrow;
use once_cell::sync::OnceCell;
use std::collections::HashMap;
use std::env;
use std::sync::{Mutex, Once};
use cryptoki::mechanism::{MechanismInfo, MechanismType};
use cryptoki::session::UserType;
use cryptoki::types::AuthPin;
use pkcs8::ObjectIdentifier;
use der::Decode;
use tracing::info;

/// SDKContext is a wrapper around Pkcs11 and Slot.
// slot is optional because we want to make sure p11 can be created first.
// then we can set slot next.
#[derive(Debug, Clone)]
pub struct SDKContext {
    p11: Pkcs11,
    slot: Option<Slot>,
}

#[derive(Debug)]
pub struct SDK {
    // pub p: SDKPkcs11, // session has Pkcs11
    // pub s: Slot,
    session: Session,
}

// A: Session only implements Send, not Sync. Should SDK implement Sync?
// Q: The consumer of SDK should protect it with Arc<Mutex<SDK>> if it needs to be shared between threads.
//  see tmkms or wfdc2 for example.
unsafe impl Sync for SDK {}
unsafe impl Send for SDK {}

// _sdk is not used explicitly but holds a logged-in open PKCS11 session when
// wrapped inside the static INIT_CELL.
// that enables future open sessions on ctx to be automatically logged in.
struct Init {
    ctx: SDKContext,
    _sdk: Mutex<SDK>,
}

static INIT_CALL: Once = Once::new();

static INIT_CELL: OnceCell<Init> = OnceCell::new();

impl SDKContext {
    // without slot
    pub fn new(p11: Pkcs11) -> Self {
        Self { p11, slot: None }
    }

    pub fn new_with_slot(p11: Pkcs11, slot: Slot) -> Self {
        let mut ctx = Self::new(p11);
        ctx.set_slot(slot);
        ctx
    }

    pub fn from_pkcs11_label(p11: Pkcs11, token_label: &str) -> Result<Self> {
        let mut ctx = Self::new(p11);
        
        ctx.set_slot_by_label(token_label)?;
        
        Ok(ctx)
    }
    
    pub fn set_slot(&mut self, slot: Slot) {
        self.slot = Some(slot);
    }
    
    pub fn set_slot_by_id(&mut self, slot_id: u64) -> Result<()> {
        let slot = self.find_slot_by_id(slot_id)?;
        
        self.set_slot(slot);
        
        Ok(())
    }
    
    pub fn set_slot_by_label(&mut self, token_label: &str) -> Result<()> {
        let slot = self.find_slot_by_label(token_label)?;
        
        self.set_slot(slot);
        
        Ok(())
    }
    
    pub fn p11(&self) -> &Pkcs11 {
        &self.p11
    }
    
    pub fn slot(&self) -> Option<Slot> {
        self.slot
    }
    
    pub fn find_slot_by_id(&self, slot_id: u64) -> Result<Slot> {
        let slots = self.p11.get_slots_with_initialized_token()?;
        
        let id = slots.iter().position(|s| s.id() == slot_id).ok_or(Error::TokenNotFound)?;
        
        Ok(slots[id])
    }
    
    pub fn find_slot_by_label(&self, token_label: &str) -> Result<Slot> {
        let slots = self.p11.get_slots_with_initialized_token()?;
        
        for slot in slots {
            let info = self.p11.get_token_info(slot)?;
            if info.label() == token_label {
                return Ok(slot);
            }
        }
        
        Err(Error::TokenNotFound)
    }

    pub fn open_rw_session(&self) -> Result<Session> {
        let slot = self.slot.ok_or(Error::TokenNotSet)?;
        
        let session = self.p11.open_rw_session(slot)?;
        
        Ok(session)
    }
    
    pub fn get_mechanism_list(&self) -> Result<Vec<MechanismType>> {
        let slot = self.slot.ok_or(Error::TokenNotSet)?;
        
        Ok(self.p11.get_mechanism_list(slot)?)
    }

    pub fn get_mechanism_info(&self, _type: MechanismType) -> Result<MechanismInfo> {
        let slot = self.slot.ok_or(Error::TokenNotSet)?;

        Ok(self.p11.get_mechanism_info(slot, _type)?)
    }
    
    pub fn create_pkcs11(env_module: Option<&str>, module: Option<&str>) -> Result<Pkcs11> {
        let m = if let Some(m) = module {
            m
        } else if let Some(env_module) = env_module {
            &env::var(env_module)?
        } else {
            return Err(Error::InvalidConfig("No module or env_module provided"));
        };
        
        let p11 = Pkcs11::new(m)?;

        p11.initialize(CInitializeArgs::OsThreads)?;

        Ok(p11)
    }
}

#[derive(Copy, Debug, Clone, PartialEq, Eq, Hash)]
pub enum CryptographAlgorithm {
    Secp256k1,
    Ed25519,
    Secp256r1,
    RSA2048,
    AES,
}

impl From<String> for CryptographAlgorithm {
    fn from(s: String) -> Self {
        match s.as_str() {
            "secp256k1" => CryptographAlgorithm::Secp256k1,
            "ed25519" => CryptographAlgorithm::Ed25519,
            "secp256r1" => CryptographAlgorithm::Secp256r1,
            "rsa2048" => CryptographAlgorithm::RSA2048,
            _ => CryptographAlgorithm::Secp256k1,
        }
    }
}

pub const OID_SECP256K1: [u8; 7] = [0x06, 0x05, 0x2B, 0x81, 0x04, 0x00, 0x0A];

// this fails FX: oid for ed25519 per https://github.com/opendnssec/SoftHSMv2/blob/ac70dc398b236e4522101930e790008936489e2d/src/lib/test/SignVerifyTests.cpp#L173
// pub const OID_ED25519: [u8; 14] = [0x13, 0x0c, 0x65, 0x64, 0x77, 0x61, 0x72, 0x64, 0x73, 0x32, 0x35, 0x35, 0x31, 0x39,];
// this works for both FX and SoftHSM2
pub const OID_ED25519: [u8; 5] = [0x06, 0x03, 0x2B, 0x65, 0x70];
pub const OID_SECP256R1: [u8; 10] = [0x06, 0x08, 0x2A, 0x86, 0x48, 0xCE, 0x3D, 0x03, 0x01, 0x07];
pub const RSA_PUBLIC_EXPONENT: [u8; 3] = [0x01, 0x00, 0x01];
pub const RSA_MODULUS_BITS: std::os::raw::c_ulong = 2048;

lazy_static! {
static ref SUPPORTED_ALGORITHMS: HashMap<CryptographAlgorithm, (Vec<Attribute>, Vec<Attribute>)> = HashMap::from([
    (CryptographAlgorithm::Secp256k1,
     (vec![
         Attribute::EcParams(Vec::from(OID_SECP256K1)),
         Attribute::Verify(true),
        ],
        vec![
            Attribute::Sign(true),
            Attribute::Sensitive(true),
            Attribute::Extractable(true),
        ]
     ),
    ),
    (CryptographAlgorithm::Ed25519,
     (vec![
         Attribute::EcParams(Vec::from(OID_ED25519)),
         Attribute::Verify(true),
         // Attribute::Token(persistent),
         // Attribute::Label(Vec::from("TestEd25519".as_bytes())),
         // Attribute::Label(Vec::from("Slot Token 0/WIM-test/id-ed25519-hsm-2/3".as_bytes())),
         // Attribute::Private(false),
     ],
      vec![
          Attribute::Sign(true),
          Attribute::Sensitive(true),
          Attribute::Extractable(true),
          // Attribute::Token(persistent),
          // Attribute::Label(Vec::from("TestEd25519".as_bytes())),
          // Attribute::Label(Vec::from("Slot Token 0/WIM-test/id-ed25519-hsm-2/3".as_bytes())),

      ]
     ),
    ),
    (CryptographAlgorithm::Secp256r1,
     (vec![
         Attribute::EcParams(Vec::from(OID_SECP256R1)),
         Attribute::Verify(true),
     ],
      vec![
          Attribute::Sign(true),
          Attribute::Sensitive(true),
          Attribute::Extractable(true),
      ]
     ),
    ),
    (CryptographAlgorithm::RSA2048,
     (vec![
         Attribute::Class(ObjectClass::PUBLIC_KEY),
         Attribute::KeyType(KeyType::RSA),
         Attribute::PublicExponent(Vec::from(RSA_PUBLIC_EXPONENT)),
         Attribute::ModulusBits(RSA_MODULUS_BITS.into()),
         Attribute::Verify(true),
     ],
      vec![
          Attribute::Sign(true),
          Attribute::Sensitive(true),
          Attribute::Extractable(true),
      ]
     ),
    ),
]);
}

/// Return supported algorithms and their base public and private key attributes
/// Note: This is replaced by the SUPPORTED_ALGORITHMS above
#[deprecated(
since = "0.1.0",
note = "Please use SUPPORTED_ALGORITHMS instead"
)]
pub fn supported_algorithms() -> HashMap<CryptographAlgorithm, (Vec<Attribute>, Vec<Attribute>)> {
    let m: HashMap<CryptographAlgorithm, (Vec<Attribute>, Vec<Attribute>)> = HashMap::from([
        (
            CryptographAlgorithm::Secp256k1,
            (
                vec![
                    Attribute::EcParams(Vec::from(OID_SECP256K1)),
                    Attribute::Verify(true),
                ],
                vec![
                    Attribute::Sign(true),
                    Attribute::Sensitive(true),
                    Attribute::Extractable(true),
                ],
            ),
        ),
        (
            CryptographAlgorithm::Ed25519,
            (
                vec![
                    Attribute::EcParams(Vec::from(OID_ED25519)),
                    Attribute::Verify(true),
                    // Attribute::Token(persistent),
                    // Attribute::Label(Vec::from("TestEd25519".as_bytes())),
                    // Attribute::Label(Vec::from("Slot Token 0/WIM-test/id-ed25519-hsm-2/3".as_bytes())),
                    // Attribute::Private(false),
                ],
                vec![
                    Attribute::Sign(true),
                    Attribute::Sensitive(true),
                    Attribute::Extractable(true),
                    // Attribute::Token(persistent),
                    // Attribute::Label(Vec::from("TestEd25519".as_bytes())),
                    // Attribute::Label(Vec::from("Slot Token 0/WIM-test/id-ed25519-hsm-2/3".as_bytes())),
                ],
            ),
        ),
        (
            CryptographAlgorithm::Secp256r1,
            (
                vec![
                    Attribute::EcParams(Vec::from(OID_SECP256R1)),
                    Attribute::Verify(true),
                ],
                vec![
                    Attribute::Sign(true),
                    Attribute::Sensitive(true),
                    Attribute::Extractable(true),
                ],
            ),
        ),
        (
            CryptographAlgorithm::RSA2048,
            (
                vec![
                    Attribute::Class(ObjectClass::PUBLIC_KEY),
                    Attribute::KeyType(KeyType::RSA),
                    Attribute::PublicExponent(Vec::from(RSA_PUBLIC_EXPONENT)),
                    Attribute::ModulusBits(RSA_MODULUS_BITS.into()),
                    Attribute::Verify(true),
                ],
                vec![
                    Attribute::Sign(true),
                    Attribute::Sensitive(true),
                    Attribute::Extractable(true),
                ],
            ),
        ),
    ]);
    m
}

impl SDK {
    /// Create a new SDK instance, fully logged in.
    // Note: it seems to do a lot of work from low level inputs. 
    //   a better API would be to take higher level inputs such as SDKPkcs11 and slot.
    //   in that spirit, it recommended to use from_context_with_login(...), or from_context(...) and login(...)
    //
    pub fn new(env_module: Option<&str>, module: Option<&str>, token_label: &str, pin: &str) -> Result<Self> {
        let p11 = SDKContext::create_pkcs11(env_module, module)?;
        
        let mut ctx = SDKContext::new(p11);
        
        ctx.set_slot_by_label(token_label)?;
        
        let mut sdk = Self::from_context(&ctx)?;
        
        sdk.login(pin)?;
        
        Ok(sdk)
    }

    /// Return a new SDK with fully logged-in session.
    pub fn from_context_with_login(ctx: &SDKContext, pin: &str) -> Result<Self> {
        let mut sdk = Self::from_context(ctx)?;
        
        sdk.login(pin)?;
        
        Ok(sdk)
    }
    
    /// SDK without login.
    pub fn from_context(ctx: &SDKContext) -> Result<Self> {
        let session = ctx.open_rw_session()?;
        
        Ok(Self { session })
    }
    
    /// login to the session, to be used after from_context(...).
    pub fn login(&mut self, pin: &str) -> Result<()> {
        if !self.is_authorized() {
            self.session.login(UserType::User, Some(&AuthPin::new(pin.into())))?;
        }
        
        Ok(())
    }      
    
    /// Check if the session is authorized.
    pub fn is_authorized(&self) -> bool {
        if let Ok(info) = self.session.get_session_info() {
            // We require Read/Write User session because the session may be used to create keys.
            info.session_state() == cryptoki::session::SessionState::RwUser
        } else {
            false
        }
    }
    
    /// Return reference to the session which is private.
    pub fn session(&self) -> &Session {
        &self.session
    }
    
    /// Close the session
    pub fn close(self) -> Result<()> {
        self.session.logout()?;
        self.session.close();
        Ok(())
    }

    /// Generate a key pair
    pub fn keygen(
        &self,
        key_label: &mut KeyLabel,
        persistent: bool,
    ) -> Result<(ObjectHandle, ObjectHandle, KeyLabel)> {
        if !self.is_authorized() {
            return Err(Error::NotAuthorized)
        }

        // DO NOT OVERWRITE EXISTING KEYS
        // find key_label with the version that does not exist
        loop {
            if !self.exist_key_handle(key_label, true) && !self.exist_key_handle(key_label, false) {
                break;
            }
            key_label.next();
        }

        // let algos = supported_algorithms();
        let algo = SUPPORTED_ALGORITHMS.get(&key_label.algorithm).ok_or(Error::AlgorithmNotSupported)?;
        let pub_key_template = &mut (algo.0).clone();
        pub_key_template.append(&mut vec![
            Attribute::Token(persistent),
            Attribute::Label(Vec::from(key_label.short_label().as_bytes())),
        ]);
        let private_key_template = &mut (algo.1).clone();
        private_key_template.append(&mut vec![
            Attribute::Token(persistent),
            Attribute::Label(Vec::from(key_label.short_label().as_bytes())),
        ]);
        let mechanism = match key_label.algorithm {
            CryptographAlgorithm::RSA2048 => Mechanism::RsaPkcsKeyPairGen,
            CryptographAlgorithm::Ed25519 => Mechanism::EccEdwardsKeyPairGen,
            _ => Mechanism::EccKeyPairGen,
        };

        Ok(self.session
            .generate_key_pair(&mechanism, pub_key_template, private_key_template)
            .map(|(public, private)| (public, private, key_label.clone()))?
        )
    }
    
    /// raw sign by HSM
    pub fn sign(&self, key_label: &KeyLabel, data: &[u8]) -> Result<Vec<u8>> {
        if !self.is_authorized() {
            return Err(Error::NotAuthorized)
        }

        let mechanism = match key_label.algorithm {
            CryptographAlgorithm::RSA2048 => Mechanism::RsaPkcs,
            CryptographAlgorithm::Ed25519 => Mechanism::Eddsa,
            _ => Mechanism::Ecdsa,
        };

        let private = self.get_key_handle(key_label, false)?;

        Ok(self.session.sign(&mechanism, private, data)?)
    }

    /// EDDSA sign
    pub fn sign_eddsa(&self, key_label: &KeyLabel, data: &[u8]) -> Result<EdSignature> {
        Self::check_algo(key_label.algorithm, &[CryptographAlgorithm::Ed25519])?;
        
        let sig = self.sign(key_label, data)?;

        Ok(EdSignature::try_from(sig.as_slice())?)
    }

    /// Return normalized ECDSA signature
    /// Note: Cosmos expects this sign fn to secure_hash the passed in data and then sign
    pub fn sign_ecdsa<C>(&self, key_label: &KeyLabel, data: &[u8]) -> Result<EcSignature<C>>
        where
            C: PrimeCurve + CurveArithmetic,
            // Scalar<C>: Invert<Output = CtOption<Scalar<C>>> + SignPrimitive<C>,
            SignatureSize<C>: ArrayLength<u8>,
            AffinePoint<C>: FromEncodedPoint<C> + ToEncodedPoint<C> + VerifyPrimitive<C>,
            FieldBytesSize<C>: ModulusSize,
    {
        Self::check_algo(key_label.algorithm, &[CryptographAlgorithm::Secp256k1, CryptographAlgorithm::Secp256r1])?;

        let hash = secure_hash(data);
        let sig = self.sign(key_label, &hash[..])?;
        let sig = EcSignature::<C>::from_slice(&sig)?;

        // Normalize to low-s to avoid malleability
        let sig = if let Some(sig) = sig.normalize_s() {
            sig
        } else {
            sig
        };
        Ok(sig)
    }

    /// Verify signature by HSM
    pub fn verify_sig(&self, key_label: &KeyLabel, data: &[u8], sig: &[u8]) -> Result<()> {
        let mechanism = match key_label.algorithm {
            CryptographAlgorithm::RSA2048 => Mechanism::RsaPkcs,
            CryptographAlgorithm::Ed25519 => Mechanism::Eddsa,
            _ => Mechanism::Ecdsa,
        };

        let public = self.get_key_handle(key_label, true)?;
        Ok(self.session.verify(&mechanism, public, data, sig)?)
    }

    /// verify via Secp256k1 or Secp256r1 PublicKey outside HSM
    /// Note: requires that sig was on Sha256 hash of cleartext data
    pub fn verify_ec_outside_hsm<C>(
        &self,
        key_label: &KeyLabel,
        data: &[u8],
        sig: &EcSignature<C>,
    ) -> Result<()>
        where
            C: PrimeCurve + CurveArithmetic + DigestPrimitive,
        // Scalar<C>: Invert<Output = CtOption<Scalar<C>>> + SignPrimitive<C>,
            SignatureSize<C>: ArrayLength<u8>,
            AffinePoint<C>: FromEncodedPoint<C> + ToEncodedPoint<C> + VerifyPrimitive<C>,
            FieldBytesSize<C>: ModulusSize,
    {
        Self::check_algo(key_label.algorithm, &[CryptographAlgorithm::Secp256k1, CryptographAlgorithm::Secp256r1])?;
        
        let public_key = self.get_ec_public_key(key_label)?;
        
        Ok(public_key.verify(data, sig)?)
    }

    /// verify via Secp256r1 PublicKey outside HSM
    /// Note: requires that sig was on Sha256 hash of cleartext data
    pub fn verify_p256_outside_hsm(
        &self,
        key_label: &KeyLabel,
        data: &[u8],
        sig: &EcSignature<NistP256>,
    ) -> Result<()> {
        Self::check_algo(key_label.algorithm, &[CryptographAlgorithm::Secp256r1])?;

        let public_key = self.get_p256_public_key(key_label)?;

        Ok(public_key.verify(data, sig)?)
    }
    
    /// verify via Secp256k1 or Secp256r1 PublicKey outside HSM
    /// Note: requires sig was on the same hash here
    pub fn verify_prehash_ec_outside_hsm<C>(
        &self,
        key_label: &KeyLabel,
        hash: &[u8],
        sig: &EcSignature<C>,
    ) -> Result<()>
        where
            C: PrimeCurve + CurveArithmetic + DigestPrimitive,
        // Scalar<C>: Invert<Output = CtOption<Scalar<C>>> + SignPrimitive<C>,
            SignatureSize<C>: ArrayLength<u8>,
            AffinePoint<C>: FromEncodedPoint<C> + ToEncodedPoint<C> + VerifyPrimitive<C>,
            FieldBytesSize<C>: ModulusSize,

    {
        Self::check_algo(key_label.algorithm, &[CryptographAlgorithm::Secp256k1, CryptographAlgorithm::Secp256r1])?;
        
        let public_key = self.get_ec_public_key(key_label)?;
        
        Ok(public_key.verify_prehash(hash, sig)?)
    }

    /// verify via Secp256k1 PublicKey outside HSM
    /// This function is superseded by verify_ec_outside_hsm.
    pub fn verify_sig_k256_outside_hsm (
        &self,
        key_label: &KeyLabel,
        data: &[u8],
        sig: &EcSignature<Secp256k1>,
    ) -> Result<()> {
        Self::check_algo(key_label.algorithm, &[CryptographAlgorithm::Secp256k1])?;

        let public_key = self.get_k256_public_key(key_label)?;
        
        Ok(<ecdsa::VerifyingKey<Secp256k1> as Verifier<ecdsa::Signature<Secp256k1>>>::verify(&public_key, data, sig)?)
    }

    pub fn verify_sig_ed_outside_hsm(
        &self,
        key_label: &KeyLabel,
        data: &[u8],
        sig: &EdSignature,
    ) -> Result<()> {
        Self::check_algo(key_label.algorithm, &[CryptographAlgorithm::Ed25519])?;
        
        let public_key = self.get_ed_public_key(key_label)?;

        Ok(public_key.verify(data, sig)?)
    }
    
    /// get secp256k1 or secp256r1 public key
    pub fn get_ec_public_key<C>(&self, key_label: &KeyLabel) -> Result<EcVerifyingKey<C>>
    where
        C: PrimeCurve + CurveArithmetic,
        SignatureSize<C>: ArrayLength<u8>,
        AffinePoint<C>: FromEncodedPoint<C> + ToEncodedPoint<C>,
        FieldBytesSize<C>: ModulusSize,
    {
        Self::check_algo(key_label.algorithm, &[CryptographAlgorithm::Secp256k1, CryptographAlgorithm::Secp256r1])?;
        
        let pubkey = self.get_public_key::<C>(key_label)?;

        Ok(EcVerifyingKey::<C>::from(&pubkey))         
    }

    /// get secp256k1 or secp256r1 or ed25519 public key from the decoded ec point
    /// TODO: how to use this generic function to get the verifying key for all three algorithms? k256, p256 and ed25519?
    ///   get_ec_public_key<C> works for secp256k1 and secp256r1
    ///   what is the name of the ed25519 curve?
    pub fn get_public_key<C>(&self, key_label: &KeyLabel) -> Result<PublicKey<C>>
    where
        C: CurveArithmetic,
        SignatureSize<C>: ArrayLength<u8>,
        AffinePoint<C>: FromEncodedPoint<C> + ToEncodedPoint<C>,
        FieldBytesSize<C>: ModulusSize,
    {
        Ok(PublicKey::<C>::from_sec1_bytes(self.get_decoded_public_key_bytes(key_label)?.as_slice())?)
    }

    /// get the decoded secp256k1 or secp256r1 or ed25519 public key bytes
    /// public key ec point is der encoded so it is correct to use the decoder instead of just taking the hard-coded bytes.
    pub fn get_decoded_public_key_bytes(&self, key_label: &KeyLabel) -> Result<Vec<u8>>
    {
        Self::check_algo(key_label.algorithm, &[CryptographAlgorithm::Secp256k1, CryptographAlgorithm::Secp256r1, CryptographAlgorithm::Ed25519])?;

        let ec_point = self.get_public_key_ec_point(key_label)?;

        let mut reader = der::SliceReader::new(&ec_point)
            .map_err(|e| Error::GenericError(format!("Error der reading ec point: {}", e)))?;

        let octets = der::asn1::OctetStringRef::decode(&mut reader)
            .map_err(|e| Error::GenericError(format!("Error der decoding ec point: {}", e)))?;

        Ok(octets.as_bytes().into())
    }
    
    // Need this for tmkms
    // #[deprecated(
    //     since = "0.1.0",
    //     note = "Please use get_ec_public_key instead"
    // )]
    /// get secp256k1 public key
    pub fn get_k256_public_key(&self, key_label: &KeyLabel) -> Result<EcVerifyingKey<Secp256k1>> {
        Self::check_algo(key_label.algorithm, &[CryptographAlgorithm::Secp256k1])?;

        let pk = self.get_public_key::<Secp256k1>(key_label)?;
        
        // public key ec_point is DER encoded. Ignore the first two bytes and treat the rest 65 bytes as sec1 uncompressed
        Ok(EcVerifyingKey::from(&pk))
    }

    pub fn get_p256_public_key(&self, key_label: &KeyLabel) -> Result<EcVerifyingKey<NistP256>> {
        Self::check_algo(key_label.algorithm, &[CryptographAlgorithm::Secp256r1])?;
        
        let pk = self.get_public_key::<NistP256>(key_label)?;

        Ok(EcVerifyingKey::from(&pk))
    }

    pub fn get_ed_public_key(&self, key_label: &KeyLabel) -> Result<EdVerifyingKey> {
        Self::check_algo(key_label.algorithm, &[CryptographAlgorithm::Ed25519])?;
        
        let a: [u8; 32] = <[u8; 32]>::try_from(self.get_decoded_public_key_bytes(key_label)?).unwrap();
        
        Ok(EdVerifyingKey::from_bytes(&a)?)
    }

    /// Return the EC point of the public key if any.
    /// Return error if none found or more than one found.
    pub fn get_public_key_ec_point(&self, key_label: &KeyLabel) -> Result<Vec<u8>> {
        if !self.is_authorized() {
            return Err(Error::NotAuthorized)
        }

        let handle = self.get_key_handle(key_label, true)?;

        let template = vec![AttributeType::EcPoint];

        let attributes = self.session.get_attributes(handle, &template)?;

        if attributes.len() == 1 {
            if let Attribute::EcPoint(point) = attributes[0].borrow() {
                return Ok(point.clone())
            }
        }

        Err(Error::GenericError("Error getting ec point".to_string()))
    }

    /// Return the EC point of the public key if any and the oid.
    /// TODO: how to use oid?
    pub fn get_public_key_ec_point_oid(&self, key_label: &KeyLabel) -> Result<(Vec<u8>, Option<ObjectIdentifier>)> {
        if !self.is_authorized() {
            return Err(Error::NotAuthorized)
        }

        let handle = self.get_key_handle(key_label, true)?;

        let template = vec![AttributeType::EcPoint, AttributeType::EcParams];

        let mut attributes = self.session.get_attributes(handle, &template)?;

        let oid = if let Some(Attribute::EcParams(oid)) = attributes.pop() {
            let mut reader = der::SliceReader::new(&oid)
                .map_err(|e| Error::GenericError(format!("Error reading oid: {}", e)))?;
            ObjectIdentifier::decode(&mut reader).map_err(|e| Error::GenericError(format!("Error decoding oid: {}", e)))?
        } else {
            return Err(Error::GenericError("Error getting oid attribute".to_string()))
        };
        
        let ec_point = if let Some(Attribute::EcPoint(point)) = attributes.pop() {
            point
        } else {
            return Err(Error::GenericError("Error getting ec point attribute".to_string()))
        };
        
        Ok((ec_point, Some(oid)))
    }
    /// Return the key handle if any for either a public or private key depending on is_public.
    /// Return err if none found or more than one found.
    pub fn get_key_handle(&self, key_label: &KeyLabel, is_public: bool) -> Result<ObjectHandle> {
        let mut template = vec![
            Attribute::Label(Vec::from(key_label.short_label().as_bytes())),
        ];
        if is_public {
            template.push(Attribute::Class(ObjectClass::PUBLIC_KEY));
        } else {
            template.push(Attribute::Class(ObjectClass::PRIVATE_KEY));
        }

        let handles = self.session.find_objects(&template)?;

        if handles.len() == 1 {
            Ok(handles[0])
        } else {
            Err(Error::GenericError(format!("Expecting 1 handle but getting: {}", handles.len())))
        }
    }

    /// Return whether or not a key handle exists for either a public or private key depending on is_public.
    pub fn exist_key_handle(&self, key_label: &KeyLabel, is_public: bool) -> bool {
        self.get_key_handle(key_label, is_public).is_ok()
            
        /*    
        let mut template = vec![
            Attribute::Label(Vec::from(key_label.short_label().as_bytes())),
        ];

        if is_public {
            template.push(Attribute::Class(ObjectClass::PUBLIC_KEY));
        } else {
            template.push(Attribute::Class(ObjectClass::PRIVATE_KEY));
        }

        if let Ok(handles) = self.session.find_objects(&template) {
            if !handles.is_empty() {
                return true;
            }
        }

        false        
         */
    }

    pub(crate) fn check_algo(algo: CryptographAlgorithm, requried: &[CryptographAlgorithm]) -> Result<()> {
        if !requried.contains(&algo) {
            return Err(Error::AlgorithmNotSupported)
        }

        Ok(())
    }
    #[deprecated(
        since = "0.1.0",
        note = "Please use get_key_handle instead"
    )]
    pub fn get_private_key_handle(&self, key_label: &KeyLabel) -> Result<ObjectHandle> {
        let template = vec![
            Attribute::Class(ObjectClass::PRIVATE_KEY),
            Attribute::Label(Vec::from(key_label.short_label().as_bytes())),
        ];

        let handles = self.session.find_objects(&template)?;

        if handles.len() == 1 {
            Ok(handles[0])
        } else {
            Err(Error::GenericError(format!("Expecting 1 handle but getting: {}", handles.len())))
        }
    }

    #[deprecated(
    since = "0.1.0",
    note = "Please use exist_key_handle instead"
    )]
    pub fn exist_private_key_handle(&self, key_label: &KeyLabel) -> bool {
        let template = vec![
            Attribute::Class(ObjectClass::PRIVATE_KEY),
            Attribute::Label(Vec::from(key_label.short_label().as_bytes())),
        ];

        if let Ok(handles) = self.session.find_objects(&template) {
            if !handles.is_empty() {
                return true;
            }
        }

        false
    }

    #[deprecated(
    since = "0.1.0",
    note = "Please use get_key_handle instead"
    )]
    pub fn get_public_key_handle(&self, key_label: &KeyLabel) -> Result<ObjectHandle> {
        let template = vec![
            Attribute::Class(ObjectClass::PUBLIC_KEY),
            Attribute::Label(Vec::from(key_label.short_label().as_bytes())),
        ];

        let handles = self.session.find_objects(&template)?;

        if handles.len() == 1 {
            Ok(handles[0])
        } else {
            Err(Error::GenericError(format!("Expecting 1 handle but getting: {}", handles.len())))
        }
    }

    #[deprecated(
    since = "0.1.0",
    note = "Please use exist_key_handle instead"
    )]
    pub fn exist_public_key_handle(&self, key_label: &KeyLabel) -> bool {
        let template = vec![
            Attribute::Class(ObjectClass::PUBLIC_KEY),
            Attribute::Label(Vec::from(key_label.short_label().as_bytes())),
        ];

        if let Ok(handles) = self.session.find_objects(&template) {
            if !handles.is_empty() {
                return true;
            }
        }

        false
    }

    #[deprecated(
        since = "0.1.0",
        note = "Please use get_ec_public_key"
    )]
    /// get secp256k1 or secp256r1 public key
    /// it hard-codes the bytes instead of using the decoder
    pub fn get_ec_public_key_hard_coded<C>(&self, key_label: &KeyLabel) -> Result<EcVerifyingKey<C>>
    where
        C: PrimeCurve + CurveArithmetic,
    //Scalar<C>: Invert<Output = CtOption<Scalar<C>>> + SignPrimitive<C>,
        SignatureSize<C>: ArrayLength<u8>,
        AffinePoint<C>: FromEncodedPoint<C> + ToEncodedPoint<C> + VerifyPrimitive<C>,
        FieldBytesSize<C>: ModulusSize,
    {
        Self::check_algo(key_label.algorithm, &[CryptographAlgorithm::Secp256k1, CryptographAlgorithm::Secp256r1])?;
        
        let ec_point = self.get_public_key_ec_point(key_label)?;

        // public key ec_point is DER encoded. Ignore the first two bytes and treat the rest 65 bytes as sec1 uncompressed
        Ok(EcVerifyingKey::<C>::from_sec1_bytes(&ec_point[2..])?)
    }

    #[deprecated(
        since = "0.1.0",
        note = "Please use get_ed_public_key"
    )]
    /// get ed25519 public key
    /// Note: SOFTHSM2 ec_point is DER encoded with 34 bytes. Ignore the first two bytes and treat the rest 32 bytes as ed25519 public key
    ///   FX is 32 bytes.
    ///  So we take the last 32 bytes.
    pub fn get_ed_public_key_hard_coded(&self, key_label: &KeyLabel) -> Result<EdVerifyingKey> {
        Self::check_algo(key_label.algorithm, &[CryptographAlgorithm::Ed25519])?;
        
        let ec_point = self.get_public_key_ec_point(key_label)?;

        let l = ec_point.len();

        let bytes = <&[u8; 32]>::try_from(
            &ec_point[l-32..l],
        ).map_err(|e: TryFromSliceError| Error::GenericError(format!("Error getting ed public bytes: {e}")))?;

        Ok(EdVerifyingKey::from_bytes(bytes)?)

    }

    #[deprecated(
        since = "0.1.0",
        note = "Please use get_k256_public_key instead"
    )]
    /// get secp256k1 public key
    /// it hard-codes the bytes.
    pub fn get_k256_public_key_hard_coded(&self, key_label: &KeyLabel) -> Result<EcVerifyingKey<Secp256k1>> {
        Self::check_algo(key_label.algorithm, &[CryptographAlgorithm::Secp256k1])?;
        
        let ec_point = self.get_public_key_ec_point(key_label)?;

        // public key ec_point is DER encoded. Ignore the first two bytes and treat the rest 65 bytes as sec1 uncompressed
        Ok(EcVerifyingKey::from_sec1_bytes(&ec_point[2..])?)
    }

}

/// init_sdk(...) is used by client site to facilitate opening of new sdk sessions fully logged in.
/* 
    note: new sdk session is fully logged in even thought it is not done explicitly.
    that is because in fn init_sdk(...), the (private) Init's private _sdk holds a logged-in session.
    so any future session opened on ctx will be automatically logged in regardless of threads.
    that is the feature of PKCS11 sessions.  
    init_sdk() is used in wfdc2 wallet_svc because there is a single (module, slot) pair.
    it is not applicable to tmkms service because one module can potentially have multiple slots,
      but is applied in keys commands. 
*/

pub fn init_sdk(env_cfg: &str, cfg: &str, env_module: Option<&str>, module: Option<&str>, token_label: &str, pin: &str) -> anyhow::Result<&'static SDKContext> {
    INIT_CALL.call_once(|| {
        env::set_var(env_cfg, cfg);
    });
    info!("env_cfg: {}; cfg: {:?}", env_cfg, cfg);
    info!(
        "evn_module: {:?}; module: {:?}",
        env_module, module
    );
    let init = INIT_CELL.get_or_try_init(|| {
        let p11 = SDKContext::create_pkcs11(env_module, module)?;
        info!("new pkcs11 created: {:?}", p11.get_library_info().unwrap());
        
        let mut ctx = SDKContext::new(p11);
        
        ctx.set_slot_by_label(token_label)?;
        info!("context slot set: {}", token_label);
        
        // let sdk = SDK::from_context_with_login(&ctx, pin)?;
        let mut sdk = SDK::from_context(&ctx)?;
        info!("sdk created from context (prior to login)");
        
        sdk.login(pin)?;
        info!("logged in sdk session: {}", sdk.session());
        
        Ok(Init { ctx, _sdk: Mutex::new(sdk) })
    });
    
    init.map(|i| &i.ctx)
}