use crate::error::{Error, Result};
use crate::sdk::{CryptographAlgorithm};
use ecdsa::signature::digest::Digest;
use regex::Regex;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct KeyLabel {
    pub prefix: String,
    pub key_ring: String,
    pub key: String,
    pub version: usize,
    pub algorithm: CryptographAlgorithm,
}

impl KeyLabel {
    pub fn new(
        prefix: String,
        key_ring: String,
        key: String,
        version: usize,
        algorithm: CryptographAlgorithm,
    ) -> Self {
        Self {
            prefix,
            key_ring,
            key,
            version,
            algorithm,
        }
    }

    pub fn from(label: &str, algorithm: CryptographAlgorithm) -> Result<Self> {
        let re = Regex::new(r".*/keyRings/.+/cryptoKeys/.+/cryptoKeyVersions/\d+").unwrap();
        if !re.is_match(label) {
            Err(Error::GenericError("Invalid label".to_string()))
        } else {
            re.split(label);
            let parts: Vec<&str> = label.split('/').collect();
            let n = parts.len();

            //TODO: this generic code does not compile because prefix does not live long enough
            /*
            let prefix: String = parts[0..n-6].join("/");
            Ok(Self {
                prefix: &prefix,
                key_ring: parts[n-5],
                key: parts[n-3],
                version: parts[n-1].parse::<usize>().unwrap(),
                algorithm,
            })
            */
            if n != 7 {
                Err(Error::GenericError(format!("Invalid label - expecting 7 segments but getting: {}", n)))
            } else {
                Ok(Self {
                    prefix: parts[n - 7].to_string(),
                    key_ring: parts[n - 5].to_string(),
                    key: parts[n - 3].to_string(),
                    version: parts[n - 1].parse::<usize>().unwrap(),
                    algorithm,
                })
            }
        }
    }

    pub fn from_short(label: &str, algorithm: CryptographAlgorithm) -> Result<Self> {
        let re = Regex::new(r".*/.+/.+/\d+").unwrap();
        if !re.is_match(label) {
            Err(Error::GenericError("Invalid label".to_string()))
        } else {
            re.split(label);
            let parts: Vec<&str> = label.split('/').collect();
            if parts.len() != 4 {
                Err(Error::GenericError(format!("Invalid short label - expecting 4 segments but getting: {}", parts.len())))
            } else {
                Ok(Self {
                    prefix: parts[0].to_string(),
                    key_ring: parts[1].to_string(),
                    key: parts[2].to_string(),
                    version: parts[3].parse::<usize>().unwrap(),
                    algorithm,
                })
            }
        }
    }

    pub fn label(&self) -> String {
        format!(
            "{}/keyRings/{}/cryptoKeys/{}/cryptoKeyVersions/{}",
            self.prefix, self.key_ring, self.key, self.version
        )
    }

    pub fn short_label(&self) -> String {
        format!(
            "{}/{}/{}/{}",
            self.prefix, self.key_ring, self.key, self.version
        )
    }

    pub fn string(&self) -> String {
        self.label()
    }

    pub fn short_string(&self) -> String {
        self.short_label()
    }

    // pub fn next(&mut self) -> &mut Self {
    //     self.version += 1;
    //     self
    // }

    pub fn next(&mut self) {
        self.version += 1;
    }
}

pub fn secure_hash_to_vec(data: &[u8]) -> Vec<u8> {
    // we can use digest() which is the wrapper of the commented code below
    /*
    let mut hasher = sha2::Sha256::new();
    hasher.update(data);
    hasher.finalize().to_vec()
    */
    sha2::Sha256::digest(data).to_vec()
}

pub fn secure_hash(data: &[u8]) -> [u8; 32] {
    sha2::Sha256::digest(data).into()
}
