use cryptoki::mechanism::aead::GcmParams;
use cryptoki::object::{Attribute, KeyType, ObjectClass, ObjectHandle, };
use cryptoki::mechanism::Mechanism;
use crate::{KeyLabel, SDK, Result, Error, CryptographAlgorithm};

impl SDK {
    const KEY_LEN: u64 = 32;
    const IV_LEN: usize = 12;
    const TAG_BITS: u64 = 128;
    pub fn aes_keygen(
        &self,
        key_label: &mut KeyLabel,
        persistent: bool,
    ) -> Result<(ObjectHandle, KeyLabel)> {
        Self::check_algo(key_label.algorithm, &[CryptographAlgorithm::AES])?;

        // DO NOT OVERWRITE EXISTING KEYS
        // find key_label with the version that does not exist
        loop {
            if !self.exist_aes_key(key_label) {
                break;
            }
            key_label.next();
        }
        
        // TODO: why should we pass in a key exposed to outside? 
        // generate a random key
        // let mut key = [0u8; Self::KEY_LEN as usize];
        // self.session().generate_random_slice(&mut key)?;
        
        let mechanism = Mechanism::AesKeyGen;
            
        let template = [
            Attribute::Class(ObjectClass::SECRET_KEY),
            Attribute::KeyType(KeyType::AES),
            Attribute::Token(persistent),
            Attribute::Encrypt(true),
            Attribute::Decrypt(true),
            // Attribute::Sign(false),
            // Attribute::Verify(false),
            // Attribute::Value(key.to_vec()),
            Attribute::ValueLen(Self::KEY_LEN.into()),
            Attribute::Private(true),
            // Attribute::Wrap(true),
            // Attribute::Unwrap(true),
            Attribute::Sensitive(true),
            // Attribute::Extractable(!persistent),
            Attribute::Label(Vec::from(key_label.short_label().as_bytes())),
        ];
        
        let handle = self.session().generate_key(&mechanism, &template)?;
        /*
        create_object: 
            works for FX
            for SoftHsm, it requires Attribute::Value(key.to_vec())
         */
        // let handle = self.session().create_object(&template)?;
        
        Ok((handle, key_label.clone()))
    }
    
    pub fn encrypt(
        &self,
        key_label: &KeyLabel,
        data: &[u8],
        aad: &[u8],
    ) -> Result<Vec<u8>> {
        Self::check_algo(key_label.algorithm, &[CryptographAlgorithm::AES])?;

        let handle = self.get_aes_key_handle(key_label)?;

        let mut iv = [0u8; Self::IV_LEN];
        self.session().generate_random_slice(&mut iv)?;
        
        let mechanism = Mechanism::AesGcm(
            GcmParams::new(
                &iv,
                aad,
                Self::TAG_BITS.into(),
            )
        );
        
        let mut ciphertext = self.session().encrypt(&mechanism, handle, data)?;
        
        // ciphertext.append(&mut iv.to_vec());
        // ciphertext.extend(&iv);
        ciphertext.extend_from_slice(&iv);
        
        Ok(ciphertext)
    }

    pub fn decrypt(
        &self,
        key_label: &KeyLabel,
        ciphertext: &[u8],
        aad: &[u8],
    ) -> Result<Vec<u8>> {
        Self::check_algo(key_label.algorithm, &[CryptographAlgorithm::AES])?;

        let handle = self.get_aes_key_handle(key_label)?;

        if ciphertext.len() <= Self::IV_LEN {
            return Err(Error::GenericError("ciphertext is too short".to_string()));
        }
        
        let (ciphertext, iv) = ciphertext.split_at(ciphertext.len() - Self::IV_LEN);
        
        let mechanism = Mechanism::AesGcm(
            GcmParams::new(
                iv,
                aad,
                Self::TAG_BITS.into(),
            )
        );
        
        Ok(self.session().decrypt(&mechanism, handle, ciphertext)?)
    }
    
    pub fn get_aes_key_handle(&self, key_label: &KeyLabel) -> Result<ObjectHandle> {
        let template = vec![
            Attribute::Label(Vec::from(key_label.short_label().as_bytes())),
            Attribute::Class(ObjectClass::SECRET_KEY),
        ];

        let handles = self.session().find_objects(&template)?;

        if handles.len() == 1 {
            Ok(handles[0])
        } else {
            Err(Error::GenericError(format!("Expecting 1 handle but getting: {}", handles.len())))
        }
    }
    
    pub fn exist_aes_key(&self, key_label: &KeyLabel) -> bool {
        self.get_aes_key_handle(key_label).is_ok()
    }
}