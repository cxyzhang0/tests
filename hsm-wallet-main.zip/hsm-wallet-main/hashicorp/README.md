## hashicorp
Hashicorp Vault is an enterprise solution for secret management and access control. Secrets are strongly encrypted via 256-bit AES-GCM and are stored in a distributed RAFT-clustered secure storage backend. 
Access to secrets is protected by policies.  
Encryption keys are encrypted by a root key which is encrypted by a unseal key which is split into multiple parts and distributed among multiple parties via threshold Shamir Secret Sharing. An alternative is to keep the unseal key inside an HSM.

We explore the use of Hashicorp Vault for key management where the secret is the private key of a wallet.    
This crate provides an ecdsa SDK and an eddsa SDK for interfacing with Hashicorp Vault to generate Secp256k1, Secp256r1 and Ed25519 key pairs, respectively.
Through integration tests, we showcase the use of the k256 SDK to create wallets and build and sign transactions on Cosmos chains.

* SDK to interface with Hashicorp Vault for key management
> Supported algorithms
> * secp256k1
> * secp256r1
> * ed25519
* Integration tests to demonstrate the use of the k256 SDK to create wallets and build and sign transactions on Cosmos chains.
> Prerequisites and dependencies
> * Hashicorp Vault dev server installed per https://developer.hashicorp.com/vault/tutorials/getting-started/getting-started-install
> * Vault dev server running at VAULT_SERVER set in common.
```shell
# to start a vault dev server,
vault server -dev -dev-root-token-id="root"
# to use vault cli in a terminal,
export VAULT_ADDR='http://127.0.0.1:8200'
```
> * local mpc-wallet source
> * local modified version of cosmos-grpc-client
> * a running Cosmos chain whose grpc Url defined in test_utils of mpc-wallet.

**TODO:** Currently need to run integration tests one at a time via IDE. cargo test could not find some modules for this special folder tests.  
cargo test works now. If there is still a problem, create directory common and put all common codes in common/mod.rs. 
Then, in each test file, use `mod common;` to import the common codes.
