mod common;

use crate::common::{VAULT_PK1_K256, VAULT_PK_ED25519, VAULT_SERVER, VAULT_STORE, VAULT_TOKEN};
use hashicorp::sdk_ed25519::SDK;

#[tokio::test]
async fn it_generate_key_pair() {
    let sdk = SDK::new(VAULT_SERVER, VAULT_TOKEN, VAULT_STORE);

    let pk = sdk.generate_key_pair().await.unwrap();

    println!("pk: {}", pk);
}

#[tokio::test]
async fn it_sign_and_verify() {
    let sdk = SDK::new(VAULT_SERVER, VAULT_TOKEN, VAULT_STORE);

    let msg = "sign me";

    let _ = sdk.sign_and_verify(&VAULT_PK_ED25519, msg).await.unwrap();
}

#[tokio::test]
#[should_panic("mixed curves")]
async fn it_sign_and_verify_negative() {
    let sdk = SDK::new(VAULT_SERVER, VAULT_TOKEN, VAULT_STORE);

    let msg = "sign me";

    let _ = sdk.sign_and_verify(&VAULT_PK1_K256, msg).await.unwrap();
}
