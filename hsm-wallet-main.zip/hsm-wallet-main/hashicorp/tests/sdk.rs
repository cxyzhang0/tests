// mod basic;
mod common;

use crate::common::{
    VAULT_ACCT1, VAULT_PK1_K256, VAULT_PK_K256, VAULT_PK_P256, VAULT_SERVER, VAULT_STORE,
    VAULT_TOKEN,
};
use cosmos_grpc_client::{BroadcastMode, CoinType, Decimal, GrpcClient, Wallet};
use cosmos_sdk_proto::cosmos::{bank::v1beta1::MsgSend, base::v1beta1::Coin as ProtoCoin};
use cosmos_sdk_proto::traits::MessageExt;
use hashicorp::get_vault_client;
use hashicorp::sdk::SDK;
use k256::Secp256k1;
use mpc_wallet::test_util::{CHAIN_GRPC, CHAIN_PREFIX, DENOM, STAKE_DENOM};
use mpc_wallet::utils::pk_to_account;
use p256::NistP256;
use std::str::FromStr;
use vaultrs::client::Client;

#[tokio::test]
async fn it_generate_key_pair_k256() {
    let sdk = SDK::<Secp256k1>::new(VAULT_SERVER, VAULT_TOKEN, VAULT_STORE);

    let pk = sdk.generate_key_pair().await.unwrap();

    // println!("pk: {}", pk);

    let account = pk_to_account(&pk, CHAIN_PREFIX);

    println!("pk: {}, account: {}", pk, account);
}

#[tokio::test]
async fn it_sign_and_verify_k256() {
    let sdk = SDK::<Secp256k1>::new(VAULT_SERVER, VAULT_TOKEN, VAULT_STORE);

    let msg = "sign me";

    let _ = sdk
        .sign_and_verify(&VAULT_PK1_K256, msg.as_bytes())
        .await
        .unwrap();
}

#[tokio::test]
async fn it_generate_key_pair_p256() {
    let sdk = SDK::<NistP256>::new(VAULT_SERVER, VAULT_TOKEN, VAULT_STORE);

    let pk = sdk.generate_key_pair().await.unwrap();

    println!("pk: {}", pk);
}

#[tokio::test]
async fn it_sign_and_verify_p256() {
    let sdk = SDK::<NistP256>::new(VAULT_SERVER, VAULT_TOKEN, VAULT_STORE);

    let msg = "sign me";

    let _ = sdk
        .sign_and_verify(&VAULT_PK_P256, msg.as_bytes())
        .await
        .unwrap();
}

#[tokio::test]
#[should_panic("mixed curves")]
async fn panic_sign_and_verify_p256() {
    let sdk = SDK::<Secp256k1>::new(VAULT_SERVER, VAULT_TOKEN, VAULT_STORE);

    let msg = "sign me";

    let _ = sdk
        .sign_and_verify(&VAULT_PK_P256, msg.as_bytes())
        .await
        .expect("mixed curves");
}

#[tokio::test]
async fn it_wallet_sign_tx_signer() {
    let mut gcp_client = GrpcClient::new(CHAIN_GRPC).await.unwrap();
    let client = get_vault_client(VAULT_SERVER, VAULT_TOKEN).unwrap();
    assert!(matches!(
        client.status().await.unwrap(),
        vaultrs::sys::ServerStatus::OK
    ));

    let sdk = SDK::<Secp256k1>::new(VAULT_SERVER, VAULT_TOKEN, VAULT_STORE);

    let sk = sdk.cosmrs_signing_key(VAULT_PK_K256).await.unwrap();

    let mut wallet = Wallet::finalize_wallet_creation(
        &mut gcp_client,
        sk,
        CHAIN_PREFIX,
        CoinType::Cosmos,
        Decimal::from_str("0.120").unwrap(), // Gas_price
        Decimal::from_str("2.0").unwrap(),   // Gas adjustment
        STAKE_DENOM,                         // Gas denom
    )
    .await
    .unwrap();

    let msg = MsgSend {
        from_address: wallet.account_address(),
        to_address: VAULT_ACCT1.to_string(),
        amount: vec![ProtoCoin {
            denom: DENOM.to_string(),
            amount: "100".to_string(),
        }],
    }
    .to_any()
    .unwrap();

    let response = wallet
        .broadcast_tx(
            &mut gcp_client,
            vec![msg],           // Vec<Any>: list of msgs to broadcast
            None,                // memo: Option<String>
            None, // fee: Option<Fee>, if not provided the tx is simulated to calculate the fee
            BroadcastMode::Sync, // Broadcast mode; Block/Sync/Async
        )
        .await
        .unwrap();

    println!("response: {response:#?}")
}
