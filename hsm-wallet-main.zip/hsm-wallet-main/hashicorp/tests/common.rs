pub const VAULT_SERVER: &str = "http://127.0.0.1:8200";
pub const VAULT_STORE: &str = "secret";
pub const VAULT_TOKEN: &str = "root";
pub const VAULT_PK_K256: &str =
    "03e28c40f5c0494c64990fb564a28e34c6471cbc3e002730da8d25fc969d27ebb1";
pub const VAULT_ACCT: &str = "wf1hxs0xukgyrrcsxv0clx8uwk2s2pnlavamde8j6";
pub const VAULT_PK1_K256: &str =
    "02445797eb4985b7d61edece4fda9dc0629b6b8da1d860e42952c140c0cbb8983c";
pub const VAULT_ACCT1: &str = "wf1z0ex92huxz7v5e5jyret5gsdv4apyhhdavdh0k";

pub const VAULT_PK_P256: &str =
    "02fad41c497623d121d242cf4cbdded7bba1fd236ba686835d315a09b82b2c7783";

pub const VAULT_PK_ED25519: &str =
    "692f36281e93a302a67b11b6dc01888ff9abfbadf06d6706ea70d163983ac25f";
