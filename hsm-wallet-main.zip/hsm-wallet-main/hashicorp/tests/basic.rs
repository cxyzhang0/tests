mod common;

use crate::common::{VAULT_ACCT1, VAULT_PK_K256, VAULT_SERVER, VAULT_STORE, VAULT_TOKEN};
use cosmos_grpc_client::cosmos_sdk_proto::cosmos::{
    bank::v1beta1::MsgSend, base::v1beta1::Coin as ProtoCoin,
};
use cosmos_grpc_client::{BroadcastMode, CoinType, Decimal, GrpcClient, Wallet};
use cosmos_sdk_proto::traits::MessageExt;
use cosmrs::bip32::secp256k1::ecdsa::signature::{Keypair, Signer, Verifier};
use cosmrs::bip32::secp256k1::Secp256k1;
use cosmrs::bip32::{PrivateKey, PublicKey};
use cosmrs::crypto::secp256k1::{Signature as K256Signature, SigningKey};
use hashicorp::get_vault_client;
use hashicorp::sdk::{K256SigningKey, WalletSecret};
use mpc_wallet::test_util::{ACCT2, CHAIN_GRPC, CHAIN_PREFIX, DENOM, STAKE_DENOM};
use mpc_wallet::utils::pk_to_account;
use rand_core::OsRng;
use serde::{Deserialize, Serialize};
use std::str::FromStr;
use vaultrs::client::{Client, VaultClient, VaultClientSettingsBuilder};
use vaultrs::kv2;

#[derive(Debug, Serialize, Deserialize, PartialEq)]
struct StringSecret {
    pk: String, // hex
    sk: String, // hex
}
impl StringSecret {
    fn new(pk: String, sk: String) -> Self {
        Self { pk, sk }
    }
}

#[derive(Debug, Serialize, Deserialize, PartialEq)]
struct BinarySecret {
    pk: String,  // hex
    sk: Vec<u8>, // byte array
}
impl BinarySecret {
    fn new(pk: String, sk: Vec<u8>) -> Self {
        Self { pk, sk }
    }
}

#[derive(Debug, Serialize, Deserialize, PartialEq)]
struct FullBinarySecret {
    pk: Vec<u8>, // hex
    sk: Vec<u8>, // byte array
}
impl crate::FullBinarySecret {
    fn new(pk: Vec<u8>, sk: Vec<u8>) -> Self {
        Self { pk, sk }
    }
}

#[tokio::test]
async fn it_get_client() {
    let client = get_vault_client(VAULT_SERVER, VAULT_TOKEN).unwrap();
    assert!(matches!(
        client.status().await.unwrap(),
        vaultrs::sys::ServerStatus::OK
    ));
    // println!("client status: {:?}", client.status().await.unwrap())
}

#[tokio::test]
async fn it_wallet_secret() {
    let client = get_vault_client(VAULT_SERVER, VAULT_TOKEN).unwrap();
    assert!(matches!(
        client.status().await.unwrap(),
        vaultrs::sys::ServerStatus::OK
    ));

    // generate a random field element as private key
    let sk = K256SigningKey::random(&mut OsRng);

    let secret = WalletSecret::new(sk.to_bytes().to_vec());
    let vk = sk.verifying_key();
    let pk: Vec<u8> = sk.verifying_key().to_bytes().to_vec();
    let pk = hex::encode(pk);

    kv2::set(&client, VAULT_STORE, pk.as_str(), &secret)
        .await
        .unwrap();

    let got_secret: WalletSecret = kv2::read(&client, VAULT_STORE, pk.as_str()).await.unwrap();

    assert_eq!(secret, got_secret);

    let got_sk = SigningKey::from_slice(got_secret.secret()).unwrap();
    /*
    Note: got_sk and sk are of different types even though they can be constructed
    from the same bytes.
    got_sk cannot be converted into bytes anymore because its inner is not public.
    got_sk can sign easily but it has not verifying key to verify.
    sk is hard to use for signing (see it_wallet_sign() below) but it has a verifying key.
     */

    let got_pk = got_sk.public_key();
    assert_eq!(pk, hex::encode(got_pk.to_bytes()));
    println!("pk: {}; account: {}", pk, pk_to_account(&pk, CHAIN_PREFIX));

    // positive
    let msg = "sign me";
    let sig = got_sk.sign(msg.as_bytes()).unwrap();
    assert!(vk.verify(msg.as_bytes(), &sig).is_ok());

    // negative
    let msg = "sign me not";
    assert!(vk.verify(msg.as_bytes(), &sig).is_err());
}

#[tokio::test]
async fn it_wallet_sign() {
    let client = get_vault_client(VAULT_SERVER, VAULT_TOKEN).unwrap();
    assert!(matches!(
        client.status().await.unwrap(),
        vaultrs::sys::ServerStatus::OK
    ));

    let got_secret: WalletSecret = kv2::read(&client, "secret", VAULT_PK_K256).await.unwrap();

    let got_sk = K256SigningKey::from_slice(got_secret.secret()).unwrap();
    // let got_sk = cosmos_grpc_client::cosmrs::crypto::secp256k1::SigningKey::from_slice(&got_secret.secret).unwrap();

    let got_pk = got_sk.public_key();
    assert_eq!(VAULT_PK_K256, hex::encode(got_pk.to_bytes()));

    // positive
    let msg = "sign me";
    // TODO: how to simplify the following sign syntax?
    let sig =
        <ecdsa::SigningKey<Secp256k1> as Signer<K256Signature>>::sign(&got_sk, msg.as_bytes());
    assert!(got_pk.verify(msg.as_bytes(), &sig).is_ok());

    // negative
    let msg = "sign me not";
    assert!(got_pk.verify(msg.as_bytes(), &sig).is_err());
}

#[tokio::test]
async fn it_wallet_sign_tx_signer() {
    let mut gcp_client = GrpcClient::new(CHAIN_GRPC).await.unwrap();
    let client = get_vault_client(VAULT_SERVER, VAULT_TOKEN).unwrap();
    assert!(matches!(
        client.status().await.unwrap(),
        vaultrs::sys::ServerStatus::OK
    ));

    let got_secret: WalletSecret = kv2::read(&client, "secret", VAULT_PK_K256).await.unwrap();
    let got_sk = SigningKey::from_slice(got_secret.secret()).unwrap();
    let mut wallet = Wallet::finalize_wallet_creation(
        &mut gcp_client,
        got_sk,
        CHAIN_PREFIX,
        CoinType::Cosmos,
        Decimal::from_str("0.120").unwrap(), // Gas_price
        Decimal::from_str("2.0").unwrap(),   // Gas adjustment
        STAKE_DENOM,                         // Gas denom
    )
    .await
    .unwrap();

    // let any = Any::pack(&got_secret.secret).unwrap();
    // let sk = MessageExt::from_any(got_secret.secret.into());
    // let sk = hex::encode(got_secret.secret.as_slice());
    // let sk = "7f7507bd29fc0726add5132c6a85e31f5476a6941510d69b0f6d35ed6d3d84fa";
    /*
    let mut wallet = Wallet::from_private_key(
        &mut gcp_client,
        sk,
        CHAIN_PREFIX,
        CoinType::Cosmos,
        Decimal::from_str("0.120").unwrap(), // Gas_price
        Decimal::from_str("2.0").unwrap(), // Gas adjustment
        STAKE_DENOM,      // Gas denom
    ).await.unwrap();
    */

    let msg = MsgSend {
        from_address: wallet.account_address(),
        to_address: VAULT_ACCT1.to_string(),
        amount: vec![ProtoCoin {
            denom: DENOM.to_string(),
            amount: "100".to_string(),
        }],
    }
    .to_any()
    .unwrap();

    let response = wallet
        .broadcast_tx(
            &mut gcp_client,
            vec![msg],           // Vec<Any>: list of msgs to broadcast
            None,                // memo: Option<String>
            None, // fee: Option<Fee>, if not provided the tx is simulated to calculate the fee
            BroadcastMode::Sync, // Broadcast mode; Block/Sync/Async
        )
        .await
        .unwrap();

    println!("response: {response:#?}")
}

// TODO: This test failed because the encoding of private key from bytearray to string is not correct.
//   Looks like the encoding is prost protobuf encoding. How?
#[tokio::test]
#[should_panic("could not parse private key")]
async fn it_wallet_sign_tx_private_key() {
    let mut gcp_client = GrpcClient::new(CHAIN_GRPC).await.unwrap();
    let client = get_vault_client(VAULT_SERVER, VAULT_TOKEN).unwrap();
    assert!(matches!(
        client.status().await.unwrap(),
        vaultrs::sys::ServerStatus::OK
    ));

    let got_secret: WalletSecret = kv2::read(&client, "secret", VAULT_PK_K256).await.unwrap();
    // let got_sk = SigningKey::from_slice(&got_secret.secret).unwrap();

    // let sk = MessageExt::from_any(got_secret.secret.into());
    // let sk = hex::encode(got_secret.secret.as_slice());
    // let sk = "7f7507bd29fc0726add5132c6a85e31f5476a6941510d69b0f6d35ed6d3d84fa";
    let sk = String::from_utf8_lossy(got_secret.secret());
    let mut wallet = Wallet::from_private_key(
        &mut gcp_client,
        sk,
        CHAIN_PREFIX,
        CoinType::Cosmos,
        Decimal::from_str("0.120").unwrap(), // Gas_price
        Decimal::from_str("2.0").unwrap(),   // Gas adjustment
        STAKE_DENOM,                         // Gas denom
    )
    .await
    .unwrap();

    let msg = MsgSend {
        from_address: wallet.account_address(),
        to_address: VAULT_ACCT1.to_string(),
        amount: vec![ProtoCoin {
            denom: DENOM.to_string(),
            amount: "100".to_string(),
        }],
    }
    .to_any()
    .unwrap();

    let response = wallet
        .broadcast_tx(
            &mut gcp_client,
            vec![msg],           // Vec<Any>: list of msgs to broadcast
            None,                // memo: Option<String>
            None, // fee: Option<Fee>, if not provided the tx is simulated to calculate the fee
            BroadcastMode::Sync, // Broadcast mode; Block/Sync/Async
        )
        .await
        .unwrap();

    println!("response: {response:#?}")
}

#[tokio::test]
async fn it_wallet_sign_tx_private_key_bytes() {
    let mut gcp_client = GrpcClient::new(CHAIN_GRPC).await.unwrap();
    let client = get_vault_client(VAULT_SERVER, VAULT_TOKEN).unwrap();
    assert!(matches!(
        client.status().await.unwrap(),
        vaultrs::sys::ServerStatus::OK
    ));

    let got_secret: WalletSecret = kv2::read(&client, "secret", VAULT_PK_K256).await.unwrap();
    let got_sk = SigningKey::from_slice(got_secret.secret()).unwrap();

    // let any = Any::pack(&got_secret.secret).unwrap();
    // let sk = MessageExt::from_any(got_secret.secret.into());
    // let sk = hex::encode(got_secret.secret.as_slice());
    // let sk = "7f7507bd29fc0726add5132c6a85e31f5476a6941510d69b0f6d35ed6d3d84fa";
    let mut wallet = Wallet::from_private_key_bytes(
        &mut gcp_client,
        Vec::from(got_secret.secret()),
        CHAIN_PREFIX,
        CoinType::Cosmos,
        Decimal::from_str("0.120").unwrap(), // Gas_price
        Decimal::from_str("2.0").unwrap(),   // Gas adjustment
        STAKE_DENOM,                         // Gas denom
    )
    .await
    .unwrap();

    let msg = MsgSend {
        from_address: wallet.account_address(),
        to_address: VAULT_ACCT1.to_string(),
        amount: vec![ProtoCoin {
            denom: DENOM.to_string(),
            amount: "100".to_string(),
        }],
    }
    .to_any()
    .unwrap();

    let response = wallet
        .broadcast_tx(
            &mut gcp_client,
            vec![msg],           // Vec<Any>: list of msgs to broadcast
            None,                // memo: Option<String>
            None, // fee: Option<Fee>, if not provided the tx is simulated to calculate the fee
            BroadcastMode::Sync, // Broadcast mode; Block/Sync/Async
        )
        .await
        .unwrap();

    println!("response: {response:#?}")
}

#[tokio::test]
async fn it_string_secret() {
    let client = get_vault_client(VAULT_SERVER, VAULT_TOKEN).unwrap();
    assert!(matches!(
        client.status().await.unwrap(),
        vaultrs::sys::ServerStatus::OK
    ));

    let secret = StringSecret::new("public".to_string(), "private".to_string());

    kv2::set(&client, "secret", "mystringsecret", &secret)
        .await
        .unwrap();

    let got_secret: StringSecret = kv2::read(&client, "secret", "mystringsecret")
        .await
        .unwrap();

    assert_eq!(secret, got_secret);
}

#[tokio::test]
async fn it_binary_secret() {
    let client = get_vault_client(VAULT_SERVER, VAULT_TOKEN).unwrap();
    assert!(matches!(
        client.status().await.unwrap(),
        vaultrs::sys::ServerStatus::OK
    ));

    let secret = BinarySecret::new("public".to_string(), "private".as_bytes().to_vec());

    kv2::set(&client, "secret", "mybinarysecret", &secret)
        .await
        .unwrap();

    let got_secret: BinarySecret = kv2::read(&client, "secret", "mybinarysecret")
        .await
        .unwrap();

    assert_eq!(secret, got_secret);
}

#[tokio::test]
async fn it_full_binary_secret() {
    let client = get_vault_client(VAULT_SERVER, VAULT_TOKEN).unwrap();
    assert!(matches!(
        client.status().await.unwrap(),
        vaultrs::sys::ServerStatus::OK
    ));

    let secret = FullBinarySecret::new("public".as_bytes().to_vec(), "private".as_bytes().to_vec());

    kv2::set(&client, "secret", "myfullbinarysecret", &secret)
        .await
        .unwrap();

    let got_secret: FullBinarySecret = kv2::read(&client, "secret", "myfullbinarysecret")
        .await
        .unwrap();

    assert_eq!(secret, got_secret);
}
