use vaultrs::client::{VaultClient, VaultClientSettingsBuilder};

pub mod sdk;
pub mod sdk_ed25519;

pub fn get_vault_client(server: &str, token: &str) -> anyhow::Result<VaultClient> {
    let client = VaultClient::new(
        VaultClientSettingsBuilder::default()
            .address(server)
            .token(token) // TODO: Is it used?
            .build()
            .unwrap(),
    )
    .unwrap();
    Ok(client)
    // println!("client status: {:?}", client.status().await.unwrap())
}
