use cosmrs::crypto::secp256k1::SigningKey as CosmrsSigningKey;
// use cosmrs::bip32::secp256k1::{Secp256k1};
use cosmrs::bip32::{PrivateKey};
// use cosmrs::bip32::secp256k1::elliptic_curve::generic_array::ArrayLength;
// use cosmrs::bip32::secp256k1::elliptic_curve::ops::Invert;
// use cosmrs::bip32::secp256k1::elliptic_curve::point::PointCompression;
// use cosmrs::bip32::secp256k1::elliptic_curve::sec1::{FromEncodedPoint, ToEncodedPoint};
// use cosmrs::bip32::secp256k1::elliptic_curve::subtle::CtOption;
use cosmrs::crypto::secp256k1::Signature as CosmrsSignature;
use ecdsa::elliptic_curve::generic_array::ArrayLength;
use ecdsa::elliptic_curve::ops::Invert;
use ecdsa::elliptic_curve::point::PointCompression;
use ecdsa::elliptic_curve::sec1::{FromEncodedPoint, ModulusSize, ToEncodedPoint};
use ecdsa::elliptic_curve::subtle::CtOption;
use ecdsa::elliptic_curve::{
    AffinePoint, CurveArithmetic, FieldBytesSize, PrimeCurve, Scalar,
};
use ecdsa::signature::{Signer, Verifier};
use ecdsa::{
    Signature as EcdsaSignature, SignatureSize, SigningKey as EcdsaSigningKey,
    VerifyingKey as EcdsaVerifyingKey,
};
use k256::Secp256k1;
use p256::NistP256;
use crate::get_vault_client;
use ecdsa::hazmat::{DigestPrimitive, SignPrimitive, VerifyPrimitive};
use rand_core::OsRng;
use serde::{Deserialize, Serialize};
use vaultrs::client::{VaultClient};
use vaultrs::kv2;

pub type K256SigningKey = EcdsaSigningKey<Secp256k1>;
pub type P256SigningKey = EcdsaSigningKey<NistP256>;
#[derive(Debug, Serialize, Deserialize, PartialEq)]
pub struct WalletSecret {
    secret: Vec<u8>,
}
impl WalletSecret {
    pub fn new(secret: Vec<u8>) -> Self {
        Self { secret }
    }

    pub fn secret(&self) -> &[u8] {
        &self.secret
    }
}
pub struct SDK<'a, C>
where
    C: PrimeCurve + CurveArithmetic,
{
    pub vault_client: VaultClient,
    pub vault_store: &'a str,
    marker: std::marker::PhantomData<C>,
}

impl<'a, C> SDK<'a, C>
where
    C: PrimeCurve + CurveArithmetic + PointCompression + DigestPrimitive,
    Scalar<C>: Invert<Output = CtOption<Scalar<C>>> + SignPrimitive<C>,
    SignatureSize<C>: ArrayLength<u8>,
    AffinePoint<C>: FromEncodedPoint<C> + ToEncodedPoint<C> + VerifyPrimitive<C>,
    FieldBytesSize<C>: ModulusSize,
{
    pub fn new(address: &str, token: &str, store: &'a str) -> Self {
        let client = get_vault_client(address, token).unwrap();

        Self {
            vault_client: client,
            vault_store: store,
            marker: std::marker::PhantomData,
        }
    }

    pub async fn k256_generate_key_pair(&self) -> anyhow::Result<String> {
        /*
        Note: cosmrs_sk cannot be serialized to bytes as is.
            So we use k256 instead.
         */
        // let cosmrs_sk = CosmrsSigningKey::random();
        // let cosmrs_pk = cosmrs_sk.public_key();
        // let cosmrs_pk = cosmrs_pk.to_bytes();
        // this fails: cosmrs_sk.to_bytes().expect("TODO: panic message");

        let sk = K256SigningKey::random(&mut OsRng);
        let vk = sk.verifying_key();
        let pk: Vec<u8> = vk.to_encoded_point(true).to_bytes().to_vec();
        let pk = hex::encode(pk);

        let secret = WalletSecret::new(sk.to_bytes().to_vec());

        kv2::set(&self.vault_client, self.vault_store, pk.as_str(), &secret)
            .await
            .unwrap();

        Ok(pk)
    }

    pub async fn cosmrs_sign(&self, pk: &str, msg: &[u8]) -> anyhow::Result<CosmrsSignature> {
        // let secret: WalletSecret = kv2::read(&self.vault_client, &self.vault_store, pk).await.unwrap();
        // let sk = CosmrsSigningKey::from_slice(secret.secret()).unwrap();
        let sk = self.cosmrs_signing_key(pk).await.unwrap();

        sk.sign(msg)
            .map_err(|e| anyhow::Error::msg(format!("sign error: {}", e)))
    }

    // TODO: This function should be protected.
    pub async fn cosmrs_signing_key(&self, pk: &str) -> anyhow::Result<CosmrsSigningKey> {
        let secret = kv2::read::<WalletSecret>(&self.vault_client, self.vault_store, pk)
            .await
            .unwrap();

        let sk = CosmrsSigningKey::from_slice(secret.secret()).unwrap();

        Ok(sk)
    }
    pub async fn k256_sign_and_verify(
        &self,
        pk: &str,
        msg: &[u8],
    ) -> anyhow::Result<CosmrsSignature> {
        let secret: WalletSecret = kv2::read(&self.vault_client, self.vault_store, pk)
            .await
            .unwrap();

        let sk = K256SigningKey::from_slice(secret.secret()).unwrap();
        let vk = sk.public_key();

        let sig = <ecdsa::SigningKey<Secp256k1> as Signer<CosmrsSignature>>::sign(&sk, msg);
        assert!(vk.verify(msg, &sig).is_ok());

        Ok(sig)
    }

    pub async fn generate_key_pair(&self) -> anyhow::Result<String> {
        let sk: EcdsaSigningKey<C> = EcdsaSigningKey::random(&mut OsRng);
        let vk: &EcdsaVerifyingKey<C> = sk.verifying_key();
        let pk: Vec<u8> = vk.to_encoded_point(true).to_bytes().to_vec();
        let pk = hex::encode(pk);

        let secret = WalletSecret::new(sk.to_bytes().to_vec());

        kv2::set(&self.vault_client, self.vault_store, pk.as_str(), &secret)
            .await
            .unwrap();

        Ok(pk)
    }

    pub async fn sign_and_verify(&self, pk: &str, msg: &[u8]) -> anyhow::Result<EcdsaSignature<C>> {
        let secret: WalletSecret = kv2::read(&self.vault_client, self.vault_store, pk)
            .await
            .unwrap();

        let sk: EcdsaSigningKey<C> = EcdsaSigningKey::from_slice(secret.secret()).unwrap();
        let vk: &EcdsaVerifyingKey<C> = sk.verifying_key();

        let got_pk = vk.to_encoded_point(true).to_bytes().to_vec();
        /*
        It is important to verify pk and got_pk are the same.
        Without such verification, we could get into a mixup of different curves.
        For example, pk is from P256 and got_pk is from secp256k1 since the user could use a
        K256 SDK to sign and verify even though the original pk is from P256.
         */
        assert_eq!(pk, hex::encode(got_pk));

        let sig = <EcdsaSigningKey<C> as Signer<EcdsaSignature<C>>>::sign(&sk, msg);
        assert!(
            <EcdsaVerifyingKey<C> as Verifier<EcdsaSignature<C>>>::verify(vk, msg, &sig).is_ok()
        );

        Ok(sig)
    }
}
