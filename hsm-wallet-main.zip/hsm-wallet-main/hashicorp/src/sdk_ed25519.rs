use crate::get_vault_client;
use crate::sdk::WalletSecret;
use ed25519_dalek::{Signature, Signer, SigningKey, Verifier};
use rand::Rng;
use vaultrs::client::VaultClient;
use vaultrs::kv2;

pub struct SDK<'a> {
    pub vault_client: VaultClient,
    pub vault_store: &'a str,
}

impl<'a> SDK<'a> {
    pub fn new(address: &str, token: &str, store: &'a str) -> Self {
        let client = get_vault_client(address, token).unwrap();

        Self {
            vault_client: client,
            vault_store: store,
        }
    }

    pub async fn generate_key_pair(&self) -> anyhow::Result<String> {
        let mut rng = rand::thread_rng();

        let sk = SigningKey::from_bytes(&rng.gen());
        let pk = sk.verifying_key().to_bytes();
        let pk = hex::encode(pk);
        let secret = WalletSecret::new(sk.to_bytes().to_vec());

        kv2::set(&self.vault_client, self.vault_store, pk.as_str(), &secret)
            .await
            .unwrap();

        Ok(pk)
    }

    pub async fn sign_and_verify(&self, pk: &str, msg: &str) -> anyhow::Result<Signature> {
        let secret = kv2::read::<WalletSecret>(&self.vault_client, self.vault_store, pk)
            .await
            .unwrap();
        let bytes = secret.secret().to_vec();
        let sk: SigningKey =
            SigningKey::from_bytes(&bytes.try_into().map_err(|_| anyhow::Error::msg(""))?);

        let sig = sk.sign(msg.as_bytes());

        let vk = sk.verifying_key();
        assert_eq!(pk, hex::encode(vk.to_bytes()));

        vk.verify(msg.as_bytes(), &sig).unwrap();

        Ok(sig)
    }
}
