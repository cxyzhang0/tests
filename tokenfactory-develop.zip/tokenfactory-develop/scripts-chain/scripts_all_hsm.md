## build 
```shell
# build binary into ./bin
make build

# install binary into $GOPATH/bin
make install
```
## test
```shell
# gentle start
./bin/tfd --home ./scripts-chain/play_all_hsm.sh/tokenfactory-1 start --pruning=nothing --minimum-gas-prices=0.001uwfUSD --grpc-web.enable=false --grpc.address="0.0.0.0:9090" --trace --log_level=trace
# destructive start
./scripts-chain/play_all_hsm.sh
```

## set up environment
```shell
source ./scripts-chain/chains_all_hsm.env

# use arrays and it works. but arrays for single value is weird - ./scripts-chain/chains_wallet_tmkms.env is more straightforward.
alias tfd=./bin/tfd
BINARY="./bin/tfd"
CHAIN_ID="tokenfactory-1"
CHAIN_DIR="./scripts-chain/play_all_hsm_sh"
NODE_CHAIN=(--node=tcp://localhost:26657)
KEYRING=(--keyring-backend=test)

HOME_DIR="$CHAIN_DIR/$CHAIN_ID"
NODE_HOME=(--home=$HOME_DIR)

NODE_CHAIN_ID=(--chain-id=$CHAIN_ID)

alias BINARY="$BINARY ${NODE_HOME[@]} ${NODE_CHAIN[@]}"

GAS_PRICE="0.001uwfUSD"
GAS=(--gas-prices "$GAS_PRICE" --gas "auto" --gas-adjustment 2.0)
GAS_NO_AUTO=(--gas-prices "$GAS_PRICE" --gas-adjustment 2.0)

# multiple flages/args in TXFLAG: use array for desired expansion in RES=$(tfd tx wasm ... "${TXFLAG[@]}" ...)
TXFLAG=("${KEYRING[@]}" "${NODE_CHAIN_ID[@]}" "${NODE_HOME[@]}" "${GAS[@]}" "${NODE_CHAIN[@]}") # for tx other than tx wasm store: use gas=auto.
TXFLAG_NO_AUTO=("${KEYRING[@]}" "${NODE_CHAIN_ID[@]}" "${NODE_HOME[@]}" "${GAS_NO_AUTO[@]}" "${NODE_CHAIN[@]}")# for tx other than tx wasm store: use gas=auto.
#TXFLAG=(--chain-id "$CHAIN_ID" --gas-prices "0.001uwfUSD" --gas "auto" --gas-adjustment 2.0 "$NODE_CHAIN") # for tx other than tx wasm store: use gas=auto.


# multiple flages/args in TXFLAG_LG_GAS: use array for desired expansion in RES=$(tfd tx wasm ... "${TXFLAG_LG_GAS[@]}" ...)
TXFLAG_LG_GAS=("${NODE_CHAIN_ID[@]}" --gas-prices "$GAS_PRICE" --gas "2000000" "${NODE_CHAIN[@]}") # for tx wasm store: we set a large gas limit here to avoid out of gas errors.

```

## tx signer
```shell
SOFTHSM2_PIN=5678 $KMS_TOOL -c /Users/johnz/Project/rust/kmstool/config.toml txsigner txsign \
  /Users/johnz/Project/go/cosmos/noblefork/scripts-offline-sign/unsigned-feegrant.json \
  --output-json /Users/johnz/Project/go/cosmos/noblefork/scripts-offline-sign/signed-feegrant.json \
  --chain-bin /Users/johnz/Project/go/cosmos/noblefork/bin/tfd \
  --chain-id tokenfactory-1 \
  --account-number 0 \
  --sequence 0 \
  --kl "Slot Token 0/wfdc2/faucet/1"

SOFTHSM2_PIN=5678 $KMS_TOOL -c /Users/johnz/Project/rust/kmstool/config.toml txsigner txsign \
  /Users/johnz/Project/go/cosmos/noblefork/scripts-offline-sign/unsigned-send.json \
  --output-json /Users/johnz/Project/go/cosmos/noblefork/scripts-offline-sign/signed-send.json \
  --chain-bin /Users/johnz/Project/go/cosmos/noblefork/bin/tfd \
  --chain-id tokenfactory-1 \
  --account-number 1 \
  --sequence 1 \
  --kl "Slot Token 0/tf/val1/1"




```

## validator set
```shell
tfd query staking validators $NODE_HOME --output json | jq
tfd tendermint show-validator $NODE_HOME

# normally, uwfUSD should be minted. but for quick testing of send, we directly send some uwfUSD from validator to users
#tfd tx bank send $VALIDATOR $USER1 1000uwfUSD "${TXFLAG[@]}" -y -b sync
#tfd tx bank send validator $USER1 1000uwfUSD "${TXFLAG[@]}" -y -b sync 
#tfd tx bank send validator $USA 1000uwfUSD "${TXFLAG[@]}" -y -b sync 

# balances
BINARY q bank balances $FAUCET
BINARY q bank balances $HSM_VALIDATOR
BINARY q bank balances $VALIDATOR
BINARY q bank balances $TF_OWNER
BINARY q bank balances $MASTERMINTER
BINARY q bank balances $MINTERCONTROLLER
BINARY q bank balances $MINTER
BINARY q bank balances $BLACKLISTER
BINARY q bank balances $PASER

BINARY q bank balances $USA
BINARY q bank balances $CAN
BINARY q bank balances $USER1
BINARY q bank balances $USER1_FX
BINARY q bank balances $USER2
BINARY q bank balances $USER2_FX
BINARY q bank balances $MINTER
BINARY q bank balances $PAUSER

tfd q bank total $NODE_CHAIN

tfd q bank denom-metadata uwfUSD $NODE_CHAIN

grpcurl -plaintext localhost:9090 cosmos.bank.v1beta1.Query/DenomsMetadata
# query tx
BINARY q tx 248C3F3A575D3B68490CDB1D56A81AA275BD53FB9A35FA43D2CB54617D48634A -o json | jq '{txhash: .txhash, tx: .tx.body.messages, gas_limit: .gas_wanted, gas_used: .gas_used, fee: .tx.auth_info.fee.amount[0], code: .code, raw_log: .raw_log, logs: .logs}'
 

# query tokenfactory
## roles
### params
BINARY q tokenfactory params

### owner: one per tokenfactory
BINARY q tokenfactory show-owner

### masterminter: one per tokenfactory
BINARY q tokenfactory show-master-minter

### mintercontroller: each address can be only once per tokenfactory, i.e., the pair (controller, minter) is unique in controller
BINARY q tokenfactory show-minter-controller $MINTERCONTROLLER
## bug: query result is independent of controller address
BINARY q tokenfactory list-minter-controller $MINTERCONTROLLER

### minting denom
BINARY q tokenfactory show-minting-denom uwfUSD

### minter: always paired with a mintercontroller
BINARY q tokenfactory show-minters $MINTER
## bug: query result is independent of controller address; this may be all minters
BINARY q tokenfactory list-minters $MINTERCONTROLLER

### blacklister: one per tokenfactory
BINARY q tokenfactory show-blacklister

### pauser: one per tokenfactory
BINARY q tokenfactory show-pauser
## states
BINARY q tokenfactory show-blacklisted $USER
BINARY q tokenfactory list-blacklisted $BLACKLISTER

BINARY q tokenfactory show-paused

# ***** NO tx can be executed via daemon because the keys are in HSM
# tx tokenfactory 
## owner
## TODO: update-owner does not change the owner
tfd tx tokenfactory update-owner $TF2_OWNER --from tf1_owner $NODE_CHAIN $NODE_HOME $KEYRING -y # --trace --log_level=trace
## TODO: Error: unknown command "noble1h8jmqsfl4mlmaqmul3malxtmsmzcved9e0sdmg" for "nobled tx tokenfactory accept-owner"
tfd tx tokenfactory accept-owner $TF2_OWNER --from tf1_owner $NODE_CHAIN $NODE_HOME $KEYRING -y # --trace --log_level=trace

## masterminter
tfd tx tokenfactory update-master-minter $USER --from tf1_owner $NODE_CHAIN $NODE_HOME $KEYRING -y
tfd tx tokenfactory update-master-minter $MASTERMINTER --from tf1_owner $NODE_CHAIN $NODE_HOME $KEYRING -y

## mintercontroller
tfd tx tokenfactory configure-minter-controller $MINTERCONTROLLER $USER --from masterminter $NODE_CHAIN $NODE_HOME $KEYRING -y
tfd tx tokenfactory configure-minter-controller $MINTERCONTROLLER $MINTER --from masterminter $NODE_CHAIN $NODE_HOME $KEYRING -y
tfd tx tokenfactory configure-minter-controller $USER $MINTER --from masterminter $NODE_CHAIN $NODE_HOME $KEYRING -y

tfd tx tokenfactory remove-minter-controller $USER --from masterminter $NODE_CHAIN $NODE_HOME $KEYRING -y

## minter
tfd tx tokenfactory configure-minter $MINTER 10000uwfusd --from mintercontroller $NODE_CHAIN $NODE_HOME $KEYRING -y

tfd tx tokenfactory remove-minter $MINTER --from mintercontroller $NODE_CHAIN $NODE_HOME $KEYRING -y

tfd tx tokenfactory configure-minter $MINTER 1000uwfusd --from mintercontroller $NODE_CHAIN $NODE_HOME $KEYRING -y

## blacklister and blacklist
tfd tx tokenfactory update-blacklister $USER --from tf1_owner $NODE_CHAIN $NODE_HOME $KEYRING -y

tfd tx tokenfactory update-blacklister $BLACKLISTER --from tf1_owner $NODE_CHAIN $NODE_HOME $KEYRING -y

tfd tx tokenfactory blacklist $USER --from blacklister $NODE_CHAIN $NODE_HOME $KEYRING -y

tfd tx tokenfactory unblacklist $USER --from blacklister $NODE_CHAIN $NODE_HOME $KEYRING -y

## pauser and pause
tfd tx tokenfactory update-pauser $USER --from tf1_owner $NODE_CHAIN $NODE_HOME $KEYRING -y

tfd tx tokenfactory update-pauser $PAUSER --from tf1_owner $NODE_CHAIN $NODE_HOME $KEYRING -y

tfd tx tokenfactory pause --from pauser $NODE_CHAIN $NODE_HOME $KEYRING -y

tfd tx tokenfactory unpause --from pauser $NODE_CHAIN $NODE_HOME $KEYRING -y

## mint and burn
tfd tx tokenfactory mint $USER 10uwfusd --from minter $NODE_CHAIN $NODE_HOME $KEYRING -y

tfd tx bank send $USER $MINTER 10uwfusd --from user $NODE_CHAIN $NODE_HOME $KEYRING -y
tfd tx tokenfactory burn 10uwfusd --from minter $NODE_CHAIN $NODE_HOME $KEYRING -y
```

## run cosmwasm tokenfactory contract
```shell
# upload wasm code and get $CODE_ID: two steps
FILE=../../../rust/cosmos/wfdc2/target/wasm32-unknown-unknown/release/tokenfactory_optimized.wasm
STORE=$(BINARY tx wasm store $FILE --from validator "${TXFLAG[@]}" -y -b sync --output json) && \
TX_HASH=$(echo $STORE | jq -r '.txhash') && \
echo "$TX_HASH" && \
sleep 5 && \
TX=$(BINARY q tx $TX_HASH --output json) && \
CODE_ID=$(echo $TX | jq -r '.events[] | select(.type=="store_code") | .attributes[] | select(.key=="code_id") | .value') && \
echo $CODE_ID

# 1

# instantiate and get CONTRACT_ADDRESS: two steps
INIT=$(jq -n --arg is_tf "true" '{ "is_tf": $is_tf | test("true") }') && \
echo $INIT && \
RES=$(BINARY tx wasm instantiate $CODE_ID "$INIT" --from validator --label "tf" --no-admin "${TXFLAG[@]}" -y --output json) && \
sleep 5 && \
CONTRACT_ADDRESS=$(BINARY query wasm list-contract-by-code $CODE_ID --output json | jq -r '.contracts[-1]') && \
echo $CONTRACT_ADDRESS

## or
TX_HASH=$(echo $RES | jq -r '.txhash') && \
CONTRACT_ADDRESS=$(BINARY q tx $TX_HASH -o json | jq -r '.events[] | select(.type=="wasm") | .attributes[] | select(.key=="_contract_address") | .value') && \
echo $CONTRACT_ADDRESS

## wf14hj2tavq8fpesdwxxcu44rty3hh90vhujrvcmstl4zr3txmfvw9s2s4a5q from code 1

# queries
## config raw data
BINARY q wasm contract-state raw $CONTRACT_ADDRESS "config" --ascii 
tfd q wasm contract-state raw $CONTRACT_ADDRESS "config" --ascii 

JSON=$(jq -n '{ config: {} }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n '{ tf: { params: {} } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n '{ tf: { owner: {} } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n '{ tf: { master_minter: {} } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n --arg address "$MINTERCONTROLLER" '{ tf: { minter_controller: { address: $address } } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n '{ tf: { all_minter_controllers: {} } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n --arg address "$MINTER" '{ tf: { minting_denom: {} } }') && \
echo $JSON && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n --arg address "$MINTER" '{ tf: { minters: { address: $address } } }') && \
echo $JSON && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n '{ tf: { all_minters: {} } }') && \
echo $JSON && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n '{ tf: { blacklister: {} } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

## being empty shows some error
JSON=$(jq -n --arg address "$USER" '{ tf: { blacklisted: { address: $address } } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

## being empty shows some error
JSON=$(jq -n '{ tf: { all_blacklisted: {} } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n '{ tf: { pauser: {} } }') && \
echo $JSON && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n '{ tf: { paused: {} } }') && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

## denom_metadata
JSON=$(jq -n --arg denom "cent" '{ bank: { denom_metadata: { denom: $denom} } }') && \
echo $JSON && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n --arg denom "uwfusd" '{ bank: { denom_metadata: { denom: $denom} } }') && \
echo $JSON && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

## all_denom_metadata
JSON=$(jq -n  '{ bank: { all_denom_metadata: { } } }') && \
echo $JSON && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

## find_denom_metadata
JSON=$(jq -n --arg base_denom "cent" --arg denom "USD" '{ bank: { find_denom_metadata: { base_denom: $base_denom, denom: $denom} } }') && \
echo $JSON && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n --arg base_denom "uwfusd" --arg denom "wfusd" '{ bank: { find_denom_metadata: { base_denom: $base_denom, denom: $denom} } }') && \
echo $JSON && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

## find_metadata_for_denom
JSON=$(jq -n --arg denom "USD" '{ bank: { find_metadata_for_denom: { denom: $denom} } }') && \
echo $JSON && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n --arg denom "wfusd" '{ bank: { find_metadata_for_denom: { denom: $denom} } }') && \
echo $JSON && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

JSON=$(jq -n --arg granter "$FAUCET" --arg grantee "$OWNER" '{ feegrant: { fee_basic_allowance: { "granter": $granter, "grantee": $grantee } } }') && \
echo $JSON && \
tfd query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" $NODE_CHAIN --output json | jq

# ***** NO tx can be executed via daemon because the keys are in HSM
# execute txs
## update_master_minter
#JSON=$(jq -n --arg address "$USER" \
JSON=$(jq -n --arg address "$MASTERMINTER" \
'{ "update_master_minter": { "address": $address } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from tf1_owner $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

## configure_minter_controller
JSON=$(jq -n --arg controller "$MINTERCONTROLLER" --arg minter "$MINTER" \
'{ "configure_minter_controller": { "controller": $controller, "minter": $minter } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from masterminter $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

## remove_minter_controller
JSON=$(jq -n --arg controller "$MINTERCONTROLLER" \
'{ "remove_minter_controller": { "controller": $controller } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from masterminter $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

## configure_minter
JSON=$(jq -n --arg address "$MINTER" --arg allowance_denom "uwfusd" --arg allowance_value 500 \
'{ "configure_minter": { "address": $address, "allowance_denom": $allowance_denom, "allowance_value": $allowance_value | tonumber } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from mintercontroller $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

## remove_minter
JSON=$(jq -n --arg address "$MINTER" \
'{ "remove_minter": { "address": $address } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from mintercontroller $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

## update_blacklister
JSON=$(jq -n --arg address "$BLACKLISTER" \
'{ "update_blacklister": { "address": $address } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from tf1_owner $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

## blacklist
JSON=$(jq -n --arg address "$USER" \
'{ "blacklist": { "address": $address } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from blacklister $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

## unblacklist
JSON=$(jq -n --arg address "$USER" \
'{ "unblacklist": { "address": $address } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from blacklister $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

## update_pauser
JSON=$(jq -n --arg address "$PAUSER" \
'{ "update_pauser": { "address": $address } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from tf1_owner $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

## pause
JSON=$(jq -n \
'{ "pause": { } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from pauser $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

## unpause
JSON=$(jq -n \
'{ "unpause": { } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from pauser $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

## mint
### minting decreases minter's allowance
JSON=$(jq -n --arg address "$USER" --arg denom "uwfusd" --arg value 10 \
'{ "mint": { "address": $address, "denom": $denom, "value": $value | tonumber } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from minter $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $JSON && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq

## burn
### burning does not increase minter's allowance
tfd tx bank send $USER $MINTER 10uwfusd --from user $NODE_CHAIN $NODE_HOME $KEYRING -y

JSON=$(jq -n --arg address "$USER" --arg denom "uwfusd" --arg value 10 \
'{ "burn": { "denom": $denom, "value": $value | tonumber } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from minter $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq


# feegrant
## grant
## TODO: why any --from can do the grant.
JSON=$(jq -n --arg granter "$FAUCET" --arg grantee "$USER" --arg denom "stake" --arg value 1000000 --arg hours_to_expire 10 \
'{ feegrant: { "grant_fee_basic_allowance": 
{ "granter": $granter, "grantee": $grantee, "allowance_denom": $denom, 
"allowance_value": $value | tonumber, "hours_to_expire": $hours_to_expire | tonumber } } }') && \
RES=$(tfd tx wasm execute $CONTRACT_ADDRESS "$JSON" --from tf2_owner $NODE_HOME $KEYRING $TXFLAG -y --output json) && \
echo $RES | jq && \
sleep 5 && \
TX_HASH=$(echo $RES | jq -r '.txhash') && \
tfd q tx $TX_HASH $NODE_CHAIN --output json | jq


```

