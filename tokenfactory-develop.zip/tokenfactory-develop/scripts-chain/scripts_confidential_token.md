## scripts for confidential transfer wasm contract
### env variables
> refer to ./posa/scripts_poas.md for most of the chain related env variables
```shell
export FAUCET_ADDR=$(BINARY keys show faucet -a $KEYRING) && echo $FAUCET_ADDR
export OWNER_ADDR=$(BINARY keys show tf_owner -a $KEYRING) && echo $OWNER_ADDR
export MASTERMINTER_ADDR=$(BINARY keys show masterminter -a $KEYRING) && echo $MASTERMINTER_ADDR
export MINTERCONTROLLER_ADDR=$(BINARY keys show mintercontroller -a $KEYRING) && echo $MINTERCONTROLLER_ADDR
export MINTER_ADDR=$(BINARY keys show minter -a $KEYRING) && echo $MINTER_ADDR

BINARY q bank balances $FAUCET_ADDR
BINARY q bank balances $OWNER_ADDR
BINARY q bank balances $MASTERMINTER_ADDR
BINARY q bank balances $MINTERCONTROLLER_ADDR
BINARY q bank balances $MINTER_ADDR
```
### upload contract and instantiate contract
```shell
# upload contract and get CODE_ID: two steps
FILE=/Users/johnz/Project/rust/cosmos/confidential-transfer-cosmwasm/artifacts/confidential_transfer_cosmwasm.wasm
STORE=$(BINARY tx wasm store $FILE --from tf_owner  "${FLAGS[@]}" -y -b sync --output json) && \
TX_HASH=$(echo $STORE | jq -r '.txhash') && \
echo "$TX_HASH" && \
sleep 5 && \
TX=$(BINARY q tx $TX_HASH --output json) && \
CODE_ID=$(echo $TX | jq -r '.events[] | select(.type=="store_code") | .attributes[] | select(.key=="code_id") | .value') && \
echo $CODE_ID

BINARY q tx $TX_HASH -o json | jq '{tx: .tx.body.messages, gas_limit: .gas_wanted, gas_used: .gas_used, fee: .tx.auth_info.fee.amount[0], raw_log: .raw_log, logs: .logs}'

# instantiate and get CONTRACT_ADDRESS: two steps
## InstantiateMsg expects key to be Binary. In json, we represent Binary as a base64-encoded string.
INIT=$(jq -n --arg mint_encryption_key "qiQy/w/pvUAYOGSlIRFtBdCzqZ2U+uFsfZ/a8S2mo3o=" --argjson allowed_addresses "[\"$USER1_ADDR\", \"$USER2_ADDR\", \"$OWNER_ADDR\", \"$MINTER_ADDR\", \"$FAUCET_ADDR\"]" '
{ "mint_encryption_key": { "key": $mint_encryption_key }, "allowed_addresses": $allowed_addresses }
') && \
#do we need | @base64d? INIT=$(jq -n --arg mint_encryption_key "qiQy/w/pvUAYOGSlIRFtBdCzqZ2U+uFsfZ/a8S2mo3o=" '{ "mint_encryption_key": { "key": $mint_encryption_key | @base64d }, "allowed_addresses": [] }') && \
#hex INIT=$(jq -n --arg mint_encryption_key "aa2432ff0fe9bd40183864a521116d05d0b3a99d94fae16c7d9fdaf12da6a37a" '{ "mint_encryption_key": { "key": $mint_encryption_key }, "allowed_addresses": [] }') && \
echo $INIT && \
RES=$(BINARY tx wasm instantiate $CODE_ID "$INIT" --from tf_owner --label "confidential_transfer_cosmwasm" --no-admin "${FLAGS[@]}" -y --output json) && \
sleep 5 && \
CONTRACT_ADDRESS=$(BINARY query wasm list-contract-by-code $CODE_ID $NODE_CHAIN --output json | jq -r '.contracts[-1]') && \
echo $CONTRACT_ADDRESS

## or
TX_HASH=$(echo $RES | jq -r '.txhash') && \
CONTRACT_ADDRESS=$(BINARY q tx $TX_HASH -o json | jq -r '.events[] | select(.type=="wasm") | .attributes[] | select(.key=="_contract_address") | .value') && \
echo $CONTRACT_ADDRESS

BINARY q tx $TX_HASH -o json | jq '{tx: .tx.body.messages, gas_limit: .gas_wanted, gas_used: .gas_used, fee: .tx.auth_info.fee.amount[0], raw_log: .raw_log, logs: .logs}'

```
### query config
```shell
JSON=$(jq -n '{ get_config: {} }') && \
BINARY query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" --output json | jq

```

### create confidential account
```shell
# user1
JSON=$(jq -n --arg owner "$USER1_ADDR" --arg pubkey "qhjuBNbZSB4w2iQdyI/NL3xGUX037DL33r3d81ATM3Q=" '
{ "create_confidential_account": { "owner": $owner, "elgamal_pubkey": { "key": $pubkey }, "tx_id": 0 | tonumber } }') && \
RES=$(BINARY tx wasm execute $CONTRACT_ADDRESS "$JSON" --from user1 "${FLAGS[@]}" -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
BINARY q tx $TX_HASH -o json | jq '{txhash: .txhash, tx: .tx.body.messages, gas_limit: .gas_wanted, gas_used: .gas_used, fee: .tx.auth_info.fee.amount[0], raw_log: .raw_log, logs: .logs}'

# user2
JSON=$(jq -n --arg owner "$USER2_ADDR" --arg pubkey "humuK+o1fmqUHFZnzlzw76k8TrCrc7LSuezFY+OmASg=" '
{ "create_confidential_account": { "owner": $owner, "elgamal_pubkey": { "key": $pubkey }, "tx_id": 0 | tonumber } }') && \
RES=$(BINARY tx wasm execute $CONTRACT_ADDRESS "$JSON" --from user1 "${FLAGS[@]}" -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
BINARY q tx $TX_HASH -o json | jq '{txhash: .txhash, tx: .tx.body.messages, gas_limit: .gas_wanted, gas_used: .gas_used, fee: .tx.auth_info.fee.amount[0], raw_log: .raw_log, logs: .logs}'

BINARY q tx B93D13251756F76FC045ED11BAB4F905F6EA3C3E76E7EC15D6FF5907D2DF575F -o json | jq '{txhash: .txhash, tx: .tx.body.messages, gas_limit: .gas_wanted, gas_used: .gas_used, fee: .tx.auth_info.fee.amount[0], raw_log: .raw_log, logs: .logs}'

```
### query account
```shell
# user1
JSON=$(jq -n --arg owner "$USER1_ADDR" '
{ get_account: { "owner": $owner } }
') && \
BINARY query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" --output json | jq

# user2
JSON=$(jq -n --arg owner "$USER2_ADDR" '
{ get_account: { "owner": $owner } }
') && \
BINARY query wasm contract-state smart $CONTRACT_ADDRESS "$JSON" --output json | jq

```

### deposit
```shell
JSON=$(jq -n --arg owner "$USER1_ADDR" \
--argjson items '[{ "denom": "uwfUSD", "plain_amount": "1000" }]' \
'{ "deposit": { "owner": $owner, "items": $items, "tx_id": 2 | tonumber } }') && \
echo $JSON && \
RES=$(BINARY tx wasm execute $CONTRACT_ADDRESS "$JSON" --amount 1000uwfUSD --from user1 "${FLAGS[@]}" -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
BINARY q tx $TX_HASH -o json | jq '{txhash: .txhash, tx: .tx.body.messages, gas_limit: .gas_wanted, gas_used: .gas_used, fee: .tx.auth_info.fee.amount[0], raw_log: .raw_log, logs: .logs}'

BINARY q tx 13BFDBB12EF103475574C22771DAB0F0297ACD12054F7C26354911BAC6E28AE2 -o json | jq '{txhash: .txhash, tx: .tx.body.messages, gas_limit: .gas_wanted, gas_used: .gas_used, fee: .tx.auth_info.fee.amount[0], raw_log: .raw_log, logs: .logs}'

```

### confidential transfer
```shell
JSON=$(jq -n \
'
{
  "transfer_confidential": {
    "sender": "wf1ymtl6h7zxmyv6ugdn9v6deypmt706hums3hkl5",
    "recipient": "wf1n5esy5vqx5rt3d4wc6q0wuky7gws7xsh28kvv9",
    "denom": "uwfUSD",
    "transfer_proof_data": {
      "equality_proof_data": "qhjuBNbZSB4w2iQdyI/NL3xGUX037DL33r3d81ATM3SqvzdRHnkEkCSKv8oXMuLc0PJrGZ09qZEvP05+aeExNQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIKkVFBpB54OVaSMAJfV9rPStwCENE4cHsn12PVsV/AEMgbmVDql7iTa/MkVx6xzseD+L8u10/PRHSGIQEG44DABvCc2qhIdHG4dc0ziXY0uY2Ovm2K2HvrbrZ/EgV2sPCP4ulSY659a61ccynJPqPkayufuf3BGRrq5/sMzPqAaJvMn+evVylvNXQs4IQxzs0XbHc09UJSt+ZboWirI4D1O0mGz6/+jkYYM++fnRk1F8Jy9NPYX+woT7vo+HI40PqVlWom2Je/XOmtftr9gMKl311aHnJBDkD7eSIXld5A0=",
      "transfer_amount_ciphertext_validity_proof_data_with_ciphertext": "qhjuBNbZSB4w2iQdyI/NL3xGUX037DL33r3d81ATM3SG6a4r6jV+apQcVmfOXPDvqTxOsKtzstK57MVj46YBKCBwb9eIsnIKHtKl2tSVKwH0E7zw51ZN6M3IFmieLblfAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABionuJb4YyJ/HS1/K1OEFRJwfCEPDlwRsizlmraFGZ0DADb7NeVjIwxbZJ6UI2bw5GBdfD8+kiTUjtnfVz5WSkWXHWse/cCNp83369hPboI98zN6ZMz+znEbyfil8nsRiHZ6UWoG7bFpBFb5EwsiERA8Ng8f9QGMMaZofjKJVYMlgU6rl3T4CChfe46wwFNAcMOKUwPw1L2moAhP71i3A4=",
      "range_proof_data": "HocUgHRy5xt6Q0PdiylZRFDuabqmQuygesu5Xoe0tk308tGOdjoAyuwUCyao6zZj9xhwOobZc2SiTSCJJKfeXrRF8EAkpGYjRQq3ErPe1TNPpWR/7tefbgkfkUH6vg89pl0+EfSh0U/PpPU3ylFgwgbOScrGuyt8BnnSpSQUeE/4XOlv6WIM/EMYOE7HofVzQQR1I6Ar6XsIZFWM+hjjPmgnTLC94cCB5/Qws0fxxiQ8Kfjv91MrsaJd15YfFm8CLK0+ea5DT42P4QZHfZ67wgq1yGo5hlP0kD79yqIUtjLQ7MU7EJmgOuJI6iXWST5QRIVvLGQQERP8Z7Mwe1nGfhAQEBAQEBAQZMXRAaDrDYF2YSMCiDEU8EhvpUClz8Udoktjp129+BZUkLk3r2kzqV07oQoHLycl/JEhaZzQhEW20lTyJK/Ha7CN086zE86vIuc4kt/u1ROznH+2CzBc/vCajIXd1Wl79PQxv2G5nRv8YnPjuxGNSxBP6lFM4qJkTDyDv6AvRxLinka/89OINXmqBHJFieT67Vmrc9jKa5VnUf7awUpzBQIp6AqN79KEuABxhmP1xAu7egc8jLOh2CWX0ABlJAcPh5Gq1/LjI4YHlPJAkyCRr+X+5uS1y7nd0spasmWG8wwarLa8dTrYgA9LVqCok4n6TcyHUmUz/kf2Y3IEbttwGebDBRyPvDsHpMGXJyqCOJDiQ/oFrgKEmRaJY4iuEncIxNuegx4g/ilzruZx7jHhelJrKZ3XrfU8P0UeRP00yUh+blA6z8zoUuUeJlmlrCu96yY3I1n3UMtPo/B2ct4kJfYqCjG73Gh4TwBKC0kHTZZoBmXpfGZA+/W6kxnRSYEDnmYdkRW1Xpr7UVNDGtzUR6waW0qQkeQ4lhZWpre1u1bohtC/xDfXymGE1ITEcZ795zycSgSr5/cbDmVCLh7WahpCNsga0jSkVViAD/s025X9Wj3/0i+6uP1k+aI65SV6ZAoC5YyMm82ZsEP9kN2Bk1tYEgnQS38fiEm7raxHV2UU6b3SVAV/c25+VnNc6aUj7ferWR6vcpquweRp3b29Zyy7RVSTuiFDAMsJlZK6LHPHEn81iWhRvMAduWlSaGJU3KndfoQLFDIuHmBoRf4qS/I7uI3aqF8qeFncR7sBeDKSaHgYzOBmjSp3rnGc0m25cLCRNReOeu9hsRSYU2txDsgfdeZpKVe9u0LBnvw3TrNvzeBR715CGl0ZjXPNSA1JDu4QbZvPwQwXvDaotrtdjz1YRkVIUQatrRNWwevQzQ1kPKgYpISs0KwBNq/RW5KhHOBo9doBxEglDCTjX6KtCQ=="
    },
    "tx_id": 5,
    "use_offchain_verify": false,
    "sender_encrypted_amount": null,
    "recipient_encrypted_amount": null
  }
}
') && \
jq -n $JSON && \
RES=$(BINARY tx wasm execute $CONTRACT_ADDRESS "$JSON" --from user1 "${FLAGS[@]}" -y --output json) && \
echo $RES | jq

TX_HASH=$(echo $RES | jq -r '.txhash') && \
BINARY q tx $TX_HASH -o json | jq '{txhash: .txhash, tx: .tx.body.messages, gas_limit: .gas_wanted, gas_used: .gas_used, fee: .tx.auth_info.fee.amount[0], raw_log: .raw_log, logs: .logs}'

BINARY q tx 8F62FCA876F8EB02BAE2EE7B9A4BBA6A50F6629879FA3CB6FEE09E5EE9E8181D -o json | jq '{txhash: .txhash, tx: .tx.body.messages, gas_limit: .gas_wanted, gas_used: .gas_used, fee: .tx.auth_info.fee.amount[0], raw_log: .raw_log, logs: .logs, contract_tx_status: .events[] | select(.type=="wasm") | .attributes[] | select(.key=="tx_status") | .value, contract_error: .events[] | select(.type=="wasm") | .attributes[] | select(.key=="error") | .value }'

```