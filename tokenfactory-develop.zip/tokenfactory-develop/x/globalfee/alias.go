package globalfee

import (
	"github.com/wfblockchain/coreblockchain/v2/x/globalfee/types"
)

const (
	ModuleName = types.ModuleName
)
