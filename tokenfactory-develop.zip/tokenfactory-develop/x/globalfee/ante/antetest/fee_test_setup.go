package antetest

// gaiaapp "github.com/cosmos/gaia/v9/app"

// type IntegrationTestSuite struct {
// 	suite.Suite

// 	app       *gaiaapp.GaiaApp
// 	ctx       sdk.Context
// 	clientCtx client.Context
// 	txBuilder client.TxBuilder
// }

// func (s *IntegrationTestSuite) SetupTest() {
// 	app := gaiahelpers.Setup(s.T())
// 	ctx := app.BaseApp.NewContext(false, tmproto.Header{
// 		ChainID: fmt.Sprintf("test-chain-%s", tmrand.Str(4)),
// 		Height:  1,
// 	})

// 	encodingConfig := gaiaapp.MakeTestEncodingConfig()
// 	encodingConfig.Amino.RegisterConcrete(&testdata.TestMsg{}, "testdata.TestMsg", nil)
// 	testdata.RegisterInterfaces(encodingConfig.InterfaceRegistry)

// 	s.app = app
// 	s.ctx = ctx
// 	s.clientCtx = client.Context{}.WithTxConfig(encodingConfig.TxConfig)
// }

// func (s *IntegrationTestSuite) SetupTestGlobalFeeStoreAndMinGasPrice(minGasPrice []sdk.DecCoin, globalFeeParams *globfeetypes.Params) types.Subspace {
// 	subspace := s.app.GetSubspace(globalfee.ModuleName)
// 	subspace.SetParamSet(s.ctx, globalFeeParams)
// 	s.ctx = s.ctx.WithMinGasPrices(minGasPrice).WithIsCheckTx(true)

// 	return subspace
// }

// // SetupTestStakingSubspace sets uatom as bond denom for the fee tests.
// func (s *IntegrationTestSuite) SetupTestStakingSubspace(params stakingtypes.Params) types.Subspace {
// 	s.app.GetSubspace(stakingtypes.ModuleName).SetParamSet(s.ctx, &params)
// 	return s.app.GetSubspace(stakingtypes.ModuleName)
// }

// func (s *IntegrationTestSuite) CreateTestTx(privs []cryptotypes.PrivKey, accNums []uint64, accSeqs []uint64, chainID string) (xauthsigning.Tx, error) {
// 	var sigsV2 []signing.SignatureV2
// 	for i, priv := range privs {
// 		sigV2 := signing.SignatureV2{
// 			PubKey: priv.PubKey(),
// 			Data: &signing.SingleSignatureData{
// 				SignMode:  s.clientCtx.TxConfig.SignModeHandler().DefaultMode(),
// 				Signature: nil,
// 			},
// 			Sequence: accSeqs[i],
// 		}

// 		sigsV2 = append(sigsV2, sigV2)
// 	}

// 	if err := s.txBuilder.SetSignatures(sigsV2...); err != nil {
// 		return nil, err
// 	}

// 	sigsV2 = []signing.SignatureV2{}
// 	for i, priv := range privs {
// 		signerData := xauthsigning.SignerData{
// 			ChainID:       chainID,
// 			AccountNumber: accNums[i],
// 			Sequence:      accSeqs[i],
// 		}
// 		sigV2, err := tx.SignWithPrivKey(
// 			s.clientCtx.TxConfig.SignModeHandler().DefaultMode(),
// 			signerData,
// 			s.txBuilder,
// 			priv,
// 			s.clientCtx.TxConfig,
// 			accSeqs[i],
// 		)
// 		if err != nil {
// 			return nil, err
// 		}

// 		sigsV2 = append(sigsV2, sigV2)
// 	}

// 	if err := s.txBuilder.SetSignatures(sigsV2...); err != nil {
// 		return nil, err
// 	}

// 	return s.txBuilder.GetTx(), nil
// }
