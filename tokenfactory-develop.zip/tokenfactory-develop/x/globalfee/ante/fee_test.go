package ante_test

import (
	"github.com/cosmos/cosmos-sdk/types"
	globalfeetypes "github.com/wfblockchain/coreblockchain/v2/x/globalfee/ante"
)

type MockFeeDecorator struct {
	globalfeetypes.FeeDecorator
	GetBondDenomFunc func(ctx types.Context) string
}

// func TestDefaultZeroGlobalFee(t *testing.T) {
// 	db := db.NewMemDB()
// 	logger := log.NewNopLogger()
// 	storeMetrics := metrics.NewNoOpMetrics()
// 	cms := rootmulti.NewStore(db, logger, storeMetrics)

// 	// Mount and load stores
// 	storeKey := storetypes.NewKVStoreKey("params")
// 	cms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
// 	_ = cms.LoadLatestVersion()

// 	ctx := types.NewContext(cms, tmproto.Header{}, false, nil)

// 	mfd := &MockFeeDecorator{
// 		FeeDecorator: globalfeetypes.FeeDecorator{},
// 		GetBondDenomFunc: func(ctx types.Context) string {
// 			return "" // Simulating empty bond denom
// 		},
// 	}

// 	// Case 1: Bond denom is empty
// 	fees, err := mfd.DefaultZeroGlobalFee(ctx)
// 	require.Error(t, err, "Expected error when bond denom is empty")
// 	require.Equal(t, "empty staking bond denomination", err.Error(), "Error message mismatch")
// 	require.Nil(t, fees, "Expected nil fee when bond denom is empty")

// 	// Case 2: Valid bond denom
// 	mfd.GetBondDenomFunc = func(ctx types.Context) string {
// 		return "ubond" // Simulating a valid bond denom
// 	}

// 	fees, err = mfd.DefaultZeroGlobalFee(ctx)
// 	require.NoError(t, err, "Expected no error when bond denom is valid")
// 	require.Len(t, fees, 1, "Expected one fee coin in the result")
// 	require.Equal(t, "ubond", fees[0].Denom, "Denom should be 'ubond'")

// }
