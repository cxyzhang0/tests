package globalfee

import (
	"context"
	"encoding/json"
	"net/http"

	"cosmossdk.io/core/address"
	sdkerrors "cosmossdk.io/errors"
	abci "github.com/cometbft/cometbft/abci/types"
	"github.com/cosmos/cosmos-sdk/client"
	"github.com/cosmos/cosmos-sdk/codec"
	codectypes "github.com/cosmos/cosmos-sdk/codec/types"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/cosmos/cosmos-sdk/types/module"
	paramstypes "github.com/cosmos/cosmos-sdk/x/params/types"
	"github.com/gorilla/mux"
	"github.com/grpc-ecosystem/grpc-gateway/runtime"
	"github.com/spf13/cobra"

	"github.com/wfblockchain/coreblockchain/v2/x/globalfee/client/cli"
	"github.com/wfblockchain/coreblockchain/v2/x/globalfee/types"
)

// var (
//  _ module.AppModuleBasic   = AppModuleBasic{}
//  _ module.AppModuleGenesis = AppModule{}
//  _ module.AppModule        = AppModule{}
// )

type AppModuleBasic struct {
	cdc codec.Codec
	ac  address.Codec
}

// AppModuleBasic defines the basic application module used by the wasm module.

func (a AppModuleBasic) Name() string {
	return types.ModuleName
}

func (a AppModuleBasic) DefaultGenesis(cdc codec.JSONCodec) json.RawMessage {
	return cdc.MustMarshalJSON(&types.GenesisState{
		Params: types.DefaultParams(),
	})
}

func (a AppModuleBasic) ValidateGenesis(marshaler codec.JSONCodec, config client.TxEncodingConfig, message json.RawMessage) error {
	var data types.GenesisState
	if err := marshaler.UnmarshalJSON(message, &data); err != nil {
		return sdkerrors.Wrap(err, "failed to unmarshal genesis state")
	}
	if err := data.Params.ValidateBasic(); err != nil {
		return sdkerrors.Wrap(err, "params")
	}
	return nil
}

func (a AppModuleBasic) RegisterInterfaces(registry codectypes.InterfaceRegistry) {
	// Blank to satisfy AppModuleBasic interface
}

func (AppModuleBasic) RegisterRESTRoutes(_ client.Context, rtr *mux.Router) {
	// Register the POST route for /forwarding/register-account
	rtr.HandleFunc("/globalfee/register-account", PostRegisterAccountHandler).Methods(http.MethodPost)
}

func PostRegisterAccountHandler(w http.ResponseWriter, r *http.Request) {
	// Implement your handler logic for POST here
	// For testing, let's just write a success message to the response.
	w.Write([]byte("Registration successful"))
}

func (a AppModuleBasic) RegisterGRPCGatewayRoutes(clientCtx client.Context, mux *runtime.ServeMux) {
	_ = types.RegisterQueryHandlerClient(context.Background(), mux, types.NewQueryClient(clientCtx))
}

// func (a AppModuleBasic) GetTxCmd() *cobra.Command {
//  return nil
// }

// func (AppModuleBasic) GetTxCmd() *cobra.Command {
// 	return cli.GetTxCmd()
// }

func (a AppModuleBasic) GetQueryCmd() *cobra.Command {
	return cli.GetQueryCmd()
}

func (a AppModuleBasic) RegisterLegacyAminoCodec(amino *codec.LegacyAmino) {
	// Blank to satisfy AppModuleBasic interface
}

type AppModule struct {
	AppModuleBasic
	paramSpace paramstypes.Subspace
}

// IsAppModule implements the appmodule.AppModule interface.
func (AppModule) IsAppModule() {
	// Blank to satisfy AppModuleBasic interface
}

// IsOnePerModuleType implements the depinject.OnePerModuleType interface.
func (AppModule) IsOnePerModuleType() {
	// Blank to satisfy AppModuleBasic interface
}

// NewAppModule constructor
func NewAppModule(paramSpace paramstypes.Subspace) *AppModule {
	if !paramSpace.HasKeyTable() {
		paramSpace = paramSpace.WithKeyTable(types.ParamKeyTable())
	}

	return &AppModule{paramSpace: paramSpace}
}

func (a AppModule) InitGenesis(ctx sdk.Context, marshaler codec.JSONCodec, message json.RawMessage) []abci.ValidatorUpdate {
	var genesisState types.GenesisState
	marshaler.MustUnmarshalJSON(message, &genesisState)
	a.paramSpace.SetParamSet(ctx, &genesisState.Params)
	return nil
}

func (a AppModule) ExportGenesis(ctx sdk.Context, marshaler codec.JSONCodec) json.RawMessage {
	var genState types.GenesisState
	a.paramSpace.GetParamSet(ctx, &genState.Params)
	return marshaler.MustMarshalJSON(&genState)
}

func (a AppModule) RegisterInvariants(registry sdk.InvariantRegistry) {
	// Blank to satisfy AppModuleBasic interface
}

// func (a AppModule) Route() sdk.Route {
//  return sdk.Route{}
// }

// func (a AppModule) QuerierRoute() string {
//  return types.QuerierRoute
// }

// func (a AppModule) LegacyQuerierHandler(amino *codec.LegacyAmino) sdk.Querier {
//  return nil
// }

func (a AppModule) RegisterServices(cfg module.Configurator) {
	types.RegisterQueryServer(cfg.QueryServer(), NewGrpcQuerier(a.paramSpace))
}

func (a AppModule) BeginBlock(context sdk.Context, block abci.RequestFinalizeBlock) {
	// Blank to satisfy AppModuleBasic interface
}

func (a AppModule) EndBlock(context sdk.Context, block abci.RequestFinalizeBlock) []abci.ValidatorUpdate {
	return nil
}

// ConsensusVersion is a sequence number for state-breaking change of the
// module. It should be incremented on each consensus-breaking change
// introduced by the module. To avoid wrong/empty versions, the initial version
// should be set to 1.
func (a AppModule) ConsensusVersion() uint64 {
	return 1
}

// func NewAppModuleBasic(cdc codec.BinaryCodec) AppModuleBasic {
// 	return AppModuleBasic{cdc: cdc}
// }
