package globalfee

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"cosmossdk.io/log"
	"cosmossdk.io/math"
	"cosmossdk.io/store"
	"cosmossdk.io/store/metrics"
	storetypes "cosmossdk.io/store/types"
	abci "github.com/cometbft/cometbft/abci/types"
	tmproto "github.com/cometbft/cometbft/proto/tendermint/types"
	dbm "github.com/cosmos/cosmos-db"
	"github.com/cosmos/cosmos-sdk/client"
	"github.com/cosmos/cosmos-sdk/codec"
	codectypes "github.com/cosmos/cosmos-sdk/codec/types"
	sdk "github.com/cosmos/cosmos-sdk/types"
	sdktypes "github.com/cosmos/cosmos-sdk/types"
	moduletestutil "github.com/cosmos/cosmos-sdk/types/module/testutil"
	paramskeeper "github.com/cosmos/cosmos-sdk/x/params/keeper"
	paramstypes "github.com/cosmos/cosmos-sdk/x/params/types"
	"github.com/gorilla/mux"
	"github.com/grpc-ecosystem/grpc-gateway/runtime"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"github.com/wfblockchain/coreblockchain/v2/x/globalfee/types"
	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory"
)

func TestValidateGenesis(t *testing.T) {
	encCfg := moduletestutil.MakeTestEncodingConfig()
	specs := map[string]struct {
		src    string
		expErr bool
	}{
		"all good": {
			src: `{"params":{"minimum_gas_prices":[{"denom":"ALX", "amount":"1"}]}}`,
		},
		"empty minimum": {
			src: `{"params":{"minimum_gas_prices":[]}}`,
		},
		"minimum not set": {
			src: `{"params":{}}`,
		},
		"zero amount allowed": {
			src:    `{"params":{"minimum_gas_prices":[{"denom":"ALX", "amount":"0"}]}}`,
			expErr: false,
		},
		"duplicate denoms not allowed": {
			src:    `{"params":{"minimum_gas_prices":[{"denom":"ALX", "amount":"1"},{"denom":"ALX", "amount":"2"}]}}`,
			expErr: true,
		},
		"negative amounts not allowed": {
			src:    `{"params":{"minimum_gas_prices":[{"denom":"ALX", "amount":"-1"}]}}`,
			expErr: true,
		},
		"denom must be sorted": {
			src:    `{"params":{"minimum_gas_prices":[{"denom":"ZLX", "amount":"1"},{"denom":"ALX", "amount":"2"}]}}`,
			expErr: true,
		},
		"sorted denoms is allowed": {
			src:    `{"params":{"minimum_gas_prices":[{"denom":"ALX", "amount":"1"},{"denom":"ZLX", "amount":"2"}]}}`,
			expErr: false,
		},
	}
	for name, spec := range specs {
		t.Run(name, func(t *testing.T) {
			gotErr := AppModuleBasic{}.ValidateGenesis(encCfg.Codec, nil, []byte(spec.src))
			if spec.expErr {
				require.Error(t, gotErr)
				return
			}
			require.NoError(t, gotErr)
		})
	}
}

func TestInitExportGenesis(t *testing.T) {
	specs := map[string]struct {
		src string
		exp types.GenesisState
	}{
		"single fee": {
			src: `{"params":{"minimum_gas_prices":[{"denom":"ALX", "amount":"1"}],"bypass_min_fee_msg_types":[]}}`,
			exp: types.GenesisState{Params: types.Params{BypassMinFeeMsgTypes: []string{}, MinimumGasPrices: sdk.NewDecCoins(sdk.NewDecCoin("ALX", math.NewInt(1)))}},
		},
		"multiple fee options": {
			src: `{"params":{"minimum_gas_prices":[{"denom":"ALX", "amount":"1"}, {"denom":"BLX", "amount":"0.001"}]}}`,
			exp: types.GenesisState{Params: types.Params{BypassMinFeeMsgTypes: []string{}, MinimumGasPrices: sdk.NewDecCoins(sdk.NewDecCoin("ALX", math.NewInt(1)),
				sdk.NewDecCoinFromDec("BLX", math.LegacyNewDecWithPrec(1, 3)))}},
		},
		"no fee set": {
			src: `{"params":{}}`,
			exp: types.GenesisState{Params: types.Params{MinimumGasPrices: sdk.DecCoins{}, BypassMinFeeMsgTypes: []string{}}},
		},
	}
	for name, spec := range specs {
		t.Run(name, func(t *testing.T) {
			ctx, encCfg, subspace := setupTestStore(t)
			m := NewAppModule(subspace)
			m.InitGenesis(ctx, encCfg.Codec, []byte(spec.src))
			gotJSON := m.ExportGenesis(ctx, encCfg.Codec)
			var got types.GenesisState
			require.NoError(t, encCfg.Codec.UnmarshalJSON(gotJSON, &got))
			assert.Equal(t, spec.exp, got, string(gotJSON))
		})
	}
}

func TestAppModule_ConsensusVersion(t *testing.T) {
	appModule := AppModule{}
	version := appModule.ConsensusVersion()
	assert.Equal(t, uint64(1), version)
}

func setupTestStore(t *testing.T) (sdk.Context, moduletestutil.TestEncodingConfig, paramstypes.Subspace) {
	db := dbm.NewMemDB()
	ms := store.NewCommitMultiStore(db, log.NewNopLogger(), metrics.Metrics{})
	encCfg := moduletestutil.MakeTestEncodingConfig()
	keyParams := storetypes.NewKVStoreKey(paramstypes.StoreKey)
	tkeyParams := storetypes.NewTransientStoreKey(paramstypes.TStoreKey)
	ms.MountStoreWithDB(keyParams, storetypes.StoreTypeIAVL, db)
	ms.MountStoreWithDB(tkeyParams, storetypes.StoreTypeTransient, db)
	require.NoError(t, ms.LoadLatestVersion())

	paramsKeeper := paramskeeper.NewKeeper(encCfg.Codec, encCfg.Amino, keyParams, tkeyParams)

	ctx := sdk.NewContext(ms, tmproto.Header{
		Height: 1234567,
		Time:   time.Date(2020, time.April, 22, 12, 0, 0, 0, time.UTC),
	}, false, log.NewNopLogger())

	subspace := paramsKeeper.Subspace(ModuleName).WithKeyTable(types.ParamKeyTable())
	return ctx, encCfg, subspace
}

func TestGetQueryCmd(t *testing.T) {
	appModuleBasic := AppModuleBasic{}

	rootCmd := AppModuleBasic.GetQueryCmd(appModuleBasic)
	require.NotNil(t, rootCmd)
	require.Equal(t, types.ModuleName, rootCmd.Use)
	subCmd := rootCmd.Commands()
	var found bool
	for _, cmd := range subCmd {
		if cmd.Use == "parameters" {
			found = true
			break
		}
	}
	require.True(t, found, "Expected subcommand 'parameters' not found")
}

func TestIsAppModule(t *testing.T) {
	am := AppModule{}
	require.NotPanics(t, func() {
		am.IsAppModule()
	}, "IsAppModule should not panic")
}

func TestIsOnePerModuleType(t *testing.T) {
	am := AppModule{}
	require.NotPanics(t, func() {
		am.IsOnePerModuleType()
	}, "IsOnePerModuleType should not panic")
}

func TestAppModuleBasicName(t *testing.T) {
	amb := AppModuleBasic{}
	expectedName := types.ModuleName

	actualName := amb.Name()

	require.Equal(t, expectedName, actualName, "AppModuleBasic.Name() should return the correct module name")
}

func TestAppModuleBasicRegisterLegacyAminoCodec(t *testing.T) {
	cdc := codec.NewLegacyAmino()
	amb := AppModuleBasic{}
	amb.RegisterLegacyAminoCodec(cdc)
	expectedType := types.GenesisState{}
	_, err := cdc.MarshalJSON(expectedType)

	require.NoError(t, err, "RegisterLegacyAminoCodec should register the expected types without errors")
}

func TestRegisterRESTRoutes(t *testing.T) {
	ctx := client.Context{}
	router := mux.NewRouter()
	am := AppModuleBasic{}
	am.RegisterRESTRoutes(ctx, router)
	routeFound := false
	router.Walk(func(route *mux.Route, router *mux.Router, ancestors []*mux.Route) error {
		path, _ := route.GetPathTemplate()
		methods, _ := route.GetMethods()

		if path == "/globalfee/register-account" && containsMethod(methods, http.MethodPost) {
			routeFound = true
			return nil
		}
		return nil
	})
	require.True(t, routeFound, "/globalfee/register-account with POST method should be registered")

}

func containsMethod(methods []string, method string) bool {
	for _, m := range methods {
		if m == method {
			return true
		}
	}
	return false
}
func TestDefaultGenesis(t *testing.T) {
	interfaceRegistry := codectypes.NewInterfaceRegistry()
	cdc := codec.NewProtoCodec(interfaceRegistry)
	expectedGenesis := types.GenesisState{
		Params: types.DefaultParams(),
	}
	expectedGenesisJSON, err := cdc.MarshalJSON(&expectedGenesis)
	assert.NoError(t, err, "Expected no error while marshaling the expected genesis state")
	appModuleBasic := AppModuleBasic{}
	actualGenesisJSON := appModuleBasic.DefaultGenesis(cdc)
	assert.JSONEq(t, string(expectedGenesisJSON), string(actualGenesisJSON), "Genesis state should match")
}

func TestPostRegisterAccountHandler(t *testing.T) {
	req, err := http.NewRequest("POST", "/register", nil)
	assert.NoError(t, err, "Failed to create request")
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(PostRegisterAccountHandler)
	handler.ServeHTTP(rr, req)
	assert.Equal(t, http.StatusOK, rr.Code, "Expected status code 200")
	expectedResponse := "Registration successful"
	assert.Equal(t, expectedResponse, rr.Body.String(), "Expected response body to be 'Registration successful'")

}

func TestRegisterGRPCGatewayRoutes(t *testing.T) {
	interfaceRegistry := codectypes.NewInterfaceRegistry()
	cdc := codec.NewProtoCodec(interfaceRegistry)
	clientCtx := client.Context{}
	mux := runtime.NewServeMux()
	appModuleBasic := tokenfactory.NewAppModuleBasic(cdc)
	appModuleBasic.RegisterGRPCGatewayRoutes(clientCtx, mux)
	assert.NotNil(t, mux, "Expected mux to be initialized")
}

type MockRegistry struct {
	invariants []sdktypes.Invariant
}

func (m *MockRegistry) RegisterInvariant(invar sdktypes.Invariant) {
	m.invariants = append(m.invariants, invar)
}

func (m *MockRegistry) RegisterRoute(route, moduleName string, invariant sdktypes.Invariant) {
	m.RegisterInvariant(invariant)
}

func TestRegisterInvariants(t *testing.T) {
	appModule := AppModule{
		AppModuleBasic: AppModuleBasic{},
	}
	mockRegistry := &MockRegistry{}

	inv := sdktypes.Invariant(func(ctx sdk.Context) (string, bool) {

		return "dummy-invariant", true
	})

	mockRegistry.RegisterRoute("test_route", "test_module", inv)
	appModule.RegisterInvariants(mockRegistry)
	assert.Len(t, mockRegistry.invariants, 1, "Expected 1 invariant to be registered")
}

func TestDefaultGenesisState(t *testing.T) {
	expectedGenesis := types.NewGenesisState(types.DefaultParams())
	actualGenesis := types.DefaultGenesisState()
	assert.NotNil(t, actualGenesis, "DefaultGenesisState should not return nil")
	assert.Equal(t, expectedGenesis, actualGenesis, "DefaultGenesisState should return a genesis state with default parameters")
}

func TestGetGenesisStateFromAppState(t *testing.T) {
	interfaceRegistry := codectypes.NewInterfaceRegistry()
	cdc := codec.NewProtoCodec(interfaceRegistry)
	expectedGenesisState := types.NewGenesisState(types.DefaultParams())
	genesisStateJSON, err := cdc.MarshalJSON(expectedGenesisState)
	assert.NoError(t, err, "Marshaling should not fail")
	appState := map[string]json.RawMessage{
		types.ModuleName: genesisStateJSON,
	}
	actualGenesisState := types.GetGenesisStateFromAppState(cdc, appState)
	assert.NotNil(t, actualGenesisState, "Returned GenesisState should not be nil")
	assert.Equal(t, expectedGenesisState, actualGenesisState, "Extracted GenesisState should match the expected state")
}

func TestValidateGenesis2(t *testing.T) {
	validGenesis := types.NewGenesisState(types.DefaultParams())
	types.ValidateGenesis(*validGenesis)
	invalidParams := types.DefaultParams()
	invalidParams.MinimumGasPrices = nil
	invalidGenesis := types.NewGenesisState(invalidParams)

	types.ValidateGenesis(*invalidGenesis)

}

func TestRegisterInterfaces(t *testing.T) {
	registry := codectypes.NewInterfaceRegistry()
	module := AppModuleBasic{}
	module.RegisterInterfaces(registry)

}

func TestEndBlock(t *testing.T) {
	ctx := sdk.NewContext(nil, tmproto.Header{}, false, nil)
	module := AppModule{}
	updates := module.EndBlock(ctx, abci.RequestFinalizeBlock{})
	require.Nil(t, updates, "EndBlock should return nil when no validator updates are made")
}

func TestBeginBlock(t *testing.T) {
	ctx := sdk.NewContext(nil, tmproto.Header{}, false, nil)
	module := AppModule{}
	require.NotPanics(t, func() {
		module.BeginBlock(ctx, abci.RequestFinalizeBlock{})
	}, "BeginBlock should execute without panic")
}
