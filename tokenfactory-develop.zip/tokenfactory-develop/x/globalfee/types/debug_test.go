package types_test
import (
"fmt"
"testing"
"cosmossdk.io/math"
sdk "github.com/cosmos/cosmos-sdk/types"
"github.com/wfblockchain/coreblockchain/v2/x/globalfee/types"
)
func TestDebugDecCoinsValidate(t *testing.T) {
	coin := sdk.DecCoin{Denom: "!bad", Amount: math.LegacyNewDec(1)}
	fmt.Printf("denom=%q  amount=%s\n", coin.Denom, coin.Amount)
	coins := sdk.DecCoins{coin}
	err := types.ValidateMinimumGasPrices(coins)
	fmt.Printf("ValidateMinimumGasPrices(single invalid denom) err=%v\n", err)
	// Also test default case with invalid first denom
	coins2 := sdk.DecCoins{
		{Denom: "!first", Amount: math.LegacyNewDec(1)},
		{Denom: "ztoken", Amount: math.LegacyNewDec(1)},
	}
	err2 := types.ValidateMinimumGasPrices(coins2)
	fmt.Printf("ValidateMinimumGasPrices(multi invalid first) err=%v\n", err2)
}
