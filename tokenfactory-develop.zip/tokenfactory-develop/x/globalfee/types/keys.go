package types

import (
	"github.com/cosmos/cosmos-sdk/types"
)

const (
	// ModuleName is the name of the this module
	ModuleName = "globalfee"

	QuerierRoute = ModuleName
)

type MsgBypass struct {
	Sender types.AccAddress
}

func NewMsgBypass(sender types.AccAddress) *MsgBypass {
	return &MsgBypass{Sender: sender}
}
