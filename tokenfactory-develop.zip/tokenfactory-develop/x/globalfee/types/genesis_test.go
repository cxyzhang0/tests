package types_test

import (
	"encoding/json"
	"testing"

	"cosmossdk.io/math"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/cosmos/cosmos-sdk/types/module/testutil"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"github.com/wfblockchain/coreblockchain/v2/x/globalfee/types"
)

func TestNewGenesisState(t *testing.T) {
	expectedParams := types.Params{
		MinimumGasPrices:     types.DefaultParams().MinimumGasPrices,
		BypassMinFeeMsgTypes: []string{"/cosmos.bank.v1beta1.MsgSend"},
	}
	genesisState := types.NewGenesisState(expectedParams)
	assert.NotNil(t, genesisState, "GenesisState should not be nil")
	assert.Equal(t, expectedParams, genesisState.Params, "Params in GenesisState should match the provided Params")
}

func TestDefaultGenesisState(t *testing.T) {
	genesisState := types.DefaultGenesisState()
	require.NotNil(t, genesisState, "DefaultGenesisState should not return nil")
	expectedParams := types.DefaultParams()
	require.Equal(t, expectedParams, genesisState.Params, "GenesisState.Params should match DefaultParams()")
}

func TestGetGenesisStateFromAppState(t *testing.T) {
	cdc := testutil.MakeTestEncodingConfig().Codec
	defaultGenesisState := types.DefaultGenesisState()
	genesisJSON, err := json.Marshal(defaultGenesisState)
	require.NoError(t, err, "Marshaling default genesis state should not error")
	appState := map[string]json.RawMessage{
		types.ModuleName: genesisJSON,
	}
	genesisState := types.GetGenesisStateFromAppState(cdc, appState)
	require.NotNil(t, genesisState, "Genesis state should not be nil")
	emptyAppState := map[string]json.RawMessage{}
	genesisStateEmpty := types.GetGenesisStateFromAppState(cdc, emptyAppState)
	require.NotNil(t, genesisStateEmpty, "Genesis state should not be nil even if appState is empty")
}

func TestValidateGenesis(t *testing.T) {
	validGenesisState := types.DefaultGenesisState()
	err := types.ValidateGenesis(*validGenesisState)
	require.NoError(t, err, "Valid genesis state should not return an error")

	invalidGenesisState := types.GenesisState{
		Params: types.Params{
			MinimumGasPrices: sdk.DecCoins{
				sdk.NewDecCoin("photon", math.OneInt()),
				sdk.NewDecCoin("photon", math.OneInt()),
			},
		},
	}
	err = types.ValidateGenesis(invalidGenesisState)
	require.Error(t, err, "Invalid genesis state should return an error")
}
