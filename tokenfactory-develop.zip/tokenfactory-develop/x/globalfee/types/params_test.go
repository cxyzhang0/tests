package types_test

import (
	"testing"

	"cosmossdk.io/math"
	sdk "github.com/cosmos/cosmos-sdk/types"
	sdkerrors "github.com/cosmos/cosmos-sdk/types/errors"
	paramtypes "github.com/cosmos/cosmos-sdk/x/params/types"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"github.com/wfblockchain/coreblockchain/v2/x/globalfee/types"
)

func TestDefaultParams(t *testing.T) {
	p := types.DefaultParams()
	require.EqualValues(t, p.MinimumGasPrices, sdk.DecCoins{})
	require.EqualValues(t, p.BypassMinFeeMsgTypes, []string{
		"/ibc.core.client.v1.MsgUpdateClient",
		"/ibc.core.channel.v1.MsgRecvPacket",
		"/ibc.core.channel.v1.MsgAcknowledgement",
		"/ibc.applications.transfer.v1.MsgTransfer",
		"/ibc.core.channel.v1.MsgTimeout",
		"/ibc.core.channel.v1.MsgTimeoutOnClose",
		"/noble.fiattokenfactory.MsgUpdateParams",
		"/cosmos.upgrade.v1beta1.MsgSoftwareUpgrade",
		"/cosmos.upgrade.v1beta1.MsgCancelUpgrade",
		"/noble.fiattokenfactory.MsgUpdateMasterMinter",
		"/noble.fiattokenfactory.MsgUpdatePauser",
		"/noble.fiattokenfactory.MsgUpdateBlacklister",
		"/noble.fiattokenfactory.MsgUpdateOwner",
		"/noble.fiattokenfactory.MsgAcceptOwner",
		"/noble.fiattokenfactory.MsgConfigureMinter",
		"/noble.fiattokenfactory.MsgRemoveMinter",
		"/noble.fiattokenfactory.MsgMint",
		"/noble.fiattokenfactory.MsgBurn",
		"/noble.fiattokenfactory.MsgBlacklist",
		"/noble.fiattokenfactory.MsgUnblacklist",
		"/noble.fiattokenfactory.MsgPause",
		"/noble.fiattokenfactory.MsgUnpause",
		"/noble.fiattokenfactory.MsgConfigureMinterController",
		"/noble.fiattokenfactory.MsgRemoveMinterController",
		"/noble.tokenfactory.MsgUpdatePauser",
		"/noble.tokenfactory.MsgUpdateBlacklister",
		"/noble.tokenfactory.MsgUpdateOwner",
		"/noble.tokenfactory.MsgAcceptOwner",
		"/noble.tokenfactory.MsgConfigureMinter",
		"/noble.tokenfactory.MsgRemoveMinter",
		"/noble.tokenfactory.MsgMint",
		"/noble.tokenfactory.MsgBurn",
		"/noble.tokenfactory.MsgBlacklist",
		"/noble.tokenfactory.MsgUnblacklist",
		"/noble.tokenfactory.MsgPause",
		"/noble.tokenfactory.MsgUnpause",
		"/noble.tokenfactory.MsgConfigureMinterController",
		"/noble.tokenfactory.MsgRemoveMinterController",
		"/noble.paramauthority.v1beta1.MsgUpdateParams",
	})
}

func Test_validateParams(t *testing.T) {
	tests := map[string]struct {
		coins     interface{}
		expectErr bool
	}{
		"DefaultParams, pass": {
			types.DefaultParams().MinimumGasPrices,
			false,
		},
		"DecCoins conversion fails, fail": {
			sdk.Coins{sdk.NewCoin("photon", math.OneInt())},
			true,
		},
		"coins amounts are zero, pass": {
			sdk.DecCoins{
				sdk.NewDecCoin("atom", math.ZeroInt()),
				sdk.NewDecCoin("photon", math.ZeroInt()),
			},
			false,
		},
		"duplicate coins denoms, fail": {
			sdk.DecCoins{
				sdk.NewDecCoin("photon", math.OneInt()),
				sdk.NewDecCoin("photon", math.OneInt()),
			},
			true,
		},
		"coins are not sorted by denom alphabetically, fail": {
			sdk.DecCoins{
				sdk.NewDecCoin("photon", math.OneInt()),
				sdk.NewDecCoin("atom", math.OneInt()),
			},
			true,
		},
	}

	for name, test := range tests {
		t.Run(name, func(t *testing.T) {
			err := types.ValidateMinimumGasPrices(test.coins)
			if test.expectErr {
				require.Error(t, err)
				return
			}
			require.NoError(t, err)
		})
	}
}

func TestParamKeyTable(t *testing.T) {
	keyTable := types.ParamKeyTable()
	assert.NotNil(t, keyTable, "ParamKeyTable should return a non-nil KeyTable")
	_, ok := interface{}(keyTable).(paramtypes.KeyTable)
	assert.True(t, ok, "ParamKeyTable should return a paramtypes.KeyTable")
}

func TestParams_ValidateBasic(t *testing.T) {
	validGasPrice, _ := sdk.ParseDecCoins("0.025stake")
	validParams := types.Params{
		MinimumGasPrices: validGasPrice,
	}
	err := validParams.ValidateBasic()
	assert.NoError(t, err, "Expected no error for valid minimum gas prices")
	invalidParams1 := types.Params{
		MinimumGasPrices: sdk.DecCoins{},
	}
	invalidParams1.ValidateBasic()
	invalidGasPrice, _ := sdk.ParseDecCoins("invalid-gas-price")
	invalidParams2 := types.Params{
		MinimumGasPrices: invalidGasPrice,
	}
	invalidParams2.ValidateBasic()

}

func TestParams_ParamSetPairs(t *testing.T) {
	minGasPrices, _ := sdk.ParseDecCoins("0.025stake")
	bypassMsgTypes := []string{"/cosmos.bank.v1beta1.MsgSend"}

	params := types.Params{
		MinimumGasPrices:     minGasPrices,
		BypassMinFeeMsgTypes: bypassMsgTypes,
	}
	paramPairs := params.ParamSetPairs()
	assert.Len(t, paramPairs, 2, "Expected exactly 2 param set pairs")
	assert.Equal(t, types.ParamStoreKeyMinGasPrices, paramPairs[0].Key, "Incorrect key for MinimumGasPrices")
	assert.Equal(t, &params.MinimumGasPrices, paramPairs[0].Value, "Incorrect value for MinimumGasPrices")
	assert.NotNil(t, paramPairs[0].ValidatorFn, "Validator function should not be nil for MinimumGasPrices")
	assert.Equal(t, types.ParamStoreKeyBypassMinFeeMsgTypes, paramPairs[1].Key, "Incorrect key for BypassMinFeeMsgTypes")
	assert.Equal(t, &params.BypassMinFeeMsgTypes, paramPairs[1].Value, "Incorrect value for BypassMinFeeMsgTypes")
	assert.NotNil(t, paramPairs[1].ValidatorFn, "Validator function should not be nil for BypassMinFeeMsgTypes")
	assert.IsType(t, paramtypes.ParamSetPairs{}, paramPairs, "Expected type ParamSetPairs")
}

func TestValidateBypassMinFeeMsgTypes(t *testing.T) {
	validMsgTypes := []string{
		"/cosmos.bank.v1beta1.MsgSend",
		"/cosmos.staking.v1beta1.MsgDelegate",
	}

	err := types.ValidateBypassMinFeeMsgTypes(validMsgTypes)
	assert.NoError(t, err, "Expected no error for a valid list of bypass message types")
	invalidInput := "not-a-slice"
	err = types.ValidateBypassMinFeeMsgTypes(invalidInput)
	assert.Error(t, err, "Expected an error for invalid input type")
	assert.Contains(t, err.Error(), sdkerrors.ErrInvalidType.Error(), "Error should indicate invalid type")
	invalidInputInt := 123
	err = types.ValidateBypassMinFeeMsgTypes(invalidInputInt)
	assert.Error(t, err, "Expected an error for an integer input")
	emptySlice := []string{}
	err = types.ValidateBypassMinFeeMsgTypes(emptySlice)
	assert.NoError(t, err, "Expected no error for an empty list of bypass message types")
	var nilSlice []string = nil
	err = types.ValidateBypassMinFeeMsgTypes(nilSlice)
	assert.NoError(t, err, "Expected no error for a nil bypass message types list")
}
