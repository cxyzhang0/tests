package poas_test

import (
	"fmt"
	"testing"

	codectypes "github.com/cosmos/cosmos-sdk/codec/types"
	sdk "github.com/cosmos/cosmos-sdk/types"
	protov2 "google.golang.org/protobuf/proto"

	authztypes "github.com/cosmos/cosmos-sdk/x/authz"
	stakingtypes "github.com/cosmos/cosmos-sdk/x/staking/types"

	"github.com/wfblockchain/coreblockchain/v2/x/poas"
	poastypes "github.com/wfblockchain/coreblockchain/v2/x/poas/types"
)

//
// ------------------------------------------------------------
// go test ./x/poas -run '^Test' -- ante_poas_test.go
// ------------------------------------------------------------
//

// ------------------------------------------------------------
// Mock Unpacker
// ------------------------------------------------------------
type mockUnpacker struct{}

func (mockUnpacker) UnpackAny(any *codectypes.Any, ptr interface{}) error {
	// Use the cached value set by codectypes.NewAnyWithValue
	cached := any.GetCachedValue()
	if cached == nil {
		return fmt.Errorf("no cached value in Any")
	}

	msg, ok := cached.(sdk.Msg)
	if !ok {
		return fmt.Errorf("cached value is not sdk.Msg: %T", cached)
	}

	switch m := ptr.(type) {
	case *sdk.Msg:
		*m = msg
		return nil
	default:
		return fmt.Errorf("bad unpack target type: %T", ptr)
	}
}

//
// ------------------------------------------------------------
// Mock Tx
// ------------------------------------------------------------
//

type mockTx struct {
	msgs []sdk.Msg
}

func (m mockTx) GetMsgs() []sdk.Msg { return m.msgs }

func (m mockTx) GetMsgsV2() ([]protov2.Message, error) {
	out := make([]protov2.Message, len(m.msgs))
	for i, msg := range m.msgs {
		p, ok := msg.(protov2.Message)
		if !ok {
			return nil, fmt.Errorf("msg %T does not implement proto.Message", msg)
		}
		out[i] = p
	}
	return out, nil
}

func (m mockTx) ValidateBasic() error { return nil }

//
// ------------------------------------------------------------
// Minimal unknownMsg
// ------------------------------------------------------------
//

var _ sdk.Msg = unknownMsg{}

type unknownMsg struct{}

func (unknownMsg) Reset()         {}
func (unknownMsg) String() string { return "unknownMsg" }
func (unknownMsg) ProtoMessage()  {}

//
// ------------------------------------------------------------
// Helper: run AnteHandle
// ------------------------------------------------------------
//

func runAnte(t *testing.T, dec poas.PoASDecorator, msgs ...sdk.Msg) (nextCalled bool, err error) {
	tx := mockTx{msgs: msgs}

	nextCalled = false
	next := func(ctx sdk.Context, _ sdk.Tx, _ bool) (sdk.Context, error) {
		nextCalled = true
		return ctx, nil
	}

	_, err = dec.AnteHandle(sdk.Context{}, tx, false, next)
	return
}

//
// ------------------------------------------------------------
// TESTS
// ------------------------------------------------------------
//

// -------------------------------------------------------------
// CreateValidator
// -------------------------------------------------------------

func TestMsgCreateValidator_BlockedAfterGenesis(t *testing.T) {
	dec := poas.NewPoASDecorator(nil, mockUnpacker{})

	nextCalled, err := runAnteWithHeight(dec, 1,
		&stakingtypes.MsgCreateValidator{},
	)

	if err == nil {
		t.Fatalf("expected CreateValidator error")
	}
	if nextCalled {
		t.Fatalf("next handler should NOT be called")
	}
}

func TestMsgCreateValidator_AllowedAtGenesis(t *testing.T) {
	dec := poas.NewPoASDecorator(nil, mockUnpacker{})

	nextCalled, err := runAnteWithHeight(dec, 0,
		&stakingtypes.MsgCreateValidator{},
	)

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if !nextCalled {
		t.Fatalf("expected next handler to run")
	}
}

// Custom helper so we can set height easily.
func runAnteWithHeight(dec poas.PoASDecorator, height int64, msg sdk.Msg) (bool, error) {
	ctx := sdk.Context{}.WithBlockHeight(height)

	tx := mockTx{msgs: []sdk.Msg{msg}}

	nextCalled := false
	next := func(ctx sdk.Context, _ sdk.Tx, _ bool) (sdk.Context, error) {
		nextCalled = true
		return ctx, nil
	}

	_, err := dec.AnteHandle(ctx, tx, false, next)
	return nextCalled, err
}

// -------------------------------------------------------------
// Delegate
// -------------------------------------------------------------

func TestMsgDelegate_Blocked(t *testing.T) {
	dec := poas.NewPoASDecorator(nil, mockUnpacker{})

	nextCalled, err := runAnte(t, dec, &stakingtypes.MsgDelegate{})

	if err == nil {
		t.Fatalf("expected MsgDelegate to be rejected")
	}
	if nextCalled {
		t.Fatalf("next handler should NOT be called")
	}
}

// -------------------------------------------------------------
// Governance Messages
// -------------------------------------------------------------

func TestMsgGovAddValidator_Blocked(t *testing.T) {
	dec := poas.NewPoASDecorator(nil, mockUnpacker{})

	nextCalled, err := runAnte(t, dec, &poastypes.MsgGovAddValidator{})

	if err == nil {
		t.Fatalf("expected MsgGovAddValidator to be rejected")
	}
	if nextCalled {
		t.Fatalf("next handler should NOT run")
	}
}

func TestMsgGovDelegate_Blocked(t *testing.T) {
	dec := poas.NewPoASDecorator(nil, mockUnpacker{})

	nextCalled, err := runAnte(t, dec, &poastypes.MsgGovDelegate{})

	if err == nil {
		t.Fatalf("expected MsgGovDelegate to be rejected")
	}
	if nextCalled {
		t.Fatalf("next handler should NOT run")
	}
}

// -------------------------------------------------------------
// Authz MsgExec Expansion
// -------------------------------------------------------------

func TestMsgExec_ExpandsAndBlocks(t *testing.T) {
	dec := poas.NewPoASDecorator(nil, mockUnpacker{})

	// MsgExec containing a MsgDelegate → should be blocked
	any, _ := codectypes.NewAnyWithValue(&stakingtypes.MsgDelegate{})

	msg := &authztypes.MsgExec{
		Grantee: "addr1",
		Msgs:    []*codectypes.Any{any},
	}

	nextCalled, err := runAnte(t, dec, msg)

	if err == nil {
		t.Fatalf("expected MsgDelegate inside MsgExec to be blocked")
	}
	if nextCalled {
		t.Fatalf("next handler should NOT be called")
	}
}

// -------------------------------------------------------------
// Unknown message → should pass
// -------------------------------------------------------------

func TestUnknownMsg_Passes(t *testing.T) {
	dec := poas.NewPoASDecorator(nil, mockUnpacker{})

	nextCalled, err := runAnte(t, dec, unknownMsg{})

	if err != nil {
		t.Fatalf("unexpected error for unknown msg: %v", err)
	}
	if !nextCalled {
		t.Fatalf("expected next handler to run")
	}
}
