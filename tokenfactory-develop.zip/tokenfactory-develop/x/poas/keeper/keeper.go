package keeper

import (
	codectypes "github.com/cosmos/cosmos-sdk/codec/types"
	govkeeper "github.com/cosmos/cosmos-sdk/x/gov/keeper"
	stakingkeeper "github.com/cosmos/cosmos-sdk/x/staking/keeper"
	stakingtypes "github.com/cosmos/cosmos-sdk/x/staking/types"
)

type Keeper struct {
	ir            codectypes.InterfaceRegistry
	stakingMsgSrv stakingtypes.MsgServer
	govKeeper     *govkeeper.Keeper
}

func NewKeeper(
	ir codectypes.InterfaceRegistry,
	stakingK *stakingkeeper.Keeper,
	govK *govkeeper.Keeper,
) Keeper {
	return Keeper{
		ir:            ir,
		stakingMsgSrv: stakingkeeper.NewMsgServerImpl(stakingK),
		govKeeper:     govK,
	}
}

func (k Keeper) Authority() string { return k.govKeeper.GetAuthority() }
