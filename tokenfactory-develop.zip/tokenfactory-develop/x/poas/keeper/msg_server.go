package keeper

import (
	"context"
	"fmt"
	authkeeper "github.com/cosmos/cosmos-sdk/x/auth/keeper"
	stakingkeeper "github.com/cosmos/cosmos-sdk/x/staking/keeper"

	sdkmath "cosmossdk.io/math"
	cryptotypes "github.com/cosmos/cosmos-sdk/crypto/types"
	sdk "github.com/cosmos/cosmos-sdk/types"
	sdkerrors "github.com/cosmos/cosmos-sdk/types/errors"
	stakingtypes "github.com/cosmos/cosmos-sdk/x/staking/types"

	"github.com/wfblockchain/coreblockchain/v2/x/poas/types"
)

type msgServer struct {
	k  Keeper
	ak authkeeper.AccountKeeper
	sk *stakingkeeper.Keeper
}

func NewMsgServerImpl(k Keeper, ak authkeeper.AccountKeeper, sk *stakingkeeper.Keeper) types.MsgServer {
	return msgServer{
		k,
		ak,
		sk,
	}
}

// GovAddValidator handles a governance-authorized validator addition.
// GovAddValidator is executed exclusively via governance (x/gov) and creates a new validator entry.
//
// Even though governance executes this message, it safely calls the staking MsgServer’s
// CreateValidator method instead of the Keeper directly. This is intentional:
//
//   - staking.MsgServer.CreateValidator does NOT depend on the transaction signer being the
//     validator or delegator—it only validates message fields (description, commission, pubkey,
//     etc.) and ensures the delegator/validator addresses match.
//   - Because governance executes with the gov module account as the outer signer, this call path
//     succeeds and preserves all of staking’s built-in validation, event emission, and hooks.
//   - Direct keeper calls are unnecessary here and would bypass useful sanity checks.
//
// Therefore, AddValidator reuses staking.MsgServer.CreateValidator for correctness and
// consistency with standard staking logic, while still being safely permission-gated in the ante
// handler (only governance may execute it).
func (s msgServer) GovAddValidator(goCtx context.Context, msg *types.MsgGovAddValidator) (*types.MsgGovAddValidatorResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	// -------------------------------------------------------------------------
	// Verify authority == governance module account
	// -------------------------------------------------------------------------
	if msg.Authority != s.k.Authority() {
		return nil, fmt.Errorf("unauthorized: authority must be %s", s.k.Authority())
	}

	var pk cryptotypes.PubKey
	if err := s.k.ir.UnpackAny(msg.Pubkey, &pk); err != nil {
		return nil, fmt.Errorf("invalid pubkey: %w", err)
	}
	if pk == nil {
		return nil, fmt.Errorf("invalid pubkey: nil")
	}

	minSD, ok := sdkmath.NewIntFromString(msg.MinSelfDelegation)
	if !ok {
		return nil, fmt.Errorf("invalid min_self_delegation: %s", msg.MinSelfDelegation)
	}

	// -------------------------------------------------------------------------
	// Construct a standard staking MsgCreateValidator
	// -------------------------------------------------------------------------
	create := &stakingtypes.MsgCreateValidator{
		Description:       *msg.Description,
		Commission:        *msg.Commission,
		MinSelfDelegation: minSD,
		ValidatorAddress:  msg.ValidatorAddress,
		Pubkey:            msg.Pubkey,
		Value:             *msg.Value,
	}

	if _, err := s.k.stakingMsgSrv.CreateValidator(goCtx, create); err != nil {
		return nil, err
	}

	// -------------------------------------------------------------------------
	// Emit additional governance-context events
	// -------------------------------------------------------------------------
	ctx.EventManager().EmitEvents(sdk.Events{
		sdk.NewEvent(
			types.EventTypeGovAddValidator,
			sdk.NewAttribute("authority", msg.Authority),
			sdk.NewAttribute("module", "poas"),
		),
	})

	return &types.MsgGovAddValidatorResponse{}, nil
}

// GovDelegate handles a governance-authorized delegation.
// GovDelegate is executed exclusively via governance (x/gov) to increase a validator’s stake
// under permissioned control.
//
// This function deliberately calls staking.Keeper.Delegate directly instead of
// staking.MsgServer.Delegate. The distinction is critical:
//
//   - staking.MsgServer.Delegate enforces that the delegator address in the message must also
//     be the transaction signer. Because governance executes with the gov module account as
//     signer (not the delegator), that check would always fail.
//   - staking.Keeper.Delegate performs the underlying state transition (bond accounting,
//     hooks, power updates) without requiring the signer == delegator condition.
//   - All necessary authorization is already enforced by x/poas itself:
//     – Ante handler restricts MsgGovDelegate to governance authority.
//     – This method re-verifies authority == gov module account before delegating.
//
// Using the Keeper directly allows governance to perform valid delegations programmatically
// while keeping MsgDelegate fully disabled for normal users. Event emission can be added
// manually to match staking’s standard telemetry if desired.
func (s msgServer) GovDelegate(
	goCtx context.Context,
	msg *types.MsgGovDelegate,
) (*types.MsgGovDelegateResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	// -------------------------------------------------------------------------
	// Verify msg authority == keeper authority governance module account
	// -------------------------------------------------------------------------
	authorityAddr, err := sdk.AccAddressFromBech32(msg.Authority)
	if err != nil {
		return nil, sdkerrors.ErrInvalidAddress.Wrap("invalid authority address")
	}
	govAddr, _ := sdk.AccAddressFromBech32(s.k.Authority()) //s.ak.GetModuleAddress(govtypes.ModuleName)
	if !authorityAddr.Equals(govAddr) {
		return nil, sdkerrors.ErrUnauthorized.Wrap("MsgGovDelegate must be signed by governance module")
	}

	// -------------------------------------------------------------------------
	// Parse addresses
	// -------------------------------------------------------------------------
	delegatorAddr, err := sdk.AccAddressFromBech32(msg.DelegatorAddress)
	if err != nil {
		return nil, sdkerrors.ErrInvalidAddress.Wrap("invalid delegator address")
	}
	valAddr, err := sdk.ValAddressFromBech32(msg.ValidatorAddress)
	if err != nil {
		return nil, sdkerrors.ErrInvalidAddress.Wrap("invalid validator address")
	}

	// -------------------------------------------------------------------------
	// Find validator
	// -------------------------------------------------------------------------
	validator, err := s.sk.GetValidator(ctx, valAddr)
	if err != nil {
		return nil, err
	}

	// -------------------------------------------------------------------------
	// Perform the delegation
	// -------------------------------------------------------------------------
	newShares, err := s.sk.Delegate(
		ctx,
		delegatorAddr,
		msg.Amount.Amount,
		stakingtypes.Unbonded,
		validator,
		true, // new delegation if not existing
	)
	if err != nil {
		return nil, err
	}

	// -------------------------------------------------------------------------
	// Emit standard staking delegation events
	// -------------------------------------------------------------------------
	ctx.EventManager().EmitEvents(sdk.Events{
		sdk.NewEvent(
			stakingtypes.EventTypeDelegate,
			sdk.NewAttribute(stakingtypes.AttributeKeyDelegator, msg.DelegatorAddress),
			sdk.NewAttribute(stakingtypes.AttributeKeyValidator, msg.ValidatorAddress),
			sdk.NewAttribute(sdk.AttributeKeyAmount, msg.Amount.String()),
			sdk.NewAttribute(stakingtypes.AttributeKeyNewShares, newShares.String()),
		),
	})

	// (Optional) Emit module-specific event for transparency
	ctx.EventManager().EmitEvent(
		sdk.NewEvent(
			types.EventTypeGovDelegate,
			sdk.NewAttribute("authority", msg.Authority),
			sdk.NewAttribute("module", "poas"),
		),
	)

	return &types.MsgGovDelegateResponse{}, nil
}
