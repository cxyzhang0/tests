package types

const (
	ModuleName = "poas"
	StoreKey   = ModuleName
	RouterKey  = ModuleName
)
