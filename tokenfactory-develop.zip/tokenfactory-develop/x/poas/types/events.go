package types

// Custom POAS event types
const (
	EventTypeGovDelegate     = "gov_delegate"
	EventTypeGovAddValidator = "gov_add_validator"
)
