package poas

import (
	"fmt"

	codectypes "github.com/cosmos/cosmos-sdk/codec/types"
	sdk "github.com/cosmos/cosmos-sdk/types"
	sdkerrors "github.com/cosmos/cosmos-sdk/types/errors"
	authztypes "github.com/cosmos/cosmos-sdk/x/authz"
	stakingtypes "github.com/cosmos/cosmos-sdk/x/staking/types"
	poastypes "github.com/wfblockchain/coreblockchain/v2/x/poas/types"
)

type PoASDecorator struct {
	authority sdk.AccAddress
	cdc       codectypes.AnyUnpacker
}

// NewPoASDecorator creates a new PoASDecorator instance
// authority: the governance module account address; caller must provide this
func NewPoASDecorator(
	authority sdk.AccAddress,
	cdc codectypes.AnyUnpacker,
) PoASDecorator {
	return PoASDecorator{authority: authority, cdc: cdc}
}

// AnteHandle PoasDecorator enforces permissioned validator and staking behavior for a PoAS chain.
//
//   - Applies only to externally-broadcast transactions (through mempool).
//     This decorator sits early in the ante chain and examines every message in a transaction
//     (recursively unwrapping authz.MsgExec containers).
//   - Internal module-to-module calls—such as governance executing MsgGovAddValidator
//     or MsgGovDelegate—do NOT traverse the ante chain and are therefore unaffected.
//
// Rule summary:
//
//  1. staking.MsgCreateValidator
//     – Blocked after genesis (ctx.BlockHeight() > 0).
//     – Prevents arbitrary validator creation by external users.
//
//  2. staking.MsgDelegate
//     – Always blocked.
//     – Prevents any account (even compromised validator) from inflating its bonded
//     power through new delegations.
//
//  3. poas.MsgGovAddValidator
//     – Governance-only message; never valid as a user transaction.
//     – Rejected outright if broadcast externally.
//
//  4. poas.MsgGovDelegate
//     – Governance-only message; never valid as a user transaction.
//     – Rejected outright if broadcast externally.
//
// Security Rationale:
//
//   - Together, these gates ensure the validator set and bonded power distribution are entirely
//     under on-chain governance control.
//   - No user or compromised validator key can create new validators or inflate voting power.
//   - Governance may still increase or decrease stake via controlled proposal messages.
//   - The decorator unpacks authz.MsgExec to prevent delegation or validator creation from being
//     tunneled through authorization wrappers.
//
// Integration:
//
//	Place this decorator early in the ante chain, before signature verification and staking
//	decorators:
//
//	    anteDecorators := []sdk.AnteDecorator{
//	        ante.NewPoasAnteDecorator(app.AccountKeeper, app.InterfaceRegistry()),
//	        ... other decorators ...
//	    }
//
//	The second argument must implement codectypes.AnyUnpacker; app.InterfaceRegistry() satisfies
//	this interface.
func (d PoASDecorator) AnteHandle(
	ctx sdk.Context,
	tx sdk.Tx,
	simulate bool,
	next sdk.AnteHandler,
) (sdk.Context, error) {

	for _, msg := range tx.GetMsgs() {
		expandedMsgs, err := d.expandMsgs(msg)
		if err != nil {
			return ctx, fmt.Errorf("failed to expand messages: %w", err)
		}
		for _, inner := range expandedMsgs {
			if err := d.checkMsg(ctx, inner); err != nil {
				return ctx, err
			}
		}
	}
	return next(ctx, tx, simulate)
}

func (d PoASDecorator) checkMsg(ctx sdk.Context, msg sdk.Msg) error {
	switch m := msg.(type) {

	// 1. Block MsgCreateValidator after genesis
	case *stakingtypes.MsgCreateValidator:
		return d.blockCreateValidator(ctx)

	// 2. Completely block MsgDelegate
	case *stakingtypes.MsgDelegate:
		return d.blockDelegate()

	// 3. Completely block MsgGovAddValidator
	case *poastypes.MsgGovAddValidator:
		return d.blockGovAddValidator()

	// 4. Completely block MsgGovDelegate
	case *poastypes.MsgGovDelegate:
		return d.blockGovDelegate()

	default:
		_ = m
		return nil
	}
}

func (d PoASDecorator) blockCreateValidator(ctx sdk.Context) error {
	if ctx.BlockHeight() > 0 {
		return sdkerrors.ErrUnauthorized.Wrap("MsgCreateValidator disabled")
	}
	return nil
}

func (d PoASDecorator) blockDelegate() error {
	return sdkerrors.ErrUnauthorized.Wrap("MsgDelegate disabled")
}

func (d PoASDecorator) blockGovAddValidator() error {
	return sdkerrors.ErrUnauthorized.
		Wrap("MsgGovAddValidator disabled: validator addition allowed only via governance")
}

func (d PoASDecorator) blockGovDelegate() error {
	return sdkerrors.ErrUnauthorized.
		Wrap("MsgGovDelegate disabled: delegate allowed only via governance")
}

// expandMsgs unwraps MsgExec(authz) or nested messages
func (d PoASDecorator) expandMsgs(m sdk.Msg) ([]sdk.Msg, error) {
	switch exec := m.(type) {
	case *authztypes.MsgExec:
		msgs := make([]sdk.Msg, 0, len(exec.Msgs))
		for _, any := range exec.Msgs {
			var inner sdk.Msg
			if err := d.cdc.UnpackAny(any, &inner); err != nil {
				return nil, fmt.Errorf("failed to unpack authz inner message: %w", err)
			}
			if inner != nil {
				expanded, err := d.expandMsgs(inner)
				if err != nil {
					return nil, err
				}
				msgs = append(msgs, expanded...)
			}
		}
		return msgs, nil
	default:
		return []sdk.Msg{m}, nil
	}
}

// prior to AVIT12247440 resolution
/*
func (d PoASDecorator) expandMsgs(m sdk.Msg) []sdk.Msg {
	switch exec := m.(type) {
	case *authztypes.MsgExec:
		msgs := make([]sdk.Msg, 0, len(exec.Msgs))
		for _, any := range exec.Msgs {
			var inner sdk.Msg
			if err := d.cdc.UnpackAny(any, &inner); err == nil && inner != nil {
				msgs = append(msgs, inner)
			}
		}
		return msgs
	default:
		return []sdk.Msg{m}
	}
}
*/
