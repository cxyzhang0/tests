package keeper

import (
	"context"

	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"

	sdkerrors "cosmossdk.io/errors"
	sdk "github.com/cosmos/cosmos-sdk/types"
)

// RemoveMinter Remove (Minter, Denom) from the store
func (k msgServer) RemoveMinter(goCtx context.Context, msg *types.MsgRemoveMinter) (*types.MsgRemoveMinterResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	minterController, found := k.GetMinterController(ctx, msg.From, msg.Address)
	if !found {
		return nil, sdkerrors.Wrapf(types.ErrUnauthorized, "minter controller not found")
	}

	// todo: this check always passes because of the above query.
	if msg.From != minterController.Controller {
		return nil, sdkerrors.Wrapf(types.ErrUnauthorized, "you are not a controller of this minter")
	}

	// todo: this check always passes because of the above query.
	if msg.Address != minterController.Minter {
		return nil, sdkerrors.Wrapf(
			types.ErrUnauthorized,
			"minter address ≠ minter controller's minter address, (%s≠%s)",
			msg.Address, minterController.Minter,
		)
	}

	minter, found := k.GetMinters(ctx, msg.Address, msg.Denom)
	if !found {
		return nil, sdkerrors.Wrapf(types.ErrUserNotFound, "a minter with a given address doesn't exist")
	}

	// the above query ensures msg.Denom = minter.Allowance.Denom
	k.RemoveMinters(ctx, minter.Address, minter.Allowance.Denom)

	err := ctx.EventManager().EmitTypedEvent(msg)

	return &types.MsgRemoveMinterResponse{}, err
}
