package keeper

import (
	"context"

	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"

	"cosmossdk.io/store/prefix"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/cosmos/cosmos-sdk/types/query"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

func (k Keeper) MinterControllerAll(c context.Context, req *types.QueryAllMinterControllerRequest) (*types.QueryAllMinterControllerResponse, error) {
	if req == nil {
		return nil, status.Error(codes.InvalidArgument, "invalid request")
	}

	var minterControllers []types.MinterController
	ctx := sdk.UnwrapSDKContext(c)

	store := ctx.KVStore(k.storeKey)
	minterControllerStore := prefix.NewStore(store, types.KeyPrefix(types.MinterControllerKeyPrefix))

	pageRes, _ := query.Paginate(minterControllerStore, req.Pagination, func(key []byte, value []byte) error {
		var minterController types.MinterController
		k.cdc.Unmarshal(value, &minterController)
		minterControllers = append(minterControllers, minterController)
		return nil
	})

	return &types.QueryAllMinterControllerResponse{MinterController: minterControllers, Pagination: pageRes}, nil
}

func (k Keeper) MinterController(c context.Context, req *types.QueryGetMinterControllerRequest) (*types.QueryGetMinterControllerResponse, error) {
	if req == nil {
		return nil, status.Error(codes.InvalidArgument, "invalid request")
	}
	ctx := sdk.UnwrapSDKContext(c)

	val, found := k.GetMinterController(
		ctx,
		req.ControllerAddress,
		req.MinterAddress,
	)
	if !found {
		return nil, status.Error(codes.NotFound, "not found")
	}

	return &types.QueryGetMinterControllerResponse{MinterController: val}, nil
}
