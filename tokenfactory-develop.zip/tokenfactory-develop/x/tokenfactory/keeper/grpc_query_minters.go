package keeper

import (
	"context"

	"cosmossdk.io/store/prefix"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/cosmos/cosmos-sdk/types/query"
	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

func (k Keeper) MintersAll(c context.Context, req *types.QueryAllMintersRequest) (*types.QueryAllMintersResponse, error) {
	if req == nil {
		return nil, status.Error(codes.InvalidArgument, "invalid request")
	}

	var minters []types.Minters
	ctx := sdk.UnwrapSDKContext(c)

	store := ctx.KVStore(k.storeKey)
	mintersStore := prefix.NewStore(store, types.KeyPrefix(types.MintersKeyPrefix))

	pageRes, _ := query.Paginate(mintersStore, req.Pagination, func(key []byte, value []byte) error {
		var minter types.Minters
		k.cdc.Unmarshal(value, &minter)

		minters = append(minters, minter)
		return nil
	})

	return &types.QueryAllMintersResponse{Minters: minters, Pagination: pageRes}, nil
}

func (k Keeper) Minters(c context.Context, req *types.QueryGetMintersRequest) (*types.QueryGetMintersResponse, error) {
	if req == nil {
		return nil, status.Error(codes.InvalidArgument, "invalid request")
	}
	ctx := sdk.UnwrapSDKContext(c)

	val, found := k.GetMinters(
		ctx,
		req.Address,
		req.Denom,
	)
	if !found {
		return nil, status.Error(codes.NotFound, "not found")
	}

	return &types.QueryGetMintersResponse{Minters: val}, nil
}
