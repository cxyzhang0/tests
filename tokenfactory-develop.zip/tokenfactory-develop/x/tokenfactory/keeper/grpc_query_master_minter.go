package keeper

import (
	"context"

	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

func (k Keeper) MasterMinter(c context.Context, req *types.QueryGetMasterMinterRequest) (*types.QueryGetMasterMinterResponse, error) {
	if req == nil {
		return nil, status.Error(codes.InvalidArgument, "invalid request")
	}
	ctx := sdk.UnwrapSDKContext(c)

	val, _ := k.GetMasterMinter(ctx)
	return &types.QueryGetMasterMinterResponse{MasterMinter: val}, nil
}
