package keeper

import (
	"fmt"

	"cosmossdk.io/store/prefix"
	sdktypes "cosmossdk.io/store/types"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"
)

// SetMinters set a specific minters in the store from its index
func (k Keeper) SetMinters(ctx sdk.Context, minters types.Minters) {
	store := prefix.NewStore(ctx.KVStore(k.storeKey), types.KeyPrefix(types.MintersKeyPrefix))
	b := k.cdc.MustMarshal(&minters)
	store.Set(types.MintersKey(
		minters.Address,
		minters.Allowance.Denom,
	), b)
}

// GetMinters returns a minters from its index
func (k Keeper) GetMinters(
	ctx sdk.Context,
	address string,
	denom string,

) (val types.Minters, found bool) {
	store := prefix.NewStore(ctx.KVStore(k.storeKey), types.KeyPrefix(types.MintersKeyPrefix))

	b := store.Get(types.MintersKey(
		address, denom,
	))
	if b == nil {
		k.Logger(ctx).Info(fmt.Sprintf("Minters not found for address: %s, denom: %s", address, denom))
		return val, false
	}

	k.cdc.MustUnmarshal(b, &val)
	return val, true
}

// RemoveMinters removes a minters from the store
func (k Keeper) RemoveMinters(
	ctx sdk.Context,
	address string,
	denom string,

) {
	store := prefix.NewStore(ctx.KVStore(k.storeKey), types.KeyPrefix(types.MintersKeyPrefix))
	store.Delete(types.MintersKey(
		address, denom,
	))
}

// GetAllMinters returns all minters
func (k Keeper) GetAllMinters(ctx sdk.Context) (list []types.Minters) {
	store := prefix.NewStore(ctx.KVStore(k.storeKey), types.KeyPrefix(types.MintersKeyPrefix))
	iterator := sdktypes.KVStorePrefixIterator(store, []byte{})

	defer iterator.Close()

	for ; iterator.Valid(); iterator.Next() {
		var val types.Minters
		k.cdc.MustUnmarshal(iterator.Value(), &val)
		list = append(list, val)
	}

	return
}
