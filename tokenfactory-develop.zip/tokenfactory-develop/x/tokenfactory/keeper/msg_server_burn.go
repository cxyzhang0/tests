package keeper

import (
	"context"

	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"

	sdkerrors "cosmossdk.io/errors"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/cosmos/cosmos-sdk/types/bech32"
)

func (k msgServer) Burn(goCtx context.Context, msg *types.MsgBurn) (*types.MsgBurnResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)
	return k.Keeper.Burn(ctx, msg)
}

func (k Keeper) Burn(ctx sdk.Context, msg *types.MsgBurn) (*types.MsgBurnResponse, error) {
	_, found := k.GetMinters(ctx, msg.From, msg.Amount.Denom)
	if !found {
		return nil, sdkerrors.Wrapf(types.ErrBurn, "%v: you are not a minter", types.ErrUnauthorized)
	}

	_, addressBz, _ := bech32.DecodeAndConvert(msg.From)

	_, found = k.GetBlacklisted(ctx, addressBz)
	if found {
		return nil, sdkerrors.Wrap(types.ErrBurn, "minter address is blacklisted")
	}

	found = k.MintingDenomSet(ctx, msg.Amount.Denom)
	if !found {
		return nil, sdkerrors.Wrapf(types.ErrBurn, "%s is not minting denom", msg.Amount.Denom)
	}

	//if msg.Amount.Denom != mintingDenom.Denom {
	//	return nil, sdkerrors.Wrap(types.ErrBurn, "burning denom is incorrect")
	//}

	paused := k.GetPaused(ctx)

	if paused.Paused {
		return nil, sdkerrors.Wrap(types.ErrBurn, "burning is paused")
	}

	minterAddress, _ := sdk.AccAddressFromBech32(msg.From)

	amount := sdk.NewCoins(msg.Amount)

	k.bankKeeper.SendCoinsFromAccountToModule(ctx, minterAddress, types.ModuleName, amount)
	k.bankKeeper.BurnCoins(ctx, types.ModuleName, amount)

	err := ctx.EventManager().EmitTypedEvent(msg)

	return &types.MsgBurnResponse{}, err
}
