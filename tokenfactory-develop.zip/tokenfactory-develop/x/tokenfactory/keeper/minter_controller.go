package keeper

import (
	"cosmossdk.io/store/prefix"
	sdktypes "cosmossdk.io/store/types"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"
)

// SetMinterController set a specific minterController in the store from its index
func (k Keeper) SetMinterController(ctx sdk.Context, minterController types.MinterController) {
	store := prefix.NewStore(ctx.KVStore(k.storeKey), types.KeyPrefix(types.MinterControllerKeyPrefix))
	// key := types.MinterControllerKey(minterController.Controller)
	b := k.cdc.MustMarshal(&minterController)
	store.Set(types.MinterControllerKey(
		minterController.Controller,
		minterController.Minter,
	), b)
}

func (k Keeper) GetMinterController(
	ctx sdk.Context,
	controller string,
	minter string,

) (val types.MinterController, found bool) {
	store := prefix.NewStore(ctx.KVStore(k.storeKey), types.KeyPrefix(types.MinterControllerKeyPrefix))

	b := store.Get(types.MinterControllerKey(
		controller, minter,
	))
	if b == nil {
		return val, false
	}
	k.cdc.MustUnmarshal(b, &val)
	return val, true
}

// RemoveMinterController removes a minterController from the store
func (k Keeper) DeleteMinterController(
	ctx sdk.Context,
	controller string,
	minter string,

) {
	store := prefix.NewStore(ctx.KVStore(k.storeKey), types.KeyPrefix(types.MinterControllerKeyPrefix))
	store.Delete(types.MinterControllerKey(
		controller, minter,
	))
}

// GetAllMinterController returns all minterController
func (k Keeper) GetAllMinterControllers(ctx sdk.Context) (list []types.MinterController) {
	store := prefix.NewStore(ctx.KVStore(k.storeKey), types.KeyPrefix(types.MinterControllerKeyPrefix))
	iterator := sdktypes.KVStorePrefixIterator(store, []byte{})

	defer iterator.Close()

	for ; iterator.Valid(); iterator.Next() {
		var val types.MinterController
		k.cdc.MustUnmarshal(iterator.Value(), &val)
		list = append(list, val)
	}

	return
}
