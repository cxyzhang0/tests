package keeper_test

import (
	"context"
	"testing"

	"cosmossdk.io/log"
	"cosmossdk.io/math"
	"cosmossdk.io/store"
	"cosmossdk.io/store/metrics"
	sdktypes "cosmossdk.io/store/types"
	storetypes "cosmossdk.io/store/types"
	tmproto "github.com/cometbft/cometbft/proto/tendermint/types"
	dbm "github.com/cosmos/cosmos-db"
	"github.com/cosmos/cosmos-sdk/codec"
	codectypes "github.com/cosmos/cosmos-sdk/codec/types"
	"github.com/cosmos/cosmos-sdk/runtime"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/cosmos/cosmos-sdk/types/bech32"
	banktypes "github.com/cosmos/cosmos-sdk/x/bank/types"
	paramtypes "github.com/cosmos/cosmos-sdk/x/params/types"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"
	"github.com/wfblockchain/coreblockchain/v2/testutil/sample"
	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/keeper"
	tfkeeper "github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/keeper"
	tokenfactorymodulekeeper "github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/keeper"
	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"
	tokenfactorymoduletypes "github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"
)

// --------------------------------------------
// go test ./x/tokenfactory -run '^Test'
// go test ./x/tokenfactory -run '^TestUpdateMasterMinter|^TestUpdateMasterMinter_FailsWhenAddressAlreadyPauser|^TestUpdateMasterMinter_FailsWhenAddressAlreadyBlacklister'
// --------------------------------------------

type MockKeeper struct {
	mock.Mock
}

func (m *MockKeeper) GetOwner(ctx sdk.Context) (types.Owner, bool) {
	args := m.Called(ctx)
	return args.Get(0).(types.Owner), args.Bool(1)
}

func (m *MockKeeper) ValidatePrivileges(ctx sdk.Context, address string) error {
	args := m.Called(ctx, address)
	return args.Error(0)
}

func (m *MockKeeper) SetPauser(ctx sdk.Context, pauser types.Pauser) {
	m.Called(ctx, pauser)
}

func (m *MockKeeper) EmitTypedEvent(event sdk.Event) error {
	args := m.Called(event)
	return args.Error(0)
}

type TestMsgServer struct {
	keeper *MockKeeper
}

func NewMsgServer(keeper *tfkeeper.Keeper) types.MsgServer {
	return tfkeeper.NewMsgServerImpl(keeper)
}

type MockBankKeeper struct{}

func (m *MockBankKeeper) SpendableCoins(ctx context.Context, addr sdk.AccAddress) sdk.Coins {
	return sdk.Coins{}
}

func (m *MockBankKeeper) MintCoins(ctx context.Context, moduleName string, amt sdk.Coins) error {
	return nil
}

func (m *MockBankKeeper) BurnCoins(ctx context.Context, moduleName string, amt sdk.Coins) error {
	return nil
}

func (m *MockBankKeeper) SendCoinsFromModuleToAccount(ctx context.Context, senderModule string, recipientAddr sdk.AccAddress, amt sdk.Coins) error {
	return nil
}

func (m *MockBankKeeper) SendCoinsFromAccountToModule(ctx context.Context, senderAddr sdk.AccAddress, recipientModule string, amt sdk.Coins) error {
	return nil
}

func (m *MockBankKeeper) GetDenomMetaData(ctx context.Context, denom string) (banktypes.Metadata, bool) {
	if denom == "stake" {
		return banktypes.Metadata{
			DenomUnits: []*banktypes.DenomUnit{
				{Denom: "stake", Exponent: 0},
			},
		}, true
	}
	return banktypes.Metadata{}, false
}

func (m *MockBankKeeper) SetDenomMetaData(ctx context.Context, metadata banktypes.Metadata) {

}

func setupKeeper(t *testing.T) (*tokenfactorymodulekeeper.Keeper, types.MsgServer, sdk.Context) {
	db := dbm.NewMemDB()
	storeKey := sdktypes.NewKVStoreKey(tokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace

	var tfbankKeeper tokenfactorymoduletypes.BankKeeper = &MockBankKeeper{}

	k := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper, runtime.NewKVStoreService(storeKey))
	msgServer := keeper.NewMsgServerImpl(k)
	return k, msgServer, ctx
}

func TestUpdatePauser(t *testing.T) {
	k, msgServer, ctx := setupKeeper(t)

	ownerAddr := sample.AccAddress()
	pauserAddr := sample.AccAddress()
	unauthorizedAddr := sample.AccAddress()
	goCtx := (ctx)
	_, err := msgServer.UpdatePauser(goCtx, &types.MsgUpdatePauser{
		From:    ownerAddr,
		Address: pauserAddr,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "you are not the owner: unauthorized")
	k.SetOwner(ctx, types.Owner{Address: ownerAddr})
	_, err = msgServer.UpdatePauser(goCtx, &types.MsgUpdatePauser{
		From:    unauthorizedAddr,
		Address: pauserAddr,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "you are not the owner")
	k.SetPauser(ctx, types.Pauser{Address: pauserAddr})
	_, err = msgServer.UpdatePauser(goCtx, &types.MsgUpdatePauser{
		From:    ownerAddr,
		Address: pauserAddr,
	})
	require.Error(t, err)
	newPauserAddr := sample.AccAddress()
	_, err = msgServer.UpdatePauser(goCtx, &types.MsgUpdatePauser{
		From:    ownerAddr,
		Address: newPauserAddr,
	})
	require.NoError(t, err)
	pauser, found := k.GetPauser(ctx)
	require.True(t, found)
	require.Equal(t, newPauserAddr, pauser.Address)

}

func TestUpdateOwner(t *testing.T) {
	k, msgServer, ctx := setupKeeper(t)
	ownerAddr := sample.AccAddress()
	newOwnerAddr := sample.AccAddress()
	unauthorizedAddr := sample.AccAddress()
	goCtx := (ctx)
	_, err := msgServer.UpdateOwner(goCtx, &types.MsgUpdateOwner{
		From:    ownerAddr,
		Address: newOwnerAddr,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "you are not the owner: unauthorized")
	k.SetOwner(ctx, types.Owner{Address: ownerAddr})

	_, err = msgServer.UpdateOwner(goCtx, &types.MsgUpdateOwner{
		From:    unauthorizedAddr,
		Address: newOwnerAddr,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "you are not the owner")
	validNewOwnerAddr := sample.AccAddress()
	_, err = msgServer.UpdateOwner(goCtx, &types.MsgUpdateOwner{
		From:    ownerAddr,
		Address: validNewOwnerAddr,
	})
	require.NoError(t, err)
}

func TestUpdateMasterMinter(t *testing.T) {
	k, msgServer, ctx := setupKeeper(t)
	ownerAddr := sample.AccAddress()
	newMasterMinterAddr := sample.AccAddress()
	unauthorizedAddr := sample.AccAddress()
	goCtx := (ctx)
	_, err := msgServer.UpdateMasterMinter(goCtx, &types.MsgUpdateMasterMinter{
		From:    ownerAddr,
		Address: newMasterMinterAddr,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "you are not the owner: unauthorized")
	k.SetOwner(ctx, types.Owner{Address: ownerAddr})
	_, err = msgServer.UpdateMasterMinter(goCtx, &types.MsgUpdateMasterMinter{
		From:    unauthorizedAddr,
		Address: newMasterMinterAddr,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "you are not the owner")
	validNewMasterMinterAddr := sample.AccAddress()
	_, err = msgServer.UpdateMasterMinter(goCtx, &types.MsgUpdateMasterMinter{
		From:    ownerAddr,
		Address: validNewMasterMinterAddr,
	})
	require.NoError(t, err)
	masterMinter, found := k.GetMasterMinter(ctx)
	require.True(t, found)
	require.Equal(t, validNewMasterMinterAddr, masterMinter.Address)
}

func TestUpdateMasterMinter_FailsWhenAddressAlreadyPauser(t *testing.T) {
	k, msgServer, ctx := setupKeeper(t)
	ownerAddr := sample.AccAddress()
	conflictingAddr := sample.AccAddress()
	newPauserAddr := sample.AccAddress()
	goCtx := (ctx)

	k.SetOwner(ctx, types.Owner{Address: ownerAddr})
	k.SetPauser(ctx, types.Pauser{Address: conflictingAddr})

	_, err := msgServer.UpdateMasterMinter(goCtx, &types.MsgUpdateMasterMinter{
		From:    ownerAddr,
		Address: conflictingAddr,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "already assigned to privileged role")
	require.Contains(t, err.Error(), "pauser role")

	// clear conflict and verify update succeeds
	k.SetPauser(ctx, types.Pauser{Address: newPauserAddr})
	_, err = msgServer.UpdateMasterMinter(goCtx, &types.MsgUpdateMasterMinter{
		From:    ownerAddr,
		Address: conflictingAddr,
	})
	require.NoError(t, err)

	masterMinter, found := k.GetMasterMinter(ctx)
	require.True(t, found)
	require.Equal(t, conflictingAddr, masterMinter.Address)
}

func TestUpdateMasterMinter_FailsWhenAddressAlreadyBlacklister(t *testing.T) {
	k, msgServer, ctx := setupKeeper(t)
	ownerAddr := sample.AccAddress()
	conflictingAddr := sample.AccAddress()
	newBlacklisterAddr := sample.AccAddress()
	goCtx := (ctx)

	k.SetOwner(ctx, types.Owner{Address: ownerAddr})
	k.SetBlacklister(ctx, types.Blacklister{Address: conflictingAddr})

	_, err := msgServer.UpdateMasterMinter(goCtx, &types.MsgUpdateMasterMinter{
		From:    ownerAddr,
		Address: conflictingAddr,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "already assigned to privileged role")
	require.Contains(t, err.Error(), "black lister role")

	// clear conflict and verify update succeeds
	k.SetBlacklister(ctx, types.Blacklister{Address: newBlacklisterAddr})
	_, err = msgServer.UpdateMasterMinter(goCtx, &types.MsgUpdateMasterMinter{
		From:    ownerAddr,
		Address: conflictingAddr,
	})
	require.NoError(t, err)

	masterMinter, found := k.GetMasterMinter(ctx)
	require.True(t, found)
	require.Equal(t, conflictingAddr, masterMinter.Address)
}

func TestUpdateBlacklister(t *testing.T) {
	k, msgServer, ctx := setupKeeper(t)
	ownerAddr := sample.AccAddress()
	newBlacklisterAddr := sample.AccAddress()
	unauthorizedAddr := sample.AccAddress()
	goCtx := (ctx)
	_, err := msgServer.UpdateBlacklister(goCtx, &types.MsgUpdateBlacklister{
		From:    ownerAddr,
		Address: newBlacklisterAddr,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "you are not the owner: unauthorized")
	k.SetOwner(ctx, types.Owner{Address: ownerAddr})
	_, err = msgServer.UpdateBlacklister(goCtx, &types.MsgUpdateBlacklister{
		From:    unauthorizedAddr,
		Address: newBlacklisterAddr,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "you are not the owner")
	k.SetPauser(ctx, types.Pauser{Address: newBlacklisterAddr})
	_, err = msgServer.UpdateBlacklister(goCtx, &types.MsgUpdateBlacklister{
		From:    ownerAddr,
		Address: newBlacklisterAddr,
	})
	require.Error(t, err)
	validNewBlacklisterAddr := sample.AccAddress()
	_, err = msgServer.UpdateBlacklister(goCtx, &types.MsgUpdateBlacklister{
		From:    ownerAddr,
		Address: validNewBlacklisterAddr,
	})
	require.NoError(t, err)
	blacklister, found := k.GetBlacklister(ctx)
	require.True(t, found)
	require.Equal(t, validNewBlacklisterAddr, blacklister.Address)
}
func TestUnpause(t *testing.T) {
	k, msgServer, ctx := setupKeeper(t)
	pauserAddr := sample.AccAddress()
	unauthorizedAddr := sample.AccAddress()
	goCtx := (ctx)
	_, err := msgServer.Unpause(goCtx, &types.MsgUnpause{
		From: pauserAddr,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "you are not the pauser: unauthorized")
	k.SetPauser(ctx, types.Pauser{Address: pauserAddr})
	_, err = msgServer.Unpause(goCtx, &types.MsgUnpause{
		From: unauthorizedAddr,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "you are not the pauser")
	_, err = msgServer.Unpause(goCtx, &types.MsgUnpause{
		From: pauserAddr,
	})
	require.NoError(t, err)

}
func TestUnblacklist(t *testing.T) {
	k, msgServer, ctx := setupKeeper(t)
	blacklisterAddr := sample.AccAddress()
	unauthorizedAddr := sample.AccAddress()
	blacklistedAddr := sample.AccAddress()
	goCtx := (ctx)

	_, err := msgServer.Unblacklist(goCtx, &types.MsgUnblacklist{
		From:    blacklisterAddr,
		Address: blacklistedAddr,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "blacklister is not set")
	k.SetBlacklister(ctx, types.Blacklister{Address: blacklisterAddr})
	_, err = msgServer.Unblacklist(goCtx, &types.MsgUnblacklist{
		From:    unauthorizedAddr,
		Address: blacklistedAddr,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "you are not the blacklister")
	_, err = msgServer.Unblacklist(goCtx, &types.MsgUnblacklist{
		From:    blacklisterAddr,
		Address: blacklistedAddr,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "the specified address is not blacklisted")

	_, addressBz, _ := bech32.DecodeAndConvert(blacklistedAddr)
	k.SetBlacklisted(ctx, types.Blacklisted{AddressBz: addressBz})

	_, err = msgServer.Unblacklist(goCtx, &types.MsgUnblacklist{
		From:    blacklisterAddr,
		Address: blacklistedAddr,
	})
	require.NoError(t, err)
	_, found := k.GetBlacklisted(ctx, addressBz)
	require.False(t, found)
}
func TestRemoveMinter(t *testing.T) {
	k, msgServer, ctx := setupKeeper(t)
	denom := "uwfusd"
	controllerAddr := sample.AccAddress()
	unauthorizedAddr := sample.AccAddress()
	minterAddr := sample.AccAddress()
	invalidMinterAddr := sample.AccAddress()
	goCtx := sdk.WrapSDKContext(ctx)
	_, err := msgServer.RemoveMinter(goCtx, &types.MsgRemoveMinter{
		From:    controllerAddr,
		Address: minterAddr,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "minter controller not found")
	k.SetMinterController(ctx, types.MinterController{
		Controller: controllerAddr,
		Minter:     minterAddr,
	})
	_, err = msgServer.RemoveMinter(goCtx, &types.MsgRemoveMinter{
		From:    unauthorizedAddr,
		Address: minterAddr,
		Denom:   denom,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "minter controller not found: unauthorized")
	_, err = msgServer.RemoveMinter(goCtx, &types.MsgRemoveMinter{
		From:    controllerAddr,
		Address: invalidMinterAddr,
		Denom:   denom,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "minter controller not found: unauthorized")
	_, err = msgServer.RemoveMinter(goCtx, &types.MsgRemoveMinter{
		From:    controllerAddr,
		Address: minterAddr,
		Denom:   denom,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "a minter with a given address doesn't exist")
	k.SetMinters(ctx, types.Minters{Address: minterAddr,
		Allowance: sdk.NewCoin(denom, math.NewInt(1000)),
	})

	_, err = msgServer.RemoveMinter(goCtx, &types.MsgRemoveMinter{
		From:    controllerAddr,
		Address: minterAddr,
		Denom:   denom,
	})
	require.NoError(t, err)
	_, found := k.GetMinters(ctx, minterAddr, denom)
	require.False(t, found)
}
func TestRemoveMinterController(t *testing.T) {
	k, msgServer, ctx := setupKeeper(t)
	masterMinterAddr := sample.AccAddress()
	minterAddr := sample.AccAddress()
	unauthorizedAddr := sample.AccAddress()
	controllerAddr := sample.AccAddress()
	nonExistentControllerAddr := sample.AccAddress()
	goCtx := sdk.WrapSDKContext(ctx)
	_, err := msgServer.RemoveMinterController(goCtx, &types.MsgRemoveMinterController{
		From:       masterMinterAddr,
		Controller: controllerAddr,
		Minter:     minterAddr,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "master minter is not set")
	k.SetMasterMinter(ctx, types.MasterMinter{Address: masterMinterAddr})
	_, err = msgServer.RemoveMinterController(goCtx, &types.MsgRemoveMinterController{
		From:       unauthorizedAddr,
		Controller: controllerAddr,
		Minter:     minterAddr,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "you are not the master minter")
	_, err = msgServer.RemoveMinterController(goCtx, &types.MsgRemoveMinterController{
		From:       masterMinterAddr,
		Controller: nonExistentControllerAddr,
		Minter:     minterAddr,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "minter controller with a given address")
	k.SetMinterController(ctx, types.MinterController{
		Controller: controllerAddr,
		Minter:     minterAddr,
	})

	_, err = msgServer.RemoveMinterController(goCtx, &types.MsgRemoveMinterController{
		From:       masterMinterAddr,
		Controller: controllerAddr,
		Minter:     minterAddr,
	})
	require.NoError(t, err)
	_, found := k.GetMinterController(ctx, controllerAddr, minterAddr)
	require.False(t, found)
}
func TestPause(t *testing.T) {
	k, msgServer, ctx := setupKeeper(t)
	pauserAddr := sample.AccAddress()
	unauthorizedAddr := sample.AccAddress()
	goCtx := sdk.WrapSDKContext(ctx)
	_, err := msgServer.Pause(goCtx, &types.MsgPause{
		From: pauserAddr,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "you are not the pauser: unauthorized")
	k.SetPauser(ctx, types.Pauser{Address: pauserAddr})
	_, err = msgServer.Pause(goCtx, &types.MsgPause{
		From: unauthorizedAddr,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "you are not the pauser")
	_, err = msgServer.Pause(goCtx, &types.MsgPause{
		From: pauserAddr,
	})
	require.NoError(t, err)
	paused := k.GetPaused(ctx)

	require.True(t, paused.Paused)
}

func TestConfigureMinter(t *testing.T) {
	k, msgServer, ctx := setupKeeper(t)
	controllerAddr := sample.AccAddress()
	minterAddr := sample.AccAddress()
	unauthorizedAddr := sample.AccAddress()
	mintingDenom := "stake"
	k.SetMintingDenom(ctx, types.MintingDenom{Denom: mintingDenom})
	goCtx := sdk.WrapSDKContext(ctx)
	_, err := msgServer.ConfigureMinter(goCtx, &types.MsgConfigureMinter{
		From:      controllerAddr,
		Address:   minterAddr,
		Allowance: sdk.NewCoin(mintingDenom, math.NewInt(1000)),
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "minter controller not found")
	k.SetMinterController(ctx, types.MinterController{
		Controller: controllerAddr,
		Minter:     minterAddr,
	})
	_, err = msgServer.ConfigureMinter(goCtx, &types.MsgConfigureMinter{
		From:      controllerAddr,
		Address:   minterAddr,
		Allowance: sdk.NewCoin("wrongdenom", math.NewInt(1000)),
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "wrongdenom is not a minting denom: tokens can not be minted")
	_, err = msgServer.ConfigureMinter(goCtx, &types.MsgConfigureMinter{
		From:      unauthorizedAddr,
		Address:   minterAddr,
		Allowance: sdk.NewCoin(mintingDenom, math.NewInt(1000)),
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "minter controller not found: unauthorized")
	wrongMinterAddr := sample.AccAddress()
	_, err = msgServer.ConfigureMinter(goCtx, &types.MsgConfigureMinter{
		From:      controllerAddr,
		Address:   wrongMinterAddr,
		Allowance: sdk.NewCoin(mintingDenom, math.NewInt(1000)),
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "minter controller not found: unauthorized")
	_, err = msgServer.ConfigureMinter(goCtx, &types.MsgConfigureMinter{
		From:      controllerAddr,
		Address:   minterAddr,
		Allowance: sdk.NewCoin(mintingDenom, math.NewInt(1000)),
	})
	require.NoError(t, err)
	minter, found := k.GetMinters(ctx, minterAddr, mintingDenom)
	require.True(t, found)
	require.Equal(t, minter.Address, minterAddr)
	require.Equal(t, minter.Allowance.Amount.Int64(), int64(1000))
}
func TestConfigureMinterController(t *testing.T) {
	k, msgServer, ctx := setupKeeper(t)
	masterMinterAddr := sample.AccAddress()
	controllerAddr := sample.AccAddress()
	minterAddr := sample.AccAddress()
	unauthorizedAddr := sample.AccAddress()
	goCtx := sdk.WrapSDKContext(ctx)
	_, err := msgServer.ConfigureMinterController(goCtx, &types.MsgConfigureMinterController{
		From:       masterMinterAddr,
		Minter:     minterAddr,
		Controller: controllerAddr,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "master minter is not set")
	k.SetMasterMinter(ctx, types.MasterMinter{Address: masterMinterAddr})
	_, err = msgServer.ConfigureMinterController(goCtx, &types.MsgConfigureMinterController{
		From:       unauthorizedAddr,
		Minter:     minterAddr,
		Controller: controllerAddr,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "you are not the master minter")
	_, err = msgServer.ConfigureMinterController(goCtx, &types.MsgConfigureMinterController{
		From:       masterMinterAddr,
		Minter:     minterAddr,
		Controller: controllerAddr,
	})
	require.NoError(t, err)
	minterController, found := k.GetMinterController(ctx, controllerAddr, minterAddr)

	require.True(t, found)
	require.Equal(t, minterController.Minter, minterAddr)
	require.Equal(t, minterController.Controller, controllerAddr)
}

func TestBlacklist(t *testing.T) {
	k, msgServer, ctx := setupKeeper(t)

	blacklisterAddr := sample.AccAddress()
	unauthorizedAddr := sample.AccAddress()
	targetAddr := sample.AccAddress()
	targetAddrBech32, err := bech32.ConvertAndEncode(sdk.GetConfig().GetBech32AccountAddrPrefix(), []byte(targetAddr))
	require.NoError(t, err)
	goCtx := sdk.WrapSDKContext(ctx)
	_, err = msgServer.Blacklist(goCtx, &types.MsgBlacklist{
		From:    blacklisterAddr,
		Address: targetAddrBech32,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "blacklister is not set")
	k.SetBlacklister(ctx, types.Blacklister{Address: blacklisterAddr})
	_, err = msgServer.Blacklist(goCtx, &types.MsgBlacklist{
		From:    unauthorizedAddr,
		Address: targetAddrBech32,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "you are not the blacklister")

	_, err = msgServer.Blacklist(goCtx, &types.MsgBlacklist{
		From:    blacklisterAddr,
		Address: "",
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "invalid address:")

	_, err = msgServer.Blacklist(goCtx, &types.MsgBlacklist{
		From:    blacklisterAddr,
		Address: targetAddrBech32,
	})
	require.NoError(t, err)
	_, addressBz, err := bech32.DecodeAndConvert(targetAddrBech32)
	require.NoError(t, err)

	_, found := k.GetBlacklisted(ctx, addressBz)
	require.True(t, found, "expected address to be blacklisted")
	_, err = msgServer.Blacklist(goCtx, &types.MsgBlacklist{
		From:    blacklisterAddr,
		Address: targetAddrBech32,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "user is already blacklisted")
}
func TestAcceptOwner(t *testing.T) {
	k, msgServer, ctx := setupKeeper(t)

	pendingOwnerAddr := sample.AccAddress()
	unauthorizedAddr := sample.AccAddress()
	goCtx := sdk.WrapSDKContext(ctx)
	_, err := msgServer.AcceptOwner(goCtx, &types.MsgAcceptOwner{
		From: pendingOwnerAddr,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "pending owner is not set: user not found")
	k.SetPendingOwner(ctx, tokenfactorymoduletypes.Owner{Address: pendingOwnerAddr})
	_, err = msgServer.AcceptOwner(goCtx, &types.MsgAcceptOwner{
		From: unauthorizedAddr,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "you are not the pending owner")
	_, err = msgServer.AcceptOwner(goCtx, &types.MsgAcceptOwner{
		From: pendingOwnerAddr,
	})
	require.NoError(t, err)
	owner, found := k.GetOwner(ctx)
	require.True(t, found, "expected owner to be set")
	require.Equal(t, pendingOwnerAddr, owner.Address)
	_, found = k.GetPendingOwner(ctx)
	require.False(t, found, "expected pending owner to be deleted")
}

func TestAcceptOwner_FailsWhenPendingOwnerIsPauser(t *testing.T) {
	k, msgServer, ctx := setupKeeper(t)

	pendingOwnerAddr := sample.AccAddress()
	replacementPauserAddr := sample.AccAddress()
	goCtx := sdk.WrapSDKContext(ctx)

	k.SetPendingOwner(ctx, tokenfactorymoduletypes.Owner{Address: pendingOwnerAddr})
	k.SetPauser(ctx, types.Pauser{Address: pendingOwnerAddr})

	_, err := msgServer.AcceptOwner(goCtx, &types.MsgAcceptOwner{
		From: pendingOwnerAddr,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "already assigned to privileged role")
	require.Contains(t, err.Error(), "pauser role")

	// clear the conflict and ensure acceptance succeeds
	k.SetPauser(ctx, types.Pauser{Address: replacementPauserAddr})
	_, err = msgServer.AcceptOwner(goCtx, &types.MsgAcceptOwner{
		From: pendingOwnerAddr,
	})
	require.NoError(t, err)

	owner, found := k.GetOwner(ctx)
	require.True(t, found, "expected owner to be set after pauser conflict is cleared")
	require.Equal(t, pendingOwnerAddr, owner.Address)
	_, found = k.GetPendingOwner(ctx)
	require.False(t, found, "expected pending owner to be deleted after successful acceptance")
}

func TestAcceptOwner_FailsWhenPendingOwnerIsBlacklister(t *testing.T) {
	k, msgServer, ctx := setupKeeper(t)

	pendingOwnerAddr := sample.AccAddress()
	replacementBlacklisterAddr := sample.AccAddress()
	goCtx := sdk.WrapSDKContext(ctx)

	k.SetPendingOwner(ctx, tokenfactorymoduletypes.Owner{Address: pendingOwnerAddr})
	k.SetBlacklister(ctx, types.Blacklister{Address: pendingOwnerAddr})

	_, err := msgServer.AcceptOwner(goCtx, &types.MsgAcceptOwner{
		From: pendingOwnerAddr,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "already assigned to privileged role")
	require.Contains(t, err.Error(), "black lister role")

	// clear the conflict and ensure acceptance succeeds
	k.SetBlacklister(ctx, types.Blacklister{Address: replacementBlacklisterAddr})
	_, err = msgServer.AcceptOwner(goCtx, &types.MsgAcceptOwner{
		From: pendingOwnerAddr,
	})
	require.NoError(t, err)

	owner, found := k.GetOwner(ctx)
	require.True(t, found, "expected owner to be set after blacklister conflict is cleared")
	require.Equal(t, pendingOwnerAddr, owner.Address)
	_, found = k.GetPendingOwner(ctx)
	require.False(t, found, "expected pending owner to be deleted after successful acceptance")
}

func TestMint(t *testing.T) {
	k, msgServer, ctx := setupKeeper(t)

	minterAddr := sample.AccAddress()
	unauthorizedAddr := sample.AccAddress()
	receiverAddr := sample.AccAddress()
	validAmount := sdk.NewCoin("stake", math.NewInt(100))
	goCtx := sdk.WrapSDKContext(ctx)
	_, err := msgServer.Mint(goCtx, &types.MsgMint{
		From:    unauthorizedAddr,
		Address: receiverAddr,
		Amount:  validAmount,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "you are not a minter")
	k.SetMinters(ctx, tokenfactorymoduletypes.Minters{
		Address:   minterAddr,
		Allowance: sdk.NewCoin("stake", math.NewInt(200)),
	})
	_, minterBz, _ := bech32.DecodeAndConvert(minterAddr)
	k.SetBlacklisted(ctx, types.Blacklisted{AddressBz: minterBz})

	_, err = msgServer.Mint(goCtx, &types.MsgMint{
		From:    minterAddr,
		Address: receiverAddr,
		Amount:  validAmount,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "minter address is blacklisted")
	k.RemoveBlacklisted(ctx, minterBz)
	_, receiverBz, _ := bech32.DecodeAndConvert(receiverAddr)
	k.SetBlacklisted(ctx, types.Blacklisted{AddressBz: receiverBz})

	_, err = msgServer.Mint(goCtx, &types.MsgMint{
		From:    minterAddr,
		Address: receiverAddr,
		Amount:  validAmount,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "receiver address is blacklisted")
	k.RemoveBlacklisted(ctx, receiverBz)
	defer func() {
		if r := recover(); r == nil {
			t.Logf("The code did not panic as expected")
		}
	}()
	k.SetMintingDenom(ctx, types.MintingDenom{Denom: "incorrect"})

	_, err = msgServer.Mint(goCtx, &types.MsgMint{
		From:    minterAddr,
		Address: receiverAddr,
		Amount:  validAmount,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "stake is not a minting denom: tokens can not be minted")
	k.SetPaused(ctx, types.Paused{Paused: true})

	_, err = msgServer.Mint(goCtx, &types.MsgMint{
		From:    minterAddr,
		Address: receiverAddr,
		Amount:  sdk.NewCoin("stake", math.NewInt(100)),
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "stake is not a minting denom: tokens can not be minted")
}

func TestMintValidDenom(t *testing.T) {
	k, msgServer, ctx := setupKeeper(t)

	minterAddr := sample.AccAddress()
	k.SetMinters(ctx, tokenfactorymoduletypes.Minters{
		Address:   minterAddr,
		Allowance: sdk.NewCoin("stake", math.NewInt(200)),
	})

	receiverAddr := sample.AccAddress()
	goCtx := sdk.WrapSDKContext(ctx)
	k.SetMintingDenom(ctx, types.MintingDenom{Denom: "stake"})
	_, err := msgServer.Mint(goCtx, &types.MsgMint{
		From:    minterAddr,
		Address: receiverAddr,
		Amount:  sdk.NewCoin("stake", math.NewInt(100)),
	})
	require.NoError(t, err)
}

func TestBurn(t *testing.T) {
	k, msgServer, ctx := setupKeeper(t)

	minterAddr := sample.AccAddress()
	unauthorizedAddr := sample.AccAddress()
	validAmount := sdk.NewCoin("stake", math.NewInt(100))
	goCtx := sdk.WrapSDKContext(ctx)
	_, err := msgServer.Burn(goCtx, &types.MsgBurn{
		From:   unauthorizedAddr,
		Amount: validAmount,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "you are not a minter")
	k.SetMinters(ctx, tokenfactorymoduletypes.Minters{
		Address:   minterAddr,
		Allowance: sdk.NewCoin("stake", math.NewInt(200)),
	})
	_, minterBz, _ := bech32.DecodeAndConvert(minterAddr)
	k.SetBlacklisted(ctx, types.Blacklisted{AddressBz: minterBz})

	_, err = msgServer.Burn(goCtx, &types.MsgBurn{
		From:   minterAddr,
		Amount: validAmount,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "minter address is blacklisted")
	k.RemoveBlacklisted(ctx, minterBz)
	defer func() {
		if r := recover(); r == nil {
			t.Logf("The code did not panic as expected")
		}
	}()
	k.SetMintingDenom(ctx, types.MintingDenom{Denom: "incorrect"})

	_, err = msgServer.Burn(goCtx, &types.MsgBurn{
		From:   minterAddr,
		Amount: validAmount,
	})
	require.Error(t, err)
	require.Contains(t, err.Error(), "stake is not minting denom: tokens can not be burned")

}

func TestMinterAllowanceAfterBurn(t *testing.T) {
	k, msgServer, ctx := setupKeeper(t)

	minterAddr := sample.AccAddress()
	k.SetMinters(ctx, tokenfactorymoduletypes.Minters{
		Address:   minterAddr,
		Allowance: sdk.NewCoin("stake", math.NewInt(200)),
	})
	goCtx := sdk.WrapSDKContext(ctx)
	k.SetMintingDenom(ctx, types.MintingDenom{Denom: "stake"})
	_, err := msgServer.Burn(goCtx, &types.MsgBurn{
		From:   minterAddr,
		Amount: sdk.NewCoin("stake", math.NewInt(100)),
	})
	require.NoError(t, err)

}
