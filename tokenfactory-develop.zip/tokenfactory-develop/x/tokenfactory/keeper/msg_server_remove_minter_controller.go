package keeper

import (
	"context"

	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"

	sdkerrors "cosmossdk.io/errors"
	sdk "github.com/cosmos/cosmos-sdk/types"
)

// RemoveMinterController remove (Controller, Minter) from the store if the minter has zero allowance
func (k msgServer) RemoveMinterController(goCtx context.Context, msg *types.MsgRemoveMinterController) (*types.MsgRemoveMinterControllerResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	masterMinter, found := k.GetMasterMinter(ctx)
	if !found {
		return nil, sdkerrors.Wrapf(types.ErrUserNotFound, "master minter is not set")
	}

	if msg.From != masterMinter.Address {
		return nil, sdkerrors.Wrapf(types.ErrUnauthorized, "you are not the master minter")
	}

	mc, found := k.GetMinterController(ctx, msg.Controller, msg.Minter)
	if !found {
		return nil, sdkerrors.Wrapf(types.ErrUserNotFound, "minter controller with a given address (%s) doesn't exist", msg.Controller)
	}

	// check if the assigned minter has non-zero allowance
	for _, m := range k.GetAllMinters(ctx) {
		if m.Address == mc.Minter && !m.Allowance.IsZero() {
			return nil, sdkerrors.Wrapf(types.ErrRemoveController, "its assigned minter still has allowance")
		}
	}
	/*
		minter, found := k.GetMinters(ctx, mc.Minter)
		if found && !minter.Allowance.IsZero() {
			return nil, sdkerrors.Wrapf(types.ErrRemoveController, "its assigned minter still has allowance")
		}
	*/

	k.DeleteMinterController(ctx, msg.Controller, msg.Minter)

	return &types.MsgRemoveMinterControllerResponse{}, nil
}
