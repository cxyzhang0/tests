package keeper_test

import (
	"testing"

	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/stretchr/testify/require"

	keepertest "github.com/wfblockchain/coreblockchain/v2/testutil/keeper"
	"github.com/wfblockchain/coreblockchain/v2/testutil/nullify"
	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/keeper"
	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"
)

func createTestMintingDenom(keeper *keeper.Keeper, ctx sdk.Context) types.MintingDenom {
	item := types.MintingDenom{
		Denom: "abcd",
	}
	keeper.SetMintingDenom(ctx, item)
	return item
}

func TestMintingDenomGet(t *testing.T) {
	keeper, ctx := keepertest.TokenfactoryKeeper(t)
	item := createTestMintingDenom(keeper, ctx)
	rst, _ := keeper.GetMintingDenom(ctx, item.Denom)
	require.Equal(t,
		nullify.Fill(&item),
		nullify.Fill(&rst),
	)
}
