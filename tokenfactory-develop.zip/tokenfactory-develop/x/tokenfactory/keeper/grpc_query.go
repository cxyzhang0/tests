package keeper

import (
	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"
)

var _ types.QueryServer = Keeper{}
