package keeper

import (
	"context"

	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"

	sdkerrors "cosmossdk.io/errors"
	sdk "github.com/cosmos/cosmos-sdk/types"
)

func (k msgServer) UpdateOwner(goCtx context.Context, msg *types.MsgUpdateOwner) (*types.MsgUpdateOwnerResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	owner, _ := k.GetOwner(ctx)
	if owner.Address != msg.From {
		return nil, sdkerrors.Wrapf(types.ErrUnauthorized, "you are not the owner")
	}

	// Note: k.ValidatePrivileges(ctx, msg.Address) is postponed until AcceptOwner,
	// because that is the point at which the new owner address is actually assigned to the owner role.

	owner.Address = msg.Address

	k.SetPendingOwner(ctx, owner)

	err := ctx.EventManager().EmitTypedEvent(msg)

	return &types.MsgUpdateOwnerResponse{}, err
}
