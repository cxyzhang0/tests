package keeper

import (
	"context"

	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"

	sdkerrors "cosmossdk.io/errors"
	sdk "github.com/cosmos/cosmos-sdk/types"
)

func (k msgServer) UpdateOwner(goCtx context.Context, msg *types.MsgUpdateOwner) (*types.MsgUpdateOwnerResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	owner, _ := k.GetOwner(ctx)
	if owner.Address != msg.From {
		return nil, sdkerrors.Wrapf(types.ErrUnauthorized, "you are not the owner")
	}

	// ensure that the specified address is not already assigned to a privileged role
	k.ValidatePrivileges(ctx, msg.Address)

	owner.Address = msg.Address

	k.SetPendingOwner(ctx, owner)

	err := ctx.EventManager().EmitTypedEvent(msg)

	return &types.MsgUpdateOwnerResponse{}, err
}
