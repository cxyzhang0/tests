package tokenfactory_test

import (
	"context"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"cosmossdk.io/log"
	"cosmossdk.io/math"
	"cosmossdk.io/x/tx/signing"
	abci "github.com/cometbft/cometbft/abci/types"
	tmproto "github.com/cometbft/cometbft/proto/tendermint/types"
	"github.com/cosmos/cosmos-sdk/client"
	"github.com/cosmos/cosmos-sdk/codec"
	codectypes "github.com/cosmos/cosmos-sdk/codec/types"
	sdk "github.com/cosmos/cosmos-sdk/types"
	sdktypes "github.com/cosmos/cosmos-sdk/types"
	banktypes "github.com/cosmos/cosmos-sdk/x/bank/types"
	"github.com/cosmos/gogoproto/proto"
	"github.com/gorilla/mux"
	"github.com/grpc-ecosystem/grpc-gateway/runtime"
	"github.com/stretchr/testify/assert"
	keepertest "github.com/wfblockchain/coreblockchain/v2/testutil/keeper"
	"github.com/wfblockchain/coreblockchain/v2/testutil/nullify"
	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory"
	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/client/cli"
	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/keeper"
	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"
	"google.golang.org/protobuf/reflect/protoreflect"

	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"
)

func TestGenesis(t *testing.T) {
	genesisState := types.GenesisState{
		Params: types.DefaultParams(),

		BlacklistedList: []types.Blacklisted{
			{
				AddressBz: []byte("0"),
			},
			{
				AddressBz: []byte("1"),
			},
		},
		Paused: &types.Paused{
			Paused: true,
		},
		MasterMinter: &types.MasterMinter{
			Address: "79",
		},
		MintersList: []types.Minters{
			{
				Address: "0",
			},
			{
				Address: "1",
			},
		},
		Pauser: &types.Pauser{
			Address: "96",
		},
		Blacklister: &types.Blacklister{
			Address: "20",
		},
		Owner: &types.Owner{
			Address: "98",
		},
		MinterControllerList: []types.MinterController{
			{
				Minter: "0",
			},
			{
				Minter: "1",
			},
		},
		MintingDenomList: []types.MintingDenom{
			{Denom: "65"},
		},
	}

	k, ctx := keepertest.TokenfactoryKeeper(t)
	tokenfactory.InitGenesis(ctx, k, keepertest.MockBankKeeper{}, genesisState)
	got := tokenfactory.ExportGenesis(ctx, k)
	require.NotNil(t, got)

	nullify.Fill(&genesisState)
	nullify.Fill(got)

	require.ElementsMatch(t, genesisState.BlacklistedList, got.BlacklistedList)
	require.Equal(t, genesisState.Paused, got.Paused)
	require.Equal(t, genesisState.MasterMinter, got.MasterMinter)
	require.ElementsMatch(t, genesisState.MintersList, got.MintersList)
	require.Equal(t, genesisState.Pauser, got.Pauser)
	require.Equal(t, genesisState.Blacklister, got.Blacklister)
	require.Equal(t, genesisState.Owner, got.Owner)
	require.ElementsMatch(t, genesisState.MinterControllerList, got.MinterControllerList)
	require.Equal(t, genesisState.MintingDenomList, got.MintingDenomList)
	// this line is used by starport scaffolding # genesis/test/assert
}

func TestAppModule_ConsensusVersion(t *testing.T) {
	appModule := tokenfactory.AppModule{}
	version := appModule.ConsensusVersion()
	assert.Equal(t, uint64(2), version)
}

func TestGetTxCmd(t *testing.T) {
	appModuleBasic := tokenfactory.AppModuleBasic{}
	txCmd := appModuleBasic.GetTxCmd()
	require.NotNil(t, txCmd, "GetTxCmd() should not return nil")
	require.Equal(t, "tokenfactory", txCmd.Use, "Transaction command should have the correct name")
	subCommands := txCmd.Commands()
	require.NotEmpty(t, subCommands, "Transaction command should have subcommands")
	for _, cmd := range subCommands {
		t.Logf("Found subcommand: %s", cmd.Use)
	}
	expectedSubcommands := []string{
		"accept-owner",
		"blacklist",
		"burn",
		"configure-minter",
		"configure-minter-controller",
		"mint",
		"pause",
		"remove-minter",
		"remove-minter-controller",
		"unblacklist",
		"unpause",
		"update-blacklister",
		"update-master-minter",
		"update-owner",
		"update-pauser",
	}

	for _, expected := range expectedSubcommands {
		found := false
		for _, cmd := range subCommands {
			if strings.HasPrefix(cmd.Use, expected) {
				found = true
				break
			}
		}
		require.Truef(t, found, "Expected subcommand %q not found", expected)
	}
}

func TestGetQueryCmd(t *testing.T) {
	queryRoute := "tokenfactory"
	queryCmd := cli.GetQueryCmd(queryRoute)
	require.NotNil(t, queryCmd, "GetQueryCmd() should not return nil")
	require.NotEmpty(t, queryCmd.Use, "Query command should have a name")
	require.Equal(t, types.ModuleName, queryCmd.Use, "Query command should match module name")
	subCommands := queryCmd.Commands()
	require.NotEmpty(t, subCommands, "Query command should have subcommands")
	for _, cmd := range subCommands {
		t.Logf("Found subcommand: %s", cmd.Use)
	}
	expectedSubcommands := []string{
		"params",
		"list-blacklisted",
		"show-blacklisted",
		"show-paused",
		"show-master-minter",
		"list-minters",
		"show-minters",
		"show-pauser",
		"show-blacklister",
		"show-owner",
		"list-minter-controller",
		"show-minter-controller",
		"show-minting-denom",
	}
	for _, expected := range expectedSubcommands {
		found := false
		for _, cmd := range subCommands {
			if strings.HasPrefix(cmd.Use, expected) {
				found = true
				break
			}
		}
		require.Truef(t, found, "Expected subcommand %q not found", expected)
	}
}
func TestIsAppModule(t *testing.T) {
	am := tokenfactory.AppModule{}
	require.NotPanics(t, func() {
		am.IsAppModule()
	}, "IsAppModule should not panic")
}

func TestIsOnePerModuleType(t *testing.T) {
	am := tokenfactory.AppModule{}
	require.NotPanics(t, func() {
		am.IsOnePerModuleType()
	}, "IsOnePerModuleType should not panic")
}

func TestAppModuleBasicName(t *testing.T) {
	amb := tokenfactory.AppModuleBasic{}
	expectedName := types.ModuleName

	actualName := amb.Name()

	require.Equal(t, expectedName, actualName, "AppModuleBasic.Name() should return the correct module name")
}

func TestAppModuleBasicRegisterLegacyAminoCodec(t *testing.T) {
	cdc := codec.NewLegacyAmino()
	amb := tokenfactory.AppModuleBasic{}
	amb.RegisterLegacyAminoCodec(cdc)
	expectedType := types.GenesisState{}
	_, err := cdc.MarshalJSON(expectedType)

	require.NoError(t, err, "RegisterLegacyAminoCodec should register the expected types without errors")
}

func TestRegisterRESTRoutes(t *testing.T) {
	ctx := client.Context{}
	router := mux.NewRouter()
	am := tokenfactory.AppModuleBasic{}
	am.RegisterRESTRoutes(ctx, router)
	routeFound := false
	router.Walk(func(route *mux.Route, router *mux.Router, ancestors []*mux.Route) error {
		path, _ := route.GetPathTemplate()
		methods, _ := route.GetMethods()

		if path == "/tokenfactory/register-account" && containsMethod(methods, http.MethodPost) {
			routeFound = true
			return nil
		}
		return nil
	})
	require.True(t, routeFound, "/tariff/register-account with POST method should be registered")

}

func containsMethod(methods []string, method string) bool {
	for _, m := range methods {
		if m == method {
			return true
		}
	}
	return false
}

func TestNewAppModuleBasic(t *testing.T) {
	interfaceRegistry := codectypes.NewInterfaceRegistry()
	cdc := codec.NewProtoCodec(interfaceRegistry)
	appModuleBasic := tokenfactory.NewAppModuleBasic(cdc)
	require.NotNil(t, appModuleBasic, "AppModuleBasic should not be nil")
}

func TestRegisterInterfaces(t *testing.T) {
	interfaceRegistry := codectypes.NewInterfaceRegistry()
	cdc := codec.NewProtoCodec(interfaceRegistry)
	appModuleBasic := tokenfactory.NewAppModuleBasic(cdc)
	appModuleBasic.RegisterInterfaces(interfaceRegistry)
	require.NotNil(t, interfaceRegistry, "InterfaceRegistry should not be nil")
}

type MockInterfaceRegistry struct {
	mock.Mock
	codectypes.InterfaceRegistry
}

func (m *MockInterfaceRegistry) RegisterInterface(protoName string, iface interface{}, impls ...proto.Message) {
	m.Called(protoName, iface, impls)
}

func (m *MockInterfaceRegistry) RegisterImplementations(iface interface{}, impls ...proto.Message) {
	m.Called(iface, impls)
}

func (m *MockInterfaceRegistry) Resolve(typeURL string) (proto.Message, error) {
	args := m.Called(typeURL)
	return args.Get(0).(proto.Message), args.Error(1)
}

func (m *MockInterfaceRegistry) FindDescriptorByName(name protoreflect.FullName) (protoreflect.Descriptor, error) {
	args := m.Called(name)
	return args.Get(0).(protoreflect.Descriptor), args.Error(1)
}

func (m *MockInterfaceRegistry) FindFileByPath(path string) (protoreflect.FileDescriptor, error) {
	args := m.Called(path)
	return args.Get(0).(protoreflect.FileDescriptor), args.Error(1)
}

func (m *MockInterfaceRegistry) ListAllInterfaces() []string {
	args := m.Called()
	return args.Get(0).([]string)
}

func (m *MockInterfaceRegistry) ListImplementations(iface string) []string {
	args := m.Called(iface)
	return args.Get(0).([]string)
}

func (m *MockInterfaceRegistry) RangeFiles(f func(protoreflect.FileDescriptor) bool) {
	m.Called(f)
}

func (m *MockInterfaceRegistry) SigningContext() *signing.Context {
	args := m.Called()
	return args.Get(0).(*signing.Context)
}

func (m *MockInterfaceRegistry) UnpackAny(any *codectypes.Any, iface interface{}) error {
	args := m.Called(any, iface)
	return args.Error(0)
}

func TestDefaultGenesis(t *testing.T) {
	interfaceRegistry := codectypes.NewInterfaceRegistry()
	cdc := codec.NewProtoCodec(interfaceRegistry)
	expectedGenesis := types.DefaultGenesis()

	expectedGenesisJSON, err := cdc.MarshalJSON(expectedGenesis)
	assert.NoError(t, err, "Expected no error while marshaling the expected genesis state")
	appModuleBasic := tokenfactory.NewAppModuleBasic(cdc)
	actualGenesisJSON := appModuleBasic.DefaultGenesis(cdc)
	assert.JSONEq(t, string(expectedGenesisJSON), string(actualGenesisJSON), "Genesis state should match")
}
func TestValidateGenesis(t *testing.T) {
	interfaceRegistry := codectypes.NewInterfaceRegistry()
	cdc := codec.NewProtoCodec(interfaceRegistry)
	var config client.TxEncodingConfig
	validGenesisState := types.GenesisState{}
	validGenesisJSON, err := cdc.MarshalJSON(&validGenesisState)
	assert.NoError(t, err, "Failed to marshal valid genesis state")
	appModuleBasic := tokenfactory.NewAppModuleBasic(cdc)
	err = appModuleBasic.ValidateGenesis(cdc, config, validGenesisJSON)
	assert.NoError(t, err, "Expected no error for valid genesis state")
	invalidGenesisJSON := []byte(`{"invalid_field": "invalid_value"}`)
	err = appModuleBasic.ValidateGenesis(cdc, config, invalidGenesisJSON)
	assert.Error(t, err, "Expected error for invalid genesis state")
	assert.Contains(t, err.Error(), "failed to unmarshal", "Error message should indicate unmarshaling failure")
}
func TestPostRegisterAccountHandler(t *testing.T) {
	req, err := http.NewRequest("POST", "/register", nil)
	assert.NoError(t, err, "Failed to create request")
	rr := httptest.NewRecorder()
	handler := http.HandlerFunc(tokenfactory.PostRegisterAccountHandler)
	handler.ServeHTTP(rr, req)
	assert.Equal(t, http.StatusOK, rr.Code, "Expected status code 200")
	expectedResponse := "Registration successful"
	assert.Equal(t, expectedResponse, rr.Body.String(), "Expected response body to be 'Registration successful'")

}

func TestRegisterGRPCGatewayRoutes(t *testing.T) {
	interfaceRegistry := codectypes.NewInterfaceRegistry()
	cdc := codec.NewProtoCodec(interfaceRegistry)
	clientCtx := client.Context{}
	mux := runtime.NewServeMux()
	appModuleBasic := tokenfactory.NewAppModuleBasic(cdc)
	appModuleBasic.RegisterGRPCGatewayRoutes(clientCtx, mux)
	assert.NotNil(t, mux, "Expected mux to be initialized")
}
func TestGetQueryCmd2(t *testing.T) {
	appModuleBasic := tokenfactory.NewAppModuleBasic(nil)
	cmd := appModuleBasic.GetQueryCmd()
	assert.NotNil(t, cmd, "Expected GetQueryCmd to return a non-nil command")
	expectedCmdName := "tokenfactory"
	assert.Equal(t, expectedCmdName, cmd.Use, "Expected the command name to be 'query'")
	err := cmd.Execute()
	assert.NoError(t, err, "Expected the query command to execute without error")
}

type SimpleAccountKeeper struct{}
type SimpleBankKeeper struct{}

func (s *SimpleAccountKeeper) GetAccount(ctx context.Context, addr sdktypes.AccAddress) sdktypes.AccountI {
	return nil
}

func (s *SimpleBankKeeper) SendCoins(fromAddr string, toAddr string, amount sdktypes.Coin) error {
	return nil
}

func (s *SimpleBankKeeper) BurnCoins(ctx context.Context, addr string, amount sdktypes.Coins) error {
	return nil
}

func (s *SimpleBankKeeper) GetDenomMetaData(ctx context.Context, denom string) (banktypes.Metadata, bool) {
	return banktypes.Metadata{
		Name:    "mockCoin",
		Symbol:  "MC",
		Base:    denom,
		Display: denom,
		DenomUnits: []*banktypes.DenomUnit{
			{
				Denom:    denom,
				Exponent: 0,
			},
			{
				Denom:    "m" + denom,
				Exponent: 3,
			},
		},
	}, true
}

func (s *SimpleBankKeeper) MintCoins(ctx context.Context, moduleName string, amt sdktypes.Coins) error {
	fmt.Printf("Minting coins for module: %s\n", moduleName)
	fmt.Printf("Coins minted: %s\n", amt.String())
	return nil
}

func (s *SimpleBankKeeper) SendCoinsFromModuleToAccount(
	ctx context.Context, senderModule string, recipientAddr sdktypes.AccAddress, amt sdktypes.Coins) error {
	fmt.Printf("Sending coins from module: %s to account: %s\n", senderModule, recipientAddr.String())
	fmt.Printf("Amount sent: %s\n", amt.String())
	return nil
}

func (s *SimpleBankKeeper) SendCoinsFromAccountToModule(
	ctx context.Context, senderAddr sdktypes.AccAddress, recipientModule string, amt sdktypes.Coins) error {
	fmt.Printf("Sending coins from account: %s to module: %s\n", senderAddr.String(), recipientModule)
	fmt.Printf("Amount sent: %s\n", amt.String())
	return nil
}

func (s *SimpleBankKeeper) SpendableCoins(ctx context.Context, addr sdktypes.AccAddress) sdktypes.Coins {
	coins := sdktypes.NewCoins(
		sdktypes.NewCoin("mockCoin", math.NewInt(1000)),
		sdktypes.NewCoin("otherCoin", math.NewInt(500)),
	)
	return coins
}

func (m *SimpleBankKeeper) SetDenomMetaData(ctx context.Context, metadata banktypes.Metadata) {

}
func TestNewAppModule(t *testing.T) {
	interfaceRegistry := codectypes.NewInterfaceRegistry()
	cdc := codec.NewProtoCodec(interfaceRegistry)
	accountKeeper := &SimpleAccountKeeper{}
	bankKeeper := &SimpleBankKeeper{}
	keeper := &keeper.Keeper{}
	appModule := tokenfactory.NewAppModule(cdc, keeper, accountKeeper, bankKeeper)
	assert.NotNil(t, appModule, "Expected AppModule to be initialized")
}

type MockKeeper struct {
}

func TestEndBlock(t *testing.T) {
	appModule := tokenfactory.AppModule{
		AppModuleBasic: tokenfactory.AppModuleBasic{},
	}
	ctx := sdktypes.NewContext(nil, tmproto.Header{}, false, log.NewNopLogger())
	validatorUpdates := appModule.EndBlock(ctx, abci.RequestFinalizeBlock{})
	assert.NotNil(t, validatorUpdates, "Expected non-nil validator updates")
	assert.Empty(t, validatorUpdates, "Expected an empty slice of validator updates")
}

type MockRegistry struct {
	invariants []sdktypes.Invariant
}

func (m *MockRegistry) RegisterInvariant(invar sdktypes.Invariant) {
	m.invariants = append(m.invariants, invar)
}

func (m *MockRegistry) RegisterRoute(route, moduleName string, invariant sdktypes.Invariant) {
	m.RegisterInvariant(invariant)
}

func TestRegisterInvariants(t *testing.T) {
	appModule := tokenfactory.AppModule{
		AppModuleBasic: tokenfactory.AppModuleBasic{},
	}
	mockRegistry := &MockRegistry{}

	inv := sdktypes.Invariant(func(ctx sdk.Context) (string, bool) {
		return "dummy-invariant", true
	})
	mockRegistry.RegisterRoute("test_route", "test_module", inv)
	appModule.RegisterInvariants(mockRegistry)
	assert.Len(t, mockRegistry.invariants, 1, "Expected 1 invariant to be registered")
}

func TestBeginBlock(t *testing.T) {
	appModule := tokenfactory.AppModule{
		AppModuleBasic: tokenfactory.AppModuleBasic{},
	}
	ctx := sdktypes.NewContext(nil, tmproto.Header{}, false, log.NewNopLogger())
	appModule.BeginBlock(ctx, abci.RequestFinalizeBlock{})

}
