package simulation

import (
	"math/rand"

	"github.com/cosmos/cosmos-sdk/baseapp"
	sdk "github.com/cosmos/cosmos-sdk/types"
	simtypes "github.com/cosmos/cosmos-sdk/types/simulation"
	banktypes "github.com/cosmos/cosmos-sdk/x/bank/types"
	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/keeper"
	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"
)

func SimulateMsgSetDenomMetadata(
	ak types.AccountKeeper,
	bk types.BankKeeper,
	k *keeper.Keeper,
) simtypes.Operation {
	return func(r *rand.Rand, app *baseapp.BaseApp, ctx sdk.Context, accs []simtypes.Account, chainID string,
	) (simtypes.OperationMsg, []simtypes.FutureOperation, error) {
		simAccount, _ := simtypes.RandomAcc(r, accs)
		denomUnits := []*banktypes.DenomUnit{
			{
				Denom:    "new_denom",
				Exponent: 0,
				Aliases:  []string{"new_denom"},
			},
		}
		metadata := banktypes.Metadata{
			Description: "new denom",
			DenomUnits:  denomUnits,
			Base:        "new_denom",
			Display:     "new_denom",
			Name:        "new_denom",
			Symbol:      "new_denom",
			URI:         "",
			URIHash:     "",
		}

		msg := &types.MsgSetDenomMetadata{
			From:     simAccount.Address.String(),
			Metadata: metadata,
		}

		// TODO: Handling the ConfigureMinterController simulation

		return simtypes.NoOpMsg(types.ModuleName, msg.Type(), "ConfigureMinterController simulation not implemented"), nil, nil
	}
}
