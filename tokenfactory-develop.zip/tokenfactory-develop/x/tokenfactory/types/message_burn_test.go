package types_test

import (
	"testing"

	"cosmossdk.io/math"
	sdk "github.com/cosmos/cosmos-sdk/types"
	sdkerrors "github.com/cosmos/cosmos-sdk/types/errors"
	"github.com/stretchr/testify/require"
	"github.com/wfblockchain/coreblockchain/v2/testutil/sample"
	tokenfactorytypes "github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"
)

func TestMsgBurn_ValidateBasic(t *testing.T) {
	tests := []struct {
		name string
		msg  tokenfactorytypes.MsgBurn
		err  error
	}{
		{
			name: "invalid address",
			msg: tokenfactorytypes.MsgBurn{
				From: "invalid_address",
			},
			err: sdkerrors.ErrInvalidAddress,
		}, {
			name: "valid address",
			msg: tokenfactorytypes.MsgBurn{
				From:   sample.AccAddress(),
				Amount: sdk.NewCoin("test", math.NewInt(1)),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			err := tt.msg.ValidateBasic()
			if tt.err != nil {
				require.ErrorIs(t, err, tt.err)
				return
			}
			require.NoError(t, err)
		})
	}
}

func TestMsgBurn(t *testing.T) {
	validAddress := sample.AccAddress()
	amount := sdk.NewCoin("atom", math.NewInt(1000))
	msg := &tokenfactorytypes.MsgBurn{
		From:   validAddress,
		Amount: amount,
	}
	t.Run("Route", func(t *testing.T) {
		require.Equal(t, tokenfactorytypes.RouterKey, msg.Route())
	})

	t.Run("Type", func(t *testing.T) {
		require.Equal(t, tokenfactorytypes.TypeMsgBurn, msg.Type())
	})

	t.Run("GetSigners", func(t *testing.T) {
		signers := msg.GetSigners()
		expectedSigner, err := sdk.AccAddressFromBech32(validAddress)
		require.NoError(t, err)
		require.Len(t, signers, 1)
		require.Equal(t, expectedSigner, signers[0])
	})

	t.Run("GetSignBytes", func(t *testing.T) {
		signBytes := msg.GetSignBytes()
		expectedBytes := sdk.MustSortJSON(ModuleCdc.MustMarshalJSON(msg))
		require.Equal(t, expectedBytes, signBytes)
	})

	t.Run("ValidateBasic", func(t *testing.T) {
		// Test with valid address
		err := msg.ValidateBasic()
		require.NoError(t, err)

		invalidMsg := &tokenfactorytypes.MsgBurn{
			From:   "invalidAddress",
			Amount: amount,
		}
		err = invalidMsg.ValidateBasic()
		require.Error(t, err)
		require.Contains(t, err.Error(), "invalid from address")
	})
}

func TestNewMsgBurn(t *testing.T) {
	validAddress := sample.AccAddress()
	from := validAddress
	amount := sdk.NewCoin("atom", math.NewInt(1000))
	msg := tokenfactorytypes.NewMsgBurn(from, amount)
	require.NotNil(t, msg, "NewMsgBurn should not return nil")
	require.Equal(t, from, msg.From, "From address should match the input")
	require.Equal(t, amount, msg.Amount, "Amount should match the input")
}
