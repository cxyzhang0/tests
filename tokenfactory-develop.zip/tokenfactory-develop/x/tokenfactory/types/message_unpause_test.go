package types_test

import (
	"testing"

	sdk "github.com/cosmos/cosmos-sdk/types"
	sdkerrors "github.com/cosmos/cosmos-sdk/types/errors"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"github.com/wfblockchain/coreblockchain/v2/testutil/sample"
	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"
)

func TestMsgUnpause_ValidateBasic(t *testing.T) {
	tests := []struct {
		name string
		msg  types.MsgUnpause
		err  error
	}{
		{
			name: "invalid address",
			msg: types.MsgUnpause{
				From: "invalid_address",
			},
			err: sdkerrors.ErrInvalidAddress,
		}, {
			name: "valid address",
			msg: types.MsgUnpause{
				From: sample.AccAddress(),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			err := tt.msg.ValidateBasic()
			if tt.err != nil {
				require.ErrorIs(t, err, tt.err)
				return
			}
			require.NoError(t, err)
		})
	}
}

func TestNewMsgUnpause(t *testing.T) {
	from := "cosmos1xyz..."
	msg := types.NewMsgUnpause(from)
	assert.NotNil(t, msg)
	assert.Equal(t, from, msg.From)
}

func TestMsgUnpauseRoute(t *testing.T) {
	from := "cosmos1xyz..."
	msg := types.NewMsgUnpause(from)
	assert.Equal(t, types.RouterKey, msg.Route())
}

func TestMsgUnpauseType(t *testing.T) {
	from := "cosmos1xyz..."
	msg := types.NewMsgUnpause(from)
	assert.Equal(t, types.TypeMsgUnpause, msg.Type())
}

func TestMsgUnpauseGetSigners(t *testing.T) {
	from := sample.AccAddress()
	msg := types.NewMsgUnpause(from)
	signers := msg.GetSigners()
	assert.Len(t, signers, 1)
	assert.Equal(t, from, signers[0].String())
}

func TestMsgUnpauseGetSignBytes(t *testing.T) {
	from := "cosmos1xyz..."
	msg := types.NewMsgUnpause(from)
	signBytes := msg.GetSignBytes()
	assert.NotNil(t, signBytes)
	expectedBytes := types.ModuleCdc.MustMarshalJSON(msg)
	assert.Equal(t, sdk.MustSortJSON(expectedBytes), signBytes)
}
