package types_test

import (
	"testing"

	sdk "github.com/cosmos/cosmos-sdk/types"
	sdkerrors "github.com/cosmos/cosmos-sdk/types/errors"
	"github.com/stretchr/testify/require"
	"github.com/wfblockchain/coreblockchain/v2/testutil/sample"
	tokenfactorytypes "github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"
)

func TestMsgRemoveMinter_ValidateBasic(t *testing.T) {
	tests := []struct {
		name string
		msg  tokenfactorytypes.MsgRemoveMinter
		err  error
	}{
		{
			name: "invalid from",
			msg: tokenfactorytypes.MsgRemoveMinter{
				From:    "invalid_address",
				Address: sample.AccAddress(),
			},
			err: sdkerrors.ErrInvalidAddress,
		},
		{
			name: "invalid address",
			msg: tokenfactorytypes.MsgRemoveMinter{
				From:    sample.AccAddress(),
				Address: "invalid_address",
			},
			err: sdkerrors.ErrInvalidAddress,
		},
		{
			name: "valid address and from",
			msg: tokenfactorytypes.MsgRemoveMinter{
				From:    sample.AccAddress(),
				Address: sample.AccAddress(),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			err := tt.msg.ValidateBasic()
			if tt.err != nil {
				require.ErrorIs(t, err, tt.err)
				return
			}
			require.NoError(t, err)
		})
	}
}

func TestMsgRemoveMinter(t *testing.T) {
	validFrom := sample.AccAddress()
	validAddress := sample.AccAddress()
	validDenom := "uwfusd"
	t.Run("NewMsgRemoveMinter", func(t *testing.T) {
		msg := tokenfactorytypes.NewMsgRemoveMinter(validFrom, validAddress, validDenom)
		require.NotNil(t, msg, "NewMsgRemoveMinter should not return nil")
		require.Equal(t, validFrom, msg.From, "From should match the input")
		require.Equal(t, validAddress, msg.Address, "Address should match the input")
	})

	t.Run("Route", func(t *testing.T) {
		msg := tokenfactorytypes.NewMsgRemoveMinter(validFrom, validAddress, validDenom)
		require.Equal(t, tokenfactorytypes.RouterKey, msg.Route(), "Route should return the correct RouterKey")
	})

	t.Run("Type", func(t *testing.T) {
		msg := tokenfactorytypes.NewMsgRemoveMinter(validFrom, validAddress, validDenom)
		require.Equal(t, tokenfactorytypes.TypeMsgRemoveMinter, msg.Type(), "Type should return the correct message type")
	})

	t.Run("GetSigners", func(t *testing.T) {
		msg := tokenfactorytypes.NewMsgRemoveMinter(validFrom, validAddress, validDenom)
		signers := msg.GetSigners()
		require.Len(t, signers, 1, "GetSigners should return exactly one signer")

		expectedSigner, err := sdk.AccAddressFromBech32(validFrom)
		require.NoError(t, err, "Valid From address should not return an error")
		require.Equal(t, expectedSigner, signers[0], "Signer should match the 'From' field")
	})

	t.Run("GetSignBytes", func(t *testing.T) {
		msg := tokenfactorytypes.NewMsgRemoveMinter(validFrom, validAddress, validDenom)
		signBytes := msg.GetSignBytes()

		expectedBytes, err := tokenfactorytypes.ModuleCdc.MarshalJSON(msg)
		require.NoError(t, err, "ModuleCdc.MarshalJSON should not return an error")
		expectedSignBytes := sdk.MustSortJSON(expectedBytes)

		require.Equal(t, expectedSignBytes, signBytes, "GetSignBytes should return sorted JSON bytes")
	})
}
