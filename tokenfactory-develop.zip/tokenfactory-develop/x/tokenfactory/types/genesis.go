package types

import (
	"fmt"

	errors "cosmossdk.io/errors"
	sdk "github.com/cosmos/cosmos-sdk/types"
	sdkerrors "github.com/cosmos/cosmos-sdk/types/errors"
)

// DefaultGenesis returns the default genesis state
func DefaultGenesis() *GenesisState {
	return &GenesisState{
		BlacklistedList:      []Blacklisted{},
		Paused:               nil,
		MasterMinter:         nil,
		MintersList:          []Minters{},
		Pauser:               nil,
		Blacklister:          nil,
		Owner:                nil,
		MinterControllerList: []MinterController{},
		MintingDenomList:     []MintingDenom{},
		// this line is used by starport scaffolding # genesis/types/default
		Params: DefaultParams(),
	}
}

// Validate performs basic genesis state validation returning an error upon any
// failure.
func (gs GenesisState) Validate() error {
	// Check for duplicated index in blacklisted
	blacklistedIndexMap := make(map[string]struct{})
	for _, elem := range gs.BlacklistedList {
		index := string(BlacklistedKey(elem.AddressBz))
		if _, ok := blacklistedIndexMap[index]; ok {
			return fmt.Errorf("duplicated index for blacklisted")
		}
		blacklistedIndexMap[index] = struct{}{}
	}

	// Check for duplicated index in minters and validate minter addr and allowance
	mintersIndexMap := make(map[string]struct{})
	for _, elem := range gs.MintersList {
		index := string(MintersKey(elem.Address, elem.Allowance.Denom))
		if _, ok := mintersIndexMap[index]; ok {
			return fmt.Errorf("duplicated index for minters")
		}
		mintersIndexMap[index] = struct{}{}

		if _, err := sdk.AccAddressFromBech32(elem.Address); err != nil {
			return errors.Wrapf(sdkerrors.ErrInvalidAddress, "invalid minter address (%s)", err)
		}
	}

	// Check for duplicated index in minterController and validate both controller and minter addresses
	minterControllerIndexMap := make(map[string]struct{})
	for _, elem := range gs.MinterControllerList {
		index := string(MinterControllerKey(elem.Controller, elem.Minter))
		if _, ok := minterControllerIndexMap[index]; ok {
			return fmt.Errorf("duplicated index for minterController")
		}
		minterControllerIndexMap[index] = struct{}{}

		if _, err := sdk.AccAddressFromBech32(elem.Minter); err != nil {
			return errors.Wrapf(sdkerrors.ErrInvalidAddress, "minter controller has invalid minter address (%s)", err)
		}
	}

	var addresses []sdk.AccAddress

	if gs.Owner != nil {
		owner, _ := sdk.AccAddressFromBech32(gs.Owner.Address)
		addresses = append(addresses, owner)
	}

	if gs.MasterMinter != nil {
		masterMinter, _ := sdk.AccAddressFromBech32(gs.MasterMinter.Address)
		addresses = append(addresses, masterMinter)
	}

	if gs.Pauser != nil {
		pauser, _ := sdk.AccAddressFromBech32(gs.Pauser.Address)
		addresses = append(addresses, pauser)
	}

	if gs.Blacklister != nil {
		blacklister, _ := sdk.AccAddressFromBech32(gs.Blacklister.Address)
		addresses = append(addresses, blacklister)
	}

	if err := validatePrivileges(addresses); err != nil {
		return err
	}

	//if gs.MintingDenom != nil && gs.MintingDenom.Denom == "" {
	//	return fmt.Errorf("minting denom cannot be an empty string")
	//}
	// Check for duplicated index in minting denoms
	mintingDenomsIndexMap := make(map[string]struct{})
	for _, elem := range gs.MintingDenomList {
		index := string(MintingDenomKey(elem.Denom))
		if _, ok := mintingDenomsIndexMap[index]; ok {
			return fmt.Errorf("duplicated index for minting denoms")
		}
		mintingDenomsIndexMap[index] = struct{}{}
	}

	// this line is used by starport scaffolding # genesis/types/validate

	return gs.Params.Validate()
}

// validatePrivileges ensures that the same address is not being assigned to more than one privileged role.
func validatePrivileges(addresses []sdk.AccAddress) error {
	for i, current := range addresses {
		for j, target := range addresses {
			if i == j {
				continue
			}

			if current.String() == target.String() {
				return errors.Wrapf(ErrAlreadyPrivileged, "%s", current)
			}
		}
	}

	return nil
}

// DefaultGenesisState - Return a default genesis state
func DefaultGenesisState() *GenesisState {
	return NewGenesisState(DefaultParams())
}

func NewGenesisState(params Params) *GenesisState {
	return &GenesisState{
		Params: params,
	}
}
