package types_test

import (
	"testing"

	sdk "github.com/cosmos/cosmos-sdk/types"
	sdkerrors "github.com/cosmos/cosmos-sdk/types/errors"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"github.com/wfblockchain/coreblockchain/v2/testutil/sample"
	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"
	tokenfactorytypes "github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"
)

func TestMsgUpdatePauser_ValidateBasic(t *testing.T) {
	tests := []struct {
		name string
		msg  tokenfactorytypes.MsgUpdatePauser
		err  error
	}{
		{
			name: "invalid from",
			msg: tokenfactorytypes.MsgUpdatePauser{
				From:    "invalid_address",
				Address: sample.AccAddress(),
			},
			err: sdkerrors.ErrInvalidAddress,
		},
		{
			name: "invalid address",
			msg: tokenfactorytypes.MsgUpdatePauser{
				From:    sample.AccAddress(),
				Address: "invalid_address",
			},
			err: sdkerrors.ErrInvalidAddress,
		},
		{
			name: "valid address and from",
			msg: tokenfactorytypes.MsgUpdatePauser{
				From:    sample.AccAddress(),
				Address: sample.AccAddress(),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			err := tt.msg.ValidateBasic()
			if tt.err != nil {
				require.ErrorIs(t, err, tt.err)
				return
			}
			require.NoError(t, err)
		})
	}
}

func TestNewMsgUpdatePauser(t *testing.T) {
	from := sample.AccAddress()
	address := sample.AccAddress()
	msg := tokenfactorytypes.NewMsgUpdatePauser(from, address)
	assert.NotNil(t, msg)
	assert.Equal(t, from, msg.From)
	assert.Equal(t, address, msg.Address)
}

func TestMsgUpdatePauserRoute(t *testing.T) {
	from := "cosmos1xyz..."
	address := "cosmos1abc..."
	msg := tokenfactorytypes.NewMsgUpdatePauser(from, address)
	assert.Equal(t, tokenfactorytypes.RouterKey, msg.Route())
}

func TestMsgUpdatePauserType(t *testing.T) {
	from := "cosmos1xyz..."
	address := "cosmos1abc..."
	msg := tokenfactorytypes.NewMsgUpdatePauser(from, address)
	assert.Equal(t, tokenfactorytypes.TypeMsgUpdatePauser, msg.Type())
}

func TestMsgUpdatePauserGetSigners(t *testing.T) {
	from := sample.AccAddress()
	address := sample.AccAddress()
	msg := tokenfactorytypes.NewMsgUpdatePauser(from, address)
	signers := msg.GetSigners()
	assert.Len(t, signers, 1)
	assert.Equal(t, from, signers[0].String())
}

func TestMsgUpdatePauserGetSignBytes(t *testing.T) {
	from := "cosmos1xyz..."
	address := "cosmos1abc..."
	msg := tokenfactorytypes.NewMsgUpdatePauser(from, address)
	signBytes := msg.GetSignBytes()
	assert.NotNil(t, signBytes)
	expectedBytes := types.ModuleCdc.MustMarshalJSON(msg)
	assert.Equal(t, sdk.MustSortJSON(expectedBytes), signBytes)
}
