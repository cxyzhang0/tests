package types

import (
	"cosmossdk.io/errors"
	sdk "github.com/cosmos/cosmos-sdk/types"
	sdkerrors "github.com/cosmos/cosmos-sdk/types/errors"
	banktypes "github.com/cosmos/cosmos-sdk/x/bank/types"
)

const TypeMsgSetDenomMetadata = "set_denom_metadata"

var _ sdk.Msg = &MsgSetDenomMetadata{}

func NewMsgSetDenomMedata(from string, metadata banktypes.Metadata) *MsgSetDenomMetadata {
	return &MsgSetDenomMetadata{
		From:     from,
		Metadata: metadata,
	}
}

func (msg *MsgSetDenomMetadata) Route() string {
	return RouterKey
}

func (msg *MsgSetDenomMetadata) Type() string {
	return TypeMsgSetDenomMetadata
}

func (msg *MsgSetDenomMetadata) GetSigners() []sdk.AccAddress {
	from, err := sdk.AccAddressFromBech32(msg.From)
	if err != nil {
		panic(err)
	}
	return []sdk.AccAddress{from}
}

func (msg *MsgSetDenomMetadata) GetSignBytes() []byte {
	bz := ModuleCdc.MustMarshalJSON(msg)
	return sdk.MustSortJSON(bz)
}

func (msg *MsgSetDenomMetadata) ValidateBasic() error {
	_, err := sdk.AccAddressFromBech32(msg.From)
	if err != nil {
		return errors.Wrapf(sdkerrors.ErrInvalidAddress, "invalid from address (%s)", err)
	}

	err = msg.Metadata.Validate()
	if err != nil {
		return err
	}

	return nil
}
