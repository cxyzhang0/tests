package types

import (
	errors "cosmossdk.io/errors"
	sdk "github.com/cosmos/cosmos-sdk/types"
	sdkerrors "github.com/cosmos/cosmos-sdk/types/errors"
)

const TypeMsgBlacklist = "blacklist"

var _ sdk.Msg = &MsgBlacklist{}

func NewMsgBlacklist(from, address string) *MsgBlacklist {
	return &MsgBlacklist{
		From:    from,
		Address: address,
	}
}

func (msg *MsgBlacklist) Route() string {
	return RouterKey
}

func (msg *MsgBlacklist) Type() string {
	return TypeMsgBlacklist
}

func (msg *MsgBlacklist) GetSigners() []sdk.AccAddress {
	from, _ := sdk.AccAddressFromBech32(msg.From)
	return []sdk.AccAddress{from}
}

func (msg *MsgBlacklist) GetSignBytes() []byte {
	bz := ModuleCdc.MustMarshalJSON(msg)
	return sdk.MustSortJSON(bz)
}

func (msg *MsgBlacklist) ValidateBasic() error {
	_, err := sdk.AccAddressFromBech32(msg.From)
	if err != nil {
		return errors.Wrapf(sdkerrors.ErrInvalidAddress, "invalid from address (%s)", err)
	}
	return nil
}
