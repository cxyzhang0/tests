package types_test

import (
	"testing"

	"github.com/stretchr/testify/require"
	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"
)

func TestMsgUpdateMasterMinter(t *testing.T) {
	msg := types.MsgUpdateMasterMinter{
		From:    "cosmos1address",
		Address: "cosmos1newminter",
	}
	require.Equal(t, "cosmos1address", msg.From)
	require.Equal(t, "cosmos1newminter", msg.Address)
}
