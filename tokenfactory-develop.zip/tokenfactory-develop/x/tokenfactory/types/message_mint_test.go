package types_test

import (
	"testing"

	"cosmossdk.io/math"
	sdk "github.com/cosmos/cosmos-sdk/types"
	sdkerrors "github.com/cosmos/cosmos-sdk/types/errors"
	"github.com/stretchr/testify/require"
	"github.com/wfblockchain/coreblockchain/v2/testutil/sample"
	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"
	tokenfactorytypes "github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"
)

func TestMsgMint_ValidateBasic(t *testing.T) {
	tests := []struct {
		name string
		msg  tokenfactorytypes.MsgMint
		err  error
	}{
		{
			name: "invalid from",
			msg: tokenfactorytypes.MsgMint{
				From:    "invalid_address",
				Address: sample.AccAddress(),
			},
			err: sdkerrors.ErrInvalidAddress,
		},
		{
			name: "invalid address",
			msg: tokenfactorytypes.MsgMint{
				From:    sample.AccAddress(),
				Address: "invalid_address",
			},
			err: sdkerrors.ErrInvalidAddress,
		},
		{
			name: "valid address and from",
			msg: tokenfactorytypes.MsgMint{
				From:    sample.AccAddress(),
				Address: sample.AccAddress(),
				Amount:  sdk.NewCoin("test", math.NewInt(1)),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			err := tt.msg.ValidateBasic()
			if tt.err != nil {
				require.ErrorIs(t, err, tt.err)
				return
			}
			require.NoError(t, err)
		})
	}
}

func TestMsgMint(t *testing.T) {
	validFrom := sample.AccAddress()
	validAddress := sample.AccAddress()
	validAmount := sdk.NewCoin("atom", math.NewInt(100))

	t.Run("NewMsgMint", func(t *testing.T) {
		msg := types.NewMsgMint(validFrom, validAddress, validAmount)
		require.NotNil(t, msg, "NewMsgMint should not return nil")
		require.Equal(t, validFrom, msg.From, "From should match the input")
		require.Equal(t, validAddress, msg.Address, "Address should match the input")
		require.Equal(t, validAmount, msg.Amount, "Amount should match the input")
	})

	t.Run("Route", func(t *testing.T) {
		msg := types.NewMsgMint(validFrom, validAddress, validAmount)
		require.Equal(t, types.RouterKey, msg.Route(), "Route should return the correct RouterKey")
	})

	t.Run("Type", func(t *testing.T) {
		msg := types.NewMsgMint(validFrom, validAddress, validAmount)
		require.Equal(t, types.TypeMsgMint, msg.Type(), "Type should return the correct message type")
	})

	t.Run("GetSigners", func(t *testing.T) {
		msg := types.NewMsgMint(validFrom, validAddress, validAmount)
		signers := msg.GetSigners()
		require.Len(t, signers, 1, "GetSigners should return exactly one signer")

		expectedSigner, err := sdk.AccAddressFromBech32(validFrom)
		require.NoError(t, err, "Valid From address should not return an error")
		require.Equal(t, expectedSigner, signers[0], "Signer should match the 'From' field")
	})

	t.Run("GetSignBytes", func(t *testing.T) {
		msg := types.NewMsgMint(validFrom, validAddress, validAmount)
		signBytes := msg.GetSignBytes()
		expectedBytes, err := types.ModuleCdc.MarshalJSON(msg)
		require.NoError(t, err, "ModuleCdc.MarshalJSON should not return an error")
		expectedSignBytes := sdk.MustSortJSON(expectedBytes)

		require.Equal(t, expectedSignBytes, signBytes, "GetSignBytes should return sorted JSON bytes")
	})
}
