package types

// DONTCOVER

import (
	sdkerrors "cosmossdk.io/errors"
)

// x/tokenfactory module sentinel errors
var (
	ErrUnauthorized        = sdkerrors.Register(ModuleName, 2, "unauthorized")
	ErrUserNotFound        = sdkerrors.Register(ModuleName, 3, "user not found")
	ErrMint                = sdkerrors.Register(ModuleName, 4, "tokens can not be minted")
	ErrSendCoinsToAccount  = sdkerrors.Register(ModuleName, 5, "can't send tokens to account")
	ErrBurn                = sdkerrors.Register(ModuleName, 6, "tokens can not be burned")
	ErrPaused              = sdkerrors.Register(ModuleName, 7, "the chain is paused")
	ErrMintingDenomSet     = sdkerrors.Register(ModuleName, 9, "the minting denom has already been set")
	ErrUserBlacklisted     = sdkerrors.Register(ModuleName, 10, "user is already blacklisted")
	ErrAlreadyPrivileged   = sdkerrors.Register(ModuleName, 11, "address is already assigned to privileged role")
	ErrDenomNotRegistered  = sdkerrors.Register(ModuleName, 12, "denom not registered in bank module")
	ErrConfigureController = sdkerrors.Register(ModuleName, 13, "controller can not be configured")
	ErrRemoveController    = sdkerrors.Register(ModuleName, 14, "controller can not be removed")
	ErrInvalidAddr         = sdkerrors.Register(ModuleName, 15, "invalid bech32")
)
