package v1

const (
	MintingDenomKey           = "MintingDenom"
	MintersKeyPrefix          = "Minters/value/"
	MinterControllerKeyPrefix = "MinterController"
)
