package v2

import (
	"cosmossdk.io/core/store"
	"cosmossdk.io/store/prefix"
	storetypes "cosmossdk.io/store/types"
	"github.com/cosmos/cosmos-sdk/codec"
	"github.com/cosmos/cosmos-sdk/runtime"
	sdk "github.com/cosmos/cosmos-sdk/types"
	v1 "github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/migrations/v1"
	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"
)

// old and new have different key prefixes
func migrateMintingDenom(store storetypes.KVStore, cdc codec.BinaryCodec) {
	oldStore := prefix.NewStore(store, types.KeyPrefix(v1.MintingDenomKey))

	newStore := prefix.NewStore(store, types.KeyPrefix(types.MintingDenomKeyPrefix))

	// even if oldStore is singleton, we treat it as a list
	iterator := storetypes.KVStorePrefixIterator(oldStore, []byte{})

	defer iterator.Close()

	for ; iterator.Valid(); iterator.Next() {
		var mintingDenom types.MintingDenom
		v := iterator.Value()
		cdc.MustUnmarshal(v, &mintingDenom)

		b := cdc.MustMarshal(&mintingDenom) // this should be the same as v
		newStore.Set(types.MintingDenomKey(mintingDenom.Denom), b)
		oldStore.Delete(iterator.Key())
	}
}

// old and new have different key prefixes
func migrateMinterControllers(store storetypes.KVStore, cdc codec.BinaryCodec) {
	oldStore := prefix.NewStore(store, types.KeyPrefix(v1.MinterControllerKeyPrefix))

	newStore := prefix.NewStore(store, types.KeyPrefix(types.MinterControllerKeyPrefix))

	iterator := storetypes.KVStorePrefixIterator(oldStore, []byte{})

	defer iterator.Close()

	for ; iterator.Valid(); iterator.Next() {
		var minterController types.MinterController
		v := iterator.Value()
		cdc.MustUnmarshal(v, &minterController)

		b := cdc.MustMarshal(&minterController) // this should be the same as v
		newStore.Set(types.MinterControllerKey(minterController.Controller, minterController.Minter), b)
		oldStore.Delete(iterator.Key())
	}
}

// old and new have same key prefixes
func migrateMinters(store storetypes.KVStore, cdc codec.BinaryCodec) {
	oldStore := prefix.NewStore(store, types.KeyPrefix(v1.MintersKeyPrefix))

	newStore := prefix.NewStore(store, types.KeyPrefix(types.MintersKeyPrefix))

	iterator := storetypes.KVStorePrefixIterator(oldStore, []byte{})

	defer iterator.Close()

	for ; iterator.Valid(); iterator.Next() {
		var minter types.Minters
		v := iterator.Value()
		cdc.MustUnmarshal(v, &minter)

		b := cdc.MustMarshal(&minter) // this should be the same as v
		newStore.Set(types.MintersKey(minter.Address, minter.Allowance.Denom), b)
		oldStore.Delete(iterator.Key())
	}

}

func MigrateStore(ctx sdk.Context, storeService store.KVStoreService, cdc codec.BinaryCodec) error {
	store := runtime.KVStoreAdapter(storeService.OpenKVStore(ctx))
	//store := ctx.KVStore(storetypes.NewKVStoreKey(types.StoreKey)) // kv store with key KVStoreKey{0x1400121f6a0, tokenfactory} has not been registered in stores

	ctx.Logger().Info("***** migrateMintingDenom")
	migrateMintingDenom(store, cdc)

	ctx.Logger().Info("***** migrateMinterControllers")
	migrateMinterControllers(store, cdc)

	ctx.Logger().Info("***** migrateMinters")
	migrateMinters(store, cdc)

	return nil
}
