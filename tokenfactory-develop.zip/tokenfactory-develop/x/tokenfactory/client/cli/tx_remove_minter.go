package cli

import (
	"strconv"

	"github.com/cosmos/cosmos-sdk/client"
	"github.com/cosmos/cosmos-sdk/client/flags"
	"github.com/cosmos/cosmos-sdk/client/tx"
	"github.com/spf13/cobra"
	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"
)

var _ = strconv.Itoa(0)

func CmdRemoveMinter() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "remove-minter [address]",
		Short: "Broadcast message remove-minter",
		Args:  cobra.ExactArgs(2),
		RunE: func(cmd *cobra.Command, args []string) (err error) {
			argAddress := args[0]
			argDenom := args[1]

			clientCtx, _ := client.GetClientTxContext(cmd)

			msg := types.NewMsgRemoveMinter(
				clientCtx.GetFromAddress().String(),
				argAddress,
				argDenom,
			)

			return tx.GenerateOrBroadcastTxCLI(clientCtx, cmd.Flags(), msg)
		},
	}

	flags.AddTxFlagsToCmd(cmd)

	return cmd
}
