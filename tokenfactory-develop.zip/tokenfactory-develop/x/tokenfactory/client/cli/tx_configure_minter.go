package cli

import (
	"strconv"

	"github.com/cosmos/cosmos-sdk/client"
	"github.com/cosmos/cosmos-sdk/client/flags"
	"github.com/cosmos/cosmos-sdk/client/tx"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/spf13/cobra"
	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"
)

var _ = strconv.Itoa(0)

func CmdConfigureMinter() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "configure-minter [address] [allowance]",
		Short: "Broadcast message configure-minter",
		Args:  cobra.ExactArgs(2),
		RunE: func(cmd *cobra.Command, args []string) (err error) {
			argAddress := args[0]
			argAllowance, _ := sdk.ParseCoinNormalized(args[1])

			clientCtx, _ := client.GetClientTxContext(cmd)
			msg := types.NewMsgConfigureMinter(
				clientCtx.GetFromAddress().String(),
				argAddress,
				argAllowance,
			)

			return tx.GenerateOrBroadcastTxCLI(clientCtx, cmd.Flags(), msg)
		},
	}

	flags.AddTxFlagsToCmd(cmd)

	return cmd
}
