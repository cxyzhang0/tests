package cli

import (
	"strconv"

	"github.com/cosmos/cosmos-sdk/client"
	"github.com/cosmos/cosmos-sdk/client/flags"
	"github.com/cosmos/cosmos-sdk/client/tx"
	"github.com/spf13/cobra"
	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"
)

var _ = strconv.Itoa(0)

func CmdUpdateMasterMinter() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "update-master-minter [address]",
		Short: "Broadcast message update-master-minter",
		Args:  cobra.ExactArgs(1),
		RunE: func(cmd *cobra.Command, args []string) (err error) {
			argAddress := args[0]

			clientCtx, _ := client.GetClientTxContext(cmd)
			msg := types.NewMsgUpdateMasterMinter(
				clientCtx.GetFromAddress().String(),
				argAddress,
			)

			return tx.GenerateOrBroadcastTxCLI(clientCtx, cmd.Flags(), msg)
		},
	}

	flags.AddTxFlagsToCmd(cmd)

	return cmd
}
