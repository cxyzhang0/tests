package cli

import (
	"context"

	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"

	"github.com/cosmos/cosmos-sdk/client"
	"github.com/cosmos/cosmos-sdk/client/flags"
	"github.com/spf13/cobra"
)

func CmdListMinterController() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "list-minter-controller",
		Short: "list all minter-controller",
		RunE: func(cmd *cobra.Command, args []string) error {
			clientCtx := client.GetClientContextFromCmd(cmd)

			pageReq, err := client.ReadPageRequest(cmd.Flags())
			if err != nil {
				return err
			}

			queryClient := types.NewQueryClient(clientCtx)

			params := &types.QueryAllMinterControllerRequest{
				Pagination: pageReq,
			}

			res, err := queryClient.MinterControllerAll(context.Background(), params)
			if err != nil {
				return err
			}

			return clientCtx.PrintProto(res)
		},
	}

	flags.AddPaginationFlagsToCmd(cmd, cmd.Use)
	flags.AddQueryFlagsToCmd(cmd)

	return cmd
}

func CmdShowMinterController() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "show-minter-controller [controller-address] [minter-address]",
		Short: "shows a minter-controller",
		Args:  cobra.ExactArgs(2),
		RunE: func(cmd *cobra.Command, args []string) (err error) {
			clientCtx := client.GetClientContextFromCmd(cmd)

			queryClient := types.NewQueryClient(clientCtx)

			argControllerAddress := args[0]
			argMinterAddress := args[1]

			params := &types.QueryGetMinterControllerRequest{
				ControllerAddress: argControllerAddress,
				MinterAddress:     argMinterAddress,
			}

			res, err := queryClient.MinterController(context.Background(), params)
			if err != nil {
				return err
			}

			return clientCtx.PrintProto(res)
		},
	}

	flags.AddQueryFlagsToCmd(cmd)

	return cmd
}
