package cli_test

// import (
// 	"fmt"
// 	"testing"

// 	tmcli "github.com/cometbft/cometbft/libs/cli"
// 	clitestutil "github.com/cosmos/cosmos-sdk/testutil/cli"
// 	"github.com/stretchr/testify/require"
// 	"google.golang.org/grpc/status"

// 	"github.com/wfblockchain/coreblockchain/v1/testutil/network"
// 	"github.com/wfblockchain/coreblockchain/v1/testutil/nullify"
// 	"github.com/wfblockchain/coreblockchain/v1/x/tokenfactory/client/cli"
// 	"github.com/wfblockchain/coreblockchain/v1/x/tokenfactory/types"
// )

// func networkWithOwnerObjects(t *testing.T) (*network.Network, types.Owner) {
// 	t.Helper()
// 	cfg := network.DefaultConfig(nil)
// 	state := types.GenesisState{}
// 	require.NoError(t, cfg.Codec.UnmarshalJSON(cfg.GenesisState[types.ModuleName], &state))

// 	owner := &types.Owner{}
// 	nullify.Fill(&owner)
// 	state.Owner = owner
// 	buf, err := cfg.Codec.MarshalJSON(&state)
// 	require.NoError(t, err)
// 	cfg.GenesisState[types.ModuleName] = buf
// 	baseDir := t.TempDir()

// 	network, err := network.New(nil, baseDir, cfg)
// 	if err != nil {
// 		return nil, *state.Owner
// 	}
// 	return network, *state.Owner
// }

// func TestShowOwner(t *testing.T) {
// 	net, obj := networkWithOwnerObjects(t)

// 	ctx := net.Validators[0].ClientCtx
// 	common := []string{
// 		fmt.Sprintf("--%s=json", tmcli.OutputFlag),
// 	}
// 	for _, tc := range []struct {
// 		desc string
// 		args []string
// 		err  error
// 		obj  types.Owner
// 	}{
// 		{
// 			desc: "get",
// 			args: common,
// 			obj:  obj,
// 		},
// 	} {
// 		t.Run(tc.desc, func(t *testing.T) {
// 			var args []string
// 			args = append(args, tc.args...)
// 			out, err := clitestutil.ExecTestCLICmd(ctx, cli.CmdShowOwner(), args)
// 			if tc.err != nil {
// 				stat, ok := status.FromError(tc.err)
// 				require.True(t, ok)
// 				require.ErrorIs(t, stat.Err(), tc.err)
// 			} else {
// 				require.NoError(t, err)
// 				var resp types.QueryGetOwnerResponse
// 				require.NoError(t, net.Config.Codec.UnmarshalJSON(out.Bytes(), &resp))
// 				require.NotNil(t, resp.Owner)
// 				require.Equal(t,
// 					nullify.Fill(&tc.obj),
// 					nullify.Fill(&resp.Owner),
// 				)
// 			}
// 		})
// 	}
// }
