package cli_test

import (
	"context"
	"testing"
	"time"

	"github.com/cosmos/cosmos-sdk/client"
	"github.com/cosmos/cosmos-sdk/types"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/spf13/cobra"
	"github.com/spf13/pflag"
	"github.com/stretchr/testify/require"
	"gotest.tools/v3/assert"

	"github.com/wfblockchain/coreblockchain/v2/testutil/sample"
	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/client/cli"
	ttypes "github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"
	"go.uber.org/mock/gomock"
)

type mockTxContext struct {
	clientCtx client.Context
}

func (m *mockTxContext) GetClientTxContext(cmd *cobra.Command) (client.Context, error) {
	return m.clientCtx, nil
}

func (m *MockClientContext) Deadline() (deadline time.Time, ok bool) {
	return time.Time{}, false
}

func (m *MockClientContext) Done() <-chan struct{} {
	ch := make(chan struct{})
	close(ch)
	return ch
}

func (m *MockClientContext) Err() error {
	return nil
}

func (m *MockClientContext) Value(key interface{}) interface{} {
	return nil
}

type MockClientContext struct {
	clientCtx client.Context
}

func (m *MockClientContext) GetFromAddress() types.AccAddress {
	return m.clientCtx.GetFromAddress()
}

type MockTxClient struct{}

func (m *MockTxClient) GenerateOrBroadcastTxCLI(clientCtx client.Context, flags *pflag.FlagSet, msg types.Msg) error {
	return nil
}

func TestCmdUpdatePauser(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()
	clientCtx := client.Context{}
	validAddress := sample.AccAddress()
	clientCtx = clientCtx.WithFromAddress(types.AccAddress(validAddress))

	fromAddr := clientCtx.GetFromAddress().String()
	if fromAddr == "" {
		t.Fatalf("The from address is empty, check if it has been set properly.")
	}
	_, err := sdk.AccAddressFromBech32(fromAddr)
	if err != nil {
		t.Fatalf("Invalid From address in context: %s, error: %v", fromAddr, err)
	}
	cmd := cli.CmdUpdatePauser()
	args := []string{sample.AccAddress()}
	cmd.SetArgs(args)
	mockClient := &MockClientContext{clientCtx: clientCtx}
	cmd.SetContext(mockClient)
	expectedMsg := ttypes.NewMsgUpdatePauser(
		fromAddr,
		args[0],
	)
	cmd.RunE(cmd, args)
	require.Equal(t, expectedMsg.From, clientCtx.GetFromAddress().String())
	require.Equal(t, expectedMsg.Address, args[0])
}

func TestCmdUpdateOwner(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()

	clientCtx := client.Context{}
	validAddress := sample.AccAddress()
	clientCtx = clientCtx.WithFromAddress(types.AccAddress(validAddress))

	fromAddr := clientCtx.GetFromAddress().String()
	if fromAddr == "" {
		t.Fatalf("The from address is empty, check if it has been set properly.")
	}
	_, err := sdk.AccAddressFromBech32(fromAddr)
	if err != nil {
		t.Fatalf("Invalid From address in context: %s, error: %v", fromAddr, err)
	}

	cmd := cli.CmdUpdateOwner()
	args := []string{sample.AccAddress()}
	cmd.SetArgs(args)

	mockClient := &MockClientContext{clientCtx: clientCtx}
	cmd.SetContext(mockClient)
	expectedMsg := ttypes.NewMsgUpdateOwner(
		fromAddr,
		args[0],
	)
	cmd.RunE(cmd, args)
	require.Equal(t, expectedMsg.From, clientCtx.GetFromAddress().String())
	require.Equal(t, expectedMsg.Address, args[0])
}

func TestCmdUpdateMasterMinter(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()

	clientCtx := client.Context{}
	validAddress := sample.AccAddress()
	clientCtx = clientCtx.WithFromAddress(types.AccAddress(validAddress))

	fromAddr := clientCtx.GetFromAddress().String()
	if fromAddr == "" {
		t.Fatalf("The from address is empty, check if it has been set properly.")
	}
	_, err := sdk.AccAddressFromBech32(fromAddr)
	if err != nil {
		t.Fatalf("Invalid From address in context: %s, error: %v", fromAddr, err)
	}

	cmd := cli.CmdUpdateMasterMinter()
	args := []string{sample.AccAddress()}
	cmd.SetArgs(args)
	mockClient := &MockClientContext{clientCtx: clientCtx}
	cmd.SetContext(mockClient)
	expectedMsg := ttypes.NewMsgUpdateMasterMinter(
		fromAddr,
		args[0],
	)
	cmd.RunE(cmd, args)
	require.Equal(t, expectedMsg.From, clientCtx.GetFromAddress().String())
	require.Equal(t, expectedMsg.Address, args[0])
}
func TestCmdUpdateBlacklister(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()

	clientCtx := client.Context{}
	validAddress := sample.AccAddress()
	clientCtx = clientCtx.WithFromAddress(types.AccAddress(validAddress))

	fromAddr := clientCtx.GetFromAddress().String()
	if fromAddr == "" {
		t.Fatalf("The from address is empty, check if it has been set properly.")
	}
	_, err := sdk.AccAddressFromBech32(fromAddr)
	if err != nil {
		t.Fatalf("Invalid From address in context: %s, error: %v", fromAddr, err)
	}
	cmd := cli.CmdUpdateBlacklister()
	args := []string{sample.AccAddress()}
	cmd.SetArgs(args)
	mockClient := &MockClientContext{clientCtx: clientCtx}
	cmd.SetContext(mockClient)
	expectedMsg := ttypes.NewMsgUpdateBlacklister(
		fromAddr,
		args[0],
	)

	cmd.RunE(cmd, args)
	require.Equal(t, expectedMsg.From, clientCtx.GetFromAddress().String())
	require.Equal(t, expectedMsg.Address, args[0])
}
func TestCmdUnpause(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()
	clientCtx := client.Context{}
	validAddress := sample.AccAddress()
	clientCtx = clientCtx.WithFromAddress(types.AccAddress(validAddress))
	fromAddr := clientCtx.GetFromAddress().String()
	if fromAddr == "" {
		t.Fatalf("The from address is empty, check if it has been set properly.")
	}
	_, err := sdk.AccAddressFromBech32(fromAddr)
	if err != nil {
		t.Fatalf("Invalid From address in context: %s, error: %v", fromAddr, err)
	}
	cmd := cli.CmdUnpause()
	cmd.SetArgs([]string{})
	mockClient := &MockClientContext{clientCtx: clientCtx}
	cmd.SetContext(mockClient)
	expectedMsg := ttypes.NewMsgUnpause(
		fromAddr,
	)
	cmd.RunE(cmd, []string{})
	require.Equal(t, expectedMsg.From, clientCtx.GetFromAddress().String())
}

func TestCmdUnblacklist(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()
	clientCtx := client.Context{}
	validAddress := sample.AccAddress()
	clientCtx = clientCtx.WithFromAddress(types.AccAddress(validAddress))
	fromAddr := clientCtx.GetFromAddress().String()
	if fromAddr == "" {
		t.Fatalf("The from address is empty, check if it has been set properly.")
	}
	_, err := sdk.AccAddressFromBech32(fromAddr)
	if err != nil {
		t.Fatalf("Invalid From address in context: %s, error: %v", fromAddr, err)
	}
	cmd := cli.CmdUnblacklist()
	argAddress := sample.AccAddress()
	cmd.SetArgs([]string{argAddress})
	mockClient := &MockClientContext{clientCtx: clientCtx}
	cmd.SetContext(mockClient)
	expectedMsg := ttypes.NewMsgUnblacklist(
		fromAddr,
		argAddress,
	)
	cmd.RunE(cmd, []string{argAddress})
	require.Equal(t, expectedMsg.From, clientCtx.GetFromAddress().String())
	require.Equal(t, expectedMsg.Address, argAddress)
}
func TestCmdRemoveMinterController(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()
	clientCtx := client.Context{}
	validAddress := sample.AccAddress()
	clientCtx = clientCtx.WithFromAddress(types.AccAddress(validAddress))
	fromAddr := clientCtx.GetFromAddress().String()
	if fromAddr == "" {
		t.Fatalf("The from address is empty, check if it has been set properly.")
	}
	_, err := sdk.AccAddressFromBech32(fromAddr)
	if err != nil {
		t.Fatalf("Invalid From address in context: %s, error: %v", fromAddr, err)
	}
	cmd := cli.CmdRemoveMinterController()
	argAddress := sample.AccAddress()
	cmd.SetArgs([]string{argAddress})
	mockClient := &MockClientContext{clientCtx: clientCtx}
	cmd.SetContext(mockClient)

	expectedMsg := ttypes.NewMsgRemoveMinterController(
		fromAddr,
		argAddress,
		"wfusd",
	)
	cmd.RunE(cmd, []string{argAddress, "Mock_Minter"})
	require.Equal(t, expectedMsg.From, clientCtx.GetFromAddress().String())
	require.Equal(t, expectedMsg.Controller, argAddress)
}
func TestCmdRemoveMinter(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()
	clientCtx := client.Context{}
	validAddress := sample.AccAddress()
	clientCtx = clientCtx.WithFromAddress(types.AccAddress(validAddress))
	fromAddr := clientCtx.GetFromAddress().String()
	if fromAddr == "" {
		t.Fatalf("The from address is empty, check if it has been set properly.")
	}
	_, err := sdk.AccAddressFromBech32(fromAddr)
	if err != nil {
		t.Fatalf("Invalid From address in context: %s, error: %v", fromAddr, err)
	}
	cmd := cli.CmdRemoveMinter()
	argAddress := sample.AccAddress()
	cmd.SetArgs([]string{argAddress})
	mockClient := &MockClientContext{clientCtx: clientCtx}
	cmd.SetContext(mockClient)
	expectedMsg := ttypes.NewMsgRemoveMinter(
		fromAddr,
		argAddress,
		"wfusd",
	)
	cmd.RunE(cmd, []string{argAddress, "Mock_Denom"})
	require.Equal(t, expectedMsg.From, clientCtx.GetFromAddress().String())
	require.Equal(t, expectedMsg.Address, argAddress)
}

func TestCmdPause(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()
	clientCtx := client.Context{}
	validAddress := sample.AccAddress()
	clientCtx = clientCtx.WithFromAddress(types.AccAddress(validAddress))
	fromAddr := clientCtx.GetFromAddress().String()
	if fromAddr == "" {
		t.Fatalf("The from address is empty, check if it has been set properly.")
	}
	_, err := sdk.AccAddressFromBech32(fromAddr)
	if err != nil {
		t.Fatalf("Invalid From address in context: %s, error: %v", fromAddr, err)
	}
	cmd := cli.CmdPause()
	mockClient := &MockClientContext{clientCtx: clientCtx}
	cmd.SetContext(mockClient)
	expectedMsg := ttypes.NewMsgPause(fromAddr)
	cmd.RunE(cmd, []string{})
	require.Equal(t, expectedMsg.From, clientCtx.GetFromAddress().String())
}
func TestCmdMint(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()
	clientCtx := client.Context{}
	validFromAddress := sample.AccAddress()
	validToAddress := sample.AccAddress()
	clientCtx = clientCtx.WithFromAddress(types.AccAddress(validFromAddress))
	fromAddr := clientCtx.GetFromAddress().String()
	require.NotEmpty(t, fromAddr, "The from address should not be empty")
	_, err := sdk.AccAddressFromBech32(fromAddr)
	require.NoError(t, err, "Invalid From address in context")
	testAmount := "1000stake"
	parsedAmount, err := sdk.ParseCoinNormalized(testAmount)
	require.NoError(t, err, "Failed to parse test coin amount")
	cmd := cli.CmdMint()
	cmd.SetContext(context.Background())
	cmd.RunE(cmd, []string{validToAddress, testAmount})
	expectedMsg := ttypes.NewMsgMint(fromAddr, validToAddress, parsedAmount)
	require.Equal(t, expectedMsg.From, fromAddr, "Expected 'From' address mismatch")
	require.Equal(t, expectedMsg.Address, validToAddress, "Expected 'To' address mismatch")
	require.Equal(t, expectedMsg.Amount, parsedAmount, "Expected amount mismatch")
}
func TestCmdConfigureMinterController(t *testing.T) {
	cmd := cli.CmdConfigureMinterController()
	fromAddress := sample.AccAddress()
	controllerAddress := sample.AccAddress()
	minterAddress := sample.AccAddress()
	cmd.SetContext(context.Background())
	cmd.RunE(cmd, []string{controllerAddress, minterAddress})
	expectedMsg := ttypes.NewMsgConfigureMinterController(fromAddress, controllerAddress, minterAddress)
	require.Equal(t, expectedMsg.From, fromAddress)
	require.Equal(t, expectedMsg.Controller, controllerAddress)
	require.Equal(t, expectedMsg.Minter, minterAddress)
}

func TestCmdConfigureMinter(t *testing.T) {
	cmd := cli.CmdConfigureMinter()
	fromAddress := sample.AccAddress()
	allowance := "1000ufusd"
	address := sample.AccAddress()
	cmd.SetContext(context.Background())
	cmd.RunE(cmd, []string{address, allowance})
	expectedAllowance, err := types.ParseCoinNormalized(allowance)
	require.NoError(t, err)

	expectedMsg := ttypes.NewMsgConfigureMinter(fromAddress, address, expectedAllowance)
	require.Equal(t, expectedMsg.From, fromAddress)
	require.Equal(t, expectedMsg.Address, address)
	require.Equal(t, expectedMsg.Allowance, expectedAllowance)
}
func TestCmdBurn(t *testing.T) {
	cmd := cli.CmdBurn()
	fromAddress := sample.AccAddress()
	amount := "1000ufusd"
	cmd.SetContext(context.Background())
	cmd.RunE(cmd, []string{amount})
	expectedAmount, err := types.ParseCoinNormalized(amount)
	require.NoError(t, err)

	expectedMsg := ttypes.NewMsgBurn(fromAddress, expectedAmount)
	require.Equal(t, expectedMsg.From, fromAddress)
	require.Equal(t, expectedMsg.Amount, expectedAmount)
}
func TestCmdBlacklist(t *testing.T) {
	cmd := cli.CmdBlacklist()
	fromAddress := sample.AccAddress()
	blacklistAddress := sample.AccAddress()
	cmd.SetContext(context.Background())
	cmd.RunE(cmd, []string{blacklistAddress})
	expectedMsg := ttypes.NewMsgBlacklist(fromAddress, blacklistAddress)
	require.Equal(t, expectedMsg.From, fromAddress)
	require.Equal(t, expectedMsg.Address, blacklistAddress)
}

func TestCmdAcceptOwner(t *testing.T) {
	cmd := cli.CmdAcceptOwner()
	fromAddress := sample.AccAddress()
	cmd.SetContext(context.Background())
	cmd.RunE(cmd, []string{})
	expectedMsg := ttypes.NewMsgAcceptOwner(fromAddress)
	require.Equal(t, expectedMsg.From, fromAddress)
}
func TestGetTxCmd(t *testing.T) {
	cmd := cli.GetTxCmd()
	tests := []struct {
		expectedCmd string
		cmdName     string
	}{
		{"update-master-minter [address]", "update-master-minter"},
		{"update-pauser [address]", "update-pauser"},
		{"update-blacklister [address]", "update-blacklister"},
		{"update-owner [address]", "update-owner"},
		{"accept-owner [address]", "accept-owner"},
		{"configure-minter [address] [allowance]", "configure-minter"},
		{"remove-minter [address]", "remove-minter"},
		{"mint [address] [amount]", "mint"},
		{"burn [amount]", "burn"},
		{"blacklist [address]", "blacklist"},
		{"unblacklist [address]", "unblacklist"},
		{"pause", "pause"},
		{"unpause", "unpause"},
		{"configure-minter-controller [controller] [minter]", "configure-minter-controller"},
		{"remove-minter-controller [controller] [minter]", "remove-minter-controller"},
	}
	for _, tt := range tests {
		t.Run(tt.cmdName, func(t *testing.T) {
			actualCmd, _, _ := cmd.Find([]string{tt.cmdName})
			assert.Equal(t, tt.expectedCmd, actualCmd.Use)
		})
	}
}
func TestNewTxCmd(t *testing.T) {
	cmd := cli.NewTxCmd(nil, nil)

	tests := []struct {
		expectedCmd string
		cmdName     string
	}{
		{"update-master-minter [address]", "update-master-minter"},
		{"update-pauser [address]", "update-pauser"},
		{"update-blacklister [address]", "update-blacklister"},
		{"update-owner [address]", "update-owner"},
		{"accept-owner [address]", "accept-owner"},
		{"configure-minter [address] [allowance]", "configure-minter"},
		{"remove-minter [address]", "remove-minter"},
		{"mint [address] [amount]", "mint"},
		{"burn [amount]", "burn"},
		{"blacklist [address]", "blacklist"},
		{"unblacklist [address]", "unblacklist"},
		{"pause", "pause"},
		{"unpause", "unpause"},
		{"configure-minter-controller [controller] [minter]", "configure-minter-controller"},
		{"remove-minter-controller [controller] [minter]", "remove-minter-controller"},
	}
	for _, tt := range tests {
		t.Run(tt.cmdName, func(t *testing.T) {
			actualCmd, _, _ := cmd.Find([]string{tt.cmdName})
			assert.Equal(t, tt.expectedCmd, actualCmd.Use)
		})
	}
}
