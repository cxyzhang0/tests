package cli_test

import (
	"encoding/json"
	"fmt"
	"testing"

	tmcli "github.com/cometbft/cometbft/libs/cli"
	clitestutil "github.com/cosmos/cosmos-sdk/testutil/cli"
	"github.com/cosmos/cosmos-sdk/testutil/configurator"
	banktypes "github.com/cosmos/cosmos-sdk/x/bank/types"
	"github.com/stretchr/testify/require"
	"google.golang.org/grpc/status"

	"github.com/wfblockchain/coreblockchain/v2/testutil/network"
	"github.com/wfblockchain/coreblockchain/v2/testutil/nullify"
	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/client/cli"
	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"

	appv1alpha1 "cosmossdk.io/api/cosmos/app/v1alpha1"
	"cosmossdk.io/core/appconfig"
	moduletestutil "github.com/cosmos/cosmos-sdk/types/module/testutil"
	authtypes "github.com/cosmos/cosmos-sdk/x/auth/types"
	stakingtypes "github.com/cosmos/cosmos-sdk/x/staking/types"
	tokenfactorymodulev1 "github.com/wfblockchain/coreblockchain/v2/api/coreblockchain/module/v1"
	tokenfactorymodule "github.com/wfblockchain/coreblockchain/v2/x/tokenfactory"
)

type StdLogger struct{}

func (l StdLogger) Log(args ...interface{}) {
	fmt.Println(args...)
}

func (l StdLogger) Logf(format string, args ...interface{}) {
	fmt.Printf(format, args...)
}

func TokenfactoryModule() configurator.ModuleOption {
	return func(config *configurator.Config) {
		config.ModuleConfigs["tokenfactory"] = &appv1alpha1.ModuleConfig{
			Name:   "tokenfactory",
			Config: appconfig.WrapAny(&tokenfactorymodulev1.Module{}),
		}
		config.InitGenesisOrder = append(config.InitGenesisOrder, "tokenfactory")
	}
}

func networkWithMintingDenomObjects(t *testing.T) (*network.Network, []types.MintingDenom) {
	t.Helper()
	cfg, err := network.DefaultConfigWithAppConfig(configurator.NewAppConfig(
		configurator.AuthModule(),
		configurator.BankModule(),
		configurator.StakingModule(),
		configurator.ParamsModule(),
		configurator.GenutilModule(),
		configurator.ConsensusModule(),
		configurator.TxModule(),
		// Add custom module here:
		TokenfactoryModule(),
	), func() network.TestFixture {
		return network.TestFixture{
			EncodingConfig: moduletestutil.MakeTestEncodingConfig(),
			GenesisState:   make(map[string]json.RawMessage),
		}
	})
	require.NoError(t, err)

	cfg.GenesisState[types.ModuleName] = cfg.Codec.MustMarshalJSON(types.DefaultGenesis())

	state := types.GenesisState{}
	require.NoError(t, cfg.Codec.UnmarshalJSON(cfg.GenesisState[types.ModuleName], &state))

	testDenom := "test"

	state.MintingDenomList = []types.MintingDenom{
		{Denom: testDenom},
	}

	bankState := banktypes.DefaultGenesisState()
	bankState.DenomMetadata = []banktypes.Metadata{{
		Base: testDenom,
	}}

	buf, err := cfg.Codec.MarshalJSON(bankState)
	require.NoError(t, err)
	cfg.GenesisState[banktypes.ModuleName] = buf

	authState := authtypes.DefaultGenesisState()
	authState.Params.MaxMemoCharacters = 512
	authState.Params.TxSigLimit = 7
	authState.Params.TxSizeCostPerByte = 10
	authState.Params.SigVerifyCostED25519 = 590
	authState.Params.SigVerifyCostSecp256k1 = 1000

	buf, err = cfg.Codec.MarshalJSON(authState)
	require.NoError(t, err)
	cfg.GenesisState[authtypes.ModuleName] = buf

	authtypes.RegisterInterfaces(cfg.InterfaceRegistry)

	buf, err = cfg.Codec.MarshalJSON(&state)
	require.NoError(t, err)
	cfg.GenesisState[types.ModuleName] = buf

	baseDir := t.TempDir()
	fmt.Printf("Creating network with baseDir: %s\n", baseDir)
	l := StdLogger{}

	stakingtypes.RegisterInterfaces(cfg.InterfaceRegistry)

	returnValue, err := network.New(l, baseDir, cfg)
	require.NoError(t, err, "failed to create network")

	return returnValue, state.MintingDenomList
}

func TestShowMintingDenom(t *testing.T) {
	tokenfactorymodule.DepinjectInit()
	net, objs := networkWithMintingDenomObjects(t)

	ctx := net.Validators[0].ClientCtx
	common := []string{
		fmt.Sprintf("--%s=json", tmcli.OutputFlag),
	}
	for _, tc := range []struct {
		desc    string
		idDenom string
		args    []string
		err     error
		obj     types.MintingDenom
	}{
		{
			desc:    "get",
			idDenom: objs[0].Denom,
			args:    common,
			obj:     objs[0],
		},
	} {
		t.Run(tc.desc, func(t *testing.T) {
			args := []string{
				tc.idDenom,
			}
			args = append(args, tc.args...)
			out, err := clitestutil.ExecTestCLICmd(ctx, cli.CmdShowMintingDenom(), args)
			if tc.err != nil {
				stat, ok := status.FromError(tc.err)
				require.True(t, ok)
				require.ErrorIs(t, stat.Err(), tc.err)
			} else {
				require.NoError(t, err)
				var resp types.QueryGetMintingDenomResponse
				require.NoError(t, net.Config.Codec.UnmarshalJSON(out.Bytes(), &resp))
				require.NotNil(t, resp.MintingDenom)
				require.Equal(t,
					nullify.Fill(&tc.obj),
					nullify.Fill(&resp.MintingDenom),
				)
			}
		})
	}
}
