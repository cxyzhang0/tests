package tokenfactory_test

import (
	"testing"

	errorsmod "cosmossdk.io/errors"
	codectypes "github.com/cosmos/cosmos-sdk/codec/types"
	"github.com/cosmos/cosmos-sdk/x/authz"
	transfertypes "github.com/cosmos/ibc-go/v10/modules/apps/transfer/types"
	tokenfactory "github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/keeper"

	sdk "github.com/cosmos/cosmos-sdk/types"
	banktypes "github.com/cosmos/cosmos-sdk/x/bank/types"

	. "github.com/wfblockchain/coreblockchain/v2/x/tokenfactory"
)

//
// ------------------------------------------------------------
// Blacklist testing utilities
// ------------------------------------------------------------
//

// Fake blacklist tracker
type fakeBlacklistTF struct {
	blacklisted map[string]bool
}

func (f fakeBlacklistTF) IsBlacklisted(addr string) bool {
	return f.blacklisted[addr]
}

// Wrap the real checker with our mockable implementation
func makeBlacklistChecker(f fakeBlacklistTF) func(
	ctx sdk.Context, addrs []string, coin sdk.Coin, t *tokenfactory.Keeper,
) (bool, string, *errorsmod.Error) {

	return func(
		ctx sdk.Context, addrs []string, coin sdk.Coin, _ *tokenfactory.Keeper,
	) (bool, string, *errorsmod.Error) {

		for _, a := range addrs {
			if f.IsBlacklisted(a) {
				return true, a, nil
			}
		}
		return false, "", nil
	}
}

// Backup original global fn
var originalBlacklistChecker = BlacklistChecker

func setBlacklistChecker(fn func(sdk.Context, []string, sdk.Coin, *tokenfactory.Keeper) (bool, string, *errorsmod.Error)) {
	BlacklistChecker = fn
}

func restoreBlacklistChecker() {
	BlacklistChecker = originalBlacklistChecker
}

//
// ------------------------------------------------------------
// Tests: checkCoinAgainstAddresses
// ------------------------------------------------------------
//

func TestCheckCoinAgainstAddresses_Blacklisted(t *testing.T) {
	defer restoreBlacklistChecker()

	tf := fakeBlacklistTF{blacklisted: map[string]bool{"addr1": true}}
	setBlacklistChecker(makeBlacklistChecker(tf))

	ad := IsBlacklistedDecorator{}
	err := ad.CheckCoinAgainstAddresses(
		sdk.Context{},
		[]string{"addr1"},
		sdk.NewInt64Coin("ufoo", 10),
	)

	if err == nil {
		t.Fatalf("expected blacklist error")
	}
}

func TestCheckCoinAgainstAddresses_NotBlacklisted(t *testing.T) {
	defer restoreBlacklistChecker()

	tf := fakeBlacklistTF{blacklisted: map[string]bool{}}
	setBlacklistChecker(makeBlacklistChecker(tf))

	ad := IsBlacklistedDecorator{}
	err := ad.CheckCoinAgainstAddresses(
		sdk.Context{},
		[]string{"addr1"},
		sdk.NewInt64Coin("ufoo", 10),
	)

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
}

//
// ------------------------------------------------------------
// Tests: checkCoinsAgainstAddresses
// ------------------------------------------------------------
//

func TestCheckCoinsAgainstAddresses(t *testing.T) {
	defer restoreBlacklistChecker()

	tf := fakeBlacklistTF{
		blacklisted: map[string]bool{
			"addr2": true,
		},
	}
	setBlacklistChecker(makeBlacklistChecker(tf))

	ad := IsBlacklistedDecorator{}
	err := ad.CheckCoinsAgainstAddresses(
		sdk.Context{},
		[]string{"addr1", "addr2"},
		sdk.NewCoins(
			sdk.NewInt64Coin("ufoo", 10),
			sdk.NewInt64Coin("ubar", 20),
		),
	)

	if err == nil {
		t.Fatalf("expected blacklist error")
	}
}

//
// ------------------------------------------------------------
// Tests: checkMessage — MsgSend
// ------------------------------------------------------------
//

func TestCheckMessage_MsgSend_Blacklisted(t *testing.T) {
	defer restoreBlacklistChecker()

	tf := fakeBlacklistTF{blacklisted: map[string]bool{"addr2": true}}
	setBlacklistChecker(makeBlacklistChecker(tf))

	msg := &banktypes.MsgSend{
		FromAddress: "addr1",
		ToAddress:   "addr2",
		Amount: sdk.NewCoins(
			sdk.NewInt64Coin("ufoo", 10),
		),
	}

	ad := IsBlacklistedDecorator{}
	err := ad.CheckMessage(sdk.Context{}, msg)

	if err == nil {
		t.Fatalf("expected blacklist error")
	}
}

func TestCheckMessage_MsgSend_NotBlacklisted(t *testing.T) {
	defer restoreBlacklistChecker()

	tf := fakeBlacklistTF{blacklisted: map[string]bool{}}
	setBlacklistChecker(makeBlacklistChecker(tf))

	msg := &banktypes.MsgSend{
		FromAddress: "addr1",
		ToAddress:   "addr2",
		Amount:      sdk.NewCoins(sdk.NewInt64Coin("ufoo", 10)),
	}

	ad := IsBlacklistedDecorator{}
	err := ad.CheckMessage(sdk.Context{}, msg)

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
}

//
// ------------------------------------------------------------
// Tests: checkMessage — MsgMultiSend
// ------------------------------------------------------------
//

func TestCheckMessage_MsgMultiSend_Blacklisted(t *testing.T) {
	defer restoreBlacklistChecker()

	tf := fakeBlacklistTF{blacklisted: map[string]bool{"addr1": true}}
	setBlacklistChecker(makeBlacklistChecker(tf))

	msg := &banktypes.MsgMultiSend{
		Inputs: []banktypes.Input{
			{
				Address: "addr1",
				Coins: sdk.NewCoins(
					sdk.NewInt64Coin("ufoo", 10),
					sdk.NewInt64Coin("ubar", 10),
				),
			},
		},
	}

	ad := IsBlacklistedDecorator{}
	err := ad.CheckMessage(sdk.Context{}, msg)

	if err == nil {
		t.Fatalf("expected blacklist error")
	}
}

func TestCheckMessage_MsgMultiSend_NotBlacklisted(t *testing.T) {
	defer restoreBlacklistChecker()

	tf := fakeBlacklistTF{blacklisted: map[string]bool{}}
	setBlacklistChecker(makeBlacklistChecker(tf))

	msg := &banktypes.MsgMultiSend{
		Inputs: []banktypes.Input{
			{
				Address: "addr1",
				Coins:   sdk.NewCoins(sdk.NewInt64Coin("ufoo", 10)),
			},
		},
		Outputs: []banktypes.Output{
			{
				Address: "addr2",
				Coins:   sdk.NewCoins(sdk.NewInt64Coin("ubar", 10)),
			},
		},
	}

	ad := IsBlacklistedDecorator{}
	err := ad.CheckMessage(sdk.Context{}, msg)

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
}

//
// ------------------------------------------------------------
// Tests: checkMessage — MsgTransfer
// ------------------------------------------------------------
//

func TestCheckMessage_MsgTransfer_Blacklisted(t *testing.T) {
	defer restoreBlacklistChecker()

	tf := fakeBlacklistTF{blacklisted: map[string]bool{"sender1": true}}
	setBlacklistChecker(makeBlacklistChecker(tf))

	msg := &transfertypes.MsgTransfer{
		Sender:   "sender1",
		Receiver: "receiver1",
		Token:    sdk.NewInt64Coin("ufoo", 10),
	}

	ad := IsBlacklistedDecorator{}
	err := ad.CheckMessage(sdk.Context{}, msg)

	if err == nil {
		t.Fatalf("expected blacklist error")
	}
}

func TestCheckMessage_MsgTransfer_NotBlacklisted(t *testing.T) {
	defer restoreBlacklistChecker()

	tf := fakeBlacklistTF{blacklisted: map[string]bool{}}
	setBlacklistChecker(makeBlacklistChecker(tf))

	msg := &transfertypes.MsgTransfer{
		Sender:   "sender1",
		Receiver: "receiver1",
		Token:    sdk.NewInt64Coin("ufoo", 10),
	}

	ad := IsBlacklistedDecorator{}
	err := ad.CheckMessage(sdk.Context{}, msg)

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
}

func TestCheckMessage_MsgExec_RecursesIntoInnerMessages_Blacklisted(t *testing.T) {
	defer restoreBlacklistChecker()

	tf := fakeBlacklistTF{blacklisted: map[string]bool{"addr2": true}}
	setBlacklistChecker(makeBlacklistChecker(tf))

	innerSend := &banktypes.MsgSend{
		FromAddress: "addr1",
		ToAddress:   "addr2",
		Amount:      sdk.NewCoins(sdk.NewInt64Coin("ufoo", 10)),
	}
	innerAny, err := codectypes.NewAnyWithValue(innerSend)
	if err != nil {
		t.Fatalf("failed to pack inner MsgSend: %v", err)
	}

	msgExec := &authz.MsgExec{Msgs: []*codectypes.Any{innerAny}}

	ad := IsBlacklistedDecorator{}
	err = ad.CheckMessage(sdk.Context{}, msgExec)
	if err == nil {
		t.Fatalf("expected blacklist error for MsgExec inner message")
	}
}

func TestCheckMessage_BlacklistMsgExec_GetMessagesError(t *testing.T) {
	defer restoreBlacklistChecker()
	setBlacklistChecker(originalBlacklistChecker)

	msgExec := &authz.MsgExec{
		Msgs: []*codectypes.Any{
			{
				TypeUrl: "/cosmos.bank.v1beta1.MsgSend",
				Value:   []byte{0x01},
			},
		},
	}

	ad := IsBlacklistedDecorator{}
	err := ad.CheckMessage(sdk.Context{}, msgExec)
	if err == nil {
		t.Fatalf("expected GetMessages error for invalid MsgExec.Any payload")
	}
}

//
// ------------------------------------------------------------
// Test: unknown message
// ------------------------------------------------------------
//

func TestCheckMessage_IgnoresUnknown(t *testing.T) {
	defer restoreBlacklistChecker()

	setBlacklistChecker(originalBlacklistChecker) // unused

	ad := IsBlacklistedDecorator{}
	err := ad.CheckMessage(sdk.Context{}, unknownMsg{})

	if err != nil {
		t.Fatalf("unexpected error for unknown msg: %v", err)
	}
}

//
// ------------------------------------------------------------
// Test: AnteHandle
// ------------------------------------------------------------
//

func TestAnteHandle_Blacklisted(t *testing.T) {
	defer restoreBlacklistChecker()

	tf := fakeBlacklistTF{blacklisted: map[string]bool{"addr1": true}}
	setBlacklistChecker(makeBlacklistChecker(tf))

	tx := mockTx{
		msgs: []sdk.Msg{
			&banktypes.MsgSend{
				FromAddress: "addr1",
				ToAddress:   "addr2",
				Amount:      sdk.NewCoins(sdk.NewInt64Coin("ufoo", 10)),
			},
		},
	}

	nextCalled := false
	next := func(ctx sdk.Context, tx sdk.Tx, simulate bool) (sdk.Context, error) {
		nextCalled = true
		return ctx, nil
	}

	ad := IsBlacklistedDecorator{}
	_, err := ad.AnteHandle(sdk.Context{}, tx, false, next)

	if err == nil {
		t.Fatalf("expected blacklist error")
	}
	if nextCalled {
		t.Fatalf("next handler should not be called")
	}
}

func TestAnteHandle_NotBlacklisted(t *testing.T) {
	defer restoreBlacklistChecker()

	tf := fakeBlacklistTF{blacklisted: map[string]bool{}}
	setBlacklistChecker(makeBlacklistChecker(tf))

	tx := mockTx{
		msgs: []sdk.Msg{
			&banktypes.MsgSend{
				FromAddress: "addr1",
				ToAddress:   "addr2",
				Amount:      sdk.NewCoins(sdk.NewInt64Coin("ufoo", 10)),
			},
		},
	}

	nextCalled := false
	next := func(ctx sdk.Context, tx sdk.Tx, simulate bool) (sdk.Context, error) {
		nextCalled = true
		return ctx, nil
	}

	ad := IsBlacklistedDecorator{}
	_, err := ad.AnteHandle(sdk.Context{}, tx, false, next)

	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}
	if !nextCalled {
		t.Fatalf("next handler should be invoked")
	}
}
