package tokenfactory

import (
	errorsmod "cosmossdk.io/errors"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/cosmos/cosmos-sdk/types/bech32"
	"github.com/cosmos/cosmos-sdk/x/authz"
	banktypes "github.com/cosmos/cosmos-sdk/x/bank/types"
	transfertypes "github.com/cosmos/ibc-go/v10/modules/apps/transfer/types"
	tokenfactory "github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/keeper"
	tokenfactorytypes "github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"
)

//
// ------------------------------------------------------------
//  go test ./x/tokenfactory -run '^Test' -- ante_tf_test.go
// ------------------------------------------------------------
//

// PausedChecker as a func var to allow mocking in unit tests
var PausedChecker = checkPausedStateByTokenFactory

type IsPausedDecorator struct {
	tokenFactory *tokenfactory.Keeper
}

func NewIsPausedDecorator(tf *tokenfactory.Keeper) IsPausedDecorator {
	return IsPausedDecorator{
		tokenFactory: tf,
	}
}

// AnteHandle checks if the token factory is paused before processing any transaction of one of the minting tokens.
// note: circlefin fiattokenfactory has evolved and this handler mostly resembles their 2004-03 release.
func (ad IsPausedDecorator) AnteHandle(
	ctx sdk.Context,
	tx sdk.Tx,
	simulate bool,
	next sdk.AnteHandler,
) (sdk.Context, error) {
	for _, msg := range tx.GetMsgs() {
		if err := ad.CheckMessage(ctx, msg); err != nil {
			return ctx, err
		}
	}

	return next(ctx, tx, simulate)
}

// --------------------------------------------
// Message dispatcher (simple + low complexity)
// --------------------------------------------
func (ad IsPausedDecorator) CheckMessage(ctx sdk.Context, msg sdk.Msg) error {
	switch m := msg.(type) {

	case *banktypes.MsgSend:
		return ad.CheckCoins(ctx, m.Amount)

	case *banktypes.MsgMultiSend:
		for _, in := range m.Inputs {
			if err := ad.CheckCoins(ctx, in.Coins); err != nil {
				return err
			}
		}
		return nil

	case *transfertypes.MsgTransfer:
		return ad.CheckCoin(ctx, m.Token)

	case *authz.MsgExec:
		msgs, err := m.GetMessages()
		if err != nil {
			return err
		}
		for _, inner := range msgs {
			if err := ad.CheckMessage(ctx, inner); err != nil {
				return err
			}
		}
		return nil

	default:
		return nil
	}
}

// --------------------------------------------
// Shared coin-checking helpers
// --------------------------------------------
func (ad IsPausedDecorator) CheckCoins(ctx sdk.Context, coins sdk.Coins) error {
	for _, c := range coins {
		if err := ad.CheckCoin(ctx, c); err != nil {
			return err
		}
	}
	return nil
}

func (ad IsPausedDecorator) CheckCoin(ctx sdk.Context, c sdk.Coin) error {
	paused, err := PausedChecker(ctx, c, ad.tokenFactory)
	if paused {
		return errorsmod.Wrap(err, "can not perform token transactions")
	}
	return nil
}

// checkPausedStateByTokenFactory first checks if the token denom is a minting denom of the tokenfactory.
// if it is, it checks if the tokenfactory is paused. If so, it returns true with an error so the handler can stop processing the transaction.
// that means if the denom is not a minting or the factory is not paused, it returns false with no error.
func checkPausedStateByTokenFactory(ctx sdk.Context, c sdk.Coin, tf *tokenfactory.Keeper) (bool, *errorsmod.Error) {
	tfMintingDenom, found := tf.GetMintingDenom(ctx, c.Denom)
	if found {
		if c.Denom == tfMintingDenom.Denom { // this should be always true because found is true; double check for safety
			paused := tf.GetPaused(ctx)
			if paused.Paused {
				return true, tokenfactorytypes.ErrPaused
			}
		}
	}
	return false, nil
}

// BlacklistChecker as a func var to allow mocking in unit tests
var BlacklistChecker = checkForBlacklistedAddressByTokenFactory

type IsBlacklistedDecorator struct {
	tokenfactory *tokenfactory.Keeper
}

func NewIsBlacklistedDecorator(tf *tokenfactory.Keeper) IsBlacklistedDecorator {
	return IsBlacklistedDecorator{
		tokenfactory: tf,
	}
}

// AnteHandle checks if the addresses in the tx are blacklisted if the tx is on one of the minting tokens.
// note: circlefin fiattokenfactory has evolved and this handler mostly resembles their 2004-03 release.
func (ad IsBlacklistedDecorator) AnteHandle(
	ctx sdk.Context,
	tx sdk.Tx,
	simulate bool,
	next sdk.AnteHandler,
) (sdk.Context, error) {

	for _, msg := range tx.GetMsgs() {
		if err := ad.CheckMessage(ctx, msg); err != nil {
			return ctx, err
		}
	}

	return next(ctx, tx, simulate)
}

// ------------------------------------------------------
// Dispatcher
// ------------------------------------------------------
func (ad IsBlacklistedDecorator) CheckMessage(ctx sdk.Context, msg sdk.Msg) error {
	switch m := msg.(type) {

	case *banktypes.MsgSend:
		return ad.checkSend(ctx, m)

	case *banktypes.MsgMultiSend:
		return ad.checkMultiSend(ctx, m)

	case *transfertypes.MsgTransfer:
		return ad.checkTransfer(ctx, m)

	default:
		return nil // ignore non-bank/transfer messages
	}
}

// ------------------------------------------------------
// MsgSend
// ------------------------------------------------------
func (ad IsBlacklistedDecorator) checkSend(ctx sdk.Context, m *banktypes.MsgSend) error {
	addresses := []string{m.FromAddress, m.ToAddress}
	return ad.CheckCoinsAgainstAddresses(ctx, addresses, m.Amount)
}

// ------------------------------------------------------
// MsgMultiSend
// ------------------------------------------------------
func (ad IsBlacklistedDecorator) checkMultiSend(ctx sdk.Context, m *banktypes.MsgMultiSend) error {
	// Inputs
	for _, in := range m.Inputs {
		if err := ad.CheckCoinsAgainstAddresses(ctx, []string{in.Address}, in.Coins); err != nil {
			return err
		}
	}
	// Outputs
	for _, out := range m.Outputs {
		if err := ad.CheckCoinsAgainstAddresses(ctx, []string{out.Address}, out.Coins); err != nil {
			return err
		}
	}
	return nil
}

// ------------------------------------------------------
// MsgTransfer
// ------------------------------------------------------
func (ad IsBlacklistedDecorator) checkTransfer(ctx sdk.Context, m *transfertypes.MsgTransfer) error {
	addresses := []string{m.Sender, m.Receiver}
	return ad.CheckCoinAgainstAddresses(ctx, addresses, m.Token)
}

// ------------------------------------------------------
// Shared helpers
// ------------------------------------------------------
func (ad IsBlacklistedDecorator) CheckCoinsAgainstAddresses(
	ctx sdk.Context,
	addresses []string,
	coins sdk.Coins,
) error {

	for _, c := range coins {
		if err := ad.CheckCoinAgainstAddresses(ctx, addresses, c); err != nil {
			return err
		}
	}
	return nil
}

func (ad IsBlacklistedDecorator) CheckCoinAgainstAddresses(
	ctx sdk.Context,
	addresses []string,
	coin sdk.Coin,
) error {

	blacklisted, address, err :=
		BlacklistChecker(ctx, addresses, coin, ad.tokenfactory)

	if blacklisted {
		return errorsmod.Wrapf(err,
			"an address (%s) is blacklisted and can not send or receive tokens", address)
	}
	if err != nil {
		return errorsmod.Wrapf(err,
			"error decoding address (%s)", address)
	}
	return nil
}

// checkForBlacklistedAddressByTokenFactory first checks if the token denom is a minting denom of the tokenFactory,
// if it is, it checks if any address involved is blacklisted, if yes, return true, with the address and error.
// otherwise, if the denom is not a minting denom or none of the addresses is blacklisted, it returns false with no error.
// note: in case one address is not decodable, it returns false with the address and error so the calling handler will stop processing the transaction.
func checkForBlacklistedAddressByTokenFactory(ctx sdk.Context, addresses []string, c sdk.Coin, tf *tokenfactory.Keeper) (blacklisted bool, blacklistedAddress string, _ *errorsmod.Error) {
	tfMintingDenom, found := tf.GetMintingDenom(ctx, c.Denom)
	if found {
		if c.Denom == tfMintingDenom.Denom {
			for _, address := range addresses {
				_, addressBz, err := bech32.DecodeAndConvert(address)
				if err != nil {
					return false, address, tokenfactorytypes.ErrInvalidAddr
				}
				_, found := tf.GetBlacklisted(ctx, addressBz)
				if found {
					return true, address, tokenfactorytypes.ErrUnauthorized
				}
			}
		}
	}
	return false, "", nil
}
