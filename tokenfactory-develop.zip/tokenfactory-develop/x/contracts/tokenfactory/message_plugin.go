package tokenfactory

import (
	"encoding/json"

	errorsmod "cosmossdk.io/errors"
	"cosmossdk.io/x/feegrant"
	feegrantkeeper "cosmossdk.io/x/feegrant/keeper"
	wasmkeeper "github.com/CosmWasm/wasmd/x/wasm/keeper"
	wasmvmtypes "github.com/CosmWasm/wasmvm/v2/types"

	codectypes "github.com/cosmos/cosmos-sdk/codec/types"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/wfblockchain/coreblockchain/v2/x/contracts/tokenfactory/bindings"
	tokenfactorymodulekeeper "github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/keeper"
	tokenfactorymoduletypes "github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"

	"time"
)

const (
	NullCustomMessageError           = "null custom message"
	FailedToParseGranterAddressError = "failed to parse granter address"
)

// CustomMessagerDecorator returns decorator for custom CosmWasm bindings messages
func CustomMessagerDecorator(tf *tokenfactorymodulekeeper.Keeper, feegrant *feegrantkeeper.Keeper) func(message wasmkeeper.Messenger) wasmkeeper.Messenger {
	return func(old wasmkeeper.Messenger) wasmkeeper.Messenger {
		return &CustomMessenger{
			Wrapped:  old,
			Tf:       tf,
			Feegrant: feegrant,
		}
	}
}

type CustomMessenger struct {
	Wrapped  wasmkeeper.Messenger
	Tf       *tokenfactorymodulekeeper.Keeper
	Feegrant *feegrantkeeper.Keeper
}

func (m *CustomMessenger) DispatchMsg(ctx sdk.Context, contractAddr sdk.AccAddress, contractIBCPortID string, msg wasmvmtypes.CosmosMsg) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	if msg.Custom == nil {
		return m.Wrapped.DispatchMsg(ctx, contractAddr, contractIBCPortID, msg)
	}

	// msg.Custom != nil
	var contractMsg bindings.FactoryMsg
	if err := json.Unmarshal(msg.Custom, &contractMsg); err != nil {
		return events, data, msgResponses, errorsmod.Wrap(err, "failed to decode custom bindings msg")
	}
	if contractMsg.TF != nil {
		tf := contractMsg.TF
		switch {
		case tf.UpdateMasterMinter != nil:
			return m.updateMasterMinter(ctx, contractAddr, tf.UpdateMasterMinter, true)
		case tf.ConfigureMinterController != nil:
			return m.configureMinterController(ctx, contractAddr, tf.ConfigureMinterController, true)
		case tf.RemoveMinterController != nil:
			return m.removeMinterController(ctx, contractAddr, tf.RemoveMinterController, true)
		case tf.ConfigureMinter != nil:
			return m.configureMinter(ctx, contractAddr, tf.ConfigureMinter, true)
		case tf.RemoveMinter != nil:
			return m.removeMinter(ctx, contractAddr, tf.RemoveMinter, true)
		case tf.UpdateBlacklister != nil:
			return m.updateBlacklister(ctx, contractAddr, tf.UpdateBlacklister, true)
		case tf.Blacklist != nil:
			return m.blacklist(ctx, contractAddr, tf.Blacklist, true)
		case tf.Unblacklist != nil:
			return m.unblacklist(ctx, contractAddr, tf.Unblacklist, true)
		case tf.UpdatePauser != nil:
			return m.updatePauser(ctx, contractAddr, tf.UpdatePauser, true)
		case tf.Pause != nil:
			return m.pause(ctx, contractAddr, tf.Pause, true)
		case tf.Unpause != nil:
			return m.unpause(ctx, contractAddr, tf.Unpause, true)
		case tf.Mint != nil:
			return m.mint(ctx, contractAddr, tf.Mint, true)
		case tf.Burn != nil:
			return m.burn(ctx, contractAddr, tf.Burn, true)
		case tf.SetDenomMetadata != nil:
			return m.setDenomMetadata(ctx, contractAddr, tf.SetDenomMetadata)
		default:
			// fall through to wrapped handler
		}
	}

	if contractMsg.Feegrant != nil {
		fg := contractMsg.Feegrant

		switch {
		case fg.GrantFeeBasicAllowance != nil:
			return m.grantFeeBasicAllowance(ctx, contractAddr, fg.GrantFeeBasicAllowance)
		case fg.RevokeFeeAllowance != nil:
			return m.revokeFeeAllowance(ctx, contractAddr, fg.RevokeFeeAllowance)
		default:
			// fall through to wrapped handler
		}
	}

	return m.Wrapped.DispatchMsg(ctx, contractAddr, contractIBCPortID, msg)
}

// prior to refactoring above
/*
func (m *CustomMessenger) DispatchMsg(ctx sdk.Context, contractAddr sdk.AccAddress, contractIBCPortID string, msg wasmvmtypes.CosmosMsg) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	if msg.Custom == nil {
		return m.Wrapped.DispatchMsg(ctx, contractAddr, contractIBCPortID, msg)
	}
	//if msg.Custom != nil {
	var contractMsg bindings.FactoryMsg
	if err := json.Unmarshal(msg.Custom, &contractMsg); err != nil {
		return events, data, msgResponses, errorsmod.Wrap(err, "failed to decode tokenfactory msg")
	}
	if contractMsg.TF != nil {
		if contractMsg.TF.UpdateMasterMinter != nil {
			return m.updateMasterMinter(ctx, contractAddr, contractMsg.TF.UpdateMasterMinter, true)
		}
		if contractMsg.TF.ConfigureMinterController != nil {
			return m.configureMinterController(ctx, contractAddr, contractMsg.TF.ConfigureMinterController, true)
		}
		if contractMsg.TF.RemoveMinterController != nil {
			return m.removeMinterController(ctx, contractAddr, contractMsg.TF.RemoveMinterController, true)
		}
		if contractMsg.TF.ConfigureMinter != nil {
			return m.configureMinter(ctx, contractAddr, contractMsg.TF.ConfigureMinter, true)
		}
		if contractMsg.TF.RemoveMinter != nil {
			return m.removeMinter(ctx, contractAddr, contractMsg.TF.RemoveMinter, true)
		}
		if contractMsg.TF.UpdateBlacklister != nil {
			return m.updateBlacklister(ctx, contractAddr, contractMsg.TF.UpdateBlacklister, true)
		}
		if contractMsg.TF.Blacklist != nil {
			return m.blacklist(ctx, contractAddr, contractMsg.TF.Blacklist, true)
		}
		if contractMsg.TF.Unblacklist != nil {
			return m.unblacklist(ctx, contractAddr, contractMsg.TF.Unblacklist, true)
		}
		if contractMsg.TF.UpdatePauser != nil {
			return m.updatePauser(ctx, contractAddr, contractMsg.TF.UpdatePauser, true)
		}
		if contractMsg.TF.Pause != nil {
			return m.pause(ctx, contractAddr, contractMsg.TF.Pause, true)
		}
		if contractMsg.TF.Unpause != nil {
			return m.unpause(ctx, contractAddr, contractMsg.TF.Unpause, true)
		}
		if contractMsg.TF.Mint != nil {
			return m.mint(ctx, contractAddr, contractMsg.TF.Mint, true)
		}
		if contractMsg.TF.Burn != nil {
			return m.burn(ctx, contractAddr, contractMsg.TF.Burn, true)
		}
		if contractMsg.TF.SetDenomMetadata != nil {
			return m.setDenomMetadata(ctx, contractAddr, contractMsg.TF.SetDenomMetadata)
		}
	} else if contractMsg.Feegrant != nil {
		if contractMsg.Feegrant.GrantFeeBasicAllowance != nil {
			return m.grantFeeBasicAllowance(ctx, contractAddr, contractMsg.Feegrant.GrantFeeBasicAllowance)
		}
		if contractMsg.Feegrant.RevokeFeeAllowance != nil {
			return m.revokeFeeAllowance(ctx, contractAddr, contractMsg.Feegrant.RevokeFeeAllowance)
		}
	}
	//}

	return m.Wrapped.DispatchMsg(ctx, contractAddr, contractIBCPortID, msg)
}
*/

func (m *CustomMessenger) updateMasterMinter(ctx sdk.Context, _ sdk.AccAddress, custMsg *bindings.UpdateMasterMinter, isTF bool) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	// this is to prevent wrong function call
	if custMsg == nil {
		return events, data, msgResponses, wasmvmtypes.InvalidRequest{Err: NullCustomMessageError}
	}

	if isTF {
		msgServer := tokenfactorymodulekeeper.NewMsgServerImpl(m.Tf)

		msg := tokenfactorymoduletypes.NewMsgUpdateMasterMinter(custMsg.Signer, custMsg.Address)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic tf MsgUpdateMasterMinter")
		}

		_, err := msgServer.UpdateMasterMinter(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to update tf master minter")
		}
	}
	return events, data, msgResponses, nil

	// TODO: is it beneficial to add an event here?
	//return []sdk.Event{sdk.NewEvent("tokenfactory", sdk.NewAttribute("update_master_minter", contractAddr.String()))}, nil, nil
}

func (m *CustomMessenger) configureMinterController(ctx sdk.Context, _ sdk.AccAddress, custMsg *bindings.ConfigureMinterController, isTF bool) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	// this is to prevent wrong function call
	if custMsg == nil {
		return events, data, msgResponses, wasmvmtypes.InvalidRequest{Err: NullCustomMessageError}
	}

	if isTF {
		msgServer := tokenfactorymodulekeeper.NewMsgServerImpl(m.Tf)

		msg := tokenfactorymoduletypes.NewMsgConfigureMinterController(custMsg.Signer, custMsg.Controller, custMsg.Minter)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic tf MsgConfigureMinterController")
		}

		_, err := msgServer.ConfigureMinterController(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to configure tf minter controller")
		}
	}
	return events, data, msgResponses, nil

	// TODO: is it beneficial to add an event here?
	//return []sdk.Event{sdk.NewEvent("tokenfactory", sdk.NewAttribute("configure_minter_controller", contractAddr.String()))}, nil, nil
}

func (m *CustomMessenger) removeMinterController(ctx sdk.Context, _ sdk.AccAddress, custMsg *bindings.RemoveMinterController, isTF bool) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	// this is to prevent wrong function call
	if custMsg == nil {
		return events, data, msgResponses, wasmvmtypes.InvalidRequest{Err: NullCustomMessageError}
	}

	if isTF {
		msgServer := tokenfactorymodulekeeper.NewMsgServerImpl(m.Tf)

		msg := tokenfactorymoduletypes.NewMsgRemoveMinterController(custMsg.Signer, custMsg.Controller, custMsg.Minter)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic tf MsgRemoveMinterController")
		}

		//_, err := msgServer.RemoveMinterController(ctx.Context(), msg)
		//_, err := msgServer.RemoveMinterController(ctx, msg) // this is the correct one
		_, err := msgServer.RemoveMinterController(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to remove tf minter controller")
		}
	}
	return events, data, msgResponses, nil

	// TODO: is it beneficial to add an event here?
	//return []sdk.Event{sdk.NewEvent("tokenfactory", sdk.NewAttribute("remove_minter_controller", contractAddr.String()))}, nil, nil
}

func (m *CustomMessenger) configureMinter(ctx sdk.Context, _ sdk.AccAddress, custMsg *bindings.ConfigureMinter, isTF bool) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	// this is to prevent wrong function call
	if custMsg == nil {
		return events, data, msgResponses, wasmvmtypes.InvalidRequest{Err: NullCustomMessageError}
	}

	if isTF {
		msgServer := tokenfactorymodulekeeper.NewMsgServerImpl(m.Tf)

		//vInt, ok := sdkmath.NewIntFromString(custMsg.AllowanceValue)
		//if !ok {
		//	return events, data, msgResponses, errors.New("failed to parse allowance")
		//}
		//msg := tokenfactorymoduletypes.NewMsgConfigureMinter(custMsg.Signer, custMsg.Address, sdk.NewCoin(custMsg.AllowanceDenom, vInt))
		msg := tokenfactorymoduletypes.NewMsgConfigureMinter(custMsg.Signer, custMsg.Address, custMsg.Allowance)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating tf basic MsgConfigureMinter")
		}

		_, err := msgServer.ConfigureMinter(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to configure tf minter")
		}
	}
	return events, data, msgResponses, nil

	// TODO: is it beneficial to add an event here?
	//return []sdk.Event{sdk.NewEvent("tokenfactory", sdk.NewAttribute("configure_minter", contractAddr.String()))}, nil, nil
}

func (m *CustomMessenger) removeMinter(ctx sdk.Context, _ sdk.AccAddress, custMsg *bindings.RemoveMinter, isTF bool) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	// this is to prevent wrong function call
	if custMsg == nil {
		return events, data, msgResponses, wasmvmtypes.InvalidRequest{Err: NullCustomMessageError}
	}

	if isTF {
		msgServer := tokenfactorymodulekeeper.NewMsgServerImpl(m.Tf)

		msg := tokenfactorymoduletypes.NewMsgRemoveMinter(custMsg.Signer, custMsg.Address, custMsg.Denom)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic tf MsgRemoveMinter")
		}

		_, err := msgServer.RemoveMinter(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to remove tf minter")
		}
	}
	return events, data, msgResponses, nil

	// TODO: is it beneficial to add an event here?
	//return []sdk.Event{sdk.NewEvent("tokenfactory", sdk.NewAttribute("remove_minter", contractAddr.String()))}, nil, nil
}

func (m *CustomMessenger) updateBlacklister(ctx sdk.Context, _ sdk.AccAddress, custMsg *bindings.UpdateBlacklister, isTF bool) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	// this is to prevent wrong function call
	if custMsg == nil {
		return events, data, msgResponses, wasmvmtypes.InvalidRequest{Err: NullCustomMessageError}
	}

	if isTF {
		msgServer := tokenfactorymodulekeeper.NewMsgServerImpl(m.Tf)

		msg := tokenfactorymoduletypes.NewMsgUpdateBlacklister(custMsg.Signer, custMsg.Address)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic tf MsgUpdateBlacklister")
		}

		_, err := msgServer.UpdateBlacklister(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to update tf blacklister")
		}
	}
	return events, data, msgResponses, nil

	// TODO: is it beneficial to add an event here?
	//return []sdk.Event{sdk.NewEvent("tokenfactory", sdk.NewAttribute("update_blacklister", contractAddr.String()))}, nil, nil
}

func (m *CustomMessenger) blacklist(ctx sdk.Context, _ sdk.AccAddress, custMsg *bindings.Blacklist, isTF bool) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	// this is to prevent wrong function call
	if custMsg == nil {
		return events, data, msgResponses, wasmvmtypes.InvalidRequest{Err: NullCustomMessageError}
	}

	if isTF {
		msgServer := tokenfactorymodulekeeper.NewMsgServerImpl(m.Tf)

		msg := tokenfactorymoduletypes.NewMsgBlacklist(custMsg.Signer, custMsg.Address)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic tf MsgBlacklist")
		}

		_, err := msgServer.Blacklist(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to blacklist tf")
		}
	}
	return events, data, msgResponses, nil

	// TODO: is it beneficial to add an event here?
	//return []sdk.Event{sdk.NewEvent("tokenfactory", sdk.NewAttribute("blacklist", contractAddr.String()))}, nil, nil
}

func (m *CustomMessenger) unblacklist(ctx sdk.Context, _ sdk.AccAddress, custMsg *bindings.Unblacklist, isTF bool) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	// this is to prevent wrong function call
	if custMsg == nil {
		return events, data, msgResponses, wasmvmtypes.InvalidRequest{Err: NullCustomMessageError}
	}

	if isTF {
		msgServer := tokenfactorymodulekeeper.NewMsgServerImpl(m.Tf)

		msg := tokenfactorymoduletypes.NewMsgUnblacklist(custMsg.Signer, custMsg.Address)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic tf MsgUnblacklist")
		}

		_, err := msgServer.Unblacklist(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to unblacklist tf")
		}
	}
	return events, data, msgResponses, nil

	// TODO: is it beneficial to add an event here?
	//return []sdk.Event{sdk.NewEvent("tokenfactory", sdk.NewAttribute("unblacklist", contractAddr.String()))}, nil, nil
}

func (m *CustomMessenger) updatePauser(ctx sdk.Context, _ sdk.AccAddress, custMsg *bindings.UpdatePauser, isTF bool) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	// this is to prevent wrong function call
	if custMsg == nil {
		return events, data, msgResponses, wasmvmtypes.InvalidRequest{Err: NullCustomMessageError}
	}

	if isTF {
		msgServer := tokenfactorymodulekeeper.NewMsgServerImpl(m.Tf)

		msg := tokenfactorymoduletypes.NewMsgUpdatePauser(custMsg.Signer, custMsg.Address)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic tf MsgUpdatePauser")
		}

		_, err := msgServer.UpdatePauser(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to update tf pauser")
		}
	}
	return events, data, msgResponses, nil

	// TODO: is it beneficial to add an event here?
	//return []sdk.Event{sdk.NewEvent("tokenfactory", sdk.NewAttribute("update_pauser", contractAddr.String()))}, nil, nil
}

func (m *CustomMessenger) pause(ctx sdk.Context, _ sdk.AccAddress, custMsg *bindings.Pause, isTF bool) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	// this is to prevent wrong function call
	if custMsg == nil {
		return events, data, msgResponses, wasmvmtypes.InvalidRequest{Err: NullCustomMessageError}
	}

	if isTF {
		msgServer := tokenfactorymodulekeeper.NewMsgServerImpl(m.Tf)

		msg := tokenfactorymoduletypes.NewMsgPause(custMsg.Signer)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic tf MsgPause")
		}

		_, err := msgServer.Pause(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to pause tf")
		}
	}
	return events, data, msgResponses, nil

	// TODO: is it beneficial to add an event here?
	//return []sdk.Event{sdk.NewEvent("tokenfactory", sdk.NewAttribute("pause", contractAddr.String()))}, nil, nil
}

func (m *CustomMessenger) unpause(ctx sdk.Context, _ sdk.AccAddress, custMsg *bindings.Unpause, isTF bool) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	// this is to prevent wrong function call
	if custMsg == nil {
		return events, data, msgResponses, wasmvmtypes.InvalidRequest{Err: NullCustomMessageError}
	}

	if isTF {
		msgServer := tokenfactorymodulekeeper.NewMsgServerImpl(m.Tf)

		msg := tokenfactorymoduletypes.NewMsgUnpause(custMsg.Signer)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic tf MsgUnpause")
		}

		_, err := msgServer.Unpause(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to unpause tf")
		}
	}
	return events, data, msgResponses, nil

	// TODO: is it beneficial to add an event here?
	//return []sdk.Event{sdk.NewEvent("tokenfactory", sdk.NewAttribute("unpause", contractAddr.String()))}, nil, nil
}

func (m *CustomMessenger) mint(ctx sdk.Context, _ sdk.AccAddress, custMsg *bindings.Mint, isTF bool) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	// this is to prevent wrong function call
	if custMsg == nil {
		return events, data, msgResponses, wasmvmtypes.InvalidRequest{Err: NullCustomMessageError}
	}

	if isTF {
		msgServer := tokenfactorymodulekeeper.NewMsgServerImpl(m.Tf)

		//vInt := sdkmath.NewIntFromUint64(custMsg.Value)
		//msg := tokenfactorymoduletypes.NewMsgMint(custMsg.Signer, custMsg.Address, sdk.NewCoin(custMsg.Denom, vInt))
		msg := tokenfactorymoduletypes.NewMsgMint(custMsg.Signer, custMsg.Address, custMsg.Amount)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic tf MsgMint")
		}

		_, err := msgServer.Mint(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to mint tf")
		}
	}
	return events, data, msgResponses, nil

	// TODO: is it beneficial to add an event here?
	//return []sdk.Event{sdk.NewEvent("tokenfactory", sdk.NewAttribute("mint", contractAddr.String()))}, nil, nil
}

func (m *CustomMessenger) burn(ctx sdk.Context, _ sdk.AccAddress, custMsg *bindings.Burn, isTF bool) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	// this is to prevent wrong function call
	if custMsg == nil {
		return events, data, msgResponses, wasmvmtypes.InvalidRequest{Err: NullCustomMessageError}
	}

	if isTF {
		msgServer := tokenfactorymodulekeeper.NewMsgServerImpl(m.Tf)

		//vInt := sdkmath.NewIntFromUint64(custMsg.Value)
		//msg := tokenfactorymoduletypes.NewMsgBurn(custMsg.Signer, sdk.NewCoin(custMsg.Denom, vInt))
		msg := tokenfactorymoduletypes.NewMsgBurn(custMsg.Signer, custMsg.Amount)

		if err := msg.ValidateBasic(); err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic tf MsgBurn")
		}

		_, err := msgServer.Burn(sdk.WrapSDKContext(ctx), msg)

		if err != nil {
			return events, data, msgResponses, errorsmod.Wrap(err, "failed to burn tf")
		}
	}
	return events, data, msgResponses, nil

	// TODO: is it beneficial to add an event here?
	//return []sdk.Event{sdk.NewEvent("tokenfactory", sdk.NewAttribute("burn", contractAddr.String()))}, nil, nil
}

func (m *CustomMessenger) setDenomMetadata(ctx sdk.Context, _ sdk.AccAddress, custMsg *bindings.SetDenomMetadata) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	// this is to prevent wrong function call
	if custMsg == nil {
		return events, data, msgResponses, wasmvmtypes.InvalidRequest{Err: NullCustomMessageError}
	}

	msgServer := tokenfactorymodulekeeper.NewMsgServerImpl(m.Tf)

	msg := tokenfactorymoduletypes.NewMsgSetDenomMedata(custMsg.Signer, custMsg.Metadata)

	if err := msg.ValidateBasic(); err != nil {
		return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic tf MsgSetDenomMedata")
	}

	_, err = msgServer.SetDenomMetadata(sdk.WrapSDKContext(ctx), msg)

	if err != nil {
		return events, data, msgResponses, errorsmod.Wrap(err, "failed to burn tf")
	}
	return events, data, msgResponses, nil

	// TODO: is it beneficial to add an event here?
	//return []sdk.Event{sdk.NewEvent("tokenfactory", sdk.NewAttribute("burn", contractAddr.String()))}, nil, nil
}

func (m *CustomMessenger) grantFeeBasicAllowance(ctx sdk.Context, _ sdk.AccAddress, custMsg *bindings.GrantFeeBasicAllowance) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	// this is to prevent wrong function call
	if custMsg == nil {
		return events, data, msgResponses, wasmvmtypes.InvalidRequest{Err: NullCustomMessageError}
	}

	msgServer := feegrantkeeper.NewMsgServerImpl(*m.Feegrant)

	granter, err := sdk.AccAddressFromBech32(custMsg.Granter)
	if err != nil {
		return events, data, msgResponses, errorsmod.Wrap(err, FailedToParseGranterAddressError)
	}

	grantee, err := sdk.AccAddressFromBech32(custMsg.Grantee)
	if err != nil {
		return events, data, msgResponses, errorsmod.Wrap(err, FailedToParseGranterAddressError)
	}

	expiration := ctx.BlockTime().UTC().Add(time.Duration(int64(time.Hour) * int64(custMsg.HoursToExpire)))
	//expiration := time.Now().UTC().Add(time.Duration(int64(time.Hour) * int64(custMsg.HoursToExpire)))

	allowance := feegrant.BasicAllowance{
		//SpendLimit: sdk.NewCoins(sdk.NewCoin(custMsg.AllowanceDenom, math.NewIntFromUint64(custMsg.AllowanceValue))),
		SpendLimit: sdk.NewCoins(custMsg.Allowance),
		Expiration: &expiration,
	}

	msg, err := feegrant.NewMsgGrantAllowance(&allowance, granter, grantee)
	if err != nil {
		return events, data, msgResponses, errorsmod.Wrap(err, "failed to create MsgGrantAllowance")
	}

	// if err := msg.ValidateBasic(); err != nil {
	// 	return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic MsgGrantFeeAllowance")
	// }

	_, err = msgServer.GrantAllowance(sdk.WrapSDKContext(ctx), msg)

	if err != nil {
		return events, data, msgResponses, errorsmod.Wrap(err, "failed to grant fee allowance")
	}

	return events, data, msgResponses, nil
}

func (m *CustomMessenger) revokeFeeAllowance(ctx sdk.Context, _ sdk.AccAddress, custMsg *bindings.RevokeFeeAllowance) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	// this is to prevent wrong function call
	if custMsg == nil {
		return events, data, msgResponses, wasmvmtypes.InvalidRequest{Err: NullCustomMessageError}
	}

	msgServer := feegrantkeeper.NewMsgServerImpl(*m.Feegrant)

	granter, err := sdk.AccAddressFromBech32(custMsg.Granter)
	if err != nil {
		return events, data, msgResponses, errorsmod.Wrap(err, FailedToParseGranterAddressError)
	}

	grantee, err := sdk.AccAddressFromBech32(custMsg.Grantee)
	if err != nil {
		return events, data, msgResponses, errorsmod.Wrap(err, FailedToParseGranterAddressError)
	}

	msg := feegrant.NewMsgRevokeAllowance(granter, grantee)
	//msg := feegranttypes.NewMsgRevokeAllowance(sdk.AccAddress(custMsg.Granter), sdk.AccAddress(custMsg.Grantee))

	// if err := msg.ValidateBasic(); err != nil {
	// 	return events, data, msgResponses, errorsmod.Wrap(err, "failed validating basic MsgRevokeAllowance")
	// }

	_, err = msgServer.RevokeAllowance(sdk.WrapSDKContext(ctx), &msg)

	if err != nil {
		return events, data, msgResponses, errorsmod.Wrap(err, "failed to revoke fee allowance")
	}

	return events, data, msgResponses, nil
}
