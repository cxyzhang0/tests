package tokenfactory_test

import (
	"testing"

	feegrantkeeper "cosmossdk.io/x/feegrant/keeper"
	wasmkeeper "github.com/CosmWasm/wasmd/x/wasm/keeper"
	bankkeeper "github.com/cosmos/cosmos-sdk/x/bank/keeper"
	"github.com/stretchr/testify/assert"
	"github.com/wfblockchain/coreblockchain/v2/x/contracts/tokenfactory"
	tokenfactorymodulekeeper "github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/keeper"
)

type MockWasmQueryPlugin struct{}

func (m *MockWasmQueryPlugin) Query(_ []byte) ([]byte, error) {
	return []byte("mocked response"), nil
}

type MockCustomQuerier struct{}

func (m *MockCustomQuerier) CustomQuery() string {
	return "custom query result"
}

func TestRegisterCustomPlugins(t *testing.T) {
	tf := &tokenfactorymodulekeeper.Keeper{}
	//ftf := &fiattokenfactorymodulekeeper.Keeper{}
	bank := &bankkeeper.BaseKeeper{}
	feegrant := &feegrantkeeper.Keeper{}
	pluginOptions := tokenfactory.RegisterCustomPlugins(tf, bank, feegrant)
	assert.Len(t, pluginOptions, 2, "Should return 2 options")
	assert.Implements(t, (*wasmkeeper.Option)(nil), pluginOptions[0], "The first plugin option should implement wasmkeeper.Option interface")
	assert.Implements(t, (*wasmkeeper.Option)(nil), pluginOptions[1], "The second plugin option should implement wasmkeeper.Option interface")
}
