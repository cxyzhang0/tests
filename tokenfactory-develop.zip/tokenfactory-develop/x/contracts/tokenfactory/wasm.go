package tokenfactory

import (
	feegrantkeeper "cosmossdk.io/x/feegrant/keeper"
	wasmkeeper "github.com/CosmWasm/wasmd/x/wasm/keeper"
	bankkeeper "github.com/cosmos/cosmos-sdk/x/bank/keeper"
	tokenfactorymodulekeeper "github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/keeper"
)

func RegisterCustomPlugins(
	tf *tokenfactorymodulekeeper.Keeper,
	bank *bankkeeper.BaseKeeper,
	feegrant *feegrantkeeper.Keeper,
) []wasmkeeper.Option {
	wasmQueryPlugin := NewQueryPlugin(tf, bank, feegrant)

	queryPluginOpt := wasmkeeper.WithQueryPlugins(&wasmkeeper.QueryPlugins{
		Custom: CustomQuerier(wasmQueryPlugin),
	})

	messengerDecoratorOpt := wasmkeeper.WithMessageHandlerDecorator(
		CustomMessagerDecorator(tf, feegrant),
	)

	return []wasmkeeper.Option{
		queryPluginOpt,
		messengerDecoratorOpt,
	}
}
