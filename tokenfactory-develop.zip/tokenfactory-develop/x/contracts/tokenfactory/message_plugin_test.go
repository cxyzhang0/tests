package tokenfactory_test

import (
	"encoding/json"
	"testing"
	"time"

	logs "log"

	"cosmossdk.io/math"
	"cosmossdk.io/store"
	"cosmossdk.io/store/metrics"
	storetypes "cosmossdk.io/store/types"
	wasmvmtypes "github.com/CosmWasm/wasmvm/v2/types"
	tmproto "github.com/cometbft/cometbft/proto/tendermint/types"
	dbm "github.com/cosmos/cosmos-db"
	"github.com/cosmos/cosmos-sdk/codec"
	codectypes "github.com/cosmos/cosmos-sdk/codec/types"
	"github.com/cosmos/cosmos-sdk/runtime"
	sdk "github.com/cosmos/cosmos-sdk/types"
	authtypes "github.com/cosmos/cosmos-sdk/x/auth/types"
	banktypes "github.com/cosmos/cosmos-sdk/x/bank/types"
	paramtypes "github.com/cosmos/cosmos-sdk/x/params/types"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"
	"github.com/wfblockchain/coreblockchain/v2/testutil/sample"
	"github.com/wfblockchain/coreblockchain/v2/x/contracts/tokenfactory/bindings"

	"cosmossdk.io/log"
	feegrant "cosmossdk.io/x/feegrant"
	feegrantkeeper "cosmossdk.io/x/feegrant/keeper"
	"github.com/wfblockchain/coreblockchain/v2/x/contracts/tokenfactory"
	tokenfactorymodulekeeper "github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/keeper"
	tokenfactorymoduletypes "github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"
)

type MockMessenger struct {
	mock.Mock
}

func (m *MockMessenger) DispatchMsg(ctx sdk.Context, contractAddr sdk.AccAddress, contractIBCPortID string, msg wasmvmtypes.CosmosMsg) (events []sdk.Event, data [][]byte, msgResponses [][]*codectypes.Any, err error) {
	args := m.Called(ctx, contractAddr, contractIBCPortID, msg)
	return args.Get(0).([]sdk.Event), args.Get(1).([][]byte), args.Get(2).([][]*codectypes.Any), args.Error(3)
}

type MsgUpdateMasterMinter struct {
	From    string `protobuf:"bytes,1,opt,name=from,proto3" json:"from,omitempty"`
	Address string `protobuf:"bytes,2,opt,name=address,proto3" json:"address,omitempty"`
}

type TokenFactoryMessages struct {
	UpdateMasterMinter *MsgUpdateMasterMinter `json:"update_master_minter,omitempty"`
}

func (m *MockMessenger) updateMasterMinter(ctx sdk.Context, contractAddr sdk.AccAddress, msg interface{}, tf bool) ([]sdk.Event, [][]byte, [][]*codectypes.Any, error) {
	args := m.Called(ctx, contractAddr, msg, tf)
	return args.Get(0).([]sdk.Event), args.Get(1).([][]byte), args.Get(2).([][]*codectypes.Any), args.Error(3)
}

func TestCustomMessagerDecorator(t *testing.T) {
	tf := &tokenfactorymodulekeeper.Keeper{}
	feegrant := &feegrantkeeper.Keeper{}

	mockMsg := &MockMessenger{}

	decoratedFunc := tokenfactory.CustomMessagerDecorator(tf, feegrant)
	wrappedMessenger := decoratedFunc(mockMsg)

	customMessenger, ok := wrappedMessenger.(*tokenfactory.CustomMessenger)
	require.True(t, ok, "Expected wrapped messenger to be of type *CustomMessenger")

	require.Equal(t, tf, customMessenger.Tf, "TokenFactory keeper not set correctly")
	require.Equal(t, feegrant, customMessenger.Feegrant, "Feegrant keeper not set correctly")
	require.Equal(t, mockMsg, customMessenger.Wrapped, "Wrapped messenger not set correctly")
}

func TestUpdateMasterMinter(t *testing.T) {
	mockMessenger := new(MockMessenger)
	ctx := sdk.Context{}
	contractAddr := sdk.AccAddress([]byte("someContractAddr"))
	msg := MsgUpdateMasterMinter{
		From:    "senderAddress",
		Address: "newMasterMinterAddress",
	}
	tf := true

	mockMessenger.On("updateMasterMinter", ctx, contractAddr, msg, tf).Return([]sdk.Event{}, [][]byte{}, [][]*codectypes.Any{}, nil)
	events, bytes, any, err := mockMessenger.updateMasterMinter(ctx, contractAddr, msg, tf)

	assert.NoError(t, err)
	assert.Len(t, events, 0)
	assert.Len(t, bytes, 0)
	assert.Len(t, any, 0)

	mockMessenger.AssertExpectations(t)
}

type FactoryMsg struct {
	TF *TokenFactoryMessages `json:"tf,omitempty"`
}

type UpdateMasterMinterMsg struct {
	MasterMinterAddress string `json:"master_minter_address"`
}

func TestDispatchMsg(t *testing.T) {
	ctx := sdk.Context{}
	contractAddr := sdk.AccAddress("contractAddr")
	contractIBCPortID := "portID"

	mockWrapped := new(MockMessenger)
	messenger := tokenfactory.CustomMessenger{Wrapped: mockWrapped}

	msg := wasmvmtypes.CosmosMsg{}
	mockWrapped.On("DispatchMsg", ctx, contractAddr, contractIBCPortID, msg).Return([]sdk.Event{}, [][]byte{}, [][]*codectypes.Any{}, nil)

	events, data, msgResponses, err := messenger.DispatchMsg(ctx, contractAddr, contractIBCPortID, msg)
	assert.NoError(t, err)
	assert.Empty(t, events)
	assert.Empty(t, data)
	assert.Empty(t, msgResponses)

	invalidMsg := wasmvmtypes.CosmosMsg{Custom: []byte("{invalid_json}")}
	events, data, msgResponses, err = messenger.DispatchMsg(ctx, contractAddr, contractIBCPortID, invalidMsg)
	assert.Error(t, err)
	assert.Contains(t, err.Error(), "failed to decode custom bindings msg")
	assert.Empty(t, events)
	assert.Empty(t, data)
	assert.Empty(t, msgResponses)

	validMsg := wasmvmtypes.CosmosMsg{
		Custom: []byte(`{
			"TF": {
				"UpdateMasterMinter": {"field": "value"}
			},
			"FTF": {
				"UpdateMasterMinter": {"field": "value"}
			}
		}`),
	}

	mockWrapped.On("DispatchMsg", ctx, contractAddr, contractIBCPortID, validMsg).Return([]sdk.Event{}, [][]byte{}, [][]*codectypes.Any{}, nil)

	events, data, msgResponses, err = messenger.DispatchMsg(ctx, contractAddr, contractIBCPortID, validMsg)
	assert.NoError(t, err)
	assert.Empty(t, events)
	assert.Empty(t, data)
	assert.Empty(t, msgResponses)

}

type MockMsgServerImpl struct {
	mock.Mock
}

type MockMsgServerImplFTF struct {
	mock.Mock
}

func TestDispatchMsg_TFUpdateMasterMinter(t *testing.T) {
	// Setup store
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(tokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)
	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	// Setup keeper
	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())
	var ps paramtypes.Subspace
	var tfbankKeeper tokenfactorymoduletypes.BankKeeper

	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper, runtime.NewKVStoreService(storeKey))

	// Setup test data
	ownerAddr := sample.AccAddress()
	owner := tokenfactorymoduletypes.Owner{Address: ownerAddr}
	tf.SetOwner(ctx, owner)

	oldMasterMinter := sample.AccAddress()
	tf.SetMasterMinter(ctx, tokenfactorymoduletypes.MasterMinter{Address: oldMasterMinter})

	newMasterMinter := sample.AccAddress()

	logs.Printf("Owner Address: %s", ownerAddr)
	logs.Printf("Old MasterMinter Address: %s", oldMasterMinter)
	logs.Printf("New MasterMinter Address: %s", newMasterMinter)

	// Create the CustomMessenger with a mock wrapped messenger
	mockWrapped := new(MockMessenger)
	customMessenger := &tokenfactory.CustomMessenger{
		Wrapped:  mockWrapped,
		Tf:       tf,
		Feegrant: nil, // Not needed for this test
	}

	contractAddr := sdk.AccAddress([]byte("contract_address"))

	// Create the update master minter message
	updateMinterMsg := bindings.FactoryMsg{
		TF: &bindings.TokenfactoryMsg{
			UpdateMasterMinter: &bindings.UpdateMasterMinter{
				Signer:  ownerAddr,
				Address: newMasterMinter,
			},
		},
	}

	msgBytes, err := json.Marshal(updateMinterMsg)
	require.NoError(t, err)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: msgBytes,
	}

	// Execute the actual DispatchMsg which should call updateMasterMinter
	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)

	// Verify no error occurred
	require.NoError(t, err)
	require.Empty(t, events)
	require.Empty(t, data)
	require.Empty(t, msgResponses)

	// Verify that the master minter was actually updated
	updatedMasterMinter, found := tf.GetMasterMinter(ctx)
	require.True(t, found, "MasterMinter should be found after update")
	require.Equal(t, newMasterMinter, updatedMasterMinter.Address, "MasterMinter should be updated to new address")
}

func TestDispatchMsg_TFConfigureMinterController(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(tokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	ownerAddr := sample.AccAddress()

	owner := tokenfactorymoduletypes.Owner{Address: ownerAddr}

	var ps paramtypes.Subspace
	var tfbankKeeper tokenfactorymoduletypes.BankKeeper

	contractAddr := sdk.AccAddress([]byte("contract_address"))
	mockMessenger := new(MockMessenger)

	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper, runtime.NewKVStoreService(storeKey))
	tf.SetOwner(ctx, owner)
	masterminter := sample.AccAddress()
	mintercontroller := sample.AccAddress()
	minter := sample.AccAddress()
	tf.SetMasterMinter(ctx, tokenfactorymoduletypes.MasterMinter{Address: masterminter})

	tf.SetMinterController(ctx, tokenfactorymoduletypes.MinterController{Minter: mintercontroller, Controller: mintercontroller})

	tf.SetMinters(ctx, tokenfactorymoduletypes.Minters{Address: minter})

	configureMinterControllerMsg := bindings.FactoryMsg{
		TF: &bindings.TokenfactoryMsg{
			ConfigureMinterController: &bindings.ConfigureMinterController{
				Signer:     masterminter,
				Controller: mintercontroller,
				Minter:     minter,
			},
		},
	}

	customMessenger := &tokenfactory.CustomMessenger{
		Tf: tf,
	}

	tfMsgBytes, err := json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)

}

func TestDispatchMsg_TFRemoveMinterController(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(tokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)
	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	require.NoError(t, ms.LoadLatestVersion())

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())
	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace
	var tfbankKeeper tokenfactorymoduletypes.BankKeeper
	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper, runtime.NewKVStoreService(storeKey))

	masterMinter := sample.AccAddress()
	minter := sample.AccAddress()
	tf.SetMasterMinter(ctx, tokenfactorymoduletypes.MasterMinter{Address: masterMinter})
	tf.SetMinterController(ctx, tokenfactorymoduletypes.MinterController{
		Minter:     minter,
		Controller: minter,
	})

	customMessenger := &tokenfactory.CustomMessenger{
		Tf: tf,
	}

	removeMsg := bindings.FactoryMsg{
		TF: &bindings.TokenfactoryMsg{
			RemoveMinterController: &bindings.RemoveMinterController{
				Signer:     masterMinter,
				Controller: minter,
				Minter:     minter,
			},
		},
	}

	msgBytes, err := json.Marshal(removeMsg)
	require.NoError(t, err)

	cosmosMsg := wasmvmtypes.CosmosMsg{Custom: msgBytes}
	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, sdk.AccAddress("contract"), "ibc-port", cosmosMsg)

	require.NoError(t, err)
	require.Empty(t, events)
	require.Empty(t, data)
	require.Empty(t, msgResponses)

	_, found := tf.GetMinterController(ctx, minter, minter)
	require.False(t, found, "minter controller should be removed")
}

func TestDispatchMsg_TFConfigureMinter(t *testing.T) {
	// Setup store
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(tokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)
	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	require.NoError(t, ms.LoadLatestVersion())

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	// Setup keeper
	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())
	var ps paramtypes.Subspace
	var tfbankKeeper tokenfactorymoduletypes.BankKeeper = &MockBankKeeper{}
	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper, runtime.NewKVStoreService(storeKey))

	// Setup test data
	ownerAddr := sample.AccAddress()
	tf.SetOwner(ctx, tokenfactorymoduletypes.Owner{Address: ownerAddr})

	masterMinter := sample.AccAddress()
	minter := sample.AccAddress()

	tf.SetMasterMinter(ctx, tokenfactorymoduletypes.MasterMinter{Address: masterMinter})
	tf.SetMinterController(ctx, tokenfactorymoduletypes.MinterController{
		Minter:     minter,
		Controller: masterMinter,
	})
	tf.SetMintingDenom(ctx, tokenfactorymoduletypes.MintingDenom{Denom: "stake"})

	customMessenger := &tokenfactory.CustomMessenger{
		Tf: tf,
	}

	// Build configure minter message
	configureMinterMsg := bindings.FactoryMsg{
		TF: &bindings.TokenfactoryMsg{
			ConfigureMinter: &bindings.ConfigureMinter{
				Signer:    masterMinter,
				Address:   minter,
				Allowance: sdk.NewCoin("stake", math.NewInt(100)),
			},
		},
	}

	msgBytes, err := json.Marshal(configureMinterMsg)
	require.NoError(t, err)

	cosmosMsg := wasmvmtypes.CosmosMsg{Custom: msgBytes}
	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, sdk.AccAddress("contract"), "ibc-port", cosmosMsg)

	require.NoError(t, err)
	require.Empty(t, events)
	require.Empty(t, data)
	require.Empty(t, msgResponses)

	_, found := tf.GetMinters(ctx, minter, "stake")
	require.True(t, found, "minter should be configured")
}

func TestDispatchMsg_TFRemoveMinter(t *testing.T) {
	// Setup store
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(tokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)
	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	require.NoError(t, ms.LoadLatestVersion())

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	// Setup keeper
	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())
	var ps paramtypes.Subspace
	var tfbankKeeper tokenfactorymoduletypes.BankKeeper = &MockBankKeeper{}
	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper, runtime.NewKVStoreService(storeKey))

	// Setup test data
	ownerAddr := sample.AccAddress()
	tf.SetOwner(ctx, tokenfactorymoduletypes.Owner{Address: ownerAddr})

	minter := sample.AccAddress()
	minterController := minter

	tf.SetMasterMinter(ctx, tokenfactorymoduletypes.MasterMinter{Address: minter})
	tf.SetMinterController(ctx, tokenfactorymoduletypes.MinterController{
		Minter:     minter,
		Controller: minterController,
	})
	tf.SetMintingDenom(ctx, tokenfactorymoduletypes.MintingDenom{Denom: "stake"})

	// Configure minter first so we can remove it
	tf.SetMinters(ctx, tokenfactorymoduletypes.Minters{
		Address:   minter,
		Allowance: sdk.NewCoin("stake", math.NewInt(100)),
	})

	customMessenger := &tokenfactory.CustomMessenger{
		Tf: tf,
	}

	// Build remove minter message
	removeMinterMsg := bindings.FactoryMsg{
		TF: &bindings.TokenfactoryMsg{
			RemoveMinter: &bindings.RemoveMinter{
				Signer:  minter,
				Address: minter,
				Denom:   "stake",
			},
		},
	}

	msgBytes, err := json.Marshal(removeMinterMsg)
	require.NoError(t, err)

	cosmosMsg := wasmvmtypes.CosmosMsg{Custom: msgBytes}
	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, sdk.AccAddress("contract"), "ibc-port", cosmosMsg)

	require.NoError(t, err)
	require.Empty(t, events)
	require.Empty(t, data)
	require.Empty(t, msgResponses)

	_, found := tf.GetMinters(ctx, minter, "stake")
	require.False(t, found, "minter should be removed")
}

func TestDispatchMsg_TFUpdateBlacklister(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(tokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace
	var tfbankKeeper tokenfactorymoduletypes.BankKeeper

	contractAddr := sdk.AccAddress([]byte("contract_address"))
	mockMessenger := new(MockMessenger)
	ownerAddr := sample.AccAddress()
	blacklister := sample.AccAddress()
	owner := tokenfactorymoduletypes.Owner{Address: ownerAddr}
	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper, runtime.NewKVStoreService(storeKey))

	tf.SetOwner(ctx, owner)

	configureMinterControllerMsg := bindings.FactoryMsg{
		TF: &bindings.TokenfactoryMsg{
			UpdateBlacklister: &bindings.UpdateBlacklister{
				Signer:  ownerAddr,
				Address: blacklister,
			},
		},
	}

	customMessenger := &tokenfactory.CustomMessenger{
		Tf: tf,
	}

	tfMsgBytes, err := json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)
}

func TestDispatchMsg_TFBlacklist(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(tokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace
	var tfbankKeeper tokenfactorymoduletypes.BankKeeper

	contractAddr := sdk.AccAddress([]byte("contract_address"))
	mockMessenger := new(MockMessenger)

	blacklister := sample.AccAddress()

	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper, runtime.NewKVStoreService(storeKey))
	tf.SetBlacklister(ctx, tokenfactorymoduletypes.Blacklister{Address: blacklister})
	blacklist := sample.AccAddress()

	configureMinterControllerMsg := bindings.FactoryMsg{
		TF: &bindings.TokenfactoryMsg{
			Blacklist: &bindings.Blacklist{
				Signer:  blacklister,
				Address: blacklist,
			},
		},
	}

	customMessenger := &tokenfactory.CustomMessenger{
		Tf: tf,
	}

	tfMsgBytes, err := json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)

}

func TestDispatchMsg_TFUnblacklist(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(tokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace
	var tfbankKeeper tokenfactorymoduletypes.BankKeeper

	contractAddr := sdk.AccAddress([]byte("contract_address"))
	mockMessenger := new(MockMessenger)

	blacklister := sample.AccAddress()

	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper, runtime.NewKVStoreService(storeKey))
	tf.SetBlacklister(ctx, tokenfactorymoduletypes.Blacklister{Address: blacklister})
	blacklist := sample.AccAddress()

	configureMinterControllerMsg := bindings.FactoryMsg{
		TF: &bindings.TokenfactoryMsg{
			Blacklist: &bindings.Blacklist{
				Signer:  blacklister,
				Address: blacklist,
			},
		},
	}

	customMessenger := &tokenfactory.CustomMessenger{
		Tf: tf,
	}

	tfMsgBytes, err := json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)

	configureMinterControllerMsg = bindings.FactoryMsg{
		TF: &bindings.TokenfactoryMsg{
			Unblacklist: &bindings.Unblacklist{
				Signer:  blacklister,
				Address: blacklist,
			},
		},
	}

	customMessenger = &tokenfactory.CustomMessenger{
		Tf: tf,
	}

	tfMsgBytes, err = json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents = []sdk.Event(nil)
	expectedData = [][]byte(nil)
	expectedMsgResponses = [][]*codectypes.Any(nil)

	cosmosMsg = wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err = customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)
}

func TestDispatchMsg_TFUpdatePauser(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(tokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace
	var tfbankKeeper tokenfactorymoduletypes.BankKeeper

	contractAddr := sdk.AccAddress([]byte("contract_address"))
	mockMessenger := new(MockMessenger)

	ownerAddr := sample.AccAddress()
	owner := tokenfactorymoduletypes.Owner{Address: ownerAddr}
	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper, runtime.NewKVStoreService(storeKey))
	pauser := sample.AccAddress()

	tf.SetOwner(ctx, owner)

	configureMinterControllerMsg := bindings.FactoryMsg{
		TF: &bindings.TokenfactoryMsg{
			UpdatePauser: &bindings.UpdatePauser{
				Signer:  ownerAddr,
				Address: pauser,
			},
		},
	}

	customMessenger := &tokenfactory.CustomMessenger{
		Tf: tf,
	}

	tfMsgBytes, err := json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)

}

func TestDispatchMsg_TFPause(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(tokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace
	var tfbankKeeper tokenfactorymoduletypes.BankKeeper

	contractAddr := sdk.AccAddress([]byte("contract_address"))
	mockMessenger := new(MockMessenger)
	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper, runtime.NewKVStoreService(storeKey))

	pauserAddr := sample.AccAddress()
	tf.SetPauser(ctx, tokenfactorymoduletypes.Pauser{Address: pauserAddr})

	configureMinterControllerMsg := bindings.FactoryMsg{
		TF: &bindings.TokenfactoryMsg{
			Pause: &bindings.Pause{
				Signer: pauserAddr,
			},
		},
	}

	customMessenger := &tokenfactory.CustomMessenger{
		Tf: tf,
	}

	tfMsgBytes, err := json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)

}

func TestDispatchMsg_TFUnpause(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(tokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace
	var tfbankKeeper tokenfactorymoduletypes.BankKeeper

	contractAddr := sdk.AccAddress([]byte("contract_address"))
	mockMessenger := new(MockMessenger)
	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper, runtime.NewKVStoreService(storeKey))

	pauserAddr := sample.AccAddress()
	tf.SetPauser(ctx, tokenfactorymoduletypes.Pauser{Address: pauserAddr})

	configureMinterControllerMsg := bindings.FactoryMsg{
		TF: &bindings.TokenfactoryMsg{
			Unpause: &bindings.Unpause{
				Signer: pauserAddr,
			},
		},
	}

	customMessenger := &tokenfactory.CustomMessenger{
		Tf: tf,
	}

	tfMsgBytes, err := json.Marshal(configureMinterControllerMsg)
	require.NoError(t, err)
	expectedEvents := []sdk.Event(nil)
	expectedData := [][]byte(nil)
	expectedMsgResponses := [][]*codectypes.Any(nil)

	cosmosMsg := wasmvmtypes.CosmosMsg{
		Custom: tfMsgBytes,
	}

	mockMessenger.On("DispatchMsg", ctx, contractAddr, "ibc-port", cosmosMsg).
		Return(expectedEvents, expectedData, expectedMsgResponses, nil)

	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, contractAddr, "ibc-port", cosmosMsg)
	require.NoError(t, err)
	require.Equal(t, expectedEvents, events)
	require.Equal(t, expectedData, data)
	require.Equal(t, expectedMsgResponses, msgResponses)
}

func TestDispatchMsg_TFMint(t *testing.T) {
	// Setup store
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(tokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)
	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	require.NoError(t, ms.LoadLatestVersion())

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	// Setup keeper
	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())
	var ps paramtypes.Subspace
	var tfbankKeeper tokenfactorymoduletypes.BankKeeper = &MockBankKeeper{}
	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper, runtime.NewKVStoreService(storeKey))

	// Setup test data
	minter := sample.AccAddress()
	recipient := sample.AccAddress()

	tf.SetMintingDenom(ctx, tokenfactorymoduletypes.MintingDenom{Denom: "stake"})
	tf.SetMinters(ctx, tokenfactorymoduletypes.Minters{
		Address:   minter,
		Allowance: sdk.NewCoin("stake", math.NewInt(1000)),
	})

	customMessenger := &tokenfactory.CustomMessenger{
		Tf: tf,
	}

	// Build mint message
	mintMsg := bindings.FactoryMsg{
		TF: &bindings.TokenfactoryMsg{
			Mint: &bindings.Mint{
				Signer:  minter,
				Address: recipient,
				Amount:  sdk.NewCoin("stake", math.NewInt(100)),
			},
		},
	}

	msgBytes, err := json.Marshal(mintMsg)
	require.NoError(t, err)

	cosmosMsg := wasmvmtypes.CosmosMsg{Custom: msgBytes}
	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, sdk.AccAddress("contract"), "ibc-port", cosmosMsg)

	require.NoError(t, err)
	require.Empty(t, events)
	require.Empty(t, data)
	require.Empty(t, msgResponses)
}

func TestDispatchMsg_TFBurn(t *testing.T) {
	// Setup store
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(tokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)
	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	require.NoError(t, ms.LoadLatestVersion())

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	// Setup keeper
	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())
	var ps paramtypes.Subspace
	var tfbankKeeper tokenfactorymoduletypes.BankKeeper = &MockBankKeeper{}
	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper, runtime.NewKVStoreService(storeKey))

	// Setup test data
	minter := sample.AccAddress()

	tf.SetMintingDenom(ctx, tokenfactorymoduletypes.MintingDenom{Denom: "stake"})
	tf.SetMinters(ctx, tokenfactorymoduletypes.Minters{
		Address:   minter,
		Allowance: sdk.NewCoin("stake", math.NewInt(1000)),
	})

	customMessenger := &tokenfactory.CustomMessenger{
		Tf: tf,
	}

	// Build burn message
	burnMsg := bindings.FactoryMsg{
		TF: &bindings.TokenfactoryMsg{
			Burn: &bindings.Burn{
				Signer: minter,
				Amount: sdk.NewCoin("stake", math.NewInt(100)),
			},
		},
	}

	msgBytes, err := json.Marshal(burnMsg)
	require.NoError(t, err)

	cosmosMsg := wasmvmtypes.CosmosMsg{Custom: msgBytes}
	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, sdk.AccAddress("contract"), "ibc-port", cosmosMsg)

	require.NoError(t, err)
	require.Empty(t, events)
	require.Empty(t, data)
	require.Empty(t, msgResponses)
}

func TestDispatchMsg_TFSetDenomMetadata(t *testing.T) {
	// Setup store
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(tokenfactorymoduletypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)
	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	require.NoError(t, ms.LoadLatestVersion())

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	// Setup keeper
	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())
	var ps paramtypes.Subspace
	var tfbankKeeper tokenfactorymoduletypes.BankKeeper = &MockBankKeeper{}
	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper, runtime.NewKVStoreService(storeKey))

	// Setup test data - master minter is the signer
	masterMinter := sample.AccAddress()
	tf.SetMasterMinter(ctx, tokenfactorymoduletypes.MasterMinter{Address: masterMinter})

	customMessenger := &tokenfactory.CustomMessenger{
		Tf: tf,
	}

	// Build set denom metadata message with master minter as signer
	metadata := banktypes.Metadata{
		Description: "Test token",
		DenomUnits: []*banktypes.DenomUnit{
			{Denom: "stake", Exponent: 0},
		},
		Base:    "stake",
		Display: "stake",
		Name:    "Stake",
		Symbol:  "STK",
	}

	setDenomMetadataMsg := bindings.FactoryMsg{
		TF: &bindings.TokenfactoryMsg{
			SetDenomMetadata: &bindings.SetDenomMetadata{
				Signer:   masterMinter, // Must be the master minter
				Metadata: metadata,
			},
		},
	}

	msgBytes, err := json.Marshal(setDenomMetadataMsg)
	require.NoError(t, err)

	cosmosMsg := wasmvmtypes.CosmosMsg{Custom: msgBytes}
	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, sdk.AccAddress("contract"), "ibc-port", cosmosMsg)

	require.NoError(t, err)
	require.Empty(t, events)
	require.Empty(t, data)
	require.Empty(t, msgResponses)
}

// testAddressCodec is a helper to satisfy the AddressCodec interface requirement for mocks
type testAddressCodec struct{}

func (testAddressCodec) StringToBytes(text string) ([]byte, error) {
	return sdk.AccAddressFromBech32(text)
}

func (testAddressCodec) BytesToString(bz []byte) (string, error) {
	return sdk.AccAddress(bz).String(), nil
}

func TestDispatchMsg_FeegrantGrantFeeBasicAllowance(t *testing.T) {
	// Setup store
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(feegrant.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)
	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	require.NoError(t, ms.LoadLatestVersion())

	// FIX: Use a current BlockTime to ensure expiration dates are valid (post-1970)
	ctx := sdk.NewContext(ms, tmproto.Header{Time: time.Now().UTC()}, false, log.NewNopLogger())

	// Setup codec and interface registry
	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	// Setup account keeper mock
	accountKeeper := &MockAccountKeeper{}

	// sample.AccAddress() returns string, so we capture them as strings first
	granter := sample.AccAddress()
	grantee := sample.AccAddress()

	// Convert to sdk.AccAddress for the keeper/mock interactions
	granterAddr, err := sdk.AccAddressFromBech32(granter)
	require.NoError(t, err)
	granteeAddr, err := sdk.AccAddressFromBech32(grantee)
	require.NoError(t, err)

	// Mock account keeper to return accounts (expects sdk.AccAddress)
	accountKeeper.On("GetAccount", mock.Anything, granterAddr).Return(authtypes.NewBaseAccountWithAddress(granterAddr))
	accountKeeper.On("GetAccount", mock.Anything, granteeAddr).Return(authtypes.NewBaseAccountWithAddress(granteeAddr))

	// Mock AddressCodec call which is required by feegrant keeper
	accountKeeper.On("AddressCodec").Return(testAddressCodec{})

	// Setup feegrant keeper
	fgKeeper := feegrantkeeper.NewKeeper(cdc, runtime.NewKVStoreService(storeKey), accountKeeper)

	customMessenger := &tokenfactory.CustomMessenger{
		Feegrant: &fgKeeper,
	}

	// Build grant fee basic allowance message using strings
	grantMsg := bindings.FactoryMsg{
		Feegrant: &bindings.FeegrantMsg{
			GrantFeeBasicAllowance: &bindings.GrantFeeBasicAllowance{
				Granter:       granter,
				Grantee:       grantee,
				Allowance:     sdk.NewCoin("stake", math.NewInt(1000)),
				HoursToExpire: 2400,
			},
		},
	}

	msgBytes, err := json.Marshal(grantMsg)
	require.NoError(t, err)

	cosmosMsg := wasmvmtypes.CosmosMsg{Custom: msgBytes}
	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, sdk.AccAddress("contract"), "ibc-port", cosmosMsg)

	require.NoError(t, err)
	require.Empty(t, events)
	require.Empty(t, data)
	require.Empty(t, msgResponses)
}

func TestDispatchMsg_FeegrantRevokeFeeAllowance(t *testing.T) {
	// Setup store
	db := dbm.NewMemDB()
	storeKey := storetypes.NewKVStoreKey(feegrant.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)
	ms.MountStoreWithDB(storeKey, storetypes.StoreTypeIAVL, db)
	require.NoError(t, ms.LoadLatestVersion())

	ctx := sdk.NewContext(ms, tmproto.Header{Time: time.Now().UTC()}, false, log.NewNopLogger())

	// Setup codec and interface registry
	registry := codectypes.NewInterfaceRegistry()
	feegrant.RegisterInterfaces(registry)
	cdc := codec.NewProtoCodec(registry)

	// Setup account keeper mock
	accountKeeper := &MockAccountKeeper{}

	// Create addresses
	granterStr := sample.AccAddress()
	granteeStr := sample.AccAddress()

	granter, err := sdk.AccAddressFromBech32(granterStr)
	require.NoError(t, err)
	grantee, err := sdk.AccAddressFromBech32(granteeStr)
	require.NoError(t, err)

	// Mock account keeper to return accounts
	accountKeeper.On("GetAccount", mock.Anything, granter).Return(authtypes.NewBaseAccountWithAddress(granter))
	accountKeeper.On("GetAccount", mock.Anything, grantee).Return(authtypes.NewBaseAccountWithAddress(grantee))
	// Required by feegrant keeper
	accountKeeper.On("AddressCodec").Return(testAddressCodec{})

	// Setup feegrant keeper
	fgKeeper := feegrantkeeper.NewKeeper(cdc, runtime.NewKVStoreService(storeKey), accountKeeper)

	// Prerequisite: Create a grant to revoke
	allowance := &feegrant.BasicAllowance{
		SpendLimit: sdk.NewCoins(sdk.NewCoin("stake", math.NewInt(100))),
	}
	err = fgKeeper.GrantAllowance(ctx, granter, grantee, allowance)
	require.NoError(t, err)

	// Setup messenger
	customMessenger := &tokenfactory.CustomMessenger{
		Feegrant: &fgKeeper,
	}

	// Build revoke fee allowance message
	revokeMsg := bindings.FactoryMsg{
		Feegrant: &bindings.FeegrantMsg{
			RevokeFeeAllowance: &bindings.RevokeFeeAllowance{
				Granter: granterStr,
				Grantee: granteeStr,
			},
		},
	}

	msgBytes, err := json.Marshal(revokeMsg)
	require.NoError(t, err)

	cosmosMsg := wasmvmtypes.CosmosMsg{Custom: msgBytes}
	events, data, msgResponses, err := customMessenger.DispatchMsg(ctx, sdk.AccAddress("contract"), "ibc-port", cosmosMsg)

	require.NoError(t, err)
	require.Empty(t, events)
	require.Empty(t, data)
	require.Empty(t, msgResponses)

	// Verify allowance is actually revoked
	// FIX: fgKeeper.GetAllowance returns an error when the grant is not found, which confirms revocation success.
	_, err = fgKeeper.GetAllowance(ctx, granter, grantee)
	require.Error(t, err)
	require.Contains(t, err.Error(), "not found")
}
