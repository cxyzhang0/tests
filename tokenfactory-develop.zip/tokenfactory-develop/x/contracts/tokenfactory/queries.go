package tokenfactory

import (
	"fmt"

	errorsmod "cosmossdk.io/errors"

	"cosmossdk.io/x/feegrant"
	feegrantkeeper "cosmossdk.io/x/feegrant/keeper"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/cosmos/cosmos-sdk/types/bech32"
	bankkeeper "github.com/cosmos/cosmos-sdk/x/bank/keeper"
	banktypes "github.com/cosmos/cosmos-sdk/x/bank/types"
	"github.com/wfblockchain/coreblockchain/v2/x/contracts/tokenfactory/bindings"

	tokenfactorymodulekeeper "github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/keeper"
)

type QueryPlugin struct {
	Tf       *tokenfactorymodulekeeper.Keeper
	Bank     *bankkeeper.BaseKeeper
	Feegrant *feegrantkeeper.Keeper
}

func NewQueryPlugin(tf *tokenfactorymodulekeeper.Keeper, bank *bankkeeper.BaseKeeper, feegrant *feegrantkeeper.Keeper) *QueryPlugin {
	return &QueryPlugin{
		tf,
		bank,
		feegrant,
	}
}

func (qp *QueryPlugin) Params(ctx sdk.Context, isTF bool) (*bindings.ParamsResponse, error) {
	r := qp.Tf.GetParams(ctx)
	resp := &bindings.ParamsResponse{Params: r.String()}
	return resp, nil
}

func (qp *QueryPlugin) Owner(ctx sdk.Context, isTF bool) (*bindings.OwnerResponse, error) {
	r, ok := qp.Tf.GetOwner(ctx)
	if !ok {
		return nil, fmt.Errorf("failed to get tf owner")
	}
	resp := &bindings.OwnerResponse{Address: r.Address}
	return resp, nil
}

func (qp *QueryPlugin) MasterMinter(ctx sdk.Context, isTF bool) (*bindings.MasterMinterResponse, error) {
	r, ok := qp.Tf.GetMasterMinter(ctx)
	if !ok {
		return nil, fmt.Errorf("failed to get master minter")
	}
	resp := &bindings.MasterMinterResponse{Address: r.Address}
	return resp, nil
}

func (qp *QueryPlugin) MinterController(ctx sdk.Context, controller string, minter string, isTF bool) (*bindings.MinterControllerResponse, error) {
	r, ok := qp.Tf.GetMinterController(ctx, controller, minter)
	if !ok {
		return nil, fmt.Errorf("failed to get minter controller")
	}
	resp := &bindings.MinterControllerResponse{Minter: r.Minter, Controller: r.Controller}
	return resp, nil
}

func (qp *QueryPlugin) AllMinterControllers(ctx sdk.Context, isTF bool) (*bindings.AllMinterControllersResponse, error) {
	r := qp.Tf.GetAllMinterControllers(ctx)
	var list []bindings.MinterControllerResponse
	for _, minterController := range r {
		list = append(list, bindings.MinterControllerResponse{Minter: minterController.Minter, Controller: minterController.Controller})
	}
	resp := &bindings.AllMinterControllersResponse{MinterControllers: list}
	return resp, nil
}

func (qp *QueryPlugin) MintingDenom(ctx sdk.Context, denom string, isTF bool) (*bindings.MintingDenomResponse, error) {
	r, found := qp.Tf.GetMintingDenom(ctx, denom)
	if !found {
		return nil, fmt.Errorf("failed to get minting denom")
	}
	resp := &bindings.MintingDenomResponse{Denom: r.Denom}
	return resp, nil
}

func (qp *QueryPlugin) AllMintingDenoms(ctx sdk.Context, isTF bool) (*bindings.AllMintingDenomsResponse, error) {
	r := qp.Tf.GetAllMintingDenoms(ctx)
	var list []bindings.MintingDenomResponse
	for _, mintingDenom := range r {
		list = append(list, bindings.MintingDenomResponse{Denom: mintingDenom.Denom})
	}
	resp := &bindings.AllMintingDenomsResponse{MintingDenoms: list}
	return resp, nil
}

func (qp *QueryPlugin) Minters(ctx sdk.Context, address string, denom string, isTF bool) (*bindings.MintersResponse, error) {
	r, ok := qp.Tf.GetMinters(ctx, address, denom)
	if !ok {
		return nil, fmt.Errorf("failed to get minters")
	}
	resp := &bindings.MintersResponse{Address: r.Address, Allowance: r.Allowance}
	return resp, nil
}

// TODO: address is not used because tf module GetAllMinters does not take an address as an argument
func (qp *QueryPlugin) AllMinters(ctx sdk.Context, address string, isTF bool) (*bindings.AllMintersResponse, error) {
	r := qp.Tf.GetAllMinters(ctx)
	var list []bindings.MintersResponse
	for _, minters := range r {
		list = append(list, bindings.MintersResponse{Address: minters.Address, Allowance: minters.Allowance})
	}
	resp := &bindings.AllMintersResponse{Minters: list}
	return resp, nil
}

func (qp *QueryPlugin) Blacklister(ctx sdk.Context, isTF bool) (*bindings.BlacklisterResponse, error) {
	r, ok := qp.Tf.GetBlacklister(ctx)
	if !ok {
		return nil, fmt.Errorf("failed to get blacklister")
	}
	resp := &bindings.BlacklisterResponse{Address: r.Address}
	return resp, nil
}

func (qp *QueryPlugin) Pauser(ctx sdk.Context, isTF bool) (*bindings.PauserResponse, error) {
	r, ok := qp.Tf.GetPauser(ctx)
	if !ok {
		return nil, fmt.Errorf("failed to get pauser")
	}
	resp := &bindings.PauserResponse{Address: r.Address}
	return resp, nil
}

func (qp *QueryPlugin) Blacklisted(ctx sdk.Context, address string, isTF bool) (*bindings.BlacklistedResponse, error) {
	_, addressBz, err := bech32.DecodeAndConvert(address)
	if err != nil {
		return nil, fmt.Errorf("failed to decode address")
	}

	r, ok := qp.Tf.GetBlacklisted(ctx, addressBz)
	if !ok {
		return nil, fmt.Errorf("failed to get blacklisted")
	}
	resp := &bindings.BlacklistedResponse{Address: r.String()}
	return resp, nil
}

func (qp *QueryPlugin) AllBlacklisted(ctx sdk.Context, isTF bool) (*bindings.AllBlacklistedResponse, error) {
	r := qp.Tf.GetAllBlacklisted(ctx)
	var list []bindings.BlacklistedResponse
	for _, blacklisted := range r {
		list = append(list, bindings.BlacklistedResponse{Address: blacklisted.String()})
	}
	resp := &bindings.AllBlacklistedResponse{Blacklisted: list}
	return resp, nil
}

func (qp *QueryPlugin) Paused(ctx sdk.Context, isTF bool) (*bindings.PausedResponse, error) {
	r := qp.Tf.GetPaused(ctx)
	resp := &bindings.PausedResponse{Paused: r.Paused}
	return resp, nil
}

func (qp *QueryPlugin) FindDenomMetadata(ctx sdk.Context, req *bindings.FindDenomMetadata) (*bindings.FindDenomMetadataResponse, error) {
	r, ok := qp.Bank.GetDenomMetaData(ctx, req.BaseDenom)
	if !ok {
		return nil, fmt.Errorf("failed to get denom metadata for %s", req.BaseDenom)
	}

	for _, u := range r.DenomUnits {
		if u.Denom == req.Denom {
			// in case unit.Aliases is nil, we need to have an empty slice so that json.Marshal does not return null but [] instead
			// otherwise, the deserialization on rust side (cosmwasm) will fail
			var aliases = make([]string, 0)
			for _, alias := range u.Aliases {
				aliases = append(aliases, alias)
			}
			return &bindings.FindDenomMetadataResponse{Description: r.Description, Base: r.Base, Display: r.Display, Name: r.Name, Symbol: r.Symbol, Denom: u.Denom, Exponent: u.Exponent, Aliases: aliases}, nil
		}
	}

	return nil, fmt.Errorf("failed to find denom unit for %s", req.Denom)
}

func (qp *QueryPlugin) FindMetadataForDenom(ctx sdk.Context, req *bindings.FindMetadataForDenom) (*bindings.FindDenomMetadataResponse, error) {
	res := qp.Bank.GetAllDenomMetaData(ctx)

	for _, r := range res {
		for _, u := range r.DenomUnits {
			if u.Denom == req.Denom {
				// in case unit.Aliases is nil, we need to have an empty slice so that json.Marshal does not return null but [] instead
				// otherwise, the deserialization on rust side (cosmwasm) will fail
				var aliases = make([]string, 0)
				for _, alias := range u.Aliases {
					aliases = append(aliases, alias)
				}
				return &bindings.FindDenomMetadataResponse{Description: r.Description, Base: r.Base, Display: r.Display, Name: r.Name, Symbol: r.Symbol, Denom: u.Denom, Exponent: u.Exponent, Aliases: aliases}, nil
			}
		}
	}

	return nil, fmt.Errorf("failed to find metadata for %s", req.Denom)
}

func (qp *QueryPlugin) DenomMetadata(ctx sdk.Context, denom string) (*bindings.DenomMetadataResponse, error) {
	//func (qp *QueryPlugin) DenomMetadata(ctx sdk.Context, denom string) (*banktypes.QueryDenomMetadataResponse, error) {
	r, ok := qp.Bank.GetDenomMetaData(ctx, denom)
	if !ok {
		return nil, fmt.Errorf("failed to get denom metadata")
	}

	var denon_units []*banktypes.DenomUnit

	for _, unit := range r.DenomUnits {
		// in case unit.Aliases is nil, we need to have an empty slice so that json.Marshal does not return null but [] instead
		// otherwise, the deserialization on rust side (cosmwasm) will fail
		var aliases = make([]string, 0)
		for _, alias := range unit.Aliases {
			aliases = append(aliases, alias)
		}
		denon_units = append(denon_units, &banktypes.DenomUnit{Denom: unit.Denom, Exponent: unit.Exponent, Aliases: aliases})
	}
	metadata := banktypes.Metadata{
		Description: r.Description,
		DenomUnits:  denon_units,
		Base:        r.Base,
		Display:     r.Display,
		Name:        r.Name,
		Symbol:      r.Symbol,
	}
	return &bindings.DenomMetadataResponse{Metadata: metadata}, nil
	//return &banktypes.QueryDenomMetadataResponse{Metadata: r}, nil
}

func (qp *QueryPlugin) AllDenomMetadata(ctx sdk.Context) *bindings.AllDenomMetadataResponse {
	r := qp.Bank.GetAllDenomMetaData(ctx)

	var metatdatas []banktypes.Metadata
	for _, m := range r {
		var denon_units []*banktypes.DenomUnit
		for _, unit := range m.DenomUnits {
			// in case unit.Aliases is nil, we need to have an empty slice so that json.Marshal does not return null but [] instead
			// otherwise, the deserialization on rust side (cosmwasm) will fail
			var aliases = make([]string, 0)
			for _, alias := range unit.Aliases {
				aliases = append(aliases, alias)
			}
			denon_units = append(denon_units, &banktypes.DenomUnit{Denom: unit.Denom, Exponent: unit.Exponent, Aliases: aliases})
		}
		metadata := banktypes.Metadata{
			Description: m.Description,
			DenomUnits:  denon_units,
			Base:        m.Base,
			Display:     m.Display,
			Name:        m.Name,
			Symbol:      m.Symbol,
		}
		metatdatas = append(metatdatas, metadata)
	}

	return &bindings.AllDenomMetadataResponse{Metadatas: metatdatas}
}

func (qp *QueryPlugin) FeeBasicAllowance(ctx sdk.Context, req *bindings.FeeBasicAllowance) (*bindings.FeeBasicAllowanceResponse, error) {
	granter, err := sdk.AccAddressFromBech32(req.Granter)
	if err != nil {
		return nil, errorsmod.Wrap(err, "failed to parse granter address")
	}

	grantee, err := sdk.AccAddressFromBech32(req.Grantee)
	if err != nil {
		return nil, errorsmod.Wrap(err, "failed to parse granter address")
	}

	allowance, err := qp.Feegrant.GetAllowance(ctx, granter, grantee)
	if err != nil {
		return nil, errorsmod.Wrap(err, "failed to get fee allowance")
	}

	basicAllowance, ok := allowance.(*feegrant.BasicAllowance)
	if !ok {
		return nil, errorsmod.Wrap(err, "failed to get basic fee allowance")
	}

	//q := feegranttypes.QueryAllowanceRequest{
	//	Granter: req.Granter,
	//	Grantee: req.Grantee,
	//}
	//r, err := qp.Feegrant.Allowance(ctx.Context(), &q)
	//if err != nil {
	//	return nil, errorsmod.Wrap(err, "failed to get fee allowance")
	//}

	return &bindings.FeeBasicAllowanceResponse{
		Allowance: &bindings.FeeBasicGrant{
			Granter:   req.Granter,
			Grantee:   req.Grantee,
			Allowance: basicAllowance.SpendLimit[0],
			//AllowanceDenom: basicAllowance.SpendLimit[0].Denom,
			//AllowanceValue: basicAllowance.SpendLimit[0].Amount.Uint64(),
			Expiration: basicAllowance.Expiration.String(),
		},
	}, nil
}
