package tokenfactory

import (
	"encoding/json"
	"fmt"

	errorsmod "cosmossdk.io/errors"
	wasmvmtypes "github.com/CosmWasm/wasmvm/types"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/wfblockchain/coreblockchain/v2/x/contracts/tokenfactory/bindings"
)

const (
	FailedToQueryErrorFmt  = "failed to query %s"
	FailedToQueryErrorFmt2 = "failed to query %s: %s"
)

func encodeOrWrap(resp any, err error, label string, wrapMsg string) ([]byte, error) {
	if label == "" {
		label = "unknown query"
	}
	if err != nil {
		if wrapMsg == "" {
			wrapMsg = fmt.Sprintf(FailedToQueryErrorFmt, label)
		}
		return nil, errorsmod.Wrap(err, wrapMsg)
	}
	return encode(resp, label)
}

func CustomQuerier(qp *QueryPlugin) func(ctx sdk.Context, request json.RawMessage) ([]byte, error) {
	return func(ctx sdk.Context, request json.RawMessage) ([]byte, error) {
		var contractQuery bindings.FactoryQuery
		if err := json.Unmarshal(request, &contractQuery); err != nil {
			return nil, errorsmod.Wrap(err, "failed to decode factory query")
		}

		var (
			label   string
			wrapMsg string
			resp    any
			err     error
		)

		switch {
		case contractQuery.TF != nil:
			tf := contractQuery.TF
			wrapMsg = ""
			switch {
			case tf.Params != nil:
				label = "params"
				resp, err = qp.Params(ctx, true)
			case tf.Owner != nil:
				label = "owner"
				resp, err = qp.Owner(ctx, true)
			case tf.MasterMinter != nil:
				label = "master minter"
				resp, err = qp.MasterMinter(ctx, true)
			case tf.MinterController != nil:
				label = "minter controller"
				resp, err = qp.MinterController(ctx, tf.MinterController.Controller, tf.MinterController.Minter, true)
				wrapMsg = fmt.Sprintf("failed to query %s: %s %s", label, tf.MinterController.Controller, tf.MinterController.Minter)
			case tf.AllMinterControllers != nil:
				label = "all minter controllers"
				resp, err = qp.AllMinterControllers(ctx, true)
			case tf.MintingDenom != nil:
				label = "minting denom"
				resp, err = qp.MintingDenom(ctx, tf.MintingDenom.Denom, true)
			case tf.AllMintingDenoms != nil:
				label = "all minting denoms"
				resp, err = qp.AllMintingDenoms(ctx, true)
			case tf.Minters != nil:
				label = "minters"
				resp, err = qp.Minters(ctx, tf.Minters.Address, tf.Minters.Denom, true)
			case tf.AllMinters != nil:
				label = "all minters"
				resp, err = qp.AllMinters(ctx, tf.AllMinters.Address, true)
			case tf.Blacklister != nil:
				label = "blacklister"
				resp, err = qp.Blacklister(ctx, true)
			case tf.Pauser != nil:
				label = "pauser"
				resp, err = qp.Pauser(ctx, true)
			case tf.Blacklisted != nil:
				label = "blacklisted"
				resp, err = qp.Blacklisted(ctx, tf.Blacklisted.Address, true)
				wrapMsg = fmt.Sprintf(FailedToQueryErrorFmt2, label, tf.Blacklisted.Address)
			case tf.AllBlacklisted != nil:
				label = "all blacklisted"
				resp, err = qp.AllBlacklisted(ctx, true)
			case tf.Paused != nil:
				label = "paused"
				resp, err = qp.Paused(ctx, true)

			default:
				return nil, wasmvmtypes.UnsupportedRequest{Kind: "unknown tokenfactory query variant"}
			}
		case contractQuery.Bank != nil:
			bk := contractQuery.Bank
			wrapMsg = ""
			switch {
			case bk.DenomMetadata != nil:
				label = "denom metadata"
				resp, err = qp.DenomMetadata(ctx, bk.DenomMetadata.Denom)
				wrapMsg = fmt.Sprintf(FailedToQueryErrorFmt2, label, bk.DenomMetadata.Denom)

			case bk.AllDenomMetadata != nil:
				label = "denoms metadata"
				resp = qp.AllDenomMetadata(ctx)
				err = nil

			case bk.FindDenomMetadata != nil:
				label = "find denom metadata"
				resp, err = qp.FindDenomMetadata(ctx, bk.FindDenomMetadata)
				wrapMsg = fmt.Sprintf("failed to %s for %s %s", label, bk.FindDenomMetadata.BaseDenom, bk.FindDenomMetadata.Denom)

			case bk.FindMetadataForDenom != nil:
				label = "find metadata for denom"
				resp, err = qp.FindMetadataForDenom(ctx, bk.FindMetadataForDenom)
				wrapMsg = fmt.Sprintf("failed to %s %s", label, bk.FindMetadataForDenom.Denom)

			default:
				return nil, wasmvmtypes.UnsupportedRequest{Kind: "unknown bank query variant"}

			}
		case contractQuery.Feegrant != nil:
			fg := contractQuery.Feegrant
			wrapMsg = ""
			switch {
			case fg.FeeBasicAllowance != nil:
				label = "fee basic allowance"
				resp, err = qp.FeeBasicAllowance(ctx, fg.FeeBasicAllowance)
				wrapMsg = fmt.Sprintf(FailedToQueryErrorFmt2, label, fg.FeeBasicAllowance.Granter)

			default:
				return nil, wasmvmtypes.UnsupportedRequest{Kind: "unknown feegrant query variant"}
			}
		default:
			return nil, wasmvmtypes.UnsupportedRequest{Kind: "unknown factory query variant"}
		}

		return encodeOrWrap(resp, err, label, wrapMsg)
	}
}

// prior to refactoring above
/*
func CustomQuerier(qp *QueryPlugin) func(ctx sdk.Context, request json.RawMessage) ([]byte, error) {
	return func(ctx sdk.Context, request json.RawMessage) ([]byte, error) {
		var contractQuery bindings.FactoryQuery
		if err := json.Unmarshal(request, &contractQuery); err != nil {
			return nil, errorsmod.Wrap(err, "failed to decode factory query")
		}

		if contractQuery.TF != nil {
			switch {
			case contractQuery.TF.Params != nil:
				resp, err := qp.Params(ctx, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf(FailedToQueryErrorFmt, "params"))
				}

				return encode(resp, "params")
			case contractQuery.TF.Owner != nil:
				resp, err := qp.Owner(ctx, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf(FailedToQueryErrorFmt, "owner"))
				}

				return encode(resp, "owner")
			case contractQuery.TF.MasterMinter != nil:
				resp, err := qp.MasterMinter(ctx, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf(FailedToQueryErrorFmt, "master minter"))
				}
				return encode(resp, "master minter")
			case contractQuery.TF.MinterController != nil:
				resp, err := qp.MinterController(ctx, contractQuery.TF.MinterController.Controller, contractQuery.TF.MinterController.Minter, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to query %s: %s %s", "minter controller", contractQuery.TF.MinterController.Controller, contractQuery.TF.MinterController.Minter))
				}
				return encode(resp, "mint controller")
			case contractQuery.TF.AllMinterControllers != nil:
				resp, err := qp.AllMinterControllers(ctx, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf(FailedToQueryErrorFmt, "all minter controllers"))
				}
				return encode(resp, "all minter controllers")
			case contractQuery.TF.MintingDenom != nil:
				resp, err := qp.MintingDenom(ctx, contractQuery.TF.MintingDenom.Denom, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf(FailedToQueryErrorFmt, "minting denom"))
				}
				return encode(resp, "minting denom")
			case contractQuery.TF.AllMintingDenoms != nil:
				resp, err := qp.AllMintingDenoms(ctx, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf(FailedToQueryErrorFmt, "all minting denoms"))
				}
				return encode(resp, "all minting denoms")
			case contractQuery.TF.Minters != nil:
				resp, err := qp.Minters(ctx, contractQuery.TF.Minters.Address, contractQuery.TF.Minters.Denom, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf(FailedToQueryErrorFmt2, "minters", contractQuery.TF.Minters.Address))
				}
				return encode(resp, "minters")
			case contractQuery.TF.AllMinters != nil:
				resp, err := qp.AllMinters(ctx, contractQuery.TF.AllMinters.Address, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf(FailedToQueryErrorFmt, "all minters"))
				}
				return encode(resp, "all minters")
			case contractQuery.TF.Blacklister != nil:
				resp, err := qp.Blacklister(ctx, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf(FailedToQueryErrorFmt, "blacklister"))
				}
				return encode(resp, "blacklister")
			case contractQuery.TF.Pauser != nil:
				resp, err := qp.Pauser(ctx, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf(FailedToQueryErrorFmt, "pauser"))
				}
				return encode(resp, "pauser")
			case contractQuery.TF.Blacklisted != nil:
				resp, err := qp.Blacklisted(ctx, contractQuery.TF.Blacklisted.Address, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf(FailedToQueryErrorFmt2, "blacklisted", contractQuery.TF.Blacklisted.Address))
				}
				return encode(resp, "blacklisted")
			case contractQuery.TF.AllBlacklisted != nil:
				resp, err := qp.AllBlacklisted(ctx, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf(FailedToQueryErrorFmt, "all blacklisted"))
				}
				return encode(resp, "blacklisted")
			case contractQuery.TF.Paused != nil:
				resp, err := qp.Paused(ctx, true)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf(FailedToQueryErrorFmt, "paused"))
				}
				return encode(resp, "paused")

			default:
				return nil, wasmvmtypes.UnsupportedRequest{Kind: "unknown tokenfactory query variant"}
			}

		} else if contractQuery.Bank != nil {
			switch {
			case contractQuery.Bank.DenomMetadata != nil:
				resp, err := qp.DenomMetadata(ctx, contractQuery.Bank.DenomMetadata.Denom)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf(FailedToQueryErrorFmt2, "denom metadata", contractQuery.Bank.DenomMetadata.Denom))
				}

				return encode(resp, "denom metadata")

			case contractQuery.Bank.AllDenomMetadata != nil:
				resp := qp.AllDenomMetadata(ctx)

				return encode(resp, "denoms metadata")

			case contractQuery.Bank.FindDenomMetadata != nil:
				resp, err := qp.FindDenomMetadata(ctx, contractQuery.Bank.FindDenomMetadata)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to find denom metadata for %s %s", contractQuery.Bank.FindDenomMetadata.BaseDenom, contractQuery.Bank.FindDenomMetadata.Denom))
				}

				return encode(resp, "find denom metadata")

			case contractQuery.Bank.FindMetadataForDenom != nil:
				resp, err := qp.FindMetadataForDenom(ctx, contractQuery.Bank.FindMetadataForDenom)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to find metadata for denom %s", contractQuery.Bank.FindMetadataForDenom.Denom))
				}

				return encode(resp, "find metadata for denom")

			default:
				return nil, wasmvmtypes.UnsupportedRequest{Kind: "unknown bank query variant"}

			}
		} else if contractQuery.Feegrant != nil {
			switch {
			case contractQuery.Feegrant.FeeBasicAllowance != nil:
				resp, err := qp.FeeBasicAllowance(ctx, contractQuery.Feegrant.FeeBasicAllowance)
				if err != nil {
					return nil, errorsmod.Wrap(err, fmt.Sprintf(FailedToQueryErrorFmt2, "fee basic allowance", contractQuery.Feegrant.FeeBasicAllowance.Granter))
				}

				return encode(resp, "fee basic allowance")

			default:
				return nil, wasmvmtypes.UnsupportedRequest{Kind: "unknown feegrant query variant"}
			}
		} else {
			return nil, wasmvmtypes.UnsupportedRequest{Kind: "unknown factory query variant"}
		}
	}
}
*/

func encode(resp any, msg string) ([]byte, error) {
	bz, err := json.Marshal(resp)
	if err != nil {
		return nil, errorsmod.Wrap(err, fmt.Sprintf("failed to encode %s response", msg))
	}
	return bz, nil
}
