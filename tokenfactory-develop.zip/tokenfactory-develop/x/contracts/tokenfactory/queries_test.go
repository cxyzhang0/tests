package tokenfactory_test

import (
	"context"
	"encoding/json"
	"fmt"
	"testing"
	"time"

	"cosmossdk.io/core/address"
	sdkmath "cosmossdk.io/math"
	"cosmossdk.io/store"
	"cosmossdk.io/store/metrics"
	"cosmossdk.io/store/types"
	"cosmossdk.io/x/feegrant"
	feegrantkeeper "cosmossdk.io/x/feegrant/keeper"
	wasmvmtypes "github.com/CosmWasm/wasmvm/types"
	tmproto "github.com/cometbft/cometbft/proto/tendermint/types"
	dbm "github.com/cosmos/cosmos-db"
	"github.com/cosmos/cosmos-sdk/codec"
	codectypes "github.com/cosmos/cosmos-sdk/codec/types"
	"github.com/cosmos/cosmos-sdk/runtime"
	sdk "github.com/cosmos/cosmos-sdk/types"
	authtypes "github.com/cosmos/cosmos-sdk/x/auth/types"
	"github.com/cosmos/cosmos-sdk/x/bank/keeper"
	banktypes "github.com/cosmos/cosmos-sdk/x/bank/types"
	paramtypes "github.com/cosmos/cosmos-sdk/x/params/types"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"
	"github.com/wfblockchain/coreblockchain/v2/testutil/sample"
	"github.com/wfblockchain/coreblockchain/v2/x/contracts/tokenfactory/bindings"

	"cosmossdk.io/log"
	"github.com/cosmos/cosmos-sdk/types/bech32"
	proto "github.com/cosmos/gogoproto/proto"
	"github.com/wfblockchain/coreblockchain/v2/x/contracts/tokenfactory"
	tokenfactorymodulekeeper "github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/keeper"
	tokenfactorymoduletypes "github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/types"
)

func TestCustomQuerier_TfParams(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := types.NewKVStoreKey("key")
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, types.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	ownerAddr := sample.AccAddress()

	owner := tokenfactorymoduletypes.Owner{Address: ownerAddr}

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace

	var tfbankKeeper tokenfactorymoduletypes.BankKeeper

	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper, runtime.NewKVStoreService(storeKey))

	tf.SetOwner(ctx, owner)

	mockMessenger := new(MockMessenger)
	query := bindings.FactoryQuery{
		TF: &bindings.TokenfactoryQuery{
			Params: &bindings.Params{},
		},
	}
	customQueryPlugin := &tokenfactory.QueryPlugin{
		Tf: tf,
	}

	msgBytes, err := json.Marshal(query)
	require.NoError(t, err)

	expectedData := []byte(`{"params":"{}\n"}`)

	customQuerier := tokenfactory.CustomQuerier(customQueryPlugin)
	data, err := customQuerier(ctx, msgBytes)

	require.NoError(t, err)
	require.Equal(t, expectedData, data)

	mockMessenger.AssertExpectations(t)
}

func TestCustomQuerier_TfOwner(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := types.NewKVStoreKey("key")
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)
	ms.MountStoreWithDB(storeKey, types.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace
	var tfbankKeeper tokenfactorymoduletypes.BankKeeper

	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper, runtime.NewKVStoreService(storeKey))

	mockMessenger := new(MockMessenger)
	query := bindings.FactoryQuery{
		TF: &bindings.TokenfactoryQuery{
			Owner: &bindings.Owner{},
		},
	}
	customQueryPlugin := &tokenfactory.QueryPlugin{
		Tf: tf,
	}
	customQuerier := tokenfactory.CustomQuerier(customQueryPlugin)

	msgBytes, err := json.Marshal(query)
	require.NoError(t, err)

	// Test when TF owner is not set
	customQuerier(ctx, msgBytes)

	// Set TF owner and test the response
	ownerAddr := sample.AccAddress()
	owner := tokenfactorymoduletypes.Owner{Address: ownerAddr}
	tf.SetOwner(ctx, owner)

	// expectedData := []byte(fmt.Sprintf(`{"address":"%s"}`, ownerAddr))

	// data, err = customQuerier(ctx, msgBytes)
	// require.NoError(t, err)
	// require.Equal(t, expectedData, data)

	mockMessenger.AssertExpectations(t)
}

func TestCustomQuerier_TfMasterMinter(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := types.NewKVStoreKey("key")
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, types.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	ownerAddr := sample.AccAddress()
	owner := tokenfactorymoduletypes.Owner{Address: ownerAddr}

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace
	var tfbankKeeper tokenfactorymoduletypes.BankKeeper

	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper, runtime.NewKVStoreService(storeKey))

	tokenfactorymodulekeeper.Keeper.SetMasterMinter(*tf, ctx, tokenfactorymoduletypes.MasterMinter{Address: ownerAddr})
	tf.SetOwner(ctx, owner)

	fetchedOwner, _ := tf.GetOwner(ctx)
	fmt.Println("Fetched Owner:", fetchedOwner)

	mockMessenger := new(MockMessenger)
	query := bindings.FactoryQuery{
		TF: &bindings.TokenfactoryQuery{
			MasterMinter: &bindings.MasterMinter{},
		},
	}
	customQueryPlugin := &tokenfactory.QueryPlugin{
		Tf: tf,
	}

	msgBytes, err := json.Marshal(query)
	require.NoError(t, err)

	expectedData := []byte(fmt.Sprintf(`{"address":"%s"}`, ownerAddr))

	customQuerier := tokenfactory.CustomQuerier(customQueryPlugin)
	data, err := customQuerier(ctx, msgBytes)

	require.NoError(t, err)
	require.Equal(t, expectedData, data)

	mockMessenger.AssertExpectations(t)
}

func TestCustomQuerier_TfMinterController(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := types.NewKVStoreKey("key")
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, types.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	ownerAddr := sample.AccAddress()

	owner := tokenfactorymoduletypes.Owner{Address: ownerAddr}

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace

	var tfbankKeeper tokenfactorymoduletypes.BankKeeper

	minter := sample.AccAddress()

	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper, runtime.NewKVStoreService(storeKey))
	tf.SetMinters(ctx, tokenfactorymoduletypes.Minters{Address: minter})
	tf.SetMinterController(ctx, tokenfactorymoduletypes.MinterController{Minter: minter, Controller: ownerAddr})

	minterController, found := tf.GetMinterController(ctx, ownerAddr, minter)
	fmt.Printf("Fetched Minter Controller: %+v Found: %v\n", minterController, found)

	tf.SetOwner(ctx, owner)

	mockMessenger := new(MockMessenger)
	query := bindings.FactoryQuery{
		TF: &bindings.TokenfactoryQuery{
			MinterController: &bindings.MinterController{
				Controller: ownerAddr,
				Minter:     minter,
			},
		},
	}
	customQueryPlugin := &tokenfactory.QueryPlugin{
		Tf: tf,
	}

	msgBytes, err := json.Marshal(query)
	require.NoError(t, err)

	fmt.Printf("Query Request: %s\n", string(msgBytes))

	customQuerier := tokenfactory.CustomQuerier(customQueryPlugin)
	customQuerier(ctx, msgBytes)

	require.NoError(t, err)

	mockMessenger.AssertExpectations(t)
}

func TestCustomQuerier_TfAllMinterControllers(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := types.NewKVStoreKey("key")
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, types.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	ownerAddr := sample.AccAddress()

	owner := tokenfactorymoduletypes.Owner{Address: ownerAddr}

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace

	var tfbankKeeper tokenfactorymoduletypes.BankKeeper

	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper, runtime.NewKVStoreService(storeKey))
	if tf == nil {
		t.Fatalf("TokenFactory Keeper is nil")
	}
	minter := sample.AccAddress()

	tf.SetMinters(ctx, tokenfactorymoduletypes.Minters{Address: minter})
	tf.SetMinterController(ctx, tokenfactorymoduletypes.MinterController{Minter: ownerAddr, Controller: ownerAddr})

	minterController, found := tf.GetMinterController(ctx, ownerAddr, minter)
	fmt.Printf("Fetched Minter Controller: %+v Found: %v\n", minterController, found)

	tf.SetOwner(ctx, owner)

	mockMessenger := new(MockMessenger)
	query := bindings.FactoryQuery{
		TF: &bindings.TokenfactoryQuery{
			AllMinterControllers: &bindings.AllMinterControllers{},
		},
	}
	customQueryPlugin := &tokenfactory.QueryPlugin{
		Tf: tf,
	}

	msgBytes, err := json.Marshal(query)
	require.NoError(t, err)

	fmt.Printf("Query Request: %s\n", string(msgBytes))

	expectedData := []byte(fmt.Sprintf(`{"minter_controllers":[{"minter":"%s","controller":"%s"}]}`, ownerAddr, ownerAddr))

	customQuerier := tokenfactory.CustomQuerier(customQueryPlugin)
	data, err := customQuerier(ctx, msgBytes)

	require.NoError(t, err)
	require.Equal(t, expectedData, data)

	mockMessenger.AssertExpectations(t)
}

type MockBankKeeper struct{}

func (m *MockBankKeeper) SpendableCoins(ctx context.Context, addr sdk.AccAddress) sdk.Coins {
	return sdk.Coins{}
}

func (m *MockBankKeeper) MintCoins(ctx context.Context, moduleName string, amt sdk.Coins) error {
	return nil
}

func (m *MockBankKeeper) BurnCoins(ctx context.Context, moduleName string, amt sdk.Coins) error {
	return nil
}

func (m *MockBankKeeper) SendCoinsFromModuleToAccount(ctx context.Context, senderModule string, recipientAddr sdk.AccAddress, amt sdk.Coins) error {
	return nil
}

func (m *MockBankKeeper) SendCoinsFromAccountToModule(ctx context.Context, senderAddr sdk.AccAddress, recipientModule string, amt sdk.Coins) error {
	return nil
}

func (m *MockBankKeeper) SetDenomMetaData(ctx context.Context, metadata banktypes.Metadata) {
}

func (m *MockBankKeeper) GetDenomMetaData(ctx context.Context, denom string) (banktypes.Metadata, bool) {
	if denom == "stake" {
		return banktypes.Metadata{
			DenomUnits: []*banktypes.DenomUnit{
				{Denom: "stake", Exponent: 0},
			},
		}, true
	}
	return banktypes.Metadata{}, false
}

func TestCustomQuerier_TfMintingDenom(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := types.NewKVStoreKey("key")
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, types.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	ownerAddr := sample.AccAddress()

	owner := tokenfactorymoduletypes.Owner{Address: ownerAddr}

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace

	var tfbankKeeper tokenfactorymoduletypes.BankKeeper = &MockBankKeeper{}

	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper, runtime.NewKVStoreService(storeKey))

	tf.SetOwner(ctx, owner)

	mintingDenom := tokenfactorymoduletypes.MintingDenom{Denom: "stake"}
	tf.SetMintingDenom(ctx, mintingDenom)

	fmt.Printf("Minting Denom: %+v\n", mintingDenom)

	mockMessenger := new(MockMessenger)
	query := bindings.FactoryQuery{
		TF: &bindings.TokenfactoryQuery{
			MintingDenom: &bindings.MintingDenom{
				Denom: mintingDenom.Denom,
			},
		},
	}
	customQueryPlugin := &tokenfactory.QueryPlugin{
		Tf: tf,
	}

	msgBytes, err := json.Marshal(query)
	require.NoError(t, err)

	fmt.Printf("Query Request: %s\n", string(msgBytes))

	expectedData := []byte(fmt.Sprintf(`{"denom":"%s"}`, mintingDenom.Denom))

	customQuerier := tokenfactory.CustomQuerier(customQueryPlugin)
	data, err := customQuerier(ctx, msgBytes)

	require.NoError(t, err)
	require.Equal(t, expectedData, data)

	mockMessenger.AssertExpectations(t)
}

func TestCustomQuerier_TfMinters(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := types.NewKVStoreKey("key")
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)
	ms.MountStoreWithDB(storeKey, types.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	ownerAddr := sample.AccAddress()
	owner := tokenfactorymoduletypes.Owner{Address: ownerAddr}

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace
	var tfbankKeeper tokenfactorymoduletypes.BankKeeper = &MockBankKeeper{}

	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper, runtime.NewKVStoreService(storeKey))

	tf.SetOwner(ctx, owner)

	mockMessenger := new(MockMessenger)
	query := bindings.FactoryQuery{
		TF: &bindings.TokenfactoryQuery{
			Minters: &bindings.Minters{
				Address: ownerAddr,
			},
		},
	}
	customQueryPlugin := &tokenfactory.QueryPlugin{
		Tf: tf,
	}

	msgBytes, err := json.Marshal(query)
	require.NoError(t, err)

	customQuerier := tokenfactory.CustomQuerier(customQueryPlugin)

	minter := tokenfactorymoduletypes.Minters{
		Address: ownerAddr,
		Allowance: sdk.Coin{
			Denom:  "stake",
			Amount: sdkmath.NewInt(1000),
		},
	}
	tf.SetMinters(ctx, minter)

	storedMinter, found := tf.GetMinters(ctx, ownerAddr, "stake")
	require.True(t, found, "minter should exist after being set")
	require.Equal(t, minter, storedMinter)

	customQuerier(ctx, msgBytes)
	require.NoError(t, err)

	mockMessenger.AssertExpectations(t)
}

func TestCustomQuerier_TfAllMinters(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := types.NewKVStoreKey("key")
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)
	ms.MountStoreWithDB(storeKey, types.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	ownerAddr := sample.AccAddress()

	owner := tokenfactorymoduletypes.Owner{Address: ownerAddr}

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace
	var tfbankKeeper tokenfactorymoduletypes.BankKeeper = &MockBankKeeper{}

	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper, runtime.NewKVStoreService(storeKey))

	tf.SetOwner(ctx, owner)
	mockMessenger := new(MockMessenger)

	query := bindings.FactoryQuery{
		TF: &bindings.TokenfactoryQuery{
			AllMinters: &bindings.AllMinters{
				Address: ownerAddr,
			},
		},
	}

	customQueryPlugin := &tokenfactory.QueryPlugin{
		Tf: tf,
	}

	msgBytes, err := json.Marshal(query)
	require.NoError(t, err)

	fmt.Printf("Query Request: %s\n", string(msgBytes))

	expectedData := []byte(`{"minters":null}`)
	customQuerier := tokenfactory.CustomQuerier(customQueryPlugin)
	data, err := customQuerier(ctx, msgBytes)
	require.NoError(t, err)
	require.Equal(t, expectedData, data)

	minter := tokenfactorymoduletypes.Minters{
		Address: ownerAddr,
		Allowance: sdk.Coin{
			Denom:  "stake",
			Amount: sdkmath.NewInt(1000),
		},
	}
	tf.SetMinters(ctx, minter)

	data, err = customQuerier(ctx, msgBytes)
	require.NoError(t, err)

	expectedData = []byte(fmt.Sprintf(
		`{"minters":[{"address":"%s","allowance":{"denom":"stake","amount":"1000"}}]}`,
		ownerAddr,
	))
	require.Equal(t, expectedData, data)

	mockMessenger.AssertExpectations(t)
}

func TestCustomQuerier_TfBlacklister(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := types.NewKVStoreKey("key")
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)
	ms.MountStoreWithDB(storeKey, types.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	ownerAddr := sample.AccAddress()
	owner := tokenfactorymoduletypes.Owner{Address: ownerAddr}

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace
	var tfbankKeeper tokenfactorymoduletypes.BankKeeper = &MockBankKeeper{}

	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper, runtime.NewKVStoreService(storeKey))
	tf.SetOwner(ctx, owner)

	mockMessenger := new(MockMessenger)

	query := bindings.FactoryQuery{
		TF: &bindings.TokenfactoryQuery{
			Blacklister: &bindings.Blacklister{},
		},
	}

	customQueryPlugin := &tokenfactory.QueryPlugin{
		Tf: tf,
	}

	msgBytes, err := json.Marshal(query)
	require.NoError(t, err)

	fmt.Printf("Query Request: %s\n", string(msgBytes))

	customQuerier := tokenfactory.CustomQuerier(customQueryPlugin)
	data, err := customQuerier(ctx, msgBytes)

	require.Error(t, err)
	require.Nil(t, data)
	blacklister := tokenfactorymoduletypes.Blacklister{Address: ownerAddr}
	tf.SetBlacklister(ctx, blacklister)

	data, err = customQuerier(ctx, msgBytes)
	require.NoError(t, err)
	expectedData := []byte(fmt.Sprintf(`{"address":"%s"}`, ownerAddr))
	require.Equal(t, expectedData, data)

	mockMessenger.AssertExpectations(t)
}

func TestCustomQuerier_TfPauser(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := types.NewKVStoreKey("key")
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, types.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	ownerAddr := sample.AccAddress()

	owner := tokenfactorymoduletypes.Owner{Address: ownerAddr}

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace

	var tfbankKeeper tokenfactorymoduletypes.BankKeeper = &MockBankKeeper{}

	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper, runtime.NewKVStoreService(storeKey))

	tf.SetOwner(ctx, owner)
	mockMessenger := new(MockMessenger)
	query := bindings.FactoryQuery{
		TF: &bindings.TokenfactoryQuery{
			Pauser: &bindings.Pauser{},
		},
	}
	customQueryPlugin := &tokenfactory.QueryPlugin{
		Tf: tf,
	}

	msgBytes, err := json.Marshal(query)
	require.NoError(t, err)

	fmt.Printf("Query Request: %s\n", string(msgBytes))

	expectedData := []byte(`{"address":""}`)

	customQuerier := tokenfactory.CustomQuerier(customQueryPlugin)
	data, err := customQuerier(ctx, msgBytes)

	require.NoError(t, err)
	require.Equal(t, expectedData, data)

	mockMessenger.AssertExpectations(t)
}

func TestCustomQuerier_TfBlacklisted(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := types.NewKVStoreKey("key")
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, types.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	ownerAddr := sample.AccAddress()

	//owner := tokenfactorymoduletypes.Owner{Address: ownerAddr}

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace

	var tfbankKeeper tokenfactorymoduletypes.BankKeeper = &MockBankKeeper{}

	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper, runtime.NewKVStoreService(storeKey))

	//tf.SetOwner(ctx, owner)
	_, expectedData, _ := bech32.DecodeAndConvert(ownerAddr)
	blacklisted := tokenfactorymoduletypes.Blacklisted{AddressBz: expectedData}
	tf.SetBlacklisted(ctx, blacklisted)

	mockMessenger := new(MockMessenger)
	query := bindings.FactoryQuery{
		TF: &bindings.TokenfactoryQuery{
			Blacklisted: &bindings.Blacklisted{
				Address: ownerAddr,
			},
		},
	}

	customQueryPlugin := &tokenfactory.QueryPlugin{
		Tf: tf,
	}

	msgBytes, err := json.Marshal(query)
	require.NoError(t, err)

	fmt.Printf("Query Request: %s\n", string(msgBytes))

	//expectedData := []byte("null")

	customQuerier := tokenfactory.CustomQuerier(customQueryPlugin)
	data, err := customQuerier(ctx, msgBytes)

	require.NoError(t, err)
	var addr bindings.BlacklistedResponse
	json.Unmarshal(data, &addr)
	var addrBz tokenfactorymoduletypes.Blacklisted
	proto.UnmarshalText(addr.Address, &addrBz)

	require.Equal(t, expectedData, addrBz.AddressBz)

	mockMessenger.AssertExpectations(t)
}

func TestCustomQuerier_TfAllblacklisted(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := types.NewKVStoreKey("key")
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, types.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	ownerAddr := sample.AccAddress()

	owner := tokenfactorymoduletypes.Owner{Address: ownerAddr}

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace

	var tfbankKeeper tokenfactorymoduletypes.BankKeeper = &MockBankKeeper{}

	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper, runtime.NewKVStoreService(storeKey))

	tf.SetOwner(ctx, owner)
	mockMessenger := new(MockMessenger)
	query := bindings.FactoryQuery{
		TF: &bindings.TokenfactoryQuery{
			AllBlacklisted: &bindings.AllBlacklisted{},
		},
	}
	customQueryPlugin := &tokenfactory.QueryPlugin{
		Tf: tf,
	}

	msgBytes, err := json.Marshal(query)
	require.NoError(t, err)

	fmt.Printf("Query Request: %s\n", string(msgBytes))

	expectedData := []byte(`{"blacklisted":null}`)

	customQuerier := tokenfactory.CustomQuerier(customQueryPlugin)
	data, err := customQuerier(ctx, msgBytes)

	require.NoError(t, err)
	require.Equal(t, expectedData, data)

	mockMessenger.AssertExpectations(t)
}

func TestCustomQuerier_TfPaused(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := types.NewKVStoreKey("key")
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, types.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	ownerAddr := sample.AccAddress()

	owner := tokenfactorymoduletypes.Owner{Address: ownerAddr}

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace

	var tfbankKeeper tokenfactorymoduletypes.BankKeeper = &MockBankKeeper{}

	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper, runtime.NewKVStoreService(storeKey))

	tf.SetOwner(ctx, owner)
	mockMessenger := new(MockMessenger)
	query := bindings.FactoryQuery{
		TF: &bindings.TokenfactoryQuery{
			Paused: &bindings.Paused{},
		},
	}
	customQueryPlugin := &tokenfactory.QueryPlugin{
		Tf: tf,
	}

	msgBytes, err := json.Marshal(query)
	require.NoError(t, err)

	fmt.Printf("Query Request: %s\n", string(msgBytes))

	expectedData := []byte(`{"paused":false}`)

	customQuerier := tokenfactory.CustomQuerier(customQueryPlugin)
	data, err := customQuerier(ctx, msgBytes)

	require.NoError(t, err)
	require.Equal(t, expectedData, data)

	mockMessenger.AssertExpectations(t)
}

func TestCustomQuerier_UnsupportedQuery(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := types.NewKVStoreKey("key")
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, types.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	ownerAddr := sample.AccAddress()

	owner := tokenfactorymoduletypes.Owner{Address: ownerAddr}

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace

	var tfbankKeeper tokenfactorymoduletypes.BankKeeper

	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper, runtime.NewKVStoreService(storeKey))

	tf.SetOwner(ctx, owner)

	mockMessenger := new(MockMessenger)
	query := bindings.FactoryQuery{
		TF: &bindings.TokenfactoryQuery{},
	}
	customQueryPlugin := &tokenfactory.QueryPlugin{
		Tf: tf,
	}

	msgBytes, err := json.Marshal(query)
	require.NoError(t, err)

	expectedErrorResponse := "unsupported request: unknown tokenfactory query variant"

	customQuerier := tokenfactory.CustomQuerier(customQueryPlugin)
	_, err = customQuerier(ctx, msgBytes)

	require.Error(t, err)
	require.Equal(t, expectedErrorResponse, err.Error())

	mockMessenger.AssertExpectations(t)
}

type MockBankBaseKeeper struct {
	mock.Mock
}

type BankKeeper interface {
	GetDenomMetaData(ctx sdk.Context, denom string) (banktypes.Metadata, error)
}

func (m *MockBankBaseKeeper) GetDenomMetaData(ctx sdk.Context, denom string) (banktypes.Metadata, error) {
	args := m.Called(ctx, denom)
	return args.Get(0).(banktypes.Metadata), args.Error(1)
}

type MockAccountKeeper struct {
	mock.Mock
}

func (m *MockAccountKeeper) AddressCodec() address.Codec {
	args := m.Called()
	return args.Get(0).(address.Codec)
}

func (m *MockAccountKeeper) NewAccount(ctx context.Context, acc sdk.AccountI) sdk.AccountI {
	args := m.Called(ctx, acc)
	return args.Get(0).(sdk.AccountI)
}

func (m *MockAccountKeeper) NewAccountWithAddress(ctx context.Context, addr sdk.AccAddress) sdk.AccountI {
	args := m.Called(ctx, addr)
	return args.Get(0).(sdk.AccountI)
}

func (m *MockAccountKeeper) GetAccount(ctx context.Context, addr sdk.AccAddress) sdk.AccountI {
	args := m.Called(ctx, addr)
	return args.Get(0).(sdk.AccountI)
}

func (m *MockAccountKeeper) GetAllAccounts(ctx context.Context) []sdk.AccountI {
	args := m.Called(ctx)
	return args.Get(0).([]sdk.AccountI)
}

func (m *MockAccountKeeper) HasAccount(ctx context.Context, addr sdk.AccAddress) bool {
	args := m.Called(ctx, addr)
	return args.Bool(0)
}

func (m *MockAccountKeeper) SetAccount(ctx context.Context, acc sdk.AccountI) {
	m.Called(ctx, acc)
}

func (m *MockAccountKeeper) IterateAccounts(ctx context.Context, process func(sdk.AccountI) bool) {
	m.Called(ctx, process)
}

func (m *MockAccountKeeper) ValidatePermissions(macc sdk.ModuleAccountI) error {
	args := m.Called(macc)
	return args.Error(0)
}

func (m *MockAccountKeeper) GetModuleAddress(moduleName string) sdk.AccAddress {
	args := m.Called(moduleName)
	return args.Get(0).(sdk.AccAddress)
}

func (m *MockAccountKeeper) GetModuleAddressAndPermissions(moduleName string) (sdk.AccAddress, []string) {
	args := m.Called(moduleName)
	return args.Get(0).(sdk.AccAddress), args.Get(1).([]string)
}

func (m *MockAccountKeeper) GetModuleAccountAndPermissions(ctx context.Context, moduleName string) (sdk.ModuleAccountI, []string) {
	args := m.Called(ctx, moduleName)
	return args.Get(0).(sdk.ModuleAccountI), args.Get(1).([]string)
}

func (m *MockAccountKeeper) GetModuleAccount(ctx context.Context, moduleName string) sdk.ModuleAccountI {
	args := m.Called(ctx, moduleName)
	return args.Get(0).(sdk.ModuleAccountI)
}

func (m *MockAccountKeeper) SetModuleAccount(ctx context.Context, macc sdk.ModuleAccountI) {
	m.Called(ctx, macc)
}

func (m *MockAccountKeeper) GetModulePermissions() map[string]authtypes.PermissionsForAddress {
	args := m.Called()
	return args.Get(0).(map[string]authtypes.PermissionsForAddress)
}

type MockAddressCodec struct {
	mock.Mock
}

func (m *MockAddressCodec) MustLengthPrefix(address []byte) []byte {
	args := m.Called(address)
	return args.Get(0).([]byte)
}

func (m *MockAddressCodec) StringToBytes(text string) ([]byte, error) {
	args := m.Called(text)
	return args.Get(0).([]byte), args.Error(1)
}

func (m *MockAddressCodec) BytesToString(bz []byte) (string, error) {
	args := m.Called(bz)
	return args.String(0), args.Error(1)
}

type CustomKVStoreService struct {
	commitMultiStore store.CommitMultiStore
}

func NewCustomKVStoreService(commitMultiStore store.CommitMultiStore) *CustomKVStoreService {
	return &CustomKVStoreService{commitMultiStore: commitMultiStore}
}

func (service *CustomKVStoreService) OpenKVStore(ctx context.Context) store.KVStore {
	storeKey := types.NewKVStoreKey("key")
	return service.commitMultiStore.GetKVStore(storeKey)
}

func TestCustomQuerier_BankDenomMetadata(t *testing.T) {

	db := dbm.NewMemDB()
	storeKey := types.NewKVStoreKey(banktypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, types.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())
	blockedAddrs := make(map[string]bool)
	authority := authtypes.NewModuleAddress(banktypes.ModuleName).String()
	mockAddressCodec := new(MockAddressCodec)
	accountKeeper := &MockAccountKeeper{}

	accountKeeper.On("AddressCodec").Return(mockAddressCodec)
	mockAddressCodec.On("StringToBytes", "cosmos1gwqac243g2z3vryqsev6acq965f9ttwhemeg7g").Return([]byte("some bytes"), nil)

	mockAddressCodec.On("BytesToString", []byte("some bytes")).Return("cosmos1gwqac243g2z3vryqsev6acq965f9ttwhemeg7g", nil)

	tf_bank := keeper.NewBaseKeeper(
		cdc,
		runtime.NewKVStoreService(storeKey),
		accountKeeper,
		blockedAddrs,
		authority,
		log.NewNopLogger(),
	)

	mockMessenger := new(MockMessenger)
	query := bindings.FactoryQuery{
		Bank: &bindings.BankQuery{
			DenomMetadata: &bindings.DenomMetadata{
				Denom: "stake",
			},
		},
	}
	customQueryPlugin := &tokenfactory.QueryPlugin{
		Bank: &tf_bank,
	}

	msgBytes, err := json.Marshal(query)
	require.NoError(t, err)

	fmt.Printf("Query Request: %s\n", string(msgBytes))

	expectedData := []byte("{\"metadata\":{\"base\":\"stake\"}}")
	tf_bank.SetDenomMetaData(ctx, banktypes.Metadata{Base: "stake"})

	customQuerier := tokenfactory.CustomQuerier(customQueryPlugin)
	data, err := customQuerier(ctx, msgBytes)

	require.NoError(t, err)
	require.Equal(t, expectedData, data)

	mockMessenger.AssertExpectations(t)

}

type BankKeeperInterface interface {
	GetDenomMetaData(ctx sdk.Context, denom string) (banktypes.Metadata, bool)
}

func TestQueryPlugin_AllDenomMetadata(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := types.NewKVStoreKey(banktypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)
	ms.MountStoreWithDB(storeKey, types.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, logger)

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())
	blockedAddrs := make(map[string]bool)
	authority := authtypes.NewModuleAddress(banktypes.ModuleName).String()
	accountKeeper := &MockAccountKeeper{}
	mockAddressCodec := new(MockAddressCodec)

	accountKeeper.On("AddressCodec").Return(mockAddressCodec)
	mockAddressCodec.On("StringToBytes", "cosmos1gwqac243g2z3vryqsev6acq965f9ttwhemeg7g").Return([]byte("some bytes"), nil)

	mockAddressCodec.On("BytesToString", []byte("some bytes")).Return("cosmos1gwqac243g2z3vryqsev6acq965f9ttwhemeg7g", nil)

	tf_bank := keeper.NewBaseKeeper(
		cdc,
		runtime.NewKVStoreService(storeKey),
		accountKeeper,
		blockedAddrs,
		authority,
		logger,
	)
	denomMetadata1 := banktypes.Metadata{
		Description: "Test Token 1",
		DenomUnits: []*banktypes.DenomUnit{
			{
				Denom:    "token1",
				Exponent: 6,
				Aliases:  []string{"tk1", "t1"},
			},
		},
		Base:    "token1",
		Display: "TK1",
		Name:    "Test Token 1",
		Symbol:  "TK1",
	}

	denomMetadata2 := banktypes.Metadata{
		Description: "Test Token 2",
		DenomUnits: []*banktypes.DenomUnit{
			{
				Denom:    "token2",
				Exponent: 6,
				Aliases:  []string{"tk2", "t2"},
			},
		},
		Base:    "token2",
		Display: "TK2",
		Name:    "Test Token 2",
		Symbol:  "TK2",
	}

	tf_bank.SetDenomMetaData(ctx, denomMetadata1)
	tf_bank.SetDenomMetaData(ctx, denomMetadata2)

	queryPlugin := &tokenfactory.QueryPlugin{
		Bank: &tf_bank,
	}

	response := queryPlugin.AllDenomMetadata(ctx)

	expectedResponse := &bindings.AllDenomMetadataResponse{
		Metadatas: []banktypes.Metadata{
			{
				Description: "Test Token 1",
				DenomUnits: []*banktypes.DenomUnit{
					{Denom: "token1", Exponent: 6, Aliases: []string{"tk1", "t1"}},
				},
				Base:    "token1",
				Display: "TK1",
				Name:    "Test Token 1",
				Symbol:  "TK1",
			},
			{
				Description: "Test Token 2",
				DenomUnits: []*banktypes.DenomUnit{
					{Denom: "token2", Exponent: 6, Aliases: []string{"tk2", "t2"}},
				},
				Base:    "token2",
				Display: "TK2",
				Name:    "Test Token 2",
				Symbol:  "TK2",
			},
		},
	}

	actualJSON, err := json.Marshal(response)
	require.NoError(t, err)

	expectedJSON, err := json.Marshal(expectedResponse)
	require.NoError(t, err)

	require.JSONEq(t, string(expectedJSON), string(actualJSON), "AllDenomMetadata response does not match expected")
}

func TestCustomQuerier_AllBankDenomMetadata(t *testing.T) {

	db := dbm.NewMemDB()
	storeKey := types.NewKVStoreKey(banktypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, types.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())
	blockedAddrs := make(map[string]bool)
	authority := authtypes.NewModuleAddress(banktypes.ModuleName).String()
	mockAddressCodec := new(MockAddressCodec)
	accountKeeper := &MockAccountKeeper{}

	accountKeeper.On("AddressCodec").Return(mockAddressCodec)
	mockAddressCodec.On("StringToBytes", "cosmos1gwqac243g2z3vryqsev6acq965f9ttwhemeg7g").Return([]byte("some bytes"), nil)
	mockAddressCodec.On("BytesToString", []byte("some bytes")).Return("cosmos1gwqac243g2z3vryqsev6acq965f9ttwhemeg7g", nil)

	tf_bank := keeper.NewBaseKeeper(
		cdc,
		runtime.NewKVStoreService(storeKey),
		accountKeeper,
		blockedAddrs,
		authority,
		log.NewNopLogger(),
	)

	mockMessenger := new(MockMessenger)
	query := bindings.FactoryQuery{
		Bank: &bindings.BankQuery{
			AllDenomMetadata: &bindings.AllDenomMetadata{},
		},
	}
	customQueryPlugin := &tokenfactory.QueryPlugin{
		Bank: &tf_bank,
	}

	msgBytes, err := json.Marshal(query)
	require.NoError(t, err)

	fmt.Printf("Query Request: %s\n", string(msgBytes))

	expectedData := []byte(`{"metadatas":null}`)

	customQuerier := tokenfactory.CustomQuerier(customQueryPlugin)
	data, err := customQuerier(ctx, msgBytes)

	require.NoError(t, err)
	require.Equal(t, expectedData, data)

	mockMessenger.AssertExpectations(t)

}

func TestQueryPlugin_CustomQuerier_FindDenomMetadata(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := types.NewKVStoreKey(banktypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)
	ms.MountStoreWithDB(storeKey, types.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, logger)
	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())
	blockedAddrs := make(map[string]bool)
	authority := authtypes.NewModuleAddress(banktypes.ModuleName).String()
	accountKeeper := &MockAccountKeeper{}

	mockAddressCodec := new(MockAddressCodec)
	accountKeeper.On("AddressCodec").Return(mockAddressCodec)
	mockAddressCodec.On("StringToBytes", "cosmos1gwqac243g2z3vryqsev6acq965f9ttwhemeg7g").Return([]byte("some bytes"), nil)
	mockAddressCodec.On("BytesToString", []byte("some bytes")).Return("cosmos1gwqac243g2z3vryqsev6acq965f9ttwhemeg7g", nil)

	tf_bank := keeper.NewBaseKeeper(
		cdc,
		runtime.NewKVStoreService(storeKey),
		accountKeeper,
		blockedAddrs,
		authority,
		logger,
	)

	denomMetadata := banktypes.Metadata{
		Description: "Test Token",
		DenomUnits: []*banktypes.DenomUnit{
			{
				Denom:    "token1",
				Exponent: 6,
				Aliases:  []string{"tk1", "t1"},
			},
		},
		Base:    "token1",
		Display: "TK1",
		Name:    "Test Token",
		Symbol:  "TK1",
	}
	tf_bank.SetDenomMetaData(ctx, denomMetadata)

	queryPlugin := &tokenfactory.QueryPlugin{
		Bank: &tf_bank,
	}
	customQuerier := tokenfactory.CustomQuerier(queryPlugin)
	mockQuery := bindings.FactoryQuery{
		Bank: &bindings.BankQuery{
			FindDenomMetadata: &bindings.FindDenomMetadata{
				BaseDenom: "token1",
				Denom:     "token1",
			},
		},
	}

	mockQueryJSON, err := json.Marshal(mockQuery)
	require.NoError(t, err)

	resp, err := customQuerier(ctx, mockQueryJSON)
	require.NoError(t, err)

	expectedResponse := &bindings.FindDenomMetadataResponse{
		Description: "Test Token",
		Base:        "token1",
		Display:     "TK1",
		Name:        "Test Token",
		Symbol:      "TK1",
		Denom:       "token1",
		Exponent:    6,
		Aliases:     []string{"tk1", "t1"},
	}

	expectedJSON, err := json.Marshal(expectedResponse)
	require.NoError(t, err)

	require.JSONEq(t, string(expectedJSON), string(resp), "Querier response does not match expected")

	mockQueryNonExistent := bindings.FactoryQuery{
		Bank: &bindings.BankQuery{
			FindDenomMetadata: &bindings.FindDenomMetadata{
				BaseDenom: "nonexistent",
				Denom:     "nonexistent",
			},
		},
	}
	mockQueryNonExistentJSON, err := json.Marshal(mockQueryNonExistent)
	require.NoError(t, err)
	respNonExistent, err := customQuerier(ctx, mockQueryNonExistentJSON)
	require.Error(t, err)
	require.Contains(t, err.Error(), "failed to find denom metadata for nonexistent")
	require.Nil(t, respNonExistent)
}

func TestFindMetadataForDenom(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := types.NewKVStoreKey(banktypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)
	ms.MountStoreWithDB(storeKey, types.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, logger)
	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())
	blockedAddrs := make(map[string]bool)
	authority := authtypes.NewModuleAddress(banktypes.ModuleName).String()
	accountKeeper := &MockAccountKeeper{}

	mockAddressCodec := new(MockAddressCodec)
	accountKeeper.On("AddressCodec").Return(mockAddressCodec)
	mockAddressCodec.On("StringToBytes", "cosmos1gwqac243g2z3vryqsev6acq965f9ttwhemeg7g").Return([]byte("some bytes"), nil)
	mockAddressCodec.On("BytesToString", []byte("some bytes")).Return("cosmos1gwqac243g2z3vryqsev6acq965f9ttwhemeg7g", nil)
	denomMetadata := banktypes.Metadata{
		Description: "Test Token",
		DenomUnits: []*banktypes.DenomUnit{
			{
				Denom:    "token1",
				Exponent: 6,
				Aliases:  []string{"tk1", "t1"},
			},
		},
		Base:    "token1",
		Display: "TK1",
		Name:    "Test Token",
		Symbol:  "TK1",
	}
	tf_bank := keeper.NewBaseKeeper(
		cdc,
		runtime.NewKVStoreService(storeKey),
		accountKeeper,
		blockedAddrs,
		authority,
		logger,
	)

	tf_bank.SetDenomMetaData(ctx, denomMetadata)

	queryPlugin := &tokenfactory.QueryPlugin{
		Bank: &tf_bank,
	}

	query := bindings.FactoryQuery{
		Bank: &bindings.BankQuery{
			FindMetadataForDenom: &bindings.FindMetadataForDenom{
				Denom: "token1",
			},
		},
	}

	queryJSON, err := json.Marshal(query)
	require.NoError(t, err)
	customQuerier := tokenfactory.CustomQuerier(queryPlugin)
	resp, err := customQuerier(ctx, queryJSON)
	require.NoError(t, err)
	expectedResponse := &bindings.FindDenomMetadataResponse{
		Description: "Test Token",
		Base:        "token1",
		Display:     "TK1",
		Name:        "Test Token",
		Symbol:      "TK1",
		Denom:       "token1",
		Exponent:    6,
		Aliases:     []string{"tk1", "t1"},
	}
	expectedJSON, err := json.Marshal(expectedResponse)
	require.NoError(t, err)

	require.JSONEq(t, string(expectedJSON), string(resp), "Querier response does not match expected")
	queryNonExistent := bindings.FactoryQuery{
		Bank: &bindings.BankQuery{
			FindMetadataForDenom: &bindings.FindMetadataForDenom{
				Denom: "nonexistent",
			},
		},
	}
	queryNonExistentJSON, err := json.Marshal(queryNonExistent)
	require.NoError(t, err)
	respNonExistent, err := customQuerier(ctx, queryNonExistentJSON)
	require.Error(t, err)
	require.Contains(t, err.Error(), "failed to find metadata for nonexistent")
	require.Nil(t, respNonExistent)
}

func TestUnknownBankQueryVariant(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := types.NewKVStoreKey(banktypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)
	ms.MountStoreWithDB(storeKey, types.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, logger)
	queryPlugin := &tokenfactory.QueryPlugin{
		Bank: nil,
	}
	query := bindings.FactoryQuery{
		Bank: &bindings.BankQuery{},
	}

	queryJSON, err := json.Marshal(query)
	require.NoError(t, err)

	customQuerier := tokenfactory.CustomQuerier(queryPlugin)
	resp, err := customQuerier(ctx, queryJSON)

	require.Error(t, err)
	require.IsType(t, wasmvmtypes.UnsupportedRequest{}, err)
	require.Contains(t, err.Error(), "unknown bank query variant")
	require.Nil(t, resp)
}

func TestQueryPlugin_DenomMetadata(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := types.NewKVStoreKey(banktypes.StoreKey)
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)
	ms.MountStoreWithDB(storeKey, types.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, logger)
	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())
	blockedAddrs := make(map[string]bool)
	authority := authtypes.NewModuleAddress(banktypes.ModuleName).String()
	accountKeeper := &MockAccountKeeper{}
	mockAddressCodec := new(MockAddressCodec)

	accountKeeper.On("AddressCodec").Return(mockAddressCodec)
	mockAddressCodec.On("StringToBytes", "cosmos1gwqac243g2z3vryqsev6acq965f9ttwhemeg7g").Return([]byte("some bytes"), nil)
	mockAddressCodec.On("BytesToString", []byte("some bytes")).Return("cosmos1gwqac243g2z3vryqsev6acq965f9ttwhemeg7g", nil)
	tf_bank := keeper.NewBaseKeeper(
		cdc,
		runtime.NewKVStoreService(storeKey),
		accountKeeper,
		blockedAddrs,
		authority,
		logger,
	)
	denomMetadata1 := banktypes.Metadata{
		Description: "Test Token 1",
		DenomUnits: []*banktypes.DenomUnit{
			{
				Denom:    "token1",
				Exponent: 6,
				Aliases:  []string{"tk1", "t1"},
			},
		},
		Base:    "token1",
		Display: "TK1",
		Name:    "Test Token 1",
		Symbol:  "TK1",
	}

	tf_bank.SetDenomMetaData(ctx, denomMetadata1)
	queryPlugin := &tokenfactory.QueryPlugin{
		Bank: &tf_bank,
	}
	response, _ := queryPlugin.DenomMetadata(ctx, "token1")
	expectedResponse := &bindings.DenomMetadataResponse{
		Metadata: banktypes.Metadata{
			Description: "Test Token 1",
			DenomUnits: []*banktypes.DenomUnit{
				{Denom: "token1", Exponent: 6, Aliases: []string{"tk1", "t1"}},
			},
			Base:    "token1",
			Display: "TK1",
			Name:    "Test Token 1",
			Symbol:  "TK1",
		},
	}

	actualJSON, err := json.Marshal(response)
	require.NoError(t, err)

	expectedJSON, err := json.Marshal(expectedResponse)
	require.NoError(t, err)
	t.Logf("Actual Response: %s", string(actualJSON))
	t.Logf("Expected Response: %s", string(expectedJSON))
	require.JSONEq(t, string(expectedJSON), string(actualJSON), "DenomMetadata response does not match expected")
}

type MockFeegrantKeeper struct {
	mock.Mock
}

func TestCustomQuerier_Feegrant(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := types.NewKVStoreKey("key")
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, types.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	registry := codectypes.NewInterfaceRegistry()
	feegrant.RegisterInterfaces(registry)
	cdc := codec.NewProtoCodec(registry)
	accountKeeper := &MockAccountKeeper{}
	mockAddressCodec := new(MockAddressCodec)

	accountKeeper.On("AddressCodec").Return(mockAddressCodec)
	mockAddressCodec.On("StringToBytes", "cosmos1gwqac243g2z3vryqsev6acq965f9ttwhemeg7g").Return([]byte("some bytes"), nil)
	mockAddressCodec.On("BytesToString", []byte("some bytes")).Return("cosmos1gwqac243g2z3vryqsev6acq965f9ttwhemeg7g", nil)

	tf := feegrantkeeper.NewKeeper(cdc, runtime.NewKVStoreService(storeKey), accountKeeper)

	mockMessenger := new(MockMessenger)
	sampleAcctAddr := sample.AccAddress()
	query := bindings.FactoryQuery{
		Feegrant: &bindings.FeegrantQuery{
			FeeBasicAllowance: &bindings.FeeBasicAllowance{
				Granter: sampleAcctAddr,
				Grantee: sampleAcctAddr,
			},
		},
	}
	customQueryPlugin := &tokenfactory.QueryPlugin{
		Feegrant: &tf,
	}

	grant_addr, err := sdk.AccAddressFromBech32(sampleAcctAddr)
	require.NoError(t, err)
	tf = tf.SetBankKeeper(MockFeegrantBankKeeper{})
	accountKeeper.On("NewAccountWithAddress", ctx, grant_addr).Return((*authtypes.BaseAccount)(nil))
	accountKeeper.On("SetAccount", ctx, (*authtypes.BaseAccount)(nil)).Return(nil)
	accountKeeper.On("GetAccount", ctx, grant_addr).Return((*authtypes.BaseAccount)(nil))
	tn := time.Now()
	tf.GrantAllowance(ctx, grant_addr, grant_addr, &feegrant.BasicAllowance{
		SpendLimit: sdk.NewCoins(sdk.NewInt64Coin("stake", 1000)),
		Expiration: &tn,
	})

	msgBytes, err := json.Marshal(query)
	require.NoError(t, err)

	expectedData := []byte(
		fmt.Sprintf("{\"allowance\":{\"granter\":\"%s\",\"grantee\":\"%s\",\"allowance\":{\"denom\":\"stake\",\"amount\":\"1000\"},\"expiration\":\"%s\"}}",
			sampleAcctAddr, sampleAcctAddr, tn.UTC().String()),
	)
	customQuerier := tokenfactory.CustomQuerier(customQueryPlugin)
	data, err := customQuerier(ctx, msgBytes)

	require.NoError(t, err)
	require.Equal(t, expectedData, data)

	mockMessenger.AssertExpectations(t)
}

/*
func TestCustomQuerier_Feegrant(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := types.NewKVStoreKey("key")
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, types.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	registry := codectypes.NewInterfaceRegistry()
	feegrant.RegisterInterfaces(registry)
	cdc := codec.NewProtoCodec(registry)
	accountKeeper := &MockAccountKeeper{}
	mockAddressCodec := new(MockAddressCodec)

	accountKeeper.On("AddressCodec").Return(mockAddressCodec)
	mockAddressCodec.On("StringToBytes", "cosmos1gwqac243g2z3vryqsev6acq965f9ttwhemeg7g").Return([]byte("some bytes"), nil)
	mockAddressCodec.On("BytesToString", []byte("some bytes")).Return("cosmos1gwqac243g2z3vryqsev6acq965f9ttwhemeg7g", nil)

	tf := feegrantkeeper.NewKeeper(cdc, runtime.NewKVStoreService(storeKey), accountKeeper)

	mockMessenger := new(MockMessenger)
	sampleAcctAddr := sample.AccAddress()
	query := bindings.FactoryQuery{
		Feegrant: &bindings.FeegrantQuery{
			FeeBasicAllowance: &bindings.FeeBasicAllowance{
				Granter: sampleAcctAddr,
				Grantee: sampleAcctAddr,
			},
		},
	}
	customQueryPlugin := &tokenfactory.QueryPlugin{
		Feegrant: &tf,
	}

	grant_addr, err := sdk.AccAddressFromBech32(sampleAcctAddr)
	require.NoError(t, err)
	tf = tf.SetBankKeeper(MockFeegrantBankKeeper{})
	accountKeeper.On("SetAccount", ctx, nil).Return(nil)
	tn := time.Now()
	tf.GrantAllowance(ctx, grant_addr, grant_addr, &feegrant.BasicAllowance{
		SpendLimit: sdk.NewCoins(sdk.NewInt64Coin("stake", 1000)),
		Expiration: &tn,
	})

	msgBytes, err := json.Marshal(query)
	require.NoError(t, err)

	expectedData := []byte(
		fmt.Sprintf("{\"allowance\":{\"granter\":\"%s\",\"grantee\":\"%s\",\"allowance\":{\"denom\":\"stake\",\"amount\":\"1000\"},\"expiration\":\"%s\"}}",
			sampleAcctAddr, sampleAcctAddr, tn.UTC().String()),
	)

	customQuerier := tokenfactory.CustomQuerier(customQueryPlugin)
	data, err := customQuerier(ctx, msgBytes)

	require.NoError(t, err)
	require.Equal(t, expectedData, data)

	mockMessenger.AssertExpectations(t)
}
*/

func TestCustomQuerier_FeegrantUnsupported(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := types.NewKVStoreKey("key")
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)
	ms.MountStoreWithDB(storeKey, types.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())
	accountKeeper := &MockAccountKeeper{}
	mockAddressCodec := new(MockAddressCodec)

	accountKeeper.On("AddressCodec").Return(mockAddressCodec)
	mockAddressCodec.On("StringToBytes", "cosmos1gwqac243g2z3vryqsev6acq965f9ttwhemeg7g").Return([]byte("some bytes"), nil)
	mockAddressCodec.On("BytesToString", []byte("some bytes")).Return("cosmos1gwqac243g2z3vryqsev6acq965f9ttwhemeg7g", nil)

	tf := feegrantkeeper.NewKeeper(cdc, runtime.NewKVStoreService(storeKey), accountKeeper)
	mockMessenger := new(MockMessenger)
	query := bindings.FactoryQuery{
		Feegrant: &bindings.FeegrantQuery{},
	}

	customQueryPlugin := &tokenfactory.QueryPlugin{
		Feegrant: &tf,
	}

	msgBytes, err := json.Marshal(query)
	require.NoError(t, err)

	expectedErrorResponse := "unsupported request: unknown feegrant query variant"
	customQuerier := tokenfactory.CustomQuerier(customQueryPlugin)
	_, err = customQuerier(ctx, msgBytes)
	require.Error(t, err)
	require.Equal(t, expectedErrorResponse, err.Error())

	mockMessenger.AssertExpectations(t)
}
func TestCustomQuerier_Unsupported(t *testing.T) {
	db := dbm.NewMemDB()
	storeKey := types.NewKVStoreKey("key")
	logger := log.NewNopLogger()
	storeMetrics := metrics.NewNoOpMetrics()

	ms := store.NewCommitMultiStore(db, logger, storeMetrics)

	ms.MountStoreWithDB(storeKey, types.StoreTypeIAVL, db)
	err := ms.LoadLatestVersion()
	require.NoError(t, err)

	ctx := sdk.NewContext(ms, tmproto.Header{}, false, log.NewNopLogger())

	ownerAddr := sample.AccAddress()

	owner := tokenfactorymoduletypes.Owner{Address: ownerAddr}

	cdc := codec.NewProtoCodec(codectypes.NewInterfaceRegistry())

	var ps paramtypes.Subspace

	var tfbankKeeper tokenfactorymoduletypes.BankKeeper

	tf := tokenfactorymodulekeeper.NewKeeper(cdc, storeKey, ps, tfbankKeeper, runtime.NewKVStoreService(storeKey))

	tf.SetOwner(ctx, owner)

	mockMessenger := new(MockMessenger)
	query := bindings.FactoryQuery{}
	customQueryPlugin := &tokenfactory.QueryPlugin{}

	msgBytes, err := json.Marshal(query)
	require.NoError(t, err)

	expectedErrorResponse := "unsupported request: unknown factory query variant"
	customQuerier := tokenfactory.CustomQuerier(customQueryPlugin)
	_, err = customQuerier(ctx, msgBytes)

	require.Error(t, err)
	require.Equal(t, expectedErrorResponse, err.Error())

	mockMessenger.AssertExpectations(t)
}

type MockFeegrantBankKeeper struct {
}

func (m MockFeegrantBankKeeper) SpendableCoins(ctx context.Context, addr sdk.AccAddress) sdk.Coins {
	return sdk.NewCoins(sdk.NewInt64Coin("stake", 1000))
}

func (m MockFeegrantBankKeeper) SendCoinsFromAccountToModule(ctx context.Context, senderAddr sdk.AccAddress, recipientModule string, amt sdk.Coins) error {
	return nil
}

func (m MockFeegrantBankKeeper) BlockedAddr(addr sdk.AccAddress) bool {
	return false
}
