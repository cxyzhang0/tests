package network

import (
	"os"
	"path/filepath"
	"testing"

	"github.com/stretchr/testify/require"
)

func TestWriteFile(t *testing.T) {
	dir := "test_dir"
	name := "test_file.txt"
	contents := []byte("This is a test content.")
	err := writeFile(name, dir, contents)
	require.NoError(t, err, "writeFile should not return an error")
	filePath := filepath.Join(dir, name)
	_, err = os.Stat(filePath)
	require.NoError(t, err, "The file should exist")
	readContents, err := os.ReadFile(filePath)
	require.NoError(t, err, "Error reading the file")
	require.Equal(t, contents, readContents, "The file contents should match")
	err = os.RemoveAll(dir)
	require.NoError(t, err, "Error cleaning up test files")
}
