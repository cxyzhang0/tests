package app

import (
	corestore "cosmossdk.io/core/store"
	errorsmod "cosmossdk.io/errors"
	circuitante "cosmossdk.io/x/circuit/ante"
	wasmkeeper "github.com/CosmWasm/wasmd/x/wasm/keeper"
	wasmtypes "github.com/CosmWasm/wasmd/x/wasm/types"
	"github.com/cosmos/cosmos-sdk/codec/types"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/cosmos/cosmos-sdk/x/auth/ante"
	govtypes "github.com/cosmos/cosmos-sdk/x/gov/types"
	ibcante "github.com/cosmos/ibc-go/v10/modules/core/ante"
	ibckeeper "github.com/cosmos/ibc-go/v10/modules/core/keeper"
	tferrors "github.com/wfblockchain/coreblockchain/v2/app/errors"
	"github.com/wfblockchain/coreblockchain/v2/x/poas"
	"github.com/wfblockchain/coreblockchain/v2/x/tokenfactory"
	tokenfactorykeeper "github.com/wfblockchain/coreblockchain/v2/x/tokenfactory/keeper"
)

type HandlerOptions struct {
	ante.HandlerOptions
	CircuitKeeper         circuitante.CircuitBreaker
	tokenFactoryKeeper    *tokenfactorykeeper.Keeper
	IBCKeeper             *ibckeeper.Keeper
	WasmConfig            *wasmtypes.NodeConfig //*wasm.Config is deprecated; use *wasmtypes.NodeConfig instead
	TXCounterStoreService corestore.KVStoreService
	interfaceRegistry     types.InterfaceRegistry
}

func NewAnteHandler(options HandlerOptions) (sdk.AnteHandler, error) {
	if options.AccountKeeper == nil {
		return nil, errorsmod.Wrap(tferrors.ErrLogic, "account keeper is required for AnteHandler")
	}
	if options.BankKeeper == nil {
		return nil, errorsmod.Wrap(tferrors.ErrLogic, "bank keeper is required for AnteHandler")
	}
	if options.SignModeHandler == nil {
		return nil, errorsmod.Wrap(tferrors.ErrLogic, "sign mode handler is required for AnteHandler")
	}
	if options.IBCKeeper == nil {
		return nil, errorsmod.Wrap(tferrors.ErrLogic, "IBC keeper is required for AnteHandler")
	}

	anteDecorators := []sdk.AnteDecorator{
		ante.NewSetUpContextDecorator(), // outermost AnteDecorator. SetUpContext must be called first

		wasmkeeper.NewLimitSimulationGasDecorator(options.WasmConfig.SimulationGasLimit), // after setup context to enforce limits early
		wasmkeeper.NewCountTXDecorator(options.TXCounterStoreService),

		// todo: test these two. for some reason, they were removed in the recent codebase as of 2025-7-15.
		//	 compare these with those in circlefin fiattokenfactory.
		tokenfactory.NewIsPausedDecorator(options.tokenFactoryKeeper),
		tokenfactory.NewIsBlacklistedDecorator(options.tokenFactoryKeeper),

		circuitante.NewCircuitBreakerDecorator(options.CircuitKeeper), // gaia does not have circuit breaker decorator.

		ante.NewExtensionOptionsDecorator(options.ExtensionOptionChecker),
		ante.NewValidateBasicDecorator(),
		ante.NewTxTimeoutHeightDecorator(),
		ante.NewValidateMemoDecorator(options.AccountKeeper),
		ante.NewConsumeGasForTxSizeDecorator(options.AccountKeeper),

		// note: gaia has a gov vote decorator. do we need it?

		// gaia does not have deduct fee decorator. is this related to feegrant? we need feegrant.
		ante.NewDeductFeeDecorator(options.AccountKeeper, options.BankKeeper, options.FeegrantKeeper, options.TxFeeChecker),

		ante.NewSetPubKeyDecorator(options.AccountKeeper), // SetPubKeyDecorator must be called before all signature verification decorators
		ante.NewValidateSigCountDecorator(options.AccountKeeper),
		ante.NewSigGasConsumeDecorator(options.AccountKeeper, options.SigGasConsumer),
		ante.NewSigVerificationDecorator(options.AccountKeeper, options.SignModeHandler),
		ante.NewIncrementSequenceDecorator(options.AccountKeeper),
		ibcante.NewRedundantRelayDecorator(options.IBCKeeper),

		poas.NewPoASDecorator(options.AccountKeeper.GetModuleAddress(govtypes.ModuleName), options.interfaceRegistry),

		// note: gaia has a fee market check decorator.
	}

	return sdk.ChainAnteDecorators(anteDecorators...), nil
}
