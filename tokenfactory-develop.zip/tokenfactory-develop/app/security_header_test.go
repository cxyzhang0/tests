package app

import (
	"errors"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"sync"
	"testing"

	"cosmossdk.io/log"
	"github.com/stretchr/testify/require"
)

type capturingLogger struct {
	lastMsg   string
	lastKVs   []interface{}
	warnCalls int
}

func (l *capturingLogger) Debug(msg string, keyVals ...interface{}) {}
func (l *capturingLogger) Info(msg string, keyVals ...interface{})  {}
func (l *capturingLogger) Error(msg string, keyVals ...interface{}) {}
func (l *capturingLogger) With(keyVals ...interface{}) log.Logger   { return l }
func (l *capturingLogger) Impl() any                                { return l }

func (l *capturingLogger) Warn(msg string, keyVals ...interface{}) {
	l.warnCalls++
	l.lastMsg = msg
	l.lastKVs = keyVals
}

func TestSecurityHeadersMiddleware_LogsWarnOnMissingConfig(t *testing.T) {
	securityHeadersOnce = sync.Once{}
	securityHeaders = nil
	securityHeadersErr = nil

	logger := &capturingLogger{}
	configDir := t.TempDir() // no `security_headers.toml` present

	calledNext := false
	next := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		calledNext = true
		w.WriteHeader(http.StatusOK)
	})

	mw := SecurityHeadersMiddleware(logger, configDir)
	h := mw(next)

	req := httptest.NewRequest(http.MethodGet, "http://example.com", nil)
	rr := httptest.NewRecorder()
	h.ServeHTTP(rr, req)

	require.True(t, calledNext)
	require.Equal(t, 1, logger.warnCalls)
	require.Equal(t, "could not load security headers config", logger.lastMsg)

	require.GreaterOrEqual(t, len(logger.lastKVs), 4)
	require.Equal(t, "file", logger.lastKVs[0])
	require.Equal(t, securityHeadersFile, logger.lastKVs[1])
	require.Equal(t, "err", logger.lastKVs[2])

	errVal, ok := logger.lastKVs[3].(error)
	require.True(t, ok)
	require.True(t, errors.Is(errVal, errVal)) // type check; actual error text/path varies by OS
	require.Contains(t, errVal.Error(), filepath.Base(securityHeadersFile))
}
