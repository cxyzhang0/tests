package app

import (
	"context"
	storetypes "cosmossdk.io/store/types"
	upgradetypes "cosmossdk.io/x/upgrade/types"
	"github.com/cosmos/cosmos-sdk/types/module"
)

// UpgradeName defines the on-chain upgrade name for the sample SimApp upgrade
// multidenom-v1tov2.
//
// NOTE: This upgrade defines a reference implementation of what an upgrade
// could look like when a module (or modules) is migrating from one version to another.

const UpgradeName = "multidenom-v1tov2"

func (app App) RegisterUpgradeHandlers() {
	app.UpgradeKeeper.SetUpgradeHandler(
		UpgradeName,
		func(ctx context.Context, _ upgradetypes.Plan, fromVM module.VersionMap) (module.VersionMap, error) {
			return app.mm.RunMigrations(ctx, app.Configurator(), fromVM)
		},
	)

	// Set any new modules, renamed modules, and/or deleted modules introduced in the upgrade
	// Q: Is rename done here?
	upgradeInfo, err := app.UpgradeKeeper.ReadUpgradeInfoFromDisk()
	if err != nil {
		panic(err)
	}
	if upgradeInfo.Name == UpgradeName && !app.UpgradeKeeper.IsSkipHeight(upgradeInfo.Height) {
		storeUpgrades := storetypes.StoreUpgrades{
			//Added: []string{
			//	newmoduletypes.ModuleName,
			//},
			//Renamed: []StoreRename{
			//	storeRename,
			//},
			//Deleted: []string{
			//	deletedmoduletypes.ModuleName,
			//},
		}

		// configure store loader that checks if version == upgradeHeight and applies store upgrades
		app.SetStoreLoader(upgradetypes.UpgradeStoreLoader(upgradeInfo.Height, &storeUpgrades))
	}
}
