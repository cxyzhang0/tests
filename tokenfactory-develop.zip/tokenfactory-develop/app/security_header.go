package app

import (
	"net/http"
	"os"
	"path/filepath"
	"sync"

	"cosmossdk.io/log"
	"github.com/pelletier/go-toml"
)

const securityHeadersFile = "security_headers.toml"

var (
	securityHeaders     map[string]string
	securityHeadersOnce sync.Once
	securityHeadersErr  error
)

func loadSecurityHeaders(configDir string) (map[string]string, error) {
	securityHeadersOnce.Do(func() {
		path := filepath.Join(configDir, securityHeadersFile)
		file, err := os.Open(path)
		if err != nil {
			securityHeadersErr = err
			return
		}
		defer file.Close()

		headers := make(map[string]string)
		tree, err := toml.LoadReader(file)
		if err != nil {
			securityHeadersErr = err
			return
		}
		for _, key := range tree.Keys() {
			headers[key] = tree.Get(key).(string)
		}
		securityHeaders = headers
	})
	return securityHeaders, securityHeadersErr
}

func SecurityHeadersMiddleware(logger log.Logger, configDir string) func(http.Handler) http.Handler {
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			headers, err := loadSecurityHeaders(configDir)
			if err != nil {
				logger.Warn("could not load security headers config", "file", securityHeadersFile, "err", err)
			} else {
				for k, v := range headers {
					w.Header().Set(k, v)
				}
			}
			next.ServeHTTP(w, r)
		})
	}
}

/*
func SecurityHeadersMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		homeDir := DefaultNodeHome
		configDir := filepath.Join(homeDir, "config")
		headers, err := loadSecurityHeaders(configDir)

		if err != nil {
			// panic if error
			panic("error loading config " + securityHeadersFile + ": " + err.Error())
		}

		//if err == nil {
		for k, v := range headers {
			w.Header().Set(k, v)
		}
		//}
		next.ServeHTTP(w, r)
	})
}
*/
