cp tokenfactory/module/v1/module.proto_for_depinject tokenfactory/module/v1/module.proto
buf generate --template buf.gen.pulsar.yaml --path tokenfactory/module/v1/module.proto
rm tokenfactory/module/v1/module.proto
