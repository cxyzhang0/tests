## Add security headers to CometBFT RPC (default 26657) and Cosmos RPC (default 1317) endpoints
We have two options: code changes and nginx reverse proxy with only config changes.
### code changes
This would involve modifying the CometBFT and the application codebases to inject middleware for adding security headers to HTTP responses.   
The former would require forking the CometBFT repo, which is not a sustainable approach because of maintenance complexity. So that is not done.   
For the latter, we modified RegisterAPIRoutes by using a middleware in the router. The headers to be added are from a configuration file (see security_headers.toml) which is to be copied the validator's config folder. Note that missing this file will result in a warning in the log.  
So we only have a partial solution, namely, only the application's RPC port (default 1317) will have the security headers added.

### nginx reverse proxy
This will cover both CometBFT and application RPC endpoints. nginx.conf is provided in this folder for local dev testing and nginx.md has the scripts. The validator's config.toml and app.toml need to be modified to bind the RPC endpoints to localhost (127.0.0.1) only so that they are not directly exposed and the corresponding ports need to be consistent with those set for proxy_pass in nginx.conf.
For production deployment, the nginx configuration may need tls cert path and private key since the RPC endpoints are typically exposed via https (see /opt/homebrew/etc/nginx/nginx.conf). Also, error log, access_log, and pid files may need to be specified to location(s) accessible by the user/account running nginx because the default locations may not be writable.
