## nginx wiht custom config file
```shell
nginx -c $HOME/Project/go/cosmos/noblefork/security_header/nginx.conf
 
# test
curl -I http://localhost:1317/status
curl -I http://localhost:1317

curl -I http://localhost:26657/status
curl -I http://localhost:26657

```

## nginx with homebrew - default
```shell
#The default port has been set in /opt/homebrew/etc/nginx/nginx.conf to 8080 so that
#nginx can run without sudo.

#nginx will load all files in /opt/homebrew/etc/nginx/servers/.

#To start nginx now and restart at login:
brew services start nginx
#Or, if you don't want/need a background service you can just run:
/opt/homebrew/opt/nginx/bin/nginx -g daemon\ off\;

cat /opt/homebrew/etc/nginx/nginx.conf 

```