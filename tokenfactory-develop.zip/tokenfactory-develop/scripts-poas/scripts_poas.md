## evn
```shell
export BINARY="./bin/tfd"
export CHAIN_ID="tokenfactory-1"
export HOME_DIR="./play_sh/$CHAIN_ID"
export KEYRING="--keyring-backend=test"
export TIMEOUT_COMMIT="1200ms"
alias BINARY="$BINARY --home=$HOME_DIR"
export FLAGS=($KEYRING --chain-id=$CHAIN_ID --home=$HOME_DIR --node tcp://localhost:26657 --gas-prices "0.001uwfUSD" --gas "auto" --gas-adjustment 2.0 --yes)
export FLAGS_NO_AUTO=($KEYRING --chain-id=$CHAIN_ID --home=$HOME_DIR --node tcp://localhost:26657 --gas-prices "0.001uwfUSD" --gas-adjustment 2.0 --yes)

export VALIDATOR=$(BINARY keys show validator -a $KEYRING) && echo $VALIDATOR
export VALIDATOR2=$(BINARY keys show validator2 -a $KEYRING) && echo $VALIDATOR2
export USER1_ADDR=$(BINARY keys show user1 -a $KEYRING) && echo $USER1_ADDR
export USER2_ADDR=$(BINARY keys show user2 -a $KEYRING) && echo $USER2_ADDR

# $BINARY debug addr $VALIDATOR
export VALIDATOR_val_ADDR=wfvaloper1h4vjafjrjkug38q434ateawrrejup0l64ffgsr
export VALIDATOR2_val_ADDR=wfvaloper1h9umn3sv5m7ks0w9vpyuecrjfpevpk2tvreqau

```

## Fees and Balances
```shell
BINARY q bank total-supply
BINARY q bank balances $USER1_ADDR
BINARY q bank balances $USER2_ADDR
BINARY q bank balances $VALIDATOR
BINARY tx bank send user1 $USER2_ADDR 1000uwfUSD $FLAGS
BINARY q tx 68BC3C9346E0B78464F26D9444D86DC697A380DDF1C53BEA5C64E73FA34E5A05 -o json | jq '{tx: .tx.body.messages, gas_limit: .gas_wanted, gas_used: .gas_used, fee: .tx.auth_info.fee.amount[0]}'
BINARY q tx 535FE9459F5F8728935ADD5E091BAF4AC5A5807F146CA6D8D662B123BAC36352 -o json | jq '{tx: .tx.body.messages, gas_limit: .gas_wanted, gas_used: .gas_used, fee: .tx.auth_info.fee.amount[0], raw_log: .raw_log, logs: .logs}'

# modules
MODULE_ACCOUNTS=$(BINARY q auth accounts -o json | jq -r '.accounts[] | select(.type=="/cosmos.auth.v1beta1.ModuleAccount") | .value.address')
#MODULE_ACCOUNTS=$(BINARY q auth accounts -o json | jq -r '.accounts[] | select(.type=="/cosmos.auth.v1beta1.ModuleAccount" or .type=="/cosmos.auth.v1beta1.BaseAccount") | .value.address')
MODULE_TOTAL=0
echo "$MODULE_ACCOUNTS" | while read -r addr; do
  BAL=$(BINARY q bank balances "$addr" -o json | jq -r '.balances[0].amount // 0')
  echo "Module account: $addr, Balance: $BAL"
  MODULE_TOTAL=$((MODULE_TOTAL + BAL))
done
echo "Total balance of all module accounts: $MODULE_TOTAL"

BINARY q distribution validator-distribution-info $VALIDATOR_val_ADDR # validator acc1

BINARY tx distribution withdraw-rewards $VALIDATOR_val_ADDR $FLAGS --from validator --commission
BINARY q tx FA249AC0E1C6CDD016756168CD4E97B0B23FF37BE534BE2629CAA4CB79B43E6A -o json | jq '{tx: .tx.body.messages, gas_limit: .gas_wanted, gas_used: .gas_used, fee: .tx.auth_info.fee.amount[0]}'

```

## cli create-validator should fail
> NOTE: do not use --gas "auto" here because our ante handler will preempt gas estimation via simulation.
```shell
BINARY tx staking create-validator ./poas/validator2_file.json "${FLAGS_NO_AUTO[@]}" --from=validator2
# create_validator.json is the wrong format: BINARY tx staking create-validator ./poas/create_validator2.json "${FLAGS_NO_AUTO[@]}" --from=validator2 

```

## cli add-validator should fail
> NOTE: do not use --gas "auto" here because our ante handler will preempt gas estimation via simulation.
```shell
BINARY tx poas gov-add-validator "${FLAGS_NO_AUTO[@]}" --from=validator2 --log_level trace --trace

```

## cli delegate should fail
> NOTE: do not use --gas "auto" here because our ante handler will preempt gas estimation via simulation.
```shell
BINARY tx staking delegate $VALIDATOR_val_ADDR 1000uwfUSD "${FLAGS_NO_AUTO[@]}" --from=validator

```

## cli gov-delegate should fail
> NOTE: do not use --gas "auto" here because our ante handler will preempt gas estimation via simulation.
```shell
BINARY tx poas gov-delegate "${FLAGS_NO_AUTO[@]}" --from=validator2 --log_level trace --trace

```

## PoA validator management - add a new validator via governance
> Recommended: the proposer, validator_address are from the same key as the new validator's. authority is the governance module address.
> - there used to be a delegate_address which is deprecated. so delegate is taken from the account corresponding to validator_address
> In reality, the proposer can be any account.
```shell
BINARY q gov params
# proposal to add validator2, proposer is from validator2 key
BINARY tx gov submit-proposal ./poas/proposal_gov_add_validator2.json $FLAGS --from=validator2
BINARY q tx 24F64E4DF1BC8551C60D72848070A2C90EF277C5F61B72CBF65E91BEF7DE7EA8 -o json | jq '{tx: .tx.body.messages, gas_limit: .gas_wanted, gas_used: .gas_used, fee: .tx.auth_info.fee.amount[0], raw_log: .raw_log, logs: .logs}'

BINARY q gov proposal 1

# vote for the proposal
BINARY tx gov vote 1 yes $FLAGS --from=validator
BINARY q tx 0C7729A09ED0211077960B0157B5A1F057AAAD1C05A4416F4A6093E59A7FB42E -o json | jq '{tx: .tx.body.messages, gas_limit: .gas_wanted, gas_used: .gas_used, fee: .tx.auth_info.fee.amount[0], raw_log: .raw_log, logs: .logs}'
BINARY q gov tally 1

BINARY q consensus comet validator-set # 2 -> 1
BINARY q staking validators --output json # 2

# to see the events emitted, need height - search log for proposal tallied expedited=true module=x/gov proposal=1 results=passed status=PROPOSAL_STATUS_PASSED title="Add new validator"
BINARY q block-results 560 --output json | jq '.finalize_block_events[] | select(.type=="gov_add_validator")'
BINARY q block-results 560 --output json | jq '.finalize_block_events[] | select(.type=="create_validator")'

BINARY q staking params
BINARY q slashing params
BINARY q slashing signing-infos
BINARY q slashing signing-info '{"@type":"/cosmos.crypto.ed25519.PubKey","key":"pl3Q8OQwtC7G2dSqRqsUrO5VZul7l40I+MKUcejqRsg="}' 

# for some reason, cannot unjail - the following comes back silently without error but no effect
BINARY tx slashing unjail --from $validator2 $FLAGS_NO_AUTO --log_level trace --trace
BINARY tx slashing unjail --from $validator2 $FLAGS 

BINARY tx slashing unjail --from $validator2 --keyring-backend=test --chain-id=tokenfactory-1 --home=./play_sh/tokenfactory-1 --node tcp://localhost:26657

# proposal to add validator2. proposer is from validator key
BINARY q bank balances $VALIDATOR 
# 900000000
BINARY tx gov submit-proposal ./poas/proposal_gov_add_validator2.json $FLAGS --from=validator
BINARY q tx FA5BB788CEE907405CA7A997CBECD70B5D728F4C51E3970EB212A69B5A88E89D -o json | jq '{tx: .tx.body.messages, gas_limit: .gas_wanted, gas_used: .gas_used, fee: .tx.auth_info.fee.amount[0], raw_log: .raw_log, logs: .logs}'
BINARY q bank balances $VALIDATOR 
# 897999638 (-2000379 deposit)
BINARY q gov proposal 1
BINARY tx gov vote 1 yes $FLAGS --from=validator
BINARY q tx 7AAC84649475889A5CDFEE4CC3F86F5813B19E721CA8F338D4AA8F6BD9BA3843 -o json | jq '{tx: .tx.body.messages, gas_limit: .gas_wanted, gas_used: .gas_used, fee: .tx.auth_info.fee.amount[0], raw_log: .raw_log, logs: .logs}'
BINARY q gov tally 1
BINARY q bank balances $VALIDATOR 
# 897999561

# after vote passed
BINARY q bank balances $VALIDATOR
# 899999561 (+2000000 deposit)
BINARY q bank balances $VALIDATOR2
# 999000000 (-1000000 self-delegate)
```

## PoA validator management - delegate
> Recommended: the proposer, delegator_address and validator_address are from the same key as the validator's. authority is the governance module address.
> In reality, the proposer can be any account, but the delegator_address can be any account as long as it has enough balance to cover the delegation.
> - That is fine since the proposal will be reviewed/validated by every validator before voting and the validators can apply their own rules.  
> Below are different test cases.
```shell
BINARY q gov params
# proposal to delegate 1000000uwfUSD from validator to validator
BINARY tx gov submit-proposal ./poas/proposal_gov_delegate.json $FLAGS --from=validator
BINARY q tx E4CC2126E007E24267F45572579823E20A88070D6DF530ECE7778ACA432D12A0 -o json | jq '{tx: .tx.body.messages, gas_limit: .gas_wanted, gas_used: .gas_used, fee: .tx.auth_info.fee.amount[0]}'

BINARY q gov proposal 1

# vote for the proposal
BINARY tx gov vote 1 yes $FLAGS --from=validator
BINARY q tx 7AAC84649475889A5CDFEE4CC3F86F5813B19E721CA8F338D4AA8F6BD9BA3843 -o json | jq '{tx: .tx.body.messages, gas_limit: .gas_wanted, gas_used: .gas_used, fee: .tx.auth_info.fee.amount[0], raw_log: .raw_log, logs: .logs}'
BINARY q gov tally 1

BINARY q gov proposals --status passed

# to see the events emitted, need height - search log for proposal tallied expedited=true module=x/gov proposal=1 results=passed status=PROPOSAL_STATUS_PASSED title="Increase stake for Validator A"
BINARY q block-results 367 --output json | jq '.finalize_block_events[] | select(.type=="gov_delegate")'
BINARY q block-results 367 --output json | jq '.finalize_block_events[] | select(.type=="delegate")'

BINARY q consensus comet validator-set # 2 -> 1
BINARY q staking validators --output json # 2

# can any account (use validator2) submit delegate proposal? yes
BINARY tx gov submit-proposal ./poas/proposal_gov_delegate.json $FLAGS --from=validator2
BINARY q tx 41955EBE6A5375953B566E9ECE646C5E343DCAFBEA0EC1D81CE7F2EAB52A1370 -o json | jq '{tx: .tx.body.messages, gas_limit: .gas_wanted, gas_used: .gas_used, fee: .tx.auth_info.fee.amount[0], raw_log: .raw_log, logs: .logs}'

BINARY q gov proposal 3
BINARY tx gov vote 3 yes $FLAGS --from=validator
BINARY q tx 4C66711A238050DC4014D71E748D95D0D89E8D603770F2AD1B20973784A16541 -o json | jq '{tx: .tx.body.messages, gas_limit: .gas_wanted, gas_used: .gas_used, fee: .tx.auth_info.fee.amount[0], raw_log: .raw_log, logs: .logs}'
BINARY q gov tally 3

# can any account (use validator2) submit delegate proposal which had a different delegator_address (use validator2)? yes
# 
BINARY q bank balances $VALIDATOR 
# 897002986
BINARY q bank balances $VALIDATOR2
# 997998620

BINARY tx gov submit-proposal ./poas/proposal_gov_delegate.json $FLAGS --from=validator2
BINARY q tx D479520A6B9C1B53960E4D9ADE298AA127C1A39AC979DEE12FEA663ED13175B5 -o json | jq '{tx: .tx.body.messages, gas_limit: .gas_wanted, gas_used: .gas_used, fee: .tx.auth_info.fee.amount[0], raw_log: .raw_log, logs: .logs}'

BINARY q bank balances $VALIDATOR 
# 897002986
BINARY q bank balances $VALIDATOR2
# 995998295 (-2000000 deposit)

BINARY q gov proposal 6
BINARY tx gov vote 6 yes $FLAGS --from=validator
BINARY q tx 814FA1C8CBCAFED5F2A42B144FB6A74EEF1595A48F1579F05F7026DF0E259EEF -o json | jq '{tx: .tx.body.messages, gas_limit: .gas_wanted, gas_used: .gas_used, fee: .tx.auth_info.fee.amount[0], raw_log: .raw_log, logs: .logs}'
BINARY q gov tally 6

# after voting but before vote passed
BINARY q bank balances $VALIDATOR 
# 897002909
BINARY q bank balances $VALIDATOR2
# 995998295 (-2000000 deposit)

# after vote passed
BINARY q bank balances $VALIDATOR 
# 897002909
BINARY q bank balances $VALIDATOR2
# 996998302 (+2000000 deposit - 1000000 delegate)

# negative case: delegator does not have enough balance to meet the delegate
# user1 is the delegator for a delegate of 1000000; but only has 0 balance
# so proposer does not have to be the same as delegator
BINARY q bank balances $USER1_ADDR
# 0
BINARY q consensus comet validator-set # 2 -> 1
# voting power = 106
BINARY q staking validators --output json # 2
# tokens: 106000000
BINARY tx gov submit-proposal ./poas/proposal_gov_delegate.json $FLAGS --from=validator
BINARY q tx 4408EA5B2ADCBABCEAF15FF22424A77D6648D0E671BAB76BE2CD71B3D3649DD9 -o json | jq '{tx: .tx.body.messages, gas_limit: .gas_wanted, gas_used: .gas_used, fee: .tx.auth_info.fee.amount[0], raw_log: .raw_log, logs: .logs}'
BINARY q bank balances $USER1_ADDR 
# 0
BINARY q gov proposal 8
BINARY tx gov vote 8 yes $FLAGS --from=validator
BINARY q tx 6DEFF91CE23E052932448629FCBA42DF50EAFEDA21CCD38C9A00ADA6BB034CE5 -o json | jq '{tx: .tx.body.messages, gas_limit: .gas_wanted, gas_used: .gas_used, fee: .tx.auth_info.fee.amount[0], raw_log: .raw_log, logs: .logs}'
BINARY q gov tally 8

# after vote passed
# 5:08PM INF proposal tallied expedited=true module=x/gov proposal=8 results="passed, but msg 0 (/poas.v1.MsgGovDelegate) failed on execution: failed to delegate; 3uwfUSD is smaller than 1000000uwfUSD: insufficient funds" status=PROPOSAL_STATUS_FAILED title="Increase stake for Validator A"
# status: PROPOSAL_STATUS_FAILED
```
