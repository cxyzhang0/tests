## State of PoA
> Strangelove’s project is decent but runtime is unstable during validator set changes
> - https://github.com/strangelove-ventures/poa/issues/247
> - https://github.com/strangelove-ventures/poa/issues/245
> - Besides, it needs to fork Cosmos SDK. And the project is not actively maintained and the dependencies are old.  

> Interchain is considering developing a PoA module, following the similar design concept as Strangelove. Cosmos sdk had an incubation poa project a few years back but it never got merged to the main branch. There were other attempts but none became mainstream. A production grade poa is not trivia given those experiences. This time, Interchain thinks it can do it in 2 to 3 months pending a commercial agreement with wf.

> Our solution - PoAS (Proof of Authority via Stake). Given the uncertainty, we should at least have a fallback position. With a separate gas/stake token, PoS can easily be made to behave as a PoA by simply controlling the token’s supply and distribution. Noble did it and our current tokenfactory chain is running the same way, securely. But with the change to use wfUSD as our gas/stake token, we introduce potential risks to the current PoS model. 
> - An adversary could amass wfUSD and create a brand-new validator with a huge self-delegation.  
> - An adversary who compromises one validator could have it accept a huge delegation.
> - Both let an attacker threaten consensus.
> PoAS mitigates that risk. 
> - The major changes are as follows.
> - It disables tx staking create-validator. So anyone sending such tx after genesis would get an error.
> - It disables tx staking delegate. So anyone sending such tx would get an error.
> - That is achieved via new ante decorators.
> - After genesis, if we need to add validators, do it by submitting an MsgGovAddValidator proposal which is subject to voting by the existing validators for approval and admission. 
> - If a validator needs to add voting power by self-delegation, do it by submitting an MsgGovDelegate proposal which is subject to voting by the existing validators for approval and admission.
> - That is achieved by developing a light weight ‘x/poas’ module which has MsgGovAddValidator and MsgGovDelegate and the corresponding msg server send either MsgCreateValidator or MsgDelegate on staking. By configuring the routing, it is called only by the gov module after the MsgGovAddValidator or MsgGovDelegate proposal is approved. Again, via ante decorators, anyone except for gov module sending add-validator or delegate tx would get an error.
> - Make configuration changes to remove slashing so the validators’s power/stake keeps constant. Other configuration changes may touch upon pex for peer discovery and validator whitelisting.  Also secure genesis.json as well as snapshots.
> - PoAS does not change the existing EndBlock functionality which determines the validator set and their voting power, unlike Strangelove’s PoA. All its changes are relate to gating the validator admission and once the validators are in they follow the batttle-tested PoS. That is why PoAS is stable and it introduces zero operational risk.

## Proof of Authority (PoA) and wfUSD as the Gas Token
### Introduction
> Gas token is essential for our tokenomics and security of the tokenfactory chain.  
> Currently, we use an artificial token called `stake` for tx fees and staking for the Proof of Staking (PoS) consensus. stake token has no real value and a fixed number of all stake tokens are minted at the genesis for the initial validators and the faucet. Future validators must get the tokens from the faucet for staking and all other accounts must request fee grant from the faucet. That introduces a lot of frictions for the wallet and blockchain operations.  
> A better strategy as also adopted by Circle's Arc blockchain is to use wfUSD as the gas token. That greatly simplifies our tokenomics and makes our chain more user-friendly.  
> But POS with wfUSD as the staking token has its own challenges. The main challenge is that validators would need a huge amount of wfUSD to secure the chain, which would put pressure on the WF treasury to lock up a lot of liquidity in order to fund the tokenfacory's operations.  
> A better alternative is to use Proof of Authority (PoA) which uses a permissioned set of validators whose voting power is determined by governance instead of wfUSDs staked. At genesis, very little wfUSD is needed to boostrap the chain, for example, to fund the owner, masterminter, mintercontroller and minter so that they can make their on-chain assignments; and to fund the initial validators for initial setup and their operations such as voting and slashing. All future wfUSD will be minted by the minter via tokenization.
> With POA, we lose a bit on decentralization, which is acceptable initially because we want more control. But we should have a path to POS in the future when the chain is more mature and there are sufficient wfUSD liquidity to support staking by validators.

### Implementation
> Consensus is complex and critical to the security of the blockchain. Implementing POA is non-trivial and it is preferable to integrate with an existing project which has been audited, has solid production record and is well maintained. Unfortunately, there are few choices. Strangelove's PoA https://github.com/strangelove-ventures/poa/tree/main comes close - it was audited, but it does seem to be maintained actively. Also there issues, for example, https://github.com/strangelove-ventures/poa/issues/245. In our own tests, we encountered chain halting when unjailing a validator. Most bothersome is the need to fork Cosmos SDK.  
> Nevertheless, we did a quick POC (sean/working and sean/upgrade branchs at ~/Project/go/cosmos/poa) to understand how it operates.
> - wfUSD as the gas token is straightfoward - just replace stake with uwfUSD as the bond denom to wfUSD.


