package apputil

import "fmt"

func PanicIfErr(err error) {
	if err != nil {
		panic(err)
	}
}

// PanicIfErrMsg adds context and wraps err (preserves errors.Is / errors.As).
func PanicIfErrMsg(err error, msg string) {
	if err != nil {
		panic(fmt.Errorf("%s: %w", msg, err))
	}
}

// PanicIfErrf formats a message and wraps err.
// Usage: PanicIfErrf(err, "reading wasm config (home=%s)", home)
func PanicIfErrf(err error, format string, args ...any) {
	if err != nil {
		msg := fmt.Sprintf(format, args...)
		panic(fmt.Errorf("%s: %w", msg, err))
	}
}

// Must unwraps (T, error) or panics (wrapping error with msg if provided).
func Must[T any](v T, err error) T {
	if err != nil {
		panic(err)
	}
	return v
}
