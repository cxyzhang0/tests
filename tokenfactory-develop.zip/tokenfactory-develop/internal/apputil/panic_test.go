package apputil

import (
	"errors"
	"fmt"
	"strings"
	"testing"
)

func TestPanicIfErr(t *testing.T) {
	tests := []struct {
		name      string
		err       error
		wantPanic bool
	}{
		{
			name:      "nil error does not panic",
			err:       nil,
			wantPanic: false,
		},
		{
			name:      "non-nil error panics",
			err:       errors.New("test error"),
			wantPanic: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			defer func() {
				r := recover()
				if (r != nil) != tt.wantPanic {
					t.Errorf("PanicIfErr() panic = %v, wantPanic %v", r != nil, tt.wantPanic)
				}
				if tt.wantPanic && r != tt.err {
					t.Errorf("PanicIfErr() panic value = %v, want %v", r, tt.err)
				}
			}()
			PanicIfErr(tt.err)
		})
	}
}

func TestPanicIfErrMsg(t *testing.T) {
	baseErr := errors.New("base error")

	tests := []struct {
		name         string
		err          error
		msg          string
		wantPanic    bool
		wantContains string
	}{
		{
			name:      "nil error does not panic",
			err:       nil,
			msg:       "context message",
			wantPanic: false,
		},
		{
			name:         "non-nil error panics with message",
			err:          baseErr,
			msg:          "failed to initialize",
			wantPanic:    true,
			wantContains: "failed to initialize: base error",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			defer func() {
				r := recover()
				if (r != nil) != tt.wantPanic {
					t.Errorf("PanicIfErrMsg() panic = %v, wantPanic %v", r != nil, tt.wantPanic)
				}
				if tt.wantPanic {
					panicErr, ok := r.(error)
					if !ok {
						t.Fatalf("panic value is not an error: %v", r)
					}
					if !strings.Contains(panicErr.Error(), tt.wantContains) {
						t.Errorf("panic message = %q, want to contain %q", panicErr.Error(), tt.wantContains)
					}
					// Verify error wrapping is preserved
					if !errors.Is(panicErr, baseErr) {
						t.Errorf("wrapped error chain broken, errors.Is() = false")
					}
				}
			}()
			PanicIfErrMsg(tt.err, tt.msg)
		})
	}
}

func TestPanicIfErrf(t *testing.T) {
	baseErr := errors.New("base error")

	tests := []struct {
		name         string
		err          error
		format       string
		args         []any
		wantPanic    bool
		wantContains string
	}{
		{
			name:      "nil error does not panic",
			err:       nil,
			format:    "reading config (home=%s)",
			args:      []any{"/home/user"},
			wantPanic: false,
		},
		{
			name:         "non-nil error panics with formatted message",
			err:          baseErr,
			format:       "reading wasm config (home=%s, port=%d)",
			args:         []any{"/home/user", 8080},
			wantPanic:    true,
			wantContains: "reading wasm config (home=/home/user, port=8080): base error",
		},
		{
			name:         "handles format with no args",
			err:          baseErr,
			format:       "simple message",
			args:         []any{},
			wantPanic:    true,
			wantContains: "simple message: base error",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			defer func() {
				r := recover()
				if (r != nil) != tt.wantPanic {
					t.Errorf("PanicIfErrf() panic = %v, wantPanic %v", r != nil, tt.wantPanic)
				}
				if tt.wantPanic {
					panicErr, ok := r.(error)
					if !ok {
						t.Fatalf("panic value is not an error: %v", r)
					}
					if !strings.Contains(panicErr.Error(), tt.wantContains) {
						t.Errorf("panic message = %q, want to contain %q", panicErr.Error(), tt.wantContains)
					}
					// Verify error wrapping is preserved
					if !errors.Is(panicErr, baseErr) {
						t.Errorf("wrapped error chain broken, errors.Is() = false")
					}
				}
			}()
			PanicIfErrf(tt.err, tt.format, tt.args...)
		})
	}
}

func TestMust(t *testing.T) {
	t.Run("returns value when error is nil", func(t *testing.T) {
		result := Must(42, nil)
		if result != 42 {
			t.Errorf("Must() = %v, want 42", result)
		}
	})

	t.Run("returns string value when error is nil", func(t *testing.T) {
		result := Must("hello", nil)
		if result != "hello" {
			t.Errorf("Must() = %v, want 'hello'", result)
		}
	})

	t.Run("panics when error is non-nil", func(t *testing.T) {
		testErr := errors.New("test error")
		defer func() {
			r := recover()
			if r == nil {
				t.Error("Must() did not panic")
			}
			if r != testErr {
				t.Errorf("Must() panic value = %v, want %v", r, testErr)
			}
		}()
		_ = Must(42, testErr)
	})

	t.Run("works with struct types", func(t *testing.T) {
		type testStruct struct {
			Value int
		}
		result := Must(testStruct{Value: 100}, nil)
		if result.Value != 100 {
			t.Errorf("Must() = %v, want {Value: 100}", result)
		}
	})

	t.Run("works with pointer types", func(t *testing.T) {
		value := 42
		result := Must(&value, nil)
		if *result != 42 {
			t.Errorf("Must() = %v, want 42", *result)
		}
	})
}

type CustomError struct {
	Code int
}

func TestErrorWrapping(t *testing.T) {
	// Create a custom error type

	customErr := &CustomError{Code: 404}

	t.Run("PanicIfErrMsg preserves errors.As", func(t *testing.T) {
		defer func() {
			r := recover()
			if r == nil {
				t.Fatal("expected panic")
			}
			panicErr, ok := r.(error)
			if !ok {
				t.Fatal("panic value is not an error")
			}

			var ce *CustomError
			if !errors.As(panicErr, &ce) {
				t.Error("errors.As() failed, error wrapping not preserved")
			}
			if ce.Code != 404 {
				t.Errorf("CustomError.Code = %d, want 404", ce.Code)
			}
		}()
		PanicIfErrMsg(customErr, "custom error occurred")
	})

	t.Run("PanicIfErrf preserves errors.As", func(t *testing.T) {
		defer func() {
			r := recover()
			if r == nil {
				t.Fatal("expected panic")
			}
			panicErr, ok := r.(error)
			if !ok {
				t.Fatal("panic value is not an error")
			}

			var ce *CustomError
			if !errors.As(panicErr, &ce) {
				t.Error("errors.As() failed, error wrapping not preserved")
			}
			if ce.Code != 404 {
				t.Errorf("CustomError.Code = %d, want 404", ce.Code)
			}
		}()
		PanicIfErrf(customErr, "custom error at line %d", 42)
	})
}

func (e *CustomError) Error() string {
	return fmt.Sprintf("custom error: code %d", e.Code)
}
