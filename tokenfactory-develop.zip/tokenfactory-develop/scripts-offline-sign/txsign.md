## generic example
> - in most cases, just update INPUT, OUTPUT, and KL
> - to get ACCOUNT_NUMBER and SEQUENCE, this needs to access the live chain.
```zsh - generic

INPUT=./scripts-offline-sign/unsigned-tf-metadata.json && \
OUTPUT=./scripts-offline-sign/signed-tf-metadata.json && \
CHAIN_BIN=./bin/tfd && \
NODE_CHAIN="--node=tcp://localhost:26657" && \
KMSTOOL=../../rust/App-block-kmstool/target/release/kmstool && \
KMSTOOL_CFG=../../rust/App-block-kmstool/config.toml && \
KL="Slot Token 0/wfdc2/masterminter/1" && \
ADDR=$(SOFTHSM2_PIN=5678 $KMSTOOL -c $KMSTOOL_CFG keys get-pub-key -l $KL -t "account" -a "secp256k1" -p "wf" | egrep -o 'addr: (.*?);' | cut -d' ' -f2 | cut -d';' -f1) && \
ACCOUNT_NUMBER=$($CHAIN_BIN query auth account $ADDR $NODE_CHAIN -o json | jq -r '.account.value.account_number // 0') && \
SEQUENCE=$($CHAIN_BIN query auth account $ADDR $NODE_CHAIN -o json | jq -r '.account.value.sequence // 0') && \
SOFTHSM2_PIN=5678 $KMSTOOL -c $KMSTOOL_CFG txsigner txsign $INPUT \
  --output-json $OUTPUT \
  --chain-bin $CHAIN_BIN \
  --chain-id tokenfactory-1 \
  --account-number $ACCOUNT_NUMBER \
  --sequence $SEQUENCE \
  --kl $KL
```