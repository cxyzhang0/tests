#!/bin/bash

# !! PLEASE ONLY RUN THIS SCRIPT IN A TESTING ENVIRONMENT !!
#   THIS SCRIPT: 
#     - Stops/starts tfd binary

# This script is meant for quick experimentation of the Tokenfactory Module and tokenfactory Chain functionality.
# - Initialize, configure and start tokenfactory chain
# - - all keys are derived from mnemonics in `../scripts-july/seeds/`
# - - poas-specific configuration settings
# - - future eureka compatible
# - - uwfUSD as gas/staking token
# - Delagates and funds all privledged accounts for the `tokenfactory`.
# - todo: parameters hard-coded for distribution, gov, staking, slashing, mint and crisis. do we need to parameterize them?

# Run instructions
# run in root
# - ./scripts-chain/play.sh
# - source ./scripts-chain/chains.env


killall tfd
sleep 2
[ -d "./scripts-chain/play_sh" ] && rm -r "./scripts-chain/play_sh"

BINARY="./bin/tfd"
CHAIN_ID="tokenfactory-1"
CHAIN_DIR="./scripts-chain/play_sh"
RPCPORT="26657"
P2PPORT="26656"
PROFPORT="6060"
GRPCPORT="9090"

MINIMUM_GAS_PRICE="0.001uwfUSD"


KEYRING="--keyring-backend=test"

HOME_DIR="$CHAIN_DIR/$CHAIN_ID"
NODE_HOME="--home=$HOME_DIR"
NODE_CHAIN_ID="--chain-id=$CHAIN_ID"
GAS=(--gas-prices "0.001uwfUSD" --gas "auto" --gas-adjustment 2.0)

TF_MINTING_DENOM='wfUSD'
TF_MINTING_CENT_DENOM='wfCENT'
TF_MINTING_BASEDENOM="u$TF_MINTING_DENOM"

STAKE_DENOM=$TF_MINTING_BASEDENOM
DENOM=$STAKE_DENOM

SILENT=1

redirect() {
  if [ "$SILENT" -eq 1 ]; then
    "$@" > /dev/null 2>&1
  else
    "$@"
  fi
}

# Add dir for chain, exit if error
if ! mkdir -p "$HOME_DIR" 2>/dev/null; then
    echo "Failed to create chain folder. Aborting..."
    exit 1
fi

# genesis values
coins="1000000000$DENOM" # 10^9
delegate="100000000$DENOM" # 10^8
# we may not use faucet anymore since we are using wfUSD as gas/stake denom
FAUCET_COINS="1000000000$STAKE_DENOM" # 10^9
# prefund user accounts from faucet
FUND_COINS="1000000$STAKE_DENOM" # 10^6

echo "initializing chain ..."
$BINARY init $NODE_HOME $NODE_CHAIN_ID $CHAIN_ID
sleep 2

echo "retrieve faucet mnemonics ..."
FAUCET_MNEMONIC=$(jq -r '.mnemonic' ./scripts-july/seeds/faucet_seed.json)
echo "retrieve validator mnemonics ..."
VAL_MNEMONIC=$(jq -r '.mnemonic' ./scripts-july/seeds/val_1_seed.json)
echo "retrieve validator2 mnemonics ..."
VAL2_MNEMONIC=$(jq -r '.mnemonic' ./scripts-july/seeds/val_2_seed.json)
echo "retrieve owner mnemonics ..."
OWNER_MNEMONIC=$(jq -r '.mnemonic' ./scripts-july/seeds/xyz_1_seed.json)
echo "retrieve masterminter mnemonics ..."
MASTERMINTER_MNEMONIC=$(jq -r '.mnemonic' ./scripts-july/seeds/xyz_2_seed.json)
echo "retrieve mintercontroller mnemonics ..."
MINTERCONTROLLER_MNEMONIC=$(jq -r '.mnemonic' ./scripts-july/seeds/xyz_3_seed.json)
echo "retrieve MINTER mnemonics ..."
MINTER_MNEMONIC=$(jq -r '.mnemonic' ./scripts-july/seeds/xyz_4_seed.json)
echo "retrieve BLACKLISTER mnemonics ..."
BLACKLISTER_MNEMONIC=$(jq -r '.mnemonic' ./scripts-july/seeds/xyz_5_seed.json)
echo "retrieve PAUSER mnemonics ..."
PAUSER_MNEMONIC=$(jq -r '.mnemonic' ./scripts-july/seeds/xyz_6_seed.json)
echo "retrieve USA mnemonics ..."
USA_MNEMONIC=$(jq -r '.mnemonic' ./scripts-july/seeds/xyz_7_seed.json)
echo "retrieve CAN mnemonics ..."
CAN_MNEMONIC=$(jq -r '.mnemonic' ./scripts-july/seeds/xyz_8_seed.json)
echo "retrieve USER1 mnemonics ..."
USER1_MNEMONIC=$(jq -r '.mnemonic' ./scripts-july/seeds/xyz_9_seed.json)
echo "retrieve USER2 mnemonics ..."
USER2_MNEMONIC=$(jq -r '.mnemonic' ./scripts-july/seeds/xyz_10_seed.json)

echo "***** add faucet key ..."
(echo $FAUCET_MNEMONIC; echo "") | $BINARY keys add faucet $NODE_HOME $KEYRING --interactive --no-backup
FAUCET=$($BINARY keys show faucet -a $NODE_HOME $KEYRING)
echo "faucet address: $FAUCET"
sleep 1
echo "***** add validator key ..."
(echo $VAL_MNEMONIC; echo "") | $BINARY keys add validator $NODE_HOME $KEYRING --interactive --no-backup
VALIDATOR=$($BINARY keys show validator -a $NODE_HOME $KEYRING)
echo "validator address: $VALIDATOR"
sleep 1
echo "***** add validator2 key ..."
(echo $VAL2_MNEMONIC; echo "") | $BINARY keys add validator2 $NODE_HOME $KEYRING --interactive --no-backup
VALIDATOR2=$($BINARY keys show validator2 -a $NODE_HOME $KEYRING)
echo "validator2 address: $VALIDATOR2"
sleep 1
echo "***** add tf_owner key ..."
(echo $OWNER_MNEMONIC; echo "") | $BINARY keys add tf_owner $NODE_HOME $KEYRING --interactive --no-backup
TF_OWNER=$($BINARY keys show tf_owner -a $NODE_HOME $KEYRING)
echo "tf_owner address: $TF_OWNER"
sleep 1
echo "***** add masterminter key ..."
(echo $MASTERMINTER_MNEMONIC; echo "") | $BINARY keys add masterminter $NODE_HOME $KEYRING --interactive --no-backup
MASTERMINTER=$($BINARY keys show masterminter -a $NODE_HOME $KEYRING)
echo "masterminter address: $MASTERMINTER"
sleep 1
echo "***** add mintercontroller key ..."
(echo $MINTERCONTROLLER_MNEMONIC; echo "") | $BINARY keys add mintercontroller $NODE_HOME $KEYRING --interactive --no-backup
MINTERCONTROLLER=$($BINARY keys show mintercontroller -a $NODE_HOME $KEYRING)
echo "mintercontroller address: $MINTERCONTROLLER"
sleep 1
echo "***** add minter key ..."
(echo $MINTER_MNEMONIC; echo "") | $BINARY keys add minter $NODE_HOME $KEYRING --interactive --no-backup
MINTER=$($BINARY keys show minter -a $NODE_HOME $KEYRING)
echo "minter address: $MINTER"
sleep 1
echo "***** add blacklister key ..."
(echo $BLACKLISTER_MNEMONIC; echo "") | $BINARY keys add blacklister $NODE_HOME $KEYRING --interactive --no-backup
BLACKLISTER=$($BINARY keys show blacklister -a $NODE_HOME $KEYRING)
echo "blacklister address: $BLACKLISTER"
sleep 1
echo "***** add pauser key ..."
(echo $PAUSER_MNEMONIC; echo "") | $BINARY keys add pauser $NODE_HOME $KEYRING --interactive --no-backup
PAUSER=$($BINARY keys show pauser -a $NODE_HOME $KEYRING)
echo "pauser address: $PAUSER"
sleep 1
echo "***** add usa key ..."
(echo $USA_MNEMONIC; echo "") | $BINARY keys add usa $NODE_HOME $KEYRING --interactive --no-backup
USA=$($BINARY keys show usa -a $NODE_HOME $KEYRING)
echo "usa address: $USA"
sleep 1
echo "***** add can key ..."
(echo $CAN_MNEMONIC; echo "") | $BINARY keys add can $NODE_HOME $KEYRING --interactive --no-backup
CAN=$($BINARY keys show can -a $NODE_HOME $KEYRING)
echo "can address: $CAN"
sleep 1
echo "***** add user1 key ..."
(echo $USER1_MNEMONIC; echo "") | $BINARY keys add user1 $NODE_HOME $KEYRING --interactive --no-backup
USER1=$($BINARY keys show user1 -a $NODE_HOME $KEYRING)
echo "user1 address: $USER1"
sleep 1
echo "***** add user2 key ..."
(echo $USER2_MNEMONIC; echo "") | $BINARY keys add user2 $NODE_HOME $KEYRING --interactive --no-backup
USER2=$($BINARY keys show user2 -a $NODE_HOME $KEYRING)
echo "user2 address: $USER2"
sleep 1


echo "***** add genesis accounts ..."
$BINARY genesis add-genesis-account "$FAUCET" $FAUCET_COINS $NODE_HOME $KEYRING
sleep 1
$BINARY genesis add-genesis-account "$VALIDATOR" $coins $NODE_HOME $KEYRING
sleep 1
$BINARY genesis add-genesis-account "$VALIDATOR2" $coins $NODE_HOME $KEYRING
sleep 1
$BINARY genesis add-genesis-account "$TF_OWNER" $coins $NODE_HOME $KEYRING
sleep 1
echo "***** add gentx ..."
$BINARY genesis gentx validator $delegate $NODE_HOME $KEYRING $NODE_CHAIN_ID --generate-only --commission-rate="0.05" --commission-max-rate="0.50"
#sleep 1
#$BINARY genesis collect-gentxs $NODE_HOME
#sleep 1
#
## Run this to ensure everything worked and that the genesis file is setup correctly
#echo "***** validate genesis ..."
#$BINARY genesis validate-genesis $NODE_HOME
