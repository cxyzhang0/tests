# Broadcast signed txs
```shell
#SIGNED_TX=./scripts-offline-sign/signed-gentx.json 
#SIGNED_TX=./scripts-offline-sign/signed-feegrant.json 
#SIGNED_TX=./scripts-offline-sign/signed-send.json
#SIGNED_TX=./scripts-offline-sign/signed-wasm-store.json
#SIGNED_TX=./scripts-offline-sign/signed-wasm-instantiate.json
#SIGNED_TX=./scripts-offline-sign/signed-wasm-migrate.json
# SIGNED_TX=./scripts-offline-sign/signed-tf-masterminter.json 
# SIGNED_TX=./scripts-offline-sign/signed-tf-blacklister.json 
# SIGNED_TX=./scripts-offline-sign/signed-tf-pauser.json 
# SIGNED_TX=./scripts-offline-sign/signed-tf-mintercontroller.json 
# SIGNED_TX=./scripts-offline-sign/signed-tf-minter.json 
# SIGNED_TX=./scripts-offline-sign/signed-tf-mint.json 
#SIGNED_TX=./scripts-offline-sign/signed-tf-burn.json 
#SIGNED_TX=./scripts-offline-sign/signed-tf-metadata.json 
#SIGNED_TX=./scripts-offline-sign/signed-tf-blacklist.json 
#SIGNED_TX=./scripts-offline-sign/signed-tf-blacklist.json 
#SIGNED_TX=./scripts-offline-sign/signed-tf-pause.json 
#SIGNED_TX=./scripts-offline-sign/signed-tf-unpause.json 
#SIGNED_TX=./scripts-offline-sign/signed-wasm-exec-mint.json 
SIGNED_TX=./scripts-offline-sign/signed-wasm-exec-add_trusted_contract_caller.json 
#SIGNED_TX=./scripts-offline-sign/signed-wasm-exec-remove_trusted_contract_caller.json 
#SIGNED_TX=./scripts-offline-sign/signed-submit-proposal.json 
#SIGNED_TX=./scripts-offline-sign/signed-vote.json 
BINARY tx broadcast $SIGNED_TX \
  -b sync \
  -y  

```