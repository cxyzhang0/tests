## account number and sequence
```shell
# get the sequence number of the account
# public_key may not be present if the account has never sent a tx before
BINARY query auth account $FAUCET $NODE_CHAIN -o json | jq '.account.value.sequence'
BINARY query auth account $HSM_VALIDATOR $NODE_CHAIN -o json | jq '.account.value.sequence'
BINARY query auth account $VALIDATOR $NODE_CHAIN -o json | jq '.account.value.sequence'
BINARY query auth account $USER1 $NODE_CHAIN -o json | jq '.account.value.sequence'
BINARY query auth account $USER2 $NODE_CHAIN -o json | jq '.account.value.account_number'
BINARY query auth account $TF_OWNER $NODE_CHAIN -o json | jq '.account.value.sequence'
BINARY query auth account $MASTERMINTER $NODE_CHAIN -o json | jq '.account.value.sequence'
BINARY query auth account $MINTERCONTROLLER $NODE_CHAIN -o json | jq '.account.value.sequence'
BINARY query auth account $MINTER $NODE_CHAIN -o json | jq '.account.value.sequence'
BINARY query auth account $BLACKLISTER $NODE_CHAIN -o json | jq '.account.value.sequence'
BINARY query auth account $PAUSER $NODE_CHAIN -o json | jq '.account.value.sequence'
```

## generate unsigned tx with simulated gas
> - generate_tx function is for a specific tx type. modify it for other tx types.
> - otherwise, the script is generic.
### fee grant
```shell
# Configuration
UNSIGNED_TX="./scripts-offline-sign/unsigned-feegrant.json"
GAS_PRICES="0.001uwfUSD"
GAS_ADJUSTMENT=2.0
GAS_USED=0
GRANTER=$FAUCET
LIMIT="10000uwfUSD"
EXPIRATION="2026-12-31T23:59:59Z"
#GRANTEE=$TF_OWNER
#GRANTEE=$MASTERMINTER
#GRANTEE=$MINTERCONTROLLER
#GRANTEE=$MINTER
#GRANTEE=$HSM_VALIDATOR
#GRANTEE=$VALIDATOR
#GRANTEE=$BLACKLISTER
#GRANTEE=$PAUSER
GRANTEE=$USER1
# Function to generate tx
generate_tx() {
    gas_raw=$(echo "$GAS_USED * $GAS_ADJUSTMENT" | bc)
    gas=${gas_raw%.*}  
    
   BINARY tx feegrant grant $GRANTER $GRANTEE \
        --generate-only \
        --gas=$gas \
        --gas-prices=$GAS_PRICES \
        --spend-limit=$LIMIT \
        --expiration $EXPIRATION \
        > $UNSIGNED_TX
}

# Step 1: Generate initial unsigned tx for simulation
generate_tx

# Step 2: Simulate to get gas estimate
GAS_USED=$($BINARY tx simulate $UNSIGNED_TX \
    --from=$FROM \
    --dry-run \
    $NODE_HOME $NODE_CHAIN \
    -o json | jq -r '.gas_info.gas_used')

# Step 3: Regenerate tx with calculated simulated GAS_USED
generate_tx
```

### tf masterminter
```shell
# Configuration
UNSIGNED_TX="./scripts-offline-sign/unsigned-tf-masterminter.json"
GAS_PRICES="0.001uwfUSD"
GAS_ADJUSTMENT=2.0
GAS_USED=0
GRANTER=
FROM=$TF_OWNER
# Function to generate tx
generate_tx() {
    gas_raw=$(echo "$GAS_USED * $GAS_ADJUSTMENT" | bc)
    gas=${gas_raw%.*}  
    
    local granter_flag=""
    if [ -n "$1" ]; then
      granter_flag="--fee-granter=$1"
    fi
    
   BINARY tx tokenfactory update-master-minter $MASTERMINTER \
        --generate-only \
        --gas=$gas \
        --gas-prices=$GAS_PRICES \
        $granter_flag \
        --from=$FROM \
        > $UNSIGNED_TX
}

# Step 1: Generate initial unsigned tx for simulation
generate_tx

# Step 2: Simulate to get gas estimate
GAS_USED=$($BINARY tx simulate $UNSIGNED_TX \
    --from=$FROM \
    --dry-run \
    $NODE_HOME $NODE_CHAIN \
    -o json | jq -r '.gas_info.gas_used')

# Step 3: Regenerate tx with calculated simulated GAS_USED
#generate_tx
generate_tx $GRANTER
```

### tf blacklister
```shell
# Configuration
UNSIGNED_TX="./scripts-offline-sign/unsigned-tf-blacklister.json"
GAS_PRICES="0.001uwfUSD"
GAS_ADJUSTMENT=2.0
GAS_USED=0
GRANTER=$FAUCET
FROM=$TF_OWNER
# Function to generate tx
generate_tx() {
    gas_raw=$(echo "$GAS_USED * $GAS_ADJUSTMENT" | bc)
    gas=${gas_raw%.*}  
    
    local granter_flag=""
    if [ -n "$1" ]; then
      granter_flag="--fee-granter=$1"
    fi
    
   BINARY tx tokenfactory update-blacklister $BLACKLISTER \
        --generate-only \
        --gas=$gas \
        --gas-prices=$GAS_PRICES \
        $granter_flag \
        --from=$FROM \
        > $UNSIGNED_TX
}

# Step 1: Generate initial unsigned tx for simulation
generate_tx

# Step 2: Simulate to get gas estimate
GAS_USED=$($BINARY tx simulate $UNSIGNED_TX \
    --from=$FROM \
    --dry-run \
    $NODE_HOME $NODE_CHAIN \
    -o json | jq -r '.gas_info.gas_used')

# Step 3: Regenerate tx with calculated simulated GAS_USED
generate_tx $GRANTER
```

### tf pauser
```shell
# Configuration
UNSIGNED_TX="./scripts-offline-sign/unsigned-tf-pauser.json"
GAS_PRICES="0.001uwfUSD"
GAS_ADJUSTMENT=2.0
GAS_USED=0
GRANTER=$FAUCET
FROM=$TF_OWNER
# Function to generate tx
generate_tx() {
    gas_raw=$(echo "$GAS_USED * $GAS_ADJUSTMENT" | bc)
    gas=${gas_raw%.*}  
    
    local granter_flag=""
    if [ -n "$1" ]; then
      granter_flag="--fee-granter=$1"
    fi
    
   BINARY tx tokenfactory update-pauser $PAUSER \
        --generate-only \
        --gas=$gas \
        --gas-prices=$GAS_PRICES \
        $granter_flag \
        --from=$FROM \
        > $UNSIGNED_TX
}

# Step 1: Generate initial unsigned tx for simulation
generate_tx

# Step 2: Simulate to get gas estimate
GAS_USED=$($BINARY tx simulate $UNSIGNED_TX \
    --from=$FROM \
    --dry-run \
    $NODE_HOME $NODE_CHAIN \
    -o json | jq -r '.gas_info.gas_used')

# Step 3: Regenerate tx with calculated simulated GAS_USED
generate_tx $GRANTER
```

### tf mintercontroller
```shell
# Configuration
UNSIGNED_TX="./scripts-offline-sign/unsigned-tf-mintercontroller.json"
GAS_PRICES="0.001uwfUSD"
GAS_ADJUSTMENT=2.0
GAS_USED=0
GRANTER=
FROM=$MASTERMINTER
# Function to generate tx
generate_tx() {
    gas_raw=$(echo "$GAS_USED * $GAS_ADJUSTMENT" | bc)
    gas=${gas_raw%.*}  
    
    local granter_flag=""
    if [ -n "$1" ]; then
      granter_flag="--fee-granter=$1"
    fi
    
   BINARY tx tokenfactory configure-minter-controller $MINTERCONTROLLER $MINTER \
        --generate-only \
        --gas=$gas \
        --gas-prices=$GAS_PRICES \
        $granter_flag \
        --from=$FROM \
        > $UNSIGNED_TX
}

# Step 1: Generate initial unsigned tx for simulation
generate_tx

# Step 2: Simulate to get gas estimate
GAS_USED=$($BINARY tx simulate $UNSIGNED_TX \
    --from=$FROM \
    --dry-run \
    $NODE_HOME $NODE_CHAIN \
    -o json | jq -r '.gas_info.gas_used')

# Step 3: Regenerate tx with calculated simulated GAS_USED
generate_tx $GRANTER
```

### tf minter
```shell
# Configuration
UNSIGNED_TX="./scripts-offline-sign/unsigned-tf-minter.json"
GAS_PRICES="0.001uwfUSD"
GAS_ADJUSTMENT=2.0
GAS_USED=0
GRANTER=
FROM=$MINTERCONTROLLER
# Function to generate tx
generate_tx() {
    gas_raw=$(echo "$GAS_USED * $GAS_ADJUSTMENT" | bc)
    gas=${gas_raw%.*}  
    
    local granter_flag=""
    if [ -n "$1" ]; then
      granter_flag="--fee-granter=$1"
    fi
    
   BINARY tx tokenfactory configure-minter $MINTER 1000000000uwfUSD \
        --generate-only \
        --gas=$gas \
        --gas-prices=$GAS_PRICES \
        $granter_flag \
        --from=$FROM \
        > $UNSIGNED_TX
}

# Step 1: Generate initial unsigned tx for simulation
generate_tx

# Step 2: Simulate to get gas estimate
GAS_USED=$($BINARY tx simulate $UNSIGNED_TX \
    --from=$FROM \
    --dry-run \
    $NODE_HOME $NODE_CHAIN \
    -o json | jq -r '.gas_info.gas_used')

# Step 3: Regenerate tx with calculated simulated GAS_USED
generate_tx $GRANTER
```

### tf mint
```shell
# Configuration
UNSIGNED_TX="./scripts-offline-sign/unsigned-tf-mint.json"
GAS_PRICES="0.001uwfUSD"
GAS_ADJUSTMENT=2.0
GAS_USED=0
GRANTER=
FROM=$MINTER
TO=$USER1
AMOUNT="1000uwfUSD"
# Function to generate tx
generate_tx() {
    gas_raw=$(echo "$GAS_USED * $GAS_ADJUSTMENT" | bc)
    gas=${gas_raw%.*}  
    
    local granter_flag=""
    if [ -n "$1" ]; then
      granter_flag="--fee-granter=$1"
    fi
    
   BINARY tx tokenfactory mint $TO $AMOUNT \
        --generate-only \
        --gas=$gas \
        --gas-prices=$GAS_PRICES \
        $granter_flag \
        --from=$FROM \
        > $UNSIGNED_TX
}

# Step 1: Generate initial unsigned tx for simulation
generate_tx

# Step 2: Simulate to get gas estimate
GAS_USED=$($BINARY tx simulate $UNSIGNED_TX \
    --from=$FROM \
    --dry-run \
    $NODE_HOME $NODE_CHAIN \
    -o json | jq -r '.gas_info.gas_used')

# Step 3: Regenerate tx with calculated simulated GAS_USED
generate_tx $GRANTER
```

### wasm mint
```shell
# Configuration
# NOTE: orig_sender is ignored because the cli caller is not a contract.
UNSIGNED_TX="./scripts-offline-sign/unsigned-wasm-exec-mint.json"
GAS_PRICES="0.001uwfUSD"
GAS_ADJUSTMENT=2.0
GAS_USED=0
GRANTER=
FROM=$MINTER
TO=$USER1
AMOUNT="1000uwfUSD"
VALUE=${AMOUNT//[^0-9]/}
DENOM=${AMOUNT#${VALUE}}
CONTRACT_ADDRESS='wf14hj2tavq8fpesdwxxcu44rty3hh90vhujrvcmstl4zr3txmfvw9s2s4a5q'
JSON=$(jq -n --arg address "$TO" --arg denom "$DENOM" --arg value "$VALUE" --arg orig_sender "$MINTERCONTROLLER" \
'{ tf: { "mint": { "orig_sender": $orig_sender, "address": $address, "denom": $denom, "value": $value } } }')

# Function to generate tx
generate_tx() {
    gas_raw=$(echo "$GAS_USED * $GAS_ADJUSTMENT" | bc)
    gas=${gas_raw%.*}  
    
    local granter_flag=""
    if [ -n "$1" ]; then
      granter_flag="--fee-granter=$1"
    fi
    
   BINARY tx wasm execute $CONTRACT_ADDRESS "$JSON" \
        --from=$FROM \
        --generate-only \
        --gas=$gas \
        --gas-prices=$GAS_PRICES \
        $granter_flag \
        --from=$FROM \
        > $UNSIGNED_TX
}

# Step 1: Generate initial unsigned tx for simulation
generate_tx

# Step 2: Simulate to get gas estimate
GAS_USED=$($BINARY tx simulate $UNSIGNED_TX \
    --from=$FROM \
    --dry-run \
    $NODE_HOME $NODE_CHAIN \
    -o json | jq -r '.gas_info.gas_used')

# Step 3: Regenerate tx with calculated simulated GAS_USED
generate_tx $GRANTER
```


### tf burn
```shell
# Configuration
UNSIGNED_TX="./scripts-offline-sign/unsigned-tf-burn.json"
GAS_PRICES="0.001uwfUSD"
GAS_ADJUSTMENT=2.0
GAS_USED=0
GRANTER=$FAUCET
FROM=$MINTER
AMOUNT="1000uwfUSD"
# Function to generate tx
generate_tx() {
    gas_raw=$(echo "$GAS_USED * $GAS_ADJUSTMENT" | bc)
    gas=${gas_raw%.*}  
    
    local granter_flag=""
    if [ -n "$1" ]; then
      granter_flag="--fee-granter=$1"
    fi
    
   BINARY tx tokenfactory burn $AMOUNT \
        --generate-only \
        --gas=$gas \
        --gas-prices=$GAS_PRICES \
        $granter_flag \
        --from=$FROM \
        > $UNSIGNED_TX
}

# Step 1: Generate initial unsigned tx for simulation
generate_tx

# Step 2: Simulate to get gas estimate
GAS_USED=$($BINARY tx simulate $UNSIGNED_TX \
    --from=$FROM \
    --dry-run \
    $NODE_HOME $NODE_CHAIN \
    -o json | jq -r '.gas_info.gas_used')

# Step 3: Regenerate tx with calculated simulated GAS_USED
generate_tx $GRANTER
```

### tf blacklist
```shell
# Configuration
UNSIGNED_TX="./scripts-offline-sign/unsigned-tf-blacklist.json"
GAS_PRICES="0.001uwfUSD"
GAS_ADJUSTMENT=2.0
GAS_USED=0
GRANTER=$FAUCET
FROM=$BLACKLISTER
WHO=$USER1
# Function to generate tx
generate_tx() {
    gas_raw=$(echo "$GAS_USED * $GAS_ADJUSTMENT" | bc)
    gas=${gas_raw%.*}  
    
    local granter_flag=""
    if [ -n "$1" ]; then
      granter_flag="--fee-granter=$1"
    fi
    
   BINARY tx tokenfactory blacklist $WHO \
        --generate-only \
        --gas=$gas \
        --gas-prices=$GAS_PRICES \
        $granter_flag \
        --from=$FROM \
        > $UNSIGNED_TX
}

# Step 1: Generate initial unsigned tx for simulation
generate_tx

# Step 2: Simulate to get gas estimate
GAS_USED=$($BINARY tx simulate $UNSIGNED_TX \
    --from=$FROM \
    --dry-run \
    $NODE_HOME $NODE_CHAIN \
    -o json | jq -r '.gas_info.gas_used')

# Step 3: Regenerate tx with calculated simulated GAS_USED
generate_tx $GRANTER
```

### tf unblacklist
```shell
# Configuration
UNSIGNED_TX="./scripts-offline-sign/unsigned-tf-unblacklist.json"
GAS_PRICES="0.001uwfUSD"
GAS_ADJUSTMENT=2.0
GAS_USED=0
GRANTER=$FAUCET
FROM=$BLACKLISTER
WHO=$USER1
# Function to generate tx
generate_tx() {
    gas_raw=$(echo "$GAS_USED * $GAS_ADJUSTMENT" | bc)
    gas=${gas_raw%.*}  
    
    local granter_flag=""
    if [ -n "$1" ]; then
      granter_flag="--fee-granter=$1"
    fi
    
   BINARY tx tokenfactory unblacklist $WHO \
        --generate-only \
        --gas=$gas \
        --gas-prices=$GAS_PRICES \
        $granter_flag \
        --from=$FROM \
        > $UNSIGNED_TX
}

# Step 1: Generate initial unsigned tx for simulation
generate_tx

# Step 2: Simulate to get gas estimate
GAS_USED=$($BINARY tx simulate $UNSIGNED_TX \
    --from=$FROM \
    --dry-run \
    $NODE_HOME $NODE_CHAIN \
    -o json | jq -r '.gas_info.gas_used')

# Step 3: Regenerate tx with calculated simulated GAS_USED
generate_tx $GRANTER
```

### tf pause
```shell
# Configuration
UNSIGNED_TX="./scripts-offline-sign/unsigned-tf-pause.json"
GAS_PRICES="0.001uwfUSD"
GAS_ADJUSTMENT=2.0
GAS_USED=0
GRANTER=$FAUCET
FROM=$PAUSER
# Function to generate tx
generate_tx() {
    gas_raw=$(echo "$GAS_USED * $GAS_ADJUSTMENT" | bc)
    gas=${gas_raw%.*}  
    
    local granter_flag=""
    if [ -n "$1" ]; then
      granter_flag="--fee-granter=$1"
    fi
    
   BINARY tx tokenfactory pause \
        --generate-only \
        --gas=$gas \
        --gas-prices=$GAS_PRICES \
        $granter_flag \
        --from=$FROM \
        > $UNSIGNED_TX
}

# Step 1: Generate initial unsigned tx for simulation
generate_tx

# Step 2: Simulate to get gas estimate
GAS_USED=$($BINARY tx simulate $UNSIGNED_TX \
    --from=$FROM \
    --dry-run \
    $NODE_HOME $NODE_CHAIN \
    -o json | jq -r '.gas_info.gas_used')

# Step 3: Regenerate tx with calculated simulated GAS_USED
generate_tx $GRANTER
```

### tf unpause
```shell
# Configuration
UNSIGNED_TX="./scripts-offline-sign/unsigned-tf-unpause.json"
GAS_PRICES="0.001uwfUSD"
GAS_ADJUSTMENT=2.0
GAS_USED=0
GRANTER=$FAUCET
FROM=$PAUSER
# Function to generate tx
generate_tx() {
    gas_raw=$(echo "$GAS_USED * $GAS_ADJUSTMENT" | bc)
    gas=${gas_raw%.*}  
    
    local granter_flag=""
    if [ -n "$1" ]; then
      granter_flag="--fee-granter=$1"
    fi
    
   BINARY tx tokenfactory unpause \
        --generate-only \
        --gas=$gas \
        --gas-prices=$GAS_PRICES \
        $granter_flag \
        --from=$FROM \
        > $UNSIGNED_TX
}

# Step 1: Generate initial unsigned tx for simulation
generate_tx

# Step 2: Simulate to get gas estimate
GAS_USED=$($BINARY tx simulate $UNSIGNED_TX \
    --from=$FROM \
    --dry-run \
    $NODE_HOME $NODE_CHAIN \
    -o json | jq -r '.gas_info.gas_used')

# Step 3: Regenerate tx with calculated simulated GAS_USED
generate_tx $GRANTER
```

### tf metadata
```shell
# Configuration
UNSIGNED_TX="./scripts-offline-sign/unsigned-tf-metadata.json"
GAS_PRICES="0.001uwfUSD"
GAS_ADJUSTMENT=2.0
GAS_USED=0
GRANTER=$FAUCET
FROM=$MASTERMINTER
METADATA='{
    "description": "Ether Wrapped and Issued on Tokenfactory",
    "denom_units": [
      {
        "denom": "wgWEI",
        "exponent": 0,
        "aliases": []
      },
      {
        "denom": "wETH",
        "exponent": 9,
        "aliases": ["wEther"]
      }
    ],
    "base": "wgWEI",
    "display": "wETH",
    "name": "Wrapped Ether",
    "symbol": "wETH"
  }'
# Function to generate tx
generate_tx() {
    gas_raw=$(echo "$GAS_USED * $GAS_ADJUSTMENT" | bc)
    gas=${gas_raw%.*}  
    
    local granter_flag=""
    if [ -n "$1" ]; then
      granter_flag="--fee-granter=$1"
    fi
    
   BINARY tx tokenfactory set-denom-metadata $METADATA \
        --generate-only \
        --gas=$gas \
        --gas-prices=$GAS_PRICES \
        $granter_flag \
        --from=$FROM \
        > $UNSIGNED_TX
}

# Step 1: Generate initial unsigned tx for simulation
generate_tx

# Step 2: Simulate to get gas estimate
GAS_USED=$($BINARY tx simulate $UNSIGNED_TX \
    --from=$FROM \
    --dry-run \
    $NODE_HOME $NODE_CHAIN \
    -o json | jq -r '.gas_info.gas_used')

# Step 3: Regenerate tx with calculated simulated GAS_USED
generate_tx $GRANTER
```

### send
```shell
# Configuration
UNSIGNED_TX="./scripts-offline-sign/unsigned-send.json"
GAS_PRICES="0.001uwfUSD"
GAS_ADJUSTMENT=2.0
GAS_USED=0
GRANTER=$FAUCET
FROM=$USER1
TO=$USER2
AMOUNT="10uwfUSD"
# Function to generate tx
generate_tx() {
    gas_raw=$(echo "$GAS_USED * $GAS_ADJUSTMENT" | bc)
    gas=${gas_raw%.*}  
    
    local granter_flag=""
    if [ -n "$1" ]; then
      granter_flag="--fee-granter=$1"
    fi
    
   BINARY tx bank send $FROM $TO 10uwfUSD \
        --generate-only \
        --gas=$gas \
        --gas-prices=$GAS_PRICES \
        $granter_flag \
        > $UNSIGNED_TX
}

# Step 1: Generate initial unsigned tx for simulation
generate_tx

# Step 2: Simulate to get gas estimate
GAS_USED=$($BINARY tx simulate $UNSIGNED_TX \
    --from=$FROM \
    --dry-run \
    $NODE_HOME $NODE_CHAIN \
    -o json | jq -r '.gas_info.gas_used')

# Step 3: Regenerate tx with calculated simulated GAS_USED
generate_tx $GRANTER
```

### tokenfactory wasm store
> MASTERMINTER to store the contract. It will also instantiate the contract so it will be the owner of the contract.
> Don't use TF_OWNER because we wanted to protect that wallet.
```shell
# Configuration
UNSIGNED_TX="./scripts-offline-sign/unsigned-wasm-store.json"
GAS_PRICES="0.001uwfUSD"
GAS_ADJUSTMENT=2.0
GAS_USED=0
GRANTER=
FROM=$MASTERMINTER
#WASM_FILE="../../../rust/cosmos/wfdc2/target/wasm32-unknown-unknown/release/tokenfactory_optimized.wasm"
#WASM_FILE="../../../rust/cosmos/cw-tokenfactory/target/wasm32-unknown-unknown/release/tokenfactory_optimized_v010.wasm"
WASM_FILE="../../../rust/cosmos/cw-tokenfactory/target/wasm32-unknown-unknown/release/tokenfactory_optimized.wasm"
# Function to generate tx
generate_tx() {
    gas_raw=$(echo "$GAS_USED * $GAS_ADJUSTMENT" | bc)
    gas=${gas_raw%.*}  
    
    local granter_flag=""
    if [ -n "$1" ]; then
      granter_flag="--fee-granter=$1"
    fi
    
   $BINARY tx wasm store $WASM_FILE \
        --from=$FROM \
        --generate-only \
        --gas=$gas \
        --gas-prices=$GAS_PRICES \
        $NODE_HOME \
        $granter_flag \
        > $UNSIGNED_TX
}

# Step 1: Generate initial unsigned tx for simulation
generate_tx

# Step 2: Simulate to get gas estimate
GAS_USED=$($BINARY tx simulate $UNSIGNED_TX \
    --from=$FROM \
    --dry-run \
    $NODE_HOME $NODE_CHAIN \
    -o json | jq -r '.gas_info.gas_used')

# Step 3: Regenerate tx with calculated simulated GAS_USED
generate_tx $GRANTER
```

### tokenfactory contract instantiation
> MASTERMINTER to initialite the contract so it is the owner of the contract.
> MASTERMINTER is also the admin of the contract so it can migrage/update the contract in the future.
```shell
# Configuration
UNSIGNED_TX="./scripts-offline-sign/unsigned-wasm-instantiate.json"
GAS_PRICES="0.001uwfUSD"
GAS_ADJUSTMENT=2.0
GAS_USED=0
GRANTER=
FROM=$MASTERMINTER
INIT=$(jq -n --arg is_tf "true" '{ "is_tf": $is_tf | test("true") }')
CODE_ID=1
LABEL="Tokenfactory Contract"
ADMIN=$MASTERMINTER
# Function to generate tx
generate_tx() {
    gas_raw=$(echo "$GAS_USED * $GAS_ADJUSTMENT" | bc)
    gas=${gas_raw%.*}  
    
    local granter_flag=""
    if [ -n "$1" ]; then
      granter_flag="--fee-granter=$1"
    fi
    
   $BINARY tx wasm instantiate $CODE_ID "$INIT" --label $LABEL \
        --from=$FROM \
        --admin=$ADMIN \
        --generate-only \
        --gas=$gas \
        --gas-prices=$GAS_PRICES \
        $NODE_HOME \
        $granter_flag \
        > $UNSIGNED_TX
}

# Step 1: Generate initial unsigned tx for simulation
generate_tx

# Step 2: Simulate to get gas estimate
GAS_USED=$($BINARY tx simulate $UNSIGNED_TX \
    --from=$FROM \
    --dry-run \
    $NODE_HOME $NODE_CHAIN \
    -o json | jq -r '.gas_info.gas_used')

# Step 3: Regenerate tx with calculated simulated GAS_USED
generate_tx $GRANTER
```

### tokenfactory contract migration
> MASTERMINTER to initialite the contract so it is the owner of the contract.
> MASTERMINTER is also the admin of the contract so it can migrage/update the contract in the future.
> test migration from 0.1.0 (code_id 3, wf17p9rzwnnfxcjp32un9ug7yhhzgtkhvl9jfksztgw5uh69wac2pgs77w6lz) contract to 0.2.0 (code_id 4
> 0.1.0: Config has owner
> 0.2.0: Config has owner removed and use cw-ownable instead. add state TRUSTED_CONTRACT_CALLERS.
```shell
# Configuration
UNSIGNED_TX="./scripts-offline-sign/unsigned-wasm-migrate.json"
GAS_PRICES="0.001uwfUSD"
GAS_ADJUSTMENT=2.0
GAS_USED=0
GRANTER=
FROM=$MASTERMINTER
CODE_ID=4
MIGRATE=$(jq -n  '{ "v2": { } }')
CONTRACT_ADDRESS="wf17p9rzwnnfxcjp32un9ug7yhhzgtkhvl9jfksztgw5uh69wac2pgs77w6lz"
# Function to generate tx
generate_tx() {
    gas_raw=$(echo "$GAS_USED * $GAS_ADJUSTMENT" | bc)
    gas=${gas_raw%.*}  
    
    local granter_flag=""
    if [ -n "$1" ]; then
      granter_flag="--fee-granter=$1"
    fi
    
   $BINARY tx wasm migrate $CONTRACT_ADDRESS $CODE_ID "$MIGRATE"  \
        --from=$FROM \
        --generate-only \
        --gas=$gas \
        --gas-prices=$GAS_PRICES \
        $NODE_HOME \
        $granter_flag \
        > $UNSIGNED_TX
}

# Step 1: Generate initial unsigned tx for simulation
generate_tx

# Step 2: Simulate to get gas estimate
GAS_USED=$($BINARY tx simulate $UNSIGNED_TX \
    --from=$FROM \
    --dry-run \
    $NODE_HOME $NODE_CHAIN \
    -o json | jq -r '.gas_info.gas_used')

# Step 3: Regenerate tx with calculated simulated GAS_USED
generate_tx $GRANTER
```


### tokenfactory contract whitelist add trusted contract caller
> MASTERMINTER is the owner of the contract so only it can do it.
```shell
# Configuration
UNSIGNED_TX="./scripts-offline-sign/unsigned-wasm-exec-add_trusted_contract_caller.json"
#CONTRACT_ADDRESS='wf14hj2tavq8fpesdwxxcu44rty3hh90vhujrvcmstl4zr3txmfvw9s2s4a5q' # first instantiated contract address
#CONTRACT_ADDRESS='wf1nc5tatafv6eyq7llkr2gv50ff9e22mnf70qgjlv737ktmt4eswrqx9slkx' # second instantiated contract address
CONTRACT_ADDRESS='wf17p9rzwnnfxcjp32un9ug7yhhzgtkhvl9jfksztgw5uh69wac2pgs77w6lz' # migrated contract address from 0.1.0 to 0.2.0
GAS_PRICES="0.001uwfUSD"
GAS_ADJUSTMENT=2.0
GAS_USED=0
GRANTER=
FROM=$MASTERMINTER
JSON=$(jq -n --arg addr "wf14hj2tavq8fpesdwxxcu44rty3hh90vhujrvcmstl4zr3txmfvw9s2s4a5q" '{ add_trusted_caller: { addr: $addr } }') && \
# Function to generate tx
generate_tx() {
    gas_raw=$(echo "$GAS_USED * $GAS_ADJUSTMENT" | bc)
    gas=${gas_raw%.*}  
    
    local granter_flag=""
    if [ -n "$1" ]; then
      granter_flag="--fee-granter=$1"
    fi
    
    $BINARY tx wasm execute $CONTRACT_ADDRESS "$JSON" \
        --from=$FROM \
        --generate-only \
        --gas=$gas \
        --gas-prices=$GAS_PRICES \
        $NODE_HOME \
        $granter_flag \
        > $UNSIGNED_TX    
}

# Step 1: Generate initial unsigned tx for simulation
generate_tx

# Step 2: Simulate to get gas estimate
GAS_USED=$($BINARY tx simulate $UNSIGNED_TX \
    --from=$FROM \
    --dry-run \
    $NODE_HOME $NODE_CHAIN \
    -o json | jq -r '.gas_info.gas_used')

# Step 3: Regenerate tx with calculated simulated GAS_USED
generate_tx $GRANTER
```

### tokenfactory contract whitelist remove trusted contract caller
> MASTERMINTER is the owner of the contract so only it can do it.
```shell
# Configuration
UNSIGNED_TX="./scripts-offline-sign/unsigned-wasm-exec-remove_trusted_contract_caller.json"
#CONTRACT_ADDRESS='wf14hj2tavq8fpesdwxxcu44rty3hh90vhujrvcmstl4zr3txmfvw9s2s4a5q' # first instantiated contract address
CONTRACT_ADDRESS='wf1nc5tatafv6eyq7llkr2gv50ff9e22mnf70qgjlv737ktmt4eswrqx9slkx' # second instantiated contract address
GAS_PRICES="0.001uwfUSD"
GAS_ADJUSTMENT=2.0
GAS_USED=0
GRANTER=
FROM=$MASTERMINTER
JSON=$(jq -n --arg addr "wf14hj2tavq8fpesdwxxcu44rty3hh90vhujrvcmstl4zr3txmfvw9s2s4a5q" '{ remove_trusted_caller: { addr: $addr } }') && \
# Function to generate tx
generate_tx() {
    gas_raw=$(echo "$GAS_USED * $GAS_ADJUSTMENT" | bc)
    gas=${gas_raw%.*}  
    
    local granter_flag=""
    if [ -n "$1" ]; then
      granter_flag="--fee-granter=$1"
    fi
    
    $BINARY tx wasm execute $CONTRACT_ADDRESS "$JSON" \
        --from=$FROM \
        --generate-only \
        --gas=$gas \
        --gas-prices=$GAS_PRICES \
        --timeout-duration=5m \
        $NODE_HOME \
        $granter_flag \
        > $UNSIGNED_TX    
}

# Step 1: Generate initial unsigned tx for simulation
generate_tx

# Step 2: Simulate to get gas estimate
GAS_USED=$($BINARY tx simulate $UNSIGNED_TX \
    --from=$FROM \
    --dry-run \
    $NODE_HOME $NODE_CHAIN \
    -o json | jq -r '.gas_info.gas_used')

# Step 3: Regenerate tx with calculated simulated GAS_USED
generate_tx $GRANTER
```

## validate signatures on signed tx
> - txsigner --offline-check did the same validate-signatures. so if done there already, this test may be redundant.
```shell
#SIGNED_TX="./scripts-offline-sign/signed-gentx.json"
#SIGNED_TX="./scripts-offline-sign/signed-submit-proposal.json"
#SIGNED_TX="./scripts-offline-sign/signed-vote.json"
#SIGNED_TX="./scripts-offline-sign/signed-withdraw-rewards.json"
#SIGNED_TX="./scripts-offline-sign/signed-create-validator2.json"
#SIGNED_TX="./scripts-offline-sign/signed-feegrant.json"
#SIGNED_TX="./scripts-offline-sign/signed-send.json"
#SIGNED_TX="./scripts-offline-sign/signed-tf-masterminter.json"
#SIGNED_TX="./scripts-offline-sign/signed-tf-blacklister.json"
#SIGNED_TX="./scripts-offline-sign/signed-tf-pauser.json"
#SIGNED_TX="./scripts-offline-sign/signed-tf-mintercontroller.json"
#SIGNED_TX="./scripts-offline-sign/signed-tf-minter.json"
#SIGNED_TX="./scripts-offline-sign/signed-tf-mint.json"
#SIGNED_TX="./scripts-offline-sign/signed-tf-burn.json"
#SIGNED_TX="./scripts-offline-sign/signed-tf-metadata.json"
#SIGNED_TX="./scripts-offline-sign/signed-tf-blacklist.json"
#SIGNED_TX="./scripts-offline-sign/signed-tf-unblacklist.json"
#SIGNED_TX="./scripts-offline-sign/signed-tf-pause.json"
#SIGNED_TX="./scripts-offline-sign/signed-tf-unpause.json"
#SIGNED_TX="./scripts-offline-sign/signed-wasm-store.json"
#SIGNED_TX="./scripts-offline-sign/signed-wasm-instantiate.json"
#SIGNED_TX="./scripts-offline-sign/signed-wasm-exec-masterminter.json"
#SIGNED_TX="./scripts-offline-sign/signed-wasm-exec-blacklister.json"
#SIGNED_TX="./scripts-offline-sign/signed-wasm-exec-pauser.json"
#SIGNED_TX="./scripts-offline-sign/signed-wasm-exec-pauser.json"
#SIGNED_TX="./scripts-offline-sign/signed-wasm-exec-metadata.json"
#SIGNED_TX="./scripts-offline-sign/signed-wasm-exec-mintercontroller.json"
#SIGNED_TX="./scripts-offline-sign/signed-wasm-exec-minter.json"
#SIGNED_TX="./scripts-offline-sign/signed-wasm-exec-mint.json"
#SIGNED_TX="./scripts-offline-sign/signed-wasm-exec-burn.json"
#SIGNED_TX="./scripts-offline-sign/signed-wasm-exec-blacklist.json"
#SIGNED_TX="./scripts-offline-sign/signed-wasm-exec-unblacklist.json"
#SIGNED_TX="./scripts-offline-sign/signed-wasm-exec-pause.json"
#SIGNED_TX="./scripts-offline-sign/signed-wasm-exec-unpause.json"
SIGNED_TX="./temp/signed-gentx.json"
BINARY tx validate-signatures $SIGNED_TX
  
```
## encode a unsigned tx
```shell
UNSIGNED_TX="./scripts-offline-sign/unsigned-send.json"
ENCODED=$(BINARY tx encode $UNSIGNED_TX)

DECODED=$(BINARY tx decode $ENCODED)

echo "encoded: $ENCODED"  
echo "decoded:"
echo $DECODED | jq

```

## encode a pre_sig tx which has auth_info but no signatures
```shell
UNSIGNED_TX="./scripts-offline-sign/pre_sig.json"
ENCODED=$(BINARY tx encode $UNSIGNED_TX)
#ENCODED=$(BINARY tx encode $UNSIGNED_TX | head -c 80)

DECODED=$(BINARY tx decode $ENCODED)

echo "encoded: $ENCODED"  
echo "decoded:"
echo $DECODED | jq

```

## encode a signed tx
```shell
#SIGNED_TX="./scripts-offline-sign/signed-send.json"
SIGNED_TX="./scripts-offline-sign/signed-gentx.json"
#SIGNED_TX="./scripts-offline-sign/signdoc_by_tfd_create_validator2.json"
ENCODED=$(BINARY tx encode $SIGNED_TX)
  
DECODED=$(BINARY tx decode $ENCODED)

echo "encoded: $ENCODED"  
echo "decoded:"
echo $DECODED | jq
  
```

### creat validator - used for gentx only
> - for coreblockchain which is PoAS, create-validator is only used for gentx
> - make sure from_address and the ed25519 key in the json are for the validator.
> - the resulting json has validator_address which is the valoper address derived from the from_address
> - the resulting json needs signer_infos (pubkey and sequence) to be filled for signing
> - delegator_address is deprecated so leave it blank.
> - CANNOT do simulate because of PoAS ante decorator restriction
> - NOTE: genesis gentx does not support --generate-only because it always signs.
> - NOTE: it is signed by the soft key of the validator account as an example down below. txsigner tool can also be used to sign it with hsm key.
```shell
# Configuration
#NODE_HOME=$NODE_HOME
UNSIGNED_TX="./scripts-offline-sign/unsigned-gentx.json"
FROM=$HSM_VALIDATOR
# Function to generate tx
#generate_tx() {    
   BINARY tx staking create-validator ./scripts-poas/validator2_file.json \
        --generate-only \
        --from=$FROM \
        > $UNSIGNED_TX
#}

# Step 1: Generate initial unsigned tx for simulation
#generate_tx

## Step 2: Simulate to get gas estimate
#GAS_USED=$($BINARY tx simulate $UNSIGNED_TX \
#    --from=$FROM \
#    --dry-run \
#    $NODE_HOME \
#    -o json | jq -r '.gas_info.gas_used')

##Step 3: Regenerate tx with calculated simulated GAS_USED
#generate_tx $GRANTER

```

### submit proposal - add validator
```shell
# Configuration
UNSIGNED_TX="./scripts-offline-sign/unsigned-submit-proposal.json"
GAS_PRICES="0.001uwfUSD"
GAS_ADJUSTMENT=2.0
GAS_USED=0
GRANTER=$FAUCET
FROM=$HSM_VALIDATOR
PROPOSAL_JSON="./scripts-offline-sign/proposal_gov_add_validator2.json"
# Function to generate tx
generate_tx() {
    gas_raw=$(echo "$GAS_USED * $GAS_ADJUSTMENT" | bc)
    gas=${gas_raw%.*}  
    
    local granter_flag=""
    if [ -n "$1" ]; then
      granter_flag="--fee-granter=$1"
    fi
    
   BINARY tx gov submit-proposal $PROPOSAL_JSON \
        --generate-only \
        --gas=$gas \
        --gas-prices=$GAS_PRICES \
        $granter_flag \
        --from=$FROM \
        > $UNSIGNED_TX
}

# Step 1: Generate initial unsigned tx for simulation
generate_tx

# Step 2: Simulate to get gas estimate
GAS_USED=$(BINARY tx simulate $UNSIGNED_TX \
    --from=$FROM \
    --dry-run \
    -o json | jq -r '.gas_info.gas_used')

# Step 3: Regenerate tx with calculated simulated GAS_USED
generate_tx $GRANTER
```

### vote
```shell
# Configuration
UNSIGNED_TX="./scripts-offline-sign/unsigned-vote.json"
GAS_PRICES="0.001uwfUSD"
GAS_ADJUSTMENT=2.0
GAS_USED=0
GRANTER=$FAUCET
FROM=$HSM_VALIDATOR
PROPOSAL_ID=1
# Function to generate tx
generate_tx() {
    gas_raw=$(echo "$GAS_USED * $GAS_ADJUSTMENT" | bc)
    gas=${gas_raw%.*}  
    
    local granter_flag=""
    if [ -n "$1" ]; then
      granter_flag="--fee-granter=$1"
    fi
    
   BINARY tx gov vote 1 yes \
        --generate-only \
        --gas=$gas \
        --gas-prices=$GAS_PRICES \
        $granter_flag \
        --from=$FROM \
        > $UNSIGNED_TX
}

# Step 1: Generate initial unsigned tx for simulation
generate_tx

# Step 2: Simulate to get gas estimate
GAS_USED=$(BINARY tx simulate $UNSIGNED_TX \
    --from=$FROM \
    --dry-run \
    -o json | jq -r '.gas_info.gas_used')

# Step 3: Regenerate tx with calculated simulated GAS_USED
generate_tx $GRANTER
```

### withdraw rewards
> - simulate requires the validator to exist so HSM_VALIDATOR will fail until the validator uses HSM for its account key.
```shell
# Configuration
UNSIGNED_TX="./scripts-offline-sign/unsigned-withdraw-rewards.json"
GAS_PRICES="0.001uwfUSD"
GAS_ADJUSTMENT=2.0
GAS_USED=0
GRANTER=$FAUCET
FROM=$HSM_VALIDATOR
VALOPER=$HSM_VALIDATOR_val_ADDR
# Function to generate tx
generate_tx() {
    gas_raw=$(echo "$GAS_USED * $GAS_ADJUSTMENT" | bc)
    gas=${gas_raw%.*}  
    
    local granter_flag=""
    if [ -n "$1" ]; then
      granter_flag="--fee-granter=$1"
    fi
    
   BINARY tx distribution withdraw-rewards $VALOPER \
        --generate-only \
        --gas=$gas \
        --gas-prices=$GAS_PRICES \
        $granter_flag \
        --from=$FROM \
        > $UNSIGNED_TX
}

# Step 1: Generate initial unsigned tx for simulation
generate_tx

# Step 2: Simulate to get gas estimate
GAS_USED=$(BINARY tx simulate $UNSIGNED_TX \
    --from=$FROM \
    --dry-run \
    -o json | jq -r '.gas_info.gas_used')

# Step 3: Regenerate tx with calculated simulated GAS_USED
generate_tx $GRANTER
```



## early tests
```shell
# the resulting json needs signer_infos (pubkey and sequence) to be filled for signing
# send tokens
UNSIGNED_TX="./scripts-offline-sign/unsigned-send.json"
GAS_PRICES="0.001uwfUSD"
GAS_ADJUSTMENT=1.5
$BINARY tx bank send $USER1 $USER2 10uwfUSD \
  --generate-only \
  $NODE_HOME \
  > $UNSIGNED_TX

GAS_USED=$($BINARY tx simulate $UNSIGNED_TX \
  --from=$USER1 \
  --dry-run \
  $NODE_HOME \
  -o json | jq '.gas_info.gas_used')

GAS=${$((GAS_USED * GAS_ADJUSTMENT))%.*}
BINARY tx bank send $USER1 $USER2 10uwfUSD \
  --generate-only \
  --gas=$GAS \
  --gas-prices=$GAS_PRICES \
  $NODE_HOME \
  > $UNSIGNED_TX


# tf masterminter
$BINARY tx tokenfactory update-master-minter $MASTERMINTER \
  --from=$TF_OWNER \
  --generate-only \
  --fees=200uwfUSD \
  $NODE_HOME \
  > "./scripts-offline-sign/unsigned-tf-masterminter.json"

# tf mintercontroller
$BINARY tx tokenfactory configure-minter-controller $MINTERCONTROLLER $MINTER \
  --from=$MASTERMINTER \
  --generate-only \
  --fees=200uwfUSD \
  $NODE_CHAIN \
  $NODE_HOME \
  $NODE_CHAIN_ID \
  > "./scripts-offline-sign/unsigned-tf-mintercontroller.json"

# tf minter
$BINARY tx tokenfactory configure-minter $MINTER 1000000000uwfUSD \
  --from=$MINTERCONTROLLER \
  --generate-only \
  --fees=200uwfUSD \
  $NODE_CHAIN \
  $NODE_HOME \
  $NODE_CHAIN_ID \
  > "./scripts-offline-sign/unsigned-tf-minter.json"
  
# tf mint
$BINARY tx tokenfactory mint $USER1 1000uwfUSD \
  --from=$MINTER \
  --generate-only \
  --fees=200uwfUSD \
  $NODE_HOME \
  > "./scripts-offline-sign/unsigned-tf-mint.json"
    
# for coreblockchain which is PoAS, create-validator is only used for gentx
# make sure from_address and the ed25519 key in the json are for the validator.
# the resulting json has validator_address which is the valoper address derived from the from_address
# the resulting json needs signer_infos (pubkey and sequence) to be filled for signing
#  delegator_address is deprecated so can be anything (our signer may fill it with the signer account address)
$BINARY tx staking create-validator ./scripts-poas/validator2_file.json \
  --from=$VALIDATOR \
  --generate-only \
  $NODE_HOME \
  $NODE_CHAIN_ID \
  > "./scripts-offline-sign/unsigned-create-validator2.json"

# unjail
$BINARY tx slashing unjail \
  --from=$VALIDATOR \
  --generate-only \
  --fees=200uwfUSD \
  $NODE_HOME \
  $NODE_CHAIN_ID \
  > "./scripts-offline-sign/unsigned-unjail.json"

# withdraw rewards
# VALIDATOR_val_ADDR can be queried via $BINARY debug addr $VALIDATOR
$BINARY tx distribution withdraw-rewards $VALIDATOR_val_ADDR \
  --generate-only \
  --fees=200uwfUSD \
  $NODE_HOME \
  $NODE_CHAIN_ID \
  > "./scripts-offline-sign/unsigned-withdraw-rewards.json"

# submit-proposal
$BINARY tx gov submit-proposal ./scripts-poas/proposal_gov_add_validator2.json \
  --from=$VALIDATOR \
  --fees=200uwfUSD \
  --generate-only \
  $NODE_HOME \
  $NODE_CHAIN_ID \
  > "./scripts-offline-sign/unsigned-submit-proposal.json"

# vote
#BINARY tx gov submit-proposal ./scripts-poas/proposal_gov_add_validator2.json "${TXFLAG[@]}" -y --from=validator
BINARY tx gov vote 1 yes \
  --from=$VALIDATOR \
  --generate-only \
  --fees=200uwfUSD \
  > "./scripts-offline-sign/unsigned-vote.json"

#BINARY tx gov vote 1 yes \
#  --from=$VALIDATOR \
#  --fees=200uwfUSD \
#  $KEYRING


# wasm store without simulate so it is offline
$BINARY tx wasm store ../../../rust/cosmos/cw-tokenfactory/target/wasm32-unknown-unknown/release/tokenfactory_optimized.wasm \
#$BINARY tx wasm store ../../../rust/cosmos/wfdc2/target/wasm32-unknown-unknown/release/tokenfactory_optimized.wasm \
  --from=$TF_OWNER \
  --generate-only \
  --gas=3000000 \
  --fees=3000uwfUSD \
  $NODE_HOME \
  > "./scripts-offline-sign/unsigned-wasm-store.json"

$BINARY tx wasm store ../../../rust/cosmos/cw-tokenfactory/target/wasm32-unknown-unknown/release/tokenfactory_optimized.wasm \
  --from=$USER1_FX \
  --generate-only \
  --gas=3000000 \
  --fees=3000uwfUSD \
  $NODE_HOME \
  > "./scripts-offline-sign/unsigned-wasm-store-fx.json"
  

# wasm instantiate 
INIT=$(jq -n --arg is_tf "true" '{ "is_tf": $is_tf | test("true") }') && \
BINARY tx wasm instantiate 1 "$INIT" --label "tf" --no-admin \
  --from=$TF_OWNER \
  --generate-only \
  --fees=200uwfUSD \
  $NODE_HOME \
  $NODE_CHAIN_ID \
  > "./scripts-offline-sign/unsigned-wasm-instantiate.json"

# wasm execute update masterminter
CONTRACT_ADDRESS='wf14hj2tavq8fpesdwxxcu44rty3hh90vhujrvcmstl4zr3txmfvw9s2s4a5q' && \
JSON=$(jq -n --arg address "$MASTERMINTER" \
'{ tf: { "update_master_minter": { "address": $address } } }') && \
BINARY tx wasm execute $CONTRACT_ADDRESS "$JSON" \
  --from=$TF_OWNER \
  --generate-only \
  --fees=200uwfUSD \
  $NODE_HOME \
  $NODE_CHAIN_ID \
  > "./scripts-offline-sign/unsigned-wasm-exec-masterminter.json"

# wasm execute update blacklister
CONTRACT_ADDRESS='wf14hj2tavq8fpesdwxxcu44rty3hh90vhujrvcmstl4zr3txmfvw9s2s4a5q' && \
JSON=$(jq -n --arg address "$BLACKLISTER" \
'{ tf: { "update_blacklister": { "address": $address } } }') && \
BINARY tx wasm execute $CONTRACT_ADDRESS "$JSON" \
  --from=$TF_OWNER \
  --generate-only \
  --fees=200uwfUSD \
  $NODE_HOME \
  $NODE_CHAIN_ID \
  > "./scripts-offline-sign/unsigned-wasm-exec-blacklister.json"

# wasm execute update pauser
CONTRACT_ADDRESS='wf14hj2tavq8fpesdwxxcu44rty3hh90vhujrvcmstl4zr3txmfvw9s2s4a5q' && \
JSON=$(jq -n --arg address "$PAUSER" \
'{ tf: { "update_pauser": { "address": $address } } }') && \
BINARY tx wasm execute $CONTRACT_ADDRESS "$JSON" \
  --from=$TF_OWNER \
  --generate-only \
  --fees=200uwfUSD \
  $NODE_HOME \
  $NODE_CHAIN_ID \
  > "./scripts-offline-sign/unsigned-wasm-exec-pauser.json"

# wasm execute denom metadata
CONTRACT_ADDRESS='wf14hj2tavq8fpesdwxxcu44rty3hh90vhujrvcmstl4zr3txmfvw9s2s4a5q' && \
METADATA='{
    "description": "BTC Wrapped and Issued on Tokenfactory",
    "denom_units": [
      {
        "denom": "wSAT",
        "exponent": 0,
        "aliases": ["wSatoshi"]
      },
      {
        "denom": "wmBTC",
        "exponent": 5,
        "aliases": ["wMillibitcoin"]
      },
      {
        "denom": "wBTC",
        "exponent": 8,
        "aliases": ["wBitcoin"]
      }
    ],
    "base": "wSAT",
    "display": "wBTC",
    "name": "Wrapped BTC",
    "symbol": "wBTC",
    "uri": "",
    "uri_hash": ""
}' && \
JSON=$(jq -n --argjson metadata "$METADATA" \
'{ tf: { "set_denom_metadata": { "metadata": $metadata } } }') && \
BINARY tx wasm execute $CONTRACT_ADDRESS "$JSON" \
  --from=$MASTERMINTER \
  --generate-only \
  --fees=200uwfUSD \
  $NODE_HOME \
  $NODE_CHAIN_ID \
  > "./scripts-offline-sign/unsigned-wasm-exec-metadata.json"
  
# wasm execute configure minter controller
CONTRACT_ADDRESS='wf14hj2tavq8fpesdwxxcu44rty3hh90vhujrvcmstl4zr3txmfvw9s2s4a5q' && \
JSON=$(jq -n --arg controller "$MINTERCONTROLLER" --arg minter "$MINTER" \
'{ tf: { "configure_minter_controller": { "controller": $controller, "minter": $minter } } }') && \
BINARY tx wasm execute $CONTRACT_ADDRESS "$JSON" \
  --from=$MASTERMINTER \
  --generate-only \
  --fees=200uwfUSD \
  $NODE_HOME \
  $NODE_CHAIN_ID \
  > "./scripts-offline-sign/unsigned-wasm-exec-mintercontroller.json"

# wasm execute configure minter
CONTRACT_ADDRESS='wf14hj2tavq8fpesdwxxcu44rty3hh90vhujrvcmstl4zr3txmfvw9s2s4a5q' && \
JSON=$(jq -n --arg address "$MINTER" --arg allowance_denom "uwfUSD" --arg allowance_value "100000000" \
'{ tf: { "configure_minter": { "address": $address, "allowance_denom": $allowance_denom, "allowance_value": $allowance_value } } }') && \
BINARY tx wasm execute $CONTRACT_ADDRESS "$JSON" \
  --from=$MINTERCONTROLLER \
  --generate-only \
  --fees=200uwfUSD \
  $NODE_HOME \
  $NODE_CHAIN_ID \
  > "./scripts-offline-sign/unsigned-wasm-exec-minter.json"

# wasm execute mint
CONTRACT_ADDRESS='wf14hj2tavq8fpesdwxxcu44rty3hh90vhujrvcmstl4zr3txmfvw9s2s4a5q' && \
JSON=$(jq -n --arg address "$USER1" --arg denom "uwfUSD" --arg value "100" \
'{ tf: { "mint": { "address": $address, "denom": $denom, "value": $value } } }') && \
BINARY tx wasm execute $CONTRACT_ADDRESS "$JSON" \
  --from=$MINTER \
  --generate-only \
  --fees=200uwfUSD \
  $NODE_HOME \
  $NODE_CHAIN_ID \
  > "./scripts-offline-sign/unsigned-wasm-exec-mint.json"

# before burn, need to send uwfUSD to minter
$BINARY tx bank send $USER1 $MINTER 100uwfUSD \
  --generate-only \
  --fees=200uwfUSD \
  $NODE_CHAIN \
  $NODE_HOME \
  $NODE_CHAIN_ID \
  > "./scripts-offline-sign/unsigned-send.json"

# wasm execute burn
CONTRACT_ADDRESS='wf14hj2tavq8fpesdwxxcu44rty3hh90vhujrvcmstl4zr3txmfvw9s2s4a5q' && \
JSON=$(jq -n --arg denom "uwfUSD" --arg value "100" \
'{ tf: { "burn": { "denom": $denom, "value": $value } } }') && \
BINARY tx wasm execute $CONTRACT_ADDRESS "$JSON" \
  --from=$MINTER \
  --generate-only \
  --fees=200uwfUSD \
  $NODE_HOME \
  $NODE_CHAIN_ID \
  > "./scripts-offline-sign/unsigned-wasm-exec-burn.json"
  
# wasm execute blacklist
CONTRACT_ADDRESS='wf14hj2tavq8fpesdwxxcu44rty3hh90vhujrvcmstl4zr3txmfvw9s2s4a5q' && \
JSON=$(jq -n --arg address "$USER1" \
'{ tf: { "blacklist": { "address": $address } } }') && \
BINARY tx wasm execute $CONTRACT_ADDRESS "$JSON" \
  --from=$BLACKLISTER \
  --generate-only \
  --fees=200uwfUSD \
  $NODE_HOME \
  $NODE_CHAIN_ID \
  > "./scripts-offline-sign/unsigned-wasm-exec-blacklist.json"
        
# wasm execute unblacklist
CONTRACT_ADDRESS='wf14hj2tavq8fpesdwxxcu44rty3hh90vhujrvcmstl4zr3txmfvw9s2s4a5q' && \
JSON=$(jq -n --arg address "$USER1" \
'{ tf: { "unblacklist": { "address": $address } } }') && \
BINARY tx wasm execute $CONTRACT_ADDRESS "$JSON" \
  --from=$BLACKLISTER \
  --generate-only \
  --fees=200uwfUSD \
  $NODE_HOME \
  $NODE_CHAIN_ID \
  > "./scripts-offline-sign/unsigned-wasm-exec-unblacklist.json"

# wasm execute pause
CONTRACT_ADDRESS='wf14hj2tavq8fpesdwxxcu44rty3hh90vhujrvcmstl4zr3txmfvw9s2s4a5q' && \
JSON=$(jq -n \
'{ tf: { "pause": { } } }') && \
BINARY tx wasm execute $CONTRACT_ADDRESS "$JSON" \
  --from=$PAUSER \
  --generate-only \
  --fees=200uwfUSD \
  $NODE_HOME \
  $NODE_CHAIN_ID \
  > "./scripts-offline-sign/unsigned-wasm-exec-pause.json"
  
# wasm execute unpause
CONTRACT_ADDRESS='wf14hj2tavq8fpesdwxxcu44rty3hh90vhujrvcmstl4zr3txmfvw9s2s4a5q' && \
JSON=$(jq -n \
'{ tf: { "unpause": { } } }') && \
BINARY tx wasm execute $CONTRACT_ADDRESS "$JSON" \
  --from=$PAUSER \
  --generate-only \
  --fees=200uwfUSD \
  $NODE_HOME \
  $NODE_CHAIN_ID \
  > "./scripts-offline-sign/unsigned-wasm-exec-unpause.json"
``` 

## broadcast signed txs
```shell
#SIGNED_TX=./scripts-offline-sign/signed-gentx.json 
#SIGNED_TX=./scripts-offline-sign/signed-feegrant.json 
#SIGNED_TX=./scripts-offline-sign/signed-send.json
#SIGNED_TX=./scripts-offline-sign/signed-wasm-store.json
#SIGNED_TX=./scripts-offline-sign/signed-wasm-instantiate.json
#SIGNED_TX=./scripts-offline-sign/signed-tf-masterminter.json 
#SIGNED_TX=./scripts-offline-sign/signed-tf-blacklister.json 
#SIGNED_TX=./scripts-offline-sign/signed-tf-pauser.json 
#SIGNED_TX=./scripts-offline-sign/signed-tf-mintercontroller.json 
#SIGNED_TX=./scripts-offline-sign/signed-tf-minter.json 
#SIGNED_TX=./scripts-offline-sign/signed-tf-mint.json 
#SIGNED_TX=./scripts-offline-sign/signed-tf-burn.json 
#SIGNED_TX=./scripts-offline-sign/signed-tf-metadata.json 
#SIGNED_TX=./scripts-offline-sign/signed-tf-blacklist.json 
#SIGNED_TX=./scripts-offline-sign/signed-tf-blacklist.json 
#SIGNED_TX=./scripts-offline-sign/signed-tf-pause.json 
#SIGNED_TX=./scripts-offline-sign/signed-tf-unpause.json 
SIGNED_TX=./scripts-offline-sign/signed-wasm-exec-mint.json 
#SIGNED_TX=./scripts-offline-sign/signed-submit-proposal.json 
#SIGNED_TX=./scripts-offline-sign/signed-vote.json 
BINARY tx broadcast $SIGNED_TX \
  -b sync \
  -y  
    

# "./scripts-offline-sign/signdoc_by_tfd_create_validator2.json" is the same as "./scripts-offline-sign/signed-create-validator2.json"
tfd tx sign "./scripts-offline-sign/unsigned-create-validator2.json" \
  --from=$VALIDATOR \
  --offline \
  --sign-mode direct \
  --chain-id tokenfactory-1 \
  --account-number 18 \
  --sequence 2 \
  $NODE_HOME $KEYRING \
  --output-document "./scripts-offline-sign/signdoc_by_tfd_create_validator2.json" \
  --output json > "./scripts-offline-sign/signed-create-validator2.json"


BINARY tx sign "./scripts-offline-sign/unsigned-create-validator2.json" \
  --from $VALIDATOR \
  $KEYRING \
  $NODE_CHAIN \
  $NODE_CHAIN_ID \
  > "./scripts-offline-sign/signed-create-validator2.json"
    

```