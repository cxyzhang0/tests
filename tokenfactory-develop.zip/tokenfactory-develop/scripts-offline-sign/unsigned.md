### send
```shell
# Configuration
UNSIGNED_TX="./scripts-offline-sign/unsigned-send.json"
GAS_PRICES="0.001uwfUSD"
GAS_ADJUSTMENT=2.0
GAS_USED=0
GRANTER=$FAUCET
FROM=$USER1_FX
TO=$USER2_FX
AMOUNT="10uwfUSD"
# Function to generate tx
generate_tx() {
    gas_raw=$(echo "$GAS_USED * $GAS_ADJUSTMENT" | bc)
    gas=${gas_raw%.*}  

    local granter_flag=""
    if [ -n "$1" ]; then
      granter_flag="--fee-granter=$1"
    fi

   BINARY tx bank send $FROM $TO $AMOUNT \
        --generate-only \
        --gas=$gas \
        --gas-prices=$GAS_PRICES \
        $granter_flag \
        > $UNSIGNED_TX
}

# Step 1: Generate initial unsigned tx for simulation
generate_tx

# Step 2: Simulate to get gas estimate
GAS_USED=$(BINARY tx simulate $UNSIGNED_TX \
    --from=$FROM \
    --dry-run \
    -o json | jq -r '.gas_info.gas_used')

# Step 3: Regenerate tx with calculated simulated GAS_USED
generate_tx $GRANTER
```

### fee grant
```shell
# Configuration
UNSIGNED_TX="./scripts-offline-sign/unsigned-feegrant.json"
GAS_PRICES="0.001uwfUSD"
GAS_ADJUSTMENT=2.0
GAS_USED=0
GRANTER=$FAUCET
LIMIT="10000uwfUSD"
EXPIRATION="2026-12-31T23:59:59Z"
#GRANTEE=$TF_OWNER
#GRANTEE=$MASTERMINTER
#GRANTEE=$MINTERCONTROLLER
#GRANTEE=$MINTER
#GRANTEE=$HSM_VALIDATOR
#GRANTEE=$VALIDATOR
#GRANTEE=$BLACKLISTER
#GRANTEE=$PAUSER
GRANTEE=$USER1_FX
# Function to generate tx
generate_tx() {
    gas_raw=$(echo "$GAS_USED * $GAS_ADJUSTMENT" | bc)
    gas=${gas_raw%.*}  
    
   BINARY tx feegrant grant $GRANTER $GRANTEE \
        --generate-only \
        --gas=$gas \
        --gas-prices=$GAS_PRICES \
        --spend-limit=$LIMIT \
        --expiration $EXPIRATION \
        > $UNSIGNED_TX
}

# Step 1: Generate initial unsigned tx for simulation
generate_tx

# Step 2: Simulate to get gas estimate
GAS_USED=$(BINARY tx simulate $UNSIGNED_TX \
    --from=$GRANTER \
    --dry-run \
    -o json | jq -r '.gas_info.gas_used')

# Step 3: Regenerate tx with calculated simulated GAS_USED
generate_tx
```