# Developer notes
> 2024-3-26: branch sean/multi-denom was originally created from main as a POC to extend the original tokenfactory 
 to support multiple minting denoms. It successfully demonstrated the feasibility.  

> 2025-03-05: sean/multi-denom-2 was created by merging sean/multi-denom into sean/working to continue the work to overcome all the limitations.

> 2025-04-23: sean/migrate-multi-denom-2 was created from sean/multi-denom-2 to add upgrade functionality so that the new tfd daemon can migrate the store  
and continue on instead of starting from genesis.
> -  code changes: ref: https://docs.cosmos.network/main/learn/advanced/upgrade
>   - app.go: tokenfactorymodulekeeper.NewKeeper has a new field storeService
>   - upgrades.go: UpgradeName = "multidenom-v1tov2", it matches MsgSoftwareUpgrade name in upgrade-info.json
>   - tokenfactory Keeper: a new field storeService
>   - tokenfactory/module.go: 
>     - ConsensusVersion: 2
>     - RegisterServices: cfg.RegisterMigration
>   - tokenfactory/keeper/migrations.go: new file
>   - tokenfactory/migrations/: migration scripts  
> -  submit gov proposal to get the upgrade approved and to trigger the upgrade.
>   - while running the chain with the old daemon
>     - submit-proposal (see shell scripts below)
>       - modify upgrade-info-v1tov2.json
>         - authority is gov address: 
>           - tfd q auth module-account gov $NODE_HOME or
>           - tfd q upgrade authority $NODE_HOME
>         - to properly set the height.
>         - makes sure name matches that in upgrades.go; e.g., "multidenom-v1tov2" for the multi-denom upgrade.
>         - use expedited voting period to speed up the testing. default is 24hrs, but can be shortened in the original genesis.json.
>         - make sure height is after the voting period.
>     - vote (see shell scripts below)
>       - voting ends after the voting period and result will be immediately available.
>     - if after the proposal is passed/approved (status = 3), the chain will crash/halt at the height as specified in the proposal.
>     - stop the chain (kill the daemon process)
>   - continue the chain by starting with the new daemon
>     - the migration scripts will run automatically 
>     - the chain will continue
>     - query to validate the migration

> See scripts.md, play_multi_denom.sh and chains_multi_denom.env for details on how to build, run and test.  

> The current limitations are:  
> - done mintingDenomList is only defined in genesis (it should be a subset of denom_metadata). To be robust, we need to add tx to update both mintintDenomList and denom_metadata.
> - - ?: update denom-metadata: this needs governance proposal and vote.
> - - - tfd q auth module-account gov
> - - - tfd q gov params
> - - - tfd tx gov submit-proposal --title "update denom-metadata" --description "update denom-metadata" --type="tokenfactory/UpdateDenomMetadata" --from mintercontroller --module-account gov --module-name tokenfactory --denom-metadata <denom-metadata>
> - - - tfd tx gov vote <proposal-id> yes
> - - - conclusion: even with the governance proposal and vote process, we still need a tx to update denom-metadata.
> - - - so we work on the tx first. whether we need governance proposal and vote to run the tx is a separate issue.
> - - after denom-metadata is updated with the new denom, update mintingDenomList: this needs a tx to update mintingDenomList.
> - - or we combine SetDenomMetadata and UpdatingMintingDenomList into a single tx.
> - - - this is the approach implemented. we now have a new tx set-denom-metadata which takes medata string as the argument.
> - done except for wasm binding - The current datamodel for mintercontroller is such that one controller can only be paired to one minter at a time because the controller address is the primary key. We may need to make (controller, minter) the primary key.
> - done except for wasm binding - The current datamodel for minters only supports one denom per minter because minter address is the primary key. We may need to make (address, denom) the primary key.
> - fixed - Burn: minter for wfusd can burn wfdc. This should be disallowed.
> - done Need to update wasm binding accordingly.

### gov proposal and vote
```shell
# note: shorten expedited voting period to help testing - add this in play_tf.sh: sed -i '' 's/"expedited_voting_period": "86400s"/"expedited_voting_period": "3600s"/g' $CHAINDIR/$CHAINID/config/genesis.json

# don't use legacy proposal: tfd tx gov submit-legacy-proposal

# (optional since we already have /upgrade-info-v1tov2.json as a template) interactive creation of a draft proposal: draft_metadata.json, draft_proposal.json
tfd tx gov draft-proposal
# submit proposal: import fields: name, height,  deposit, expedited 
tfd tx gov submit-proposal ./upgrade-info-v1tov2.json --from validator $NODE_CHAIN $NODE_HOME $KEYRING -y
## B600DD3B4C92460A7BBBC99C9816084A326A6768447E4898B1499D2EFAF2CB8F
## proposal_id: 1

# this is another to make the proposal but seems to be legacy format; not tested yet, missing params
# tfd tx upgrade software-upgrade --a few params --from validator $NODE_CHAIN $NODE_HOME $KEYRING -y
# is it another proposal? tfd tx upgrade cancel-software-upgrade --from validator $NODE_CHAIN $NODE_HOME $KEYRING -y

# vote yes
tfd tx gov vote 1 yes --from validator $NODE_CHAIN $NODE_HOME $KEYRING -y
## F329A98EB14423D4478A124022552187898D3E0FDBBA204D52A90E9218A34F8D

# query proposal:
## note yes_count is always 0
tfd q gov proposal 1 $NODE_HOME 
##// ProposalStatus enumerates the valid statuses of a proposal.
##enum ProposalStatus {
##  // PROPOSAL_STATUS_UNSPECIFIED defines the default proposal status.
##  PROPOSAL_STATUS_UNSPECIFIED = 0;
##  // PROPOSAL_STATUS_DEPOSIT_PERIOD defines a proposal status during the deposit
##  // period.
##  PROPOSAL_STATUS_DEPOSIT_PERIOD = 1;
##  // PROPOSAL_STATUS_VOTING_PERIOD defines a proposal status during the voting
##  // period.
##  PROPOSAL_STATUS_VOTING_PERIOD = 2;
##  // PROPOSAL_STATUS_PASSED defines a proposal status of a proposal that has
##  // passed.
##  PROPOSAL_STATUS_PASSED = 3;
##  // PROPOSAL_STATUS_REJECTED defines a proposal status of a proposal that has
##  // been rejected.
##  PROPOSAL_STATUS_REJECTED = 4;
##  // PROPOSAL_STATUS_FAILED defines a proposal status of a proposal that has
##  // failed.
##  PROPOSAL_STATUS_FAILED = 5;
##}
##

# this gives the correct counts
## this gives the correct counts
tfd q gov tally 1 $NODE_HOME  

## in case deposits are not enough, add more
tfd q gov deposits 1 $NODE_HOME 
tfd q gov deposit 1 $VALIDATOR $NODE_HOME
tfd tx gov deposit 1 1000000stake --from validator $NODE_CHAIN $NODE_HOME $KEYRING -y
 
# query upgrade
## get details of an applied upgrade
tfd q upgrade applied "multidenom-v1tov2" $NODE_HOME ## this only returns height; but according to doc, there should be more
## get current module versions
tfd q upgrade module-versions $NODE_HOME
tfd q upgrade module-versions "tokenfactory" $NODE_HOME
## get currently scheduled plan if any
tfd q upgrade plan $NODE_HOME
 
# query stakes
tfd q staking -h
tfd q staking validators $NODE_HOME
tfd q staking validator wfvaloper10xr3uvutqslghk9m8p6samuwjjetgmdfn97k3y $NODE_HOME
tfd q staking pool $NODE_HOME  
 
tfd q staking delegations $VALIDATOR $NODE_HOME
tfd q staking delegations-to wfvaloper10xr3uvutqslghk9m8p6samuwjjetgmdfn97k3y $NODE_HOME
```

These are the files that were modified for sean/multi-denom-2:
```shell
       modified:   app.go
       modified:   build.sh
       modified:   chain.sh
       modified:   Developer.md
        modified:   Makefile
        modified:   chains_multi_denom.env
        modified:   play_multi_denom.sh
        modified:   proto/tokenfactory/genesis.proto
        modified:   proto/tokenfactory/query.proto
        modified:   scripts_multi_denom.md
        modified:   x/blockibc/blockibc.go
        modified:   x/contracts/tokenfactory/bindings/query.go
        modified:   x/contracts/tokenfactory/queries.go
        modified:   x/contracts/tokenfactory/query_plugin.go
        modified:   x/tokenfactory/client/cli/query_minting_denom.go
        modified:   x/tokenfactory/client/cli/query_minting_denom_test.go
        modified:   x/tokenfactory/genesis.go
        modified:   x/tokenfactory/keeper/grpc_query_minting_denom.go
        modified:   x/tokenfactory/keeper/grpc_query_minting_denom_test.go
        modified:   x/tokenfactory/keeper/minting_denom.go
        modified:   x/tokenfactory/keeper/minting_denom_test.go
        modified:   x/tokenfactory/keeper/msg_server_burn.go
        modified:   x/tokenfactory/keeper/msg_server_configure_minter.go
        modified:   x/tokenfactory/keeper/msg_server_mint.go
        modified:   x/tokenfactory/module_simulation.go
        modified:   x/tokenfactory/types/genesis.go
        modified:   x/tokenfactory/types/genesis.pb.go
        modified:   x/tokenfactory/types/genesis_test.go
        modified:   x/tokenfactory/types/keys.go
        modified:   x/tokenfactory/types/query.pb.go
        modified:   x/tokenfactory/types/query.pb.gw.go
```
> Making tokenfactory support multiple minting denoms is necessary now because we are doing POC of WaaS which mints wrapped coins such as wbtc, beth, etc.  
> xEven though it is feadible to extend the tokenfactory to support multiple minting denominations, it is not necessarily urgent to focus on this at this moment because of other priorities.  
> xOur current tokenfactory chain as is is sufficient to production-support a single currency (USD) wfdc2 and the deposit token because we may have two modules: x/tokenfactory and x/fiat-tokenfactory.    
> xIf the production wfdc2 needs to exend to multi-currencies, we can revisit it. Remember we have been waiting for the WFDC production for many years and it is currently in no sight. 

