## tests
### existing unit tests for each module
### existing interchain tests in ./interchaintest
### x/tokenfactory tests - make sure all edge cases are covered
### x/contracts tests - make sure all cases are covered

## cosmos-sdk
### learn how to modify a module by adding new states and messages
### learn how to upgrade a module.

## future work
### eureka POC - ref eureka.md
>- analyze interchain-wf-demo-wfchain to see how to integrate with euraka
### replace tokenfactory by ciclefin's fiattokenfactory by forking fiattokenfactory and adding functions from tokenfactory
>- import instead of in place
### cctp





