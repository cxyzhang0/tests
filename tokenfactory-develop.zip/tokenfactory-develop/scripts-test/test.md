## help
```shell
go help test
go help testflag
```

# run all tests
```shell
go test -v ./...
go test -v ./... > ./scripts-test/tests.out 2>&1 &

```

## run all tests with coverage
```shell
go test -v -coverpkg=./... -cover -coverprofile=./scripts-test/coverage.out ./...
go test -v -cover -coverprofile=./scripts-test/coverage.out ./...
go tool cover -html=./scripts-test/coverage.out
go tool cover -func=./scripts-test/coverage.out

```

## x/tokenfactory test coverage
```shell
go test -v -cover -coverprofile=./scripts-test/coverage.out ./x/tokenfactory -run '^Test'
go tool cover -html=./scripts-test/coverage.out

go tool cover -func=./scripts-test/coverage.out | grep ante_tf.go
```

## x/poas test coverage
```shell
go test -v -cover -coverprofile=./scripts-test/coverage.out ./x/poas -run '^Test'
go tool cover -html=./scripts-test/coverage.out
go tool cover -func=./scripts-test/coverage.out
```

## cmd test coverage
```shell
go test -v -cover -coverprofile=./scripts-test/coverage.out ./cmd -run '^Test'
go tool cover -html=./scripts-test/coverage.out
go tool cover -func=./scripts-test/coverage.out
```