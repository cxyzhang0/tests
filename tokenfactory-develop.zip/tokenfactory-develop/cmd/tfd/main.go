package main

import (
	svrcmd "github.com/cosmos/cosmos-sdk/server/cmd"
	"github.com/wfblockchain/coreblockchain/v2/app"
	"github.com/wfblockchain/coreblockchain/v2/cmd"
)

func main() {
	rootCmd := cmd.NewRootCmd()

	svrcmd.Execute(rootCmd, "", app.DefaultNodeHome)
}
