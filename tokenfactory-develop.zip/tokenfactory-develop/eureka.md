## POC Integration with Eureka
### Prerequisites
>- upgrade ibc to v10 from v8 https://ibc.cosmos.network/v10/migrations/v8_1-to-v10/
>  - v10 does not have modules/capacity anymore
>  - v10 does not have modules/apps/29-fee anymore
>  - packetforward has two repos: 
>    - https://github.com/cosmos/ibc-go/tree/main/modules/apps/packet-forward-middleware used by simapp https://github.com/cosmos/ibc-go/blob/main/simapp/app.go
>    - https://github.com/cosmos/ibc-apps/tree/main/middleware/packet-forward-middleware used by gaia https://github.com/cosmos/gaia/blob/main/app/keepers/keepers.go
>    - we follow gaia
>  - ?do we need to update cosmos-sdk and/or cometbft: gaia uses v0.53.3 and v0.38.18 and we are using v0.53.0 and v0.38.17; cometbft now has v1.0.1
>    - need to use cosmos-sdk v0.53.3 for 
>  - ?do we need to update wasmd and wasmvm: gaia uses v0.60.1 and wasmvm/v2 v2.2.4 and we v0.51.0 and wasmvm/v2 v2.0.0 and wasmvm v1.5.2
>    - need to use wasmd v0.60.1 for wasmStackIBCHandler
>  - add dependency on 08-wasm module https://ibc.cosmos.network/v10/ibc/light-clients/wasm/integration/
>    - ref gaia https://github.com/cosmos/gaia/blob/main/go.mod
>    - ref https://pkg.go.dev/github.com/cosmos/ibc-go/modules/light-clients/08-wasm/v10#readme-version-matrix
>  - x/blockibc, x/forwarding, x/tarrif still depends on ibc-go/v8, which causes build to fail because v8 and v10 are not compatible: because they have the same errors code.
>    - so we delete them from the branch.
>    - note: noble-assets has a repo for forwarding, so later we should use that instead of x/forwarding local module.
>  - circlefin's fiattokenfactory depends on ibc-go/v8, which again causes build to fail for the same reason as above.
>    - what can we do to resolve this? remove the dependency and replace it with tokenfactory as placeholder, which means is_tf = true/false will direct to tokenfactory only.
>    - cctp dependes on fiattokenfactory, we will remove it too.
>  - things learned during the upgrade:
>    - only one ibc-go can be in the build: either ibc-go/v8 or ibc-go/v10. cctp, fiattokenfactory still depends on ibc-go/v8, so we remove them.
>    - app/errors and x/tokenfactory/errors can not have the same codespace so the former is app-tokenfactory and the latter is tokenfactory.
>    - cli can use dependency injection. this is for future refactoring.
>- eureka light client .wasm file
   >  - build .wasm file per https://github.com/cosmos/solidity-ibc-eureka/blob/main/programs/cw-ics08-wasm-eth/README.md
>  - store .wasm on chain
>  - ?instantiate the light client upon receiving a relayer-submitted MsgCreateClient. https://ibc.cosmos.network/v10/ibc/light-clients/wasm/overview/
>  - affirmative to the above question. per https://ibc.cosmos.network/v10/ibc/light-clients/wasm/messages/, 
>  - why do we need github.com/wfblockchain/noble-paramauthority v1.1.1-0.20250619112332-55984f81c547

### additional dependencies (as compared to interchain-wf-demo-wfchain)
```shell
cosmos-sdk 0.53.4 instead of 0.53.3
removed wasmvm, wasmd
cosmossdk.io/collections v1.3.1
github.com/cosmos/gogoproto v1.7.0
github.com/cosmos/ibc-go/modules/light-clients/08-wasm/v10 v10.0.0-20250826092355-12126c98ead7 instead of v10.3.0
github.com/cosmos/solidity-ibc-eureka/packages/go-abigen v0.0.0-20250830091122-66e14022b770
github.com/ethereum/go-ethereum v1.15.11
github.com/grpc-ecosystem/grpc-gateway/v2 v2.27.2
github.com/stretchr/testify v1.11.1 instead of v1.10..0
google.golang.org/grpc v1.75.0 instead of v1.72.2
golang.org/x/tools v0.36.0
google.golang.org/genproto/googleapis/api v0.0.0-20250826171959-ef028d996bc1 instead of v0.0.0-20250528174236-200df99c418a
google.golang.org/grpc/cmd/protoc-gen-go-grpc v1.5.1
google.golang.org/protobuf v1.36.8 instead of v1.36.6

replace (
	github.com/cosmos/ibc-go/modules/light-clients/08-wasm/v10 => github.com/cosmos/ibc-go/modules/light-clients/08-wasm/v10 v10.0.0-20250830103228-0c440fd84655
	// use contract-call branch of ibc-go
	github.com/cosmos/ibc-go/v10 => github.com/cosmos/ibc-go/v10 v10.0.0-beta.0.0.20250830103228-0c440fd84655
	// replace broken goleveldb
	github.com/syndtr/goleveldb => github.com/syndtr/goleveldb v1.0.1-0.20210819022825-2ae1ddf74ef7
)
  
```

```shell
openssl sha256 ../../../../Project/monorepos/solidity-ibc-eureka/artifacts/cw_ics08_wasm_eth.wasm
# sha256sum ../../../../Project/monorepos/solidity-ibc-eureka/artifacts/cw_ics08_wasm_eth.wasm
base64 -i ../../../../Project/monorepos/solidity-ibc-eureka/artifacts/cw_ics08_wasm_eth.wasm -o base64_wasm.tx 
gzip -9 -k ./cw_ics08_wasm_eth.wasm

tfd q gov params $NODE_CHAIN  

### this one worked (need keyring-backend=test)
tfd tx ibc-wasm store-code ./temp/cw_ics08_wasm_eth.wasm.gz --from validator --home ./play_sh/tokenfactory-1 --chain-id tokenfactory-1 --keyring-backend=test --title ethereum_lc --summary propose_to_load_ethereum_wasm --deposit 10000000stake --gas auto --gas-adjustment 1.5 --fees 183097873stake
tfd q tx DF9997585F61D601338A7A2DF0F706C080D475090C477E940247DC81D928F88D $NODE_CHAIN
tfd tx gov vote 1 yes --from validator $NODE_CHAIN $NODE_HOME $KEYRING -y
tfd q gov proposal 1 $NODE_HOME # PROPOSAL_STATUS_DEPOSIT_PERIOD
tfd q gov tally 1 $NODE_HOME  
tfd tx gov deposit 4 10000000stake --from validator --gas 20000000 $NODE_CHAIN $NODE_HOME $KEYRING -y


## try another .wasm file gzipped
### this did not work
tfd tx ibc-wasm store-code ./temp/ics10_grandpa_cw.wasm.gz --from validator --deposit 100000stake -y -b sync --output json "${TXFLAG_LG_GAS[@]}" $KEYRING $NODE_HOME
### this worked
tfd tx ibc-wasm store-code ./temp/ics10_grandpa_cw.wasm.gz --from validator --home ./play_sh/tokenfactory-1 --chain-id tokenfactory-1 --keyring-backend=test --title ethereum_lc --summary propose_to_load_ethereum_wasm --deposit 100000stake --gas auto --gas-adjustment 1.5 --fees 183097873stake
tfd q tx 44B3859CD8CA5E9BA23C545F062C568063FCB23964B68623D4DDD40BB731B00C $NODE_CHAIN
tfd q gov proposals $NODE_HOME
tfd q gov proposal 2 $NODE_HOME # PROPOSAL_STATUS_DEPOSIT_PERIOD
tfd q gov deposits 2 $NODE_HOME
tfd q gov deposit 2 $VALIDATOR $NODE_HOME
tfd tx gov deposit 2 10000000stake --from validator --gas 20000000 $NODE_CHAIN $NODE_HOME $KEYRING -y
tfd q tx C813441ABF4C7080283819EBE7FE0B0C013AD1CDE9004B2493FD7162CDD09AEF $NODE_CHAIN

###

## ibc cli for light clients
### which ibc client is allowed
tfd q ibc client params $NODE_HOME  
### all loaded client codes' checksums
tfd q ibc-wasm checksums $NODE_HOME
### the base64 of the wasm file
tfd q ibc-wasm code f4ff70b26f743f4ebce61936722c2621ab9b4c6c2b832d8f9ba5a2d05a0a532c $NODE_HOME


## use gov proposal to load the wasm file
### get the gov module account
tfd q auth module-account gov
### gov voting params
tfd q gov params $NODE_HOME  # tfd q gov params seems to run correctly even without $NODE_HOME
### this works with a huge gas: 200000000
tfd tx gov submit-proposal ./temp/proposal_wasm_lc.json --from validator "${TXFLAG_LG_GAS[@]}" $NODE_CHAIN $NODE_HOME $KEYRING -y
tfd q tx 6973EF2472FA1424349E620F14CEB234C13F1F037790117DE3082222E20AA8C2 $NODE_CHAIN
tfd q tx 969452B1656088D4EE7D3DD50DC056009A90E1B85A5675BCCCECFD5E642EFD11 $NODE_CHAIN
tfd tx gov vote 1 yes --from validator $NODE_CHAIN $NODE_HOME $KEYRING -y
tfd q gov proposal 1 $NODE_HOME 
tfd q gov tally 1 $NODE_HOME

## another way for gov proposal - this is for the older version of the sdk.
tfd tx gov submit-proposal --type=wasm-store --title="Store GRANDPA Light Client" --description="Upload GRANDPA Wasm light client" --run-as=<gov_module_account> --wasm-file=~/Downloads/ics10_grandpa_cw.wasm --from validator --home ~/.gm/ibc-0/ --gas auto
   
## instantiate the light client: ref discord dev-support-ai topic Light Client Development in Rust
tfd tx ibc client create ./temp/client_state.json ./temp/consensus_state.json --from validator --home ./play_sh/tokenfactory-1 --chain-id tokenfactory-1 --node=tcp://localhost:26657 --keyring-backend=test --gas auto --gas-adjustment 1.5 --fees 10000stake
mychaind tx ibc client create ./temp/client_state.json ./temp/consensus_state.json --from validator --home ./mychain-1 --chain-id mychain-1 --keyring-backend=test --gas auto --gas-adjustment 1.5 --fees 10000stake

tfd tx ibc client create \
  --client-type 08-wasm \
  --client-state "$(cat ./temp/client_state.json)" \
  --consensus-state "$(cat ./temp/consensus_state.json)" \
  --from validator \
  --home ./play_sh/tokenfactory-1/ \
  --chain-id tokenfactory-1 \
  --keyring-backend=test

## or use hermes
### If your checksum is in a variable called CHECKSUM_HEX; 
CHECKSUM_BIN=$(echo $CHECKSUM_HEX | xxd -r -p | base64)
hermes create client --host-chain ibc-0 --reference-chain ibc-1 --client-type 08-wasm --client-state ./temp/client_state_hermes.json

hermes create client \
  --host-chain ibc-0 \
  --reference-chain ibc-1 \
  --client-type 08-wasm \
  --client-state ./temp/client_state_hermes.json \
  --consensus-state ./temp/consensus_state_hermes.json
```