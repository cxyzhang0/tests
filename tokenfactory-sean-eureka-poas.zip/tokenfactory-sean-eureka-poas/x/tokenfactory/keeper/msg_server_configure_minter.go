package keeper

import (
	"context"

	"github.com/wfblockchain/noblechain/v5/x/tokenfactory/types"

	sdkerrors "cosmossdk.io/errors"
	sdk "github.com/cosmos/cosmos-sdk/types"
)

func (k msgServer) ConfigureMinter(goCtx context.Context, msg *types.MsgConfigureMinter) (*types.MsgConfigureMinterResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	_, found := k.GetMintingDenom(ctx, msg.Allowance.Denom)

	if !found {
		return nil, sdkerrors.Wrapf(types.ErrMint, "%s is not a minting denom", msg.Allowance.Denom)
	}

	//if msg.Allowance.Denom != mintingDenom.Denom {
	//	return nil, sdkerrors.Wrapf(types.ErrMint, "minting denom is incorrect")
	//}

	minterController, found := k.GetMinterController(ctx, msg.From, msg.Address)
	if !found {
		return nil, sdkerrors.Wrapf(types.ErrUnauthorized, "minter controller not found")
	}

	// todo: this check always passes because of the above query.
	if msg.From != minterController.Controller {
		return nil, sdkerrors.Wrapf(types.ErrUnauthorized, "you are not a controller of this minter")
	}

	// todo: this check always passes because of the above query.
	if msg.Address != minterController.Minter {
		return nil, sdkerrors.Wrapf(
			types.ErrUnauthorized,
			"minter address ≠ minter controller's minter address, (%s≠%s)",
			msg.Address, minterController.Minter,
		)
	}

	k.SetMinters(ctx, types.Minters{
		Address:   msg.Address,
		Allowance: msg.Allowance,
	})

	err := ctx.EventManager().EmitTypedEvent(msg)

	return &types.MsgConfigureMinterResponse{}, err
}
