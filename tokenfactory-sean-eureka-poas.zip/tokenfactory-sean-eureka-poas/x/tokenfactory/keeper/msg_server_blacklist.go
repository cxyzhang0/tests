package keeper

import (
	"context"

	"github.com/cosmos/cosmos-sdk/types/bech32"
	"github.com/wfblockchain/noblechain/v5/x/tokenfactory/types"

	sdkerrors "cosmossdk.io/errors"
	sdk "github.com/cosmos/cosmos-sdk/types"
)

func (k msgServer) Blacklist(goCtx context.Context, msg *types.MsgBlacklist) (*types.MsgBlacklistResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)

	blacklister, found := k.GetBlacklister(ctx)
	if !found {
		return nil, sdkerrors.Wrapf(types.ErrUserNotFound, "blacklister is not set")
	}

	if blacklister.Address != msg.From {
		return nil, sdkerrors.Wrapf(types.ErrUnauthorized, "you are not the blacklister")
	}

	_, addressBz, _ := bech32.DecodeAndConvert(msg.Address)
	_, found = k.GetBlacklisted(ctx, addressBz)
	if found {
		return nil, types.ErrUserBlacklisted
	}

	blacklisted := types.Blacklisted{
		AddressBz: addressBz,
	}

	k.SetBlacklisted(ctx, blacklisted)

	err := ctx.EventManager().EmitTypedEvent(msg)

	return &types.MsgBlacklistResponse{}, err
}
