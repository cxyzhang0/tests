package keeper

import (
	sdktypes "cosmossdk.io/store/types"
	"fmt"

	"github.com/wfblockchain/noblechain/v5/x/tokenfactory/types"

	"cosmossdk.io/store/prefix"
	sdk "github.com/cosmos/cosmos-sdk/types"
)

// SetMintingDenom set mintingDenom in the store
func (k *Keeper) SetMintingDenom(ctx sdk.Context, mintingDenom types.MintingDenom) {
	if k.MintingDenomSet(ctx, mintingDenom.Denom) {
		return
	}

	_, found := k.bankKeeper.GetDenomMetaData(ctx, mintingDenom.Denom)
	if !found {
		panic(fmt.Sprintf("Denom metadata for '%s' should be set", mintingDenom.Denom))
	}

	store := prefix.NewStore(ctx.KVStore(k.storeKey), types.KeyPrefix(types.MintingDenomKeyPrefix))
	b := k.cdc.MustMarshal(&mintingDenom)
	store.Set(types.MintingDenomKey(
		mintingDenom.Denom,
	), b)
}

// GetMintingDenom returns mintingDenom
func (k *Keeper) GetMintingDenom(ctx sdk.Context, denom string) (val types.MintingDenom, found bool) {
	store := prefix.NewStore(ctx.KVStore(k.storeKey), types.KeyPrefix(types.MintingDenomKeyPrefix))

	b := store.Get(types.MintingDenomKey(
		denom,
	))
	if b == nil {
		return val, false
	}

	k.cdc.MustUnmarshal(b, &val)
	return val, true
}

// RemoveMintingDenom removes a minting denom from the store
func (k *Keeper) RemoveMintingDenom(ctx sdk.Context, denom string) {
	store := prefix.NewStore(ctx.KVStore(k.storeKey), types.KeyPrefix(types.MintingDenomKeyPrefix))
	store.Delete(types.MintingDenomKey(
		denom,
	))
}

// MintingDenomSet returns true if the MintingDenom is already set in the store, it returns false otherwise.
func (k Keeper) MintingDenomSet(ctx sdk.Context, denom string) bool {
	store := prefix.NewStore(ctx.KVStore(k.storeKey), types.KeyPrefix(types.MintingDenomKeyPrefix))

	b := store.Get(types.MintingDenomKey(
		denom,
	))
	if b == nil {
		return false
	}

	return true
}

// GetAllMintingDenoms returns all minting denoms
func (k *Keeper) GetAllMintingDenoms(ctx sdk.Context) (list []types.MintingDenom) {
	store := prefix.NewStore(ctx.KVStore(k.storeKey), types.KeyPrefix(types.MintingDenomKeyPrefix))
	iterator := sdktypes.KVStorePrefixIterator(store, []byte{})

	defer iterator.Close()

	for ; iterator.Valid(); iterator.Next() {
		var val types.MintingDenom
		k.cdc.MustUnmarshal(iterator.Value(), &val)
		list = append(list, val)
	}
	return
}
