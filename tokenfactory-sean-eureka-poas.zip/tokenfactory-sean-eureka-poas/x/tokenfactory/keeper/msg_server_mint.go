package keeper

import (
	"context"

	"github.com/cosmos/cosmos-sdk/types/bech32"
	"github.com/wfblockchain/noblechain/v5/x/tokenfactory/types"

	sdkerrors "cosmossdk.io/errors"

	sdk "github.com/cosmos/cosmos-sdk/types"
)

func (k msgServer) Mint(goCtx context.Context, msg *types.MsgMint) (*types.MsgMintResponse, error) {
	ctx := sdk.UnwrapSDKContext(goCtx)
	return k.Keeper.Mint(ctx, msg)
}

func (k Keeper) Mint(ctx sdk.Context, msg *types.MsgMint) (*types.MsgMintResponse, error) {
	minter, found := k.GetMinters(ctx, msg.From, msg.Amount.Denom)
	if !found {
		return nil, sdkerrors.Wrapf(types.ErrUnauthorized, "you are not a minter")
	}

	_, addressBz, _ := bech32.DecodeAndConvert(msg.From)

	_, found = k.GetBlacklisted(ctx, addressBz)
	if found {
		return nil, sdkerrors.Wrapf(types.ErrMint, "minter address is blacklisted")
	}

	_, addressBz, _ = bech32.DecodeAndConvert(msg.Address)

	_, found = k.GetBlacklisted(ctx, addressBz)
	if found {
		return nil, sdkerrors.Wrapf(types.ErrMint, "receiver address is blacklisted")
	}

	found = k.MintingDenomSet(ctx, msg.Amount.Denom)
	if !found {
		return nil, sdkerrors.Wrapf(types.ErrMint, "%s is not a minting denom", msg.Amount.Denom)
	}

	//if msg.Amount.Denom != mintingDenom.Denom {
	//	return nil, sdkerrors.Wrapf(types.ErrMint, "minting denom is incorrect")
	//}

	if minter.Allowance.IsLT(msg.Amount) {
		return nil, sdkerrors.Wrapf(types.ErrMint, "minting amount is greater than the allowance")
	}

	paused := k.GetPaused(ctx)

	if paused.Paused {
		return nil, sdkerrors.Wrapf(types.ErrMint, "minting is paused")
	}

	minter.Allowance = minter.Allowance.Sub(msg.Amount)

	k.SetMinters(ctx, minter)

	amount := sdk.NewCoins(msg.Amount)

	k.bankKeeper.MintCoins(ctx, types.ModuleName, amount)

	receiver, _ := sdk.AccAddressFromBech32(msg.Address)

	k.bankKeeper.SendCoinsFromModuleToAccount(ctx, types.ModuleName, receiver, amount)

	err := ctx.EventManager().EmitTypedEvent(msg)

	return &types.MsgMintResponse{}, err
}
