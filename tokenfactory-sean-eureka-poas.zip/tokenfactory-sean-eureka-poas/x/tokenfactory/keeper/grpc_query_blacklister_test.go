package keeper_test

import (
	"testing"

	"github.com/stretchr/testify/require"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"

	keepertest "github.com/wfblockchain/noblechain/v5/testutil/keeper"
	"github.com/wfblockchain/noblechain/v5/testutil/nullify"
	"github.com/wfblockchain/noblechain/v5/x/tokenfactory/types"
)

func TestBlacklisterQuery(t *testing.T) {
	keeper, ctx := keepertest.TokenfactoryKeeper(t)
	wctx := (ctx)
	item := createTestBlacklister(keeper, ctx)
	for _, tc := range []struct {
		desc     string
		request  *types.QueryGetBlacklisterRequest
		response *types.QueryGetBlacklisterResponse
		err      error
	}{
		{
			desc:     "First",
			request:  &types.QueryGetBlacklisterRequest{},
			response: &types.QueryGetBlacklisterResponse{Blacklister: item},
		},
		{
			desc: "InvalidRequest",
			err:  status.Error(codes.InvalidArgument, "invalid request"),
		},
	} {
		t.Run(tc.desc, func(t *testing.T) {
			response, err := keeper.Blacklister(wctx, tc.request)
			if tc.err != nil {
				require.ErrorIs(t, err, tc.err)
			} else {
				require.NoError(t, err)
				require.Equal(t,
					nullify.Fill(tc.response),
					nullify.Fill(response),
				)
			}
		})
	}
}
