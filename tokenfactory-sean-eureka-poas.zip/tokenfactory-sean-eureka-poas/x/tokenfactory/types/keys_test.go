package types_test

import (
	"testing"

	"github.com/cosmos/cosmos-sdk/codec"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/stretchr/testify/require"
	"github.com/wfblockchain/noblechain/v5/testutil/sample"
	"github.com/wfblockchain/noblechain/v5/x/tokenfactory/types"
)

func TestKeyPrefix(t *testing.T) {
	testCases := []struct {
		input    string
		expected []byte
	}{
		{"example", []byte("example")},
		{"", []byte("")},
		{"12345", []byte("12345")},
		{"@#$%^&*", []byte("@#$%^&*")},
	}

	for _, tc := range testCases {
		output := types.KeyPrefix(tc.input)
		require.Equal(t, tc.expected, output, "KeyPrefix(%q) should return %v", tc.input, tc.expected)
	}
}

func TestNewMsgAcceptOwner(t *testing.T) {
	testCases := []struct {
		name     string
		input    string
		expected string
	}{
		{"Valid address", "cosmos1xyz123", "cosmos1xyz123"},
		{"Empty address", "", ""},
		{"Special characters", "@#$%^&*", "@#$%^&*"},
	}

	for _, tc := range testCases {
		t.Run(tc.name, func(t *testing.T) {
			msg := types.NewMsgAcceptOwner(tc.input)
			require.NotNil(t, msg, "NewMsgAcceptOwner should not return nil")
			require.Equal(t, tc.expected, msg.From, "From field mismatch")
		})
	}
}

func TestMsgAcceptOwner_Route(t *testing.T) {
	msg := &types.MsgAcceptOwner{}

	expectedRouterKey := types.RouterKey

	actualRouterKey := msg.Route()
	require.Equal(t, expectedRouterKey, actualRouterKey, "Route method should return the correct RouterKey")
}

func TestMsgAcceptOwner_Type(t *testing.T) {
	msg := &types.MsgAcceptOwner{}
	expectedType := types.TypeMsgAcceptOwner
	actualType := msg.Type()
	require.Equal(t, expectedType, actualType, "Type method should return the correct TypeMsgAcceptOwner")
}

func TestMsgAcceptOwner_GetSigners(t *testing.T) {
	validAddress := sample.AccAddress()
	msg := &types.MsgAcceptOwner{
		From: validAddress,
	}
	signers := msg.GetSigners()
	expectedSigner, err := sdk.AccAddressFromBech32(validAddress)
	require.NoError(t, err)
	require.Len(t, signers, 1, "GetSigners should return one signer")
	require.Equal(t, expectedSigner, signers[0], "Signer should match the 'From' field")
}

var ModuleCdc = codec.NewLegacyAmino()

func TestMsgAcceptOwner_GetSignBytes(t *testing.T) {
	validAddress := sample.AccAddress()
	msg := &types.MsgAcceptOwner{
		From: validAddress,
	}
	signBytes := msg.GetSignBytes()
	expectedJSON := `{"from":"` + validAddress + `"}`
	expectedSignBytes := sdk.MustSortJSON([]byte(expectedJSON))
	require.Equal(t, expectedSignBytes, signBytes, "GetSignBytes should return the correct signed bytes")
}

func TestMsgAcceptOwner_ValidateBasic(t *testing.T) {
	validAddress := sample.AccAddress()
	invalidAddress := "cosmos1invalidaddress"
	msgValid := &types.MsgAcceptOwner{
		From: validAddress,
	}
	err := msgValid.ValidateBasic()
	require.NoError(t, err, "ValidateBasic should not return error for valid address")

	msgInvalid := &types.MsgAcceptOwner{
		From: invalidAddress,
	}
	err = msgInvalid.ValidateBasic()
	require.Error(t, err, "ValidateBasic should return error for invalid address")
	require.Contains(t, err.Error(), "invalid from address", "Error message should contain 'invalid from address'")
}
