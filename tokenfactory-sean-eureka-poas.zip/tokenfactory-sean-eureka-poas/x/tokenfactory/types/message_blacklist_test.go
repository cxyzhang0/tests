package types_test

import (
	"testing"

	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/stretchr/testify/require"
	"github.com/wfblockchain/noblechain/v5/testutil/sample"
	"github.com/wfblockchain/noblechain/v5/x/tokenfactory/types"
)

func TestNewMsgBlacklist(t *testing.T) {
	from := sample.AccAddress()
	address := sample.AccAddress()

	msg := types.NewMsgBlacklist(from, address)
	require.Equal(t, from, msg.From)
	require.Equal(t, address, msg.Address)
}

func TestMsgBlacklist_Route(t *testing.T) {
	msg := &types.MsgBlacklist{
		From:    sample.AccAddress(),
		Address: sample.AccAddress(),
	}

	require.Equal(t, types.RouterKey, msg.Route())
}

func TestMsgBlacklist_Type(t *testing.T) {
	msg := &types.MsgBlacklist{
		From:    sample.AccAddress(),
		Address: sample.AccAddress(),
	}
	require.Equal(t, types.TypeMsgBlacklist, msg.Type())
}

func TestMsgBlacklist_GetSigners(t *testing.T) {
	validAddress := sample.AccAddress()

	msg := &types.MsgBlacklist{
		From:    validAddress,
		Address: sample.AccAddress(),
	}

	signers := msg.GetSigners()

	expectedSigner, err := sdk.AccAddressFromBech32(validAddress)
	require.NoError(t, err)
	require.Len(t, signers, 1, "GetSigners should return one signer")
	require.Equal(t, expectedSigner, signers[0], "Signer should match the 'From' field")
}

func TestMsgBlacklist_GetSignBytes(t *testing.T) {
	from := sample.AccAddress()
	address := sample.AccAddress()

	msg := &types.MsgBlacklist{
		From:    from,
		Address: address,
	}
	signBytes := msg.GetSignBytes()
	expectedBytes := sdk.MustSortJSON(ModuleCdc.MustMarshalJSON(msg))
	require.Equal(t, expectedBytes, signBytes, "GetSignBytes should return the correct sign bytes")
}
func TestMsgBlacklist_ValidateBasic(t *testing.T) {
	validAddress := sample.AccAddress()
	invalidAddress := "invalid_address"
	msgValid := &types.MsgBlacklist{
		From:    validAddress,
		Address: "cosmos1v4kslf84kk42kzkl4q5wxn3wufgcksf89gfveq",
	}
	err := msgValid.ValidateBasic()
	require.NoError(t, err, "ValidateBasic should not return error for valid address")
	msgInvalid := &types.MsgBlacklist{
		From:    invalidAddress,
		Address: "cosmos1v4kslf84kk42kzkl4q5wxn3wufgcksf89gfveq",
	}
	err = msgInvalid.ValidateBasic()
	require.Error(t, err, "ValidateBasic should return error for invalid 'From' address")
	require.Contains(t, err.Error(), "invalid from address", "Error message should contain 'invalid from address'")
}
