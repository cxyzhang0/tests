package types_test

import (
	"testing"

	sdk "github.com/cosmos/cosmos-sdk/types"
	sdkerrors "github.com/cosmos/cosmos-sdk/types/errors"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"github.com/wfblockchain/noblechain/v5/testutil/sample"
	"github.com/wfblockchain/noblechain/v5/x/tokenfactory/types"
)

func TestMsgUpdateBlacklister_ValidateBasic(t *testing.T) {
	tests := []struct {
		name string
		msg  types.MsgUpdateBlacklister
		err  error
	}{
		{
			name: "invalid from",
			msg: types.MsgUpdateBlacklister{
				From:    "invalid_address",
				Address: sample.AccAddress(),
			},
			err: sdkerrors.ErrInvalidAddress,
		},
		{
			name: "invalid address",
			msg: types.MsgUpdateBlacklister{
				From:    sample.AccAddress(),
				Address: "invalid_address",
			},
			err: sdkerrors.ErrInvalidAddress,
		},
		{
			name: "valid address and from",
			msg: types.MsgUpdateBlacklister{
				From:    sample.AccAddress(),
				Address: sample.AccAddress(),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			err := tt.msg.ValidateBasic()
			if tt.err != nil {
				require.ErrorIs(t, err, tt.err)
				return
			}
			require.NoError(t, err)
		})
	}
}

func TestNewMsgUpdateBlacklister(t *testing.T) {
	from := "cosmos1xyz..."
	address := "cosmos1abc..."
	msg := types.NewMsgUpdateBlacklister(from, address)
	assert.NotNil(t, msg)
	assert.Equal(t, from, msg.From)
	assert.Equal(t, address, msg.Address)
}

func TestMsgUpdateBlacklisterRoute(t *testing.T) {
	from := "cosmos1xyz..."
	address := "cosmos1abc..."
	msg := types.NewMsgUpdateBlacklister(from, address)
	assert.Equal(t, types.RouterKey, msg.Route())
}

func TestMsgUpdateBlacklisterType(t *testing.T) {
	from := "cosmos1xyz..."
	address := "cosmos1abc..."
	msg := types.NewMsgUpdateBlacklister(from, address)
	assert.Equal(t, types.TypeMsgUpdateBlacklister, msg.Type())
}

func TestMsgUpdateBlacklisterGetSigners(t *testing.T) {
	from := sample.AccAddress()
	address := sample.AccAddress()
	msg := types.NewMsgUpdateBlacklister(from, address)
	signers := msg.GetSigners()
	assert.Len(t, signers, 1)
	assert.Equal(t, from, signers[0].String())
}

func TestMsgUpdateBlacklisterGetSignBytes(t *testing.T) {
	from := "cosmos1xyz..."
	address := "cosmos1abc..."
	msg := types.NewMsgUpdateBlacklister(from, address)
	signBytes := msg.GetSignBytes()
	assert.NotNil(t, signBytes)
	expectedBytes := types.ModuleCdc.MustMarshalJSON(msg)
	assert.Equal(t, sdk.MustSortJSON(expectedBytes), signBytes)
}
