package types_test

import (
	"testing"

	sdk "github.com/cosmos/cosmos-sdk/types"
	sdkerrors "github.com/cosmos/cosmos-sdk/types/errors"
	"github.com/stretchr/testify/require"
	"github.com/wfblockchain/noblechain/v5/testutil/sample"
	tokenfactorytypes "github.com/wfblockchain/noblechain/v5/x/tokenfactory/types"
)

func TestMsgRemoveMinterController_ValidateBasic(t *testing.T) {
	tests := []struct {
		name string
		msg  tokenfactorytypes.MsgRemoveMinterController
		err  error
	}{
		{
			name: "invalid from",
			msg: tokenfactorytypes.MsgRemoveMinterController{
				From:       "invalid_address",
				Controller: sample.AccAddress(),
			},
			err: sdkerrors.ErrInvalidAddress,
		},
		{
			name: "invalid controller",
			msg: tokenfactorytypes.MsgRemoveMinterController{
				From:       sample.AccAddress(),
				Controller: "invalid_address",
			},
			err: sdkerrors.ErrInvalidAddress,
		},
		{
			name: "valid controller and from",
			msg: tokenfactorytypes.MsgRemoveMinterController{
				From:       sample.AccAddress(),
				Controller: sample.AccAddress(),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			err := tt.msg.ValidateBasic()
			if tt.err != nil {
				require.ErrorIs(t, err, tt.err)
				return
			}
			require.NoError(t, err)
		})
	}
}

func TestMsgRemoveMinterController(t *testing.T) {
	validFrom := sample.AccAddress()
	validController := sample.AccAddress()
	validMinter := sample.AccAddress()
	t.Run("NewMsgRemoveMinterController", func(t *testing.T) {
		msg := tokenfactorytypes.NewMsgRemoveMinterController(validFrom, validController, validMinter)
		require.NotNil(t, msg, "NewMsgRemoveMinterController should not return nil")
		require.Equal(t, validFrom, msg.From, "From should match the input")
		require.Equal(t, validController, msg.Controller, "Controller should match the input")
	})

	t.Run("Route", func(t *testing.T) {
		msg := tokenfactorytypes.NewMsgRemoveMinterController(validFrom, validController, validMinter)
		require.Equal(t, tokenfactorytypes.RouterKey, msg.Route(), "Route should return the correct RouterKey")
	})

	t.Run("Type", func(t *testing.T) {
		msg := tokenfactorytypes.NewMsgRemoveMinterController(validFrom, validController, validMinter)
		require.Equal(t, tokenfactorytypes.TypeMsgRemoveMinterController, msg.Type(), "Type should return the correct message type")
	})

	t.Run("GetSigners", func(t *testing.T) {
		msg := tokenfactorytypes.NewMsgRemoveMinterController(validFrom, validController, validMinter)
		signers := msg.GetSigners()
		require.Len(t, signers, 1, "GetSigners should return exactly one signer")

		expectedSigner, err := sdk.AccAddressFromBech32(validFrom)
		require.NoError(t, err, "Valid From address should not return an error")
		require.Equal(t, expectedSigner, signers[0], "Signer should match the 'From' field")
	})

	t.Run("GetSignBytes", func(t *testing.T) {
		msg := tokenfactorytypes.NewMsgRemoveMinterController(validFrom, validController, validMinter)
		signBytes := msg.GetSignBytes()
		expectedBytes, err := tokenfactorytypes.ModuleCdc.MarshalJSON(msg)
		require.NoError(t, err, "ModuleCdc.MarshalJSON should not return an error")

		expectedSignBytes := sdk.MustSortJSON(expectedBytes)

		require.Equal(t, expectedSignBytes, signBytes, "GetSignBytes should return sorted JSON bytes")
	})
}
