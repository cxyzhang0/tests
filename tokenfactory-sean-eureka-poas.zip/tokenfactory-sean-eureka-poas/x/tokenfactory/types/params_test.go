package types_test

import (
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/wfblockchain/noblechain/v5/x/tokenfactory/types"
	"gopkg.in/yaml.v2"
)

func TestParamsString(t *testing.T) {
	params := types.Params{}
	expectedYaml, err := yaml.Marshal(params)
	if err != nil {
		t.Fatalf("Failed to marshal expected params: %v", err)
	}
	stringOutput := params.String()
	assert.Equal(t, string(expectedYaml), stringOutput, "The string output does not match the expected YAML format.")
}

func TestParams_ParamSetPairs(t *testing.T) {
	params := &types.Params{}
	paramSetPairs := params.ParamSetPairs()
	assert.Empty(t, paramSetPairs, "Expected ParamSetPairs to be an empty slice.")
}

func TestParamKeyTable(t *testing.T) {
	keyTable := types.ParamKeyTable()
	params := &types.Params{}
	assert.NotNil(t, keyTable, "Expected KeyTable to be non-nil")
	assert.Len(t, params.ParamSetPairs(), 0, "Expected KeyTable to have no param sets registered (empty set in this case)")
}
