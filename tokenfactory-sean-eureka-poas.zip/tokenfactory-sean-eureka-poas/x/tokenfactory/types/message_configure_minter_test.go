package types_test

import (
	"fmt"
	"testing"

	"cosmossdk.io/math"
	sdk "github.com/cosmos/cosmos-sdk/types"
	sdkerrors "github.com/cosmos/cosmos-sdk/types/errors"
	"github.com/stretchr/testify/require"
	"github.com/wfblockchain/noblechain/v5/testutil/sample"
	tokenfactorytypes "github.com/wfblockchain/noblechain/v5/x/tokenfactory/types"
)

func TestMsgConfigureMinter_ValidateBasic(t *testing.T) {
	tests := []struct {
		name string
		msg  tokenfactorytypes.MsgConfigureMinter
		err  error
	}{
		{
			name: "invalid from",
			msg: tokenfactorytypes.MsgConfigureMinter{
				From:    "invalid_address",
				Address: sample.AccAddress(),
			},
			err: sdkerrors.ErrInvalidAddress,
		},
		{
			name: "invalid address",
			msg: tokenfactorytypes.MsgConfigureMinter{
				From:    sample.AccAddress(),
				Address: "invalid_address",
			},
			err: sdkerrors.ErrInvalidAddress,
		},
		{
			name: "valid address and from",
			msg: tokenfactorytypes.MsgConfigureMinter{
				From:      sample.AccAddress(),
				Address:   sample.AccAddress(),
				Allowance: sdk.NewCoin("test", math.NewInt(1)),
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			err := tt.msg.ValidateBasic()
			if tt.err != nil {
				require.ErrorIs(t, err, tt.err)
				return
			}

		})
	}
}

func TestMsgConfigureMinter_GetSignBytes(t *testing.T) {
	validAddress1 := sample.AccAddress()
	validAddress2 := sample.AccAddress()
	allowance := sdk.NewCoin("atom", math.NewInt(1000))
	msg := &tokenfactorytypes.MsgConfigureMinter{
		From:      validAddress1,
		Address:   validAddress2,
		Allowance: allowance,
	}

	signBytes := msg.GetSignBytes()
	expectedJSON := fmt.Sprintf(
		`{"allowance":{"amount":"%s","denom":"%s"},"address":"%s","from":"%s"}`,
		allowance.Amount.String(),
		allowance.Denom,
		validAddress2,
		validAddress1,
	)
	expectedSignBytes := sdk.MustSortJSON([]byte(expectedJSON))
	require.Equal(t, expectedSignBytes, signBytes)
}

func TestMsgConfigureMinter(t *testing.T) {
	validFrom := sample.AccAddress()
	validAddress := sample.AccAddress()
	allowance := sdk.NewCoin("atom", math.NewInt(1000))
	t.Run("NewMsgConfigureMinter", func(t *testing.T) {
		msg := tokenfactorytypes.NewMsgConfigureMinter(validFrom, validAddress, allowance)
		require.NotNil(t, msg, "NewMsgConfigureMinter should not return nil")
		require.Equal(t, validFrom, msg.From, "From should match the input")
		require.Equal(t, validAddress, msg.Address, "Address should match the input")
		require.Equal(t, allowance, msg.Allowance, "Allowance should match the input")
	})
	t.Run("Route", func(t *testing.T) {
		msg := tokenfactorytypes.NewMsgConfigureMinter(validFrom, validAddress, allowance)
		require.Equal(t, tokenfactorytypes.RouterKey, msg.Route(), "Route should return the correct RouterKey")
	})

	t.Run("Type", func(t *testing.T) {
		msg := tokenfactorytypes.NewMsgConfigureMinter(validFrom, validAddress, allowance)
		require.Equal(t, tokenfactorytypes.TypeMsgConfigureMinter, msg.Type(), "Type should return the correct message type")
	})

	t.Run("GetSigners", func(t *testing.T) {
		msg := tokenfactorytypes.NewMsgConfigureMinter(validFrom, validAddress, allowance)
		signers := msg.GetSigners()
		require.Len(t, signers, 1, "GetSigners should return exactly one signer")

		expectedSigner, err := sdk.AccAddressFromBech32(validFrom)
		require.NoError(t, err, "Valid From address should not return an error")
		require.Equal(t, expectedSigner, signers[0], "Signer should match the 'From' field")
	})
}
