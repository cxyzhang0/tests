package cli

import (
	"strconv"

	"github.com/wfblockchain/noblechain/v5/x/tokenfactory/types"

	"github.com/cosmos/cosmos-sdk/client"
	"github.com/cosmos/cosmos-sdk/client/flags"
	"github.com/cosmos/cosmos-sdk/client/tx"
	"github.com/spf13/cobra"
)

var _ = strconv.Itoa(0)

func CmdRemoveMinterController() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "remove-minter-controller [controller] [minter]",
		Short: "Broadcast message remove-minter-controller",
		Args:  cobra.ExactArgs(2),
		RunE: func(cmd *cobra.Command, args []string) (err error) {
			argController := args[0]
			argMinter := args[1]

			clientCtx, _ := client.GetClientTxContext(cmd)

			msg := types.NewMsgRemoveMinterController(
				clientCtx.GetFromAddress().String(),
				argController,
				argMinter,
			)

			return tx.GenerateOrBroadcastTxCLI(clientCtx, cmd.Flags(), msg)
		},
	}

	flags.AddTxFlagsToCmd(cmd)

	return cmd
}
