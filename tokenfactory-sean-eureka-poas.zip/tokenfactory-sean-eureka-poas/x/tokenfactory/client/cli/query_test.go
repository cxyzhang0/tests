package cli_test

import (
	"context"
	"fmt"
	"testing"
	"time"

	"github.com/cosmos/cosmos-sdk/client"
	"github.com/cosmos/cosmos-sdk/types"
	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/stretchr/testify/require"
	"github.com/wfblockchain/noblechain/v5/testutil/sample"
	"github.com/wfblockchain/noblechain/v5/x/tokenfactory/client/cli"
	ttypes "github.com/wfblockchain/noblechain/v5/x/tokenfactory/types"
	"go.uber.org/mock/gomock"
)

func TestGetQueryCmd(t *testing.T) {
	queryCmd := cli.GetQueryCmd(ttypes.ModuleName)
	require.NotNil(t, queryCmd)
	subcommands := queryCmd.Commands()
	require.Len(t, subcommands, 14, "Expected 14 subcommands to be registered")
	expectedCommands := []string{
		"params",
		"blacklisted",
		"show-blacklisted",
		"show-paused",
		"master-minter",
		"minters",
		"show-minters",
		"pauser",
		"show-blacklister",
		"show-owner",
		"minter-controller",
		"show-minter-controller",
		"minting-denom",
	}

	for _, cmdName := range expectedCommands {
		t.Run(fmt.Sprintf("check command: %s", cmdName), func(t *testing.T) {
			cmd, _, _ := queryCmd.Find([]string{cmdName})
			require.NotNil(t, cmd, fmt.Sprintf("Command %s should be present", cmdName))
		})
	}
	t.Run("TestCmdQueryParams", func(t *testing.T) {
		cmd := queryCmd.Commands()[0]
		cmd.SetArgs([]string{})
		err := cmd.Execute()
		require.NoError(t, err, "Expected the command to execute without error")
	})
}

type MockQueryContext struct {
	clientCtx        client.Context
	PrintProtoCalled bool
}

func (m *MockQueryContext) GetFromAddress() sdk.AccAddress {
	return m.clientCtx.GetFromAddress()
}

func (m *MockQueryContext) PrintProto(res interface{}) error {
	m.PrintProtoCalled = true
	return nil
}

func (m *MockQueryContext) Deadline() (deadline time.Time, ok bool) {
	return time.Time{}, false
}

func (m *MockQueryContext) Done() <-chan struct{} {
	ch := make(chan struct{})
	close(ch)
	return ch
}

func (m *MockQueryContext) Err() error {
	return nil
}

func (m *MockQueryContext) Value(key interface{}) interface{} {
	return nil
}

func TestCmdShowPauser(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()
	clientCtx := client.Context{}
	validAddress := sample.AccAddress()
	clientCtx = clientCtx.WithFromAddress(types.AccAddress(validAddress))

	clientCtx = clientCtx.WithOffline(false)
	fromAddr := clientCtx.GetFromAddress().String()
	if fromAddr == "" {
		t.Fatalf("The from address is empty, check if it has been set properly.")
	}
	_, err := sdk.AccAddressFromBech32(fromAddr)
	if err != nil {
		t.Fatalf("Invalid From address in context: %s, error: %v", fromAddr, err)
	}
	cmd := cli.CmdShowPauser()
	cmd.SetArgs([]string{})
	mockClient := &MockQueryContext{clientCtx: clientCtx}
	cmd.SetContext(mockClient)
	cmd.RunE(cmd, []string{})

}

func TestCmdShowOwner(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()
	clientCtx := client.Context{}
	validAddress := sample.AccAddress()
	clientCtx = clientCtx.WithFromAddress(types.AccAddress(validAddress))
	fromAddr := clientCtx.GetFromAddress().String()
	if fromAddr == "" {
		t.Fatalf("The from address is empty, check if it has been set properly.")
	}
	_, err := sdk.AccAddressFromBech32(fromAddr)
	if err != nil {
		t.Fatalf("Invalid From address in context: %s, error: %v", fromAddr, err)
	}
	cmd := cli.CmdShowOwner()
	cmd.SetArgs([]string{})
	mockClient := &MockQueryContext{clientCtx: clientCtx}
	cmd.SetContext(mockClient)
	cmd.RunE(cmd, []string{})

}

func TestCmdShowMintingDenom(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()
	clientCtx := client.Context{}
	validAddress := sample.AccAddress()
	clientCtx = clientCtx.WithFromAddress(types.AccAddress(validAddress))
	fromAddr := clientCtx.GetFromAddress().String()
	if fromAddr == "" {
		t.Fatalf("The from address is empty, check if it has been set properly.")
	}
	_, err := sdk.AccAddressFromBech32(fromAddr)
	if err != nil {
		t.Fatalf("Invalid From address in context: %s, error: %v", fromAddr, err)
	}
	cmd := cli.CmdShowMintingDenom()
	cmd.SetArgs([]string{})
	mockClient := &MockQueryContext{clientCtx: clientCtx}
	cmd.SetContext(mockClient)
	cmd.RunE(cmd, []string{"mock-address"})

}
func TestCmdShowMinters(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()
	clientCtx := client.Context{}
	validAddress := sample.AccAddress()
	clientCtx = clientCtx.WithFromAddress(types.AccAddress(validAddress))
	fromAddr := clientCtx.GetFromAddress().String()
	if fromAddr == "" {
		t.Fatalf("The from address is empty, check if it has been set properly.")
	}
	_, err := sdk.AccAddressFromBech32(fromAddr)
	if err != nil {
		t.Fatalf("Invalid From address in context: %s, error: %v", fromAddr, err)
	}
	cmd := cli.CmdShowMinters()
	cmd.SetArgs([]string{"mock-address"})
	mockClient := &MockQueryContext{clientCtx: clientCtx}
	cmd.SetContext(mockClient)
	cmd.RunE(cmd, []string{"mock-address", "mock-denom"})

}

type MockQueryClient struct {
	PausedFunc func(ctx context.Context, req *ttypes.QueryGetPausedRequest) (*ttypes.QueryGetPausedResponse, error)
}

func (m *MockQueryClient) Paused(ctx context.Context, req *ttypes.QueryGetPausedRequest) (*ttypes.QueryGetPausedResponse, error) {
	return m.PausedFunc(ctx, req)
}

func TestCmdShowPaused(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()

	clientCtx := client.Context{}
	validAddress := sample.AccAddress()
	clientCtx = clientCtx.WithFromAddress(types.AccAddress(validAddress))

	clientCtx = clientCtx.WithOffline(false)
	fromAddr := clientCtx.GetFromAddress().String()
	if fromAddr == "" {
		t.Fatalf("The from address is empty, check if it has been set properly.")
	}
	_, err := sdk.AccAddressFromBech32(fromAddr)
	if err != nil {
		t.Fatalf("Invalid From address in context: %s, error: %v", fromAddr, err)
	}

	cmd := cli.CmdShowPaused()
	cmd.SetArgs([]string{})
	mockClient := &MockQueryContext{clientCtx: clientCtx}
	cmd.SetContext(mockClient)
	cmd.RunE(cmd, []string{})
}

func TestCmdQueryParams(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()
	clientCtx := client.Context{}
	validAddress := sample.AccAddress()
	clientCtx = clientCtx.WithFromAddress(types.AccAddress(validAddress))

	clientCtx = clientCtx.WithOffline(false)
	fromAddr := clientCtx.GetFromAddress().String()
	if fromAddr == "" {
		t.Fatalf("The from address is empty, check if it has been set properly.")
	}
	_, err := sdk.AccAddressFromBech32(fromAddr)
	if err != nil {
		t.Fatalf("Invalid From address in context: %s, error: %v", fromAddr, err)
	}
	cmd := cli.CmdQueryParams()
	cmd.SetArgs([]string{})
	mockClient := &MockQueryContext{clientCtx: clientCtx}
	cmd.SetContext(mockClient)
	cmd.RunE(cmd, []string{})
}
func TestCmdShowMinterController(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()
	clientCtx := client.Context{}
	validAddress := sample.AccAddress()
	clientCtx = clientCtx.WithFromAddress(types.AccAddress(validAddress))

	clientCtx = clientCtx.WithOffline(false)
	fromAddr := clientCtx.GetFromAddress().String()
	if fromAddr == "" {
		t.Fatalf("The from address is empty, check if it has been set properly.")
	}
	_, err := sdk.AccAddressFromBech32(fromAddr)
	if err != nil {
		t.Fatalf("Invalid From address in context: %s, error: %v", fromAddr, err)
	}
	minterAddress := sample.AccAddress()
	cmd := cli.CmdShowMinterController()
	cmd.SetArgs([]string{minterAddress})
	mockClient := &MockQueryContext{clientCtx: clientCtx}
	cmd.SetContext(mockClient)
	cmd.RunE(cmd, []string{"Mock_ControllerAddress", minterAddress})
}
func TestCmdShowMasterMinter(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()
	clientCtx := client.Context{}
	validAddress := sample.AccAddress()
	clientCtx = clientCtx.WithFromAddress(types.AccAddress(validAddress))

	clientCtx = clientCtx.WithOffline(false)
	fromAddr := clientCtx.GetFromAddress().String()
	if fromAddr == "" {
		t.Fatalf("The from address is empty, check if it has been set properly.")
	}
	_, err := sdk.AccAddressFromBech32(fromAddr)
	if err != nil {
		t.Fatalf("Invalid From address in context: %s, error: %v", fromAddr, err)
	}
	cmd := cli.CmdShowMasterMinter()
	cmd.SetArgs([]string{})
	mockClient := &MockQueryContext{clientCtx: clientCtx}
	cmd.SetContext(mockClient)
	cmd.RunE(cmd, []string{})
}

func TestCmdShowBlacklister(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()
	clientCtx := client.Context{}
	validAddress := sample.AccAddress()
	clientCtx = clientCtx.WithFromAddress(types.AccAddress(validAddress))

	clientCtx = clientCtx.WithOffline(false)
	fromAddr := clientCtx.GetFromAddress().String()
	if fromAddr == "" {
		t.Fatalf("The from address is empty, check if it has been set properly.")
	}
	_, err := sdk.AccAddressFromBech32(fromAddr)
	if err != nil {
		t.Fatalf("Invalid From address in context: %s, error: %v", fromAddr, err)
	}
	cmd := cli.CmdShowBlacklister()
	cmd.SetArgs([]string{})
	mockClient := &MockQueryContext{clientCtx: clientCtx}
	cmd.SetContext(mockClient)
	cmd.RunE(cmd, []string{})
}

func TestCmdShowBlacklisted(t *testing.T) {
	ctrl := gomock.NewController(t)
	defer ctrl.Finish()
	clientCtx := client.Context{}
	validAddress := sample.AccAddress()
	clientCtx = clientCtx.WithFromAddress(types.AccAddress(validAddress))

	clientCtx = clientCtx.WithOffline(false)
	fromAddr := clientCtx.GetFromAddress().String()
	if fromAddr == "" {
		t.Fatalf("The from address is empty, check if it has been set properly.")
	}
	_, err := sdk.AccAddressFromBech32(fromAddr)
	if err != nil {
		t.Fatalf("Invalid From address in context: %s, error: %v", fromAddr, err)
	}
	cmd := cli.CmdShowBlacklisted()
	blacklistedAddress := sample.AccAddress()
	cmd.SetArgs([]string{blacklistedAddress})

	mockClient := &MockQueryContext{clientCtx: clientCtx}
	cmd.SetContext(mockClient)
	cmd.RunE(cmd, []string{blacklistedAddress})
}
