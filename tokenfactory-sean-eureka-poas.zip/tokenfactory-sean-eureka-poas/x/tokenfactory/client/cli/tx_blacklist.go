package cli

import (
	"strconv"

	"github.com/cosmos/cosmos-sdk/client"
	"github.com/cosmos/cosmos-sdk/client/flags"
	"github.com/cosmos/cosmos-sdk/client/tx"
	"github.com/spf13/cobra"
	"github.com/wfblockchain/noblechain/v5/x/tokenfactory/types"
)

var _ = strconv.Itoa(0)

func CmdBlacklist() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "blacklist [address]",
		Short: "Broadcast message blacklist",
		Args:  cobra.ExactArgs(1),
		RunE: func(cmd *cobra.Command, args []string) (err error) {
			argAddress := args[0]

			clientCtx, _ := client.GetClientTxContext(cmd)

			msg := types.NewMsgBlacklist(
				clientCtx.GetFromAddress().String(),
				argAddress,
			)

			return tx.GenerateOrBroadcastTxCLI(clientCtx, cmd.Flags(), msg)
		},
	}

	flags.AddTxFlagsToCmd(cmd)

	return cmd
}
