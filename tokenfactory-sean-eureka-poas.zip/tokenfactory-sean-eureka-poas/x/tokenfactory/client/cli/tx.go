package cli

import (
	"fmt"

	"cosmossdk.io/core/address"
	"github.com/cosmos/cosmos-sdk/client"
	"github.com/spf13/cobra"
	"github.com/wfblockchain/noblechain/v5/x/tokenfactory/types"
)

// GetTxCmd returns the transaction commands for this module
func GetTxCmd() *cobra.Command {
	cmd := &cobra.Command{
		Use:                        types.ModuleName,
		Short:                      fmt.Sprintf("%s transactions subcommands", types.ModuleName),
		DisableFlagParsing:         true,
		SuggestionsMinimumDistance: 2,
		RunE:                       client.ValidateCmd,
	}

	cmd.AddCommand(CmdUpdateMasterMinter())
	cmd.AddCommand(CmdUpdatePauser())
	cmd.AddCommand(CmdUpdateBlacklister())
	cmd.AddCommand(CmdUpdateOwner())
	cmd.AddCommand(CmdAcceptOwner())
	cmd.AddCommand(CmdConfigureMinter())
	cmd.AddCommand(CmdRemoveMinter())
	cmd.AddCommand(CmdMint())
	cmd.AddCommand(CmdBurn())
	cmd.AddCommand(CmdBlacklist())
	cmd.AddCommand(CmdUnblacklist())
	cmd.AddCommand(CmdPause())
	cmd.AddCommand(CmdUnpause())
	cmd.AddCommand(CmdConfigureMinterController())
	cmd.AddCommand(CmdRemoveMinterController())
	cmd.AddCommand(CmdSetDenomMetadata())
	// this line is used by starport scaffolding # 1

	return cmd
}

func NewTxCmd(valAc, ac address.Codec) *cobra.Command {
	cmd := &cobra.Command{
		Use:                        types.ModuleName,
		Short:                      "Distribution transactions subcommands",
		DisableFlagParsing:         true,
		SuggestionsMinimumDistance: 2,
		RunE:                       client.ValidateCmd,
	}

	cmd.AddCommand(CmdUpdateMasterMinter())
	cmd.AddCommand(CmdUpdatePauser())
	cmd.AddCommand(CmdUpdateBlacklister())
	cmd.AddCommand(CmdUpdateOwner())
	cmd.AddCommand(CmdAcceptOwner())
	cmd.AddCommand(CmdConfigureMinter())
	cmd.AddCommand(CmdRemoveMinter())
	cmd.AddCommand(CmdMint())
	cmd.AddCommand(CmdBurn())
	cmd.AddCommand(CmdBlacklist())
	cmd.AddCommand(CmdUnblacklist())
	cmd.AddCommand(CmdPause())
	cmd.AddCommand(CmdUnpause())
	cmd.AddCommand(CmdConfigureMinterController())
	cmd.AddCommand(CmdRemoveMinterController())

	return cmd
}
