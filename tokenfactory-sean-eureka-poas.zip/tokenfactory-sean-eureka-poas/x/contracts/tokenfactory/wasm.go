package tokenfactory

import (
	feegrantkeeper "cosmossdk.io/x/feegrant/keeper"
	wasmkeeper "github.com/CosmWasm/wasmd/x/wasm/keeper"
	//fiattokenfactorymodulekeeper "github.com/circlefin/noble-fiattokenfactory/x/fiattokenfactory/keeper"
	bankkeeper "github.com/cosmos/cosmos-sdk/x/bank/keeper"
	tokenfactorymodulekeeper "github.com/wfblockchain/noblechain/v5/x/tokenfactory/keeper"
)

func RegisterCustomPlugins(
	tf *tokenfactorymodulekeeper.Keeper,
	ftf *tokenfactorymodulekeeper.Keeper,
	bank *bankkeeper.BaseKeeper,
	feegrant *feegrantkeeper.Keeper,
) []wasmkeeper.Option {
	wasmQueryPlugin := NewQueryPlugin(tf, ftf, bank, feegrant)

	queryPluginOpt := wasmkeeper.WithQueryPlugins(&wasmkeeper.QueryPlugins{
		Custom: CustomQuerier(wasmQueryPlugin),
	})

	messengerDecoratorOpt := wasmkeeper.WithMessageHandlerDecorator(
		CustomMessagerDecorator(tf, ftf, feegrant),
	)

	return []wasmkeeper.Option{
		queryPluginOpt,
		messengerDecoratorOpt,
	}
}
