package globalfee

import (
	"testing"

	sdk "github.com/cosmos/cosmos-sdk/types"
	"github.com/stretchr/testify/require"
	"github.com/wfblockchain/noblechain/v5/x/globalfee/types"
)

type mockParamSource struct {
	minGasPrices         sdk.DecCoins
	bypassMinFeeMsgTypes []string
}

func (m mockParamSource) Has(ctx sdk.Context, key []byte) bool {
	return true
}

func (m mockParamSource) Get(ctx sdk.Context, key []byte, ptr interface{}) {
	switch string(key) {
	case string(types.ParamStoreKeyMinGasPrices):
		if p, ok := ptr.(*sdk.DecCoins); ok {
			*p = m.minGasPrices
		}
	case string(types.ParamStoreKeyBypassMinFeeMsgTypes):
		if p, ok := ptr.(*[]string); ok {
			*p = m.bypassMinFeeMsgTypes
		}
	}
}

func TestNewGrpcQuerier(t *testing.T) {
	mockSource := mockParamSource{}
	querier := NewGrpcQuerier(mockSource)
	require.NotNil(t, querier, "GrpcQuerier should not be nil")
	require.Equal(t, mockSource, querier.paramSource, "paramSource should be correctly assigned")
}
