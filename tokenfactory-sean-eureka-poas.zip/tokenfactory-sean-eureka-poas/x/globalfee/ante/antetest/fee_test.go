package antetest

import (
	"testing"

	"cosmossdk.io/store/types"
	"github.com/cosmos/cosmos-sdk/codec"
	paramtypes "github.com/cosmos/cosmos-sdk/x/params/types"
	"github.com/stretchr/testify/require"
	"github.com/wfblockchain/noblechain/v5/x/globalfee/ante"
	gtypes "github.com/wfblockchain/noblechain/v5/x/globalfee/types"
)

func TestNewFeeDecorator(t *testing.T) {
	cdc := codec.NewLegacyAmino()
	bCodec := codec.NewProtoCodec(nil)
	storeKey1 := types.NewMemoryStoreKey("globalfee")
	storeKey2 := types.NewMemoryStoreKey("staking")
	keyTable := paramtypes.NewKeyTable().RegisterParamSet(&gtypes.Params{})
	globalfeeSubspace := paramtypes.NewSubspace(bCodec, cdc, storeKey1, storeKey1, "GlobalFee").WithKeyTable(keyTable)
	stakingSubspace := paramtypes.NewSubspace(bCodec, cdc, storeKey2, storeKey2, "Staking").WithKeyTable(keyTable)
	require.NotPanics(t, func() {
		fd := ante.NewFeeDecorator(globalfeeSubspace, stakingSubspace, 100)
		require.NotNil(t, fd, "FeeDecorator should be initialized properly")
	})
}
