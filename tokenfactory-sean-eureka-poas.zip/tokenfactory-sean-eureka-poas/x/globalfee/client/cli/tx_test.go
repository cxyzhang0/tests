package cli_test

import (
	"context"
	"testing"
	"time"

	"github.com/cosmos/cosmos-sdk/client"
	"github.com/spf13/cobra"
	"github.com/stretchr/testify/mock"
	"github.com/stretchr/testify/require"
	"github.com/wfblockchain/noblechain/v5/x/globalfee/client/cli"
	"github.com/wfblockchain/noblechain/v5/x/globalfee/types"
)

func TxRegisterAccount() *cobra.Command {
	return &cobra.Command{
		Use: "register-account",
		RunE: func(cmd *cobra.Command, args []string) error {
			return nil
		},
	}
}

func TxClearAccount() *cobra.Command {
	return &cobra.Command{
		Use: "clear-account",
		RunE: func(cmd *cobra.Command, args []string) error {
			return nil
		},
	}
}

func TestGetQueryCmd(t *testing.T) {
	queryCmd := cli.GetQueryCmd()
	require.NotNil(t, queryCmd, "Query command should not be nil")
	t.Log("Available subcommands:")
	for _, cmd := range queryCmd.Commands() {
		t.Logf(" - %s", cmd.Use)
	}
	var found bool
	for _, cmd := range queryCmd.Commands() {
		if cmd.Use == "parameters" {
			found = true
			break
		}
	}
	require.True(t, found, "GetCmdShowMinimumGasPrices should be a subcommand")

}

type MockQueryClient struct {
	mock.Mock
	clientCtx client.Context
}

func (m *MockQueryClient) Params(ctx context.Context, req *types.QueryParamsRequest) (*types.QueryParamsResponse, error) {
	args := m.Called(ctx, req)
	return args.Get(0).(*types.QueryParamsResponse), args.Error(1)
}

func (m *MockQueryClient) Deadline() (deadline time.Time, ok bool) {
	return time.Time{}, false
}

func (m *MockQueryClient) Done() <-chan struct{} {
	ch := make(chan struct{})
	close(ch)
	return ch
}

func (m *MockQueryClient) Err() error {
	return nil
}

func (m *MockQueryClient) Value(key interface{}) interface{} {
	return nil
}

func TestGetCmdShowMinimumGasPrices_RunE(t *testing.T) {
	cmd := cli.GetCmdShowMinimumGasPrices()
	require.NotNil(t, cmd, "Command should not be nil")
	clientCtx := client.Context{}
	mockClient := &MockQueryClient{clientCtx: clientCtx}
	cmd.SetContext(mockClient)
	mockQueryClient := new(MockQueryClient)
	expectedResponse := &types.QueryParamsResponse{}
	mockQueryClient.On("Params", mock.Anything, &types.QueryParamsRequest{}).Return(expectedResponse, nil)
	cmd.RunE = func(cmd *cobra.Command, args []string) error {
		res, err := mockQueryClient.Params(cmd.Context(), &types.QueryParamsRequest{})
		if err != nil {
			return err
		}
		require.Equal(t, expectedResponse, res, "Response should match expected")
		return nil
	}
	err := cmd.Execute()
	require.NoError(t, err, "Command execution should not fail")
	mockQueryClient.AssertExpectations(t)
}
