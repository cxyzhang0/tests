package cli

import (
	"github.com/cosmos/cosmos-sdk/client"
	"github.com/cosmos/cosmos-sdk/client/flags"
	"github.com/spf13/cobra"

	"github.com/wfblockchain/noblechain/v5/x/globalfee/types"
)

func GetQueryCmd() *cobra.Command {
	queryCmd := &cobra.Command{
		Use:                        types.ModuleName,
		Short:                      "Querying commands for the global fee module",
		DisableFlagParsing:         true,
		SuggestionsMinimumDistance: 2,
		RunE:                       client.ValidateCmd,
	}
	queryCmd.AddCommand(
		GetCmdShowMinimumGasPrices(),
	)
	return queryCmd
}

func GetCmdShowMinimumGasPrices() *cobra.Command {
	cmd := &cobra.Command{
		Use:     "parameters",
		Short:   "query module parameters",
		Long:    "Query the current global fee module parameters",
		Aliases: []string{"params"},
		Args:    cobra.ExactArgs(0),
		RunE: func(cmd *cobra.Command, args []string) error {
			clientCtx, _ := client.GetClientQueryContext(cmd)

			queryClient := types.NewQueryClient(clientCtx)
			res, _ := queryClient.Params(cmd.Context(), &types.QueryParamsRequest{})

			return clientCtx.PrintProto(res)
		},
	}
	flags.AddQueryFlagsToCmd(cmd)
	return cmd
}
