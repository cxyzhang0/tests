package keepers

import (
	"fmt"
	codectypes "github.com/cosmos/cosmos-sdk/codec/types"
	"github.com/cosmos/cosmos-sdk/x/params"
	paramproposal "github.com/cosmos/cosmos-sdk/x/params/types/proposal"
	"github.com/spf13/cast"
	"os"
	"path/filepath"

	"github.com/CosmWasm/wasmd/x/wasm"
	wasmkeeper "github.com/CosmWasm/wasmd/x/wasm/keeper"
	wasmtypes "github.com/CosmWasm/wasmd/x/wasm/types"
	wasmvm "github.com/CosmWasm/wasmvm/v2"

	"cosmossdk.io/log"
	storetypes "cosmossdk.io/store/types"
	circuitkeeper "cosmossdk.io/x/circuit/keeper"
	circuittypes "cosmossdk.io/x/circuit/types"
	evidencekeeper "cosmossdk.io/x/evidence/keeper"
	evidencetypes "cosmossdk.io/x/evidence/types"
	"cosmossdk.io/x/feegrant"
	feegrantkeeper "cosmossdk.io/x/feegrant/keeper"
	nftkeeper "cosmossdk.io/x/nft/keeper"
	upgradekeeper "cosmossdk.io/x/upgrade/keeper"
	upgradetypes "cosmossdk.io/x/upgrade/types"

	"github.com/cosmos/cosmos-sdk/baseapp"
	"github.com/cosmos/cosmos-sdk/codec"
	"github.com/cosmos/cosmos-sdk/runtime"
	"github.com/cosmos/cosmos-sdk/server"
	servertypes "github.com/cosmos/cosmos-sdk/server/types"
	sdk "github.com/cosmos/cosmos-sdk/types"
	authcodec "github.com/cosmos/cosmos-sdk/x/auth/codec"
	authkeeper "github.com/cosmos/cosmos-sdk/x/auth/keeper"
	authtypes "github.com/cosmos/cosmos-sdk/x/auth/types"
	authzkeeper "github.com/cosmos/cosmos-sdk/x/authz/keeper"
	bankkeeper "github.com/cosmos/cosmos-sdk/x/bank/keeper"
	banktypes "github.com/cosmos/cosmos-sdk/x/bank/types"
	consensusparamkeeper "github.com/cosmos/cosmos-sdk/x/consensus/keeper"
	consensusparamtypes "github.com/cosmos/cosmos-sdk/x/consensus/types"
	crisiskeeper "github.com/cosmos/cosmos-sdk/x/crisis/keeper"
	crisistypes "github.com/cosmos/cosmos-sdk/x/crisis/types"
	distrkeeper "github.com/cosmos/cosmos-sdk/x/distribution/keeper"
	distrtypes "github.com/cosmos/cosmos-sdk/x/distribution/types"
	govkeeper "github.com/cosmos/cosmos-sdk/x/gov/keeper"
	govtypes "github.com/cosmos/cosmos-sdk/x/gov/types"
	govv1 "github.com/cosmos/cosmos-sdk/x/gov/types/v1"
	govv1beta1 "github.com/cosmos/cosmos-sdk/x/gov/types/v1beta1"
	"github.com/cosmos/cosmos-sdk/x/group"
	groupkeeper "github.com/cosmos/cosmos-sdk/x/group/keeper"
	mintkeeper "github.com/cosmos/cosmos-sdk/x/mint/keeper"
	minttypes "github.com/cosmos/cosmos-sdk/x/mint/types"
	paramskeeper "github.com/cosmos/cosmos-sdk/x/params/keeper"
	paramstypes "github.com/cosmos/cosmos-sdk/x/params/types"
	slashingkeeper "github.com/cosmos/cosmos-sdk/x/slashing/keeper"
	slashingtypes "github.com/cosmos/cosmos-sdk/x/slashing/types"
	stakingkeeper "github.com/cosmos/cosmos-sdk/x/staking/keeper"
	stakingtypes "github.com/cosmos/cosmos-sdk/x/staking/types"

	pfm "github.com/cosmos/ibc-apps/middleware/packet-forward-middleware/v10/packetforward"
	pfmkeeper "github.com/cosmos/ibc-apps/middleware/packet-forward-middleware/v10/packetforward/keeper"
	pfmtypes "github.com/cosmos/ibc-apps/middleware/packet-forward-middleware/v10/packetforward/types"
	ratelimit "github.com/cosmos/ibc-apps/modules/rate-limiting/v10"
	ratelimitkeeper "github.com/cosmos/ibc-apps/modules/rate-limiting/v10/keeper"
	ratelimittypes "github.com/cosmos/ibc-apps/modules/rate-limiting/v10/types"
	ratelimitv2 "github.com/cosmos/ibc-apps/modules/rate-limiting/v10/v2"

	"github.com/cosmos/ibc-go/modules/light-clients/08-wasm/v10/blsverifier"
	ibcwasmkeeper "github.com/cosmos/ibc-go/modules/light-clients/08-wasm/v10/keeper"
	ibcwasmtypes "github.com/cosmos/ibc-go/modules/light-clients/08-wasm/v10/types"
	icacontroller "github.com/cosmos/ibc-go/v10/modules/apps/27-interchain-accounts/controller"
	icacontrollerkeeper "github.com/cosmos/ibc-go/v10/modules/apps/27-interchain-accounts/controller/keeper"
	icacontrollertypes "github.com/cosmos/ibc-go/v10/modules/apps/27-interchain-accounts/controller/types"
	icahost "github.com/cosmos/ibc-go/v10/modules/apps/27-interchain-accounts/host"
	icahostkeeper "github.com/cosmos/ibc-go/v10/modules/apps/27-interchain-accounts/host/keeper"
	icahosttypes "github.com/cosmos/ibc-go/v10/modules/apps/27-interchain-accounts/host/types"
	ibccallbacks "github.com/cosmos/ibc-go/v10/modules/apps/callbacks"
	ibccallbacksv2 "github.com/cosmos/ibc-go/v10/modules/apps/callbacks/v2"
	ibctransfer "github.com/cosmos/ibc-go/v10/modules/apps/transfer"
	ibctransferkeeper "github.com/cosmos/ibc-go/v10/modules/apps/transfer/keeper"
	ibctransfertypes "github.com/cosmos/ibc-go/v10/modules/apps/transfer/types"
	ibctransferv2 "github.com/cosmos/ibc-go/v10/modules/apps/transfer/v2"
	ibcclienttypes "github.com/cosmos/ibc-go/v10/modules/core/02-client/types"
	ibcconnectiontypes "github.com/cosmos/ibc-go/v10/modules/core/03-connection/types"
	porttypes "github.com/cosmos/ibc-go/v10/modules/core/05-port/types"
	ibcapi "github.com/cosmos/ibc-go/v10/modules/core/api"
	ibcexported "github.com/cosmos/ibc-go/v10/modules/core/exported"
	ibckeeper "github.com/cosmos/ibc-go/v10/modules/core/keeper"
	icsprovider "github.com/cosmos/interchain-security/v7/x/ccv/provider"
	icsproviderkeeper "github.com/cosmos/interchain-security/v7/x/ccv/provider/keeper"
	icsprovidertypes "github.com/cosmos/interchain-security/v7/x/ccv/provider/types"

	//cctpkeeper "github.com/circlefin/noble-cctp/x/cctp/keeper"
	//cctptypes "github.com/circlefin/noble-cctp/x/cctp/types"
	//ftfkeeper "github.com/circlefin/noble-fiattokenfactory/x/fiattokenfactory/keeper"
	//ftftypes "github.com/circlefin/noble-fiattokenfactory/x/fiattokenfactory/types"

	poaskeeper "github.com/wfblockchain/noblechain/v5/x/poas/keeper"

	tfbinding "github.com/wfblockchain/noblechain/v5/x/contracts/tokenfactory"
	"github.com/wfblockchain/noblechain/v5/x/globalfee"
	tfkeeper "github.com/wfblockchain/noblechain/v5/x/tokenfactory/keeper"
	tftypes "github.com/wfblockchain/noblechain/v5/x/tokenfactory/types"
)

const (
	// MaxIBCCallbackGas should roughly be a couple orders of magnitude larger than needed.
	MaxIBCCallbackGas = uint64(10_000_000)
)

type AppKeepers struct {
	// keys to access the substores
	keys  map[string]*storetypes.KVStoreKey
	tkeys map[string]*storetypes.TransientStoreKey

	// keepers
	ParamsKeeper          paramskeeper.Keeper
	ConsensusParamsKeeper consensusparamkeeper.Keeper
	AccountKeeper         authkeeper.AccountKeeper
	BankKeeper            bankkeeper.Keeper
	AuthzKeeper           authzkeeper.Keeper
	FeeGrantKeeper        feegrantkeeper.Keeper
	StakingKeeper         *stakingkeeper.Keeper
	DistrKeeper           distrkeeper.Keeper
	SlashingKeeper        slashingkeeper.Keeper
	UpgradeKeeper         *upgradekeeper.Keeper
	IBCKeeper             *ibckeeper.Keeper // IBC Keeper must be a pointer in the app, so we can SetRouter on it correctly
	WasmClientKeeper      ibcwasmkeeper.Keeper
	ICSProviderKeeper     icsproviderkeeper.Keeper
	GovKeeper             *govkeeper.Keeper
	MintKeeper            mintkeeper.Keeper
	EvidenceKeeper        evidencekeeper.Keeper
	GroupKeeper           groupkeeper.Keeper //todo: do we need GroupKeeper? noble does not have it anymore.
	NFTKeeper             nftkeeper.Keeper
	CircuitKeeper         circuitkeeper.Keeper //todo: do we need CircuitKeeper? noble does not have it anymore.
	CrisisKeeper          *crisiskeeper.Keeper //todo: do we need CrisisKeeper?

	ICAHostKeeper       icahostkeeper.Keeper
	RatelimitKeeper     ratelimitkeeper.Keeper //todo: should this be a pointer since ratelimitkeeper.NewKeeper returns a pointer?
	ICAControllerKeeper icacontrollerkeeper.Keeper
	PFMKeeper           *pfmkeeper.Keeper
	IBCTransferKeeper   ibctransferkeeper.Keeper

	TFKeeper  *tfkeeper.Keeper
	FTFKeeper *tfkeeper.Keeper // todo: remove FTFKeeper.

	POASKeeper poaskeeper.Keeper
	WasmKeeper wasmkeeper.Keeper

	// custom modules keepers
	//CCTPKeeper *cctpkeeper.Keeper

	/*
		noble-assets' forwarding keeper is only ibc v8 compatible, but not ibc v10 compatible.
		todo: wait for ibc v10 compatible forwarding keeper
	*/
	//ForwardingKeeper *forwardingkeeper.Keeper

	/*
		tariff keeper is only ibc v8 compatible, but not ibc v10 compatible.
		mostly importantly, noble-assets does not have tariff keeper anymore.
	*/
	//TariffKeeper tariffkeeper.Keeper //todo: do we need TarrifKeeper? noble does not have it anymore.

	// modules
	ICSProviderModule icsprovider.AppModule

	/*
		these mock modules were inherited from early versons of noble-assets's noble chain.
		now neither noble nor gaia use them so we do not support them either.
		if in the future we need them, refer to app_bak.
	*/
	// Mock modules for testing
	//IBCMockModule mock.IBCModule
	//ICAAuthModule mock.IBCModule
	//FeeMockModule mock.IBCModule
}

func NewAppKeeper(
	appCodec codec.Codec,
	bApp *baseapp.BaseApp,
	legacyAmino *codec.LegacyAmino,
	maccPerms map[string][]string,
	//modAccAddrs map[string]bool, // gaia passes in as derived from maccPerms, but never uses it.
	blockedAddress map[string]bool,
	//skipUpgradeHeights map[int64]bool, // gaia passes this in, but we construct it from appOpts below just as gaia does in its root.go
	homePath string,
	logger log.Logger,
	appOpts servertypes.AppOptions,
	interfaceRegistry codectypes.InterfaceRegistry,
	// wasmOpts []wasmkeeper.Option, // gaia passes this in as wasmkeeper.WithVMCacheMetrics(prometheus.DefaultRegisterer if telemetry is enabled
) AppKeepers {
	appKeepers := AppKeepers{}

	// Set keys KVStoreKey, TransientStoreKey, MemoryStoreKey
	appKeepers.GenerateKeys()

	/*
		configure state listening capabilities using AppOptions
		we are doing nothing with the returned streamingServices and waitGroup in this case
	*/
	// load state streaming if enabled
	if err := bApp.RegisterStreamingServices(appOpts, appKeepers.keys); err != nil {
		logger.Error("failed to load state streaming", "err", err)
		os.Exit(1)
	}

	appKeepers.ParamsKeeper = initParamsKeeper(
		appCodec,
		legacyAmino,
		appKeepers.keys[paramstypes.StoreKey],
		appKeepers.tkeys[paramstypes.TStoreKey],
	)

	// set the BaseApp's param store
	appKeepers.ConsensusParamsKeeper = consensusparamkeeper.NewKeeper(
		appCodec,
		runtime.NewKVStoreService(appKeepers.keys[consensusparamtypes.StoreKey]),
		authtypes.NewModuleAddress(govtypes.ModuleName).String(),
		runtime.EventService{},
	)
	bApp.SetParamStore(appKeepers.ConsensusParamsKeeper.ParamsStore)

	// add normal keepers
	appKeepers.AccountKeeper = authkeeper.NewAccountKeeper(
		appCodec,
		runtime.NewKVStoreService(appKeepers.keys[authtypes.StoreKey]),
		authtypes.ProtoBaseAccount,
		maccPerms,
		authcodec.NewBech32Codec(sdk.GetConfig().GetBech32AccountAddrPrefix()),
		sdk.GetConfig().GetBech32AccountAddrPrefix(),
		authtypes.NewModuleAddress(govtypes.ModuleName).String(),
	)

	appKeepers.BankKeeper = bankkeeper.NewBaseKeeper(
		appCodec,
		runtime.NewKVStoreService(appKeepers.keys[banktypes.StoreKey]),
		appKeepers.AccountKeeper,
		blockedAddress,
		authtypes.NewModuleAddress(govtypes.ModuleName).String(),
		logger,
	)

	appKeepers.AuthzKeeper = authzkeeper.NewKeeper(
		runtime.NewKVStoreService(appKeepers.keys[authzkeeper.StoreKey]),
		appCodec,
		bApp.MsgServiceRouter(),
		appKeepers.AccountKeeper,
	)
	// We need to set the bank keeper here otherwise risk a NPE in certain message handlers
	appKeepers.AuthzKeeper = appKeepers.AuthzKeeper.SetBankKeeper(appKeepers.BankKeeper)

	appKeepers.FeeGrantKeeper = feegrantkeeper.NewKeeper(
		appCodec,
		runtime.NewKVStoreService(appKeepers.keys[feegrant.StoreKey]),
		appKeepers.AccountKeeper,
	)

	appKeepers.StakingKeeper = stakingkeeper.NewKeeper(
		appCodec,
		runtime.NewKVStoreService(appKeepers.keys[stakingtypes.StoreKey]),
		appKeepers.AccountKeeper,
		appKeepers.BankKeeper,
		authtypes.NewModuleAddress(govtypes.ModuleName).String(),
		authcodec.NewBech32Codec(sdk.GetConfig().GetBech32ValidatorAddrPrefix()),
		authcodec.NewBech32Codec(sdk.GetConfig().GetBech32ConsensusAddrPrefix()),
	)

	appKeepers.DistrKeeper = distrkeeper.NewKeeper(
		appCodec,
		runtime.NewKVStoreService(appKeepers.keys[distrtypes.StoreKey]),
		appKeepers.AccountKeeper,
		appKeepers.BankKeeper,
		appKeepers.StakingKeeper,
		authtypes.FeeCollectorName,
		authtypes.NewModuleAddress(govtypes.ModuleName).String(),
	)

	appKeepers.SlashingKeeper = slashingkeeper.NewKeeper(
		appCodec,
		legacyAmino,
		runtime.NewKVStoreService(appKeepers.keys[slashingtypes.StoreKey]),
		appKeepers.StakingKeeper,
		authtypes.NewModuleAddress(govtypes.ModuleName).String(),
	)

	// register the staking hooks
	// NOTE: stakingKeeper above is passed by reference, so that it will contain these hooks
	appKeepers.StakingKeeper.SetHooks(
		stakingtypes.NewMultiStakingHooks(
			appKeepers.DistrKeeper.Hooks(),
			appKeepers.SlashingKeeper.Hooks(),
			appKeepers.ICSProviderKeeper.Hooks(),
			//appKeepers.LiquidKeeper.Hooks(), //todo: do we need this? gaia has it.
		),
	)

	skipUpgradeHeights := map[int64]bool{}
	for _, h := range cast.ToIntSlice(appOpts.Get(server.FlagUnsafeSkipUpgrades)) {
		skipUpgradeHeights[int64(h)] = true
	}

	// upgrade keeper msut be created before the IBC keeper
	appKeepers.UpgradeKeeper = upgradekeeper.NewKeeper(
		skipUpgradeHeights,
		runtime.NewKVStoreService(appKeepers.keys[upgradetypes.StoreKey]),
		appCodec, // Ensure appCodec implements codec.BinaryCodec
		homePath,
		bApp, // Use the ProtocolVersionSetter from BaseApp    // Provide the Subspace for the upgrade module
		authtypes.NewModuleAddress(govtypes.ModuleName).String(), // Authority address
	)

	// ibc keeper must be created after the upgrade keeper
	appKeepers.IBCKeeper = ibckeeper.NewKeeper(
		appCodec,
		runtime.NewKVStoreService(appKeepers.keys[ibcexported.StoreKey]),
		appKeepers.GetSubspace(ibcexported.ModuleName),
		appKeepers.UpgradeKeeper,
		authtypes.NewModuleAddress(govtypes.ModuleName).String(),
	)

	// wasm light client keeper. note there is another way: https://ibc.cosmos.network/v10/ibc/light-clients/wasm/integration/#if-xwasm-is-not-present
	wasmLightClientQuerier := ibcwasmkeeper.QueryPlugins{
		// Custom: MyCustomQueryPlugin(),
		// `myAcceptList` is a `[]string` containing the list of gRPC query paths that the chain wants to allow for the `08-wasm` module to query.
		// These queries must be registered in the chain's gRPC query router, be deterministic, and track their gas usage.
		// The `AcceptListStargateQuerier` function will return a query plugin that will only allow queries for the paths in the `myAcceptList`.
		// The query responses are encoded in protobuf unlike the implementation in `x/wasm`.
		Stargate: ibcwasmkeeper.AcceptListStargateQuerier([]string{
			"/ibc.core.client.v1.Query/ClientState",
			"/ibc.core.client.v1.Query/ConsensusState",
			"/ibc.core.connection.v1.Query/Connection",
		}, bApp.GRPCQueryRouter()),
		Custom: blsverifier.CustomQuerier(),
	}

	dataDir := filepath.Join(homePath, "data")

	var memCacheSizeMB uint32 = 100
	lc08, err := wasmvm.NewVM(filepath.Join(dataDir, "08-light-client"), wasmkeeper.BuiltInCapabilities(), 32, false, memCacheSizeMB)
	if err != nil {
		panic(fmt.Sprintf("failed to create VM for 08 light client: %s", err))
	}

	appKeepers.WasmClientKeeper = ibcwasmkeeper.NewKeeperWithVM(
		appCodec,
		runtime.NewKVStoreService(appKeepers.keys[ibcwasmtypes.StoreKey]),
		appKeepers.IBCKeeper.ClientKeeper,
		authtypes.NewModuleAddress(govtypes.ModuleName).String(),
		lc08,
		bApp.GRPCQueryRouter(),
		ibcwasmkeeper.WithQueryPlugins(&wasmLightClientQuerier),
	)

	appKeepers.ICSProviderKeeper = icsproviderkeeper.NewKeeper(
		appCodec,
		appKeepers.keys[icsprovidertypes.StoreKey],
		appKeepers.GetSubspace(icsprovidertypes.ModuleName),
		appKeepers.IBCKeeper.ChannelKeeper,
		appKeepers.IBCKeeper.ConnectionKeeper,
		appKeepers.IBCKeeper.ClientKeeper,
		appKeepers.StakingKeeper,
		appKeepers.SlashingKeeper,
		appKeepers.AccountKeeper,
		appKeepers.DistrKeeper,
		appKeepers.BankKeeper,
		govkeeper.Keeper{}, //todo: how to// cyclic dependency between provider and governance, will be set later
		authtypes.NewModuleAddress(govtypes.ModuleName).String(),
		authcodec.NewBech32Codec(sdk.GetConfig().GetBech32ValidatorAddrPrefix()),
		authcodec.NewBech32Codec(sdk.GetConfig().GetBech32ConsensusAddrPrefix()),
		authtypes.FeeCollectorName,
	)

	// gov keeper and staking keeper have a cyclic dependency
	/*
		it used to depend on staking keeper.
		gaia uses icsprovider keeper for staking keeper
			because governance should be based on the consensus-active validators
	*/
	govConfig := govtypes.DefaultConfig()
	// set the MaxMetadataLen for proposals to the same value as it was pre-sdk v0.47.x
	govConfig.MaxMetadataLen = 10200
	appKeepers.GovKeeper = govkeeper.NewKeeper(
		appCodec,
		runtime.NewKVStoreService(appKeepers.keys[govtypes.StoreKey]),
		appKeepers.AccountKeeper,
		appKeepers.BankKeeper,
		appKeepers.ICSProviderKeeper,
		appKeepers.DistrKeeper,
		bApp.MsgServiceRouter(),
		govConfig,
		authtypes.NewModuleAddress(govtypes.ModuleName).String(),
	)

	// mint keeper
	/*
		mint keeper used to use the staking keeper
		gaia uses icsprovider keeper instead
	*/
	appKeepers.MintKeeper = mintkeeper.NewKeeper(
		appCodec,
		runtime.NewKVStoreService(appKeepers.keys[minttypes.StoreKey]),
		appKeepers.ICSProviderKeeper,
		appKeepers.AccountKeeper,
		appKeepers.BankKeeper,
		authtypes.FeeCollectorName,
		authtypes.NewModuleAddress(govtypes.ModuleName).String(),
	)

	//todo: why does gaia SetGovKeeper after minter keeper? can it just after gov keeper?
	appKeepers.ICSProviderKeeper.SetGovKeeper(*appKeepers.GovKeeper)

	appKeepers.ICSProviderModule = icsprovider.NewAppModule(
		&appKeepers.ICSProviderKeeper,
		appKeepers.GetSubspace(icsprovidertypes.ModuleName),
		appKeepers.keys[icsprovidertypes.StoreKey],
	)

	// set the governance module account as the authority for conducting upgrades
	// Register the proposal types
	// Deprecated: Avoid adding new handlers, instead use the new proposal flow
	// by granting the governance module the right to execute the message.
	// See: https://docs.cosmos.network/main/modules/gov#proposal-messages
	govRouter := govv1beta1.NewRouter()
	govRouter.
		AddRoute(govtypes.RouterKey, govv1beta1.ProposalHandler).
		AddRoute(paramproposal.RouterKey, params.NewParamChangeProposalHandler(appKeepers.ParamsKeeper))

	// Set legacy router for backwards compatibility with gov v1beta1
	appKeepers.GovKeeper.SetLegacyRouter(govRouter)

	appKeepers.GovKeeper = appKeepers.GovKeeper.SetHooks(
		govtypes.NewMultiGovHooks(
			appKeepers.ICSProviderKeeper.Hooks(),
		),
	)

	evidenceKeeper := evidencekeeper.NewKeeper(
		appCodec,
		runtime.NewKVStoreService(appKeepers.keys[evidencetypes.StoreKey]),
		appKeepers.StakingKeeper,
		appKeepers.SlashingKeeper,
		appKeepers.AccountKeeper.AddressCodec(),
		runtime.ProvideCometInfoService(),
	)
	// If evidence needs to be handled for the app, set routes in router here and seal
	appKeepers.EvidenceKeeper = *evidenceKeeper

	groupConfig := group.DefaultConfig()
	appKeepers.GroupKeeper = groupkeeper.NewKeeper(
		appKeepers.keys[group.StoreKey],
		appCodec,
		bApp.MsgServiceRouter(),
		appKeepers.AccountKeeper,
		groupConfig,
	)

	appKeepers.NFTKeeper = nftkeeper.NewKeeper(
		runtime.NewKVStoreService(appKeepers.keys[nftkeeper.StoreKey]),
		appCodec,
		appKeepers.AccountKeeper,
		appKeepers.BankKeeper,
	)

	appKeepers.CircuitKeeper = circuitkeeper.NewKeeper(
		appCodec,
		runtime.NewKVStoreService(appKeepers.keys[circuittypes.StoreKey]),
		authtypes.NewModuleAddress(govtypes.ModuleName).String(),
		appKeepers.AccountKeeper.AddressCodec(),
	)

	bApp.SetCircuitBreaker(&appKeepers.CircuitKeeper)

	invCheckPeriod := cast.ToUint(appOpts.Get(server.FlagInvCheckPeriod))
	appKeepers.CrisisKeeper = crisiskeeper.NewKeeper(
		appCodec,
		runtime.NewKVStoreService(appKeepers.keys[crisistypes.StoreKey]),
		invCheckPeriod,
		appKeepers.BankKeeper,
		authtypes.FeeCollectorName,
		authtypes.NewModuleAddress(govtypes.ModuleName).String(),
		appKeepers.AccountKeeper.AddressCodec(),
	)

	appKeepers.ICAHostKeeper = icahostkeeper.NewKeeper(
		appCodec,
		runtime.NewKVStoreService(appKeepers.keys[icahosttypes.StoreKey]),
		appKeepers.GetSubspace(icahosttypes.SubModuleName),
		appKeepers.IBCKeeper.ChannelKeeper,
		appKeepers.IBCKeeper.ChannelKeeper,
		appKeepers.AccountKeeper,
		bApp.MsgServiceRouter(),
		bApp.GRPCQueryRouter(),
		authtypes.NewModuleAddress(govtypes.ModuleName).String(),
	)

	/*
		todo: why do we use only govAuthority for RatelimitKeeper and PFMKeeper?
			can we use it for all other keepers?
	*/
	govAuthority := authtypes.NewModuleAddress(govtypes.ModuleName).String()
	appKeepers.RatelimitKeeper = *ratelimitkeeper.NewKeeper(
		appCodec, // BinaryCodec
		runtime.NewKVStoreService(appKeepers.keys[ratelimittypes.StoreKey]), // StoreKey
		appKeepers.GetSubspace(ratelimittypes.ModuleName),                   // param Subspace
		govAuthority, // authority
		appKeepers.BankKeeper,
		appKeepers.IBCKeeper.ChannelKeeper, // ChannelKeeper
		appKeepers.IBCKeeper.ClientKeeper,
		appKeepers.IBCKeeper.ChannelKeeper, // ICS4Wrapper
	)

	appKeepers.ICAControllerKeeper = icacontrollerkeeper.NewKeeper(
		appCodec,
		runtime.NewKVStoreService(appKeepers.keys[icacontrollertypes.StoreKey]),
		appKeepers.GetSubspace(icacontrollertypes.SubModuleName),
		appKeepers.IBCKeeper.ChannelKeeper,
		appKeepers.IBCKeeper.ChannelKeeper,
		bApp.MsgServiceRouter(),
		authtypes.NewModuleAddress(govtypes.ModuleName).String(),
	)

	// PFMKeeper must be created before IBCTransferKeeper
	appKeepers.PFMKeeper = pfmkeeper.NewKeeper(
		appCodec,
		runtime.NewKVStoreService(appKeepers.keys[pfmtypes.StoreKey]),
		nil, // Will be zero-value here. Reference is set later on with SetTransferKeeper.
		appKeepers.IBCKeeper.ChannelKeeper,
		appKeepers.BankKeeper,
		appKeepers.RatelimitKeeper, // ICS4Wrapper
		govAuthority,
	)

	// transfer keeper must be created after the packet forward middleware keeper
	appKeepers.IBCTransferKeeper = ibctransferkeeper.NewKeeper(
		appCodec,
		runtime.NewKVStoreService(appKeepers.keys[ibctransfertypes.StoreKey]),
		appKeepers.GetSubspace(ibctransfertypes.ModuleName),
		appKeepers.IBCKeeper.ChannelKeeper, // ISC4 Wrapper: This is overridden later
		appKeepers.IBCKeeper.ChannelKeeper,
		bApp.MsgServiceRouter(),
		appKeepers.AccountKeeper,
		appKeepers.BankKeeper,
		authtypes.NewModuleAddress(govtypes.ModuleName).String(),
	)

	// Must be called on PFMRouter AFTER IBCTransferKeeper initialized
	/*
		I don't understand why IBCTransferKeeper cannot be set before PFMKeeper is created
		since the former does not depend on the latter.
	*/
	appKeepers.PFMKeeper.SetTransferKeeper(appKeepers.IBCTransferKeeper)

	// poas keeper after staking and gov keepers
	appKeepers.POASKeeper = poaskeeper.NewKeeper(
		interfaceRegistry,
		appKeepers.StakingKeeper,
		appKeepers.GovKeeper,
	)

	// tokenfactory keeper and fiat token factory keeper must be created before wasm keeper
	appKeepers.TFKeeper = tfkeeper.NewKeeper(
		appCodec,
		appKeepers.keys[tftypes.StoreKey],
		appKeepers.GetSubspace(tftypes.ModuleName),
		appKeepers.BankKeeper,
		runtime.NewKVStoreService(appKeepers.keys[tftypes.StoreKey]),
	)

	// FTFKeeper is the same as TFKeeper
	appKeepers.FTFKeeper = tfkeeper.NewKeeper(
		appCodec,
		appKeepers.keys[tftypes.StoreKey],
		appKeepers.GetSubspace(tftypes.ModuleName),
		appKeepers.BankKeeper,
		runtime.NewKVStoreService(appKeepers.keys[tftypes.StoreKey]),
	)

	// old FTFKeeper
	//appKeepers.FTFKeeper = ftfkeeper.NewKeeper(
	//	appCodec,
	//	logger,
	//	runtime.NewKVStoreService(appKeepers.keys[ftftypes.StoreKey]),
	//	appKeepers.BankKeeper,
	//)

	// wasm keeper must be created after the tokenfactory keeper and fiat token factory keeper
	wasmDir := filepath.Join(homePath, "wasm")
	wasmConfig, err := wasm.ReadNodeConfig(appOpts)
	if err != nil {
		panic("error while reading wasm config: " + err.Error())
	}

	availableCapabilities := wasmkeeper.BuiltInCapabilities()
	availableCapabilities = append(availableCapabilities, "tokenfactory", "fiattokenfactory")
	bankbasekeeper := appKeepers.BankKeeper.(bankkeeper.BaseKeeper)
	var wasmOpts []wasmkeeper.Option
	wasmOpts = append(
		tfbinding.RegisterCustomPlugins(
			appKeepers.TFKeeper,
			appKeepers.FTFKeeper,
			&bankbasekeeper,
			&appKeepers.FeeGrantKeeper),
		wasmOpts...,
	)
	appKeepers.WasmKeeper = wasmkeeper.NewKeeper(
		appCodec,
		runtime.NewKVStoreService(appKeepers.keys[wasmtypes.StoreKey]),
		appKeepers.AccountKeeper,
		appKeepers.BankKeeper,
		appKeepers.StakingKeeper,
		distrkeeper.NewQuerier(appKeepers.DistrKeeper),
		appKeepers.IBCKeeper.ChannelKeeper,
		appKeepers.IBCKeeper.ChannelKeeper,
		appKeepers.IBCTransferKeeper,
		bApp.MsgServiceRouter(),
		bApp.GRPCQueryRouter(),
		wasmDir,
		wasmConfig,
		wasmtypes.VMConfig{},
		availableCapabilities,
		authtypes.NewModuleAddress(govtypes.ModuleName).String(),
		wasmOpts...,
	)

	// wasmStackIBCHandler is injected into both ICA and transfer stacks
	wasmStackIBCHandler := wasm.NewIBCHandler(appKeepers.WasmKeeper, appKeepers.IBCKeeper.ChannelKeeper,
		appKeepers.IBCKeeper.ChannelKeeper)

	//appKeepers.CCTPKeeper = cctpkeeper.NewKeeper(
	//	appCodec,
	//	logger,
	//	runtime.NewKVStoreService(appKeepers.keys[cctptypes.StoreKey]),
	//	appKeepers.BankKeeper,
	//	appKeepers.FTFKeeper,
	//)

	/*
		forwarding.keeper and tariff depend on ibc v8 ChannelKeeper
		but we are using ibc v10
	*/
	/*
			appKeepers.ForwardingKeeper = forwardingkeeper.NewKeeper(
				appCodec,
				appKeepers.keys[forwardingtypes.StoreKey],
				appKeepers.tkeys[forwardingtypes.TransientStoreKey],
				appKeepers.AccountKeeper,
				appKeepers.BankKeeper,
				appKeepers.IBCKeeper.ChannelKeeper,
				nil,
			)

		appKeepers.TariffKeeper = tariffkeeper.NewKeeper(
			appKeepers.GetSubspace(tarifftypes.ModuleName),
			appKeepers.AccountKeeper,
			appKeepers.BankKeeper,
			authtypes.FeeCollectorName,
			appKeepers.IBCKeeper.ChannelKeeper,
		)
	*/

	// Create Transfer Stack (from bottom to top of stack)
	// - core IBC
	// - ratelimit
	// - pfm
	// - provider
	// - callbacks
	// - transfer
	//
	// This is how transfer stack will work in the end:
	// * RecvPacket -> IBC core -> RateLimit -> PFM -> Provider -> Callbacks -> Transfer (AddRoute)
	// * SendPacket -> Transfer -> Callbacks -> PFM -> RateLimit -> IBC core (ICS4Wrapper)

	var transferStack porttypes.IBCModule
	transferStack = ibctransfer.NewIBCModule(appKeepers.IBCTransferKeeper)
	cbStack := ibccallbacks.NewIBCMiddleware(
		transferStack,
		appKeepers.PFMKeeper,
		wasmStackIBCHandler,
		MaxIBCCallbackGas,
	)
	transferStack = icsprovider.NewIBCMiddleware(cbStack, appKeepers.ICSProviderKeeper)
	transferStack = pfm.NewIBCMiddleware(
		transferStack,
		appKeepers.PFMKeeper,
		0, // retries on timeout
		pfmkeeper.DefaultForwardTransferPacketTimeoutTimestamp,
	)
	transferStack = ratelimit.NewIBCMiddleware(appKeepers.RatelimitKeeper, transferStack)
	appKeepers.IBCTransferKeeper.WithICS4Wrapper(cbStack)

	// Create ICAHost Stack
	var icaHostStack porttypes.IBCModule = icahost.NewIBCModule(appKeepers.ICAHostKeeper)

	// Create Interchain Accounts Controller Stack
	var icaControllerStack porttypes.IBCModule = icacontroller.NewIBCMiddleware(appKeepers.ICAControllerKeeper)
	icaControllerStack = ibccallbacks.NewIBCMiddleware(icaControllerStack, appKeepers.IBCKeeper.ChannelKeeper,
		wasmStackIBCHandler, MaxIBCCallbackGas)
	icaICS4Wrapper := icaControllerStack.(porttypes.ICS4Wrapper)
	appKeepers.ICAControllerKeeper.WithICS4Wrapper(icaICS4Wrapper)
	wasmStack := wasm.NewIBCHandler(appKeepers.WasmKeeper, appKeepers.IBCKeeper.ChannelKeeper, appKeepers.IBCKeeper.ChannelKeeper)

	// Create IBCv2 Transfer Stack
	var transferStackV2 ibcapi.IBCModule
	transferStackV2 = ibctransferv2.NewIBCModule(appKeepers.IBCTransferKeeper)
	transferStackV2 = ibccallbacksv2.NewIBCMiddleware(
		transferStackV2,
		appKeepers.IBCKeeper.ChannelKeeperV2,
		wasmStackIBCHandler,
		appKeepers.IBCKeeper.ChannelKeeperV2,
		MaxIBCCallbackGas,
	)
	transferStackV2 = ratelimitv2.NewIBCMiddleware(appKeepers.RatelimitKeeper, transferStackV2)

	// Create IBC Router & seal
	ibcRouter := porttypes.NewRouter().
		AddRoute(icahosttypes.SubModuleName, icaHostStack).
		AddRoute(icacontrollertypes.SubModuleName, icaControllerStack).
		AddRoute(ibctransfertypes.ModuleName, transferStack).
		AddRoute(icsprovidertypes.ModuleName, appKeepers.ICSProviderModule).
		AddRoute(wasmtypes.ModuleName, wasmStack)

	appKeepers.IBCKeeper.SetRouter(ibcRouter)

	// Create IBCv2 Router & seal
	ibcv2Router := ibcapi.NewRouter().
		AddRoute(ibctransfertypes.PortID, transferStackV2)
	appKeepers.IBCKeeper.SetRouterV2(ibcv2Router)

	// Modules
	//appKeepers.TFModule = tf.NewAppModule(appCodec, appKeepers.TFKeeper, appKeepers.AccountKeeper, appKeepers.BankKeeper)
	//appKeepers.FTFModule = ftf.NewAppModule(appKeepers.FTFKeeper, appKeepers.BankKeeper)

	return appKeepers
}

// initParamsKeeper init params keeper and its subspaces
func initParamsKeeper(appCodec codec.BinaryCodec, legacyAmino *codec.LegacyAmino, key,
	tkey storetypes.StoreKey,
) paramskeeper.Keeper { //nolint:staticcheck
	paramsKeeper := paramskeeper.NewKeeper(appCodec, legacyAmino, key, tkey) //nolint:staticcheck

	// register the key tables for legacy param subspaces
	keyTable := ibcclienttypes.ParamKeyTable()
	keyTable.RegisterParamSet(&ibcconnectiontypes.Params{})
	paramsKeeper.Subspace(authtypes.ModuleName).WithKeyTable(authtypes.ParamKeyTable())       //nolint: staticcheck // SA1019
	paramsKeeper.Subspace(banktypes.ModuleName).WithKeyTable(banktypes.ParamKeyTable())       //nolint: staticcheck // SA1019
	paramsKeeper.Subspace(stakingtypes.ModuleName).WithKeyTable(stakingtypes.ParamKeyTable()) //nolint: staticcheck // SA1019

	//paramsKeeper.Subspace(tarifftypes.ModuleName).WithKeyTable(tarifftypes.ParamKeyTable())     //nolint: staticcheck // SA1019
	//does forwarding module need subspace? did not for ibc v8 paramsKeeper.Subspace(forwardingtypes.ModuleName)

	paramsKeeper.Subspace(distrtypes.ModuleName).WithKeyTable(distrtypes.ParamKeyTable())       //nolint: staticcheck // SA1019
	paramsKeeper.Subspace(slashingtypes.ModuleName).WithKeyTable(slashingtypes.ParamKeyTable()) //nolint: staticcheck // SA1019
	paramsKeeper.Subspace(crisistypes.ModuleName).WithKeyTable(crisistypes.ParamKeyTable())     //nolint: staticcheck // SA1019
	paramsKeeper.Subspace(minttypes.ModuleName).WithKeyTable(minttypes.ParamKeyTable())         //nolint: staticcheck // SA1019
	paramsKeeper.Subspace(govtypes.ModuleName).WithKeyTable(govv1.ParamKeyTable())              //nolint: staticcheck // SA1019
	paramsKeeper.Subspace(pfmtypes.ModuleName)
	paramsKeeper.Subspace(ibcexported.ModuleName).WithKeyTable(keyTable)
	paramsKeeper.Subspace(ibctransfertypes.ModuleName).WithKeyTable(ibctransfertypes.ParamKeyTable())
	paramsKeeper.Subspace(icacontrollertypes.SubModuleName).WithKeyTable(icacontrollertypes.ParamKeyTable())
	paramsKeeper.Subspace(icahosttypes.SubModuleName).WithKeyTable(icahosttypes.ParamKeyTable())
	paramsKeeper.Subspace(tftypes.ModuleName)
	//paramsKeeper.Subspace(ftftypes.ModuleName)
	paramsKeeper.Subspace(globalfee.ModuleName)
	//paramsKeeper.Subspace(cctptypes.ModuleName)
	paramsKeeper.Subspace(ratelimittypes.ModuleName).WithKeyTable(ratelimittypes.ParamKeyTable())
	paramsKeeper.Subspace(icsprovidertypes.ModuleName).WithKeyTable(icsprovidertypes.ParamKeyTable())
	paramsKeeper.Subspace(wasmtypes.ModuleName)

	return paramsKeeper
}

// GetSubspace returns a param subspace for a given module name.
func (appKeepers *AppKeepers) GetSubspace(moduleName string) paramstypes.Subspace {
	subspace, ok := appKeepers.ParamsKeeper.GetSubspace(moduleName)
	if !ok {
		panic("couldn't load subspace for module: " + moduleName)
	}
	return subspace
}
