package app

import (
	"cosmossdk.io/x/circuit"
	circuittypes "cosmossdk.io/x/circuit/types"
	"cosmossdk.io/x/evidence"
	evidencetypes "cosmossdk.io/x/evidence/types"
	"cosmossdk.io/x/feegrant"
	feegrantmodule "cosmossdk.io/x/feegrant/module"
	"cosmossdk.io/x/nft"
	nftmodule "cosmossdk.io/x/nft/module"
	"cosmossdk.io/x/upgrade"
	upgradetypes "cosmossdk.io/x/upgrade/types"
	"github.com/CosmWasm/wasmd/x/wasm"
	wasmtypes "github.com/CosmWasm/wasmd/x/wasm/types"
	"github.com/cosmos/cosmos-sdk/x/staking"
	ibcwasm "github.com/cosmos/ibc-go/modules/light-clients/08-wasm/v10"
	"github.com/wfblockchain/noblechain/v5/x/poas"
	poastypes "github.com/wfblockchain/noblechain/v5/x/poas/types"

	//"github.com/circlefin/noble-cctp/x/cctp"
	//cctptypes "github.com/circlefin/noble-cctp/x/cctp/types"
	//ftf "github.com/circlefin/noble-fiattokenfactory/x/fiattokenfactory"
	//ftftypes "github.com/circlefin/noble-fiattokenfactory/x/fiattokenfactory/types"
	"github.com/cosmos/cosmos-sdk/client"
	"github.com/cosmos/cosmos-sdk/codec"
	"github.com/cosmos/cosmos-sdk/types/module"
	"github.com/cosmos/cosmos-sdk/x/auth"
	authtypes "github.com/cosmos/cosmos-sdk/x/auth/types"
	"github.com/cosmos/cosmos-sdk/x/auth/vesting"
	vestingtypes "github.com/cosmos/cosmos-sdk/x/auth/vesting/types"
	"github.com/cosmos/cosmos-sdk/x/authz"
	authzmodule "github.com/cosmos/cosmos-sdk/x/authz/module"
	"github.com/cosmos/cosmos-sdk/x/bank"
	banktypes "github.com/cosmos/cosmos-sdk/x/bank/types"
	"github.com/cosmos/cosmos-sdk/x/consensus"
	consensusparamtypes "github.com/cosmos/cosmos-sdk/x/consensus/types"
	"github.com/cosmos/cosmos-sdk/x/crisis"
	crisistypes "github.com/cosmos/cosmos-sdk/x/crisis/types"
	distr "github.com/cosmos/cosmos-sdk/x/distribution"
	distrtypes "github.com/cosmos/cosmos-sdk/x/distribution/types"
	"github.com/cosmos/cosmos-sdk/x/genutil"
	genutiltypes "github.com/cosmos/cosmos-sdk/x/genutil/types"
	"github.com/cosmos/cosmos-sdk/x/gov"
	govclient "github.com/cosmos/cosmos-sdk/x/gov/client"
	govtypes "github.com/cosmos/cosmos-sdk/x/gov/types"
	"github.com/cosmos/cosmos-sdk/x/group"
	groupmodule "github.com/cosmos/cosmos-sdk/x/group/module"
	"github.com/cosmos/cosmos-sdk/x/mint"
	minttypes "github.com/cosmos/cosmos-sdk/x/mint/types"
	sdkparams "github.com/cosmos/cosmos-sdk/x/params"
	paramsclient "github.com/cosmos/cosmos-sdk/x/params/client"
	paramstypes "github.com/cosmos/cosmos-sdk/x/params/types"
	"github.com/cosmos/cosmos-sdk/x/slashing"
	slashingtypes "github.com/cosmos/cosmos-sdk/x/slashing/types"
	stakingtypes "github.com/cosmos/cosmos-sdk/x/staking/types"
	pfm "github.com/cosmos/ibc-apps/middleware/packet-forward-middleware/v10/packetforward"
	pfmtypes "github.com/cosmos/ibc-apps/middleware/packet-forward-middleware/v10/packetforward/types"
	ratelimit "github.com/cosmos/ibc-apps/modules/rate-limiting/v10"
	ratelimittypes "github.com/cosmos/ibc-apps/modules/rate-limiting/v10/types"
	ibcwasmtypes "github.com/cosmos/ibc-go/modules/light-clients/08-wasm/v10/types"
	ica "github.com/cosmos/ibc-go/v10/modules/apps/27-interchain-accounts"
	icatypes "github.com/cosmos/ibc-go/v10/modules/apps/27-interchain-accounts/types"
	ibctransfer "github.com/cosmos/ibc-go/v10/modules/apps/transfer"
	ibctransfertypes "github.com/cosmos/ibc-go/v10/modules/apps/transfer/types"
	ibc "github.com/cosmos/ibc-go/v10/modules/core"
	ibcexported "github.com/cosmos/ibc-go/v10/modules/core/exported"
	tendermint "github.com/cosmos/ibc-go/v10/modules/light-clients/07-tendermint"
	no_valupdates_genutil "github.com/cosmos/interchain-security/v7/x/ccv/no_valupdates_genutil"
	no_valupdates_staking "github.com/cosmos/interchain-security/v7/x/ccv/no_valupdates_staking"
	icsprovidertypes "github.com/cosmos/interchain-security/v7/x/ccv/provider/types"
	"github.com/wfblockchain/noblechain/v5/x/globalfee"
	tf "github.com/wfblockchain/noblechain/v5/x/tokenfactory"
	tftypes "github.com/wfblockchain/noblechain/v5/x/tokenfactory/types"
)

// module account permissions
var maccPerms = map[string][]string{
	authtypes.FeeCollectorName:  nil,
	distrtypes.ModuleName:       nil,
	icatypes.ModuleName:         nil,
	ibctransfertypes.ModuleName: {authtypes.Minter, authtypes.Burner},
	poastypes.ModuleName:        {authtypes.Staking},
	tftypes.ModuleName:          {authtypes.Minter, authtypes.Burner, authtypes.Staking},
	//ftftypes.ModuleName:                  {authtypes.Minter, authtypes.Burner, authtypes.Staking},
	stakingtypes.BondedPoolName:    {authtypes.Burner, authtypes.Staking},
	stakingtypes.NotBondedPoolName: {authtypes.Burner, authtypes.Staking},
	//cctptypes.ModuleName:                 {authtypes.Minter, authtypes.Burner},
	wasmtypes.ModuleName:                 {authtypes.Minter, authtypes.Burner},
	minttypes.ModuleName:                 {authtypes.Minter},
	govtypes.ModuleName:                  {authtypes.Burner},
	nft.ModuleName:                       nil,
	icsprovidertypes.ConsumerRewardsPool: nil,
}

// Create module manager for the app.
// Ideally, we should just return a slice of module.AppModule, and create the module manager in app.go using the function.
// But module.AppModule as interface is deprecated.
func moduleManager(
	app *App,
	appCodec codec.Codec,
	txConfig client.TxEncodingConfig,
	skipGenesisInvariants bool,
	tmLightClientModule tendermint.LightClientModule,
) *module.Manager /*[]module.AppModule*/ {
	return /*[]module.AppModule*/ module.NewManager(
		no_valupdates_genutil.NewAppModule(
			app.AccountKeeper,
			app.StakingKeeper,
			app,
			txConfig,
		),
		auth.NewAppModule(appCodec, app.AccountKeeper, nil, app.GetSubspace(authtypes.ModuleName)),
		vesting.NewAppModule(app.AccountKeeper, app.BankKeeper),
		bank.NewAppModule(appCodec, app.BankKeeper, app.AccountKeeper, app.GetSubspace(banktypes.ModuleName)),
		gov.NewAppModule(appCodec, app.GovKeeper, app.AccountKeeper, app.BankKeeper, app.GetSubspace(govtypes.ModuleName)),
		staking.NewAppModule(appCodec, app.StakingKeeper, app.AccountKeeper, app.BankKeeper, app.GetSubspace(stakingtypes.ModuleName)),
		poas.NewAppModule(appCodec, app.interfaceRegistry, app.POASKeeper, app.AccountKeeper, app.StakingKeeper),
		mint.NewAppModule(appCodec, app.MintKeeper, app.AccountKeeper, nil, app.GetSubspace(minttypes.ModuleName)),
		slashing.NewAppModule(appCodec, app.SlashingKeeper, app.AccountKeeper, app.BankKeeper, app.StakingKeeper, app.GetSubspace(slashingtypes.ModuleName), app.interfaceRegistry),
		distr.NewAppModule(appCodec, app.DistrKeeper, app.AccountKeeper, app.BankKeeper, app.StakingKeeper, app.GetSubspace(distrtypes.ModuleName)),
		no_valupdates_staking.NewAppModule(appCodec, app.StakingKeeper, app.AccountKeeper, app.BankKeeper, app.GetSubspace(stakingtypes.ModuleName)),
		upgrade.NewAppModule(app.UpgradeKeeper, app.AccountKeeper.AddressCodec()),
		evidence.NewAppModule(app.EvidenceKeeper),
		feegrantmodule.NewAppModule(appCodec, app.AccountKeeper, app.BankKeeper, app.FeeGrantKeeper, app.interfaceRegistry),
		authzmodule.NewAppModule(appCodec, app.AuthzKeeper, app.AccountKeeper, app.BankKeeper, app.interfaceRegistry),
		ibc.NewAppModule(app.IBCKeeper),
		ibcwasm.NewAppModule(app.WasmClientKeeper),
		sdkparams.NewAppModule(app.ParamsKeeper), //nolint:staticcheck
		consensus.NewAppModule(appCodec, app.ConsensusParamsKeeper),
		wasm.NewAppModule(appCodec, &app.WasmKeeper, app.StakingKeeper, app.AccountKeeper, app.BankKeeper, app.MsgServiceRouter(), app.GetSubspace(wasmtypes.ModuleName)),

		ibctransfer.NewAppModule(app.IBCTransferKeeper),
		ica.NewAppModule(&app.ICAControllerKeeper, &app.ICAHostKeeper),
		pfm.NewAppModule(app.PFMKeeper, app.GetSubspace(pfmtypes.ModuleName)),
		ratelimit.NewAppModule(appCodec, app.RatelimitKeeper),
		app.ICSProviderModule,
		tendermint.NewAppModule(tmLightClientModule),

		// these gaia modules are not used in tokenfactory chain yet.
		//metaprotocols.NewAppModule(),
		//feemarket.NewAppModule(appCodec, *app.FeeMarketKeeper),
		//liquid.NewAppModule(appCodec, app.LiquidKeeper, app.AccountKeeper, app.BankKeeper, app.StakingKeeper),
		//telemetry.NewAppModule(&stakingkeeper.Querier{Keeper: app.StakingKeeper}, app.otelClient),

		groupmodule.NewAppModule(appCodec, app.GroupKeeper, app.AccountKeeper, app.BankKeeper, app.interfaceRegistry),
		nftmodule.NewAppModule(appCodec, app.NFTKeeper, app.AccountKeeper, app.BankKeeper, app.interfaceRegistry),
		crisis.NewAppModule(app.CrisisKeeper, skipGenesisInvariants, app.GetSubspace(crisistypes.ModuleName)), //nolint:staticcheck
		circuit.NewAppModule(appCodec, app.CircuitKeeper),
		globalfee.NewAppModule(app.GetSubspace(globalfee.ModuleName)),
		//cctp.NewAppModule(app.CCTPKeeper),
		tf.NewAppModule(appCodec, app.TFKeeper, app.AccountKeeper, app.BankKeeper),
		//ftf.NewAppModule(app.FTFKeeper, app.BankKeeper),

		// these former noble modules are only ibc v8 compatible.
		//forwarding.NewAppModule(app.ForwardingKeeper),
	)
}

const (
	CCTPModuleName             = "cctp"
	TokenFactoryModuleName     = "tokenfactory"
	FiatTokenFactoryModuleName = "fiattokenfactory"
	Params                     = "params"
	ParamauthorityModuleName   = "paramauthority"
)

// ModuleBasics defines the module BasicManager that is in charge of setting up basic,
// non-dependant module elements, such as codec registration
// and genesis verification.
func newBasicManagerFromManager(app *App) module.BasicManager {
	basicManager := module.NewBasicManagerFromManager(
		app.mm,
		map[string]module.AppModuleBasic{
			genutiltypes.ModuleName: genutil.NewAppModuleBasic(genutiltypes.DefaultMessageValidator),
			govtypes.ModuleName: gov.NewAppModuleBasic(
				[]govclient.ProposalHandler{
					paramsclient.ProposalHandler,
				},
			),
			//CCTPModuleName:             cctp.AppModuleBasic{},
			TokenFactoryModuleName: tf.AppModuleBasic{},
			//FiatTokenFactoryModuleName: tf.AppModuleBasic{},
			Params: sdkparams.AppModuleBasic{},
		})
	basicManager.RegisterLegacyAminoCodec(app.legacyAmino)
	basicManager.RegisterInterfaces(app.interfaceRegistry)

	return basicManager
}

/*
orderBeginBlockers tells the app's module manager how to set the order of
BeginBlockers, which are run at the beginning of every block.

Interchain Security Requirements:
During begin block slashing happens after distr.BeginBlocker so that
there is nothing left over in the validator fee pool, so as to keep the
CanWithdrawInvariant invariant.
NOTE: staking module is required if HistoricalEntries param > 0

Q: what happens if a module is not listed here?
*/

func orderBeginBlockers() []string {
	return []string{
		minttypes.ModuleName,
		distrtypes.ModuleName,
		slashingtypes.ModuleName,
		evidencetypes.ModuleName,
		stakingtypes.ModuleName,
		authtypes.ModuleName,
		banktypes.ModuleName,
		govtypes.ModuleName,
		crisistypes.ModuleName,
		ibcexported.ModuleName,
		ibctransfertypes.ModuleName,
		icatypes.ModuleName,
		pfmtypes.ModuleName,
		ratelimittypes.ModuleName,
		genutiltypes.ModuleName,
		authz.ModuleName,
		feegrant.ModuleName,
		paramstypes.ModuleName,
		vestingtypes.ModuleName,
		icsprovidertypes.ModuleName,
		consensusparamtypes.ModuleName,
		wasmtypes.ModuleName,
		ibcwasmtypes.ModuleName,
		crisistypes.ModuleName,
		nft.ModuleName,
		group.ModuleName,
		circuittypes.ModuleName,
		tftypes.ModuleName,
		//ftftypes.ModuleName,
		globalfee.ModuleName,
		//cctptypes.ModuleName,
		//forwardingtypes.ModuleName,
	}
}

/*
Interchain Security Requirements:
- provider.EndBlock gets validator updates from the staking module;
thus, staking.EndBlock must be executed before provider.EndBlock;
- creating a new consumer chain requires the following order,
CreateChildClient(), staking.EndBlock, provider.EndBlock;
thus, gov.EndBlock must be executed before staking.EndBlock

Note: AppKeepers does not include CrisisKeeper but orderEndBlockers includes crisistypes.ModuleName.
Note: upgrade module is here but not in orderBeginBlockers.
*/
func orderEndBlockers() []string {
	return []string{
		crisistypes.ModuleName,
		govtypes.ModuleName,
		stakingtypes.ModuleName,
		ibcexported.ModuleName,
		ibctransfertypes.ModuleName,
		icatypes.ModuleName,
		pfmtypes.ModuleName,
		ratelimittypes.ModuleName,
		authtypes.ModuleName,
		banktypes.ModuleName,
		distrtypes.ModuleName,
		slashingtypes.ModuleName,
		minttypes.ModuleName,
		genutiltypes.ModuleName,
		evidencetypes.ModuleName,
		authz.ModuleName,
		feegrant.ModuleName,
		paramstypes.ModuleName,
		upgradetypes.ModuleName,
		vestingtypes.ModuleName,
		icsprovidertypes.ModuleName,
		consensusparamtypes.ModuleName,
		wasmtypes.ModuleName,
		ibcwasmtypes.ModuleName,
		nft.ModuleName,
		group.ModuleName,
		circuittypes.ModuleName,
		tftypes.ModuleName,
		//ftftypes.ModuleName,
		globalfee.ModuleName,
		//cctptypes.ModuleName,
	}
}

/*
NOTE: The genutils module must occur after staking so that pools are
properly initialized with tokens from genesis accounts.
NOTE: The genutils module must also occur after auth so that it can access the params from auth.
can do so safely.
*/
func orderInitGenesis() []string {
	return []string{
		authtypes.ModuleName,
		banktypes.ModuleName,
		distrtypes.ModuleName,
		govtypes.ModuleName,
		stakingtypes.ModuleName,
		slashingtypes.ModuleName,
		minttypes.ModuleName,
		genutiltypes.ModuleName,
		ibctransfertypes.ModuleName,
		ibcexported.ModuleName,
		icatypes.ModuleName,
		evidencetypes.ModuleName,
		authz.ModuleName,
		feegrant.ModuleName,
		pfmtypes.ModuleName,
		ratelimittypes.ModuleName,
		paramstypes.ModuleName,
		upgradetypes.ModuleName,
		vestingtypes.ModuleName,
		// The feemarket module should ideally be initialized before the genutil module in theory:
		// The feemarket antehandler performs checks in DeliverTx, which is called by gentx.
		// When the fee > 0, gentx needs to pay the fee. However, this is not expected.
		// To resolve this issue, we should initialize the feemarket module after genutil, ensuring that the
		// min fee is empty when gentx is called.
		// A similar issue existed for the 'globalfee' module, which was previously used instead of 'feemarket'.
		// For more details, please refer to the following link: https://github.com/cosmos/gaia/issues/2489
		//feemarkettypes.ModuleName,
		icsprovidertypes.ModuleName,
		consensusparamtypes.ModuleName,
		wasmtypes.ModuleName,
		ibcwasmtypes.ModuleName,
		nft.ModuleName,
		group.ModuleName,
		circuittypes.ModuleName,
		poastypes.ModuleName,
		tftypes.ModuleName,
		//ftftypes.ModuleName,
		globalfee.ModuleName,
		//cctptypes.ModuleName,
		// crisis needs to be last so that the genesis state is consistent
		// when it checks invariants
		crisistypes.ModuleName,
	}
}

func orderExportGenesis() []string {
	return []string{
		ibctransfertypes.ModuleName,
		authtypes.ModuleName,
		banktypes.ModuleName,
		stakingtypes.ModuleName,
		distrtypes.ModuleName,
		slashingtypes.ModuleName,
		govtypes.ModuleName,
		minttypes.ModuleName,
		crisistypes.ModuleName,
		pfmtypes.ModuleName,
		genutiltypes.ModuleName,
		ibctransfertypes.ModuleName,
		ibcexported.ModuleName,
		icatypes.ModuleName,
		evidencetypes.ModuleName,
		authz.ModuleName,
		feegrant.ModuleName,
		pfmtypes.ModuleName,
		ratelimittypes.ModuleName,
		paramstypes.ModuleName,
		upgradetypes.ModuleName,
		vestingtypes.ModuleName,
		icsprovidertypes.ModuleName,
		consensusparamtypes.ModuleName,
		wasmtypes.ModuleName,
		ibcwasmtypes.ModuleName,
		circuittypes.ModuleName,
		poastypes.ModuleName,
		tftypes.ModuleName,
		//ftftypes.ModuleName,
		globalfee.ModuleName,
		//cctptypes.ModuleName,
		nft.ModuleName,
		group.ModuleName,
	}
}
