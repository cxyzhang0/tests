package main

import (
	svrcmd "github.com/cosmos/cosmos-sdk/server/cmd"
	"github.com/wfblockchain/noblechain/v5/app"
	"github.com/wfblockchain/noblechain/v5/cmd"
)

func main() {
	rootCmd := cmd.NewRootCmd()

	svrcmd.Execute(rootCmd, "", app.DefaultNodeHome)
}
